# AUD0603 — revisão independente bounded: parecer final

**Correção específica CONFIRMADA. Nenhum P1/P2 demonstrado contra o contrato aprovado no escopo revalidado; três observações conservadoras/contratuais, sem prioridade automática de defeito.** Encerrei a matriz. A classificação P2 anterior foi retirada: inferia garantias mais amplas que o texto aprovado. As reproduções permanecem válidas.

Candidata `9b85d5b4c6c1f4fb7eee4b1bb4c6e67db3f44e04`; base `4aa4d8f700b922cd38344edbeb0e2c43745bd9bb`. Node22.23.2. Sem escrita em root/checkout/lock/deps. Parecer limitado à entrega: **última leitura de pausa, dependências saudáveis, cancelamento/prazo → corpo0, APPROVED, retry uma vez e replay sem duplicação**.

## Repro base + candidata

| Última leitura async retorna false, dependências saudáveis | Base-runtime | Candidata |
| --- | --- | --- |
| Cancelamento durante await | corpo1; UNCERTAIN/UNCERTAIN | corpo0; APPROVED/EFFECT_FAILED; retry corpo1; replay sem corpo adicional |
| Prazo durante await | corpo1; UNCERTAIN/UNCERTAIN | corpo0; APPROVED/EFFECT_FAILED; retry corpo1; replay sem corpo adicional |

Estados são **aprovação/journal** após tentativa inicial. Repro: [candidate-pause_last-cancel.json](candidate-pause_last-cancel.json), [base-runtime-pause_last-cancel.json](base-runtime-pause_last-cancel.json), variantes `*-pause_last-deadline.json`. A comparação carrega somente runtime.ts da base no endereço original e usa módulos adjacentes da candidata (recovery/journal/approval-engine sem diff no intervalo). **Não é suíte da árvore base completa.**

Duas retomadas concorrentes após pausa/cancelamento da última leitura: corpo total1, journal CONFIRMED e replay sem duplicação. Conformance existente **17/17 PASS**, exit0: [conformance.log](conformance.log), [conformance.json](conformance.json).

## Observações reconciliadas com trechos literais

**KR-F01 — limite conservador observado; sem P2 contratual estabelecido.** `packages/agent-runtime/src/runtime.ts:1259–1275`: cancelamento/prazo após markExecuting ou markEffectStarted, mas antes de toolExecutor, dá corpo0 e UNCERTAIN/UNCERTAIN; retry operation_uncertain. Quatro casos, iguais na base/candidata. [candidate-approval_executing-cancel.json](candidate-approval_executing-cancel.json), [candidate-effect_started-deadline.json](candidate-effect_started-deadline.json) e variantes.

- SPEC0181 I8, `docs/02_spec/0181_kernel_plugin_contract.md:97`: **“Cancelamento antes do despacho não executa a ferramenta nem registra efeito”**. Não exige APPROVED nem retry após a marca de início. O corpo permaneceu0; o journal de intenção foi conservado como incerto, não como efeito confirmado.
- `packages/agent-runtime/src/contracts.ts:129–133`: **“Only `no_effect` allows an approval to be released back to APPROVED; anything else keeps an honest UNCERTAIN state without automatic retry.”** É condição de permissão para release, não obrigação de converter toda interrupção pré-corpo em no_effect persistido.
- SPEC §11.1, linhas185–189: **“Cancelamento, prazo esgotado e falha de plugin antes do despacho continuam terminais e usam `fail`”**; **“a aprovação volta a `APPROVED`”** descreve o release do DurableApprovalEngineAdapter para pausa, não garantia universal da ApprovalAuthority após markEffectStarted. Não existe trecho literal exigindo APPROVED/retry nos quatro cenários sondados.

**Proposta**, sujeita a contrato/decisão: registrar prova confiável pré-despacho para evitar reconciliação conservadora desnecessária. Até lá, liveness limitada, sem efeito/duplicação demonstrados; não bloqueia automaticamente a correção da última leitura saudável.

**KR-F02 — limite de recuperação sob falha de infraestrutura; sem P2 contratual estabelecido.** `runtime.ts:1313–1329`, `runtime-effect-recovery.ts:929–945`: pause + release falha uma vez retorna paused com EXECUTING/EFFECT_FAILED; retry recupera e executa1. Pause + failEffect falha uma vez retorna paused com APPROVED/EFFECT_STARTED; retry operation_in_progress; depois de +61s, UNCERTAIN/UNCERTAIN, corpo total0. A/B iguais na base; TTL só candidato. [candidate-pause-release-outage.json](candidate-pause-release-outage.json), [candidate-pause-journal-outage.json](candidate-pause-journal-outage.json), [candidate-supplement-pause-journal-outage-ttl.json](candidate-supplement-pause-journal-outage-ttl.json).

- SPEC I12, linha101: **“Pausa reconhecida impede o próximo efeito ainda não iniciado; entradas pendentes não são apagadas”**. Não promete conclusão de release/failEffect quando a porta falha.
- Contrato paused, `contracts.ts:71–73`: **“no new effect started and no approval was consumed. The caller keeps the work and retries it after the pause is lifted.”** Define preservação/possibilidade de repetir a chamada, não sucesso garantido com settlement indisponível. Não foi demonstrado corpo ou consumo definitivo nessas tentativas.
- SPEC §11.1, linhas186–187: **“Porta sem `release`, ou `release` que falha, cai em `fail`.”** Obrigação explícita da **ApprovalExecutionPort** daquele kernel; o runtime auditado usa **ApprovalAuthority**. Não há cláusula correspondente garantindo APPROVED ou retry bem-sucedido sob falha da authority/journal. §13.3, linhas248–252, trata pausa antes da reserva e switch ilegível, não settlement pós-reserva falho.

**Proposta**: expor falha de settlement separada da pausa e preservar prova de ausência para recuperação. Sem aplicar a obrigação de outro port a este runtime. Não significa garantia de retomada em infraestrutura degradada.

**KR-F03 — ambiguidade de precedência; sem P2 aprovado demonstrado.** `runtime.ts:1309–1331`: leitura async aborta signal e retorna pausa → paused:operator_paused, corpo0, APPROVED/EFFECT_FAILED. Idêntico na base. [candidate-last-cancel_pause.json](candidate-last-cancel_pause.json); deadline+pause também observado.

- SPEC **I8** exige ausência de execução antes do despacho; **I11**, linha100, diz **“Orçamento é verificado num único lugar (controle `budget`) antes de cada passo, chamada ao modelo e chamada de ferramenta”**. Nenhum dos dois estabelece precedência de cancelamento sobre pausa, nem fala explicitamente de suspensão após o último await. O §8 da SPEC0181 é “Fora do escopo”.
- `contracts.ts:57–60` contém **“checkpoints before each budgeted stage and after each await interrupt the turn with `turn_cancelled`”**. É o vínculo literal mais forte para a expectativa de motivo; porém não define arbitragem quando a leitura também reconhece pausa, que I12 determina respeitar. Aponto tensão de documentação/precedência, não decreto prioridade que a SPEC não explicitou.

**Proposta**: definir cancelamento vs pausa vs prazo concorrentes e assertar o motivo escolhido; ambas invariantes de não despacho foram respeitadas nas sondas. O worker trata paused especialmente (`apps/worker/src/kernel-composition.ts:651–652`), mas o fluxo de fila PG não foi executado aqui.

## Contagens e artefatos

Máquinas reais: **ApprovalEngine + InMemoryApprovalStore**, **FileEffectJournal** em journals próprios, wrappers preservando métodos reais e awaits/setImmediate. Runtime/journal reabertos antes do retry; authority mantida em memória. Estados iniciais, antes do retry:

| Execução | Aprovação | Journal | Corpo inicial0/1 | Máximo corpo total/caso |
| --- | --- | --- | --- | --- |
| Candidata24 | APPROVED15; UNCERTAIN7; EXECUTING2 | EFFECT_FAILED15; UNCERTAIN7; EFFECT_STARTED1; CONFIRMED1 | 20/4 | 1 |
| Base-runtime24 | APPROVED13; UNCERTAIN9; EXECUTING2 | EFFECT_FAILED13; UNCERTAIN9; EFFECT_STARTED1; CONFIRMED1 | 18/6 | 1 |
| Suplemento3 | APPROVED3 | EFFECT_FAILED2; EFFECT_STARTED1 | 3/0 | 1 |

Os quatro corpos iniciais da candidata pertencem a controles deliberados pós-despacho; os dois adicionais da base são o bug corrigido. [state-counts.json](state-counts.json). Pós-corpo cancelado/prazo/erro unknown conserva UNCERTAIN sem retry; pós-confirmação mantém CONFIRMED/effectConfirmed:true e replay sem corpo adicional.

Os oracles **amplos** originais deram candidata16/24, base14/24, suplemento2/3; zero erro de fixture; auditoria válida51/51. Esses FAILs medem garantias de retomada/classificação propostas acima e **não são automaticamente falhas do contrato aprovado**. Dados preservados em [summary.json](summary.json), [candidate-results.json](candidate-results.json), [base-runtime-results.json](base-runtime-results.json), [candidate-supplement-results.json](candidate-supplement-results.json). Script exit0 agrega todos os casos; campos failures guardam a avaliação original. Revisão normativa atual é este arquivo.

Fontes: [probes.mjs](probes.mjs), [loader.mjs](loader.mjs), [runtime.diff](runtime.diff); JSON/logs por caso. [evidence-detail.md](evidence-detail.md) é histórico, com classificação anterior explicitamente superada. [criteria.md](criteria.md) registra a reconciliação solicitada, sem novas execuções ou alteração de resultados.

## Limites / encerramento

Nenhum PG/Docker/E2E/certify/fullsuite/cobertura/install/subagente/commit/push/dado real. Não incorporei PG299PASS/cobertura do lead. Não provei restart de processo com approval persistida, multihost ou commit PG ambíguo. Loader sem typecheck; conformance Vitest node, cache/config próprios. Não li arquivos de relatórios/conclusões de auditor/builder; ledgers obrigatórios continham resumos históricos, não usados como prova.

Inputs/lockfile **MATCH**, SHA intacto: [manifest-before.json](manifest-before.json), [manifest-after.json](manifest-after.json). Status final mostrou alteração de certification/mutation-guard.json fora do escopo e dos comandos reviewer; não revertida; não alego checkout global limpo. Somente arquivos próprios escritos. Lead integra este parecer final; observações KR-F01–03 podem gerar decisão/SPEC futura, não impedimento automático da correção comprovada. Sem parecer de release.

## Registro final de integração — diferença preservada

Lead informou que integrará KR-F03 como **P2 canônico** pelo motivo literal de `packages/agent-runtime/src/contracts.ts:57–60`, com três reproduções próprias. Este reviewer confirma sua evidência de cancel+pause → paused/corpo0, mas preserva a ressalva autônoma: I8/I11/I12 da SPEC0181 não definem a precedência concorrente; há tensão entre o comentário local de motivo e a regra de pausa. As três reproduções adicionais do lead não foram lidas/reexecutadas por esta lane. KR-F01/F02 permanecem observações conservadoras/recuperação a esclarecer, sem P2 canônico. O total informado pelo lead é três P2 (dois de sessão + cancelreason); sessão está fora deste parecer e esse total não é verificação independente desta lane. Lane **ENCERRADA**, sem novos probes nem rootwrites.
