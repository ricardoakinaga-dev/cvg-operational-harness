> HISTÓRICO SUPERADO na classificação normativa. As prioridades P2 deste texto foram retiradas após separar a barra ampla das sondas do contrato aprovado. Use review.md para integração; reproduções/dados permanecem válidos.

# AUD0603 — revisão independente bounded do kernel

Revisão concluída, somente leitura dos checkouts. Candidata `9b85d5b4c6c1f4fb7eee4b1bb4c6e67db3f44e04`, base `4aa4d8f700b922cd38344edbeb0e2c43745bd9bb`. Node `22.23.2`; dependências existentes da candidata. Artefatos e journals sintéticos exclusivamente neste diretório.

**Resultado: correção da última leitura assíncrona confirmada; aderência integral aos critérios solicitados PARTIAL, com três P2 herdados.** Nenhum corpo indevido ou duplicado observado na candidata nas sondas executadas. A base com o runtime anterior executa corpo 1 nos dois casos de cancelamento/prazo durante a leitura final; a candidata executa corpo 0 e permite retry uma vez. Isto confirma a correção específica e não fecha os caminhos restantes de estado/settlement. Não é parecer de release/produção.

## Escopo, contratos e independência

- Diff de `packages/agent-runtime/src/runtime.ts` e `tests/conformance/agent-runtime.conformance.test.ts`, entre os SHAs acima. Fontes adjacentes de recuperação, journal e aprovação; `packages/agent-runtime/src/contracts.ts`, `packages/contracts/src/contracts.ts`, SPEC0181 e o consumidor do resultado `paused` no worker.
- Barra congelada em [criteria.md](criteria.md): corpo 0 em parada pré-despacho, aprovação reutilizável quando há certeza de não efeito, resume once/replay sem duplicação, pausa consistente, certeza do efeito correta. SPEC0181 I4/I5/I8/I11/I12 e §13.3; contrato de `cancelSignal` e `paused` do runtime durável.
- Não consultei arquivos de relatórios/conclusões de auditor ou builder. Li as instruções e os ledgers obrigatórios do repositório, que contêm resumos históricos; esses resumos não foram usados como prova de comportamento. Só o mecanismo do loader anterior autorizado foi aproveitado. Fixture, sondas e julgamento próprios, sem subagentes.
- Não generalizo a regra `ApprovalExecutionPort.fail` do §11.1 a `ApprovalAuthority` deste runtime: os contratos são diferentes. A reutilização após cancelamento/prazo nesta revisão deriva da barra explícita do solicitante e é também comportamento exigido pelos testes novos da candidata.

## Evidência executada

| Procedimento | Resultado atual | Artefatos |
| --- | --- | --- |
| Conformance existente do GovernedAgentRuntime, Vitest 4.1.11, environment node, cache/config próprios | 17/17 PASS, exit 0 | [conformance.log](conformance.log), [conformance.json](conformance.json), [vitest.config.mjs](vitest.config.mjs) |
| 24 sondas próprias, candidata, ApprovalEngine real + InMemoryApprovalStore real + FileEffectJournal real | 16 critérios/casos PASS; 8 casos com falha de oracle; zero erro de fixture | [candidate-results.json](candidate-results.json), [candidate-probes.log](candidate-probes.log) |
| Mesmas 24 sondas, runtime.ts da base carregado no endereço original, demais módulos da candidata | 14 PASS; 10 casos com falha de oracle; zero erro de fixture | [base-runtime-results.json](base-runtime-results.json), [base-runtime-probes.log](base-runtime-probes.log), [base-runtime.ts](base-runtime.ts) |
| Suplemento: retomada concorrente após pausa e cancelamento; falha de journal seguida de TTL | 2 PASS; 1 falha de oracle; zero erro de fixture | [candidate-supplement-results.json](candidate-supplement-results.json), [supplement-probes.log](supplement-probes.log) |
| Cadeia de auditoria real das sondas | Valid em todos os 51 casos (24 candidata + 24 comparação + 3 suplemento) | JSON individual de cada caso, campo `auditValid` |
| Hash dos inputs/lockfile e SHA antes/depois | MATCH | [manifest-before.json](manifest-before.json), [manifest-after.json](manifest-after.json) |

As falhas dos oracles são falhas dos critérios, não exceções do executável de sondas. O processo das sondas termina 0 para preservar todos os resultados; o campo `failures` e os totais em [summary.json](summary.json) são a autoridade para PASS/FAIL. Journals reais em `journals/`, reabertos por uma nova instância do runtime antes do retry. O store de aprovação permanece a autoridade real em memória; não há alegação de persistência da aprovação após restart de processo.

### Achado KR-F01 — P2 — cancelamento/prazo antes do corpo produz falsa incerteza e impede retomada

**Paths/linhas:** `packages/agent-runtime/src/runtime.ts:1232` (await de `approvals.markExecuting`), `:1250` (await de `markEffectStarted`), `:1259–1275` (`postStartStop` marca journal e aprovação UNCERTAIN antes de `toolExecutor` em `:1357`). `runtime-effect-recovery.ts:948–961` persiste evidence `unknown`. Contrato local de certeza em `contracts.ts:139–150`; barra C2/C4.

**Reprodução:** abortar ou avançar relógio +31s depois de o await real de `markExecuting` ou `markEffectStarted` terminar. Os wrappers preservam o método real e acrescentam `await setImmediate()`; não substituem a máquina de estados. Resultado inicial `denied:turn_cancelled` ou `denied:loop_deadline_exceeded`, corpo **0**, aprovação **UNCERTAIN**, journal **UNCERTAIN**. Retry e replay retornam `denied:operation_uncertain`, corpo total **0**. Nenhum despacho ocorreu; o próprio runtime tem certeza de ausência de corpo, mas usa a semântica de efeito possivelmente iniciado.

**Impacto:** aprovação concedida deixa de ser reutilizável e o trabalho exige reconciliação humana indevida. É falha de recuperação/certeza; não foi demonstrado efeito indevido. A reserva de efeito marcada `EFFECT_STARTED` antes do despacho não prova, sozinha, que o corpo rodou.

**Evidência:** [candidate-approval_executing-cancel.json](candidate-approval_executing-cancel.json), [candidate-approval_executing-deadline.json](candidate-approval_executing-deadline.json), [candidate-effect_started-cancel.json](candidate-effect_started-cancel.json), [candidate-effect_started-deadline.json](candidate-effect_started-deadline.json). Mesmos resultados nos arquivos `base-runtime-*` correspondentes: **herdado**, não regressão diferencial.

**Fechamento esperado:** separar inequivocamente pré-despacho de corpo já invocado; quando não houve corpo e o settlement for confirmado, journal com prova de no-effect e aprovação APPROVED, retry com corpo 1, replay/concurrent retry sem segundo corpo. Preservar UNCERTAIN quando o corpo começou ou a prova não pôde ser persistida. Incluir os quatro checkpoints no teste; os controles pós-corpo das sondas já confirmam a necessidade de manter UNCERTAIN nesses outros cenários.

### Achado KR-F02 — P2 — `paused` esconde falha de settlement; estado pode não ser retomável

**Paths/linhas:** `packages/agent-runtime/src/runtime.ts:1313–1329`: exceção de `failEffect` é engolida, retorno booleano de `releaseApproval` é ignorado, resposta continua `paused`. `runtime-effect-recovery.ts:929–945` transforma falha de release em `false`. Contrato `paused` em `contracts.ts:70–75` e SPEC0181 I12/§13.3.

**Reprodução A:** pausa na última leitura; somente `approvals.release` falha uma vez. Resposta **paused:operator_paused**, corpo **0**, aprovação ainda **EXECUTING**, journal **EFFECT_FAILED**. O retry posterior se recupera e executa uma vez, mas a resposta inicial declarou pausa limpa com a reserva ainda pendente.

**Reprodução B:** pausa na última leitura; somente `journal.failEffect` falha uma vez. Resposta **paused:operator_paused**, corpo **0**, aprovação **APPROVED**, journal **EFFECT_STARTED**. Depois de levantar pausa e restaurar dependência, retry/replay devolvem **operation_in_progress**, corpo total **0**. Depois de +61s, o sweep real torna o journal **UNCERTAIN**; o novo turno torna também a aprovação **UNCERTAIN**, retorna **operation_uncertain** e não retoma. A falha transitória não ganha settlement posterior de no-effect.

**Impacto:** a pausa reportada como retomável pode perder retomabilidade e exigir reconciliação apesar de corpo 0. A falha operacional não aparece na resposta; o consumidor do worker em `apps/worker/src/kernel-composition.ts:651–652` interpreta `paused` como `KernelPausedError`. A consequência completa na fila PostgreSQL não foi executada aqui. Não houve duplicação observada.

**Evidência:** [candidate-pause-release-outage.json](candidate-pause-release-outage.json), [candidate-pause-journal-outage.json](candidate-pause-journal-outage.json), [candidate-supplement-pause-journal-outage-ttl.json](candidate-supplement-pause-journal-outage-ttl.json). A/B também falham na base: **herdado**; suplemento TTL só executado na candidata.

**Fechamento esperado:** settlement confirmado ou falha explícita, com prova de no-effect preservada para recuperação. Não anunciar pausa limpa/retomável enquanto approval/journal divergem. Testar falhas isoladas e combinadas de journal/release, retry e sweep; manter proteção contra retry com efeito incerto real.

### Achado KR-F03 — P2 — pausa na mesma leitura oculta cancelamento do turno

**Paths/linhas:** `packages/agent-runtime/src/runtime.ts:1309–1331`: `finishPaused` retorna antes de executar `beginStage`/`stopReason`. Contrato `cancelSignal` em `contracts.ts:56–62` exige `turn_cancelled` após checkpoints awaited. A mesma ordem existe em `pausedStop` em `runtime.ts:439–447`.

**Reprodução:** na leitura final verdadeiramente assíncrona, abortar o signal e responder `true` para pausa. Resultado **paused:operator_paused**, corpo **0**, aprovação **APPROVED**, journal **EFFECT_FAILED**. Levantar pausa e repetir com signal novo executa corpo 1; o cancelamento anterior não consta como motivo terminal. O contrato do turno pede `turn_cancelled`; a parada foi reportada como retomável.

**Impacto:** cancelamento e pausa produzem desfechos distintos para o consumidor. O worker trata `paused` de modo especial para preservar pendência; portanto a diferença de classificação importa, mesmo sem efeito na primeira tentativa. Isto não significa que a aprovação precise ser destruída: turno cancelado e aprovação reutilizável são fatos separados.

**Evidência:** [candidate-last-cancel_pause.json](candidate-last-cancel_pause.json); mesmo resultado em [base-runtime-last-cancel_pause.json](base-runtime-last-cancel_pause.json): **herdado**. [candidate-last-deadline_pause.json](candidate-last-deadline_pause.json) mostra o análogo de prazo; a SPEC não fixa explicitamente precedência global entre prazo e pausa, então essa variante fica como extensão a esclarecer, não prova independente de um quarto defeito.

**Fechamento esperado:** revalidar a parada terminal depois da leitura awaited, preservar motivo do cancelamento mesmo se pausa também estiver ligada, liquidar no-effect sem perder a aprovação e deixar retomada explícita num turno novo. Definir e testar a precedência de prazo + pausa no contrato.

## Comportamentos confirmados e avaliação da conformance

- Na candidata, cancelamento/prazo durante a leitura final (que retorna false) dá corpo 0, APPROVED/EFFECT_FAILED, retry executado, replay `idempotent_replay`, mesmo com caller idempotency key alterada. O runtime.ts anterior dá corpo 1 e UNCERTAIN nos mesmos casos. **Correção específica confirmada.**
- Cancelamento/prazo depois de reservar aprovação ou journal dá corpo 0 e aprovação reutilizável. Pausa depois de reservar aprovação, journal, `markExecuting` ou `markEffectStarted` dá pausa limpa no caminho saudável, corpo 0 e retomada/replay sem duplicação.
- Leitura final indisponível dá `paused:pause_state_unavailable`, corpo 0 e retomada segura quando o settlement funciona.
- Duas retomadas concorrentes, depois de pausa e depois de cancelamento na leitura final: corpo total 1, journal final CONFIRMED, replay sem corpo adicional. Journal reaberto de arquivo antes da retomada; a aprovação permanece no store original.
- Cancelamento/prazo dentro do corpo, e erro de ferramenta com certeza `unknown`: corpo 1, journal/aprovação UNCERTAIN, retry bloqueado. Cancelamento após confirmação do journal: resposta inclui `effectConfirmed:true`, journal continua CONFIRMED e recuperação/replay não chamam o corpo novamente.
- Os testes novos em `tests/conformance/agent-runtime.conformance.test.ts:404–452` validam bem a janela específica, mas não cobrem os checkpoints do KR-F01, falhas de settlement ou cancel+pause. Os casos novos não assertam o journal nem replay após retomada. O replay em `:399` aceita qualquer outcome diferente de `executed`, o que prova no duplicate via contador, mas não exige replay confirmado. O 17/17 não demonstra a barra inteira.

## Reexecução e artefatos

Fonte das sondas: [probes.mjs](probes.mjs); loader: [loader.mjs](loader.mjs); diff: [runtime.diff](runtime.diff). Cada caso guarda resposta, aprovação, journal, contadores, checkpoints, histórico de tipos de auditoria e falhas do oracle em JSON individual. Para reexecutar, usar **novo LABEL** para não reutilizar journals já confirmados:

```sh
cd /tmp/cvg-aud0603-20261006/kernel-reviewer
AUD0603_LABEL=candidate-fresh /home/ricardo/.nvm/versions/node/v22.23.2/bin/node --import ./loader.mjs ./probes.mjs
AUD0603_LABEL=base-fresh AUD0603_RUNTIME_BASE=/tmp/cvg-aud0603-20261006/kernel-reviewer/base-runtime.ts /home/ricardo/.nvm/versions/node/v22.23.2/bin/node --import ./loader.mjs ./probes.mjs
```

O arquivo atual contém 27 casos; as primeiras execuções foram de 24, com os 3 novos executados separadamente pelo filtro `AUD0603_CASE_FILTER='concurrent|outage-ttl'`. O filtro/totais constam nos logs e JSON. Critérios não foram relaxados após a execução.

## Limitações e preservação

- Auditoria local bounded; nenhum PostgreSQL, Docker, E2E, certify, fullsuite, installs, provider, dado real, subagente, commit ou push. Não houve escrita de fonte, root, lockfile ou deps. Não há aprovação de rollout nem teste de crash/queda de processo ou concorrência entre hosts.
- ApprovalEngine e FileEffectJournal são implementações reais; injeções de falha atuam nas fronteiras dos métodos. Não comprovam timeout/commit ambíguo de PostgreSQL. Clock controlado; `setImmediate` torna a leitura/checkpoint genuinamente assíncrono; não é teste de carga.
- Vitest com environment node e aliases próprios para os mesmos fontes, sem a configuração jsdom global; nenhum DOM é usado nesse arquivo. O loader transpila TS sem typecheck; não declaro lint/typecheck/cobertura novos.
- Comparação é do runtime.ts da base com os módulos adjacentes da candidata, não execução integral da base. `git diff` confirma nenhuma mudança em recovery/journal/approval-engine nesse intervalo; apenas o runtime e conformance mudam no escopo relevante.
- Inputs congelados e lockfile mantiveram os hashes. O status inicial da candidata era limpo; ao final havia `M certification/mutation-guard.json`, fora dos inputs auditados. Os comandos desta revisão não executaram mutation guard nem escreveram esse path. Nenhuma tentativa de revertê-lo; o claim lead cobre trabalho simultâneo. Não declaro checkout global limpo.
- Ledgers/root foram preservados por instrução direta de escrever apenas aqui. Handoff para o lead: agregar este parecer/evidências e registrar estado/log/backlog nos caminhos do claim lead. Próximo passo de implementação, se autorizado ao owner, é tratar os três P2 e reauditar os mesmos negativos no novo SHA; a correção específica já está comprovada.
