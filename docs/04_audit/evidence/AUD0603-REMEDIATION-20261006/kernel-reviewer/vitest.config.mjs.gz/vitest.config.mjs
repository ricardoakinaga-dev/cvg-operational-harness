export default {
  "root": "/tmp/cvg-aud0603-20261006/kernel-reviewer",
  "cacheDir": "/tmp/cvg-aud0603-20261006/kernel-reviewer/vite-cache",
  "test": {
    "environment": "node",
    "include": [
      "/tmp/cvg-aud0603-20261006/candidate/tests/conformance/agent-runtime.conformance.test.ts"
    ],
    "fileParallelism": false,
    "maxWorkers": 1
  },
  "resolve": {
    "alias": {
      "@cvg/harness-contracts": "/tmp/cvg-aud0603-20261006/candidate/packages/contracts/src/index.ts",
      "@cvg/harness-orchestrator": "/tmp/cvg-aud0603-20261006/candidate/packages/orchestrator/src/index.ts",
      "@cvg/harness": "/tmp/cvg-aud0603-20261006/candidate/packages/harness/src/index.ts",
      "@cvg/shared": "/tmp/cvg-aud0603-20261006/candidate/packages/shared/src/index.ts",
      "@cvg/persistence": "/tmp/cvg-aud0603-20261006/candidate/packages/persistence/src/index.ts",
      "@cvg/agent-core": "/tmp/cvg-aud0603-20261006/candidate/packages/agent-core/src/index.ts",
      "@cvg/legacy-secretary-evals": "/tmp/cvg-aud0603-20261006/candidate/legacy/packages/secretary-evals/src/index.ts",
      "@cvg/legacy-secretary-journeys": "/tmp/cvg-aud0603-20261006/candidate/legacy/packages/secretary-journeys/src/index.ts",
      "@cvg/legacy-secretary-profile": "/tmp/cvg-aud0603-20261006/candidate/legacy/packages/secretary-profile/src/index.ts",
      "@cvg/policy": "/tmp/cvg-aud0603-20261006/candidate/packages/policy/src/index.ts",
      "@cvg/adapters": "/tmp/cvg-aud0603-20261006/candidate/packages/adapters/src/index.ts",
      "@cvg/rag": "/tmp/cvg-aud0603-20261006/candidate/packages/rag/src/index.ts",
      "@cvg/platform": "/tmp/cvg-aud0603-20261006/candidate/packages/platform/src/index.ts",
      "@cvg/model-gateway": "/tmp/cvg-aud0603-20261006/candidate/packages/model-gateway/src/index.ts",
      "@cvg/policy-engine": "/tmp/cvg-aud0603-20261006/candidate/packages/policy-engine/src/index.ts",
      "@cvg/approval-engine": "/tmp/cvg-aud0603-20261006/candidate/packages/approval-engine/src/index.ts",
      "@cvg/channel-gateway": "/tmp/cvg-aud0603-20261006/candidate/packages/channel-gateway/src/index.ts",
      "@cvg/observability": "/tmp/cvg-aud0603-20261006/candidate/packages/observability/src/index.ts",
      "@cvg/agent-runtime": "/tmp/cvg-aud0603-20261006/candidate/packages/agent-runtime/src/index.ts",
      "@cvg/agent-evals": "/tmp/cvg-aud0603-20261006/candidate/packages/agent-evals/src/index.ts",
      "@cvg/chaos": "/tmp/cvg-aud0603-20261006/candidate/packages/chaos/src/index.ts",
      "@cvg/conversation": "/tmp/cvg-aud0603-20261006/candidate/packages/conversation/src/index.ts"
    }
  },
  "server": {
    "fs": {
      "allow": [
        "/tmp/cvg-aud0603-20261006/candidate",
        "/tmp/cvg-aud0603-20261006/kernel-reviewer"
      ]
    }
  },
  "ssr": {
    "noExternal": [
      "@cvg/"
    ]
  }
};
