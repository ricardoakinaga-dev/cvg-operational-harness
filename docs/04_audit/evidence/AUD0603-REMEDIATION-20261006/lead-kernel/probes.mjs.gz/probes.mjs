import { createRequire } from 'node:module';
import { writeFileSync } from 'node:fs';
import { setImmediate as immediate } from 'node:timers/promises';
import { ApprovalEngine, InMemoryApprovalStore } from '@cvg/approval-engine';
import { DeterministicModelProvider, ModelGateway, PromptRegistry } from '@cvg/model-gateway';
import { PolicyEngine, REFERENCE_POLICY_PROFILE } from '@cvg/policy-engine';
import { HashChainedAuditLedger, InMemoryTelemetry } from '@cvg/observability';
import { GovernedAgentRuntime, FileEffectJournal, ToolExecutionError } from '@cvg/agent-runtime';
const require = createRequire('/tmp/cvg-aud0603-20261006/candidate/package.json');
const { z } = require('zod');
const DIR = '/tmp/cvg-aud0603-20261006/lead-kernel';
const LABEL = process.env.AUD0603_LABEL ?? 'candidate';
const TENANT = 'tenant_00000000-0000-4000-8000-000000000073';
const AGENT = 'agent_00000000-0000-4000-8000-000000000073';
const epoch = Date.parse('2026-10-06T12:00:00Z');
function turn(extra = {}) {
  return { tenantId: TENANT, operatorId: 'op_synthetic_a', operatorRole: 'Supervisor',
    agentId: AGENT, agentVersion: 'v1', agentProfile: 'assistant', conversationId: 'conv_probe',
    correlationId: 'corr_00000000-0000-4000-8000-000000000073', capability: 'record.cancel',
    action: 'record.cancel', resource: { type: 'record', id: 'synthetic_73', tenantId: TENANT },
    dataClassification: 'INTERNAL', prompt: { promptId: 'probe', version: '1.0.0' },
    modelProfile: 'fast', modelMessages: { messages: [{ role: 'user', content: 'Synthetic audit payload' }] },
    structuredOutput: { schemaName: 'Payload', schema: z.object({ text: z.string() }) }, ...extra };
}
async function executeCase(spec) {
  let offset = 0, armed = false, fired = false, paused = false, unreadable = false;
  let reads = 0, bodies = 0, outboxCalls = 0, failCalls = 0, releaseCalls = 0;
  const clock = () => new Date(epoch + offset);
  const controller = new AbortController();
  const checkpoints = [], bodiesLog = [];
  const prompts = new PromptRegistry();
  prompts.register({ promptId: 'probe', version: '1.0.0', content: 'Synthetic only.', owner: 'platform',
    approvedBy: 'synthetic_reviewer', status: 'approved', effectiveFrom: '2026-09-01T00:00:00Z', classification: 'INTERNAL', tenantId: TENANT });
  const modelGateway = new ModelGateway({ providers: [new DeterministicModelProvider({ respond: () => ({
    text: JSON.stringify({ text: 'SYNTHETIC' }), usage: { inputTokens: 2, outputTokens: 2 },
    providerId: 'deterministic', model: 'deterministic-v1', externalCall: false }) })],
    profiles: { fast: { name: 'fast', providerId: 'deterministic', model: 'deterministic-v1', location: 'local',
      temperature: 0, maxTokens: 256, timeoutMs: 5000, maxCostUsd: 1, estimatedCostUsd: 0, maxRetries: 0,
      pricing: { inputPer1kUsd: 0, outputPer1kUsd: 0 } } }, prompts, clock, retry: { maxRetries: 0 } });
  const approvals = new ApprovalEngine({ store: new InMemoryApprovalStore(), clock });
  const policy = new PolicyEngine({ profile: REFERENCE_POLICY_PROFILE, documents: [], clock });
  const audit = new HashChainedAuditLedger();
  const telemetry = new InMemoryTelemetry({ clock });
  const directory = `${DIR}/journals/${LABEL}/${spec.name}`;
  const journal = new FileEffectJournal({ directory, clock });
  function trigger(point) {
    checkpoints.push({ point, armed, offset, aborted: controller.signal.aborted });
    if (!armed || fired || spec.point !== point) return;
    fired = true;
    if (spec.fault.includes('cancel')) controller.abort('synthetic abort at ' + point);
    if (spec.fault.includes('deadline')) offset += 31000;
    if (spec.fault.includes('pause')) paused = true;
    if (spec.fault === 'unavailable') unreadable = true;
  }
  for (const [obj, method, point] of [[approvals, 'reserve', 'approval_reserve'],
    [journal, 'reserve', 'journal_reserve'], [approvals, 'markExecuting', 'approval_executing'],
    [journal, 'markEffectStarted', 'effect_started'], [journal, 'confirmEffect', 'effect_confirmed']]) {
    const original = obj[method].bind(obj);
    obj[method] = async (...args) => { const result = await original(...args); await immediate(); trigger(point); return result; };
  }
  const originalFail = journal.failEffect.bind(journal);
  journal.failEffect = async (...args) => {
    failCalls++;
    if (armed && spec.failJournal && failCalls === 1) throw new Error('synthetic failEffect outage');
    return await originalFail(...args);
  };
  const originalRelease = approvals.release.bind(approvals);
  approvals.release = async (...args) => {
    releaseCalls++;
    if (armed && spec.failRelease && releaseCalls === 1) throw new Error('synthetic approval release outage');
    return await originalRelease(...args);
  };
  const options = { policy, approvals, modelGateway, telemetry, audit, effectJournal: journal,
    effectScopes: { 'record.cancel': 'controlled_fake' }, clock,
    pause: { isPaused: async () => { await immediate(); reads++; trigger(reads === 1 ? 'pause_first' : 'pause_last');
      if (unreadable) throw new Error('synthetic pause outage'); return paused; } },
    toolExecutor: async (invocation) => {
      bodies++; bodiesLog.push({ aborted: invocation.signal?.aborted, offset, payload: invocation.payload });
      trigger('body');
      if (armed && spec.toolError) throw new ToolExecutionError('synthetic_failure', 'synthetic failure', { certainty: spec.toolError });
      return { result: { ok: true, synthetic: true } };
    }, outbox: async (event) => { outboxCalls++; return { eventId: `evt_${event.idempotencyKey}` }; } };
  let runtime = new GovernedAgentRuntime(options);
  const requested = await runtime.runTurn(turn());
  if (requested.outcome !== 'approval_required') throw new Error('fixture did not request approval: ' + JSON.stringify(requested));
  const id = requested.approvalId;
  await approvals.submit(TENANT, id, 'op_synthetic_a');
  await approvals.approve(TENANT, id, { approverId: 'op_synthetic_b' });
  armed = true; reads = 0;
  const first = await runtime.runTurn(turn({ approvalId: id, cancelSignal: controller.signal, idempotencyKey: 'synthetic-key-73' }));
  const approvalFirst = approvals.get(TENANT, id);
  const journalFirst = approvalFirst.operationKey ? await journal.get(TENANT, approvalFirst.operationKey) : undefined;
  const bodiesFirst = bodies;
  armed = false; paused = false; unreadable = false;
  // Recreate the runtime and reopen its actual file journal, preserving the real approval authority.
  options.effectJournal = new FileEffectJournal({ directory, clock });
  runtime = new GovernedAgentRuntime(options);
  const retries = spec.concurrent
    ? await Promise.all([runtime.runTurn(turn({ approvalId: id, idempotencyKey: 'synthetic-key-changed-after-denial' })),
        runtime.runTurn(turn({ approvalId: id, idempotencyKey: 'synthetic-key-other-concurrent' }))])
    : [await runtime.runTurn(turn({ approvalId: id, idempotencyKey: 'synthetic-key-changed-after-denial' }))];
  const retry = retries.find(r => r.outcome === 'executed') ?? retries[0];
  const replay = await runtime.runTurn(turn({ approvalId: id }));
  const approvalEnd = approvals.get(TENANT, id);
  const journalEnd = approvalEnd.operationKey ? await options.effectJournal.get(TENANT, approvalEnd.operationKey) : undefined;
  const failures = [];
  const check = (name, truth) => { if (!truth) failures.push(name); };
  if (spec.expected === 'no_effect_reusable') {
    check('body0_before_denial', bodiesFirst === 0);
    check('approval_reusable_after_no_effect', approvalFirst.status === 'APPROVED');
    check('retry_executes_once', retry.outcome === 'executed' && bodies === 1);
    check('replay_confirmed_no_duplicate', replay.outcome === 'executed' && replay.replayed === true && bodies === 1);
    check('journal_confirms_on_resume', journalEnd?.state === 'CONFIRMED');
    if (spec.fault === 'cancel') check('cancellation_reason', first.reason === 'turn_cancelled');
    if (spec.fault === 'deadline') check('deadline_reason', first.reason === 'loop_deadline_exceeded');
    if (spec.fault === 'pause' || spec.fault === 'unavailable') check('pause_outcome', first.outcome === 'paused');
  } else if (spec.expected === 'unknown') {
    check('body_started', bodiesFirst === 1);
    check('uncertain_states', approvalFirst.status === 'UNCERTAIN' && journalFirst?.state === 'UNCERTAIN');
    check('no_retry_of_unknown', bodies === 1 && retry.outcome === 'denied');
  } else if (spec.expected === 'confirmed') {
    check('body_started', bodiesFirst === 1);
    check('confirmed_honest_response', first.effectConfirmed === true && journalFirst?.state === 'CONFIRMED');
    check('retry_and_replay_do_not_execute', retry.outcome === 'executed' && replay.replayed === true && bodies === 1);
  } else if (spec.expected === 'settlement_error_visible') {
    check('body0', bodiesFirst === 0);
    check('no_clean_pause_with_unsettled_states', first.outcome !== 'paused' ||
      (approvalFirst.status === 'APPROVED' && journalFirst?.state === 'EFFECT_FAILED'));
    check('no_duplicate', bodies <= 1);
  } else if (spec.expected === 'terminal_precedence') {
    check('body0', bodiesFirst === 0);
    check('cancel_or_deadline_stays_terminal', first.outcome === 'denied' && ['turn_cancelled', 'loop_deadline_exceeded'].includes(first.reason));
  }
  let ttlResult, approvalTtl, journalTtl;
  if (spec.ttl) {
    offset += 61000;
    ttlResult = await runtime.runTurn(turn({ approvalId: id }));
    approvalTtl = approvals.get(TENANT, id);
    journalTtl = await options.effectJournal.get(TENANT, approvalTtl.operationKey);
  }
  const artifact = { name: spec.name, spec, first, approvalFirst, journalFirst, bodiesFirst, retry, retries, replay,
    approvalEnd, journalEnd, bodies, outboxCalls, reads, failCalls, releaseCalls, checkpoints, bodiesLog,
    ttlResult, approvalTtl, journalTtl, auditValid: audit.verify(), auditTypes: audit.records().map(x => x.type), failures };
  writeFileSync(`${DIR}/${LABEL}-${spec.name}.json`, JSON.stringify(artifact, null, 2) + '\n');
  return { name: spec.name, first: `${first.outcome}:${first.reason}`, approval: approvalFirst.status,
    journal: journalFirst?.state, bodyFirst: bodiesFirst, bodyTotal: bodies, retry: `${retry.outcome}:${retry.reason}`,
    replay: `${replay.outcome}:${replay.reason}`, ttl: ttlResult ? `${ttlResult.outcome}:${ttlResult.reason}:${approvalTtl.status}:${journalTtl.state}` : undefined, failures };
}
const cases = [];
for (const point of ['approval_reserve', 'journal_reserve', 'approval_executing', 'effect_started', 'pause_last'])
  for (const fault of ['cancel', 'deadline', 'pause']) cases.push({ name: `${point}-${fault}`, point, fault, expected: 'no_effect_reusable' });
cases.push({ name: 'async-pause-last-unavailable', point: 'pause_last', fault: 'unavailable', expected: 'no_effect_reusable' });
for (const fault of ['cancel_pause', 'deadline_pause']) cases.push({ name: `last-${fault}`, point: 'pause_last', fault, expected: 'terminal_precedence' });
cases.push({ name: 'pause-release-outage', point: 'pause_last', fault: 'pause', failRelease: true, expected: 'settlement_error_visible' });
cases.push({ name: 'pause-journal-outage', point: 'pause_last', fault: 'pause', failJournal: true, expected: 'settlement_error_visible' });
for (const fault of ['cancel', 'deadline']) cases.push({ name: `body-${fault}`, point: 'body', fault, expected: 'unknown' });
cases.push({ name: 'body-unknown-error', point: 'never', fault: 'none', toolError: 'unknown', expected: 'unknown' });
cases.push({ name: 'confirmed-cancel', point: 'effect_confirmed', fault: 'cancel', expected: 'confirmed' });
cases.push({ name: 'concurrent-resume-pause', point: 'pause_last', fault: 'pause', concurrent: true, expected: 'no_effect_reusable' });
cases.push({ name: 'concurrent-resume-cancel', point: 'pause_last', fault: 'cancel', concurrent: true, expected: 'no_effect_reusable' });
cases.push({ name: 'pause-journal-outage-ttl', point: 'pause_last', fault: 'pause', failJournal: true, ttl: true, expected: 'settlement_error_visible' });
const results = [];
for (const spec of cases) {
  if (process.env.AUD0603_CASE_FILTER && !spec.name.match(new RegExp(process.env.AUD0603_CASE_FILTER))) continue;
  try { const r = await executeCase(spec); results.push(r); console.log(JSON.stringify(r)); }
  catch (e) { const r = { name: spec.name, harnessError: e.stack }; results.push(r); console.log(JSON.stringify(r)); }
}
writeFileSync(`${DIR}/${LABEL}-results.json`, JSON.stringify({ label: LABEL, results }, null, 2) + '\n');
console.log(JSON.stringify({ label: LABEL, total: results.length, passed: results.filter(x => x.failures?.length === 0).length,
  failed: results.filter(x => x.failures?.length > 0).length, harnessErrors: results.filter(x => x.harnessError).length }));
