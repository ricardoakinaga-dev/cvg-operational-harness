import fs from 'node:fs';
import assert from 'node:assert/strict';
import * as old from './old-test-log-summaries.mjs';
import * as fixed from './candidate/scripts/lib/test-log-summaries.mjs';
import {Phase10ResultSchema} from './candidate/scripts/lib/certification-rules.mjs';
const b='/tmp/cvg-aud0603-20261006';
const cases=[];
for (const gate of ['unit','coverage','postgres']) {
 const log=fs.readFileSync(`${b}/remote-verify/gates/${gate}.log`,'utf8');
 const before=old.parseVitestSummary(log,'Tests');
 const after=fixed.parseVitestSummary(log,'Tests');
 assert.equal(before,null); assert.ok(after.passed>0); assert.equal(after.failed,0); assert.equal(after.skipped,0);
 cases.push({gate,base:before,candidate:after});
}
const unit=cases[0].candidate;
const bad=Phase10ResultSchema.shape.metrics.safeParse({unit:null});
const good=Phase10ResultSchema.shape.metrics.safeParse({unit});
assert.equal(bad.success,false); assert.equal(good.success,true);
const negatives=['Tests  2 failed | 5 passed | 3 skipped (10)', '\u001b[31mTests  2 failed | 5 passed | 3 skipped (10)\u001b[0m'];
for(const log of negatives) assert.deepEqual(fixed.parseVitestSummary(log,'Tests'), {passed:5,failed:2,skipped:3,total:10});
fs.writeFileSync(`${b}/parser-probe.json`,JSON.stringify({candidate:'9b85d5b4c6c1f4fb7eee4b1bb4c6e67db3f44e04',historicalInputSHA:'4aa4d8f700b922cd38344edbeb0e2c43745bd9bb',cases,oldSchemaAccepted:bad.success,newSchemaAccepted:good.success,negativePreservation:true,fullCertificationRun:false},null,2)+'\n');
console.log('Parser real de três gates, schema de metrics.unit e preservação de falhas/skips: PASS. Certificação completa NOT_RUN.');
