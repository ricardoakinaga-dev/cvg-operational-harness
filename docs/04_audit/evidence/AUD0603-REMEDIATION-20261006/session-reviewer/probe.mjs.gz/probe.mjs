import {createRequire} from 'node:module';
import {randomBytes,createHash} from 'node:crypto';
import {writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {runPostgresMigrations,TENANT_SCHEMA_TABLES} from '@cvg/persistence';
import {runOperatorSessionMigrations,grantOperatorSessionFunctions} from '/tmp/cvg-aud0603-20261006/candidate/packages/persistence/src/operator-session-migrations.ts';
import {buildApiWithProductionSessions} from '/tmp/cvg-aud0603-20261006/candidate/apps/api/src/production-bootstrap.ts';
import {createConfiguredOperatorIdentityResolver,createTrustedOperatorIdentityToken} from '/tmp/cvg-aud0603-20261006/candidate/apps/api/src/operator-identity.ts';
const require=createRequire('/tmp/cvg-aud0603-20261006/candidate/package.json');
const {Client}=require('pg');
const out='/tmp/cvg-aud0603-20261006/session-reviewer';
const db='postgres://postgres:synthetic-aud0603-local@127.0.0.1:55725/cvg_aud0603_review';
const suffix=randomBytes(6).toString('hex');
const prefix=`aud0603review_session_${suffix}`;
const data=`${prefix}_data`, auth=`${prefix}_auth`;
const migration=`${prefix}_mig`, owner=`${prefix}_own`,runtime=`${prefix}_run`,sessionRole=`${prefix}_sess`;
const roles=[migration,owner,runtime,sessionRole];
const urls=role=>{const u=new URL(db);u.username=role;u.password='synthetic_session_review_only';return u.toString()};
const key={keyId:'aud0603review-key',secret:'aud0603review-synthetic-identity-signing-0123456789'};
const A={tenantId:'tenant_11111111-1111-4111-8111-111111111111',operatorId:'aud0603review.alice',role:'Admin'};
const alternatives={operator:{...A,operatorId:'aud0603review.bob'},tenant:{...A,tenantId:'tenant_33333333-3333-4333-8333-333333333333'},role:{...A,role:'Operator'}};
const admin=new Client({connectionString:db});
const apps=[]; const results=[];let env,port;
function record(name,expected,observed,status='OBSERVED') {const r={name,expected,observed,status};results.push(r);console.log(JSON.stringify(r));writeFileSync(out+'/results.json',JSON.stringify({candidate:'9b85d5b4c6c1f4fb7eee4b1bb4c6e67db3f44e04',prefix,results},null,2));}
async function open(){const app=await buildApiWithProductionSessions(env,{operatorIdentityResolver:createConfiguredOperatorIdentityResolver(env)});await app.listen({port:0,host:'127.0.0.1'});apps.push(app);return {app,url:`http://127.0.0.1:${app.server.address().port}`};}
async function req(server,path='/v1/session',cookie,identity,method='GET',extra={}){const r=await fetch(server.url+path,{method,headers:{origin:'https://aud0603review.test','x-forwarded-proto':'https',...(cookie?{cookie}:{}),...(identity?{'x-cvg-operator-token':createTrustedOperatorIdentityToken(identity,key)}:{}),...extra},signal:AbortSignal.timeout(10000)});return {status:r.status,setCookie:r.headers.get('set-cookie'),body:await r.json()};}
const cookie=r=>{assert.equal(r.status,200);assert.ok(r.setCookie?.startsWith('cvg_operator_session=opsess_'));return r.setCookie.split(';')[0]};
const digest=c=>createHash('sha256').update(c.slice(c.indexOf('=')+1)).digest();
const login=(s,c,i=A)=>req(s,'/v1/session',c,i);
const reload=(s,c)=>req(s,'/v1/session',c);
const logout=(s,c)=>req(s,'/v1/session/logout',c,undefined,'POST');
const control=(s,c)=>req(s,'/v1/admin/agents',c);
async function active(c){const r=await admin.query(`SELECT s.operator_id,s.tenant_id,s.role,s.revoked_at,f.revoked_at AS family_revoked FROM ${auth}.operator_sessions s JOIN ${auth}.operator_session_families f USING(family_id) WHERE s.token_digest=$1`,[digest(c)]);return r.rows[0]??null;}
async function revokeGrant(name){await admin.query(`REVOKE EXECUTE ON FUNCTION ${auth}.${name} FROM ${sessionRole}`)}
async function restoreGrant(name){await admin.query(`GRANT EXECUTE ON FUNCTION ${auth}.${name} TO ${sessionRole}`)}
async function lockFamily(c){const client=new Client({connectionString:db});await client.connect();await client.query('BEGIN');await client.query(`SELECT f.family_id FROM ${auth}.operator_session_families f JOIN ${auth}.operator_sessions s USING(family_id) WHERE s.token_digest=$1 FOR UPDATE OF f`,[digest(c)]);return {release:async()=>{await client.query('ROLLBACK');await client.end()}};}
async function waitBlocked(count){const start=Date.now();while(Date.now()-start<1400){const r=await admin.query("SELECT count(*)::int n FROM pg_stat_activity WHERE usename=$1 AND wait_event_type='Lock'",[sessionRole]);if(r.rows[0].n>=count)return;await new Promise(r=>setTimeout(r,10));}throw new Error(`Harness did not observe ${count} own auth calls blocked`)}
await admin.connect();
try{
 const database=(await admin.query('SELECT current_database() name')).rows[0].name;assert.equal(database,'cvg_aud0603_review');
 for(const role of roles) await admin.query(`CREATE ROLE ${role} LOGIN PASSWORD 'synthetic_session_review_only' NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE NOREPLICATION NOINHERIT`);
 await admin.query(`CREATE SCHEMA ${data} AUTHORIZATION ${migration}`);await admin.query(`GRANT USAGE ON SCHEMA ${data} TO ${runtime}`);
 await admin.query(`ALTER ROLE ${migration} SET search_path=${data}`);await admin.query(`ALTER ROLE ${runtime} SET search_path=${data}`);
 for(const role of [migration,owner]){if(role===owner)await admin.query(`GRANT CREATE ON DATABASE "${database}" TO ${owner}`);const c=new Client({connectionString:urls(role)});await c.connect();try{if(role===migration)await runPostgresMigrations(c,{schemaName:data,createSchema:false});else{await runOperatorSessionMigrations(c,auth,data);await grantOperatorSessionFunctions(c,auth,sessionRole)}}finally{await c.end()}if(role===owner)await admin.query(`REVOKE CREATE ON DATABASE "${database}" FROM ${owner}`)}
 for(const table of TENANT_SCHEMA_TABLES)await admin.query(`GRANT SELECT,INSERT,UPDATE ON ${data}.${table} TO ${runtime}`);
 await admin.query(`GRANT SELECT ON ${data}.schema_migrations TO ${runtime}`);
 await admin.query(`GRANT SELECT,INSERT,UPDATE,DELETE ON ${data}.webhook_replay_events,${data}.rate_limit_buckets TO ${runtime}`);
 process.env.NODE_ENV='production';
 env={NODE_ENV:'production',API_PERSISTENCE_MODE:'postgres',DATABASE_URL:urls(runtime),DATABASE_MIGRATION_URL:urls(migration),POSTGRES_SCHEMA:data,POSTGRES_RLS_ENFORCEMENT:'true',POSTGRES_AUTO_MIGRATE:'false',OUTBOX_DURABLE_INBOUND:'true',CVG_IDENTITY_MODE:'trusted',CVG_OPERATOR_IDENTITY_KEYRING:JSON.stringify({current:key}),CVG_OPERATOR_SESSION_DATABASE_URL:urls(sessionRole),CVG_OPERATOR_AUTH_SCHEMA:auth,CVG_OPERATOR_SESSION_ROLE:sessionRole,CVG_RATE_LIMIT_KEYRING:JSON.stringify({budgetSecret:'aud0603review-synthetic-budget-secret-0123456789',current:{keyId:'aud0603review-rate',secret:'aud0603review-synthetic-rate-secret-0123456789'}}),INBOUND_TENANT_ID:A.tenantId,INBOUND_AGENT_ID:'agent_22222222-2222-4222-8222-222222222222',WEBHOOK_SIGNING_SECRET:'aud0603review-synthetic-webhook-secret-0123456789',API_ALLOWED_ORIGINS:'https://aud0603review.test',API_REQUIRE_HTTPS:'true',API_TRUSTED_PROXY_ADDRESSES:'127.0.0.1',API_TRUSTED_PROXY_HOPS:'0'};
 const s=await open(), replica=await open();
 record('production-composition','startup with durable auth, trusted identity and PG data/RLS',{urls:[s.url,replica.url],node:process.version,postgres:(await admin.query('SELECT version() v')).rows[0].v},'PASS');
 let c=cookie(await login(s));const a=await reload(replica,c);assert.equal(a.status,200);assert.deepEqual(a.body.data.identity,A);
 assert.ok((await login(s)).setCookie.includes('Secure'));record('reload-replica','200 same identity, secure HttpOnly Strict cookie',a,'PASS');
 await s.app.close();const restart=await open();const restarted=await reload(restart,c);assert.equal(restarted.status,200);record('restart','200 cookie-only restore',restarted,'PASS');
 const rotated=cookie(await login(restart,c));assert.equal((await reload(replica,c)).status,401);assert.equal((await reload(replica,rotated)).status,200);assert.equal((await logout(replica,c)).status,200);const after=await reload(restart,rotated);assert.equal(after.status,401);record('same-identity-rotation-old-cookie-logout','old cookie logout revokes successor',{after},'PASS');
 for(const [dimension,b] of Object.entries(alternatives)){
  const old=cookie(await login(restart));const next=cookie(await login(replica,old,b));const oldResponse=await reload(restart,old),nextResponse=await reload(restart,next);assert.equal(oldResponse.status,401);assert.equal(nextResponse.status,200);assert.deepEqual(nextResponse.body.data.identity,b);record(`sequential-switch-${dimension}`,'old family revoked; new identity exact',{oldResponse,nextResponse,oldRow:await active(old),nextRow:await active(next)},'PASS');await logout(restart,next);
 }
 const functions={get:'operator_session_get(bytea)',revoke:'operator_session_revoke(bytea)',replace:'operator_session_replace(bytea,bytea,text,text,text,timestamptz)',create:'operator_session_create(bytea,text,text,text,timestamptz)'};
 for(const operation of ['get','revoke','replace']){
  const old=cookie(await login(restart));await revokeGrant(functions[operation]);let failed;try{failed=operation==='get'?await reload(restart,old):operation==='revoke'?await login(replica,old,alternatives.operator):await login(replica,old)}finally{await restoreGrant(functions[operation])}const recovered=await reload(restart,old);assert.equal(failed.status,503);assert.equal(failed.setCookie,null);assert.equal(recovered.status,200);record(`db-${operation}-failure-recovery`,'503/no cookie change; cookie resumes after permissions recover',{failed,recovered},'PASS');await logout(restart,old);
 }
 const logc=cookie(await login(restart));await revokeGrant(functions.revoke);let lf;try{lf=await logout(replica,logc)}finally{await restoreGrant(functions.revoke)}assert.equal(lf.status,503);assert.equal(lf.setCookie,null);assert.equal((await reload(restart,logc)).status,200);assert.equal((await logout(restart,logc)).status,200);assert.equal((await reload(restart,logc)).status,401);record('logout-db-failure-retry','503 preserve; subsequent retry revokes',{lf},'PASS');
 // True PG failure after first durable step. No fake store injected.
 for(const [dimension,b] of Object.entries(alternatives)){
  const old=cookie(await login(restart));await revokeGrant(functions.create);let failed;try{failed=await login(replica,old,b)}finally{await restoreGrant(functions.create)}const recovered=await reload(restart,old);const row=await active(old);const meets=failed.status===503&&failed.setCookie===null&&recovered.status===200;record(`create-failure-after-retire-${dimension}`,'SPEC0144 atomic substitution; 503 preserves prior usable cookie',{failed,recovered,oldRow:row},meets?'PASS':'FAIL_CONTRACT');const retry=await login(replica,old,b);assert.equal(retry.status,200);await logout(restart,cookie(retry));
 }
 // A predecessor whose successor is live must not make retiring old family optional.
 for(const [dimension,b] of Object.entries(alternatives)){
  const old=cookie(await login(restart));const successor=cookie(await login(replica,old));const switched=cookie(await login(restart,old,b));const oldFamilyAccess=await reload(replica,successor);const newAccess=await reload(replica,switched);record(`stale-cookie-switch-${dimension}`,'retire the prior family before new operator/tenant/role session',{oldFamilyAccess,newAccess,oldSuccessorRow:await active(successor),newRow:await active(switched)},oldFamilyAccess.status===401?'PASS':'FAIL_CONTRACT');await logout(restart,old);await logout(restart,switched);
 }
 // Use a real DB lock so both replicas have read same active cookie before retire.
 const old=cookie(await login(restart));const lock=await lockFamily(old);let p1,p2;try{p1=login(restart,old,alternatives.operator);p2=login(replica,old,alternatives.tenant);await waitBlocked(2)}finally{await lock.release()}const responses=await Promise.all([p1,p2]);const cookies=responses.filter(x=>x.status===200).map(cookie);const surviving=await Promise.all(cookies.map(c=>reload(restart,c)));const rows=await Promise.all(cookies.map(active));record('concurrent-distinct-switch','atomic replacement must not emit two active successor families for same prior session',{responses,surviving,rows},surviving.filter(x=>x.status===200).length>1?'FAIL_CONTRACT':'PASS');for(const x of cookies)await logout(replica,x);
 // Same-family rotation/logout serialize in either ordering.
 for(const order of ['rotation-first','logout-first']){
  const old=cookie(await login(restart));const lock=await lockFamily(old);let rotation,logged;try{if(order==='rotation-first'){rotation=login(restart,old);await waitBlocked(1);logged=logout(replica,old)}else{logged=logout(restart,old);await waitBlocked(1);rotation=login(replica,old)}await waitBlocked(2)}finally{await lock.release()}const rr=await rotation,lr=await logged;assert.equal(lr.status,200);const successor=rr.status===200?cookie(rr):null;const surviving=successor?await reload(replica,successor):null;assert.equal((await reload(replica,old)).status,401);if(surviving)assert.equal(surviving.status,401);record(`concurrent-${order}`,'successful logout invalidates all same-family digests',{rr,lr,surviving},'PASS');
 }
 // Lock timeout is actual PostgreSQL statement/query timeout (~2s).
 const timed=cookie(await login(restart));const timeoutLock=await lockFamily(timed);const start=Date.now();let timeout;try{timeout=await login(replica,timed)}finally{await timeoutLock.release()}const timeoutReload=await reload(restart,timed);assert.equal(timeout.status,503);assert.equal(timeout.setCookie,null);assert.equal(timeoutReload.status,200);record('rotation-lock-timeout-recovery','bounded 503 preserves old cookie, rollback and reload succeeds',{elapsedMs:Date.now()-start,timeout,timeoutReload},'PASS');await logout(replica,timed);
 // Missing/forged/duplicate cookie cannot recover authority, even via simulation headers.
 for(const bad of ['cvg_operator_session=opsess_'+'z'.repeat(43),'cvg_operator_session=opsess_x;cvg_operator_session=opsess_y']){const denied=await reload(restart,bad);assert.equal(denied.status,401);record('invalid-cookie-deny','401',denied,'PASS')}
 record('completed','all focused probes executed; findings do not count as PASS',{checks:results.length,contractFailures:results.filter(r=>r.status==='FAIL_CONTRACT').length},'PROCEDURE_COMPLETED');
} catch(e){record('harness-error','no harness errors',{message:e.message,stack:e.stack},'HARNESS_ERROR');process.exitCode=2}
finally{
 for(const app of apps)await app.close().catch(()=>{});
 try{await admin.query(`DROP SCHEMA IF EXISTS ${auth} CASCADE`);await admin.query(`DROP SCHEMA IF EXISTS ${data} CASCADE`);for(const role of roles){await admin.query(`DROP OWNED BY ${role}`);await admin.query(`DROP ROLE ${role}`)}const remain=(await admin.query("SELECT nspname AS name FROM pg_namespace WHERE nspname LIKE $1 UNION ALL SELECT rolname FROM pg_roles WHERE rolname LIKE $1",[prefix+'%'])).rows;record('cleanup','only own schemas/roles removed; none remain',remain,remain.length?'FAIL_CLEANUP':'PASS')}catch(e){record('cleanup','remove own resources',{message:e.message},'FAIL_CLEANUP');process.exitCode=2}await admin.end();
}
