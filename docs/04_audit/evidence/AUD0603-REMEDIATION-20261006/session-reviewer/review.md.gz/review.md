# AUD0603 — revisão independente de sessão, somente leitura

**Resultado: dois achados P2; um regressivo e um herdado.** Não é PASS nem aprovação de release. Candidata `9b85d5b4c6c1f4fb7eee4b1bb4c6e67db3f44e04`; base `4aa4d8f700b922cd38344edbeb0e2c43745bd9bb`. Classificação final em [verdict.json](verdict.json); respostas, estado persistido e critérios experimentais em [results.json](results.json).

## SESSION-F01 — P2 / média — falha de criação após revogação perde sessão e cookie anteriores

**Origem: regressão da candidata.** Local: `apps/api/src/server.ts:820–850`; chamadas independentes do adapter em `apps/api/src/operator-session-postgres.ts:84–94` e `:142–148`.

Expectativa literal da SPEC 0144, linha 42: “o store precisa oferecer substituição atômica” e “Falhas em qualquer etapa retornam 503 e preservam o cookie anterior”. A linha 29 também distingue indisponibilidade de autenticação e preserva cookie potencialmente válido. Não identifiquei mudança desse contrato no diff base/candidata.

Reprodução pela rota HTTP real, sem mock do store:

1. Criar sessão A com identidade sintética válida.
2. No schema/role exclusivos da sonda, retirar `EXECUTE` de `operator_session_create(bytea,text,text,text,timestamptz)`; manter `get` e `revoke` disponíveis.
3. Chamar `GET /v1/session` com cookie A e token válido que muda operador, tenant ou papel.
4. Restaurar a permissão e tentar recarga somente com cookie A.

Na candidata, `revoke(A)` confirma primeiro; `create` falha em seguida. Resposta **503 com Set-Cookie de limpeza**, `family_revoked` persistido e recarga **401**, mesmo depois da recuperação da permissão. Nas três dimensões, a sonda principal reproduziu esse resultado. Uma nova autenticação com token novo recupera o serviço, mas a sessão anterior já foi perdida.

Na base, o mesmo caso diferencial de mudança de papel retorna **503 sem Set-Cookie**, família anterior não revogada e recarga **200**. Evidências: `results.json`, casos `create-failure-after-retire-{operator,tenant,role}`; `supplement-candidate/results.json` e `supplement-base/results.json`, caso `switch-create-failure-base-comparison`. O diferencial executável da base cobre papel; equivalência da origem nas outras dimensões é inspeção do mesmo ramo, não execução adicional da base.

Impacto: indisponibilidade transitória interrompe uma sessão válida e exige autenticação nova. Não foi observado mint sem autenticação nem duas famílias ativas nesse cenário. A gravidade é P2, sem atribuir bypass de autorização. A correção deve preservar o contrato de substituição atômica e recuperação; apenas retirar a limpeza do cookie não desfaz a revogação já confirmada.

## SESSION-F02 — P2 / média — cookie predecessor permite troca sem retirar a família anterior ainda ativa

**Origem: herdada da base.** Locais: `apps/api/src/operator-session-hook.ts:53–73`; `apps/api/src/server.ts:770`, `:808–841`; SQL `packages/persistence/migrations/operator-session/0000_auth.sql`, função `operator_session_get`.

Expectativa literal estreita: SPEC 0144, linha 17, “troca de tenant removem o acesso”; intenção explícita da rota, `server.ts:805–807`, token para outro operador inicia nova família e retira a anterior. A família considerada aqui é somente aquela identificável pelo cookie predecessor apresentado, não todas as sessões do operador. O efeito sobre papel foi observado, mas a SPEC não define revogação global de permissões por um token com papel menor.

Reprodução:

1. Login A1; rotação da mesma identidade A1 → A2, que preserva a família.
2. Apresentar cookie A1, já substituído, e token novo válido para outro tenant/operador/papel em `GET /v1/session`.
3. A rota emite B. Tentar recarga com A2 numa segunda réplica.

A2 e B continuam respondendo **200**; as duas famílias permanecem sem revogação. O hook consulta somente sessões ativas: A1 devolve `null`, não preenche `sessionRecordByHeaders`; `existing` fica ausente e o ramo de retirada não roda. O banco ainda conserva o vínculo de A1 com a família de A2, usado normalmente por logout, mas a rota de troca não o utiliza.

Evidências: `results.json`, `stale-cookie-switch-{operator,tenant,role}`. No suplemento executado **tanto na base quanto na candidata**, A2 conserva autorização **200 em `/v1/admin/agents`** após a troca para Operator; B recebe **403** nessa mesma rota. Logout de B não retira A2. Caso `stale-cookie-downgrade-protected-route` em ambos os suplementos. A origem herdada de tenant/operador também é suportada pelos mesmos predicados e pelo hook/SQL inalterados; o diferencial executável suplementar cobre papel.

Limite: exige predecessor conhecido e um token novo independentemente autenticado. Nenhum cookie forjado ampliou papel ou tenant. O achado sobre troca de tenant não pressupõe uma política global de sessão única; trata da família anterior explicitamente referenciada na transição. Para papel, o resultado comprova persistência da autorização anterior, sem inferir uma política global de downgrade que não foi especificada.

## Concorrência e famílias — separação entre observação e violação literal

**SESSION-O01, INFO, herdada:** duas trocas com tokens válidos distintos e o mesmo cookie ativo produziram dois 200 e duas novas famílias ativas em ambos os SHAs. Um lock real da família no PostgreSQL garantiu que as duas réplicas já tinham lido a sessão antes de revogar. O critério experimental inicial marcou `FAIL_CONTRACT`, mas essa etiqueta não é o parecer final: a SPEC não exige literalmente vencedor único entre bootstraps novos independentemente autenticados. Portanto, não há terceiro finding nem severidade de segurança atribuída a essa observação. Ela também não é uma regressão da candidata.

**Contrato literal de concorrência, SPEC linha 57:** `replace` trava a família e valida a sessão antiga ativa; `replace` e logout se serializam, e nenhum digest da linhagem funciona após logout bem-sucedido. A sonda da candidata confirmou isso nas duas ordens controladas: rotação primeiro → resposta de rotação 200, logout 200, sucessora 401; logout primeiro → logout 200, rotação 503, predecessor 401. Esse contrato passou nos cenários executados.

**SESSION-O02, INFO, herdada:** token novo da mesma identidade com cookie substituído cria outra família; logout do predecessor revoga a sucessora da família original, mas não a nova. O suplemento reproduziu isso nos dois SHAs. Não classifico isoladamente como falha: a SPEC não explicita se autenticação nova com cookie já inválido deve ser rejeitada, tratada como login novo ou reunida à família antiga. Preservar essa observação evita inventar uma política.

## Método, resultados e limites

- Node **22.23.2**, PostgreSQL sintético exclusivo `cvg_aud0603_review` em loopback 55725. Cada execução criou apenas schemas e quatro roles com prefixo próprio `aud0603review_session_<aleatório>`, a partir da fixture de produção versionada. Falhas por grants afetaram somente essas funções/roles próprias.
- `buildApiWithProductionSessions` compôs store PostgreSQL, preflight, dados PostgreSQL com RLS e proteção/replay de produção. `NODE_ENV=production`; duas instâncias com listener HTTP em portas efêmeras de loopback, `fetch` pela rota real, headers HTTPS do proxy confiável sintético. Nenhum store de sessão injetado ou header de identidade de simulação.
- PASS nos casos executados: recarga entre réplicas, restart, cookies Secure/HttpOnly/Strict, rotação normal e logout com predecessor, troca sequencial com cookie ativo nas três dimensões, falhas de `get`/`revoke`/`replace` com recuperação, falha de logout e retry, timeout real de lock (~2 s) com rollback/recarga, cookies forjado/duplicado negados. O rótulo nominal PASS não cobre os achados adversariais.
- A sonda principal tem 25 registros: 17 PASS (inclui cleanup), 7 `FAIL_CONTRACT` experimentais e 1 conclusão de procedimento. Os sete são três casos F01, três F02 e uma observação O01 reclassificada explicitamente neste parecer. Não são sete findings nem uma suíte aprovada.
- Os suplementos da candidata e da base terminaram com exit **0**, embora ambos detectem falhas. O exit significa conclusão do diagnóstico, **não PASS do artefato**. O exit da primeira sonda não foi capturado na primeira chamada; seus registros finais de conclusão/cleanup foram inspecionados. Duas tentativas iniciais de carregar a base falharam antes de abrir conexão por montagem incompleta de fontes; stderr preservado, execução final completa posterior.
- Base executada a partir de `git archive 4aa4d8f` das fontes necessárias, não por substituição híbrida de `server.ts`. Dependências recebidas da candidata usadas em modo leitura; manifests/lock sem delta entre esses SHAs. Não executei fullsuite, E2E, certify, SBOM, licenças, instalação ou push.
- Fontes e lock conferidos byte a byte contra o SHA da candidata: [metadata.json](metadata.json). O status Git da candidata registrou alteração concorrente em `certification/mutation-guard.json`, fora do escopo; não a li, alterei ou reverti. Não obtive hash prévio de toda a árvore de dependências e não certifico sua imutabilidade integral.
- Todos os listeners próprios foram encerrados. As três execuções completas apagaram somente seus namespaces/roles; consulta final com prefixo exato retornou `[]`. Nenhum recurso do lead ou de terceiros foi removido. Nenhuma escrita em root, docs/ledgers ou fontes; a evidência desta lane fica exclusivamente aqui, sob o claim AUD0603 do lead.
- Os ledgers obrigatórios foram consultados para contexto operacional/coordenação; suas entradas históricas não constituem evidência técnica deste parecer. Não consultei relatórios anteriores nem relatórios/conclusões do builder. A SPEC é o contrato usado na classificação final.
- Fora da prova: navegador/OIDC callback real, entrypoint como subprocesso, expiração temporal nova, perda de confirmação de commit por queda de rede, indisponibilidade física de todo o banco e catálogo adversarial completo. Falhas de permissão e lock demonstram ramos específicos de indisponibilidade, sem substituir esses cenários.

## Repetição pelo lead e congelamento

Sonda final de achados/diferencial: [supplement.mjs](supplement.mjs), loader [loader.mjs](loader.mjs). Os resultados congelados estão em `supplement-candidate/` e `supplement-base/`. Usar pasta **nova** via `REVIEW_OUT`; não sobrescrever evidências congeladas. Exemplo para a candidata:

```bash
cd /tmp/cvg-aud0603-20261006/candidate
mkdir -p /tmp/cvg-aud0603-20261006/session-reviewer/replay-lead
REVIEW_OUT=/tmp/cvg-aud0603-20261006/session-reviewer/replay-lead \
  /home/ricardo/.nvm/versions/node/v22.23.2/bin/node \
  --import /tmp/cvg-aud0603-20261006/session-reviewer/loader.mjs \
  /tmp/cvg-aud0603-20261006/session-reviewer/supplement.mjs
```

Para a base, usar cwd `session-reviewer/base-source`, `REVIEW_ROOT` apontando a essa pasta, `REVIEW_SHA=4aa4d8f700b922cd38344edbeb0e2c43745bd9bb` e outra pasta nova `REVIEW_OUT`. O programa cria/retira somente seu namespace sintético; repetir exige manter a autorização original para esses objetos próprios. Depois do congelamento não farei novas sondas nesta lane.

Hashes finais de scripts, evidências, parecer e classificação em `frozen-manifest.json`. A classificação vinculante da lane é `verdict.json`; rótulos experimentais mais fortes sobre concorrência foram preservados para rastreabilidade, não adotados como política nova.
