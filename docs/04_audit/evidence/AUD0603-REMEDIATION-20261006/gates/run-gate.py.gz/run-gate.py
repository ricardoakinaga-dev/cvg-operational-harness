import os, sys, json, time, subprocess
from pathlib import Path
base = Path('/tmp/cvg-aud0603-20261006')
name, *command = sys.argv[1:]
env = dict(os.environ)
env.update(PATH='/home/ricardo/.nvm/versions/node/v22.23.2/bin:' + env['PATH'], CI='1', PHASE4A_PG_REQUIRED='1', PHASE4A_DISPOSABLE_PG='1', TEST_DATABASE_URL='postgres://postgres:synthetic-aud0603-local@127.0.0.1:55725/cvg_aud0603')
if name == 'postgres': env['TEST_DATABASE_URL'] = env['TEST_DATABASE_URL'] + '_pgonly'
started = time.time()
with (base / (name + '.log')).open('w') as log:
    result = subprocess.run(command, cwd=base/'candidate', env=env, stdout=log, stderr=subprocess.STDOUT)
receipt = dict(gate=name, command=command, exitCode=result.returncode, elapsedSeconds=round(time.time()-started, 3), node='22.23.2', candidate='9b85d5b4c6c1f4fb7eee4b1bb4c6e67db3f44e04', postgresRequired=True, log=name+'.log')
(base / (name + '.result.json')).write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt))
sys.exit(result.returncode)
