from pathlib import Path
import json,hashlib,gzip,tarfile,io
R=Path(__file__).resolve().parent;C=Path('/mnt/dados/cvg-work/aud0625-par-q01-catalog-20261031/candidate');E=C/'docs/04_audit/evidence/AUD0625-Q01-CURRENT-DOCS-272-20261031';H=lambda b:hashlib.sha256(b).hexdigest()
for n in ['task.json','baseline.json','edits.json','setup-initial-failure.json','verify.py']:(E/n).write_bytes((R/n).read_bytes())
(E/'REPORT.md').write_text('''# Q01 — escopo vigente reconciliado nos documentos de execução

**0379,0380 e0381 agora usam272 como escopo corrente do DeepSeek.** A tarefa fecha a sincronização documental que faltava após os recibos30/32 e a publicação da medida272, sem conceder o freeze do Q01 ou aceite funcional. Início GBrain89040, sob o novo objetivo do usuário de assumir as tarefas pendentes.

- No roadmap0379, a regra de denominador e a próxima entrega do Q01/Q05 passam a272. Uma nota distingue o escopo atual das266 capacidades e das estatísticas do levantamento de16/10.
- No backlog0380, a entrega do Q01, a ponte entre catálogos e o escopo vigente apontam para272 e para o manifesto com hash. A próxima ação registra as355 propostas e a disposição de revisão pendente com o DF; as26 relações novas permanecem propostas separadas.
- No protocolo0381, a preservação dos catálogos e a independência do Claude100 usam272. Permanecem111 cartões PAR,37 C100,117 resultados Claude e17 controles CVG.

O [manifesto da medida](../AUD0625-PAR-Q01-CATALOG-20261031/denominator-272/measure.json) tem catálogo descomprimido SHA-256 `df114f5eb8aa99c638bb1472279adda3151902f6824ed905fa4ba5307e693a84`. Recibos30 e32 foram autenticados pelos hashes originais. WEB-02 conserva a exceção de DNS da referência pelo proxy e a exigência universal do CVG de validar/fixar ou desligar esse caminho.

As dez alterações textuais mantêm todas as tabelas, títulos de cartões, estados e dependências exatamente como estavam. O texto e a posição de0380:31 permanecem intactos. O levantamento histórico de266, inclusive totais e estimativas por leitura, não foi recalculado nem convertido em medição atual. Nada foi retirado do denominador para aumentar um percentual. Não houve novo lote de folhas, crítico, reset de revisão, implementação ou PASS funcional.

## Preservação do trabalho compartilhado

Os três documentos já tinham edições não commitadas de outros trabalhos. A baseline registra seus bytes completos, hashes, diff prévio e índice root. As trocas próprias são exatas: sua inversão virtual reconstrói integralmente a baseline compartilhada, sem restaurar arquivos ou descartar alterações anteriores. A candidata privada antiga tinha versões diferentes dos três documentos; os corpos atuais foram importados e identificados como baseline existente, sem atribuir sua autoria a esta tarefa. O commit privado contém essa preservação e as dez mudanças próprias, sem staging no root.

A preparação inicial recusou primeiro um arquivo ausente no checkout esparso e depois a diferença entre o blob antigo da candidata e a fonte atual compartilhada. A baseline foi então corrigida para os documentos atuais; nenhuma edição compartilhada ocorreu nessas recusas. Os registros e ambas as versões estão no bruto.

[Verificação das invariantes](verification.json), [baseline](baseline.json), [trocas exatas](edits.json), [conferência do root](root-publication.json), [checks](checks.json), [notas](NOTAS.md), [deltas](LEDGER-DELTAS.md), [bruto](raw-current-docs.tar.gz), [inventário](raw-files.json), [readback bruto](raw-archive.json).

Q01/F01 e a revisão semântica permanecem abertos. O próximo avanço de revisão depende da disposição já solicitada ao DF sobre o ciclo permitido para355. O novo objetivo também permite selecionar outra tarefa livre com seus gates, sem assumir os caminhos dos pares. Nenhum push, merge, aplicação, instalação, PG, Docker, rede externa ou produção nesta sincronização.
''')
(E/'NOTAS.md').write_text('''# Notas

Esta é uma sincronização dos documentos correntes, autorizada pela emenda já registrada; não é outro pacote de propostas nem uma revisão do catálogo. O catálogo272 e seus32 artefatos anteriores permanecem imutáveis. O fato87049 descreve o bloqueio do objetivo anterior; o usuário o substituiu por novo objetivo ativo. A contagem de recorrência foi reiniciada e a seleção passou a considerar toda a documentação disponível.

Claims dos três arquivos referenciavam tarefas concluídas em16/17out; nenhum escritor ativo nesses mesmos arquivos foi encontrado na reconciliação atual. As frentes PROGRAM-CLOSURE D07/D08/D09 foram consultadas e preservadas. O root possuía edições anteriores e a candidata usava blobs mais antigos; snapshots de ambos, fonte escolhida e limitações são explícitos. Regras e tabelas foram comparadas integralmente; a conferência não é apresentada como revisão semântica independente das capacidades.

O formato da baseline dos três documentos já passou antes das edições. Links e formato finais usam os arquivos realmente publicados. O scanner cobre arquivos visíveis e o diff próprio; o bruto comprimido tem inventário/hash e readback, sem alegação de varredura dos seus membros. Ledgers99/20/30 compartilhados seguem readonly, com deltas próprios para o holder.
''')
(E/'LEDGER-DELTAS.md').write_text('''# Deltas para o holder

- Última ação: sincronização de escopo vigente272 nos documentos0379/0380/0381, sob recibos30/32; histórico266 de16/10 preservado. O manifesto versionado e seu hash são vinculados diretamente.
- Estado da tarefa: reconciliação documental concluída quando conferências e publicação local constam de checks/root-publication. Q01/F01 e revisão355 permanecem abertos; nenhuma alteração de estados/dependências/aceites dos111PAR/37C100,117+17Claude.
- Backlog: não há nova revisão ou lote Q01. A próxima ação corrente conserva355propostas com gate histórico para disposição do DF e26 relações propostas separadas. WEB02targetCVGuniversalfailclosed mantido.
- Objetivo do usuário: novo goal ACTIVE, execução de tarefas livres sequenciais com consulta/registro GBrain; não herda a condição blocked do goal substituído. Gate de um cartão não impede selecionar outra tarefa livre autorizada.
- Root99/20/30/índice/peers preservados; nenhum push/merge/produção.
''')
(E/'empty-artifact-status.json').write_text(json.dumps({'schemaVersion':1,'files':[]},indent=2)+'\n')
(E/'checks.json').write_text(json.dumps({'status':'PENDING_FINAL_T1','functional_tests':0,'independent_semantic_review':False},indent=2)+'\n')
(E/'root-publication.json').write_text(json.dumps({'status':'PENDING_CAS_PUBLICATION'},indent=2)+'\n')
files=sorted(p for p in R.rglob('*') if p.is_file());rows=[];buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as t:
 for p in files:
  data=p.read_bytes();rel=str(p.relative_to(R));rows.append({'path':rel,'bytes':len(data),'sha256':H(data)});i=tarfile.TarInfo(rel);i.size=len(data);i.mtime=0;t.addfile(i,io.BytesIO(data))
raw=gzip.compress(buf.getvalue(),mtime=0);(E/'raw-current-docs.tar.gz').write_bytes(raw)
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as t:
 extracted={m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
for x in rows:assert len(extracted[x['path']])==x['bytes'] and H(extracted[x['path']])==x['sha256']
(E/'raw-files.json').write_text(json.dumps(rows,indent=2)+'\n');(E/'raw-archive.json').write_text(json.dumps({'files':len(rows),'bytes':len(raw),'sha256':H(raw),'readback':'ALL_MEMBERS_EXACT_SHA256','scanner_scope':'VISIBLE_ARTIFACTS_ONLY_NOT_COMPRESSED_MEMBERS'},indent=2)+'\n');print(json.dumps({'raw_files':len(rows),'raw_bytes':len(raw),'raw_sha256':H(raw)}))
