--- before/docs/03_build/0381_plano_executivo_paridade_claude_code.md
+++ after/docs/03_build/0381_plano_executivo_paridade_claude_code.md
@@ -97,7 +97,7 @@
 
 O [0380](0380_backlog_paridade_100_deepseek.md) continua proprietário do estado e do trabalho PAR. O [0383](0383_backlog_paridade_claude_code.md) é a extensão de deltas C100 e da qualificação Claude, ligada por uma ponte no 0380. O mesmo componente não ganha duas tasks de construção ou dois estados concorrentes.
 
-Há **37 cartões C100 novos**, **53 PAR referenciados diretamente** e **58 PAR no fecho transitivo**, sem contar carriers opcionais como SSH/ACP como obrigatórios para cloud/IDE. Reuso opcional só vira dependência após decisão arquitetural, com recalculo do grafo e do esforço. Não se exige concluir todos os 111 PAR ou obter 266/266 DeepSeek para iniciar ou aceitar o Claude100.
+Há **37 cartões C100 novos**, **53 PAR referenciados diretamente** e **58 PAR no fecho transitivo**, sem contar carriers opcionais como SSH/ACP como obrigatórios para cloud/IDE. Reuso opcional só vira dependência após decisão arquitetural, com recalculo do grafo e do esforço. Não se exige concluir todos os 111 PAR ou obter 272/272 DeepSeek para iniciar ou aceitar o Claude100.
 
 Um PAR pode produzir evidência aproveitável pelos dois alvos, mas cada catálogo qualifica seus próprios requisitos. `PAR-Q02` compara DeepSeek; não é automaticamente um comparador Claude. C100-Q01 adiciona o driver/oráculo específico. Infraestrutura Q03/Q04/Q06/Q08 é reutilizada, sem alterar o denominador aprovado do PAR-CAP.
 
@@ -174,7 +174,7 @@
 ### Fontes e fronteiras de autoridade
 
 - Estado, dependências, prioridade P0/P1 e próxima ação dos PAR: somente0380. Estado dos C100: somente0383. Roadmaps descrevem ordem e marcos; SPECs aprovadas definem contratos; registros de execução demonstram o resultado. Atualizar um desses artefatos não atualiza os demais por inferência.
-- Preservar os111 PAR,37 C100,266 capacidades DeepSeek e117 resultados Claude mais17 controles CVG. Uma implementação comum tem um único builder e pode servir aos dois alvos depois dos respectivos aceites. Nenhum requisito sai do denominador por esta priorização.
+- Preservar os 111 PAR,37 C100, 272 capacidades DeepSeek no [escopo vigente do Q01](0380_backlog_paridade_100_deepseek.md#escopo-par-cap-vigente) e117 resultados Claude mais17 controles CVG. Uma implementação comum tem um único builder e pode servir aos dois alvos depois dos respectivos aceites. Nenhum requisito sai do denominador por esta priorização.
 - A prioridade orienta seleção dentro das dependências existentes. Não transforma TODO em READY, não revoga trabalho já autorizado, não transfere lease nem reduz aceites. Preparação de contrato em caminho livre pode ocorrer antes de a implementação dependente estar habilitada.
 - Aprovações0221/0222/0225 com ajustes continuam vinculadas ao [recibo de16/10](../04_audit/evidence/USER-DECISIONS-20261016/spec-gates.json). Conferir a revisão e aplicar o recorte permitido; não repetir a decisão nem tratar o pacote inteiro como aprovado.0220/0226 adiadas conservam sua situação.
 - Controles de policy, approval, budget, journal, auditoria, pausa e cancelamento acompanham todas as fatias. Orquestrador decide por descritores; runtime executa pelo kernel. MCP, hooks, planos, skills e filhos nunca ganham um caminho paralelo de efeito.
