--- before/docs/03_build/0379_roadmap_paridade_100_deepseek.md
+++ after/docs/03_build/0379_roadmap_paridade_100_deepseek.md
@@ -10,7 +10,9 @@
 
 Atualização de27/10/2026, por direção explícita de Ricardo: a prioridade de execução é estabilizar e qualificar **kernel/runtime e controles**, depois continuidade de sessões/streaming, extensões MCP/skills/hooks e orquestração supervisionada. O [protocolo comum do núcleo](0381_plano_executivo_paridade_claude_code.md#execucao-nucleo) governa tarefa, posse, prova e integração dos dois programas; o0380 continua dono de todos os estados PAR.
 
-Os números, lacunas e calendário abaixo pertencem ao levantamento de16/10. Avanços posteriores devem ser reconciliados por fonte/recibo no cartão, sem reconstruir o que já foi entregue. O recorte de prioridade não reduz os266 itens, não exclui F6 nem substitui os aceites.
+Os números, lacunas e calendário abaixo pertencem ao levantamento de16/10. Avanços posteriores devem ser reconciliados por fonte/recibo no cartão, sem reconstruir o que já foi entregue. O recorte de prioridade não reduz o escopo aprovado, não exclui F6 nem substitui os aceites.
+
+Escopo vigente em 31/10/2026: **272 capacidades**, conforme os [recibos30 e32 e a medida versionada do Q01](0380_backlog_paridade_100_deepseek.md#escopo-par-cap-vigente). O levantamento de 266 e suas estatísticas abaixo são históricos de16/10; não foram recalculados nem promovidos a resultado atual. O freeze do Q01 permanece aberto, a paridade continua `NOT_MEASURED` e a ampliação documental não concede BUILD ou produção.
 
 - **Ponto de partida:** das 266 capacidades da referência levantadas em 16/10, o CVG tem 9 presentes, 76 parciais e 175 ausentes; 6 são divergência deliberada ou não se aplicam. A cobertura indicativa por leitura é de cerca de **18%** (parcial vale meio). Nenhuma capacidade tem ainda `PASS_CURRENT`.
 - **Por que não 70%:** a [auditoria 0611](../04_audit/0611_harness_deepseek_pairing_2026-10-14.md) mediu só o motor, com peso alto em governança, onde o CVG é forte. Aqui cada capacidade conta igual e entram interface, orquestração, protocolos e ferramentas, onde o CVG quase não tem nada.
@@ -41,7 +43,7 @@
 
 ## O que significa 100% (decisões D1, D2 e D4)
 
-1. **Denominador:** o catálogo PAR-CAP v1, com as 266 capacidades revisadas no PAR-Q01, cada uma com fonte na referência, procedimento de aceite e cartão. As 44.132 folhas estáticas da matriz P100-003 ficam como rastreabilidade de cada capacidade, não como denominador. Uma folha estática não é um comportamento testável.
+1. **Denominador:** o escopo autorizado do catálogo PAR-CAP v1 tem 272 capacidades; sua revisão e freeze continuam abertos no PAR-Q01. Cada capacidade exige fonte na referência, procedimento de aceite e cartão. As 44.132 folhas estáticas da matriz P100-003 ficam como rastreabilidade de cada capacidade, não como denominador. Uma folha estática não é um comportamento testável.
 2. **Numerador:** capacidades com `PASS_CURRENT` no medidor PAR-Q05. `PARTIAL`, `NOT_RUN`, `BLOCKED` e exceção pendente não contam. Uma falha de autorização, isolamento, efeito duplicado ou recuperação bloqueia o aceite mesmo com percentual alto, como no 0376.
 3. **Classes de capacidade:**
    - `EQUIVALENTE`: mesmo comportamento observável.
@@ -103,7 +105,7 @@
 O plano abaixo registra a seleção inicial; PAR-G01 já possui fechamento no0380. Na retomada de27/10, usar a fila prioritária e o protocolo comum para reconciliar os saldos reais. Não repetir commit, decisão humana ou qualificação já concluída por ler esta lista histórica.
 
 1. **PAR-G01:** o Codex faz commit, em branch própria, do trabalho da worktree em `/tmp` e integra a migration 0029. Os cinco gates T3 pendentes foram decididos em 16/10/2026 (0221, 0222 e 0225 aprovadas com ajustes; 0220 e 0226 adiadas), [registro](../04_audit/evidence/USER-DECISIONS-20261016/spec-gates.json).
-2. **PAR-Q01 e PAR-Q05:** congelar o catálogo PAR-CAP v1 a partir das 266 capacidades e publicar o medidor com a linha de base real.
+2. **PAR-Q01 e PAR-Q05:** concluir a revisão e congelar o catálogo PAR-CAP v1 no escopo autorizado de 272 capacidades, depois publicar o medidor com a linha de base real.
 3. **Em paralelo, com caminhos disjuntos:** PAR-K01 continua com o Codex (dono do P100-010); PAR-X01 e depois PAR-X02 (Landlock real, P0 de segurança, independente do resto); PAR-Q03 (kit de testes).
 4. **Saída do sprint:** denominador congelado, medidor com número real, serviço de subprocesso integrado e contrato do Landlock revisado. Nada de declaração antecipada de paridade.
 
