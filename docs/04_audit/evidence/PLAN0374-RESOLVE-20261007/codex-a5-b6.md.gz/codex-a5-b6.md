# Reauditoria independente A5/B6 — PLAN0374

**Candidato:** `d9172627fc5338951efdbc2877327869bc0519f4`  
**Base publicada informada:** `31dc1c3`  
**Data:** 07/10/2026  
**Modalidade:** somente leitura, sem subagentes.

| Gate | Veredito | Motivo |
|---|---|---|
| **A5** | **REJECT no material apresentado; remoto pendente** | A proteção arquivada não exige revisão; os checks obrigatórios não abrangem o novo scan nem a política de proveniência. |
| **B6** | **REJECT** | Dois mecanismos produzem aceitação indevida: confiança terminal no instalado e exceções sem vínculo suficiente com a implementação justificada. B3 também não atravessa o gate. |
| **C10** | **BLOCKED — sem GO** | Ambiente real, serviços e responsáveis ainda não identificados; não há comprovação das dez condições no mesmo SHA/digest. |

A aprovação atual de `hiso-010-v1-core-sealed` autoriza sua **validação**, sem aprovar retroativamente o BUILD ou dispensar os critérios restantes.

## Escopo e evidência

Inspecionei o delta dos quatro commits `d98d9ce`, `45723e4`, `47da95c` e `d917262`, com aprofundamento nos arquivos conectados a A5/B6. Li as instruções AGENTS aplicáveis, a seção `PLAN0374-RESOLVE`, os registros operacionais e os critérios HISO/ADR-010.

**Executado nesta revisão:** sondas pequenas em Node **22.23.2**, usando sobreposições de leitura e sistemas de arquivos sintéticos exclusivamente em memória; conferência mecânica de toda a tabela de exceções; verificações puras do contrato de CI; compilação `noEmit` do exemplo contra os pacotes já construídos existentes.

**Não executado:** suíte completa, os 128 testes de fronteira, gate completo sobre a árvore real, certificação, E2E, SBOM/licenças, Docker, PostgreSQL, CI remoto ou consultas de rede. Números desses procedimentos presentes no pacote são **evidência do implementador**, não execuções independentes minhas.

Algumas resoluções por subprocesso encontraram `EPERM` na sandbox. Portanto, esta revisão não qualifica integralmente a resolução nativa Node. Nenhum alvo sintético de carregamento foi efetivamente importado.

Não alterei arquivos, Git, ledgers, infraestrutura ou recursos. Não li `.env` nem credenciais. O checkout continuou em `d917262`; os diffs concorrentes foram preservados.

## Findings A5

### A5-P1-01 — Proteção apresentada não exige revisão e o runbook admite push direto

**Evidência estática:**

- `docs/04_audit/evidence/PLAN0374-A-20261007/raw/branch-protection-main.json:1`: `required_pull_request_reviews: null`.
- [Plano 0374, linha 59](</home/ricardo/Área de trabalho/cvg-operational-harness/docs/03_build/0374_plano_producao_harness.md:59>): A1 exige revisão obrigatória e ausência de push direto.
- [Runbook 0803, linhas 70–79](</home/ricardo/Área de trabalho/cvg-operational-harness/docs/08_runtime/0803_runbook_gates_locais.md:70>): publica um fluxo terminando em `git push origin HEAD:main`.

Além disso, o comentário de que o push para `candidate/<task>` dispara Verify/Security contradiz os workflows: ambos aceitam `pull_request`, mas seus eventos `push` abrangem apenas `main`/`master`.

**Cenário reproduzível:** seguir o fluxo documentado publicando somente a branch candidata não dispara esses workflows por `push`. A proteção arquivada também não estabelece revisão obrigatória.

**Limite:** não consultei a proteção atual. Uma correção remota posterior pode resolver parte do finding; precisa ser comprovada pelo integrador.

**Remediação mínima / owner:** administrador do repositório e mantenedor do runbook devem exigir PR com revisão, comprovar a regra efetiva e corrigir o fluxo documental.

### A5-P1-02 — Os checks obrigatórios não bloqueiam falhas do scan ou da proveniência

A proteção arquivada exige apenas:

`REM21 CI bar (Node 22)`, `codeql`, `secret-scan`, `supply-chain`.

O novo `image-scan` é um job independente em [Security, linha 87](</home/ricardo/Área de trabalho/cvg-operational-harness/.github/workflows/security.yml:87>). A verificação final da proveniência fica em `verify.yml:401–423`, job **Provenance policy**, também ausente dessa lista.

**Cenário reproduzível — estático:** os quatro contextos exigidos podem passar enquanto `image-scan` ou `Provenance policy` falham. A regra arquivada, isoladamente, permite integração nessas condições.

O Trivy está presente, com action fixada por SHA e `exit-code: '1'` para HIGH/CRITICAL com correção disponível. A lacuna é a exigibilidade do resultado, não a ausência do scanner.

**Remediação mínima / owner:** engenharia de CI e administrador devem tornar esses resultados obrigatórios, diretamente ou por agregador que falhe quando algum resultado necessário falhar, faltar ou for pulado. O integrador deve verificar nomes e identidade dos checks no remoto.

### A5-P2-01 — O relatório Trivy desaparece no caminho de falha

Em `security.yml:103–128`, o scan bloqueante vem antes do relatório JSON e do upload. Esses passos posteriores não possuem condição para executar após falha.

**Cenário reproduzível — estático:** uma vulnerabilidade corrigível faz o primeiro scan falhar; o relatório completo e seu upload são pulados.

**Remediação mínima / owner:** mantenedor de Security deve preservar o relatório também na falha, mantendo o resultado bloqueante do scan.

Não verifiquei a situação atual da CVE citada nem concedo nova aceitação de vulnerabilidade ou extensão de prazo.

## Findings B6

### B6-P1-01 — Metadados do lockfile não comprovam os bytes realmente instalados

Em [boundary-manifests.mjs, linhas 445–469](</home/ricardo/Área de trabalho/cvg-operational-harness/scripts/boundary-manifests.mjs:445>), a instalação é considerada verificada por identidade nominal, URL HTTPS e formato de `integrity`. Não ocorre validação desses bytes contra o conteúdo instalado. Até divergência de versão mantém `verified: true`.

O scan posterior, linhas 481–503, procura referências literais a produtos. O próprio comentário o define como *tripwire*, não prova.

**Sonda executada:** sobrepus somente leituras de `node_modules/semver/package.json` e `index.js` em memória, preservando o lockfile real. Informei versão instalada `9.9.9`, contra `7.7.4` no lock, e conteúdo:

```js
module.exports = require('../../' + 'products/' + 'shift-assistant/src/main.ts')
```

O resultado foi:

- `verified: true`;
- deriva de versão apenas informativa;
- nenhuma referência detectada pelo tripwire;
- nenhuma ligação simbólica detectada.

Avaliei a concatenação com `require` inerte, que apenas registrou o argumento. **Não carreguei o produto e não executei o gate completo da árvore real.** O defeito demonstrado é a aceitação desses bytes pelo componente que fundamenta o tratamento terminal.

A evidência do implementador também registra `source-map-js` instalado em versão diferente do lock e explicita a premissa de que pacotes de registro não construirão caminhos de produto dinamicamente. Essa premissa não foi aprovada pelo usuário.

**Remediação mínima / owner:** mantenedor do gate e engenharia de instalação devem comprovar a identidade do conteúdo efetivamente instalado, recusar deriva e definir explicitamente o tratamento de código opaco. Sem prova suficiente, o resultado deve permanecer `INCOMPLETE`. Conferir apenas o texto do campo SRI não valida o conteúdo.

### B6-P1-02 — Exceções preservam linha/digest, mas permitem trocar o receptor

O mecanismo em [check-product-boundary.mjs, linhas 1737–1764](</home/ricardo/Área de trabalho/cvg-operational-harness/scripts/check-product-boundary.mjs:1737>) vincula motivo, caminho, texto normalizado da linha e digest da expressão diagnosticada, com contagem máxima.

Isso não necessariamente vincula o corpo do receptor, seu import ou sua identidade. O digest pode cobrir apenas `process` ou `globalThis`. A linha é texto normalizado, não uma posição numérica congelada; a contagem é um teto, não igualdade obrigatória.

**Sonda executada 1 — shutdown:** no sistema de arquivos em memória, mantive o arquivo `packages/shared/src/lifecycle.ts` byte a byte, satisfazendo o único pin dessa família, mas substituí o receptor no arquivo permitido:

```ts
const shutdown = {
  install(source: any) {
    source.getBuiltinModule('module')
      .createRequire(__filename)('../../../products/shift/src/index.ts')
  }
}
shutdown.install(process)
```

Resultado do checker original: **PASS**, sem diagnósticos ou violações, consumindo `shutdown-signal-source`. Com exceções desativadas: **INCOMPLETE**.

**Sonda executada 2 — spy:** defini um objeto local `vi` cujo `spyOn` usava `globalThis.process` para adquirir um carregador, preservando a linha permitida:

```ts
vi.spyOn(globalThis, 'fetch').mockImplementation((input) => {
})
```

Resultado: **PASS**, consumindo `vitest-fetch-spy`; sem exceções: **INCOMPLETE**.

Essas sondas demonstram bypass da decisão do gate. Os corpos foram analisados, não executados. Não demonstram que os receptores atuais do candidato carregam o produto.

**Remediação mínima / owner:** mantenedor da fronteira deve vincular a exceção à implementação e identidade efetivamente justificadas, recusando mudança de receptor/import/alias. Aplicar a correção a todas as famílias, inclusive espelhos compilados, com controles negativos de troca de receptor e corpo.

### Revisão de toda a tabela de exceções

Conferi **10 grupos, 9 IDs, 120 chaves e capacidade total de 169 diagnósticos**, distribuídos por **44 caminhos distintos**. Os vínculos mecânicos conferem com as fontes presentes e os registros arquivados; isso não resolve o finding semântico anterior.

| Grupo e linhas em `check-product-boundary.mjs` | Chaves / capacidade | Resultado da revisão |
|---|---:|---|
| `vitest-fetch-spy`, 1875–2007 | 30 / 58 | Sem pins; identidade de `vi` não vinculada. **Bypass demonstrado.** |
| `entrypoint-subprocess`, 2009–2144 | 38 / 42 | Inclui chamadas e referências auxiliares; sem pin de implementações. Troca de identidade permanece hipótese não sondada. |
| `shutdown-signal-source`, 2146–2176 | 4 / 7 | Pin de `lifecycle.ts` não garante que o receptor seja sua implementação. **Bypass demonstrado.** |
| `entrypoint-process-double`, 2178–2199 | 4 / 4 | Referências a `process`; sem vínculo completo com doubles/receptores. Risco estático. |
| `plain-object-reflection`, 2201–2299 | 24 / 35 | Digests de reflexão/propriedades não comprovam procedência dos objetos e descritores. Risco estático. |
| `test-proxy-get-trap`, 2301–2329 | 6 / 8 | `Reflect.get`, `value`, `bind`; justificativa depende de valores externos ao fragmento. Risco estático. |
| `function-type-matcher`, 2331–2350 | 3 / 3 | Digest de `Function`, sem vínculo completo com o uso justificado. Risco estático. |
| `web-bootstrap-token`, 2352–2364 | 1 / 1 | Escape de `globalThis`, sem pin da implementação. Risco estático. |
| `web-bootstrap-token`, 2366–2386 | 4 / 4 | Propriedades do bootstrap; mesmo ID, outro motivo, sem pin. Risco estático. |
| `typescript-reexport-helper`, 2388–2411 | 6 / 7 | Helper em espelho compilado ignorado pelo Git; procedência da geração não vinculada. Risco estático. |
| **Total** | **120 / 169** | **Binding mecânico confere; soundness não aceita.** |

Não alego bypass executado em todas as famílias. Também não considero os **128 testes verdes** suficientes para aceitar a tabela: os dois controles adversariais acima preservam seus bindings e ainda recebem PASS.

### B6-P2-01 — B3 não passa pelo gate; o CI também não aplica o checker à árvore real

As raízes do checker em [linha 93](</home/ricardo/Área de trabalho/cvg-operational-harness/scripts/check-product-boundary.mjs:93>) são `packages`, `apps`, `legacy` e `products`. Os arquivos de `examples/consumers` não entram no inventário de fontes.

**Sonda executada:** coloquei em memória no exemplo:

```ts
export const product = process.env.SHIFT_PORT
```

Resultado: **PASS**; o arquivo não apareceu no grafo. Isso demonstra ausência de inspeção, não aceitação válida de B3.

A própria evidência B, `summary.md:80–82`, informa que a verificação foi por grep e que o exemplo não entra no gate.

Adicionalmente, a barra de 34 gates e `verify.yml` não invocam o checker sobre a árvore real. Os testes de fronteira exercitam fixtures; não substituem essa execução.

**Remediação mínima / owner:** responsáveis por fronteira/B3/CI devem dar ao consumidor neutro uma rota explícita de verificação e arquivar seu grafo. Integrar a execução da árvore real à aceitação automatizada sob o contrato de evidência apropriado.

### B6-P2-02 — Falta prova arquivada do consumidor contra exports construídos sem aliases

A documentação lista **103 nomes suportados em cinco pacotes**. Na conferência das fontes, não encontrei nome documentado ausente nos entrypoints. Os manifests expõem a raiz pública e a documentação descreve corretamente o uso direto de `OpenAICompatibleProvider` pelo produto.

Entretanto, [consumers-public-surface.test.ts, linhas 114–128 e 314–324](</home/ricardo/Área de trabalho/cvg-operational-harness/tests/consumers-public-surface.test.ts:114>) resolve imports com a configuração de aliases para os entrypoints de **fonte**. Isso não substitui o aceite de HISO-009 contra pacotes construídos. O smoke em scratch declarado pelo implementador não foi arquivado.

**Sonda executada:** a compilação `noEmit`, retirando `paths` e usando os `dist` existentes, produziu dois TS2339 relacionados a `ModelRequest.signal`. A fonte declara `signal` em `packages/contracts/src/contracts.ts:259–270`; o `dist/contracts.d.ts:193–200` local não.

**Classificação:** observação de artefato local desatualizado e lacuna de evidência. **Não é bug demonstrado na fonte congelada.**

**Remediação mínima / owner:** mantenedor dos contratos/B3 deve construir os pacotes em cópia limpa do candidato e arquivar compilação sem aliases mais jornada sintética contra os exports construídos.

### B6-P2-03 — B5 separa testes/cobertura do core, mas não fecha a certificação por artefato

Há avanços verificáveis:

- `CVG_TEST_SCOPE=core` exclui o produto dos testes e cobertura do núcleo;
- o escopo entra no estado/manifesto e é conferido na atestação;
- as sondas puras recusaram caminhos de produto em relatórios do core;
- o self-test do contrato executado retornou **40/40 PASS**;
- o workflow do produto mede dono, arquivos, testes, SHA/run e hash do relatório.

As lacunas permanecem:

1. [Workflow do produto, linhas 87–165](</home/ricardo/Área de trabalho/cvg-operational-harness/.github/workflows/product-shift-assistant.yml:87>): não produz coverage própria; o job de imagem é independente e não arquiva digest/proveniência vinculados ao resultado dos testes.
2. O denominador recusa vazio, skips e arquivos estrangeiros, mas não confronta um inventário esperado: uma suíte reduzida ainda pode passar. A preservação de `2 arquivos/37 testes` é uma medição arquivada, não esse controle.
3. Format/lint/typecheck/docs do harness ainda abrangem `products/**`; portanto, uma falha do produto pode bloquear a barra do core fora de testes/coverage.
4. A cobertura core favorável citada é recálculo de agregado anterior. Não equivale à execução atual em Node 22 com PostgreSQL.
5. Não há execução real independente comprovada aqui de CI/proveniência no candidato sob a aprovação atual.

**Cenário reproduzível — estático:** o job de imagem pode passar apesar da falha do job de testes; o relatório de testes não identifica o digest dessa imagem. Alterações inválidas no produto continuam afetando checks globais do harness.

**Remediação mínima / owner:** engenharia de CI e responsável pelo produto devem validar a matriz gate→artefato aprovada, produzir evidências próprias de coverage e imagem/proveniência, preservar o inventário de regressões e executar CI real no candidato. Os critérios aplicáveis de segurança, PG e E2E continuam exigidos por HISO-010; não imponho automaticamente os antigos 16 gates nem aprovo sua dispensa.

### B6-P2-04 — Comandos do runbook não executam todos os gates listados

Em `0803_runbook_gates_locais.md:30,33,36–40`, comandos como:

```sh
npm run format:check typecheck lint build
```

invocam o primeiro script com argumentos adicionais; não executam os quatro scripts em sequência.

**Evidência:** análise estática. Não executei os comandos, pois várias linhas acionariam procedimentos proibidos nesta revisão.

**Remediação mínima / owner:** mantenedor do runbook deve explicitar cada invocação sequencial ou um agregador existente, preservando falha e saída de cada gate. Atualizar também a descrição antiga do checker em linhas 58–61, sem apresentá-lo como aceito.

## Condição dos aceites e próximo gate

| Critério | Condição resultante |
|---|---|
| **HISO-005** | **Aberto:** bridges `.d.mts`, aliases e links de workspace receberam tratamento melhor, mas confiança terminal e exceções ainda invalidam a conclusão geral. |
| **HISO-009** | **Aberto:** superfície documental coerente com fontes; falta prova arquivada contra exports construídos, e B3 não atravessa a fronteira. |
| **HISO-010** | **Em validação autorizada:** separação e selagem do core avançaram; certificação por artefato e CI real permanecem pendentes. |
| **HISO-014 / ADR-010** | **Não aceitar isolamento:** faltam os pré-requisitos acima e comprovação limpa da variante independente. Não atualizar para “isolamento aceito”. |
| **C10** | **BLOCKED:** falta inventário do ambiente real e comprovação operacional no mesmo SHA/digest. |

A autorização de `BYPASSRLS` permanece restrita ao backup dedicado, somente leitura e fora do serving. A configuração preparada não comprova os papéis e ACLs do ambiente existente; não concedo extensão dessa exceção.

O próximo gate é o integrador confrontar a proteção remota atual com A5, encaminhar as remediações aos owners e congelar um novo candidato. A nova validação deve incluir os controles negativos de instalação/receptor, consumidor neutro realmente inspecionado, smoke público sem aliases e CI real sob o contrato atualmente autorizado. **C10 continua bloqueado até identificação e evidência do ambiente real; este parecer não concede merge, release ou GO.**