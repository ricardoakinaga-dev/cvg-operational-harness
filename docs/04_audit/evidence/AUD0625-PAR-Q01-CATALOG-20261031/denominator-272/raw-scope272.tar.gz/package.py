from pathlib import Path
import json,gzip,hashlib,tarfile,io,shutil
R=Path(__file__).resolve().parent;C=R.parent/'candidate';E=C/'docs/04_audit/evidence/AUD0625-PAR-Q01-CATALOG-20261031/denominator-272';H=lambda b:hashlib.sha256(b).hexdigest();J=lambda p:json.loads(p.read_text())
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
summary=J(R/'build-summary.json');measure=J(E/'measure.json')
(E/'REPORT.md').write_text('''# Q01 — medida r3 com 272 capacidades

**Emenda de escopo aplicada ao novo rascunho; Q01 continua aberto, sem aceite funcional.** A medida `r3-denominator-272` tem272 IDs únicos, mantém os270 IDs e descrições anteriores verbatim e acrescenta G1/SPILL-03 e G1/SESSION-07. O recibo32 e a disposição DF83727 autorizam esta alteração documental. Início GBrain85930, após a entrega prioritária da revisão0297/85652.

O [manifesto da medida](measure.json) publica os hashes comprimido e descomprimido do [catálogo272](catalog-272.json.gz), a autoridade e o denominador. O [índice legível](capability-index.json) contém os272 IDs e descrições. GrupoG1 passa de50 a52; G2=71, G3=56, G4=47 e G5=46. Numerador PASS_CURRENT=0, paridade NOT_MEASURED, produção NO_GO. Publicar este rascunho com hash não equivale ao freeze canônico do Q01 nem à implementação das capacidades.

## Duas capacidades com escopo autorizado

As [fichas novas](new-capabilities.json) conservam literalmente as descrições e procedimentos do scope-options aprovado. Incluem fontes Git768fb, positivos, negativos, artefatos e gates pendentes. SPILL-03 cobre as23 folhas de limpeza por idade/raízes confiáveis/sweep aguardado; SESSION-07 cobre as três folhas de renomeação manual/origem user/normalização/supersession da geração.

As26 folhas estão na [proposta de relações](scope-leaf-proposals.json), com metadados e status de extração preservados:21 STATIC e5 UNKNOWN. A decisão humana resolve a lacuna de escopo, mas não aceita automaticamente cada relação semântica. Nenhuma delas virou relação revista ou PASS. Os cartões candidatos PAR-C03/PAR-S03 permanecem associações para reconciliar; o catálogo não afirma que a SPEC0224 ou o escopo antigo do cartão já autorizam as capacidades novas.

## WEB-02: exceção da referência e meta CVG

A [disposição de proxy](proxy-disposition.json) registra a referência real: a rota direta valida/fixa IPs; o proxy delega DNS ao dispatcher e não faz a mesma resolução/fixação local. A recusa de literal não público continua explícita no código. O procedimento compara as duas rotas e documenta a exceção, sem fingir pinning local no proxy.

A exigência da CVG permanece **UNIVERSAL_FAIL_CLOSED**: validar e fixar também pelo proxy, ou deixá-lo desligado. A descrição WEB-02 original ficou verbatim; o procedimento anterior está no histórico. A disposição do DF não resolve as outras diferenças: QUERY-02/carregamento integral, SESSION-05/deduplicação de estatística e WEB-02/truncamento de stream continuam abertas. Nenhuma dispensa de egress ou produção foi concedida.

## Entrada concreta para revisão das355 propostas

O [handoff](review-handoff.json) congela exatamente as263 propostas util e92 propostas corrigidas pedidas pelo DF:220 grupos/355 folhas,268 STATIC e87 UNKNOWN. O [input355](review-input355.json.gz) preserva cada grupo original integralmente, com origem e status PENDING_INDEPENDENT_REVIEW. Não incorpora silenciosamente as26 novas relações ou as881 propostas de ferramentas à solicitação355. Nenhuma folha ou aceitação nova foi criada para inflar contagem.

A regra0380:31 continua literal: uma revisão independente por cartão, no máximo dois retrabalhos, retorno ao replanejamento após duas rejeições. O histórico não foi apagado: R1 rejeitou o freeze; REWORK1/R2 aprovou apenas reparos F02/F03/F04; a conferência F01/B01 rejeitou118 relações; veio o replanejamento78654; agora DF83727 pede revisão das355. Não se presume que uma nova versão da medida reinicie esse orçamento.

Nenhum crítico foi iniciado nesta unidade de autoria. **A revisão semântica independente permanece pendente.** Próxima ação concreta para Claude DF: dispor o gate remanescente exato sob esse histórico e0380:31, com escopo355 e revisor não autor/paths; dispor as26 relações separadamente. Se o ciclo permitido se esgotou, manter o replanejamento. Isso é uma pendência de aceite, não uma alegação de que a preparação documental ficou bloqueada ou de que o objetivo integral terminou.

## Conferências realizadas

- Os270 IDs/descrições estão exatos;269 objetos anteriores ficaram integralmente iguais. Somente WEB-02 recebeu a disposição autorizada, mantendo classificação, fontes, cartões, gates e histórico.
-121 blobs da referência e1376 trechos citados foram autenticados por Git/OID/SHA/limites, incluindo as fontes carregadas pelas355 propostas. Isso é integridade da entrada, não nova leitura semântica independente de355 folhas. O Lead leu novamente os caminhos focais de cleanup, unload, rename e proxy.
- Matriz original44132 conferida:30586 STATIC/13546 UNKNOWN. As381 identidades da entrada355 e das26 novas propostas mantêm hashes, fonte, owner, escopo, extração e estado de paridade.
- A [verificação documental](verification.json) aceitou o pacote e recusou15 cópias deliberadamente inválidas: remoção/mudança de ID ou descrição, denominador errado, perda de positivo/folha, promoção UNKNOWN, PASS fictício, dispensa de proxy, eliminação do pendente de stream, alteração da entrada355, falso aceite/reset e fecho indevido do Q01. São guardas do artefato, não testes funcionais do produto.
-15 inputs anteriores/recibos/backlog conferidos sem alteração. Todos os originais ficam imutáveis. O índice de folhas270 e as antigas lanes foram qualificados como proveniência histórica; as26 propostas têm suplemento próprio e não recebem crédito retroativo pelo índice antigo.

Partição global, sem dupla contagem:2893 relações estáticas revistas anteriormente +355 propostas para revisão +881 propostas de ferramentas +26 propostas de escopo novo +74 util unresolved +94 ferramentas unresolved +1511 sessão pendentes +811 orquestração pendentes +37487 fora do B01 =44132. Continuam41239 folhas sem aceite semântico e1262 propostas não aceitas. Uma relação estática revista não é PASS funcional.

[Inputs](input-pins.json), [fontes](source-pins.json), [trechos autenticados](authenticated-ranges.json), [recibo32](receipt32.json), [cadeia31](receipt31.json), [checks](checks.json), [notas](NOTAS.md), [deltas](LEDGER-DELTAS.md), [bruto](raw-scope272.tar.gz), [inventário](raw-files.json), [readback do bruto](raw-archive.json).

Nenhum BUILD, aplicação, import de produto, teste funcional, provider, PG, Docker, instalação, rede de aplicação, push, merge ou produção foi executado. A autoria documental usa inspeção própria, sem declarar revisão independente. O objetivo integral permanece ativo.
''')
(E/'NOTAS.md').write_text('''# Notas da emenda272

A revisão prioritária0297 terminou antes desta tarefa, com entrega85652/commit25620bdc9 e seisP2 para DF/D9. Esta unidade começou com consulta incremental e leitura exata da disposição83727, do recibo32 e da cadeia31. Não reabriu X01/X02 ou entregas anteriores.

O arquivo-base real é capabilities-r3-draft.json.gz do reparo ed757af924, cujo conteúdo descomprimido tem SHA325c2c114533e8a3716d288c2eed4337cfe558660fd42a18f6a9077e6eb25574. O catálogo semantic anterior SHA84419b36 é histórico, não foi confundido com esse draft mais recente. O denominador era270 na medida r2; o identificador draft r3 era distinto da revisão da medida. Agora medida r3-denominator-272 e draft r4 são explícitos.

Na montagem inicial, uma asserção recusou o uso de índice posicional do inventário: ele selecionava o hash do recibo31 para a autoridade32. A correção passou a selecionar o recibo32 autenticado explicitamente. Nenhum catálogo ou artefato de evidência tinha sido publicado naquele ponto; fontes/recibos/escopo permaneceram iguais. O erro está preservado no bruto.

O rascunho herdava um ponteiro dizendo que F02/F03/F04 ainda aguardavam readback. A disposição histórica autenticada já os fecha somente no escopo R2. O novo catálogo aponta para essa disposição e conserva F01 aberto, sem nova aprovação ou reabertura dos achados fechados.

Os procedimentos das capacidades novas contêm o texto de gates aprovado no pacote anterior à decisão humana32. Uma qualificação explícita informa que apenas a condição D1 de escopo foi satisfeita; os gates de SPEC/T3/efeito/execução continuam obrigatórios. O cartão candidato não herda autorização de BUILD ou da SPEC de capacidade vizinha.

O scanner valida arquivos visíveis. O catálogo e inputs355 comprimidos têm digests e leitura de volta, sem alegar varredura do conteúdo comprimido. A autenticação de121 blobs/1376 ranges não equivale a reler semanticamente todo esse conteúdo, nem substitui o crítico independente solicitado pelo DF.

A preparação355 mantém o pedido concreto e o histórico de orçamento. Nenhum filho, ciclo extra de crítica, novo lote ou aceite foi iniciado. Ledgers99/20/30 compartilhados e índice root ficaram somente leitura; deltas próprios seguem para o holder. Objetivo integral ativo; não há impasse externo global nesta unidade.
''')
(E/'LEDGER-DELTAS.md').write_text('''# Deltas para o holder

Não aplicados aos ledgers99/20/30 compartilhados.

- Última ação: DF83727/human32 aplicado em nova medida r3-denominator-272 com hash, preservando270IDs/descrições; SPILL-03 e SESSION-07 com26folhas propostas,21STATIC/5UNKNOWN. Autoridade de escopo concedida, BUILD/aceite funcional não concedidos.
- WEB-02: exceção da referência por proxy DNS documentada; CVG universal fail-closed, validar/fixar ou desligar proxy; sem dispensa. IO QUERY-02, deduplicação SESSION-05 e truncamento WEB-02 continuam pendentes.
- Validação:272IDs/descrições/oráculos/gates,355inputs exatos220grupos,121sources1376ranges autenticados,matriz44132/metadados381preservados,15cópias inválidas recusadas; integridade documental, não revisão semântica.
- Backlog Q01: OPEN/F01;2893 relações antes revistas,1262 propostas não aceitas,41239 folhas sem aceite semântico,0PASS_CURRENT. Nova medida não é freeze canônico/Q05 nem liberação produtiva.
- Próxima ação: DF dispõe exatamente o gate remanescente de revisão355 sob0380:31 e históricoR1/reworkR2/B01/replanejamento, nomeia revisor não autor/paths;26 relações novas tratadas separadamente. Nenhum reset inferido, novo lote ou critic iniciado.
- Objetivo global ACTIVE/incompleto, rodada com progresso documental; sem push/merge/produção.
''')
dump(E/'checks.json',{'status':'PENDING_T1','functional_tests':0,'semantic_review':False});dump(E/'build-summary.json',summary)
# Archive actual task scripts, frozen inputs and source snapshots. The archive is immutable after this packaging.
files=sorted(p for p in R.rglob('*') if p.is_file() and p.name not in ['raw-scope272.tar.gz','raw-files.json','raw-archive.json'])
rows=[{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':H(p.read_bytes())} for p in files]
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as t:
 for p in files:
  data=p.read_bytes();i=tarfile.TarInfo(str(p.relative_to(R)));i.size=len(data);i.mtime=0;t.addfile(i,io.BytesIO(data))
archive=gzip.compress(buf.getvalue(),mtime=0);(E/'raw-scope272.tar.gz').write_bytes(archive)
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as t:
 members={m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
assert len(members)==len(rows)
for row in rows:assert len(members[row['path']])==row['bytes'] and H(members[row['path']])==row['sha256']
dump(E/'raw-files.json',rows);dump(E/'raw-archive.json',{'path':'raw-scope272.tar.gz','files':len(rows),'bytes':len(archive),'sha256':H(archive),'readback':'ALL_MEMBERS_EXACT_SHA256','scanner_scope':'VISIBLE_ARTIFACTS_ONLY_NOT_COMPRESSED_MEMBERS'})
for n in ['build.py','verify.py']:(E/n).write_bytes((R/n).read_bytes())
print(json.dumps({'raw_files':len(rows),'raw_bytes':len(archive),'raw_sha256':H(archive),'catalog_sha256':measure['catalog']['raw_sha256']}))
