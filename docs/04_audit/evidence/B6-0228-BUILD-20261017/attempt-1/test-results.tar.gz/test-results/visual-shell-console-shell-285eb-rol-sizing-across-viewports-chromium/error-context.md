# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: visual-shell.spec.ts >> console shell preserves layout, focus and control sizing across viewports
- Location: tests/e2e/visual-shell.spec.ts:9:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'CVG Agent Secretary' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByRole('heading', { name: 'CVG Agent Secretary' })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e4]: "[plugin:vite:import-analysis] Failed to resolve import \"@cvg/shared\" from \"apps/web/src/features/platform/draft-helpers.ts\". Does the file exist?"
  - generic [ref=e5]: /home/ricardo/cvg-candidates/b6-0228-20261017/apps/web/src/features/platform/draft-helpers.ts:9:36
  - generic [ref=e6]: "7 | * platform characterization suite (unchanged behavior). 8 | */ 9 | import { redactSensitiveText } from \"@cvg/shared\"; | ^ 10 | import { parsePromptProfile, serializePromptBlocks, serializeResponseTemplates } from \"./prompt-profile.ts\"; 11 | export const initialForm = {"
  - generic [ref=e7]: at TransformPluginContext._formatLog (file:///home/ricardo/cvg-candidates/b6-0228-20261017/node_modules/vite/dist/node/chunks/node.js:31147:39) at TransformPluginContext.error (file:///home/ricardo/cvg-candidates/b6-0228-20261017/node_modules/vite/dist/node/chunks/node.js:31144:14) at normalizeUrl (file:///home/ricardo/cvg-candidates/b6-0228-20261017/node_modules/vite/dist/node/chunks/node.js:28083:18) at async file:///home/ricardo/cvg-candidates/b6-0228-20261017/node_modules/vite/dist/node/chunks/node.js:28153:30 at async Promise.all (index 0) at async TransformPluginContext.transform (file:///home/ricardo/cvg-candidates/b6-0228-20261017/node_modules/vite/dist/node/chunks/node.js:28119:4) at async EnvironmentPluginContainer.transform (file:///home/ricardo/cvg-candidates/b6-0228-20261017/node_modules/vite/dist/node/chunks/node.js:30932:14) at async loadAndTransform (file:///home/ricardo/cvg-candidates/b6-0228-20261017/node_modules/vite/dist/node/chunks/node.js:20671:26) at async viteTransformMiddleware (file:///home/ricardo/cvg-candidates/b6-0228-20261017/node_modules/vite/dist/node/chunks/node.js:25205:20)
  - generic [ref=e8]:
    - text: Click outside, press Esc key, or fix the code to dismiss.
    - text: You can also disable this overlay by setting
    - code [ref=e9]: server.hmr.overlay
    - text: to
    - code [ref=e10]: "false"
    - text: in
    - code [ref=e11]: vite.config.mts
    - text: .
```

# Test source

```ts
  1  | import { expect, test } from '@playwright/test'
  2  | 
  3  | const viewports = [
  4  |   { name: 'mobile', width: 375, height: 812 },
  5  |   { name: 'tablet', width: 768, height: 900 },
  6  |   { name: 'desktop', width: 1440, height: 900 }
  7  | ] as const
  8  | 
  9  | test('console shell preserves layout, focus and control sizing across viewports', async ({
  10 |   page
  11 | }) => {
  12 |   for (const viewport of viewports) {
  13 |     await page.setViewportSize(viewport)
  14 |     await page.goto('/', { waitUntil: 'networkidle' })
  15 | 
  16 |     await expect(
  17 |       page.getByRole('heading', { name: 'CVG Agent Secretary' })
> 18 |     ).toBeVisible()
     |       ^ Error: expect(locator).toBeVisible() failed
  19 |     const skipLink = page.getByRole('link', {
  20 |       name: 'Pular para o console operacional'
  21 |     })
  22 |     await expect(skipLink).toBeAttached()
  23 |     await skipLink.focus()
  24 |     await skipLink.press('Enter')
  25 |     await expect(page.locator('#console-operacional')).toBeFocused()
  26 | 
  27 |     const metrics = await page.evaluate(() => ({
  28 |       viewport: window.innerWidth,
  29 |       scrollWidth: document.documentElement.scrollWidth,
  30 |       actionMinHeights: Array.from(
  31 |         document.querySelectorAll('.actions button, .sessionButton')
  32 |       ).map((element) => Number.parseFloat(getComputedStyle(element).minHeight))
  33 |     }))
  34 |     expect(
  35 |       metrics.scrollWidth,
  36 |       `${viewport.name} horizontal overflow`
  37 |     ).toBeLessThanOrEqual(metrics.viewport)
  38 |     expect(metrics.actionMinHeights.every((height) => height >= 40)).toBe(true)
  39 | 
  40 |     const sessionButton = page.getByRole('button', { name: 'Encerrar sessão' })
  41 |     await sessionButton.focus()
  42 |     await expect
  43 |       .poll(() =>
  44 |         sessionButton.evaluate(
  45 |           (element) => getComputedStyle(element).outlineStyle
  46 |         )
  47 |       )
  48 |       .toBe('solid')
  49 |     await expect(page).toHaveScreenshot(`console-${viewport.name}.png`, {
  50 |       animations: 'disabled',
  51 |       caret: 'hide',
  52 |       fullPage: false,
  53 |       maxDiffPixelRatio: 0.02
  54 |     })
  55 |   }
  56 | })
  57 | 
  58 | test('admin control center remains navigable on a narrow viewport', async ({
  59 |   page
  60 | }) => {
  61 |   await page.setViewportSize({ width: 375, height: 812 })
  62 |   await page.goto('/', { waitUntil: 'networkidle' })
  63 |   await page.getByLabel('ID do operador').fill('operator.fixture')
  64 |   await page.getByLabel('Papel operacional').selectOption('Admin')
  65 |   await page
  66 |     .getByLabel('Tenant ID')
  67 |     .fill('tenant_00000000-0000-4000-8000-000000000199')
  68 | 
  69 |   await expect(page.locator('#platform-panel')).toBeVisible()
  70 |   await expect(
  71 |     page.getByRole('navigation', { name: 'Atalhos do Control Center' })
  72 |   ).toBeVisible()
  73 |   await expect(page.getByRole('link', { name: 'Release ledger' })).toBeVisible()
  74 | 
  75 |   const metrics = await page.evaluate(() => ({
  76 |     viewport: window.innerWidth,
  77 |     scrollWidth: document.documentElement.scrollWidth
  78 |   }))
  79 |   expect(metrics.scrollWidth).toBeLessThanOrEqual(metrics.viewport)
  80 | })
  81 | 
```