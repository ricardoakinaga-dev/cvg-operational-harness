import assert from 'node:assert/strict';
import {randomBytes, createHash} from 'node:crypto';
import {writeFile} from 'node:fs/promises';
import {Client} from 'pg';
import {TENANT_SCHEMA_TABLES, runPostgresMigrations} from '@cvg/persistence';
import {runOperatorSessionMigrations, grantOperatorSessionFunctions} from '../candidate/packages/persistence/src/operator-session-migrations.ts';
import {buildApiWithProductionSessions} from '../candidate/apps/api/src/production-bootstrap.ts';
import {createConfiguredOperatorIdentityResolver, createTrustedOperatorIdentityToken} from '../candidate/apps/api/src/operator-identity.ts';
import {createPostgresOperatorSessionPool, PostgresOperatorSessionStore} from '../candidate/apps/api/src/operator-session-postgres.ts';
const out='/tmp/cvg-aud0604-20261006/session-reviewer';
const base='postgres://postgres:synthetic-aud0604-local@127.0.0.1:55726/cvg_aud0604_review';
const prefix='aud0604review_'+randomBytes(6).toString('hex');
const data=prefix+'_data',auth=prefix+'_auth';
const mig=prefix+'_mig',owner=prefix+'_owner',runtime=prefix+'_runtime',session=prefix+'_session';
const roles=[mig,owner,runtime,session];
const admin=new Client({connectionString:base});
const clients=[], pools=[], apps=[];
const results=[];
const A={operatorId:'review.synthetic.a',role:'Admin',tenantId:'tenant_11111111-1111-4111-8111-111111111111'};
const B={...A,operatorId:'review.synthetic.b'};
const key={keyId:'review-synthetic',secret:'review-synthetic-auth-key-01234567890123456789'};
const headers={origin:'https://review.test','x-forwarded-proto':'https'};
function roleUrl(role){const u=new URL(base);u.username=role;u.password='aud0604_review_only';return u.toString();}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const digest=id=>createHash('sha256').update(id).digest();
const cookieOf=r=>String(r.headers['set-cookie']).split(';')[0];
const sid=c=>c.split('=')[1];
const createSig='operator_session_create(bytea,text,text,text,timestamptz)';
const revokeSig='operator_session_revoke(bytea)';
let store,app,otherStore;
async function record(name,fn){const t=Date.now();try{const detail=await fn();results.push({name,status:'PASS',ms:Date.now()-t,detail});console.log('PASS',name,JSON.stringify(detail));}catch(e){results.push({name,status:'FAIL',ms:Date.now()-t,error:e.stack});console.log('FAIL',name,e.stack);}}
async function request(identity,cookie,token){return app.inject({url:'/v1/session',headers:{...headers,...(cookie?{cookie}:{}),...(identity?{'x-cvg-operator-token':token??createTrustedOperatorIdentityToken(identity,key)}:{})}});}
async function login(identity=A){const r=await request(identity);assert.equal(r.statusCode,200,r.body);return cookieOf(r);}
async function count(){return (await admin.query(`SELECT (SELECT count(*)::int FROM ${auth}.operator_sessions) AS sessions,(SELECT count(*)::int FROM ${auth}.operator_session_families) AS families,(SELECT count(*)::int FROM ${auth}.operator_session_families WHERE revoked_at IS NULL) AS live`)).rows[0];}
async function oldValid(cookie){const r=await request(null,cookie);assert.equal(r.statusCode,200,r.body);assert.deepEqual(r.json().data.identity,A);assert.equal(r.headers['set-cookie'],undefined);assert.ok(await otherStore.get(sid(cookie)));}
async function rejected503(r){assert.equal(r.statusCode,503,r.body);assert.equal(r.json().error.code,'configuration_error');assert.equal(r.headers['set-cookie'],undefined);assert.equal(r.headers['cache-control'],'no-store');assert.doesNotMatch(r.body,/permission denied|operator_session_create|operator_session_revoke|aud0604review/);}
async function retry(cookie,identity=B){const r=await request(identity,cookie);assert.equal(r.statusCode,200,r.body);assert.deepEqual(r.json().data.identity,identity);assert.equal(await store.get(sid(cookie)),null);assert.deepEqual((await otherStore.get(sid(cookieOf(r)))).identity,identity);return r;}
async function waiter(){for(let i=0;i<180;i++){const r=await admin.query('SELECT pid,query,wait_event FROM pg_stat_activity WHERE usename=$1 AND datname=current_database() AND wait_event_type=$2',[session,'Lock']);if(r.rows.length)return r.rows[0];await sleep(20);}throw Error('own lock wait not observed');}
async function blockSessions(){const c=new Client({connectionString:base});await c.connect();clients.push(c);await c.query('BEGIN');await c.query(`LOCK TABLE ${auth}.operator_sessions IN SHARE MODE`);return c;}
await admin.connect();
let topError;
try{
 const db=(await admin.query('SELECT current_database() AS db')).rows[0].db;assert.equal(db,'cvg_aud0604_review');
 for(const role of roles)await admin.query(`CREATE ROLE ${role} LOGIN PASSWORD 'aud0604_review_only' NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE NOREPLICATION NOINHERIT`);
 await admin.query(`CREATE SCHEMA ${data} AUTHORIZATION ${mig}`);
 await admin.query(`ALTER ROLE ${mig} SET search_path=${data}`);
 await admin.query(`ALTER ROLE ${runtime} SET search_path=${data}`);
 const mc=new Client({connectionString:roleUrl(mig)});clients.push(mc);await mc.connect();await runPostgresMigrations(mc,{schemaName:data,createSchema:false});await mc.end();
 await admin.query(`GRANT CREATE ON DATABASE "${db}" TO ${owner}`);
 const oc=new Client({connectionString:roleUrl(owner)});clients.push(oc);await oc.connect();await runOperatorSessionMigrations(oc,auth,data);await grantOperatorSessionFunctions(oc,auth,session);await oc.end();
 await admin.query(`REVOKE CREATE ON DATABASE "${db}" FROM ${owner}`);
 await admin.query(`GRANT USAGE ON SCHEMA ${data} TO ${runtime}`);
 for(const table of TENANT_SCHEMA_TABLES)await admin.query(`GRANT SELECT,INSERT,UPDATE ON ${data}.${table} TO ${runtime}`);
 await admin.query(`GRANT SELECT ON ${data}.schema_migrations TO ${runtime}`);
 await admin.query(`GRANT SELECT,INSERT,UPDATE,DELETE ON ${data}.webhook_replay_events,${data}.rate_limit_buckets TO ${runtime}`);
 const env={NODE_ENV:'production',API_PERSISTENCE_MODE:'postgres',DATABASE_URL:roleUrl(runtime),DATABASE_MIGRATION_URL:roleUrl(mig),POSTGRES_SCHEMA:data,POSTGRES_RLS_ENFORCEMENT:'true',POSTGRES_AUTO_MIGRATE:'false',OUTBOX_DURABLE_INBOUND:'true',CVG_IDENTITY_MODE:'trusted',CVG_OPERATOR_IDENTITY_KEYRING:JSON.stringify({current:key}),CVG_OPERATOR_SESSION_DATABASE_URL:roleUrl(session),CVG_OPERATOR_AUTH_SCHEMA:auth,CVG_OPERATOR_SESSION_ROLE:session,CVG_RATE_LIMIT_KEYRING:JSON.stringify({budgetSecret:'review-synthetic-budget-secret-0123456789',current:{keyId:'review-rate',secret:'review-synthetic-rate-secret-0123456789'}}),INBOUND_TENANT_ID:A.tenantId,INBOUND_AGENT_ID:'agent_22222222-2222-4222-8222-222222222222',WEBHOOK_SIGNING_SECRET:'review-synthetic-webhook-secret-0123456789',API_ALLOWED_ORIGINS:headers.origin,API_REQUIRE_HTTPS:'true',API_TRUSTED_PROXY_ADDRESSES:'127.0.0.1',API_TRUSTED_PROXY_HOPS:'0'};
 app=await buildApiWithProductionSessions(env,{operatorIdentityResolver:createConfiguredOperatorIdentityResolver(env)});apps.push(app);
 const pool=createPostgresOperatorSessionPool(roleUrl(session));pool.on('error',()=>{});pools.push(pool);store=new PostgresOperatorSessionStore(pool,auth);
 const otherPool=createPostgresOperatorSessionPool(roleUrl(session));otherPool.on('error',()=>{});pools.push(otherPool);otherStore=new PostgresOperatorSessionStore(otherPool,auth);
 await writeFile(out+'/resume-fixture.json',JSON.stringify({candidate:'5111ad60cbaac49ddbec028a6733be2b51611836',prefix,data,auth,roles,node:process.version,db,pg:(await admin.query('SELECT version() AS v')).rows[0].v,poolOptions:{max:pool.options.max,query_timeout:pool.options.query_timeout,statement_timeout:pool.options.statement_timeout,connectionTimeoutMillis:pool.options.connectionTimeoutMillis}},null,2)+'\n');
 await record('minimal-serving-roles-and-no-direct-auth-DML',async()=>{
  const attrs=(await admin.query('SELECT rolname,rolsuper,rolbypassrls,rolcreatedb,rolcreaterole,rolreplication,rolinherit FROM pg_roles WHERE rolname=ANY($1)',[roles])).rows;
  for(const r of attrs)for(const field of ['rolsuper','rolbypassrls','rolcreatedb','rolcreaterole','rolreplication','rolinherit'])assert.equal(r[field],false);
  const sc=new Client({connectionString:roleUrl(session)});clients.push(sc);await sc.connect();
  for(const sql of [`SELECT * FROM ${auth}.operator_sessions`,`UPDATE ${auth}.operator_session_families SET revoked_at=now()`,`SELECT * FROM ${data}.tasks`])await assert.rejects(sc.query(sql),e=>e.code==='42501');
  const rc=new Client({connectionString:roleUrl(runtime)});clients.push(rc);await rc.connect();await assert.rejects(rc.query(`SELECT * FROM ${auth}.operator_session_get($1)`,[randomBytes(32)]),e=>e.code==='42501');
  return {roles:attrs,sessionDmlDenied:true,runtimeAuthDenied:true,pool:pool.options.max};
 });
 for(const signature of [revokeSig,createSig])await record('503-rollback-permission-'+signature.split('(')[0],async()=>{
  const cookie=await login();const before=await count();await admin.query(`REVOKE EXECUTE ON FUNCTION ${auth}.${signature} FROM ${session}`);
  try{const response=await request(B,cookie);await rejected503(response);await oldValid(cookie);assert.deepEqual(await count(),before);}finally{await admin.query(`GRANT EXECUTE ON FUNCTION ${auth}.${signature} TO ${session}`);}
  const after=await retry(cookie);return {status:503,cookieUnchanged:true,oldValid:true,noRowsLeaked:true,retryStatus:after.statusCode};
 });
 await record('create-partial-insert-error-rolls-back-revoke-and-new-family',async()=>{
  const cookie=await login();const before=await count();
  await admin.query(`CREATE FUNCTION ${auth}.review_insert_fault() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN IF NEW.operator_id='review.synthetic.b' THEN RAISE EXCEPTION 'synthetic INSERT fault' USING ERRCODE='23514'; END IF; RETURN NEW; END $$`);
  await admin.query(`CREATE TRIGGER review_insert_fault BEFORE INSERT ON ${auth}.operator_sessions FOR EACH ROW EXECUTE FUNCTION ${auth}.review_insert_fault()`);
  try{await rejected503(await request(B,cookie));await oldValid(cookie);assert.deepEqual(await count(),before);}finally{await admin.query(`DROP TRIGGER review_insert_fault ON ${auth}.operator_sessions`);await admin.query(`DROP FUNCTION ${auth}.review_insert_fault()`);}
  await retry(cookie);return {oldValid:true,noPartialFamily:true,retryStatus:200};
 });
 await record('COMMIT-rejected-by-deferred-constraint-before-ack-rolls-back',async()=>{
  const cookie=await login();const before=await count();
  await admin.query(`CREATE FUNCTION ${auth}.review_commit_fault() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN IF NEW.operator_id='review.synthetic.b' THEN RAISE EXCEPTION 'synthetic deferred constraint' USING ERRCODE='23514'; END IF; RETURN NEW; END $$`);
  await admin.query(`CREATE CONSTRAINT TRIGGER review_commit_fault AFTER INSERT ON ${auth}.operator_sessions DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION ${auth}.review_commit_fault()`);
  try{await rejected503(await request(B,cookie));await oldValid(cookie);assert.deepEqual(await count(),before);}finally{await admin.query(`DROP TRIGGER review_commit_fault ON ${auth}.operator_sessions`);await admin.query(`DROP FUNCTION ${auth}.review_commit_fault()`);}
  await retry(cookie);return {preAckCommitRejected:true,oldValid:true,retryStatus:200,ambiguousAckNotClaimed:true};
 });
 await record('statement-timeout-after-revoke-uncommitted-no-partial-state',async()=>{
  const cookie=await login();const before=await count();const blocker=await blockSessions();const started=Date.now();let response;let waiting;
  try{const p=request(B,cookie);waiting=await waiter();assert.match(waiting.query,/operator_session_create/);await oldValid(cookie);response=await p;await rejected503(response);assert.ok(Date.now()-started<7500);assert.deepEqual(await count(),before);}finally{await blocker.query('ROLLBACK');await blocker.end();}
  await oldValid(cookie);await retry(cookie);return {waiting,ms:Date.now()-started,oldValidDuringAndAfter:true,noPartialRows:true,retryStatus:200};
 });
 for(const [label,next] of [['operator',B],['role',{...A,role:'Operator'}],['tenant',{...A,tenantId:'tenant_22222222-2222-4222-8222-222222222222'}],['same-identity',A]])await record('predecessor-to-live-successors-switch-'+label,async()=>{
  const predecessor=await login();const rotated=await request(A,predecessor);assert.equal(rotated.statusCode,200,rotated.body);const successor=cookieOf(rotated);
  const rotated2=await request(A,successor);assert.equal(rotated2.statusCode,200,rotated2.body);const successor2=cookieOf(rotated2);
  assert.equal(await store.get(sid(predecessor)),null);assert.equal(await store.get(sid(successor)),null);assert.ok(await store.get(sid(successor2)));
  const changed=await request(next,predecessor);assert.equal(changed.statusCode,200,changed.body);const newCookie=cookieOf(changed);
  for(const c of [predecessor,successor,successor2]){assert.equal(await otherStore.get(sid(c)),null);const p=await app.inject({url:'/v1/tasks',headers:{...headers,cookie:c}});assert.equal(p.statusCode,401,p.body);}
  assert.deepEqual((await request(null,newCookie)).json().data.identity,next);
  const ids=(await admin.query(`SELECT encode(family_id,'hex') AS family FROM ${auth}.operator_sessions WHERE token_digest=ANY($1::bytea[])`,[[digest(sid(predecessor)),digest(sid(newCookie))]])).rows;
  assert.equal(new Set(ids.map(r=>r.family)).size,2);return {oldLinks:3,oldFamilyRevoked:true,newIdentity:next,newFamily:true};
 });
 await record('predecessor-create-failure-preserves-live-successor-and-fresh-retry',async()=>{
  const predecessor=await login();const successor=cookieOf(await request(A,predecessor));const before=await count();await admin.query(`REVOKE EXECUTE ON FUNCTION ${auth}.${createSig} FROM ${session}`);
  try{await rejected503(await request(B,predecessor));await oldValid(successor);assert.deepEqual(await count(),before);}finally{await admin.query(`GRANT EXECUTE ON FUNCTION ${auth}.${createSig} TO ${session}`);}
  await retry(predecessor);assert.equal(await store.get(sid(successor)),null);return {presentedPredecessorStaysInvalid:true,successorPreserved:true,retryRetiresSuccessor:true};
 });
 await record('retry-identical-bootstrap-token-observation',async()=>{
  const cookie=await login();const token=createTrustedOperatorIdentityToken(B,key);await admin.query(`REVOKE EXECUTE ON FUNCTION ${auth}.${createSig} FROM ${session}`);
  try{await rejected503(await request(B,cookie,token));}finally{await admin.query(`GRANT EXECUTE ON FUNCTION ${auth}.${createSig} TO ${session}`);}
  const reused=await request(B,cookie,token);await oldValid(cookie);await retry(cookie);
  return {sameTokenStatus:reused.statusCode,sameTokenError:reused.json().error,freshTokenStatus:200,note:'Bootstrap is one-use; fresh authenticated retry works; no same-token retry guarantee inferred.'};
 });
 await record('logout-predecessor-revokes-family-and-503-preserves-cookie',async()=>{
  const c=await login();const successor=cookieOf(await request(A,c));await admin.query(`REVOKE EXECUTE ON FUNCTION ${auth}.${revokeSig} FROM ${session}`);
  try{const r=await app.inject({method:'POST',url:'/v1/session/logout',headers:{...headers,cookie:c}});await rejected503(r);await oldValid(successor);}finally{await admin.query(`GRANT EXECUTE ON FUNCTION ${auth}.${revokeSig} TO ${session}`);}
  const r=await app.inject({method:'POST',url:'/v1/session/logout',headers:{...headers,cookie:c}});assert.equal(r.statusCode,200,r.body);assert.match(String(r.headers['set-cookie']),/Max-Age=0/);assert.equal(await store.get(sid(successor)),null);return {failureCookieUnchanged:true,successorRevoked:true};
 });
 await record('no-simulation-tenant-role-escalation-with-cookie',async()=>{
  const i={...A,role:'Operator'};const c=await login(i);const r=await app.inject({url:'/v1/session',headers:{...headers,cookie:c,'x-cvg-tenant-id':'tenant_22222222-2222-4222-8222-222222222222','x-cvg-operator-role':'Admin','x-cvg-operator-id':'attacker.synthetic'}});assert.equal(r.statusCode,200,r.body);assert.deepEqual(r.json().data.identity,i);const denied=await app.inject({url:'/v1/admin/agents',headers:{...headers,cookie:c,'x-cvg-operator-role':'Admin'}});assert.equal(denied.statusCode,403,denied.body);return {identity:i,adminRouteStatus:denied.statusCode};
 });
 await record('pool-exhaustion-acquisition-bounded-and-recovery',async()=>{
  const cookie=await login();const acquired=[];const before=await count();const started=Date.now();try{for(let i=0;i<10;i++)acquired.push(await pool.connect());await assert.rejects(store.switchIdentity(sid(cookie),{identity:B,expiresAt:Date.now()+120000}));assert.ok(Date.now()-started<5000);assert.deepEqual(await count(),before);}finally{acquired.forEach(c=>c.release());}await oldValid(cookie);await retry(cookie);return {max:10,ms:Date.now()-started,noRowsLeaked:true,retryStatus:200};
 });
 await record('wrong-port-fails-bounded-without-mutation',async()=>{
  const u=new URL(roleUrl(session));u.port='1';const bad=createPostgresOperatorSessionPool(u.toString());bad.on('error',()=>{});pools.push(bad);const s=new PostgresOperatorSessionStore(bad,auth);const before=await count();const t=Date.now();await assert.rejects(s.switchIdentity('opsess_'+randomBytes(32).toString('base64url'),{identity:B,expiresAt:Date.now()+120000}));assert.ok(Date.now()-t<5000);assert.deepEqual(await count(),before);await bad.end();return {syntheticPort:1,ms:Date.now()-t,noMutation:true};
 });
}catch(e){topError=e.stack;console.log('TOP_ERROR',topError);}
finally{
 const cleanup=[];
 for(const a of apps){try{await a.close();}catch(e){cleanup.push('app: '+e.message);}}
 for(const p of pools){try{await p.end();}catch(e){if(!/Called end/.test(e.message))cleanup.push('pool: '+e.message);}}
 for(const c of clients){try{await c.end();}catch(e){cleanup.push('client: '+e.message);}}
 try{const n=(await admin.query('SELECT pid,usename,state,xact_start FROM pg_stat_activity WHERE usename=ANY($1)',[roles])).rows;assert.equal(n.length,0);results.push({name:'own-serving-resources-closed',status:'PASS',detail:{activeOwnConnections:n}});}catch(e){cleanup.push(e.message);}
 for(const schema of [auth,data])try{await admin.query(`DROP SCHEMA IF EXISTS ${schema} CASCADE`);}catch(e){cleanup.push('schema: '+e.message);}
 for(const role of roles)try{await admin.query(`DROP OWNED BY ${role}`);await admin.query(`DROP ROLE IF EXISTS ${role}`);}catch(e){cleanup.push('role: '+e.message);}
 let residual;try{residual={schemas:(await admin.query('SELECT nspname FROM pg_namespace WHERE nspname=ANY($1)',[[auth,data]])).rows,roles:(await admin.query('SELECT rolname FROM pg_roles WHERE rolname=ANY($1)',[roles])).rows};}catch(e){cleanup.push(e.message);}
 await admin.end();await writeFile(out+'/results.json',JSON.stringify({candidate:'5111ad60cbaac49ddbec028a6733be2b51611836',base:'9b85d5b',observedAt:new Date().toISOString(),results,topError,cleanupErrors:cleanup,residual},null,2)+'\n');
 console.log('FINISH',JSON.stringify({pass:results.filter(r=>r.status==='PASS').length,fail:results.filter(r=>r.status==='FAIL').length,topError,cleanup,residual}));
 if(topError||cleanup.length||results.some(r=>r.status==='FAIL'))process.exitCode=1;
}
