import {readFile, readdir, access} from 'node:fs/promises';
import {pathToFileURL, fileURLToPath} from 'node:url';
import ts from '/tmp/cvg-aud0604-20261006/candidate/node_modules/typescript/lib/typescript.js';
const root='/tmp/cvg-aud0604-20261006/candidate';
const packages=new Map();
for(const base of ['packages','apps','legacy/packages','products']) {
 for(const dir of await readdir(root+'/'+base)) {
  try {const j=JSON.parse(await readFile(root+'/'+base+'/'+dir+'/package.json','utf8'));
   packages.set(j.name,pathToFileURL(root+'/'+base+'/'+dir+'/src/index.ts').href);
  } catch {}
 }
}
export async function resolve(spec,ctx,next) {
 if(packages.has(spec)) return {url:packages.get(spec),shortCircuit:true};
 if((spec.startsWith('.')||spec.startsWith('/')) && spec.endsWith('.js')) {
  const u=new URL(spec,ctx.parentURL); const p=fileURLToPath(u);
  try {await access(p);}catch {try {await access(p.slice(0,-3)+'.ts');return {url:pathToFileURL(p.slice(0,-3)+'.ts').href,shortCircuit:true};}catch {}}
 }
 if(ctx.parentURL?.startsWith('file:///tmp/cvg-aud0604-20261006/session-reviewer/')&&!spec.startsWith('.')&&!spec.startsWith('/')&&!spec.startsWith('node:'))
  return next(spec,{...ctx,parentURL:pathToFileURL(root+'/package.json').href});
 return next(spec,ctx);
}
export async function load(url,ctx,next) {
 if(url.endsWith('.ts')) {
  const source=await readFile(fileURLToPath(url),'utf8');
  return {format:'module',source:ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText,shortCircuit:true};
 }
 return next(url,ctx);
}
