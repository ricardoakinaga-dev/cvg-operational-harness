import pg from '/tmp/cvg-aud0604-20261006/candidate/node_modules/pg/lib/index.js';
const {Client}=pg;
import {readFile,writeFile} from 'node:fs/promises';
const path=process.argv[2];const fixture=JSON.parse(await readFile(path,'utf8'));
const names=[fixture.auth,fixture.data,...fixture.roles];for(const n of names)if(!/^aud0604review_[a-z0-9_]+$/.test(n))throw Error('not own resource');
const c=new Client({connectionString:'postgres://postgres:synthetic-aud0604-local@127.0.0.1:55726/cvg_aud0604_review'});await c.connect();
try{
 const ownConnections=(await c.query('SELECT pid,usename,state FROM pg_stat_activity WHERE usename=ANY($1)',[fixture.roles])).rows;
 if(ownConnections.length)throw Error('own process connections remain '+JSON.stringify(ownConnections));
 const before=(await c.query(`SELECT (SELECT count(*)::int FROM ${fixture.auth}.operator_sessions) sessions,(SELECT count(*)::int FROM ${fixture.auth}.operator_session_families WHERE revoked_at IS NULL) live`)).rows[0];
 for(const s of [fixture.auth,fixture.data])await c.query(`DROP SCHEMA IF EXISTS ${s} CASCADE`);
 for(const r of fixture.roles){await c.query(`DROP OWNED BY ${r}`);await c.query(`DROP ROLE IF EXISTS ${r}`);}
 const residual=(await c.query('SELECT nspname FROM pg_namespace WHERE nspname=ANY($1)',[[fixture.auth,fixture.data]])).rows;
 const summary={fixture:path,before,ownConnections,residual,closedAt:new Date().toISOString()};
 await writeFile(path+'.cleanup.json',JSON.stringify(summary,null,2)+'\n');console.log(JSON.stringify(summary));
}finally{await c.end();}
