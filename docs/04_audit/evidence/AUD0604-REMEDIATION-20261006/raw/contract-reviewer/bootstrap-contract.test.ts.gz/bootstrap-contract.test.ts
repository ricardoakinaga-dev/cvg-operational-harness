// @vitest-environment node
// This rejection happens before pool allocation: never accesses PostgreSQL.
import { expect, it } from 'vitest'
import { createProductionOperatorSessionBootstrap } from '/tmp/cvg-aud0604-20261006/candidate/apps/api/src/production-bootstrap.ts'
it('SPEC0144 serving environment without DDL credential is rejected by the current bootstrap',async()=>{
  await expect(createProductionOperatorSessionBootstrap({
    NODE_ENV:'production',
    DATABASE_URL:'postgresql://runtime:synthetic@127.0.0.1/db',
    POSTGRES_SCHEMA:'data',
    CVG_OPERATOR_SESSION_DATABASE_URL:'postgresql://sessions:synthetic@127.0.0.1/db',
    CVG_OPERATOR_SESSION_ROLE:'sessions',
    CVG_OPERATOR_AUTH_SCHEMA:'auth'
  })).rejects.toThrow('DATABASE_MIGRATION_URL is required for production bootstrap')
})
