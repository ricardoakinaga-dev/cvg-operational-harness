// @vitest-environment node
// Fake store proves route calls only, never PostgreSQL atomicity or rollback.
import { afterEach, describe, expect, it, vi } from 'vitest'
import { buildServer } from '/tmp/cvg-aud0604-20261006/candidate/apps/api/src/server.ts'
import { createTrustedOperatorIdentityResolver, createTrustedOperatorIdentityToken } from '/tmp/cvg-aud0604-20261006/candidate/apps/api/src/operator-identity.ts'
import { createInMemoryOperatorSessionStore } from '/tmp/cvg-aud0604-20261006/candidate/apps/api/src/operator-session.ts'

const key = 'contract-reviewer-synthetic-only-secret-0123456789'
const identity = {operatorId:'review.synthetic', role:'Supervisor' as const, tenantId:'tenant_11111111-1111-4111-8111-111111111111'}
const activeId = 'opsess_active_synthetic_cookie'
const staleId = 'opsess_predecessor_synthetic_cookie'
const expiresAt = () => Date.now()+120000
const cookie = (id:string) => `cvg_operator_session=${encodeURIComponent(id)}`
const apps:ReturnType<typeof buildServer>[]=[]
afterEach(async()=>{ await Promise.all(apps.splice(0).map(a=>a.close())); vi.unstubAllEnvs() })
function fixture({live=true, fault='', replay=true}={}) {
  const mutation = {create:vi.fn(), replace:vi.fn(), switchIdentity:vi.fn(), revoke:vi.fn()}
  const returned=(input:any)=>({sessionId:'opsess_new_synthetic_cookie', ...input})
  mutation.create.mockImplementation(async(input:any)=>{if(fault==='create') throw new Error('fake-secret'); return returned(input)})
  for(const name of ['replace','switchIdentity'] as const)
    mutation[name].mockImplementation(async(_id:string,input:any)=>{if(fault===name) throw new Error('fake-secret'); return returned(input)})
  mutation.revoke.mockImplementation(async()=>{if(fault==='revoke')throw new Error('fake-secret')})
  const get=vi.fn(async(id:string)=>{if(fault==='get')throw new Error('fake-secret');return live&&id===activeId?{sessionId:id,identity,expiresAt:expiresAt()}:null})
  const claim=vi.fn(async()=>replay)
  const app=buildServer({identityMode:'trusted',operatorSessionStore:{...mutation,get},operatorIdentityResolver:createTrustedOperatorIdentityResolver({secret:key}),tokenReplayStore:{claim}})
  apps.push(app)
  const request=(inputIdentity=identity,id:string|undefined=activeId,raw?:string)=>app.inject({url:'/v1/session',headers:{...(id?{cookie:cookie(id)}:{}),'x-cvg-operator-token':raw??createTrustedOperatorIdentityToken(inputIdentity,key,Date.now,120)}})
  return {app,mutation,get,claim,request}
}
function expectOnly(m:any,name:string){for(const key of Object.keys(m))expect(m[key].mock.calls.length,key).toBe(key===name?1:0)}
describe('independent route calls: fake store, no PG',()=>{
  it('active same identity selects replace, never switch/create/revoke',async()=>{const f=fixture();expect((await f.request()).statusCode).toBe(200);expectOnly(f.mutation,'replace');expect(f.mutation.replace.mock.calls[0][0]).toBe(activeId)})
  it.each(['operatorId','role','tenantId'])('changed %s selects switch',async(field)=>{const next={...identity,[field]:field==='role'?'Admin':field==='tenantId'?'tenant_22222222-2222-4222-8222-222222222222':'other.synthetic'};const f=fixture();const r=await f.request(next as any);expect(r.statusCode).toBe(200);expectOnly(f.mutation,'switchIdentity');expect(f.mutation.switchIdentity.mock.calls[0][0]).toBe(activeId);expect(r.json().data.identity).toEqual(next)})
  it('predecessor get=null selects switch using raw cookie but derives identity solely from validated token',async()=>{const f=fixture();const next={...identity,role:'Operator' as const};const r=await f.app.inject({url:'/v1/session',headers:{cookie:cookie(staleId),'x-cvg-operator-token':createTrustedOperatorIdentityToken(next,key,Date.now,120),'x-operator-role':'Admin','x-tenant-id':'tenant_22222222-2222-4222-8222-222222222222'}});expect(r.statusCode).toBe(200);expectOnly(f.mutation,'switchIdentity');expect(f.mutation.switchIdentity.mock.calls[0][0]).toBe(staleId);expect(r.json().data.identity).toEqual(next)})
  it('unknown syntactically valid cookie selects switch without claiming it authenticates',async()=>{const f=fixture();expect((await f.request(identity,'unknown_synthetic_cookie')).statusCode).toBe(200);expectOnly(f.mutation,'switchIdentity')})
  it('no cookie selects create',async()=>{const f=fixture();const r=await f.app.inject({url:'/v1/session',headers:{'x-cvg-operator-token':createTrustedOperatorIdentityToken(identity,key,Date.now,120)}});expect(r.statusCode).toBe(200);expectOnly(f.mutation,'create')})
  it('active cookie without token restores identity without effect',async()=>{const f=fixture();const r=await f.app.inject({url:'/v1/session',headers:{cookie:cookie(activeId)}});expect(r.statusCode).toBe(200);expect(r.json().data.identity).toEqual(identity);expect(r.headers['set-cookie']).toBeUndefined();for(const m of Object.values(f.mutation))expect(m).not.toHaveBeenCalled();expect(f.claim).not.toHaveBeenCalled()})
  it.each(['missing','bad-signature','expired'])('%s token plus predecessor has no session/replay mutation',async(kind)=>{const f=fixture();const raw=kind==='expired'?createTrustedOperatorIdentityToken(identity,key,()=>Date.now()-300000,120):kind==='bad-signature'?createTrustedOperatorIdentityToken(identity,'different-synthetic-signing-key-0123456789',Date.now,120):undefined;const r=await f.app.inject({url:'/v1/session',headers:{cookie:cookie(staleId),...(raw?{'x-cvg-operator-token':raw}:{})}});expect(r.statusCode).toBe(401);for(const m of Object.values(f.mutation))expect(m).not.toHaveBeenCalled();expect(f.claim).not.toHaveBeenCalled();expect(r.json()).not.toHaveProperty('data.identity')})
  it('distributed replay rejection prevents switch',async()=>{const f=fixture({replay:false});expect((await f.request(identity,staleId)).statusCode).toBe(401);expect(f.claim).toHaveBeenCalledTimes(1);for(const m of Object.values(f.mutation))expect(m).not.toHaveBeenCalled()})
  it.each(['replace','switchIdentity','create'])('%s rejection is redacted 503 with no Set-Cookie',async(name)=>{const f=fixture({fault:name});const r=name==='create'?await f.app.inject({url:'/v1/session',headers:{'x-cvg-operator-token':createTrustedOperatorIdentityToken(identity,key,Date.now,120)}}):await f.request(identity,name==='switchIdentity'?staleId:activeId);expect(r.statusCode).toBe(503);expect(r.headers['set-cookie']).toBeUndefined();expect(r.headers['cache-control']).toBe('no-store');expect(r.body).not.toContain('fake-secret');expectOnly(f.mutation,name)})
  it('lookup fault plus valid token blocks writes and preserves cookie',async()=>{const f=fixture({fault:'get'});const r=await f.request();expect(r.statusCode).toBe(503);expect(r.headers['set-cookie']).toBeUndefined();for(const m of Object.values(f.mutation))expect(m).not.toHaveBeenCalled()})
  it('logout revoke rejection preserves cookie',async()=>{const f=fixture({fault:'revoke'});const r=await f.app.inject({method:'POST',url:'/v1/session/logout',headers:{cookie:cookie(staleId)}});expect(r.statusCode).toBe(503);expect(r.headers['set-cookie']).toBeUndefined();expectOnly(f.mutation,'revoke')})
  it.each(['Operator','Approver','Supervisor','Admin'])('valid %s identity survives cookie roundtrip in real in-memory store',async(role)=>{const next={...identity,role};const app=buildServer({identityMode:'trusted',operatorSessionStore:createInMemoryOperatorSessionStore(),operatorIdentityResolver:createTrustedOperatorIdentityResolver({secret:key})});apps.push(app);const r=await app.inject({url:'/v1/session',headers:{'x-cvg-operator-token':createTrustedOperatorIdentityToken(next as any,key,Date.now,120)}});expect(r.statusCode).toBe(200);const c=String(r.headers['set-cookie']);expect(c).toContain('HttpOnly');expect(c).toContain('SameSite=Strict');const reload=await app.inject({url:'/v1/session',headers:{cookie:c.split(';')[0]}});expect(reload.statusCode).toBe(200);expect(reload.json().data.identity).toEqual(next)})
  it('non-atomic fallback can revoke then fail create; documents only its injected-store limit',async()=>{const backing=createInMemoryOperatorSessionStore();const old=await backing.create({identity,expiresAt:expiresAt()});const app=buildServer({identityMode:'trusted',operatorSessionStore:{...backing,create:async()=>{throw new Error('fake-create-fault')}},operatorIdentityResolver:createTrustedOperatorIdentityResolver({secret:key})});apps.push(app);const r=await app.inject({url:'/v1/session',headers:{cookie:cookie(old.sessionId),'x-cvg-operator-token':createTrustedOperatorIdentityToken({...identity,role:'Admin'},key,Date.now,120)}});expect(r.statusCode).toBe(503);expect(r.headers['set-cookie']).toBeUndefined();expect(await backing.get(old.sessionId)).toBeNull()})
})
