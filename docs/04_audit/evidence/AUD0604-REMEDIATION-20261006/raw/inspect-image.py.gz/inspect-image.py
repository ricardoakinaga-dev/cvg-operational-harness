import subprocess,json,tarfile,hashlib
from pathlib import Path,PurePosixPath
b=Path('/tmp/cvg-aud0604-20261006');image='cvg-operational-harness:aud0604-5111ad6'
probe="""const fs=require('fs');let appWrite;try{fs.writeFileSync('/app/aud0604-probe','synthetic');appWrite='WRITABLE'}catch(e){appWrite=e.code};console.log(JSON.stringify({node:process.version,uid:process.getuid(),gid:process.getgid(),api:fs.existsSync('/app/apps/api/dist/main.js'),worker:fs.existsSync('/app/apps/worker/dist/main.js'),healthcheck:fs.existsSync('/app/scripts/runtime-healthcheck.mjs'),shells:['/bin/sh','/bin/bash','/bin/dash','/usr/bin/sh','/usr/bin/bash'].filter(x=>fs.existsSync(x)),packageManagers:['/usr/bin/apt','/usr/bin/apt-get','/usr/local/bin/npm','/usr/bin/npm'].filter(x=>fs.existsSync(x)),appWrite}));"""
raw=subprocess.check_output(['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges',image,'node','-e',probe]);d=json.loads(raw);assert d['uid']==10001 and d['gid']==10001 and d['api'] and d['worker'] and d['healthcheck'] and not d['shells'] and not d['packageManagers'] and d['appWrite']=='EROFS'
info=json.loads(subprocess.check_output(['docker','image','inspect',image]))[0];d['imageId']=info['Id'];d['image']=image;d['healthcheckConfig']=info['Config']['Healthcheck'];(b/'image-inspection.json').write_text(json.dumps(d,indent=2)+'\n')
name='cvg-aud0604-image-scan-20261006';subprocess.run(['docker','create','--name',name,'--network','none',image],check=True,stdout=subprocess.DEVNULL)
try:
 with (b/'image.tar').open('wb') as f:subprocess.run(['docker','export',name],check=True,stdout=f)
finally:subprocess.run(['docker','rm',name],check=True,stdout=subprocess.DEVNULL)
dest=b/'image-filesystem';dest.mkdir(exist_ok=True);count=0
with tarfile.open(b/'image.tar') as t:
 for m in t:
  path=PurePosixPath(m.name)
  if not m.isfile() or path.is_absolute() or '..' in path.parts:continue
  p=dest/path;p.parent.mkdir(parents=True,exist_ok=True)
  with p.open('wb') as f:f.write(t.extractfile(m).read())
  count+=1
scope={'image':image,'imageId':info['Id'],'regularFilesExtracted':count,'extractor':'relative regular files only; symlinks excluded','gitleaks':'8.28.0 default rules including node_modules exclusion'};(b/'image-scan-scope.json').write_text(json.dumps(scope,indent=2)+'\n')
print(json.dumps(d));print('Regular image files extracted:',count)
