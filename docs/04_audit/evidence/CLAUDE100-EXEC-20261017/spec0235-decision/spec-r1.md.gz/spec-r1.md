# SPEC0235 — Probe contido da porta nativa do Claude

Task `C100-Q01-REF-PORT-001`, vinculada a C100-Q01/G04, preparação18/10/2026.
Trilha **T3**, segurança/identidade de execução e observação do cliente nativo.
Estado `DRAFT_FOR_INDEPENDENT_REVIEW / HUMAN_T3_REVIEW_PENDING / BUILD_NOT_AUTHORIZED`.

## Problema e vínculo com o programa

[PRD0029](../01_prd/0029_claude100_initial_qualification.md) exige captura real
da referência e M1. O mecanismo [0229](0229_claude100_initial_qualification.md)
está qualificado localmente; nenhum cliente Claude com prompt foi executado
por ele. A aprovação0229 exclui um driver presumidamente keyless. Este contrato
propõe descobrir uma porta local observando o binário real sob contenção, com
uma resposta HTTP de erro finita; não pressupõe que ele aceite essa configuração.

O [recon](../04_audit/evidence/CLAUDE100-EXEC-20261017/reference-driver-recon/README.md)
confirmou os mesmos bytes2.1.302 e encontrou configurações de origem HTTP.
A ajuda capturada declara `--bare`, `--print`, `--tools ""`, configuração MCP
estrita, settings explícitas e saída JSON. Declaração e strings não provam uso
da porta, autenticação aceita, isolamento ou ausência de efeitos.

Este probe não compara CVG, não fornece modelo, não responde semanticamente ao
prompt e não produz uma captura funcional apta ao comparador. O resultado
pretendido é uma observação verificável de POST nativo ao endpoint esperado,
ou um resultado honesto de porta não observada/bloqueio/infraestrutura.

## Escopo e pré-condições

Após aprovação humana desta SPEC exata, implementar somente
`tests/claude100/reference-port/**` e `scripts/claude100-reference-port.mjs` em
candidata própria. Sem root package/lock, instalação, atualização do Claude,
mudança em runtime/SDK/provider, produto, policy/approval ou schema público.
Reusar parser estrito/canonicalização já qualificados; não copiar normalizador.
Erro primário e cleanup devem permanecer na mesma cadeia de causas.

Antes de executar o alvo: kitQ03 e mecanismo0229 qualificados; suporteQ04
qualificado no mesmo conjunto de fontes se seu helper for importado; código do
probe congelado e revisto independentemente. Nenhuma execução nativa com prompt
antes de aprovação T3 e dessa revisão de código. Testes unitários do controlador
podem usar respostas Docker falsas declaradas; controles positivos de contenção
e porta exigem observações reais dos contêineres e do binário selecionado.

## Identidades fixas desta unidade

Os hashes foram lidos de arquivos selecionados, sem executar o Claude.
[Inventário](../04_audit/evidence/CLAUDE100-EXEC-20261017/reference-driver-recon/toolchain-static.json).

| Papel                   | Caminho/identidade                                                        | SHA-256                                                            |
| ----------------------- | ------------------------------------------------------------------------- | ------------------------------------------------------------------ |
| Claude2.1.302           | `/home/ricardo/.local/share/claude/versions/2.1.302`                      | `60d7eb7f12fbb28a52533fe8be5884097403562aa02dc73991a021c7067e29a5` |
| Node22.23.2             | `/home/ricardo/.nvm/versions/node/v22.23.2/bin/node`                      | `3517c2df0b2f8cd7f422b4b8450ef81c6889f08eb03e281d6de9079b15e6a327` |
| Docker CLI              | `/usr/bin/docker`                                                         | `7ed12b00293d64742419a6601ae97960a367a0ce97c88b06e3278cc0a409557b` |
| Imagem pública já local | `sha256:f1c3376c26f2609ab9f29f71f824103fe2fcd8ee0346485cb6122a4f93df6f94` | ID de conteúdo Docker, sem pull                                    |

Compatibilidade ELF/Node com a imagem não foi executada. Ausência, hash diferente
ou dependência incompatível bloqueia a execução; não baixar imagem, biblioteca,
engine ou nova versão automaticamente. Nenhum Ghidra/IDA/Hopper é requerido para
o probe. IDs, caminhos, perfil ou binário diferentes exigem revisão do contrato.

## Contenção e separação do coletor

Dois contêineres efêmeros próprios, criados por IDs novos com labels da task e
runId; comandos `execFile` com argv fixo, sem shell. O observador usa Node,
rede `none` e HTTP127.0.0.1:porta0. O cliente compartilha somente a rede do
observador (`container:<ID próprio>`), preservando PID/IPC/mount namespaces
separados. Não publicar portas ou conectar bridge/host/overlay.

A documentação descreve rede `none` com apenas loopback e compartilhamento de
pilha por `container:`; isso orienta o desenho, não prova a estação.
[Docker none](https://docs.docker.com/engine/network/drivers/none/),
[container networks](https://docs.docker.com/engine/network/#container-networks).

Ambos: UID/GID1000:1000, rootfs somente leitura, `cap-drop=ALL`, no-new-privileges,
sem privileged/devices extras/docker socket/host PID ou IPC; cgroupns private.
PidsLimit64, nofile256,
CPU1 por contêiner; cliente768MiB e observador192MiB. Scratch/tmp são tmpfs
privados com limite agregado128MiB, nosuid/nodev/noexec, UID/GID1000 e modo0700.
Somente binários aprovados, bundle estático do probe/helpers e fixtures
sintéticas entram por mounts readonly. Nada do perfil real, repositório inteiro,
secret store, config real, workspace de outro agente ou saída host RW é montado.

O observador e o cliente iniciam primeiro wrappers Node confiáveis, sem iniciar
o Claude. O host confere os Docker inspect reais (IDs, labels, imagem, mounts,
User, recursos, readonly, CapDrop, SecurityOpt e namespaces) e preflight real dos
wrappers: UID, PID1, inodes PID distintos, inode de rede igual, interfaces/rotas
somente loopback e ausência de marcador sintético host que não foi montado.
Sem testes TCP contra destinos externos. Configuração impossível, campo ausente
ou divergente dá `BLOCKED_CONTAINMENT`; não usar fallback host/bridge.

O host só envia a mensagem literal `START_NATIVE` ao wrapper do cliente depois
dessas verificações. Observador fica em outro namespace PID e não compartilha
diretórios ou stdout com o Claude. Request observado vem do callback HTTP desse
coletor protegido, não de texto impresso pelo alvo. O host captura pipes
separados do observador e cliente e escreve evidências fora dos mounts deles.

O controlador usa Docker local via unix socket preexistente e configDir vazio
próprio, com imagem local e pull=never. Não herdar contextos remotos, login helpers
ou credenciais. Criação/inspect/start/stop/remove somente dos IDs criados por
esta execução e conferidos pelos labels; nunca listas globais ou nome parcial.
O nome usa prefixo da task/role e16hex de hash(runId+nonce), abaixo de64bytes;
IDs e nonce não vêm do cliente. Hashes e stat dos binários são conferidos antes
da criação e depois do encerramento, mantendo handles durante a observação.
Drift invalida o resultado; isso não é atestação criptográfica da imagem carregada
nem proteção contra alteração host maliciosa entre as duas leituras.

## Entrada, ambiente e invocação fechados

CLI: `--manifest`, `--evidence-root`, `--out`, cada uma obrigatória uma vez,
sem posicionais. Manifesto JSON fechado: `{version:1,runId,fixtureId}`;
fixtureId literal `NATIVE_PORT_503_V1`, runId ASCII alfanumérico/underscore/hífen
de1–64caracteres. Arquivo64KiB, JSON estrito UTF-8/profundidade16/string4KiB,
sem duplicatas/campos extras. Não aceitar comando, módulo, URL, imagem, perfil,
credencial, diretório de mount ou prompt vindo do manifesto.

O input semântico único é o texto literal `CVG_SYNTHETIC_NATIVE_PORT_PROBE_V1`,
fornecido por stdin fechado após os bytes. Workspace sintético contém apenas
settings `{}` e MCP `{"mcpServers":{}}`, readonly; cwd `/workspace`. Wrappers
passam ao alvo env construído explicitamente: PATH da imagem, LANG=C.UTF-8,
TZ=UTC, HOME/CLAUDE_CONFIG_DIR sob scratch e ANTHROPIC_BASE_URL calculada como
`http://127.0.0.1:<porta observada>`. ANTHROPIC_API_KEY é somente o literal
`cvg-synthetic-native-probe-v1`. Sem spread/snapshot de env host no cliente,
sem OAuth, helper de chave, tokens/cookies reais ou proxy env.

Args nativos fixos: `--bare --print --output-format json --tools ""`
`--no-session-persistence --strict-mcp-config --mcp-config /workspace/mcp.json`
`--settings /workspace/settings.json --setting-sources ""`. Strings vazias são
elementos argv reais. Não usar skip-permissions ou flags não declaradas.
No máximo duas execuções sequenciais do binário: primeiro `--version` deve
confirmar2.1.302; depois o probe. Nenhum comando impresso pelo alvo é executado.

## Observação HTTP e limites

O observador responde sempre503 com JSON de erro sintético fixo, sem redirect,
modelo, upstream, proxy ou handler controlado por dados. Limites:4requests,
512KiB por body/2MiB total, headers8KiB, stdout e stderr nativos1MiB cada,
artefatos agregados8MiB. Sem truncar e declarar completo; cap excedido termina
como falha explícita. Nenhuma compressão é descomprimida nesta unidade.

Antes de persistir body, conferir auth: somente x-api-key com o sentinel exato,
ou ausência de auth em requests não elegíveis a prova; outro auth/token/cookie
descarta body/valores e registra apenas uma violação não sensível. Auth nunca é
persistida. Requests elegíveis precisam POST, pathname `/v1/messages`, query
vazia ou exatamente `beta=true`, sentinel verificado e body dentro do limite.
Outras rotas recebem o mesmo erro finito, com pathname classificado como
UNSUPPORTED_PATH e sem gravar URL/query arbitrários. Nada vira instrução de replay.

O probe registra bytes brutos elegíveis, hashes, ordinal, monotonic timestamps,
content-type/content-encoding classificados e relação temporal com START_NATIVE.
JSON do body só é interpretado pelo parser estrito; formato não reconhecido ou
comprimido permanece opaco/incompleto. A presença do marker é check separado e
nunca é inferida de texto livre. Nenhum POST anterior a START_NATIVE conta.

O sucesso desta unidade requer pelo menos um request elegível observado. A
rejeição503 é deliberada: exit/status/stdout do cliente são registrados como
observados, não convertidos em execução funcional bem-sucedida. Falta de porta,
auth recusada antes do request, erro de compatibilidade ou timeout mantém o
estado real; não procurar credencial real ou modificar o executável para passar.

Prazo20s para o cliente,30s total do controlador, cleanup separado≤5s. SIGTERM
seguido de SIGKILL/stop próprio em prazo finito, sem repetir efeito incerto ou
matar processo alheio. Cancelamento também fecha observador, sockets, timers e
ambos IDs próprios; erro primário e todos erros de cleanup ficam acessíveis.

## Resultado e autoridade

Saída exclusiva nova sob evidence-root privado próprio; negar traversal,
symlink/arquivo especial e overwrite. Mantém brutos parciais como falha,
inventário de hashes e relatório fechado. Nenhum arquivo host de saída entra
no cliente/observador. Resultado parcial não pode aparecer como relatório
publicado, usando protocolo de publicação após IO/cleanup qualificados.

Reportv1 fechado: version, runId, fixtureId, verificationClass literal
REFERENCE_RECON_ONLY, status, exitCode, toolchainDigests, driverSha256,
profileSha256, containmentChecks, observations, nativeExecution, artifacts,
limitations, reviewStatus literalPENDING. status enum PORT_OBSERVED,
PORT_NOT_OBSERVED, BLOCKED_CONTAINMENT, INVALID_INPUT ou INFRA_FAILURE;
exit0somentePORT_OBSERVED, demais1, usoCLIinválido2. Sem campo PASS_CURRENT,
índice de confiança ou recibo funcional compatível com0229.

toolchainDigests tem somente expected e observed; cada um contém claudeSha256,
nodeSha256,dockerSha256,imageId. expected são os valores fixos acima, observed
são digest/ID conferidos ou null se ainda indisponíveis. driverSha256 e
profileSha256 são digests ou null se não calculáveis. runId e fixtureId podem
ser null somente na rejeição de input; verificationClass permanece fixa.
containmentChecks são `{id,status:PASS|FAIL|NOT_RUN,message≤512}`; observations
são `{ordinal,method,path,bodySha256,bytes,markerVerified,encodingKnown,offsetMs}`:
ordinal0–3, method literalPOST, path literal/v1/messages, digest/bytes de body
elegível0–512KiB, booleans e offsetMs inteiro0–35000. Contagem de rota/auth
rejeitadas fica em checks sem valores sensíveis. nativeExecution tem somente
versionObserved (2.1.302ou null), versionProbe e portProbe, cada probe com
startedAt/endedAt UTCou null se não iniciado, exitCode inteiro0–255ou null,
timeoutboolean e signalSIGTERM/SIGKILLou null. Não inferir código do nativo de
texto livre ou do código de saída do wrapper; se não observado, fica null com
limitação. artifacts são `{path,sha256,bytes}`, preservando a ordem; brutos
nunca executados. Limitations não vazia inclui porta-only/erro503 deliberado,
SDK/protocolo ainda não qualificados e nenhum resultado de paridade.

Falha de manifesto/entrada/hash/cap de input→INVALID_INPUT; preflight ausente/divergente→
BLOCKED_CONTAINMENT antes do alvo; falha de toolchain/IO/cleanup/limite de
execução/cap durante observação→INFRA_FAILURE; execução íntegra sem POSTelegível→PORT_NOT_OBSERVED;
somente observação íntegra sob todos controles→PORT_OBSERVED. Checks posteriores
ficam NOT_RUN. Nenhum relatório autoriza M1 ou fecha requisito do catálogo.

## Aceites congelados para futura implementação

| ID   | Critério rejeitável                                                      | Prova necessária                                                                                                         |
| ---- | ------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------ |
| NP01 | Inputs/identidades/caps fechados; dados não escolhem executável/comando. | Negativos de UTF-8/dup/schema/path/hash e zero Dockercreate antes da validação.                                          |
| NP02 | Perfil real sem hostdata/RW/bridge/privilégio.                           | Docker inspect e preflight reais com hashes, namespaces/rotas/UID/mounts; falha bloqueia antes do Claude.                |
| NP03 | Coletor HTTP separado do PID/filesystem/stdout do alvo.                  | Inodes PID distintos/rede igual e IDs próprios; stdout fake do cliente não cria observation.                             |
| NP04 | Alvo só nasce depois dos controles; env/argv/input exatos.               | Sequência START_NATIVE e negativos semfork; versão/process lineage/caps nativos observados.                              |
| NP05 | Porta é observada ou declarada ausente honestamente.                     | Claude real, bindsource antes/depois, POST503 real; timeout/auth/ELF falham sem credencial ou fallback.                  |
| NP06 | Header/body/output caps e privacidade sem truncamento silencioso.        | Limiteexato/+1, segredo inventado em auth descartado, stdout/route falsos não elegíveis.                                 |
| NP07 | Cleanup preserva causas e não deixa contêiner/socket/processo próprio.   | Cancel/crash/dualfailure com identidade nativa quando viável; IDs/handles após encerramento.                             |
| NP08 | Brutos/hash/publicação reproduzíveis e histórico íntegro.                | Alteração de qualquer insumo, overwrite e erro final de IO/cleanup sem relatório completo enganoso.                      |
| NP09 | Nenhum crédito automático ou conta/modelo real.                          | Catálogo134IDs/classes/hash antes/depois, reportREFERENCE_RECON_ONLY e ausência de índice funcional.                     |
| NP10 | Revisão/gates atuais no mesmo candidato.                                 | Código congelado, crítico independente, tipo/lint/unit/PG/E2E/certifyNode22; revisão humanaT3 desta SPEC antes do BUILD. |

Todos NP são NOT_RUN. Mais do que dois retrabalhos exige diagnóstico/replanejamento
registrado; não reduzir a barra. Revisor de código julga fonte/negativos antes
do primeiro lançamento do alvo. Mudança de binário/toolchain/perfil/API de
observação ou necessidade de acesso real reabre o contrato/gate correspondente.

## Próxima decisão revisável

Preparar parecer documental independente e pacote com SHA-256 desta SPEC.
A decisão solicitável é somente BUILD local e probe nativo contido descritos
aqui, depois das pré-condições. Não inclui M1, resposta de modelo, adapter de
equivalência, serviço/conta remota, dado real, instalação, push, deploy ou release.
Sem decisão humana específica, continuar apenas documentação e trabalho
independente já autorizado, mantendo esta unidade sem código/executável lançado.
