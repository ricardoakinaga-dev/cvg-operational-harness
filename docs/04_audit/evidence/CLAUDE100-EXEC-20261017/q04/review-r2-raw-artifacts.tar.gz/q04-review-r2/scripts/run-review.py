from pathlib import Path
import subprocess,json,time,hashlib,os
own=Path('/tmp/cvg-claude100-exec-20261017/q04-review-r2');old=Path('/tmp/cvg-claude100-exec-20261017/q04-review-r1');candidate=Path('/tmp/cvg-claude100-exec-20261017/q04-candidate');repo=Path('/home/ricardo/Área de trabalho/cvg-operational-harness');node='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node'
env={'HOME':str(own/'home'),'TMPDIR':str(own/'tmp'),'XDG_CONFIG_HOME':str(own/'config'),'XDG_CACHE_HOME':str(own/'cache'),'LANG':'C.UTF-8','TZ':'UTC','PATH':str(Path(node).parent)+':/usr/bin:/bin'}
# Test/assertion logic is unchanged. Only common data/output configuration moves to R2.
for name in ['repro-mf05-causes.mjs','probe-common.mjs','probe-wire.mjs','probe-record.mjs','probe-guard.mjs','probe-http-errors.mjs','probe-lifetime.mjs','probe-persist-r2.mjs']:
 data=(old/'scripts'/name).read_bytes()
 if name=='probe-common.mjs':data=data.replace(str(old).encode(),str(own).encode())
 (own/'scripts'/name).write_bytes(data)
assert (old/'scripts/repro-mf05-causes.mjs').read_bytes()==(own/'scripts/repro-mf05-causes.mjs').read_bytes()
(own/'original-reproducer-copy.json').write_text(json.dumps({'originalPath':str(old/'scripts/repro-mf05-causes.mjs'),'copiedPath':str(own/'scripts/repro-mf05-causes.mjs'),'identicalBytes':True,'sha256':hashlib.sha256((own/'scripts/repro-mf05-causes.mjs').read_bytes()).hexdigest(),'helperChange':'only own output-root constant R1->R2; candidate unchanged; no test/assertion changes'},indent=2)+'\n')
d=json.loads((repo/'docs/04_audit/evidence/CLAUDE100-EXEC-20261017/q04/lead/combined-correction1.json').read_text());files=[r['name'] for r in d['testResults']];files.append(str(candidate/'packages/model-gateway/src/__tests__/local-http-providers.test.ts'))
runner=f'''import {{ startVitest }} from '{candidate}/node_modules/vitest/dist/node.js';
process.chdir('{candidate}');
const context=await startVitest('test',{json.dumps(files)},{{watch:false,fileParallelism:false,maxWorkers:1,reporters:['verbose','json'],outputFile:{{json:'{own}/logs/focal-results.json'}},cache:false,configLoader:'native',testTimeout:15000}},{{cacheDir:'{own}/cache'}});
const failed=context.state.getUnhandledErrors().length||context.state.getFiles().some(f=>f.result?.state==='fail');await context.close();if(failed)process.exitCode=1;
'''
(own/'scripts/run-focal.mjs').write_text(runner)
commands=[]
def run(label,cmd,timeout=30):
 start=time.time()
 with (own/f'logs/{label}.log').open('wb') as f:
  try:r=subprocess.run(cmd,env=env,cwd=candidate if label=='focal' else own,stdout=f,stderr=subprocess.STDOUT,timeout=timeout);code=r.returncode
  except subprocess.TimeoutExpired:code='TIMEOUT'
 row={'label':label,'command':cmd,'exit':code,'elapsedSeconds':time.time()-start,'log':str(own/f'logs/{label}.log')};commands.append(row);(own/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(label,code,flush=True)
run('original-reproducer',[node,str(own/'scripts/repro-mf05-causes.mjs')])
run('focal',[node,str(own/'scripts/run-focal.mjs')],180)
for name in ['wire','record','guard','http-errors','lifetime']:
 run(name,[node,str(own/f'scripts/probe-{name}.mjs')])
# Only own special-file inputs; do not retry the previously denied UID change.
root=own/'tmp/persist-evidence';root.mkdir(mode=0o700);os.mkfifo(root/'fifo.json',0o600);(root/'foreign.json').write_bytes((own/'logs/record-chunked-json.json').read_bytes())
run('persistence',[node,str(own/'scripts/probe-persist-r2.mjs')])
run('static-cause',[node,str(candidate/'tests/support/model-fault-server/cause-probe.js')])
print('DONE',flush=True)
