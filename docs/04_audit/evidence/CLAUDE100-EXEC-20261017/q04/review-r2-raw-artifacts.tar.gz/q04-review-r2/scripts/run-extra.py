from pathlib import Path
import subprocess,json,time
own=Path('/tmp/cvg-claude100-exec-20261017/q04-review-r2');node='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node';env={'HOME':str(own/'home'),'TMPDIR':str(own/'tmp'),'XDG_CONFIG_HOME':str(own/'config'),'XDG_CACHE_HOME':str(own/'cache'),'LANG':'C.UTF-8','TZ':'UTC','PATH':str(Path(node).parent)+':/usr/bin:/bin'};rows=[]
for label in ['multiple-fd','native-listen']:
 cmd=[node,str(own/f'scripts/probe-{label}.mjs')];start=time.time()
 with (own/f'logs/{label}.log').open('wb') as f:r=subprocess.run(cmd,env=env,cwd=own,stdout=f,stderr=subprocess.STDOUT,timeout=20)
 rows.append({'label':label,'command':cmd,'exit':r.returncode,'elapsedSeconds':time.time()-start});print(label,r.returncode,(own/f'logs/{label}.log').read_text()[:2500])
(own/'extra-commands.json').write_text(json.dumps(rows,indent=2)+'\n')
