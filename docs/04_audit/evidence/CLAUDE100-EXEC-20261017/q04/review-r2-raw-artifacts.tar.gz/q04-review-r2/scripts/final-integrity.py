from pathlib import Path
import json,hashlib,subprocess,datetime,stat
own=Path('/tmp/cvg-claude100-exec-20261017/q04-review-r2');old=Path('/tmp/cvg-claude100-exec-20261017/q04-review-r1');c=Path('/tmp/cvg-claude100-exec-20261017/q04-candidate');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=json.loads((own/'pins-before.json').read_text())
for x in rows:x['actualAfter']=sha(Path(x['path']));x['matchAfter']=x['actualAfter']==x['expected']
(own/'pins-after.json').write_text(json.dumps(rows,indent=2)+'\n');assert all(x['matchAfter'] for x in rows)
base=json.loads((own/'candidate-source-before.json').read_text());after={p:sha(c/p) for p in base};changes=[p for p,h in base.items() if after[p]!=h];(own/'candidate-source-after.json').write_text(json.dumps(after,indent=2)+'\n');assert not changes
status=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=c);(own/'candidate-git-after.txt').write_bytes(status);assert status==(own/'candidate-git-before.txt').read_bytes()
q1=json.loads((old/'approved-Q01-source-before.json').read_text());assert sha(Path(q1['authorityPacket']))==q1['packetSha256']
for x in q1['sources']:x['actualR2']=sha(Path(x['path']));x['matchR2']=x['actualR2']==x['expected']
assert all(x['matchR2'] for x in q1['sources']);(own/'approved-Q01-source-preservation.json').write_text(json.dumps(q1,indent=2)+'\n')
q3=json.loads((old/'Q03-qualified-archive-before.json').read_text())
for x in q3['files']:x['actualR2']=sha(Path(x['path']));x['matchR2']=x['actualR2']==x['expected']
assert all(x['matchR2'] for x in q3['files']);(own/'qualified-Q03-archive-preservation.json').write_text(json.dumps(q3,indent=2)+'\n')
r1=json.loads((old/'raw-content-manifest.json').read_text());n=0
for x in r1['files']:
 if x['kind']=='file':assert sha(old/x['path'])==x['sha256'];n+=1
(own/'R1-archive-preservation.json').write_text(json.dumps({'oldRawRoot':str(old),'regularRawFilesMatchOriginalManifest':n,'oldArchiveHashInPins':True,'originalRedScriptByteExact':(own/'scripts/repro-mf05-causes.mjs').read_bytes()==(old/'scripts/repro-mf05-causes.mjs').read_bytes(),'oldAreasWritten':False},indent=2)+'\n')
report={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'packetPins':23,'expandedPinOccurrences':len(rows),'allPinsMatch':True,'candidateFilesUnchanged':len(after),'candidateGitStatusUnchanged':True,'approvedQ01SourcesMatch':len(q1['sources']),'Q03ArchivedEvidenceFilesMatch':len(q3['files']),'R1RawFilesMatch':n,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=c).decode().strip(),'sourceWrites':0,'commits':0,'descendantAgents':0}
(own/'final-integrity.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
