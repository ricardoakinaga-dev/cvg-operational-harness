import assert from 'node:assert/strict';
import http from 'node:http';
import {writeFile} from 'node:fs/promises';
import {api,own,planFor,exchange,idle,serialError,pause} from './probe-common.mjs';
const contains=(e,t)=>e===t||Boolean(e?.cause&&contains(e.cause,t))||Boolean(e?.errors&&[...e.errors].some(x=>contains(x,t)));
const p=planFor();const server=await api.createModelFaultServer(p);const realHead=http.ServerResponse.prototype.writeHead;const realClose=http.Server.prototype.close;
const syntheticCleanup=Object.assign(new Error('CVG_SYNTHETIC_CLOSE_FAULT'),{code:'CVG_FAKE_ECLOSE'});let nativePrimary,nativeClosed=false;
http.ServerResponse.prototype.writeHead=function(_status,...args){try{return realHead.call(this,-1,...args)}catch(e){nativePrimary=e;throw e}};
let returned;
try{
 await exchange(server,p);await idle(server);http.ServerResponse.prototype.writeHead=realHead;
 http.Server.prototype.close=function(callback){return realClose.call(this,error=>{nativeClosed=!error;callback(error??syntheticCleanup)})};
 try{await server.close()}catch(e){returned=e}
}finally{http.ServerResponse.prototype.writeHead=realHead;http.Server.prototype.close=realClose}
assert.equal(nativePrimary.code,'ERR_HTTP_INVALID_STATUS_CODE');assert.ok(nativeClosed);assert.ok(returned instanceof AggregateError);assert.equal(returned.cause,returned.errors[0]);assert.ok(contains(returned.errors[0],nativePrimary));assert.ok(contains(returned.errors[1],syntheticCleanup));assert.equal(contains(returned.errors[0],syntheticCleanup),false);
assert.equal(server.state().closed,true);assert.equal(server.state().sockets,0);assert.equal(server.state().timers,0);assert.equal(server.state().active,0);
const result={nativePrimary:serialError(nativePrimary),syntheticCleanup:serialError(syntheticCleanup),returned:serialError(returned),realNativeCloseCompleted:nativeClosed,recursivePrimaryIdentityPreserved:true,recursiveCleanupIdentityPreserved:true,stablePrimaryThenCleanupOrder:true,state:server.state(),limit:'Cleanup callback error is explicitly synthetic after successful actual native closure, not an OS HTTP-close failure.'};await writeFile(`${own}/logs/http-causal-order-observations.json`,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({probe:'actual-http-lifecycle-causal-order',recursiveCauseIdentityAndOrder:true,realNativeCloseCompleted:true,zeroOwnedResourceCounts:true}));
