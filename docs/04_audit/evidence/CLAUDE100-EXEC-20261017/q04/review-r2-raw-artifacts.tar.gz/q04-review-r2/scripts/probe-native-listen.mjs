import assert from 'node:assert/strict';
import http from 'node:http';
import {writeFile} from 'node:fs/promises';
import {api,own,pause,planFor,serialError} from './probe-common.mjs';
const blocker=http.createServer();await new Promise(r=>blocker.listen(0,'127.0.0.1',r));
const port=blocker.address().port;const realListen=http.Server.prototype.listen;let nativeError,candidateServer;
http.Server.prototype.listen=function(_port,host,callback){candidateServer=this;this.once('error',e=>nativeError=e);return realListen.call(this,port,host,callback)};
let returned;
try{await api.createModelFaultServer(planFor())}catch(e){returned=e}finally{http.Server.prototype.listen=realListen;await new Promise((r,j)=>blocker.close(e=>e?j(e):r()))}
assert.equal(nativeError?.code,'EADDRINUSE');assert.equal(returned?.cause,nativeError);assert.equal(returned.message,'synthetic listen failed');assert.equal(candidateServer.listening,false);
await pause(25);const extraServers=process._getActiveHandles().filter(x=>x instanceof http.Server);assert.equal(extraServers.length,0);
const result={probe:'native-listen-failure',nativeError:serialError(nativeError),returned:serialError(returned),exactCauseIdentityRetained:true,extraNativeServers:extraServers.length,boundary:'Real EADDRINUSE at an own occupied loopback port initially allocated as port0; no other session ports used; original native listen delegated.'};
await writeFile(`${own}/logs/native-listen-observations.json`,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
