import assert from 'node:assert/strict';
import fsp from 'node:fs/promises';
import {closeSync} from 'node:fs';
import {syncBuiltinESMExports} from 'node:module';
const realOpen=fsp.open;let phase=null;let handles=[];let nativeWrite=null;let nativeCloses=[];
fsp.open=async(...args)=>{
 const h=await realOpen(...args);if(!phase)return h;
 handles.push({h,path:String(args[0])});
 const realClose=h.close.bind(h);h.close=async()=>{try{return await realClose()}catch(e){nativeCloses.push({fd:h.fd,error:e});throw e}};
 if(String(args[0]).endsWith('/multiple.json')){
  const victims=handles.slice(-3);assert.equal(victims[0].path.endsWith(phase.rootName),true);assert.equal(victims[1].path.endsWith('/nested'),true);
  const invalidate=()=>{for(const {h:fd} of victims)closeSync(fd.fd)};
  if(phase.mode==='primary-and-cleanup'){
   const write=h.writeFile.bind(h);h.writeFile=async(...values)=>{invalidate();try{return await write(...values)}catch(e){nativeWrite=e;throw e}};
  }else{
   const sync=h.sync.bind(h);h.sync=async()=>{await sync();invalidate()};
  }
 }
 return h;
};syncBuiltinESMExports();
const {api,own,serialError}=await import('./probe-common.mjs');
const recording=JSON.parse(await fsp.readFile(`${own}/logs/record-chunked-json.json`,'utf8'));
const results=[];
for(const mode of ['primary-and-cleanup','cleanup-only']){
 const root=await fsp.mkdtemp(`${own}/tmp/multi-fd-`);await fsp.mkdir(`${root}/nested`,{mode:0o700});
 handles=[];nativeWrite=null;nativeCloses=[];phase={mode,rootName:root.split('/').at(-1)};let returned;
 try{await api.persistSyntheticRecording(recording,{evidenceRoot:root,path:'nested/multiple.json',mode:'record',previousDigest:null})}catch(e){returned=e}finally{phase=null}
 assert.equal(nativeCloses.length,3);assert.deepEqual(nativeCloses.map(x=>[x.error.code,x.error.syscall]),Array.from({length:3},()=>['EBADF','close']));
 let cleanup;
 if(mode==='primary-and-cleanup'){
  assert.equal(nativeWrite.code,'EBADF');assert.equal(returned.cause,returned.errors[0]);assert.equal(returned.errors[0].cause,nativeWrite);cleanup=returned.errors[1];
 }else cleanup=returned;
 assert.ok(cleanup instanceof AggregateError);assert.equal(cleanup.errors.length,3);assert.deepEqual(cleanup.errors.map(x=>x.cause),nativeCloses.map(x=>x.error));
 results.push({mode,nativeWrite:serialError(nativeWrite),nativeCloseCauses:nativeCloses.map(x=>serialError(x.error)),returned:serialError(returned),stableReverseFdCleanupOrder:true,allActualCauseIdentitiesRetained:true});
}
await fsp.writeFile(`${own}/logs/multiple-fd-observations.json`,JSON.stringify({results,injection:'Only own newly created output/nested/root FDs are invalidated. All write/close failures are real native EBADF. Transparent observation rethrows the original object. Cleanup-only invalidates after successful native fsync.'},null,2)+'\n');console.log(JSON.stringify({probe:'multiple-real-FD-close-causes',cases:results.length,realCloseErrorsPerCase:3,allCauseIdentitiesAndOrderPreserved:true}));
