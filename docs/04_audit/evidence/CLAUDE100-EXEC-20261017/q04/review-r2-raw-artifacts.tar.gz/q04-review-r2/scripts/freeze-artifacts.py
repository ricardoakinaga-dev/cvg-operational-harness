from pathlib import Path
import os,stat,json,hashlib,tarfile,datetime
own=Path('/tmp/cvg-claude100-exec-20261017/q04-review-r2');dest=Path('/home/ricardo/Área de trabalho/cvg-operational-harness/docs/04_audit/evidence/CLAUDE100-EXEC-20261017/q04/review-r2');archive=own/'raw-review-r2-artifacts.tar.gz';manifest=own/'raw-content-manifest.json';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not archive.exists() and not manifest.exists()
v=json.loads((dest/'verdict.json').read_text());assert v['verdict']=='APPROVE_SCOPED_IMPLEMENTATION' and not v['blockingFindings'] and len(v['resolvedFindings'])==2
assert (dest/'report.md').read_bytes()==(own/'review-report-snapshot.md').read_bytes();assert (dest/'verdict.json').read_bytes()==(own/'review-verdict-snapshot.json').read_bytes()
items=sorted(own.rglob('*'),key=lambda p:str(p.relative_to(own)));rows=[]
for p in items:
 s=p.lstat();rel=str(p.relative_to(own))
 if stat.S_ISREG(s.st_mode):os.chmod(p,0o444);rows.append({'path':rel,'kind':'file','bytes':s.st_size,'sha256':sha(p)})
 elif stat.S_ISLNK(s.st_mode):rows.append({'path':rel,'kind':'symlink','target':os.readlink(p)})
 elif stat.S_ISFIFO(s.st_mode):rows.append({'path':rel,'kind':'fifo','note':'own negative special-file fixture, no content read'})
 elif stat.S_ISDIR(s.st_mode):rows.append({'path':rel,'kind':'directory'})
 else:raise RuntimeError('unexpected artifact type')
manifest.write_text(json.dumps({'schemaVersion':1,'root':str(own),'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':rows,'excludes':['raw-content-manifest.json (self)','raw-review-r2-artifacts.tar.gz (container)'],'meaning':'Frozen regular-file content hashes; synthetic fixtures only; symlink/FIFO metadata recorded without following/reading.'},indent=2)+'\n');os.chmod(manifest,0o444)
with tarfile.open(archive,'w:gz',compresslevel=6,dereference=False) as tf:
 for p in items+[manifest]:tf.add(p,arcname='q04-review-r2/'+str(p.relative_to(own)),recursive=False)
os.chmod(archive,0o444)
with tarfile.open(archive,'r:gz') as tf:
 names=tf.getnames()
 for row in rows:
  if row['kind']=='file':assert hashlib.sha256(tf.extractfile('q04-review-r2/'+row['path']).read()).hexdigest()==row['sha256']
meta={'path':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'memberCount':len(names),'regularFiles':sum(x['kind']=='file' for x in rows)+1,'contentManifest':{'path':str(manifest),'sha256':sha(manifest)},'contents':['Byte-identical original red reproducer and relocated output configuration; copied prior observers preserved with their disclosed shallow-metadata limitations','New native multi-FD primary/cleanup-only and native loopback listen probes plus live recursive HTTP causal-identity/order assertions','Full614/614 zero-skip exact test stdout and machine JSON, focal lint/format logs, all14commands/results','Seven record/replay wire recordings, actual callback timings/termination, guard/descriptor/auth/hidden-prompt/tamper and lifecycle reports','Synthetic canonical/noncanonical history, TOCTOU, symlink/hardlink/FIFO/private-directory inputs and native error outputs','9frozen source files and unchanged SPEC snapshot;42before/after pins,38104file source baselines/gitstatus,35Q01source and161Q03archive hash verification, sealedR1preservationproof','Report/verdict snapshots and current review/integrity/freezing scripts'],'verified':'Every regular archive member content hash checked against standalone manifest; raw regular files chmod0444','rawArtifactPolicy':'Raw artifacts remain only in new reviewer tmp root. Lead may preserve this sealed archive later; old areas readonly.','sourceIntegrity':v['integrity'],'reviewDocumentHashes':{'verdict.json':sha(dest/'verdict.json'),'report.md':sha(dest/'report.md')}}
(dest/'raw-artifacts.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps({k:meta[k] for k in ['path','sha256','bytes','memberCount','regularFiles']},indent=2))
