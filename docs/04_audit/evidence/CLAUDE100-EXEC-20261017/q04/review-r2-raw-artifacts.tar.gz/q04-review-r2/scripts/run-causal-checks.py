from pathlib import Path
import subprocess,json,time
own=Path('/tmp/cvg-claude100-exec-20261017/q04-review-r2');candidate=Path('/tmp/cvg-claude100-exec-20261017/q04-candidate');node='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node';env={'HOME':str(own/'home'),'TMPDIR':str(own/'tmp'),'XDG_CONFIG_HOME':str(own/'config'),'XDG_CACHE_HOME':str(own/'cache'),'LANG':'C.UTF-8','TZ':'UTC','PATH':str(Path(node).parent)+':/usr/bin:/bin'};rows=[]
for label,cmd,cwd in [('http-causal-order',[node,str(own/'scripts/probe-http-causal-order.mjs')],own),('focal-lint',[node,str(candidate/'node_modules/eslint/bin/eslint.js'),'tests/support/model-fault-server','tests/model-fault-server.test.ts'],candidate),('focal-format',[node,str(candidate/'node_modules/prettier/bin/prettier.cjs'),'--check','tests/support/model-fault-server','tests/model-fault-server.test.ts'],candidate)]:
 start=time.time()
 with (own/f'logs/{label}.log').open('wb') as f:r=subprocess.run(cmd,env=env,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=30)
 rows.append({'label':label,'command':cmd,'cwd':str(cwd),'exit':r.returncode,'seconds':time.time()-start});print(label,r.returncode,(own/f'logs/{label}.log').read_text()[:800])
(own/'causal-check-commands.json').write_text(json.dumps(rows,indent=2)+'\n')
