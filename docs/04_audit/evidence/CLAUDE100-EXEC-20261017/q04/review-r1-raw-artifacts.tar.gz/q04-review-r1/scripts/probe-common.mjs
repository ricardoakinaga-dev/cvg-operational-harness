import assert from 'node:assert/strict';
import http from 'node:http';
import net from 'node:net';
import { performance } from 'node:perf_hooks';
export const candidate='/tmp/cvg-claude100-exec-20261017/q04-candidate';
export const own='/tmp/cvg-claude100-exec-20261017/q04-review-r1';
export const kit=await import(`${candidate}/tests/support/governed-test-kit/index.js`);
export const api=await import(`${candidate}/tests/support/model-fault-server/index.js`);
export const contract=await import(`${candidate}/tests/support/model-fault-server/contract.js`);
export const planFor=(scenario='ok-json',chunkDelayMs=0)=>({version:1,suiteId:'critic-r1',caseId:'critic-case',scenario,maxRequests:1,chunkDelayMs});
export const pause=ms=>new Promise(r=>setTimeout(r,ms));
export async function idle(s){for(let i=0;i<1000&&s.state().active;i++)await pause(1);assert.equal(s.state().active,0);}
export function serialError(e){return e?{name:e.name,message:e.message,code:e.code??null,syscall:e.syscall??null,cause:e.cause?serialError(e.cause):null,...(e.errors?{errors:[...e.errors].map(serialError)}:{})}:null;}
export async function exchange(s,p,{body=contract.expectedRequestBytes(p),headers={},abortAfterMs=0}={}){
 return new Promise((resolve,reject)=>{const parts=[];const events=[];let status=0,complete=false;const started=performance.now();
 const c=http.request(`${s.url}/chat/completions`,{method:'POST',agent:false,headers:{'content-type':'application/json',...headers}},r=>{status=r.statusCode;r.on('data',b=>{parts.push(b);events.push({atMs:performance.now()-started,base64:b.toString('base64')});});r.on('end',()=>complete=true);r.on('error',e=>events.push({error:e.code}));r.on('close',()=>done());});
 const deadline=setTimeout(()=>{c.destroy();done();},abortAfterMs||1000);let finished=false;const done=()=>{if(finished)return;finished=true;clearTimeout(deadline);resolve({status,complete,bytes:Buffer.concat(parts).toString('base64'),events,elapsedMs:performance.now()-started});};
 c.on('error',e=>{events.push({error:e.code});done();});c.end(body);
 });
}
export async function raw(s,headers,body){return new Promise((resolve,reject)=>{const buffers=[];const sock=net.connect(Number(new URL(s.url).port),'127.0.0.1',()=>sock.end(`POST /chat/completions HTTP/1.1\r\nHost: 127.0.0.1\r\nContent-Type: application/json\r\n${headers}Content-Length: ${body.length}\r\nConnection: close\r\n\r\n${body}`));sock.on('data',b=>buffers.push(b));sock.on('error',reject);const deadline=setTimeout(()=>{sock.destroy();reject(new Error('own raw timeout'));},2000);sock.on('close',()=>{clearTimeout(deadline);resolve(Buffer.concat(buffers).toString());});});}
