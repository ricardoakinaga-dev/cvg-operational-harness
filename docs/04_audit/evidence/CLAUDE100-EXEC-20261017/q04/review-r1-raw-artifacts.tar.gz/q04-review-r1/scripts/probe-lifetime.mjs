import assert from 'node:assert/strict';
import net from 'node:net';
import {performance} from 'node:perf_hooks';
import {writeFile} from 'node:fs/promises';
import {api,own,planFor,exchange,pause,serialError} from './probe-common.mjs';
const baseline=process._getActiveHandles().filter(h=>!([process.stdout,process.stderr,process.stdin].includes(h)));
const results=[];
const noListener=s=>new Promise(resolve=>{const x=net.connect(Number(new URL(s.url).port),'127.0.0.1');x.on('connect',()=>{x.destroy();resolve(false)});x.on('error',e=>resolve(e.code==='ECONNREFUSED'))});
{
 const p=planFor('timeout');const s=await api.createModelFaultServer(p,{mode:'record'});const start=performance.now();
 const sock=net.connect(Number(new URL(s.url).port),'127.0.0.1');sock.on('error',()=>{});const bytes=Buffer.from(JSON.stringify({model:'cvg-synthetic-model-v1',messages:[{role:'user',content:'CVG_SYNTHETIC_REQUEST:critic-case'}],temperature:0,max_tokens:32,stream:false}));
 await new Promise(r=>sock.once('connect',r));sock.write(`POST /chat/completions HTTP/1.1\r\nHost: synthetic\r\nContent-Type: application/json\r\nContent-Length: ${bytes.length}\r\n\r\n`);sock.write(bytes);
 await new Promise(r=>sock.once('close',r));await s.close();const duration=performance.now()-start;assert.ok(duration>=4800&&duration<5700);assert.equal(s.recording().termination,'timeout');assert.equal(s.state().active,0);assert.equal(s.state().timers,0);assert.equal(s.state().sockets,0);assert.equal(await noListener(s),true);
 results.push({case:'own-lifetime-timeout-record',durationMs:duration,state:s.state(),recording:s.recording(),listenerRefused:true});
}
{
 const p=planFor('ok-json');const s=await api.createModelFaultServer(p);const sock=net.connect(Number(new URL(s.url).port),'127.0.0.1');sock.on('error',()=>{});await new Promise(r=>sock.once('connect',r));sock.write('POST /chat/completions HTTP/1.1\r\nHost: synthetic\r\nContent-Type: application/json\r\nContent-Length: 500\r\n\r\n{');
 while(s.state().requests===0)await pause(1);const close=s.close();assert.equal(close,s.close());await close;await pause(10);assert.equal(s.state().active,0);assert.equal(s.state().sockets,0);assert.equal(s.state().timers,0);assert.equal(await noListener(s),true);assert.throws(()=>s.recording());results.push({case:'close-incomplete-body',state:s.state(),listenerRefused:true});
}
{
 const p=planFor('chunked-json',100);const s=await api.createModelFaultServer(p,{mode:'record'});const pending=exchange(s,p);while(s.state().requests===0)await pause(1);await pause(15);const started=performance.now();let error;const first=s.close();assert.equal(first,s.close());try{await first}catch(e){error=e}const wire=await pending;assert.ok(error);assert.equal(s.state().active,0);assert.equal(s.state().sockets,0);assert.equal(s.state().timers,0);assert.equal(await noListener(s),true);assert.throws(()=>s.recording());results.push({case:'close-pending-write-delay',closeMs:performance.now()-started,error:serialError(error),wire,state:s.state(),listenerRefused:true});
}
await pause(30);const extra=process._getActiveHandles().filter(h=>!baseline.includes(h)&&!([process.stdout,process.stderr,process.stdin].includes(h)));
assert.equal(extra.length,0);
await writeFile(`${own}/logs/lifetime-observations.json`,JSON.stringify({results,extraNativeHandles:extra.map(x=>x.constructor.name)},null,2)+'\n');console.log(JSON.stringify({probe:'native-lifetime-and-cancel',cases:results.map(x=>x.case),extraNativeHandles:extra.length}));
