// Repeatable regression reproducer. Only own temporary files and loopback HTTP.
// Exit 1 means the frozen candidate violates MF05 cause preservation.
import assert from 'node:assert/strict';
import http from 'node:http';
import fsp from 'node:fs/promises';
import {closeSync} from 'node:fs';
import {syncBuiltinESMExports} from 'node:module';
const realOpen=fsp.open;let inject=false;const originals=[];
fsp.open=async(...args)=>{const h=await realOpen(...args);if(inject&&String(args[0]).endsWith('/dual.json')){closeSync(h.fd);for(const method of ['writeFile','close']){const real=h[method].bind(h);h[method]=async(...a)=>{try{return await real(...a)}catch(error){originals.push({method,error});throw error}}}}return h};
syncBuiltinESMExports();
const {api,kit,own,planFor,exchange,idle,serialError}=await import('./probe-common.mjs');
const contains=(e,target)=>e===target||(e?.cause?contains(e.cause,target):false)||(e?.errors?[...e.errors].some(x=>contains(x,target)):false);
const checks=[];const p=planFor();
const s=await api.createModelFaultServer(p,{mode:'record'});await exchange(s,p);await idle(s);const recording=s.recording();await s.close();
const root=await fsp.mkdtemp(`${own}/tmp/repro-mf05-`);inject=true;let returned;
try{await api.persistSyntheticRecording(recording,{evidenceRoot:root,path:'dual.json',mode:'record',previousDigest:null})}catch(error){returned=error}finally{inject=false}
assert.deepEqual(originals.map(x=>x.error.code),['EBADF','EBADF']);
checks.push({name:'real-write-and-FD-close-errors-preserved',pass:originals.every(x=>contains(returned,x.error)),expected:'AggregateError retains native EBADF write and close causes, in primary/cleanup order',native:originals.map(x=>({method:x.method,error:serialError(x.error)})),actual:serialError(returned)});
const faulty=await api.createModelFaultServer(p);const realHead=http.ServerResponse.prototype.writeHead;let handlerError;
http.ServerResponse.prototype.writeHead=function(_status,...args){try{return realHead.call(this,-1,...args)}catch(e){handlerError=e;throw e}};
try{await exchange(faulty,p);await idle(faulty)}finally{http.ServerResponse.prototype.writeHead=realHead}
let closedError;try{await faulty.close()}catch(e){closedError=e}
assert.equal(handlerError.code,'ERR_HTTP_INVALID_STATUS_CODE');
checks.push({name:'real-handler-error-preserved',pass:contains(closedError,handlerError),expected:'close retains the native RangeError cause',native:serialError(handlerError),actual:serialError(closedError),closedState:faulty.state()});
console.log(JSON.stringify({criterion:'MF05',checks,pass:checks.every(x=>x.pass)},null,2));
process.exitCode=checks.every(x=>x.pass)?0:1;
