import assert from 'node:assert/strict';
import http from 'node:http';
import fsp from 'node:fs/promises';
import {syncBuiltinESMExports} from 'node:module';
const realOpen=fsp.open,realListen=http.Server.prototype.listen;
let opens=0,listens=0;
fsp.open=function(...args){opens++;return realOpen.apply(this,args)};
http.Server.prototype.listen=function(...args){listens++;return realListen.apply(this,args)};
syncBuiltinESMExports();
const {api,contract,kit,own,planFor,exchange,idle}=await import('./probe-common.mjs');
const plan=planFor();const s=await api.createModelFaultServer(plan);await exchange(s,plan);await idle(s);const rec=s.recording();await s.close();
let guardCases=0;const before={opens,listens};
for(const name of api.CREDENTIAL_NAMES){process.env[name]='HOSTILE_FAKE';try{
 for(const mode of ['record','refresh']){
 await assert.rejects(api.createModelFaultServer(plan,{mode}),/credential environment blocked/);
 await assert.rejects(api.persistSyntheticRecording(rec,{evidenceRoot:`${own}/tmp/nonexistent-private`,path:'never.json',mode,previousDigest:mode==='record'?null:rec.digest}),/credential environment blocked/);
 guardCases+=2;
 }
}finally{delete process.env[name]}}
assert.deepEqual({opens,listens},before);
const descriptors=[];let getters=0;
for(const [label,mutate]of [
 ['getter',p=>Object.defineProperty(p,'scenario',{enumerable:true,get(){getters++;return'ok-json'}})],
 ['hidden-getter',p=>Object.defineProperty(p,'hidden',{get(){getters++;return 1}})],
 ['setter',p=>Object.defineProperty(p,'caseId',{enumerable:true,set(v){getters++}})],
 ['symbol',p=>{p[Symbol('unknown')]=1;return p}],
 ['unknown-body',p=>({...p,body:'HOSTILE_FAKE'})],
 ['url',p=>({...p,upstream:'https://synthetic.invalid'})],
 ['callback',p=>({...p,handler(){getters++}})],
 ['prototype',p=>Object.assign(Object.create({inherited:1}),p)],
 ['maxRequests+1',p=>({...p,maxRequests:33})],
 ['delay+1',p=>({...p,chunkDelayMs:101})],
 ['id+1',p=>({...p,caseId:'a'.repeat(129)})]
]){await assert.rejects(api.createModelFaultServer(mutate({...plan})));descriptors.push(label);}
for(const [label,options]of [
 ['option-getter',Object.defineProperty({},'mode',{enumerable:true,get(){getters++;return'replay'}})],
 ['snapshot-bypass',{mode:'record',envSnapshot:{}}],
 ['free-recording',{recording:{synthetic:true}}],
 ['option-url',{url:'http://127.0.0.1:1'}],
 ['option-callback',{callback(){getters++}}]
]){await assert.rejects(api.createModelFaultServer(plan,options));descriptors.push(label)}
const bad=structuredClone(rec);Object.defineProperty(bad.chunks[0],'base64',{enumerable:true,get(){getters++;return'YQ=='}});await assert.rejects(api.createModelFaultServer(plan,{recording:bad}));
assert.equal(getters,0);assert.deepEqual({opens,listens},before);
console.log(JSON.stringify({probe:'actual-current-environment-guard-before-resources',credentialNames:api.CREDENTIAL_NAMES.length,negativeCalls:guardCases,newListenCalls:listens-before.listens,newOpenCalls:opens-before.opens,descriptorCases:descriptors,getterExecutions:getters,recordingGetterRejected:true,interposition:'count-only real Server.listen/fs.promises.open via builtin exports; no request/fetch/clock/timer replacement'}));
