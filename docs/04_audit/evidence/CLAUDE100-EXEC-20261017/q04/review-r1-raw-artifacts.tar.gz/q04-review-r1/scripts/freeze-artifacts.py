from pathlib import Path
import os,stat,json,hashlib,tarfile,datetime
own=Path('/tmp/cvg-claude100-exec-20261017/q04-review-r1');dest=Path('/home/ricardo/Área de trabalho/cvg-operational-harness/docs/04_audit/evidence/CLAUDE100-EXEC-20261017/q04/review-r1');archive=own/'raw-review-r1-artifacts.tar.gz';manifest=own/'raw-content-manifest.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not archive.exists() and not manifest.exists()
verdict=json.loads((dest/'verdict.json').read_text());assert verdict['verdict']=='REVISE' and len(verdict['blockingFindings'])==2
assert (dest/'report.md').read_bytes()==(own/'review-report-snapshot.md').read_bytes()
assert (dest/'verdict.json').read_bytes()==(own/'review-verdict-snapshot.json').read_bytes()
q1=json.loads((own/'approved-Q01-source-before.json').read_text());assert sha(Path(q1['authorityPacket']))==q1['packetSha256']
items=sorted(own.rglob('*'),key=lambda p:str(p.relative_to(own)));rows=[]
for p in items:
 s=p.lstat();rel=str(p.relative_to(own))
 if stat.S_ISREG(s.st_mode):
  os.chmod(p,0o444);rows.append({'path':rel,'kind':'file','bytes':s.st_size,'sha256':sha(p)})
 elif stat.S_ISLNK(s.st_mode):rows.append({'path':rel,'kind':'symlink','target':os.readlink(p)})
 elif stat.S_ISFIFO(s.st_mode):rows.append({'path':rel,'kind':'fifo','note':'negative special-file fixture; never read as data'})
 elif stat.S_ISDIR(s.st_mode):rows.append({'path':rel,'kind':'directory'})
 else:raise RuntimeError('unexpected artifact type')
manifest.write_text(json.dumps({'schemaVersion':1,'root':str(own),'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':rows,'excludes':['raw-content-manifest.json (self)','raw-review-r1-artifacts.tar.gz (container)'],'meaning':'Each regular-file content hash frozen after completed execution; symlinks/FIFO metadata only. Raw fixtures are synthetic.'},indent=2)+'\n');os.chmod(manifest,0o444)
with tarfile.open(archive,'w:gz',compresslevel=6,dereference=False) as tf:
 for p in items+[manifest]:tf.add(p,arcname='q04-review-r1/'+str(p.relative_to(own)),recursive=False)
os.chmod(archive,0o444)
with tarfile.open(archive,'r:gz') as tf:
 names=tf.getnames();assert any(x.endswith('/logs/repro-mf05-causes.log') for x in names);assert any(x.endswith('/scripts/probe-persist.mjs') for x in names)
 for row in rows:
  if row['kind']=='file':
   data=tf.extractfile('q04-review-r1/'+row['path']).read();assert hashlib.sha256(data).hexdigest()==row['sha256']
meta={'path':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'memberCount':len(names),'regularFiles':sum(x['kind']=='file' for x in rows)+1,'contentManifest':{'path':str(manifest),'sha256':sha(manifest)},'rawArtifactPolicy':'Raw files stay only in reviewer-owned tmp; Lead may preserve this sealed archive later. This review did not copy raw logs into root evidence.','contents':['All probe/reproducer and review/integrity/freezing scripts, including preserved failed first persistence harness','Complete focal existing-test stdout, standalone builder static child outputs, EXPECTED_RED MF05 causal regression output','Raw synthetic HTTP request/response bytes, seven actual recordings, callback timings/termination and replay observations','Guard/descriptor, filesystem TOCTOU, special-file, canonical-history and lifetime reports plus synthetic inputs','40 before/after pin occurrences,38103-file candidate source baselines/git status,35 approved Q01 source hashes,161 Q03 archive hashes','Exact frozen8source/SPEC snapshots, root report/verdict snapshots, commands/results and harness-error disclosures'],'verified':'Every regular archive member checked against standalone SHA256 content manifest; all raw regular files chmod0444','sourceIntegrity':verdict['integrity'],'reviewDocumentHashes':{'verdict.json':sha(dest/'verdict.json'),'report.md':sha(dest/'report.md')}}
(dest/'raw-artifacts.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps({k:meta[k] for k in ['path','sha256','bytes','memberCount','regularFiles']},indent=2))
