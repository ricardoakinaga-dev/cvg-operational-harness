from pathlib import Path
import json,hashlib,subprocess,datetime
own=Path('/tmp/cvg-claude100-exec-20261017/q04-review-r1');c=Path('/tmp/cvg-claude100-exec-20261017/q04-candidate')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=json.loads((own/'pins-before.json').read_text())
for x in rows:x['actual_after']=sha(Path(x['path']));x['match_after']=x['actual_after']==x['expected']
(own/'pins-after.json').write_text(json.dumps(rows,indent=2)+'\n');assert all(x['match_after'] for x in rows)
base=json.loads((own/'candidate-source-before.json').read_text());after={p:sha(c/p) for p in base};changes=[p for p,h in base.items() if after[p]!=h]
(own/'candidate-source-after.json').write_text(json.dumps(after,indent=2)+'\n');assert not changes
status=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=c);(own/'candidate-git-after.txt').write_bytes(status);assert status==(own/'candidate-git-before.txt').read_bytes()
q1=json.loads((own/'approved-Q01-source-before.json').read_text())
for r in q1['sources']:r['actual_after']=sha(Path(r['path']));r['match_after']=r['actual_after']==r['expected']
assert all(x['match_after'] for x in q1['sources']);(own/'approved-Q01-source-after.json').write_text(json.dumps(q1,indent=2)+'\n')
q3=json.loads((own/'Q03-qualified-archive-before.json').read_text())
for r in q3['files']:r['actual_after']=sha(Path(r['path']));r['match_after']=r['actual_after']==r['expected']
assert all(x['match_after'] for x in q3['files']);(own/'Q03-qualified-archive-after.json').write_text(json.dumps(q3,indent=2)+'\n')
report={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'packetPinOccurrences':len(rows),'allMatch':True,'candidateFilesUnchanged':len(after),'candidateGitStatusUnchanged':True,'approvedQ01SourcesUnchanged':len(q1['sources']),'Q03ArchivedEvidenceFilesUnchanged':len(q3['files']),'qualifiedQ03':'16 gates,38 official verifier artifact hashes (historical qualification remains unchanged)','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=c).decode().strip(),'sourceWrites':0,'commits':0,'descendantAgents':0}
(own/'final-integrity.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
