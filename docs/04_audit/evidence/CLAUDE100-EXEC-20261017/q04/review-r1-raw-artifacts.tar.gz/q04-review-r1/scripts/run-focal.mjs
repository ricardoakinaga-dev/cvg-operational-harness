import { startVitest } from '/tmp/cvg-claude100-exec-20261017/q04-candidate/node_modules/vitest/dist/node.js';
const candidate='/tmp/cvg-claude100-exec-20261017/q04-candidate';
const own='/tmp/cvg-claude100-exec-20261017/q04-review-r1';
process.chdir(candidate);
const filters=['tests/model-fault-server.test.ts','tests/support/governed-test-kit/governed-test-kit.test.ts','tests/conformance/harness-runtimes.conformance.test.ts','tests/consumers-sdk-session.test.ts','packages/model-gateway/src/__tests__/local-http-providers.test.ts'];
const context=await startVitest('test',filters,{watch:false,fileParallelism:false,maxWorkers:1,reporters:['verbose'],cache:false,configLoader:'native',testNamePattern:'^(?!.*actual guarded subprocess).*',testTimeout:15000},{cacheDir:`${own}/cache`});
const failed=context.state.getUnhandledErrors().length || context.state.getFiles().some(f=>f.result?.state==='fail');
await context.close();if(failed)process.exitCode=1;
