import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {api,contract,kit,own,planFor,exchange,idle,raw,serialError} from './probe-common.mjs';
const result=[];
for(const [label,make] of [
 ['ordinary',()=> 'Authorization: Bearer HOSTILE_FAKE\r\n'],
 ['hidden-after-32',()=>Array.from({length:32},(_,i)=>`X-Benign-${i}: 1\r\n`).join('')+'Authorization: Bearer HOSTILE_FAKE\r\n'],
 ['hidden-duplicate',()=> 'Authorization: Bearer cvg-synthetic-token-v1\r\n'+Array.from({length:32},(_,i)=>`X-Benign-${i}: 1\r\n`).join('')+'Authorization: Bearer HOSTILE_FAKE\r\n'],
 ['duplicate-visible',()=> 'Authorization: Bearer cvg-synthetic-token-v1\r\nAuthorization: Bearer HOSTILE_FAKE\r\n']
]){
 const p=planFor(); const s=await api.createModelFaultServer(p,{mode:'record'});
 try {const wire=await raw(s,make(),contract.expectedRequestBytes(p));await idle(s);let rec=null,error=null;try{rec=s.recording()}catch(e){error=serialError(e)}
 result.push({label,responseStatusLine:wire.split('\r\n')[0],history:s.requestHistory(),recordable:!!rec,recordError:error,state:s.state()});
 await writeFile(`${own}/logs/request-${label}.http`, `POST /chat/completions HTTP/1.1\r\nHost: 127.0.0.1\r\nContent-Type: application/json\r\n${make()}Content-Length: ${contract.expectedRequestBytes(p).length}\r\nConnection: close\r\n\r\n${contract.expectedRequestBytes(p)}`);
 await writeFile(`${own}/logs/response-${label}.http`,wire);
 }finally{await s.close();}
}
console.log(JSON.stringify({probe:'auth-header-limits',result},null,2));
const good=contract.expectedRequestBytes(planFor()).toString();
for(const [label,body]of [
 ['duplicate-prompt',good.replace('"messages":','"messages":[{"role":"user","content":"HOSTILE_FAKE"}],"messages":')],
 ['duplicate-stream',good.replace('"stream":false','"stream":true,"stream":false')],
 ['hidden-extra',good.slice(0,-1)+',"metadata":"HOSTILE_FAKE"}'],
 ['canonical-order',kit.canonicalJson(contract.expectedSyntheticRequest(planFor()))],
 ['space',good+' ']
]){const s=await api.createModelFaultServer(planFor(),{mode:'record'});try{const r=await exchange(s,planFor(),{body});await idle(s);assert.equal(r.status,400);assert.equal(s.requestHistory().length,0);assert.throws(()=>s.recording());console.log(JSON.stringify({probe:label,status:r.status,retained:s.requestHistory().length}));}finally{await s.close()}}
