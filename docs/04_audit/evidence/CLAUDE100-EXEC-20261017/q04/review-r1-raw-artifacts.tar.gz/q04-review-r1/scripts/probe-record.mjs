import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {api,contract,kit,own,planFor,exchange,idle} from './probe-common.mjs';
const good=Buffer.from('{"choices":[{"message":{"content":"CVG_SYNTHETIC_OK_á"},"finish_reason":"stop"}],"usage":{"prompt_tokens":3,"completion_tokens":2}}');
const expected={ 'ok-json':good,'rate-limit':Buffer.from('{"error":"CVG_SYNTHETIC_RATE_LIMIT"}'),'timeout':Buffer.alloc(0),'disconnect':good.subarray(0,24),'invalid-json':good.subarray(0,24),'chunked-json':good,'synthetic-sse':Buffer.from('data: {"synthetic":"CVG_SYNTHETIC_EVENT_1"}\n\ndata: [DONE]\n\n') };
const results=[];let recorded;
for(const [scenario,bytes]of Object.entries(expected)){
 const p=planFor(scenario,80); const server=await api.createModelFaultServer(p,{mode:'record'});let rec,wire;
 try{assert.throws(()=>server.recording());wire=await exchange(server,p,{abortAfterMs:scenario==='timeout'?90:1000});await idle(server);rec=server.recording();assert.equal(wire.bytes,bytes.toString('base64'));assert.equal(Buffer.concat(rec.chunks.map(x=>Buffer.from(x.base64,'base64'))).toString('base64'),wire.bytes);assert.equal(rec.termination,scenario==='timeout'?'timeout':scenario==='disconnect'?'disconnect':'complete');if(rec.chunks.length)assert.ok(wire.elapsedMs>=rec.chunks.length*80-15);
 if(scenario==='chunked-json'){assert.equal(rec.chunks.length,2);assert.equal(Buffer.from(rec.chunks[0].base64,'base64').at(-1),0xc3);assert.equal(Buffer.from(rec.chunks[1].base64,'base64')[0],0xa1);recorded=rec;}
 }finally{await server.close();assert.deepEqual({...server.state(),mode:undefined,requests:undefined,rejected:undefined},{...server.state(),mode:undefined,requests:undefined,rejected:undefined});assert.equal(server.state().closed,true);assert.equal(server.state().sockets,0);assert.equal(server.state().timers,0);assert.equal(server.state().active,0);}
 const replay=await api.createModelFaultServer(p,{recording:rec});let again;
 try{again=await exchange(replay,p,{abortAfterMs:scenario==='timeout'?90:1000});await idle(replay);assert.equal(again.bytes,wire.bytes);assert.equal(again.complete,wire.complete);assert.deepEqual(replay.recording(),rec);}finally{await replay.close()}
 results.push({scenario,recording:rec,wire,replay:again,closedState:server.state()});
 await writeFile(`${own}/logs/record-${scenario}.json`,kit.canonicalJson(rec)+'\n');
}
let rejectCount=0;
const p=planFor('chunked-json',80);
for(const [name,change]of [
 ['byte',r=>{r.chunks[0].base64=Buffer.from('HOSTILE_FAKE').toString('base64')}],
 ['delay',r=>{r.chunks[0].delayMs=79}],
 ['ordinal',r=>{r.chunks[1].ordinal=0}],
 ['order',r=>{r.chunks.reverse()}],
 ['missing',r=>{r.chunks.pop()}],
 ['base64-noncanonical',r=>{r.chunks[0].base64+='='}],
 ['header',r=>{r.headers['content-type']='text/event-stream'}],
 ['status',r=>{r.status=429}],
 ['termination',r=>{r.termination='disconnect'}],
 ['request',r=>{r.requestSha256='0'.repeat(64)}],
 ['plan',r=>{r.planSha256='0'.repeat(64)}],
 ['field',r=>{r.extra='HOSTILE_FAKE'}],
 ['synthetic',r=>{r.synthetic=false}]
]){const r=structuredClone(recorded);change(r);delete r.digest;r.digest=kit.jsonDigest(r);await assert.rejects(api.createModelFaultServer(p,{recording:r}));rejectCount++;}
await writeFile(`${own}/logs/record-observations.json`,JSON.stringify({results,rehashedTamperRejected:rejectCount},null,2)+'\n');
console.log(JSON.stringify({probe:'independent-record-wire-and-replay',scenarios:results.length,rehashedTamperRejected:rejectCount,delays:'scheduled80ms, actual per-data-callback and total monotonic timings in record-observations.json; no packet-boundary claim'}));
