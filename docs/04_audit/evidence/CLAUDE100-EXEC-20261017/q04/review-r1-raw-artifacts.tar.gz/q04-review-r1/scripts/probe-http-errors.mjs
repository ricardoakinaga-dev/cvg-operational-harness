import assert from 'node:assert/strict';
import http from 'node:http';
import {api,own,planFor,exchange,idle,serialError} from './probe-common.mjs';
import {writeFile} from 'node:fs/promises';
const realHead=http.ServerResponse.prototype.writeHead;const realClose=http.Server.prototype.close;
const results=[];
for(const dual of [false,true]){
 const p=planFor();const s=await api.createModelFaultServer(p);let actualPrimary;
 http.ServerResponse.prototype.writeHead=function(status,...args){try{return realHead.call(this,-1,...args)}catch(e){actualPrimary=e;throw e}};
 const wire=await exchange(s,p);await idle(s);
 http.ServerResponse.prototype.writeHead=realHead;
 const fakeCleanup=Object.assign(new Error('CVG_SYNTHETIC_CLOSE_FAULT'),{code:'CVG_FAKE_ECLOSE'});let nativeCloseCompleted=false;
 if(dual)http.Server.prototype.close=function(callback){return realClose.call(this,error=>{nativeCloseCompleted=!error;callback(error??fakeCleanup)})};
 let returned;
 try{await s.close()}catch(e){returned=e}finally{http.Server.prototype.close=realClose;}
 assert.equal(actualPrimary?.code,'ERR_HTTP_INVALID_STATUS_CODE');assert.ok(returned);
 assert.equal(s.state().closed,true);assert.equal(s.state().active,0);assert.equal(s.state().timers,0);assert.equal(s.state().sockets,0);
 results.push({dualFailure:dual,realHandlerCause:serialError(actualPrimary),nativeCloseCompleted,cleanupFault:dual?serialError(fakeCleanup):null,returned:serialError(returned),primaryIdentityPreserved:returned===actualPrimary||returned.cause===actualPrimary||returned.errors?.includes(actualPrimary)||false,cleanupIdentityPreserved:dual?returned.errors?.includes(fakeCleanup)||false:null,state:s.state(),wire});
}
await writeFile(`${own}/logs/http-error-observations.json`,JSON.stringify({probe:'real-handler-and-cleanup-path',results,injectionLimit:'Response.writeHead delegates to native method with invalid status, producing real Node RangeError. Cleanup callback error is synthetic after actual successful HTTP close, not an OS server.close failure. No pure aggregation-helper call; no fetch/timer/Date replacement.'},null,2)+'\n');
console.log(JSON.stringify(results,null,2));
