import assert from 'node:assert/strict';
import fsp from 'node:fs/promises';
import {constants,closeSync} from 'node:fs';
import {syncBuiltinESMExports} from 'node:module';
const realOpen=fsp.open;let hook=null;const nativeErrors=[];
fsp.open=async function(...args){if(hook)await hook(args);try{return await realOpen.apply(this,args)}catch(e){nativeErrors.push({code:e.code,syscall:e.syscall});throw e}};syncBuiltinESMExports();
const {api,contract,kit,own,planFor,exchange,idle,serialError}=await import('./probe-common.mjs');
const root=`${own}/tmp/persist-evidence`;
await fsp.mkdir(root,{mode:0o700});await fsp.mkdir(`${root}/nested`,{mode:0o700});await fsp.mkdir(`${root}/outside`,{mode:0o700});
const p=planFor('chunked-json',1);const s=await api.createModelFaultServer(p,{mode:'record'});await exchange(s,p);await idle(s);const r=s.recording();await s.close();
const p2=planFor('ok-json',2);const s2=await api.createModelFaultServer(p2,{mode:'refresh'});await exchange(s2,p2);await idle(s2);const r2=s2.recording();await s2.close();
const record=(path,rec=r)=>api.persistSyntheticRecording(rec,{evidenceRoot:root,path,mode:'record',previousDigest:null});
const refresh=(path,prev=r.digest)=>api.persistSyntheticRecording(r2,{evidenceRoot:root,path,mode:'refresh',previousDigest:prev});
const out=await record('original.json');const before=await fsp.readFile(`${root}/original.json`);assert.equal(before.toString(),`${kit.canonicalJson(r)}\n`);assert.equal((await fsp.stat(`${root}/original.json`)).mode&0o777,0o600);
let collision;try{await record('original.json')}catch(e){collision=serialError(e)}assert.ok(collision);
const newOut=await refresh('original.json');assert.deepEqual(await fsp.readFile(`${root}/original.json`),before);assert.equal(newOut.path,`original.json.refresh-${r2.digest}.json`);await assert.rejects(refresh('original.json'));assert.equal((await fsp.readFile(`${root}/${newOut.path}`)).toString(),`${kit.canonicalJson(r2)}\n`);
const rejected=[];
for(const [name,bytes]of [
 ['space',Buffer.from(' '+before.toString())],
 ['newline',before.subarray(0,before.length-1)],
 ['duplicate',Buffer.from(before.toString().replace('"synthetic":true','"synthetic":false,"synthetic":true'))],
 ['wrong-digest',Buffer.from(before.toString().replace(r.digest,'0'.repeat(64)))],
 ['size',Buffer.alloc(400001,32)]
]){await fsp.writeFile(`${root}/${name}.json`,bytes);await assert.rejects(refresh(`${name}.json`));assert.deepEqual(await fsp.readFile(`${root}/${name}.json`),bytes);rejected.push(name)}
await fsp.symlink(`${root}/original.json`,`${root}/symlink.json`);await assert.rejects(refresh('symlink.json'));rejected.push('symlink');
await fsp.link(`${root}/original.json`,`${root}/hardlink.json`);await assert.rejects(refresh('hardlink.json'));await fsp.unlink(`${root}/hardlink.json`);rejected.push('nlink2');
await fsp.mkdir(`${root}/directory.json`,{mode:0o700});await assert.rejects(refresh('directory.json'));rejected.push('directory');
// FIFO and foreign UID fixture were prepared only within own temporary tree.
for(const path of ['fifo.json','foreign.json']){await assert.rejects(refresh(path));rejected.push(path)}
await fsp.mkdir(`${root}/writable`,{mode:0o777});await fsp.chmod(`${root}/writable`,0o777);await assert.rejects(record('writable/no.json'));rejected.push('world-writable-child');
for(const path of ['../no.json','/tmp/no.json','nested/../no.json','a'.repeat(129),'a//b']){await assert.rejects(record(path));rejected.push(path)}
let swapped=false;hook=async ([path])=>{if(String(path).endsWith('/race.json')&&!swapped){swapped=true;await fsp.rename(`${root}/nested`,`${root}/parked`);await fsp.symlink(`${root}/outside`,`${root}/nested`);}};
await record('nested/race.json');hook=null;assert.equal(swapped,true);assert.equal((await fsp.readFile(`${root}/parked/race.json`)).toString(),`${kit.canonicalJson(r)}\n`);await assert.rejects(fsp.stat(`${root}/outside/race.json`));
// Inject a real kernel EBADF by invalidating only the newly-created owned output FD.
// No fake Error and no replacement of FileHandle methods or timers. Wrapper delegates native opens.
const delegate=fsp.open;
fsp.open=async function(...args){const h=await delegate.apply(this,args);if(String(args[0]).endsWith('/fault-primary.json'))closeSync(h.fd);return h};syncBuiltinESMExports();
let dual;try{await record('fault-primary.json')}catch(e){dual=serialError(e)}assert.equal(dual?.name,'AggregateError');
fsp.open=delegate;syncBuiltinESMExports();
const result={probe:'persistence-real-boundaries',canonical0600:true,refreshHistoricalBytesPreserved:true,exclusiveRecordCollision:{underlyingNativeOpen:nativeErrors.find(e=>e.code==='EEXIST'),returned:collision},rejectedCases:rejected,TOCTOU:{swappedAfterValidationBeforeOutputOpen:swapped,writtenInParkedFdDirectory:true,symlinkDestinationUntouched:true},realFDInvalidation:{method:'closeSync(new output fd) before native FileHandle.writeFile/close; both syscalls return real EBADF',returned:dual,partialFileBytes:(await fsp.stat(`${root}/fault-primary.json`)).size},UIDFixture:(await fsp.stat(`${root}/foreign.json`)).uid};
await fsp.writeFile(`${own}/logs/persistence-observations.json`,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
