import { startVitest } from '/tmp/cvg-claude100-exec-20261017/q04-candidate/node_modules/vitest/dist/node.js'

const candidate = '/tmp/cvg-claude100-exec-20261017/q04-candidate'
const own = '/tmp/cvg-claude100-exec-20261017/q04-builder'
process.chdir(candidate)
const filters = [
  'tests/model-fault-server.test.ts',
  'tests/support/governed-test-kit/governed-test-kit.test.ts',
  'tests/conformance/harness-runtimes.conformance.test.ts',
  'tests/consumers-sdk-session.test.ts'
]
const context = await startVitest('test', filters, {
  watch: false, fileParallelism: false, maxWorkers: 1, reporters: ['verbose'],
  cache: false, configLoader: 'native'
}, { cacheDir: `${own}/cache` })
await context.close()
