import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { createRequire } from 'node:module';
import { guardPostgresPoolErrors } from '/tmp/cvg-aud0605-20261006/candidate/packages/persistence/src/pool-errors.ts';
const require=createRequire('/tmp/cvg-aud0605-20261006/candidate/package.json');
const { Pool, Client }=require('pg');
const tick=()=>new Promise(resolve=>setImmediate(resolve));
class Wire extends EventEmitter {
  constructor(){super();this.parsedStatements={};this._connecting=true;this.sent=[];this.stream={destroy:()=>this.end()};}
  query(sql){this.sent.push(sql); if(sql==='WAIT')return; queueMicrotask(()=>{
    if(sql==='SQL_ERROR')this.emit('errorMessage', Object.assign(new Error('synthetic SQL rejection'),{code:'23505'}));
    else this.emit('commandComplete',{text:sql==='BEGIN'?'BEGIN':sql==='COMMIT'?'COMMIT':'SELECT 0'});
    this.emit('readyForQuery');
  });}
  end(){if(this.stopped)return; this.stopped=true;queueMicrotask(()=>this.emit('end'));}
  ref(){} unref(){}
}
class PhysicalClient extends Client {
  static failNext=false;
  constructor(){super({connection:new Wire()});}
  connect(cb){this._connecting=true;this._connectionCallback=cb;this._attachListeners(this.connection);this.connection.on('end',()=>{this._ended=true;this.emit('end')});queueMicrotask(()=>{
    if(PhysicalClient.failNext){PhysicalClient.failNext=false;this.connection.emit('error',new Error('synthetic connect failure'));}
    else this.connection.emit('readyForQuery');
  });}
}
const make=(opts={},report)=>guardPostgresPoolErrors(new Pool({Client:PhysicalClient,max:1,idleTimeoutMillis:0,...opts}), report);
function lose(client){const e=new Error('synthetic socket loss');client.connection.emit('error',e);return e;}

console.log(JSON.stringify({node:process.version,pg:require('pg/package.json').version,pgPool:JSON.parse(readFileSync(join(dirname(require.resolve('pg-pool')),'package.json'),'utf8')).version,pgResolved:require.resolve('pg'),pgPoolResolved:require.resolve('pg-pool'),boundary:'real pg.Client/query/error + pg-pool; simulated Connection only; no sockets or DB'}));

test('negative control: unguarded newly leased client error is an uncaught emitter throw',async()=>{
 const p=new Pool({Client:PhysicalClient,idleTimeoutMillis:0});const c=await p.connect();assert.throws(()=>lose(c),/synthetic socket loss/);c.release();await p.end();
});
test('guard returns original pool and successful query/release/end remain intact',async()=>{
 const raw=new Pool({Client:PhysicalClient,max:1,idleTimeoutMillis:0});const p=guardPostgresPoolErrors(raw);assert.equal(p,raw);const c=await p.connect();assert.equal(c.listenerCount('error'),1);await c.query('SELECT 1');c.release();assert.equal(p.idleCount,1);await p.end();assert.equal(p.totalCount,0);assert.equal(p.ended,true);
});
for(const reused of [false,true]){
 test(`${reused?'reused':'new'} leased loss rejects active and queued queries; release destroys and next acquisition recovers`,async()=>{
  const seen=[];const p=make({},e=>seen.push(e));let c=await p.connect();if(reused){c.release();const before=c;c=await p.connect();assert.equal(c,before);}
  const pending=c.query('WAIT');const queued=c.query('SELECT queued');const both=Promise.allSettled([pending,queued]);const failure=lose(c);const results=await both;
  assert.deepEqual(results.map(x=>x.status),['rejected','rejected']);assert.ok(results.every(x=>x.reason===failure));assert.deepEqual(seen,[failure]);assert.equal(c.listenerCount('error'),1);
  await assert.rejects(c.query('SELECT after'),/not queryable/);c.release();await tick();assert.equal(p.totalCount,0);const fresh=await p.connect();assert.notEqual(fresh,c);await fresh.query('SELECT recovered');fresh.release();await p.end();
 });
 test(`${reused?'reused':'new'} leased loss between queries rejects next query and preserves release safety`,async()=>{
  const p=make();let c=await p.connect();await c.query('SELECT before');if(reused){c.release();c=await p.connect();}
  assert.doesNotThrow(()=>lose(c));await assert.rejects(c.query('SELECT next'),/not queryable/);c.release();await tick();assert.equal(p.totalCount,0);await p.query('SELECT recovered');await p.end();
 });
}
test('idle loss is handled at both client and pool; removed client stays safe on late error',async()=>{
 const seen=[];const p=make({},e=>seen.push(e));const c=await p.connect();c.release();assert.equal(c.listenerCount('error'),2);const error=lose(c);await tick();assert.equal(p.totalCount,0);assert.equal(p.idleCount,0);assert.equal(seen.length,2);assert.ok(seen.every(x=>x===error));assert.doesNotThrow(()=>c.emit('error',new Error('late error')));await p.query('SELECT fresh');await p.end();
});
test('guard installed before acquire delivery, without adding listeners on 2000 reuses',async()=>{
 const p=make();const original=await p.connect();let maxLeased=0,maxIdle=0;original.release();for(let i=0;i<2000;i++){const c=await p.connect();assert.equal(c,original);maxLeased=Math.max(maxLeased,c.listenerCount('error'));await c.query('SELECT reuse');c.release();maxIdle=Math.max(maxIdle,c.listenerCount('error'));}
 assert.equal(maxLeased,1);assert.equal(maxIdle,2);assert.equal(p.listenerCount('connect'),1);assert.equal(p.listenerCount('error'),1);console.log(JSON.stringify({reuses:2000,maxLeased,maxIdle,poolConnectListeners:1,poolErrorListeners:1}));await p.end();
});
test('pool.query loss rejects once, releases once, removes client and recovers',async()=>{
 const p=make();const c=await p.connect();c.release();let releases=0;p.on('release',()=>releases++);const pending=p.query('WAIT');await tick();const error=lose(c);await assert.rejects(pending,e=>e===error);await tick();assert.equal(releases,1);assert.equal(p.totalCount,0);await p.query('SELECT fresh');assert.equal(releases,2);await p.end();
});
test('ordinary SQL error propagates without client error event; pool.query discards failed client',async()=>{
 const seen=[];const p=make({},e=>seen.push(e));await assert.rejects(p.query('SQL_ERROR'),e=>e.code==='23505');await tick();assert.equal(p.totalCount,0);assert.deepEqual(seen,[]);await p.query('SELECT recovery');await p.end();
});
test('new connection establishment failure propagates and replacement connects',async()=>{
 const p=make();PhysicalClient.failNext=true;await assert.rejects(p.connect(),/synthetic connect failure/);assert.equal(p.totalCount,0);await p.query('SELECT fresh');await p.end();
});
test('waiting borrower recovers after leased loss and caller release',async()=>{
 const p=make();const c=await p.connect();const waiting=p.connect();assert.equal(p.waitingCount,1);lose(c);c.release();const fresh=await waiting;assert.notEqual(c,fresh);await fresh.query('SELECT fresh');fresh.release();await p.end();
});
test('shutdown waits for borrowed client; error and release unblock end, preserving end contracts',async()=>{
 const p=make();const c=await p.connect();let finished=false;const closing=p.end().then(()=>finished=true);await tick();assert.equal(finished,false);lose(c);c.release();await closing;assert.equal(p.totalCount,0);await assert.rejects(p.connect(),/after calling end/);await assert.rejects(p.end(),/more than once/);
});
test('maxUses retirement attaches one guard per replacement and does not retain pool clients',async()=>{
 const p=make({maxUses:1});let previous;for(let i=0;i<20;i++){const c=await p.connect();assert.notEqual(c,previous);assert.equal(c.listenerCount('error'),1);await c.query('SELECT maxUses');c.release();await tick();assert.equal(p.totalCount,0);previous=c;}await p.end();
});
test('idle timeout retires client normally and fresh query recovers',async()=>{
 const p=make({idleTimeoutMillis:5});await p.query('SELECT idle');await new Promise(r=>setTimeout(r,20));assert.equal(p.totalCount,0);await p.query('SELECT fresh');await p.end();
});
