import subprocess,pathlib,json,sys,datetime
out=pathlib.Path('/tmp/cvg-aud0605-20261006/pool-reviewer')
label=sys.argv[1];cmd=sys.argv[2:];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
r=subprocess.run(cmd,cwd='/tmp/cvg-aud0605-20261006/candidate',capture_output=True,text=True)
(out/(label+'.log')).write_text(r.stdout+r.stderr)
(out/(label+'.json')).write_text(json.dumps({'label':label,'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':'/tmp/cvg-aud0605-20261006/candidate','command':cmd,'exit_status':r.returncode,'output':label+'.log'},indent=2)+'\n')
print(r.stdout+r.stderr);sys.exit(r.returncode)
