import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { createRequire } from 'node:module';
import { guardPostgresPoolErrors } from '/tmp/cvg-aud0605-20261006/candidate/packages/persistence/src/pool-errors.ts';
const require=createRequire('/tmp/cvg-aud0605-20261006/candidate/package.json');
const { Pool, Client }=require('pg');
const tick=()=>new Promise(resolve=>setImmediate(resolve));
class Wire extends EventEmitter {
  constructor(){super();this.parsedStatements={};this._connecting=true;this.sent=[];this.stream={destroy:()=>this.end()};}
  query(sql){this.sent.push(sql); const action=this.plan?.(sql);if(action==='loss'){queueMicrotask(()=>this.emit('error',new Error('synthetic socket loss at '+sql)));return;}if(sql==='WAIT')return; queueMicrotask(()=>{
    if(sql==='SQL_ERROR'||action==='sql-error')this.emit('errorMessage', Object.assign(new Error('synthetic SQL rejection'),{code:'23505'}));
    else {if(sql==='SHOW search_path'||sql.includes('NULLIF(current_setting')){const name=sql==='SHOW search_path'?'search_path':'tenant_id';this.emit('rowDescription',{fields:[{name,tableID:0,columnID:0,dataTypeID:25,dataTypeSize:-1,dataTypeModifier:-1,format:'text'}]});this.emit('dataRow',{fields:[name==='search_path'?Buffer.from('public'):null]});}this.emit('commandComplete',{text:sql==='BEGIN'?'BEGIN':sql==='COMMIT'?'COMMIT':'SELECT 0'});}
    this.emit('readyForQuery');
  });}
  parse(config){this.text=config.text;} bind(){} describe(){} execute(){} sync(){this.query(this.text);}
  end(){if(this.stopped)return; this.stopped=true;queueMicrotask(()=>this.emit('end'));}
  ref(){} unref(){}
}
class PhysicalClient extends Client {
  static failNext=false;static nextPlan;
  constructor(){super({connection:new Wire()});this.connection.plan=PhysicalClient.nextPlan;PhysicalClient.nextPlan=undefined;}
  connect(cb){this._connecting=true;this._connectionCallback=cb;this._attachListeners(this.connection);this.connection.on('end',()=>{this._ended=true;this.emit('end')});queueMicrotask(()=>{
    if(PhysicalClient.failNext){PhysicalClient.failNext=false;this.connection.emit('error',new Error('synthetic connect failure'));}
    else this.connection.emit('readyForQuery');
  });}
}
const make=(opts={},report)=>guardPostgresPoolErrors(new Pool({Client:PhysicalClient,max:1,idleTimeoutMillis:0,...opts}), report);
function lose(client){const e=new Error('synthetic socket loss');client.connection.emit('error',e);return e;}


export { Wire,PhysicalClient,Pool,Client,make,lose,tick,require };
