import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { PhysicalClient,make,lose,tick,require } from './app-fixture.mjs';
import { createPostgresOperatorSessionPool,PostgresOperatorSessionStore } from '/tmp/cvg-aud0605-20261006/candidate/apps/api/src/operator-session-postgres.ts';
import { openPostgresControlledConnection,createControlledNoopHandlers } from '/tmp/cvg-aud0605-20261006/candidate/apps/worker/src/postgres-controlled.ts';
import { createOperationalHarnessWorker } from '/tmp/cvg-aud0605-20261006/candidate/apps/worker/src/operational-harness-worker.ts';
import { withTenantContext,withTenantTransaction } from '/tmp/cvg-aud0605-20261006/candidate/packages/persistence/src/tenant-scoped-postgres.ts';
const tenantId='tenant_00000000-0000-4000-8000-000000000605';
const previous='opsess_'+'A'.repeat(43);
const input=()=>({identity:{tenantId,operatorId:'reviewer-synthetic',role:'Operator'},expiresAt:Date.now()+60000});
const env={NODE_ENV:'test',DATABASE_URL:'postgresql://synthetic@invalid.invalid/db',POSTGRES_SCHEMA:'synthetic',POSTGRES_RLS_ENFORCEMENT:'true',CVG_WORKER_CONTROLLED_MODE:'true',CVG_WORKER_TENANT_ID:tenantId};
function fakePool(p){p.Client=PhysicalClient;return p;}
for(const [name,create] of [
 ['API operator-session',()=>({pool:createPostgresOperatorSessionPool(env.DATABASE_URL)})],
 ['worker controlled',()=>openPostgresControlledConnection(env,createControlledNoopHandlers())],
 ['worker operational',()=>createOperationalHarnessWorker(env)]
])test(`${name} actual factory handles leased loss and replacement with exactly one guard`,async()=>{
 const runtime=create();const p=fakePool(runtime.pool);assert.equal(p.listenerCount('connect'),1);assert.equal(p.listenerCount('error'),1);const c=await p.connect();assert.equal(c.listenerCount('error'),1);assert.doesNotThrow(()=>lose(c));await assert.rejects(c.query('SELECT 1'),/not queryable/);c.release();await tick();assert.equal(p.totalCount,0);await p.query('SELECT fresh');if(runtime.close)await runtime.close();else await p.end();assert.equal(p.ended,true);
});
for(const point of ['BEGIN','operator_session_revoke','operator_session_create','COMMIT'])test(`actual switchIdentity loss at ${point} rejects without a session, destroys client, recovers`,async()=>{
 const p=fakePool(createPostgresOperatorSessionPool(env.DATABASE_URL));PhysicalClient.nextPlan=sql=>sql.includes(point)?'loss':undefined;const c=await p.connect();c.release();let releases=0;p.on('release',()=>releases++);const store=new PostgresOperatorSessionStore(p,'synthetic_auth');await assert.rejects(store.switchIdentity(previous,input()),/synthetic socket loss/);await tick();assert.equal(releases,1);assert.equal(p.totalCount,0);const fresh=await p.connect();assert.notEqual(fresh,c);fresh.release();const session=await store.switchIdentity(previous,input());assert.match(session.sessionId,/^opsess_/);await p.end();
});
test('actual switchIdentity SQL create rejection executes rollback, destroys lease, and keeps original error',async()=>{
 const p=fakePool(createPostgresOperatorSessionPool(env.DATABASE_URL));PhysicalClient.nextPlan=sql=>sql.includes('operator_session_create')?'sql-error':undefined;const c=await p.connect();c.release();const store=new PostgresOperatorSessionStore(p,'synthetic_auth');await assert.rejects(store.switchIdentity(previous,input()),e=>e.code==='23505');await tick();assert.equal(c.connection.sent.at(-1),'ROLLBACK');assert.equal(c.connection.sent.some(sql=>sql==='COMMIT'),false);assert.equal(p.totalCount,0);await p.end();
});
for(const helper of [withTenantContext,withTenantTransaction])test(`${helper.name} loss inside operation rejects, discards tenant-bearing client, and permits fresh query`,async()=>{
 const p=make();const c=await p.connect();c.release();let invoked=0;await assert.rejects(helper(p,tenantId,async client=>{invoked++;lose(client);return await client.query('SELECT forbidden-after-loss');}));assert.equal(invoked,1);await tick();assert.equal(p.totalCount,0);const fresh=await p.connect();assert.notEqual(fresh,c);await fresh.query('SELECT fresh');fresh.release();await p.end();
});
for(const helper of [withTenantContext,withTenantTransaction])test(`${helper.name} context establishment loss rejects before operation/any effect`,async()=>{
 const p=make();PhysicalClient.nextPlan=sql=>sql.includes('set_config')?'loss':undefined;let invoked=0;await assert.rejects(helper(p,tenantId,async()=>{invoked++;return 'unexpected'}),/synthetic socket loss/);assert.equal(invoked,0);await tick();assert.equal(p.totalCount,0);await p.end();
});
test('connected AST inventory: every API/worker production Pool construction is wrapped once in guard',()=>{
 const ts=require('typescript');const paths=['apps/api/src/server.ts','apps/api/src/operator-session-postgres.ts','apps/api/src/stop-alert-monitor.ts','apps/worker/src/postgres-controlled.ts','apps/worker/src/operational-harness-worker.ts'];let total=0;const inventory=[];
 for(const path of paths){const text=readFileSync('/tmp/cvg-aud0605-20261006/candidate/'+path,'utf8');const ast=ts.createSourceFile(path,text,ts.ScriptTarget.Latest,true);let count=0;function walk(node){if(ts.isNewExpression(node)&&node.expression.getText(ast)==='Pool'){count++;total++;const parent=node.parent;assert.ok(ts.isCallExpression(parent));assert.equal(parent.expression.getText(ast),'guardPostgresPoolErrors');assert.equal(parent.arguments.length,1);assert.equal(parent.arguments[0],node);}ts.forEachChild(node,walk);}walk(ast);assert.equal(count,1);inventory.push({path,newPools:count});}assert.equal(total,5);console.log(JSON.stringify({factoryInventory:inventory}));
});
test('worker factories retain production/controlled-mode prohibitions',()=>{
 assert.throws(()=>createOperationalHarnessWorker({...env,NODE_ENV:'production'}),/production is forbidden/);assert.throws(()=>openPostgresControlledConnection({...env,CVG_WORKER_CONTROLLED_MODE:'false'},createControlledNoopHandlers()),/controlled mode/);assert.throws(()=>openPostgresControlledConnection({...env,POSTGRES_RLS_ENFORCEMENT:'false'},createControlledNoopHandlers()),/RLS enforcement/);
});
import { PostgresOidcLoginStateStore } from '/tmp/cvg-aud0605-20261006/candidate/apps/api/src/oidc-state-postgres.ts';
import { PostgresWebhookReplayStore } from '/tmp/cvg-aud0605-20261006/candidate/apps/api/src/webhook-security.ts';
for(const method of ['reserve','commit','release'])test(`actual webhook replay ${method} leased loss rejects and finally release evicts broken client`,async()=>{
 const p=make();PhysicalClient.nextPlan=()=> 'loss';let released=0;p.on('release',()=>released++);const store=new PostgresWebhookReplayStore(p);const operation=method==='reserve'?store.reserve('synthetic-review-key',Date.now()+60000):store[method]({key:'synthetic-review-key',generation:1,token:'synthetic-token'});await assert.rejects(operation,/synthetic socket loss/);await tick();assert.equal(released,1);assert.equal(p.totalCount,0);await p.query('SELECT recovery');await p.end();
});
for(const method of ['reserve','consume'])test(`actual OIDC state ${method} pool.query loss rejects rather than accepting state; pool recovers`,async()=>{
 const p=fakePool(createPostgresOperatorSessionPool(env.DATABASE_URL));PhysicalClient.nextPlan=()=> 'loss';const store=new PostgresOidcLoginStateStore(p,'synthetic_auth');await assert.rejects(method==='reserve'?store.reserve('a'.repeat(64),Date.now()+60000):store.consume('a'.repeat(64)),/synthetic socket loss/);await tick();assert.equal(p.totalCount,0);await p.query('SELECT recovery');await p.end();
});
for(const method of ['create','get','replace','revoke'])test(`actual session ${method} pool.query loss propagates; no successful auth result; fresh connection recovers`,async()=>{
 const p=fakePool(createPostgresOperatorSessionPool(env.DATABASE_URL));PhysicalClient.nextPlan=()=> 'loss';const store=new PostgresOperatorSessionStore(p,'synthetic_auth');const operation=method==='create'?store.create(input()):method==='replace'?store.replace(previous,input()):store[method](previous);await assert.rejects(operation,/synthetic socket loss/);await tick();assert.equal(p.totalCount,0);await p.query('SELECT recovery');await p.end();
});
