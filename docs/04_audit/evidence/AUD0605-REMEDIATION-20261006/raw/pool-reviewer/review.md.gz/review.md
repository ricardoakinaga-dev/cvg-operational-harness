# AUD0605 — bounded pool/error review

Review complete with **no reproducible contract violation found in this lane**. This is a limited review of the pool guard and connected API/worker callsites, not a release decision or proof of the real PostgreSQL/image boundary.

## Candidate, authority, independence

- Actual `git rev-parse HEAD`: `216e17c512efe1ec6d244698b2c82f62ba567667` (expected prefix matches).
- Actual base: `5b098a71c93226c616323f0255b271cb234ccafc`.
- Candidate: `/tmp/cvg-aud0605-20261006/candidate`. Outputs exclusively `/tmp/cvg-aud0605-20261006/pool-reviewer`.
- Readonly authority: user's bounded delegation and lead's AUD0605 section in shared `docs/08_runtime/agent_coordination.md`. Shared ledger writes/claim updates belong to lead and were expressly excluded from this lane.
- Mandatory root/constitution/runtime/log/backlog/coordination reads unavoidably exposed earlier audit conclusions embedded in those ledgers, including crash, transaction, and DDL outcomes. The initial bulk read was output-truncated; it did not provide exhaustive visible ledger history. Coordination and SPEC 0144 also contain embedded historical conclusions. **This reviewer is separate from implementation, but cannot claim blindness to all prior conclusions.** No delivery summary or prior audit report/evidence conclusion was opened; links from ledgers/SPEC were not followed. Assertions were derived from current source and the supplied frozen criteria.
- Applied engineering-framework audit/verification guidance. No descendants/subagents.

## Frozen expectations and assessment

| Criterion | Contract | Result and evidence | Confidence / limits |
| --- | --- | --- | --- |
| C1 | Handle client error events for idle/leased/new/reused clients. | Focused driver tests cover new and reused leases, pending and queued queries, loss between queries, idle loss, and failed connection establishment. Negative control without guard produces emitter throw. All five production source constructors are guarded. | High for exercised driver event paths; simulated connection, not socket/backend termination. |
| C2 | Query failures propagate; safe release/recovery; no weakened auth/effect semantics. | Real `pg.Client` and `pg-pool` reject queries and discard nonqueryable/released failed clients. Actual session switch/create/get/replace/revoke, OIDC state reserve/consume, replay reserve/commit/release, and tenant helpers reject injected faults and permit fresh connections. Tenant establishment loss never invokes operation. Worker safety prohibitions remain enforced. | High for tested promises/release, moderate for integrated auth/effects. HTTP cookies, actual database state and external effects not exercised here. |
| C3 | No listener accumulation or pool lifecycle regression. | 2,000 reuses: leased listener count 1, idle count 2, pool connect/error count 1 each. Tested pending borrower recovery, shutdown with active lease, maxUses retirement, idle timeout, and rejecting connect after end/double end. | High for tested lifecycle configurations. No heap profiling or full process shutdown test. |

Criterion source is the user's frozen lane contract. SPEC `docs/02_spec/0144_trusted_operator_session_production.md` additionally requires fail-closed auth, post-commit cookie installation, bounded auth pools, and no memory fallback. ADR-010 preserves infrastructure/product ownership and does not grant release. No telemetry requirement was added.

## Connected source inspection

Hashes and physical paths are in [sources.json](sources.json); the scoped base/candidate diff is [scoped-diff.log](scoped-diff.log). Constructor and callsite inventories are [constructor-inventory.log](constructor-inventory.log) and [callsite-inventory.log](callsite-inventory.log).

- `packages/persistence/src/pool-errors.ts:12–22`: attaches one pool `error` listener and one client listener from pool `connect`; never resolves/replaces query promises, retries effects, or changes client release/end methods.
- Installed `node_modules/pg-pool/index.js`: new-client acquisition emits `connect` before removing its idle listener and delivering the borrower; reused acquisitions do not emit `connect`. `pool.query` retains its temporary error listener. Release removes clients on an error, `_queryable=false`, ending, maxUses, or expiry.
- Installed `node_modules/pg/lib/client.js`: connection error marks the client nonqueryable, schedules failure of active/queued queries, then emits the client error. Ordinary SQL errors retain normal query rejection semantics.
- Five constructors: API `server.ts:4649` (runtime plus optional nonproduction migration pool), `operator-session-postgres.ts:200`, `stop-alert-monitor.ts:78`; worker `postgres-controlled.ts:118`, `operational-harness-worker.ts:243`. Every `new Pool` in production API/worker source is wrapped exactly once; verified by source search and AST test. Tests constructing their own pools are outside runtime construction inventory.
- Session bootstrap `production-bootstrap.ts:91–150`: uses guarded session factory, readiness failure destroys lease, close retains a shared promise. Session store `operator-session-postgres.ts:152–184` retains BEGIN/revoke/create/COMMIT and rollback/destroy-on-failure. API `server.ts:820–855` catches store errors with 503 and sets the session cookie only after returned success; inspected, not HTTP-tested here.
- API readiness `server.ts:4580–4640` keeps admission occupied until acquisition settles and uses one guarded release on failure/deadline. Preflight `server.ts:5310–5420` awaits checks, releases clients in finally, closes pools on rejected checks. Legacy non-RLS path and onClose are at `5424–5466`.
- API replay `webhook-security.ts:222–297` releases in finally. OIDC store uses session pool.query, validates bounded settings, and returns acceptance only on a boolean result. Session preflight queries reject naturally through pool.query.
- Worker role preflight `postgres-role-preflight.ts:92,285–312` destroys on failed tenant cleanup; `main.ts:350–370,450–470` drains/stops before end. `homolog-worker.ts` consumes the already-composed operational pool; it does not construct another Pool.
- Connected persistence helpers `tenant-scoped-postgres.ts:83–215`, `operational-execution-postgres.ts:265–276`, and `worker-operations-postgres.ts` retain context cleanup/transaction failure handling. Guard integration does not change SQL, tenant scope, approval checks or effect authorization.

## Executed checks and actual outputs

Runtime was `/home/ricardo/.nvm/versions/node/v22.23.2/bin/node` (`v22.23.2`). Physical candidate dependencies resolved to its own `node_modules`: `pg 8.20.0`, `pg-pool 3.13.0`. No dependencies were installed or altered by this reviewer. TSX cache disabled for application tests.

| Check | Actual outcome | Evidence |
| --- | --- | --- |
| Independent focused driver suite | exit 0; 15 tests, 15 pass, 0 fail/skip/cancel | [focused.json](focused.json), [focused.log](focused.log), [focused.test.mjs](focused.test.mjs) |
| Independent application/tenant suite, final expanded run | exit 0; 23 tests, 23 pass, 0 fail/skip/cancel | [app-boundaries.json](app-boundaries.json), [app-boundaries.log](app-boundaries.log), [app-boundaries.test.mts](app-boundaries.test.mts), [app-fixture.mjs](app-fixture.mjs) |
| Current-source inventory/diff/preservation | exit 0; five constructor paths, 51 callsite lines, 616 source/manifest/lock inputs unchanged | [static-review.json](static-review.json), [static-review.log](static-review.log), [preservation.json](preservation.json) |

Actual final output includes `# tests 15 / # pass 15 / # fail 0` and `# tests 23 / # pass 23 / # fail 0`. The reuse output is `{"reuses":2000,"maxLeased":1,"maxIdle":2,"poolConnectListeners":1,"poolErrorListeners":1}`. Exactly **3 final PASS procedures**: focused suite (15 cases), application suite (23 cases), and static inventory/diff/preservation procedure (4 subordinate read-only commands exit 0). These are 38 final passing test cases, not 38 top-level procedures. Total final focused tests: **38**; an earlier 14-test application pass is retained separately and not counted twice.

Harness failures were retained, corrected only inside this output directory, and are not candidate findings:

1. Initial focused metadata lookup used unexported `pg-pool/package.json`: runner exit 1 before tests, preserved in `focused.tap`. Corrected by reading metadata beside the physically resolved dependency entrypoint.
2. Initial app fixture had an extra parenthesis: exit 1 before tests, `app-boundaries-harness-error.log/json`. Corrected fixture then passed 14, subsequently expanded to 23 tests.
3. Initial preservation check unnecessarily asserted whole-tree cleanliness: exit 1 solely because concurrent `certification/mutation-guard.json` changed. Source/lock drift was zero. Final check records that foreign artifact status instead of claiming a clean tree. Earlier output: `static-review-concurrent-artifact.log/json`.

The fixture subclasses physical `pg.Client` only for synthetic connection establishment and supplies an EventEmitter protocol connection (including simple/extended query replies). Actual client query/error handling, actual Pool acquisition/release/shutdown, source factories/stores/tenant helpers run. Factory test changes only each in-process Pool's Client transport to this fixture; no source or dependency bytes are changed. This does not reproduce actual PostgreSQL commit/rollback persistence.

## Findings versus observations/inherited behavior

**Findings: none reproduced.** No severity-bearing remediation is proposed. This does not assert absence of faults outside exercised boundaries.

- **Observation O1 — duplicate reporting on idle faults (confirmed):** `onError` receives the same idle loss twice, through pool forwarding and the permanent client listener. Current production callsites use the default no-op. No telemetry/exactly-once reporting contract exists in the supplied bar; this is not a defect or listener accumulation. Confidence high; focused test 7.
- **Observation O2 — COMMIT ambiguity (known boundary):** simulated loss while COMMIT is sent rejects without returning a session and destroys the lease; it cannot prove whether a real server committed. Never use this lane to claim the old session survives loss after COMMIT. The candidate comment explicitly states the ambiguity. Confidence high in rejection; persistent outcome untested.
- **Inherited O3 — cleanup error can supersede callback error:** withTenantContext prioritizes failed cleanup over an operation error, still rejecting and destroying the client. Base/candidate diff for this helper is empty. This does not weaken fail-closed behavior and is not a new finding. Confidence high from connected source and exercised rejection/disposal; exact error identity not separately asserted.
- **Inherited O4 — legacy non-RLS retained lease:** `server.ts` retains one client for the lifetime of non-RLS persistence and releases only on app close; it has no client replacement path. Guard preserves the process/error handling, not repair of that permanently held failed client. This composition predates the candidate, is forbidden in the production tenant-RLS configuration, and is a static limitation rather than a new production regression. Confidence moderate; legacy app recovery not executed here.
- **Concurrent state:** candidate HEAD and 616 tracked code/manifest/lock inputs are unchanged. Git status now contains ` M certification/mutation-guard.json`; its author was not independently identified. This reviewer never wrote it, did not inspect its conclusions, and made no attempt to restore it.

## Remaining boundary and handoff

Actual PostgreSQL backend termination/transaction rollback, API process liveness and HTTP 503/no-cookie/old-session validity, real retry authentication, disposable image behavior, full suite/coverage, worker durable effect semantics and genuine shutdown remain with lead. This lane does not duplicate or claim those checks. No PG/Docker, process termination, certify, E2E, SBOM, license gate, commit, push or shared-ledger edit was performed.

Resource closure: all reviewer Node/test/TSX/Python procedures have returned; no background process, server, socket, PostgreSQL resource, Docker resource, pool timer or active lease was retained. Synthetic pools were ended by the probes. No process termination was used. Output evidence is retained for lead.

Lane status: `COMPLETED_BOUNDED_REVIEW`; verification is positive for the exercised boundary and partial for system-level criteria. `last_completed_action`: independent pool/store/tenant fault and lifecycle checks plus source preservation. `next_action`: lead combines this receipt with its real DB/image and regression results before its own audit verdict.
