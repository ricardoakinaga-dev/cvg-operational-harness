import pathlib,subprocess,json,hashlib,datetime
root=pathlib.Path('/tmp/cvg-aud0605-20261006/candidate'); out=pathlib.Path('/tmp/cvg-aud0605-20261006/pool-reviewer')
paths=['packages/persistence/src/pool-errors.ts','packages/persistence/src/index.ts','packages/persistence/src/tenant-scoped-postgres.ts','packages/persistence/src/operational-execution-postgres.ts','packages/persistence/src/worker-operations-postgres.ts','apps/api/src/operator-session-postgres.ts','apps/api/src/oidc-state-postgres.ts','apps/api/src/production-bootstrap.ts','apps/api/src/server.ts','apps/api/src/stop-alert-monitor.ts','apps/api/src/webhook-security.ts','apps/api/src/operator-session-preflight.ts','apps/worker/src/postgres-controlled.ts','apps/worker/src/postgres-role-preflight.ts','apps/worker/src/operational-harness-worker.ts','apps/worker/src/main.ts','apps/worker/src/homolog-worker.ts','docs/02_spec/0144_trusted_operator_session_production.md','docs/architecture/adrs/ADR-010-harness-product-isolation.md','node_modules/pg/lib/client.js','node_modules/pg/lib/query.js','node_modules/pg/lib/index.js','node_modules/pg-pool/index.js','node_modules/pg/package.json','node_modules/pg-pool/package.json','node_modules/tsx/package.json','node_modules/typescript/package.json','AGENTS.md','docs/07_agents/AGENTS.md','tsconfig.base.json','package-lock.json']
source_info=[]
for p in paths:
 f=root/p;source_info.append({'path':p,'realpath':str(f.resolve()),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(out/'sources.json').write_text(json.dumps(source_info,indent=2)+'\n')
for label,cmd in [('constructor-inventory',['rg','-n','new Pool|guardPostgresPoolErrors','apps/api/src','apps/worker/src','-g','!**/__tests__/**']),('callsite-inventory',['rg','-n',"from 'pg'|pool\\.connect|pool\\.query|pool\\.end|client\\.release",'apps/api/src','apps/worker/src','-g','!**/__tests__/**']),('scoped-diff',['git','diff','5b098a7','HEAD','--']+paths[:17]),('inherited-helpers-diff',['git','diff','5b098a7','HEAD','--','packages/persistence/src/tenant-scoped-postgres.ts','apps/api/src/webhook-security.ts','apps/worker/src/postgres-role-preflight.ts'])]:
 r=subprocess.run(cmd,cwd=root,capture_output=True,text=True);(out/(label+'.log')).write_text(r.stdout+r.stderr);(out/(label+'.json')).write_text(json.dumps({'command':cmd,'exit_status':r.returncode,'output':label+'.log','at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n');assert r.returncode==0
 print(label+': exit 0, '+str(len(r.stdout.splitlines()))+' lines')
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();base=subprocess.check_output(['git','rev-parse','5b098a7'],cwd=root,text=True).strip()
print('candidate '+sha+'; base '+base)
assert sha=='216e17c512efe1ec6d244698b2c82f62ba567667'
old=json.loads((out/'inputs-before.json').read_text());changed=[]
for p,digest in old['files'].items():
 if hashlib.sha256((root/p).read_bytes()).hexdigest()!=digest:changed.append(p)
status=subprocess.check_output(['git','status','--short'],cwd=root,text=True)
print('tracked source/lock inputs checked: '+str(len(old['files']))+'; drift: '+str(len(changed))+'; git status: '+repr(status))
assert not changed
(out/'preservation.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sha':sha,'base':base,'tracked_input_count':len(old['files']),'changed_inputs':changed,'candidate_git_status':status,'dependency_physical_realpaths':[i for i in source_info if i['path'].startswith('node_modules/')]},indent=2)+'\n')
