import pg from 'pg'
import {randomBytes} from 'node:crypto'
import {spawnSync} from 'node:child_process'
import {writeFileSync} from 'node:fs'
import {buildApiWithProductionSessions} from '/tmp/cvg-aud0605-20261006/candidate/apps/api/src/production-bootstrap.ts'
import {createConfiguredOperatorIdentityResolver} from '/tmp/cvg-aud0605-20261006/candidate/apps/api/src/operator-identity.ts'
const root='/tmp/cvg-aud0605-20261006/job-reviewer',candidate='/tmp/cvg-aud0605-20261006/candidate'
const prefix='aud0605job_'+randomBytes(4).toString('hex')
const roles={migration:prefix+'_mig',runtime:prefix+'_run',auth:prefix+'_owner',session:prefix+'_session'}
const schemas={data:prefix+'_data',auth:prefix+'_auth'}
const password='synthetic-job-reviewer-only'
const url=(role:string)=>`postgres://${role}:${password}@127.0.0.1:55727/cvg_aud0605_review`
const admin=new pg.Client({connectionString:'postgres://postgres:synthetic-aud0605-local@127.0.0.1:55727/cvg_aud0605_review',connectionTimeoutMillis:2000})
const result:any={prefix,roles,schemas,node:process.version,correctedHarness:{identityResolver:'createConfiguredOperatorIdentityResolver as main.ts:40',identityKeyring:'current object {keyId,secret}, as parser requires'},checks:[],residuals:{}}
let app:Awaited<ReturnType<typeof buildApiWithProductionSessions>>|undefined
try{
  await admin.connect()
  for(const role of Object.values(roles))await admin.query(`CREATE ROLE ${role} LOGIN PASSWORD '${password}' NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE NOREPLICATION NOINHERIT`)
  await admin.query(`CREATE SCHEMA ${schemas.data} AUTHORIZATION ${roles.migration}`)
  await admin.query(`ALTER ROLE ${roles.migration} SET search_path=${schemas.data}`)
  await admin.query(`ALTER ROLE ${roles.runtime} SET search_path=${schemas.data}`)
  await admin.query(`GRANT CREATE ON DATABASE cvg_aud0605_review TO ${roles.auth}`)
  const job=spawnSync('/home/ricardo/.nvm/versions/node/v22.23.2/bin/node',['--import',candidate+'/node_modules/tsx/dist/loader.mjs',root+'/runtime/scripts/migrate-job.mjs'],{cwd:candidate,encoding:'utf8',env:{PATH:process.env.PATH,HOME:root,NODE_ENV:'production',TSX_TSCONFIG_PATH:candidate+'/tsconfig.base.json',DATABASE_MIGRATION_URL:url(roles.migration),POSTGRES_SCHEMA:schemas.data,CVG_RUNTIME_ROLE:roles.runtime,CVG_OPERATOR_AUTH_MIGRATION_URL:url(roles.auth),CVG_OPERATOR_AUTH_SCHEMA:schemas.auth,CVG_OPERATOR_SESSION_ROLE:roles.session}})
  result.setupJob={status:job.status,stdout:job.stdout,stderr:job.stderr}
  if(job.status!==0)throw new Error('fixture migration job failed')
  await admin.query(`REVOKE CREATE ON DATABASE cvg_aud0605_review FROM ${roles.auth}`)
  const env={NODE_ENV:'production',API_PERSISTENCE_MODE:'postgres',DATABASE_URL:url(roles.runtime),POSTGRES_SCHEMA:schemas.data,POSTGRES_RLS_ENFORCEMENT:'true',POSTGRES_AUTO_MIGRATE:'false',OUTBOX_DURABLE_INBOUND:'true',CVG_IDENTITY_MODE:'trusted',CVG_OPERATOR_IDENTITY_KEYRING:JSON.stringify({current:{keyId:'synthetic-reviewer',secret:'synthetic-identity-key-0123456789abcdef0123456789abcdef'}}),CVG_OPERATOR_SESSION_DATABASE_URL:url(roles.session),CVG_OPERATOR_AUTH_SCHEMA:schemas.auth,CVG_OPERATOR_SESSION_ROLE:roles.session,CVG_RATE_LIMIT_KEYRING:JSON.stringify({budgetSecret:'synthetic-budget-key-0123456789abcdef0123456789',current:{keyId:'synthetic',secret:'synthetic-rate-key-0123456789abcdef0123456789abcdef'}}),INBOUND_TENANT_ID:'tenant_11111111-1111-4111-8111-111111111111',INBOUND_AGENT_ID:'agent_22222222-2222-4222-8222-222222222222',WEBHOOK_SIGNING_SECRET:'synthetic-webhook-key-0123456789abcdef0123456789abcdef',API_ALLOWED_ORIGINS:'https://aud0605.example.invalid',API_REQUIRE_HTTPS:'true',API_TRUSTED_PROXY_ADDRESSES:'127.0.0.1',API_TRUSTED_PROXY_HOPS:'0'}
  Object.assign(process.env,env)
  app=await buildApiWithProductionSessions(env,{operatorIdentityResolver:createConfiguredOperatorIdentityResolver(env)!})
  await app.ready()
  const live=await app.inject({url:'/live'})
  result.checks.push({name:'production_runtime_session_catalog_start',pass:live.statusCode===200,details:{readyResolved:true,liveStatus:live.statusCode,noDdlUrlInEnv:!('DATABASE_MIGRATION_URL' in env),listenUsed:false}})
}catch(e:any){result.failure={message:e.message,stack:e.stack}}
finally{
  await app?.close().catch(e=>{result.residuals.appCloseError=String(e)})
  for(const schema of Object.values(schemas))await admin.query(`DROP SCHEMA IF EXISTS ${schema} CASCADE`).catch(e=>{result.residuals.schemaError=String(e)})
  for(const role of Object.values(roles)){
    await admin.query(`DROP OWNED BY ${role}`).catch(e=>{result.residuals.dropOwnedError=String(e)})
    await admin.query(`DROP ROLE IF EXISTS ${role}`).catch(e=>{result.residuals.roleError=String(e)})
  }
  result.residuals.roles=(await admin.query('SELECT rolname FROM pg_roles WHERE rolname=ANY($1)',[Object.values(roles)])).rows
  result.residuals.schemas=(await admin.query('SELECT nspname FROM pg_namespace WHERE nspname=ANY($1)',[Object.values(schemas)])).rows
  await admin.end()
  writeFileSync(root+'/startup-retest.json',JSON.stringify(result,null,2)+'\n')
  console.log(JSON.stringify(result))
}
