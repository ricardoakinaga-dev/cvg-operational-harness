import pg from 'pg'
import {randomBytes,createHash} from 'node:crypto'
import {writeFileSync} from 'node:fs'
import {spawnSync} from 'node:child_process'
import * as current from '/tmp/cvg-aud0605-20261006/candidate/apps/api/src/tenant-preflight.ts'
import * as baseline from './baseline-tenant-preflight.ts'
import {buildApiWithProductionSessions} from '/tmp/cvg-aud0605-20261006/candidate/apps/api/src/production-bootstrap.ts'
const root='/tmp/cvg-aud0605-20261006/job-reviewer'
const candidate='/tmp/cvg-aud0605-20261006/candidate'
const node='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node'
const loader=candidate+'/node_modules/tsx/dist/loader.mjs'
const prefix='aud0605job_'+randomBytes(4).toString('hex')
const roles={migration:prefix+'_mig',runtime:prefix+'_run',auth:prefix+'_owner',session:prefix+'_session'}
const schemas={data:prefix+'_data',auth:prefix+'_auth'}
const password='synthetic-job-reviewer-only'
const admin=new pg.Client({connectionString:'postgres://postgres:synthetic-aud0605-local@127.0.0.1:55727/cvg_aud0605_review',connectionTimeoutMillis:2000})
const url=(role:string)=>`postgres://${role}:${password}@127.0.0.1:55727/cvg_aud0605_review`
const clients:pg.Client[]=[]
const checks:any[]=[]
const jobs:any[]=[]
const residuals:any={roles:[],schemas:[]}
writeFileSync(root+'/allocation.json',JSON.stringify({prefix,roles,schemas},null,2))
function record(name:string,pass:boolean,details:any){checks.push({name,pass,details}); console.log(JSON.stringify(checks.at(-1)))}
async function connect(role:string){const c=new pg.Client({connectionString:url(role),connectionTimeoutMillis:2000});await c.connect();clients.push(c);return c}
async function attempt(f:()=>Promise<any>){try{return {accepted:true,value:await f()}}catch(e:any){return {accepted:false,message:e.message}}}
function job(name:string,overrides:Record<string,string|undefined>={}) {
  const env:Record<string,string|undefined>={PATH:process.env.PATH,HOME:root,NODE_ENV:'production',TSX_TSCONFIG_PATH:candidate+'/tsconfig.base.json',DATABASE_MIGRATION_URL:url(roles.migration),POSTGRES_SCHEMA:schemas.data,CVG_RUNTIME_ROLE:roles.runtime,CVG_OPERATOR_AUTH_MIGRATION_URL:url(roles.auth),CVG_OPERATOR_AUTH_SCHEMA:schemas.auth,CVG_OPERATOR_SESSION_ROLE:roles.session,...overrides}
  for(const key of Object.keys(env))if(env[key]===undefined)delete env[key]
  const r=spawnSync(node,['--import',loader,root+'/runtime/scripts/migrate-job.mjs'],{cwd:candidate,env,encoding:'utf8'})
  const result={name,status:r.status,signal:r.signal,stdout:r.stdout,stderr:r.stderr,error:r.error?.message}
  jobs.push(result);writeFileSync(root+'/jobs.json',JSON.stringify(jobs,null,2));return result
}
async function snapshot(){return (await admin.query(`SELECT version,checksum,applied_at FROM ${schemas.data}.schema_migrations ORDER BY version`)).rows}
async function equivalent(name:string,owner:pg.Client,runtime:pg.Client,expect:boolean){
  const oldSecurity=await attempt(()=>baseline.assertMigrationRoleSecurityBoundary(owner,roles.runtime))
  const oldLeast=await attempt(()=>baseline.assertMigrationRoleIsLeastPrivilege(owner,roles.runtime))
  const catalog=await attempt(()=>current.assertMigrationOwnerFromCatalog(runtime,roles.runtime))
  record(name,(oldSecurity.accepted&&oldLeast.accepted)===expect&&catalog.accepted===expect,{oldSecurity,oldLeast,catalog,expect})
}
let failure:any
try{
  await admin.connect()
  record('environment',true,(await admin.query('SELECT version(),current_database()')).rows)
  for(const role of Object.values(roles))await admin.query(`CREATE ROLE ${role} LOGIN PASSWORD '${password}' NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE NOREPLICATION NOINHERIT`)
  await admin.query(`CREATE SCHEMA ${schemas.data} AUTHORIZATION ${roles.migration}`)
  await admin.query(`ALTER ROLE ${roles.migration} SET search_path=${schemas.data}`)
  await admin.query(`ALTER ROLE ${roles.runtime} SET search_path=${schemas.data}`)
  // A minimal temporary CREATE grant is scoped to this review database and own role.
  await admin.query(`GRANT CREATE ON DATABASE cvg_aud0605_review TO ${roles.auth}`)
  const badGrant=job('missing_runtime_role',{CVG_RUNTIME_ROLE:prefix+'_absent'})
  const committed=await snapshot()
  const grantUsage=(await admin.query("SELECT has_schema_privilege($1,$2,'USAGE') AS usage",[roles.runtime,schemas.data])).rows
  record('runtime_grant_failure_commits_migrations_not_grants',badGrant.status===1&&committed.length===28&&grantUsage[0].usage===false,{badGrant,versions:committed.length,grantUsage})
  const authFail=job('auth_schema_rejected_after_product_commit',{CVG_OPERATOR_AUTH_SCHEMA:schemas.data})
  record('auth_failure_reports_product_success_then_failure',authFail.status===1&&authFail.stdout.includes('migration.product_applied')&&authFail.stderr.includes('migration.failed'),authFail)
  const badSession=job('auth_grant_failure',{CVG_OPERATOR_SESSION_ROLE:prefix+'_absent'})
  const authPartial=(await admin.query(`SELECT version FROM ${schemas.auth}.schema_migrations ORDER BY version`)).rows
  const noSessionUsage=(await admin.query("SELECT has_schema_privilege($1,$2,'USAGE') AS usage",[roles.session,schemas.auth])).rows
  record('auth_grant_failure_commits_auth_not_grants',badSession.status===1&&authPartial.length===2&&!noSessionUsage[0].usage,{badSession,authPartial,noSessionUsage})
  const good=job('four_role_complete')
  record('four_role_job',good.status===0&&good.stdout.includes('migration.operator_auth_applied'),good)
  const before=await snapshot()
  const authBefore=(await admin.query(`SELECT version,checksum,applied_at FROM ${schemas.auth}.schema_migrations ORDER BY version`)).rows
  const again=job('idempotent_repeat')
  const after=await snapshot()
  const authAfter=(await admin.query(`SELECT version,checksum,applied_at FROM ${schemas.auth}.schema_migrations ORDER BY version`)).rows
  record('repeat_preserves_versions_checksums_timestamps',again.status===0&&JSON.stringify(before)===JSON.stringify(after)&&JSON.stringify(authBefore)===JSON.stringify(authAfter),{again,productCount:after.length,authCount:authAfter.length})
  await admin.query(`REVOKE CREATE ON DATABASE cvg_aud0605_review FROM ${roles.auth}`)
  const owner=await connect(roles.migration);const runtime=await connect(roles.runtime);const session=await connect(roles.session)
  await equivalent('catalog_baseline_valid',owner,runtime,true)
  record('runtime_least_privilege_after_job',(await attempt(()=>current.assertRuntimeRoleIsLeastPrivilege(runtime,roles.migration))).accepted,true)
  for(const flag of ['SUPERUSER','BYPASSRLS','CREATEDB','CREATEROLE','REPLICATION']){
    await admin.query(`ALTER ROLE ${roles.migration} ${flag}`)
    await equivalent('catalog_owner_'+flag,owner,runtime,false)
    await admin.query(`ALTER ROLE ${roles.migration} NO${flag}`)
  }
  await admin.query(`GRANT ${roles.auth} TO ${roles.migration}`)
  await equivalent('catalog_owner_membership',owner,runtime,false)
  await admin.query(`REVOKE ${roles.auth} FROM ${roles.migration}`)
  await admin.query(`ALTER TABLE ${schemas.data}.worker_heartbeats OWNER TO ${roles.auth}`)
  await equivalent('catalog_table_owner_mismatch',owner,runtime,false)
  await admin.query(`ALTER TABLE ${schemas.data}.worker_heartbeats OWNER TO ${roles.migration}`)
  for(const grant of ['DELETE','TRUNCATE','TRIGGER','REFERENCES']){
    await admin.query(`GRANT ${grant} ON ${schemas.data}.worker_heartbeats TO ${roles.runtime}`)
    const rejected=await attempt(()=>current.assertRuntimeRoleIsLeastPrivilege(runtime,roles.migration))
    record('runtime_forbidden_'+grant,!rejected.accepted,rejected)
    await admin.query(`REVOKE ${grant} ON ${schemas.data}.worker_heartbeats FROM ${roles.runtime}`)
  }
  await admin.query(`GRANT SELECT ON ${schemas.data}.tenant_isolation_quarantine TO ${roles.runtime}`)
  const quarantine=await attempt(()=>current.assertRuntimeRoleIsLeastPrivilege(runtime,roles.migration))
  record('runtime_quarantine_denied',!quarantine.accepted,quarantine)
  await admin.query(`REVOKE SELECT ON ${schemas.data}.tenant_isolation_quarantine FROM ${roles.runtime}`)
  const grants=(await admin.query(`SELECT p.proname, has_function_privilege($1,p.oid,'EXECUTE') AS session_execute FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname=$2 ORDER BY p.proname`,[roles.session,schemas.auth])).rows
  record('six_auth_functions_granted',grants.length===6&&grants.every(g=>g.session_execute),grants)
  const dml=await attempt(()=>session.query(`SELECT * FROM ${schemas.auth}.operator_sessions`))
  const productAccess=await attempt(()=>session.query(`SELECT * FROM ${schemas.data}.worker_heartbeats`))
  record('session_no_auth_dml_or_product_access',!dml.accepted&&!productAccess.accepted,{dml,productAccess})
  const digest=randomBytes(32)
  await session.query(`SELECT ${schemas.auth}.operator_session_create($1,$2,$3,$4,clock_timestamp()+interval '5 minutes')`,[digest,'tenant_11111111-1111-4111-8111-111111111111','synthetic.operator','Operator'])
  const sessionRead=(await session.query(`SELECT * FROM ${schemas.auth}.operator_session_get($1)`,[digest])).rows
  record('session_create_get_real',sessionRead.length===1,sessionRead)
  await session.query(`SELECT ${schemas.auth}.operator_session_revoke($1)`,[digest])
  await session.query(`SELECT ${schemas.auth}.operator_session_revoke($1)`,[digest])
  record('session_revoke_idempotent',(await session.query(`SELECT * FROM ${schemas.auth}.operator_session_get($1)`,[digest])).rows.length===0,true)
  // Corrupt only the marker in our schema; prove a repeat refuses altered input.
  await admin.query(`UPDATE ${schemas.data}.schema_migrations SET checksum='bad' WHERE version='0027_worker_operations'`)
  const corrupted=job('checksum_mismatch')
  record('checksum_guard',corrupted.status===1&&corrupted.stderr.includes('checksum mismatch'),corrupted)
  await admin.query(`UPDATE ${schemas.data}.schema_migrations SET checksum=$1 WHERE version='0027_worker_operations'`,[before.find(v=>v.version==='0027_worker_operations').checksum])
  const env={NODE_ENV:'production',API_PERSISTENCE_MODE:'postgres',DATABASE_URL:url(roles.runtime),POSTGRES_SCHEMA:schemas.data,POSTGRES_RLS_ENFORCEMENT:'true',POSTGRES_AUTO_MIGRATE:'false',OUTBOX_DURABLE_INBOUND:'true',CVG_IDENTITY_MODE:'trusted',CVG_OPERATOR_IDENTITY_KEYRING:JSON.stringify({current:'synthetic-identity-key-0123456789abcdef0123456789abcdef'}),CVG_OPERATOR_SESSION_DATABASE_URL:url(roles.session),CVG_OPERATOR_AUTH_SCHEMA:schemas.auth,CVG_OPERATOR_SESSION_ROLE:roles.session,CVG_RATE_LIMIT_KEYRING:JSON.stringify({budgetSecret:'synthetic-budget-key-0123456789abcdef0123456789',current:{keyId:'synthetic',secret:'synthetic-rate-key-0123456789abcdef0123456789abcdef'}}),API_ALLOWED_ORIGINS:'https://aud0605.example.invalid',API_REQUIRE_HTTPS:'true'}
  Object.assign(env,{INBOUND_TENANT_ID:'tenant_11111111-1111-4111-8111-111111111111',INBOUND_AGENT_ID:'agent_22222222-2222-4222-8222-222222222222',WEBHOOK_SIGNING_SECRET:'synthetic-webhook-key-0123456789abcdef0123456789abcdef',API_TRUSTED_PROXY_ADDRESSES:'127.0.0.1',API_TRUSTED_PROXY_HOPS:'0'})
  Object.assign(process.env,env)
  for(const ddl of ['',url(roles.migration)]){
    const rejected=await attempt(()=>buildApiWithProductionSessions({...env,DATABASE_MIGRATION_URL:ddl}))
    record('production_rejects_ddl_'+(ddl?'nonempty':'empty'),!rejected.accepted&&rejected.message?.includes('DATABASE_MIGRATION_URL'),rejected)
  }
  const auto=await attempt(()=>buildApiWithProductionSessions({...env,POSTGRES_AUTO_MIGRATE:'true'}))
  record('production_rejects_auto_migration',!auto.accepted&&auto.message?.includes('must not run PostgreSQL migrations'),auto)
  const startup=await attempt(async()=>{
    const app=await buildApiWithProductionSessions(env)
    try{await app.ready();const live=await app.inject({url:'/live'});return {live:live.statusCode}}finally{await app.close()}
  })
  record('production_runtime_session_catalog_start',startup.accepted,startup)
}catch(e:any){failure={message:e.message,stack:e.stack};console.log(JSON.stringify({failure}))}
finally{
  for(const client of clients)await client.end().catch(e=>{residuals.clientError=String(e)})
  for(const schema of Object.values(schemas))await admin.query(`DROP SCHEMA IF EXISTS ${schema} CASCADE`).catch(e=>{residuals.schemaError=String(e)})
  for(const role of Object.values(roles)){
    await admin.query(`DROP OWNED BY ${role}`).catch(e=>{residuals.dropOwnedError=String(e)})
    await admin.query(`DROP ROLE IF EXISTS ${role}`).catch(e=>{residuals.roleError=String(e)})
  }
  residuals.roles=(await admin.query('SELECT rolname FROM pg_roles WHERE rolname=ANY($1)',[Object.values(roles)])).rows
  residuals.schemas=(await admin.query('SELECT nspname FROM pg_namespace WHERE nspname=ANY($1)',[Object.values(schemas)])).rows
  await admin.end()
  const result={prefix,node:process.version,checks,jobs,failure,residuals,passed:checks.filter(c=>c.pass).length,failed:checks.filter(c=>!c.pass).length}
  writeFileSync(root+'/results.json',JSON.stringify(result,null,2)+'\n')
  console.log(JSON.stringify({summary:{passed:result.passed,failed:result.failed,failure,residuals}}))
}
