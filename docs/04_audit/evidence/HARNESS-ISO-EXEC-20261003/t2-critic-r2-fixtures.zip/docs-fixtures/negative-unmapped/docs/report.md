[source](../old/other.ts)
