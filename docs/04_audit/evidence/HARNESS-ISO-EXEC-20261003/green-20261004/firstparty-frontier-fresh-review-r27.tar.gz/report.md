# Finite first-party dispositions — fresh I1 review

**ACCEPT — scoped to the 222 I0 proposals.** 140 exact positive reference roles are accepted; 82 observations remain UNRESOLVED and unaccepted. Source/dist rows and duplicate occurrences remain separate. This does not grant a whole-closure PASS, frontier readiness, vendor waiver or release.

Authority SHA-256: `baf9102d5e3c6fe5a03a77afce274d44cf85315fc98c029588b304af2768723c`. Source: `/home/ricardo/.cache/cvg-harness-green-20261004/c1-nonbinding-label-r22/candidate`. Effective runtime: Node v22.23.2, TypeScript parser 6.0.3. No prior critic judgments or default Root governance were read.

The review independently enumerated AST occurrences before comparing proposed offsets, bound local symbols/imports, inspected actual caller/callee bodies and package export wiring, and retained raw code fragments. All 222 file/text hashes and UTF-16/UTF-8 positions matched; all 222 finite role checks matched. Eight AST-only discriminating controls and five trusted builtin controls matched. Source-consuming tests, payloads and fullCLI were not executed.

Source integrity: 115/115 source/parser files unchanged; 48/48 internal links unchanged. Packet inputs and effective Node binary also matched. Sentinel applies to the read set, not unread whole-tree bytes. See [Sourceintegrity.json](Sourceintegrity.json).

Spies retain the receiver, original function descriptors and mock contexts/results. In R26-097 the returned `process` is recorded by the spy even though `lifecycle.install` ignores it. The independent judgments explicitly acknowledge that retention; no concrete subsequent loader/evaluator selection is shown. `Readable.on` has its own Node22 body, delegates registration to `Stream.on`, and may start flow. These effects are included in the finite analysis.

The unknown rows cover 54 dependency declarations, 12 executor acquisitions/transfers, eight reflected store transfers, five bootstrap global observations and three returned child handles. Each row below preserves its missing concrete conditions. Types and declared version ranges were not used as runtime proof.

Raw evidence: [independent AST](raw-independent-ast.json), [callee fragments and row proof checks](raw-proof-facts.json), [Node22 trusted probes](raw-trusted-probes.json), [builtin child-process source](node22-internalChildProcess.js.txt), [machine report](report.json). Authored verifier corrections and their earlier raw results are preserved; none changed the candidate.

No disputed positive counterexample was found under the finite authority. The AST negative controls distinguish dynamic/evaluator selections from the exact accepted roles; they are verifier controls, not claims about candidate failures.

Next: obtain the explicit module graphs, finite store methods, global injector identities and returned-handle consumer proofs for the 82 unknowns. R30 supplemental CJS/ESM resolver-only identities and package hashes were reproduced for all 54 declarations (108 result records). Its native condition sources matched the effective Node22 binary; node-addons/module-sync are included and default is fallback eligibility. The supplied 7818-file before/after captures are identical; this critic did not independently rehash that whole capture. Closure remains unaccepted. The packet count of 8882 full diagnostics was not rerun or accepted.

| Row | Actual source / line | I0 proposal | Independent disposition | Evidence role |
| --- | --- | --- | --- | --- |
| R26-001 | `packages/shared/package.json:19` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-002 | `packages/shared/package.json:16` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-003 | `packages/approval-engine/package.json:17` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-004 | `packages/approval-engine/package.json:20` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-005 | `packages/channel-gateway/package.json:17` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-006 | `packages/channel-gateway/package.json:20` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-007 | `packages/model-gateway/package.json:17` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-008 | `packages/model-gateway/package.json:20` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-009 | `packages/observability/package.json:17` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-010 | `packages/observability/package.json:18` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-011 | `packages/observability/package.json:19` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-012 | `packages/observability/package.json:20` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-013 | `packages/observability/package.json:23` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-014 | `packages/policy-engine/package.json:17` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-015 | `packages/policy-engine/package.json:20` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-016 | `packages/agent-runtime/package.json:22` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-017 | `packages/agent-runtime/package.json:25` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-018 | `packages/orchestrator/package.json:19` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-019 | `packages/harness/package.json:20` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-020 | `packages/platform/package.json:17` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-021 | `packages/rag/package.json:20` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-022 | `packages/platform/package.json:21` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-023 | `packages/persistence/package.json:23` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-024 | `packages/persistence/package.json:24` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-025 | `packages/persistence/package.json:27` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-026 | `packages/policy/package.json:19` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-027 | `packages/agent-core/package.json:20` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-028 | `packages/agent-core/package.json:23` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-029 | `legacy/packages/secretary-journeys/package.json:22` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-030 | `legacy/packages/secretary-journeys/package.json:23` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-031 | `legacy/packages/secretary-journeys/package.json:24` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-032 | `legacy/packages/secretary-profile/package.json:22` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-033 | `apps/api/package.json:19` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-034 | `apps/api/package.json:20` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-035 | `apps/api/package.json:21` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-036 | `apps/api/package.json:24` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-037 | `apps/web/package.json:8` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-038 | `apps/web/package.json:9` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-039 | `apps/web/package.json:10` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-040 | `apps/web/package.json:11` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-041 | `apps/web/package.json:14` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-042 | `apps/web/package.json:15` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-043 | `apps/worker/package.json:19` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-044 | `apps/worker/package.json:20` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-045 | `apps/worker/package.json:23` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-046 | `packages/adapters/package.json:11` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-047 | `packages/agent-evals/package.json:10` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-048 | `packages/agent-evals/package.json:13` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-049 | `packages/chaos/package.json:14` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-050 | `packages/chaos/package.json:18` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-051 | `packages/chaos/package.json:19` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-052 | `packages/conversation/package.json:17` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-053 | `packages/conversation/package.json:22` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-054 | `packages/conversation/package.json:23` | unknown | UNRESOLVED | DECLARED_INSTALLED_MODULE_REFERENCE |
| R26-055 | `packages/harness/src/capability-boundary.ts:595` | positive | ACCEPTED_FINITE_POSITIVE | DESCRIPTOR_JSON_DATA |
| R26-056 | `packages/harness/src/capability-boundary.ts:596` | positive | ACCEPTED_FINITE_POSITIVE | DESCRIPTOR_JSON_DATA |
| R26-057 | `packages/harness/src/capability-boundary.ts:596` | positive | ACCEPTED_FINITE_POSITIVE | DESCRIPTOR_JSON_DATA |
| R26-058 | `packages/harness/src/capability-boundary.ts:600` | positive | ACCEPTED_FINITE_POSITIVE | DESCRIPTOR_JSON_DATA |
| R26-059 | `packages/harness/src/capability-boundary.ts:628` | positive | ACCEPTED_FINITE_POSITIVE | PROTOTYPE_BOOLEAN_GUARD |
| R26-060 | `packages/harness/src/capability-boundary.ts:629` | positive | ACCEPTED_FINITE_POSITIVE | PROTOTYPE_BOOLEAN_GUARD |
| R26-061 | `packages/harness/src/capability-boundary.ts:629` | positive | ACCEPTED_FINITE_POSITIVE | PROTOTYPE_BOOLEAN_GUARD |
| R26-062 | `packages/model-gateway/src/__tests__/bounded-observer-options.test.ts:14` | unknown | UNRESOLVED | PROCESS_LAUNCH |
| R26-063 | `packages/model-gateway/src/__tests__/bounded-observer-options.test.ts:38` | positive | ACCEPTED_FINITE_POSITIVE | SPAWN_SYNC_DATA_CONSUMER |
| R26-064 | `packages/model-gateway/src/__tests__/bounded-observer-options.test.ts:39` | positive | ACCEPTED_FINITE_POSITIVE | SPAWN_SYNC_DATA_CONSUMER |
| R26-065 | `packages/model-gateway/src/__tests__/bounded-observer-options.test.ts:39` | positive | ACCEPTED_FINITE_POSITIVE | SPAWN_SYNC_DATA_CONSUMER |
| R26-066 | `packages/model-gateway/src/__tests__/bounded-observer-options.test.ts:40` | positive | ACCEPTED_FINITE_POSITIVE | SPAWN_SYNC_DATA_CONSUMER |
| R26-067 | `packages/model-gateway/src/__tests__/bounded-tls-node22.test.ts:11` | unknown | UNRESOLVED | EXECUTOR_ALIAS_TO_PROMISIFY |
| R26-068 | `packages/model-gateway/src/__tests__/d009-budget.test.ts:171` | unknown | UNRESOLVED | PROCESS_LAUNCH |
| R26-069 | `packages/model-gateway/src/__tests__/d009-budget.test.ts:186` | positive | ACCEPTED_FINITE_POSITIVE | SPAWN_SYNC_DATA_CONSUMER |
| R26-070 | `packages/model-gateway/src/__tests__/d009-budget.test.ts:186` | positive | ACCEPTED_FINITE_POSITIVE | SPAWN_SYNC_DATA_CONSUMER |
| R26-071 | `packages/model-gateway/src/__tests__/d009-budget.test.ts:187` | positive | ACCEPTED_FINITE_POSITIVE | SPAWN_SYNC_DATA_CONSUMER |
| R26-072 | `packages/model-gateway/src/__tests__/d009-budget.test.ts:641` | unknown | UNRESOLVED | PROCESS_LAUNCH |
| R26-073 | `packages/model-gateway/src/__tests__/d009-budget.test.ts:646` | positive | ACCEPTED_FINITE_POSITIVE | SPAWN_SYNC_DATA_CONSUMER |
| R26-074 | `packages/model-gateway/src/__tests__/d009-budget.test.ts:646` | positive | ACCEPTED_FINITE_POSITIVE | SPAWN_SYNC_DATA_CONSUMER |
| R26-075 | `packages/persistence/src/__tests__/outbox-edge.test.ts:119` | positive | ACCEPTED_FINITE_POSITIVE | FUNCTION_IDENTITY_AS_MATCHER_SAMPLE |
| R26-076 | `packages/platform/src/__tests__/controlled-preset-hardening.test.ts:106` | unknown | UNRESOLVED | REFLECT_GET_DYNAMIC_STORE_MEMBER |
| R26-077 | `packages/platform/src/__tests__/controlled-preset-hardening.test.ts:107` | unknown | UNRESOLVED | REFLECT_GET_DYNAMIC_STORE_MEMBER |
| R26-078 | `packages/platform/src/__tests__/controlled-preset-hardening.test.ts:107` | unknown | UNRESOLVED | REFLECT_GET_DYNAMIC_STORE_MEMBER |
| R26-079 | `packages/platform/src/__tests__/controlled-preset-hardening.test.ts:107` | unknown | UNRESOLVED | REFLECT_GET_DYNAMIC_STORE_MEMBER |
| R26-080 | `packages/platform/src/tool-invocation-boundary.ts:201` | positive | ACCEPTED_FINITE_POSITIVE | PROTOTYPE_BOOLEAN_GUARD |
| R26-081 | `packages/platform/src/tool-invocation-boundary.ts:202` | positive | ACCEPTED_FINITE_POSITIVE | PROTOTYPE_BOOLEAN_GUARD |
| R26-082 | `packages/platform/src/tool-invocation-boundary.ts:202` | positive | ACCEPTED_FINITE_POSITIVE | PROTOTYPE_BOOLEAN_GUARD |
| R26-083 | `packages/shared/src/canonical.ts:27` | positive | ACCEPTED_FINITE_POSITIVE | PROTOTYPE_BOOLEAN_GUARD |
| R26-084 | `packages/shared/src/canonical.ts:28` | positive | ACCEPTED_FINITE_POSITIVE | PROTOTYPE_BOOLEAN_GUARD |
| R26-085 | `packages/shared/src/canonical.ts:28` | positive | ACCEPTED_FINITE_POSITIVE | PROTOTYPE_BOOLEAN_GUARD |
| R26-086 | `apps/api/src/__tests__/approval-decision-atomicity-postgres.test.ts:366` | unknown | UNRESOLVED | REFLECT_GET_DYNAMIC_STORE_MEMBER |
| R26-087 | `apps/api/src/__tests__/approval-decision-atomicity.test.ts:135` | unknown | UNRESOLVED | REFLECT_GET_DYNAMIC_STORE_MEMBER |
| R26-088 | `apps/api/src/__tests__/approval-decision-atomicity.test.ts:141` | unknown | UNRESOLVED | REFLECT_GET_DYNAMIC_STORE_MEMBER |
| R26-089 | `apps/api/src/__tests__/approval-decision-atomicity.test.ts:197` | unknown | UNRESOLVED | REFLECT_GET_DYNAMIC_STORE_MEMBER |
| R26-090 | `apps/api/src/__tests__/identity-composition-wiring.test.ts:406` | unknown | UNRESOLVED | PROCESS_LAUNCH |
| R26-091 | `apps/api/src/__tests__/identity-composition-wiring.test.ts:415` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_STDIO_EVENT |
| R26-092 | `apps/api/src/__tests__/identity-composition-wiring.test.ts:418` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_STDIO_EVENT |
| R26-093 | `apps/api/src/__tests__/identity-composition-wiring.test.ts:421` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_EXIT_ERROR_EVENT |
| R26-094 | `apps/api/src/__tests__/identity-composition-wiring.test.ts:422` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_EXIT_ERROR_EVENT |
| R26-095 | `apps/api/src/__tests__/production-bootstrap-main-own.test.ts:37` | positive | ACCEPTED_FINITE_POSITIVE | BIND_PROCESS_ONCE_RECEIVER |
| R26-096 | `apps/api/src/__tests__/production-bootstrap-main-own.test.ts:38` | positive | ACCEPTED_FINITE_POSITIVE | SPY_PROCESS_ONCE |
| R26-097 | `apps/api/src/__tests__/production-bootstrap-main-own.test.ts:41` | positive | ACCEPTED_FINITE_POSITIVE | RETURN_PROCESS_FROM_SIGNAL_MOCK |
| R26-098 | `apps/api/src/__tests__/production-bootstrap-main-own.test.ts:45` | positive | ACCEPTED_FINITE_POSITIVE | SPY_PROCESS_EXIT |
| R26-099 | `apps/api/src/main.ts:31` | positive | ACCEPTED_FINITE_POSITIVE | PROCESS_TO_SELECTED_SIGNAL_SOURCE |
| R26-100 | `apps/api/src/webhook-security.ts:507` | positive | ACCEPTED_FINITE_POSITIVE | PROTOTYPE_BOOLEAN_GUARD |
| R26-101 | `apps/api/src/webhook-security.ts:508` | positive | ACCEPTED_FINITE_POSITIVE | PROTOTYPE_BOOLEAN_GUARD |
| R26-102 | `apps/api/src/webhook-security.ts:508` | positive | ACCEPTED_FINITE_POSITIVE | PROTOTYPE_BOOLEAN_GUARD |
| R26-103 | `apps/web/src/__tests__/app.test.tsx:335` | positive | ACCEPTED_FINITE_POSITIVE | FUNCTION_IDENTITY_AS_MATCHER_SAMPLE |
| R26-104 | `apps/web/src/__tests__/app.test.tsx:539` | positive | ACCEPTED_FINITE_POSITIVE | FUNCTION_IDENTITY_AS_MATCHER_SAMPLE |
| R26-105 | `apps/web/src/__tests__/app.test.tsx:50` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-106 | `apps/web/src/__tests__/app.test.tsx:190` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-107 | `apps/web/src/__tests__/app.test.tsx:377` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-108 | `apps/web/src/__tests__/app.test.tsx:492` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-109 | `apps/web/src/__tests__/app.test.tsx:562` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-110 | `apps/web/src/__tests__/app.test.tsx:588` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-111 | `apps/web/src/__tests__/app.test.tsx:691` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-112 | `apps/web/src/__tests__/app.test.tsx:831` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-113 | `apps/web/src/__tests__/app.test.tsx:926` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-114 | `apps/web/src/__tests__/app.test.tsx:1005` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-115 | `apps/web/src/__tests__/app.test.tsx:1133` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-116 | `apps/web/src/__tests__/app.test.tsx:1320` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-117 | `apps/web/src/__tests__/app.test.tsx:1365` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-118 | `apps/web/src/__tests__/attendance-approval-conflict.test.tsx:29` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-119 | `apps/web/src/__tests__/attendance-approval-conflict.test.tsx:92` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-120 | `apps/web/src/__tests__/audit-checkpoint-app.test.tsx:16` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-121 | `apps/web/src/__tests__/journeys-identity-race.test.tsx:38` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-122 | `apps/web/src/__tests__/journeys-identity-race.test.tsx:76` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-123 | `apps/web/src/__tests__/journeys-identity-race.test.tsx:101` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-124 | `apps/web/src/__tests__/journeys-identity-race.test.tsx:151` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-125 | `apps/web/src/__tests__/journeys-identity-race.test.tsx:232` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-126 | `apps/web/src/__tests__/platform-panel.test.tsx:103` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-127 | `apps/web/src/__tests__/platform-panel.test.tsx:225` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-128 | `apps/web/src/__tests__/platform-panel.test.tsx:308` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-129 | `apps/web/src/__tests__/platform-panel.test.tsx:381` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-130 | `apps/web/src/__tests__/platform-panel.test.tsx:449` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-131 | `apps/web/src/__tests__/platform-panel.test.tsx:511` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-132 | `apps/web/src/__tests__/trusted-session-app.test.tsx:40` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-133 | `apps/web/src/api/audit-evidence-checkpoint-client.test.ts:29` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-134 | `apps/web/src/api/audit-evidence-checkpoint-client.test.ts:97` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-135 | `apps/web/src/api/client.test.ts:52` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-136 | `apps/web/src/api/release-candidate-client.test.ts:45` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-137 | `apps/web/src/api/release-candidate-client.test.ts:58` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-138 | `apps/web/src/api/release-candidate-client.test.ts:108` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-139 | `apps/web/src/api/resilient-client.test.ts:57` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-140 | `apps/web/src/api/resilient-client.test.ts:77` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-141 | `apps/web/src/api/resilient-client.test.ts:104` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-142 | `apps/web/src/api/resilient-client.test.ts:119` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-143 | `apps/web/src/api/resilient-client.test.ts:133` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-144 | `apps/web/src/api/resilient-client.test.ts:144` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-145 | `apps/web/src/api/resilient-client.test.ts:157` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-146 | `apps/web/src/api/resilient-client.test.ts:173` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-147 | `apps/web/src/api/resilient-client.test.ts:187` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-148 | `apps/web/src/auth/session.ts:77` | unknown | UNRESOLVED | GLOBAL_NAMESPACE_ALIAS |
| R26-149 | `apps/web/src/auth/session.ts:78` | unknown | UNRESOLVED | INJECTED_PROVIDER_READ |
| R26-150 | `apps/web/src/auth/session.ts:79` | unknown | UNRESOLVED | INJECTED_PROVIDER_CALL |
| R26-151 | `apps/web/src/auth/session.ts:81` | unknown | UNRESOLVED | TOKEN_GLOBAL_READ |
| R26-152 | `apps/web/src/auth/session.ts:82` | unknown | UNRESOLVED | TOKEN_GLOBAL_DELETE |
| R26-153 | `apps/web/src/features/journeys/journeys.test.tsx:28` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-154 | `apps/web/src/features/platform/handoff-policy-control-center.test.tsx:78` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-155 | `apps/web/src/features/platform/handoff-policy-control-center.test.tsx:167` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-156 | `apps/web/src/features/platform/knowledge-source-catalog.test.tsx:25` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-157 | `apps/web/src/features/platform/multi-agent-creation.test.tsx:54` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-158 | `apps/web/src/features/platform/multi-agent-creation.test.tsx:228` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-159 | `apps/web/src/features/platform/multi-agent-creation.test.tsx:305` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-160 | `apps/web/src/features/platform/multi-agent-creation.test.tsx:411` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-161 | `apps/web/src/features/platform/multi-agent-creation.test.tsx:516` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-162 | `apps/web/src/features/platform/multi-agent-creation.test.tsx:626` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-163 | `apps/web/src/features/platform/platform.test.tsx:33` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-164 | `apps/web/src/features/platform/platform.test.tsx:116` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-165 | `apps/web/src/features/platform/platform.test.tsx:194` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-166 | `apps/web/src/features/platform/prompt-profile-control-center.test.tsx:96` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-167 | `apps/web/src/features/platform/release-candidate-ledger.test.tsx:75` | positive | ACCEPTED_FINITE_POSITIVE | GLOBAL_FETCH_SPY |
| R26-168 | `apps/worker/src/__tests__/continuous-worker-entrypoint.integration.test.ts:54` | unknown | UNRESOLVED | PROCESS_LAUNCH |
| R26-169 | `apps/worker/src/__tests__/continuous-worker-entrypoint.integration.test.ts:64` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_STDIO_EVENT |
| R26-170 | `apps/worker/src/__tests__/continuous-worker-entrypoint.integration.test.ts:67` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_STDIO_EVENT |
| R26-171 | `apps/worker/src/__tests__/continuous-worker-entrypoint.integration.test.ts:70` | unknown | UNRESOLVED | CHILD_HANDLE_RETURN |
| R26-172 | `apps/worker/src/__tests__/continuous-worker.test.ts:116` | unknown | UNRESOLVED | PROCESS_LAUNCH |
| R26-173 | `apps/worker/src/__tests__/continuous-worker.test.ts:126` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_STDIO_EVENT |
| R26-174 | `apps/worker/src/__tests__/continuous-worker.test.ts:129` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_STDIO_EVENT |
| R26-175 | `apps/worker/src/__tests__/continuous-worker.test.ts:132` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_TERMINATION |
| R26-176 | `apps/worker/src/__tests__/continuous-worker.test.ts:133` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_EXIT_ERROR_EVENT |
| R26-177 | `apps/worker/src/__tests__/continuous-worker.test.ts:137` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_EXIT_ERROR_EVENT |
| R26-178 | `apps/worker/src/__tests__/homolog-worker-lifecycle.test.ts:96` | unknown | UNRESOLVED | PROCESS_LAUNCH |
| R26-179 | `apps/worker/src/__tests__/homolog-worker-lifecycle.test.ts:119` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_STDIO_EVENT |
| R26-180 | `apps/worker/src/__tests__/homolog-worker-lifecycle.test.ts:122` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_STDIO_EVENT |
| R26-181 | `apps/worker/src/__tests__/homolog-worker-lifecycle.test.ts:127` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_EXIT_ERROR_EVENT |
| R26-182 | `apps/worker/src/__tests__/homolog-worker-lifecycle.test.ts:128` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_EXIT_ERROR_EVENT |
| R26-183 | `apps/worker/src/__tests__/homolog-worker-lifecycle.test.ts:139` | unknown | UNRESOLVED | PROCESS_LAUNCH |
| R26-184 | `apps/worker/src/__tests__/homolog-worker-lifecycle.test.ts:155` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_STDIO_EVENT |
| R26-185 | `apps/worker/src/__tests__/homolog-worker-lifecycle.test.ts:158` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_STDIO_EVENT |
| R26-186 | `apps/worker/src/__tests__/homolog-worker-lifecycle.test.ts:163` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_EXIT_ERROR_EVENT |
| R26-187 | `apps/worker/src/__tests__/homolog-worker-lifecycle.test.ts:164` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_EXIT_ERROR_EVENT |
| R26-188 | `apps/worker/src/__tests__/operational-harness-homolog.integration.test.ts:131` | unknown | UNRESOLVED | PROCESS_LAUNCH |
| R26-189 | `apps/worker/src/__tests__/operational-harness-homolog.integration.test.ts:141` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_STDIO_EVENT |
| R26-190 | `apps/worker/src/__tests__/operational-harness-homolog.integration.test.ts:144` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_STDIO_EVENT |
| R26-191 | `apps/worker/src/__tests__/operational-harness-homolog.integration.test.ts:148` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_EXIT_ERROR_EVENT |
| R26-192 | `apps/worker/src/__tests__/operational-harness-homolog.integration.test.ts:149` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_EXIT_ERROR_EVENT |
| R26-193 | `apps/worker/src/__tests__/operational-harness-homolog.integration.test.ts:151` | unknown | UNRESOLVED | CHILD_HANDLE_RETURN |
| R26-194 | `apps/worker/src/__tests__/operational-harness-process-restart.integration.test.ts:132` | unknown | UNRESOLVED | PROCESS_LAUNCH |
| R26-195 | `apps/worker/src/__tests__/operational-harness-process-restart.integration.test.ts:142` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_STDIO_EVENT |
| R26-196 | `apps/worker/src/__tests__/operational-harness-process-restart.integration.test.ts:145` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_STDIO_EVENT |
| R26-197 | `apps/worker/src/__tests__/operational-harness-process-restart.integration.test.ts:149` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_EXIT_ERROR_EVENT |
| R26-198 | `apps/worker/src/__tests__/operational-harness-process-restart.integration.test.ts:150` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_EXIT_ERROR_EVENT |
| R26-199 | `apps/worker/src/__tests__/operational-harness-process-restart.integration.test.ts:152` | unknown | UNRESOLVED | CHILD_HANDLE_RETURN |
| R26-200 | `apps/worker/src/__tests__/startup-error-redaction.test.ts:98` | unknown | UNRESOLVED | PROCESS_LAUNCH |
| R26-201 | `apps/worker/src/__tests__/startup-error-redaction.test.ts:121` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_STDIO_EVENT |
| R26-202 | `apps/worker/src/__tests__/startup-error-redaction.test.ts:124` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_STDIO_EVENT |
| R26-203 | `apps/worker/src/__tests__/startup-error-redaction.test.ts:129` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_EXIT_ERROR_EVENT |
| R26-204 | `apps/worker/src/__tests__/startup-error-redaction.test.ts:130` | positive | ACCEPTED_FINITE_POSITIVE | CHILD_EXIT_ERROR_EVENT |
| R26-205 | `apps/worker/src/homolog-worker.ts:275` | positive | ACCEPTED_FINITE_POSITIVE | PROCESS_TO_SELECTED_SIGNAL_SOURCE |
| R26-206 | `apps/worker/src/main.ts:185` | positive | ACCEPTED_FINITE_POSITIVE | PROCESS_TO_SELECTED_SIGNAL_SOURCE |
| R26-207 | `apps/worker/src/main.ts:267` | positive | ACCEPTED_FINITE_POSITIVE | PROCESS_TO_SELECTED_SIGNAL_SOURCE |
| R26-208 | `apps/worker/src/main.ts:385` | positive | ACCEPTED_FINITE_POSITIVE | PROCESS_TO_SELECTED_SIGNAL_SOURCE |
| R26-209 | `apps/worker/src/main.ts:490` | positive | ACCEPTED_FINITE_POSITIVE | PROCESS_TO_SELECTED_SIGNAL_SOURCE |
| R26-210 | `packages/shared/dist/canonical.js:24` | positive | ACCEPTED_FINITE_POSITIVE | PROTOTYPE_BOOLEAN_GUARD |
| R26-211 | `packages/shared/dist/canonical.js:25` | positive | ACCEPTED_FINITE_POSITIVE | PROTOTYPE_BOOLEAN_GUARD |
| R26-212 | `packages/shared/dist/canonical.js:25` | positive | ACCEPTED_FINITE_POSITIVE | PROTOTYPE_BOOLEAN_GUARD |
| R26-213 | `packages/harness/dist/capability-boundary.js:427` | positive | ACCEPTED_FINITE_POSITIVE | DESCRIPTOR_JSON_DATA |
| R26-214 | `packages/harness/dist/capability-boundary.js:428` | positive | ACCEPTED_FINITE_POSITIVE | DESCRIPTOR_JSON_DATA |
| R26-215 | `packages/harness/dist/capability-boundary.js:428` | positive | ACCEPTED_FINITE_POSITIVE | DESCRIPTOR_JSON_DATA |
| R26-216 | `packages/harness/dist/capability-boundary.js:431` | positive | ACCEPTED_FINITE_POSITIVE | DESCRIPTOR_JSON_DATA |
| R26-217 | `packages/harness/dist/capability-boundary.js:458` | positive | ACCEPTED_FINITE_POSITIVE | PROTOTYPE_BOOLEAN_GUARD |
| R26-218 | `packages/harness/dist/capability-boundary.js:459` | positive | ACCEPTED_FINITE_POSITIVE | PROTOTYPE_BOOLEAN_GUARD |
| R26-219 | `packages/harness/dist/capability-boundary.js:459` | positive | ACCEPTED_FINITE_POSITIVE | PROTOTYPE_BOOLEAN_GUARD |
| R26-220 | `packages/platform/dist/tool-invocation-boundary.js:157` | positive | ACCEPTED_FINITE_POSITIVE | PROTOTYPE_BOOLEAN_GUARD |
| R26-221 | `packages/platform/dist/tool-invocation-boundary.js:158` | positive | ACCEPTED_FINITE_POSITIVE | PROTOTYPE_BOOLEAN_GUARD |
| R26-222 | `packages/platform/dist/tool-invocation-boundary.js:158` | positive | ACCEPTED_FINITE_POSITIVE | PROTOTYPE_BOOLEAN_GUARD |

## Row judgments

**R26-001 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/shared declares zod in {'dependencies': '^4.3.6'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for zod from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-002 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/shared declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-003 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/approval-engine declares zod in {'dependencies': '^4.3.6'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for zod from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-004 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/approval-engine declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-005 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/channel-gateway declares zod in {'dependencies': '^4.3.6'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for zod from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-006 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/channel-gateway declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-007 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/model-gateway declares zod in {'dependencies': '^4.3.6'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for zod from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-008 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/model-gateway declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-009 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/observability declares @opentelemetry/api in {'dependencies': '^1.9.0'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for @opentelemetry/api from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-010 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/observability declares @opentelemetry/sdk-metrics in {'dependencies': '^2.11.0'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for @opentelemetry/sdk-metrics from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-011 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/observability declares @opentelemetry/sdk-trace-base in {'dependencies': '^2.11.0'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for @opentelemetry/sdk-trace-base from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-012 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/observability declares zod in {'dependencies': '^4.3.6'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for zod from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-013 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/observability declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-014 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/policy-engine declares zod in {'dependencies': '^4.3.6'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for zod from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-015 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/policy-engine declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-016 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/agent-runtime declares zod in {'dependencies': '^4.3.6'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for zod from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-017 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/agent-runtime declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-018 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/harness-orchestrator declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-019 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/harness declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-020 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/platform declares zod in {'dependencies': '^4.3.6'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for zod from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-021 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/rag declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-022 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/platform declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-023 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/persistence declares pg in {'dependencies': '^8.20.0'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for pg from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-024 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/persistence declares zod in {'dependencies': '^4.3.6'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for zod from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-025 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/persistence declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-026 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/policy declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-027 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/agent-core declares zod in {'dependencies': '^4.3.6'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for zod from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-028 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/agent-core declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-029 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/legacy-secretary-journeys declares fastify in {'devDependencies': '^5.12.3'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for fastify from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-030 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/legacy-secretary-journeys declares pg in {'devDependencies': '^8.20.0'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for pg from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-031 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/legacy-secretary-journeys declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-032 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/legacy-secretary-profile declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-033 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/api declares fastify in {'dependencies': '^5.12.5'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for fastify from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-034 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/api declares pg in {'dependencies': '^8.20.0'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for pg from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-035 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/api declares zod in {'dependencies': '^4.3.6'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for zod from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-036 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/api declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-037 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/web declares @fontsource-variable/inter in {'dependencies': '5.3.0'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for @fontsource-variable/inter from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-038 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/web declares @tanstack/react-query in {'dependencies': '^5.100.6'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for @tanstack/react-query from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-039 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/web declares react in {'dependencies': '^19.2.5'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for react from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-040 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/web declares react-dom in {'dependencies': '^19.2.5'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for react-dom from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-041 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/web declares @testing-library/react in {'devDependencies': '^16.3.2'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for @testing-library/react from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-042 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/web declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-043 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/worker declares pg in {'dependencies': '^8.20.0'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for pg from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-044 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/worker declares zod in {'dependencies': '^4.3.6'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for zod from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-045 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/worker declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-046 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/adapters declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-047 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/agent-evals declares zod in {'dependencies': '^4.3.6'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for zod from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-048 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/agent-evals declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-049 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/chaos declares pg in {'dependencies': '^8.20.0'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for pg from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-050 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/chaos declares @types/pg in {'devDependencies': '^8.20.0'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for @types/pg from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-051 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/chaos declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-052 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/conversation declares zod in {'dependencies': '^4.3.6'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for zod from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-053 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/conversation declares pg in {'devDependencies': '^8.20.0'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for pg from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-054 — ACCEPT (UNRESOLVED)**

Actual manifest @cvg/conversation declares vitest in {'devDependencies': '^4.1.11'}. JSON declaration is not runtime implementation or transitive closure proof. R30 supplemental CJS/ESM results and physical entry/package hashes were independently reproduced; these resolve identities, not transitive closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound relevant transitive runtime/module-reference closure for vitest from the R30-bound entries/package export conditions; keep any mode resolution failure explicit. Resolve types/runtime distinctions within that graph. The now-reproduced entry identities and versions do not close the edge.

**R26-055 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Own descriptor is checked for a value field; accessors fail. That value is only passed to the same stableSerialize body, which rejects function/undefined/symbol/bigint before object recursion and returns JSON text, subsequently parsed by cloneJsonValue. No reflected callable is invoked, returned as a callable, or used as a module specifier at these sites. Data consumption only, not a proof that unknown input objects, Proxy traps or capability implementation callbacks are free of side effects.

**R26-056 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Own descriptor is checked for a value field; accessors fail. That value is only passed to the same stableSerialize body, which rejects function/undefined/symbol/bigint before object recursion and returns JSON text, subsequently parsed by cloneJsonValue. No reflected callable is invoked, returned as a callable, or used as a module specifier at these sites. Data consumption only, not a proof that unknown input objects, Proxy traps or capability implementation callbacks are free of side effects.

**R26-057 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Own descriptor is checked for a value field; accessors fail. That value is only passed to the same stableSerialize body, which rejects function/undefined/symbol/bigint before object recursion and returns JSON text, subsequently parsed by cloneJsonValue. No reflected callable is invoked, returned as a callable, or used as a module specifier at these sites. Data consumption only, not a proof that unknown input objects, Proxy traps or capability implementation callbacks are free of side effects.

**R26-058 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Own descriptor is checked for a value field; accessors fail. That value is only passed to the same stableSerialize body, which rejects function/undefined/symbol/bigint before object recursion and returns JSON text, subsequently parsed by cloneJsonValue. No reflected callable is invoked, returned as a callable, or used as a module specifier at these sites. Data consumption only, not a proof that unknown input objects, Proxy traps or capability implementation callbacks are free of side effects.

**R26-059 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

The reflected prototype has only strict comparisons with Object.prototype/null in the actual function. Its identity is neither invoked nor forwarded; the comparison chooses a JSON/object guard branch. Actual caller bodies are inspected, not inferred from the object type annotation. The guard accepts/rejects shape; it does not certify getters, Proxy traps or external handlers as an arbitrary-JavaScript sandbox.

**R26-060 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

The reflected prototype has only strict comparisons with Object.prototype/null in the actual function. Its identity is neither invoked nor forwarded; the comparison chooses a JSON/object guard branch. Actual caller bodies are inspected, not inferred from the object type annotation. The guard accepts/rejects shape; it does not certify getters, Proxy traps or external handlers as an arbitrary-JavaScript sandbox.

**R26-061 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

The reflected prototype has only strict comparisons with Object.prototype/null in the actual function. Its identity is neither invoked nor forwarded; the comparison chooses a JSON/object guard branch. Actual caller bodies are inspected, not inferred from the object type annotation. The guard accepts/rejects shape; it does not certify getters, Proxy traps or external handlers as an arbitrary-JavaScript sandbox.

**R26-062 — ACCEPT (UNRESOLVED)**

Actual imported spawnSync creates a separate executor with the preserved argv/cwd/env AST. Concrete source entry or -e template and tsx loader acquisition remain without a separately adjudicated physical module closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Bind the exact launcher, argv/template, effective cwd and loader/entry module targets to their hash-bound relevant module graph. Inherited env expressions are preserved statically, not read or executed.

**R26-063 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local const is actually initialized by node:child_process.spawnSync. The selected error/status/stdout/stderr fields feed expect or JSON.parse (with trim at R26-066). Node22 builtin implementation converts output buffers with the selected encoding and assigns stdout/stderr; the launcher itself remains a separately unresolved executor. No shown output is evaluated or imported. This data consumer does not accept the upstream launch, -e script, --import tsx or its closure. Native result provenance is trusted Node22 plus inspected builtin code, not a TypeScript declaration alone.

**R26-064 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local const is actually initialized by node:child_process.spawnSync. The selected error/status/stdout/stderr fields feed expect or JSON.parse (with trim at R26-066). Node22 builtin implementation converts output buffers with the selected encoding and assigns stdout/stderr; the launcher itself remains a separately unresolved executor. No shown output is evaluated or imported. This data consumer does not accept the upstream launch, -e script, --import tsx or its closure. Native result provenance is trusted Node22 plus inspected builtin code, not a TypeScript declaration alone.

**R26-065 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local const is actually initialized by node:child_process.spawnSync. The selected error/status/stdout/stderr fields feed expect or JSON.parse (with trim at R26-066). Node22 builtin implementation converts output buffers with the selected encoding and assigns stdout/stderr; the launcher itself remains a separately unresolved executor. No shown output is evaluated or imported. This data consumer does not accept the upstream launch, -e script, --import tsx or its closure. Native result provenance is trusted Node22 plus inspected builtin code, not a TypeScript declaration alone.

**R26-066 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local const is actually initialized by node:child_process.spawnSync. The selected error/status/stdout/stderr fields feed expect or JSON.parse (with trim at R26-066). Node22 builtin implementation converts output buffers with the selected encoding and assigns stdout/stderr; the launcher itself remains a separately unresolved executor. No shown output is evaluated or imported. This data consumer does not accept the upstream launch, -e script, --import tsx or its closure. Native result provenance is trusted Node22 plus inspected builtin code, not a TypeScript declaration alone.

**R26-067 — ACCEPT (UNRESOLVED)**

Actual node:child_process.execFile is passed to promisify and retained as exec. Real local callers invoke openssl and Node with --import loader and a generated TLS child template. This is executor transfer, not matcher/data identity. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound finite exec invocation plan, generated child/template and ssrf-node.ts import target, effective tsx loader/entry closure. No key generation, TLS fixture execution or network is needed in this review.

**R26-068 — ACCEPT (UNRESOLVED)**

Actual imported spawnSync creates a separate executor with the preserved argv/cwd/env AST. Concrete source entry or -e template and tsx loader acquisition remain without a separately adjudicated physical module closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Bind the exact launcher, argv/template, effective cwd and loader/entry module targets to their hash-bound relevant module graph. Inherited env expressions are preserved statically, not read or executed.

**R26-069 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local const is actually initialized by node:child_process.spawnSync. The selected error/status/stdout/stderr fields feed expect or JSON.parse (with trim at R26-066). Node22 builtin implementation converts output buffers with the selected encoding and assigns stdout/stderr; the launcher itself remains a separately unresolved executor. No shown output is evaluated or imported. This data consumer does not accept the upstream launch, -e script, --import tsx or its closure. Native result provenance is trusted Node22 plus inspected builtin code, not a TypeScript declaration alone.

**R26-070 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local const is actually initialized by node:child_process.spawnSync. The selected error/status/stdout/stderr fields feed expect or JSON.parse (with trim at R26-066). Node22 builtin implementation converts output buffers with the selected encoding and assigns stdout/stderr; the launcher itself remains a separately unresolved executor. No shown output is evaluated or imported. This data consumer does not accept the upstream launch, -e script, --import tsx or its closure. Native result provenance is trusted Node22 plus inspected builtin code, not a TypeScript declaration alone.

**R26-071 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local const is actually initialized by node:child_process.spawnSync. The selected error/status/stdout/stderr fields feed expect or JSON.parse (with trim at R26-066). Node22 builtin implementation converts output buffers with the selected encoding and assigns stdout/stderr; the launcher itself remains a separately unresolved executor. No shown output is evaluated or imported. This data consumer does not accept the upstream launch, -e script, --import tsx or its closure. Native result provenance is trusted Node22 plus inspected builtin code, not a TypeScript declaration alone.

**R26-072 — ACCEPT (UNRESOLVED)**

Actual imported spawnSync creates a separate executor with the preserved argv/cwd/env AST. Concrete source entry or -e template and tsx loader acquisition remain without a separately adjudicated physical module closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Bind the exact launcher, argv/template, effective cwd and loader/entry module targets to their hash-bound relevant module graph. Inherited env expressions are preserved statically, not read or executed.

**R26-073 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local const is actually initialized by node:child_process.spawnSync. The selected error/status/stdout/stderr fields feed expect or JSON.parse (with trim at R26-066). Node22 builtin implementation converts output buffers with the selected encoding and assigns stdout/stderr; the launcher itself remains a separately unresolved executor. No shown output is evaluated or imported. This data consumer does not accept the upstream launch, -e script, --import tsx or its closure. Native result provenance is trusted Node22 plus inspected builtin code, not a TypeScript declaration alone.

**R26-074 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local const is actually initialized by node:child_process.spawnSync. The selected error/status/stdout/stderr fields feed expect or JSON.parse (with trim at R26-066). Node22 builtin implementation converts output buffers with the selected encoding and assigns stdout/stderr; the launcher itself remains a separately unresolved executor. No shown output is evaluated or imported. This data consumer does not accept the upstream launch, -e script, --import tsx or its closure. Native result provenance is trusted Node22 plus inspected builtin code, not a TypeScript declaration alone.

**R26-075 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes the Function identity to expect.any, not to an invocation/new expression. Installed Any stores sample, branches on sample === Function and returns a typeof test. Formatting uses name/Function.prototype.toString.call; it does not compile text with Function. Entry wiring and actual matcher bodies were inspected. Function constructor remains an evaluator in other roles; this acceptance covers only the exact matcher argument.

**R26-076 — ACCEPT (UNRESOLVED)**

Actual Proxy.get takes the variable property parameter and Reflect.get returns the target member; callers bind/return it or use it as Reflect.apply callee. Actual target/store construction and consumers are visible in the preserved caller AST. Runtime store method bodies and finite consumer keys are not supplied as accepted proof. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Enumerate concrete keys used by ensureControlledAgentPreset or buildServer for this exact target/store; inspect hash-bound returned method bodies and call edges. This is a concrete callable-transfer gap, not a generic Proxy/callback absence obligation.

**R26-077 — ACCEPT (UNRESOLVED)**

Actual Proxy.get takes the variable property parameter and Reflect.get returns the target member; callers bind/return it or use it as Reflect.apply callee. Actual target/store construction and consumers are visible in the preserved caller AST. Runtime store method bodies and finite consumer keys are not supplied as accepted proof. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Enumerate concrete keys used by ensureControlledAgentPreset or buildServer for this exact target/store; inspect hash-bound returned method bodies and call edges. This is a concrete callable-transfer gap, not a generic Proxy/callback absence obligation.

**R26-078 — ACCEPT (UNRESOLVED)**

Actual Proxy.get takes the variable property parameter and Reflect.get returns the target member; callers bind/return it or use it as Reflect.apply callee. Actual target/store construction and consumers are visible in the preserved caller AST. Runtime store method bodies and finite consumer keys are not supplied as accepted proof. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Enumerate concrete keys used by ensureControlledAgentPreset or buildServer for this exact target/store; inspect hash-bound returned method bodies and call edges. This is a concrete callable-transfer gap, not a generic Proxy/callback absence obligation.

**R26-079 — ACCEPT (UNRESOLVED)**

Actual Proxy.get takes the variable property parameter and Reflect.get returns the target member; callers bind/return it or use it as Reflect.apply callee. Actual target/store construction and consumers are visible in the preserved caller AST. Runtime store method bodies and finite consumer keys are not supplied as accepted proof. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Enumerate concrete keys used by ensureControlledAgentPreset or buildServer for this exact target/store; inspect hash-bound returned method bodies and call edges. This is a concrete callable-transfer gap, not a generic Proxy/callback absence obligation.

**R26-080 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

The reflected prototype has only strict comparisons with Object.prototype/null in the actual function. Its identity is neither invoked nor forwarded; the comparison chooses a JSON/object guard branch. Actual caller bodies are inspected, not inferred from the object type annotation. The guard accepts/rejects shape; it does not certify getters, Proxy traps or external handlers as an arbitrary-JavaScript sandbox.

**R26-081 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

The reflected prototype has only strict comparisons with Object.prototype/null in the actual function. Its identity is neither invoked nor forwarded; the comparison chooses a JSON/object guard branch. Actual caller bodies are inspected, not inferred from the object type annotation. The guard accepts/rejects shape; it does not certify getters, Proxy traps or external handlers as an arbitrary-JavaScript sandbox.

**R26-082 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

The reflected prototype has only strict comparisons with Object.prototype/null in the actual function. Its identity is neither invoked nor forwarded; the comparison chooses a JSON/object guard branch. Actual caller bodies are inspected, not inferred from the object type annotation. The guard accepts/rejects shape; it does not certify getters, Proxy traps or external handlers as an arbitrary-JavaScript sandbox.

**R26-083 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

The reflected prototype has only strict comparisons with Object.prototype/null in the actual function. Its identity is neither invoked nor forwarded; the comparison chooses a JSON/object guard branch. Actual caller bodies are inspected, not inferred from the object type annotation. The guard accepts/rejects shape; it does not certify getters, Proxy traps or external handlers as an arbitrary-JavaScript sandbox.

**R26-084 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

The reflected prototype has only strict comparisons with Object.prototype/null in the actual function. Its identity is neither invoked nor forwarded; the comparison chooses a JSON/object guard branch. Actual caller bodies are inspected, not inferred from the object type annotation. The guard accepts/rejects shape; it does not certify getters, Proxy traps or external handlers as an arbitrary-JavaScript sandbox.

**R26-085 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

The reflected prototype has only strict comparisons with Object.prototype/null in the actual function. Its identity is neither invoked nor forwarded; the comparison chooses a JSON/object guard branch. Actual caller bodies are inspected, not inferred from the object type annotation. The guard accepts/rejects shape; it does not certify getters, Proxy traps or external handlers as an arbitrary-JavaScript sandbox.

**R26-086 — ACCEPT (UNRESOLVED)**

Actual Proxy.get takes the variable property parameter and Reflect.get returns the target member; callers bind/return it or use it as Reflect.apply callee. Actual target/store construction and consumers are visible in the preserved caller AST. Runtime store method bodies and finite consumer keys are not supplied as accepted proof. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Enumerate concrete keys used by ensureControlledAgentPreset or buildServer for this exact target/store; inspect hash-bound returned method bodies and call edges. This is a concrete callable-transfer gap, not a generic Proxy/callback absence obligation.

**R26-087 — ACCEPT (UNRESOLVED)**

Actual Proxy.get takes the variable property parameter and Reflect.get returns the target member; callers bind/return it or use it as Reflect.apply callee. Actual target/store construction and consumers are visible in the preserved caller AST. Runtime store method bodies and finite consumer keys are not supplied as accepted proof. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Enumerate concrete keys used by ensureControlledAgentPreset or buildServer for this exact target/store; inspect hash-bound returned method bodies and call edges. This is a concrete callable-transfer gap, not a generic Proxy/callback absence obligation.

**R26-088 — ACCEPT (UNRESOLVED)**

Actual Proxy.get takes the variable property parameter and Reflect.get returns the target member; callers bind/return it or use it as Reflect.apply callee. Actual target/store construction and consumers are visible in the preserved caller AST. Runtime store method bodies and finite consumer keys are not supplied as accepted proof. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Enumerate concrete keys used by ensureControlledAgentPreset or buildServer for this exact target/store; inspect hash-bound returned method bodies and call edges. This is a concrete callable-transfer gap, not a generic Proxy/callback absence obligation.

**R26-089 — ACCEPT (UNRESOLVED)**

Actual Proxy.get takes the variable property parameter and Reflect.get returns the target member; callers bind/return it or use it as Reflect.apply callee. Actual target/store construction and consumers are visible in the preserved caller AST. Runtime store method bodies and finite consumer keys are not supplied as accepted proof. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Enumerate concrete keys used by ensureControlledAgentPreset or buildServer for this exact target/store; inspect hash-bound returned method bodies and call edges. This is a concrete callable-transfer gap, not a generic Proxy/callback absence obligation.

**R26-090 — ACCEPT (UNRESOLVED)**

Actual imported spawn creates a separate executor with the preserved argv/cwd/env AST. Concrete source entry or -e template and tsx loader acquisition remain without a separately adjudicated physical module closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Bind the exact launcher, argv/template, effective cwd and loader/entry module targets to their hash-bound relevant module graph. Inherited env expressions are preserved statically, not read or executed.

**R26-091 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local child const comes from the actual imported spawn binding. A literal data event on stdout/stderr has a callback that only adds String(chunk) to local output. Node22 Readable.on delegates to Stream.on and may resume the stream; this is an event/data role, with no new loader/evaluator selection in the callback. Spawn and returned handle dispositions remain unresolved; this does not attest to launched-program behavior or actual child completion.

**R26-092 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local child const comes from the actual imported spawn binding. A literal data event on stdout/stderr has a callback that only adds String(chunk) to local output. Node22 Readable.on delegates to Stream.on and may resume the stream; this is an event/data role, with no new loader/evaluator selection in the callback. Spawn and returned handle dispositions remain unresolved; this does not attest to launched-program behavior or actual child completion.

**R26-093 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Actual child const comes from imported spawn. once selects a literal error or close event. Shown callbacks reject the enclosing Promise or resolve exit/code/signal/output metadata, clearing a timer where present. Trusted Node22 ChildProcess.once is the actual EventEmitter.once implementation. Callback/event role only; upstream executor and returned child handles are not accepted by this row.

**R26-094 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Actual child const comes from imported spawn. once selects a literal error or close event. Shown callbacks reject the enclosing Promise or resolve exit/code/signal/output metadata, clearing a timer where present. Trusted Node22 ChildProcess.once is the actual EventEmitter.once implementation. Callback/event role only; upstream executor and returned child handles are not accepted by this row.

**R26-095 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

process is the thisArg of process.once.bind. Actual local bound once is used only for the event/listener fallback of the signal mock. Trusted Node22 process.once equals EventEmitter.once. No evaluator or loader is selected from this receiver. Bound receiver retention is real; no general process capability acceptance is issued.

**R26-096 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Actual vi.spyOn selects literal once on process. Installed spy callee was inspected. Mock diverts SIGTERM/SIGINT listeners to the local EventEmitter and falls back to the captured once for other events. Source/dist lifecycle.install discards the returned receiver. Spy restoration and mock contexts/results retain process; finite selected-member analysis does not require absence of that retention.

**R26-097 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

The exact return process is inside the literal once mock; actual imported main installs the shared lifecycle helper, whose install discards source.once return. Installed spy createMock additionally records receiver and return value in public mock state; no concrete subsequent loader/evaluator member acquisition from those records is shown by this finite caller. The returned object is not data-only and is not claimed unretained. This is an exact receiver/result role, not a universal no-escape claim.

**R26-098 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Actual vi.spyOn selects literal exit on process and supplies a callback returning undefined. Caller observes expected numeric exit arguments and calls restoreAllMocks. Actual installed spy retains restoration state for that property; no module loader/evaluator is selected by this argument. No actual process.exit occurred in review. Other process capabilities and vendor closure remain unaccepted.

**R26-099 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local shutdown const is created by createShutdownController imported from @cvg/shared. Package import/default export points to dist/index.js, which re-exports lifecycle.js; src and actual dist callee bodies both implement install using source.once. The returned value is discarded; callback gets signal, not source. Actual options at the six sites use the default SIGTERM/SIGINT set. close/flush/log/exit callbacks are separate lifecycle effects; they are not a universal callback-absence obligation nor accepted execution of shutdown.

**R26-100 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

The reflected prototype has only strict comparisons with Object.prototype/null in the actual function. Its identity is neither invoked nor forwarded; the comparison chooses a JSON/object guard branch. Actual caller bodies are inspected, not inferred from the object type annotation. The guard accepts/rejects shape; it does not certify getters, Proxy traps or external handlers as an arbitrary-JavaScript sandbox.

**R26-101 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

The reflected prototype has only strict comparisons with Object.prototype/null in the actual function. Its identity is neither invoked nor forwarded; the comparison chooses a JSON/object guard branch. Actual caller bodies are inspected, not inferred from the object type annotation. The guard accepts/rejects shape; it does not certify getters, Proxy traps or external handlers as an arbitrary-JavaScript sandbox.

**R26-102 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

The reflected prototype has only strict comparisons with Object.prototype/null in the actual function. Its identity is neither invoked nor forwarded; the comparison chooses a JSON/object guard branch. Actual caller bodies are inspected, not inferred from the object type annotation. The guard accepts/rejects shape; it does not certify getters, Proxy traps or external handlers as an arbitrary-JavaScript sandbox.

**R26-103 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes the Function identity to expect.any, not to an invocation/new expression. Installed Any stores sample, branches on sample === Function and returns a typeof test. Formatting uses name/Function.prototype.toString.call; it does not compile text with Function. Entry wiring and actual matcher bodies were inspected. Function constructor remains an evaluator in other roles; this acceptance covers only the exact matcher argument.

**R26-104 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes the Function identity to expect.any, not to an invocation/new expression. Installed Any stores sample, branches on sample === Function and returns a typeof test. Formatting uses name/Function.prototype.toString.call; it does not compile text with Function. Entry wiring and actual matcher bodies were inspected. Function constructor remains an evaluator in other roles; this acceptance covers only the exact matcher argument.

**R26-105 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-106 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-107 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-108 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-109 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-110 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-111 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-112 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-113 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-114 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-115 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-116 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-117 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-118 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-119 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-120 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-121 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-122 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-123 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-124 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-125 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-126 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-127 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-128 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-129 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-130 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-131 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-132 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-133 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-134 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-135 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-136 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-137 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-138 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-139 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-140 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-141 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-142 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-143 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-144 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-145 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-146 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-147 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-148 — ACCEPT (UNRESOLVED)**

Actual runtimeBootstrapTokenProvider aliases globalThis, truthiness-tests an injected provider and calls it without an implementation binding. Fallback token is read/deleted and load calls trim/getSession; the type cast does not establish runtime provider or token identity. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound concrete injector/provider implementation and global property producer, runtime returned token validation and finite consumers. No tokens or private environment values were read.

**R26-149 — ACCEPT (UNRESOLVED)**

Actual runtimeBootstrapTokenProvider aliases globalThis, truthiness-tests an injected provider and calls it without an implementation binding. Fallback token is read/deleted and load calls trim/getSession; the type cast does not establish runtime provider or token identity. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound concrete injector/provider implementation and global property producer, runtime returned token validation and finite consumers. No tokens or private environment values were read.

**R26-150 — ACCEPT (UNRESOLVED)**

Actual runtimeBootstrapTokenProvider aliases globalThis, truthiness-tests an injected provider and calls it without an implementation binding. Fallback token is read/deleted and load calls trim/getSession; the type cast does not establish runtime provider or token identity. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound concrete injector/provider implementation and global property producer, runtime returned token validation and finite consumers. No tokens or private environment values were read.

**R26-151 — ACCEPT (UNRESOLVED)**

Actual runtimeBootstrapTokenProvider aliases globalThis, truthiness-tests an injected provider and calls it without an implementation binding. Fallback token is read/deleted and load calls trim/getSession; the type cast does not establish runtime provider or token identity. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound concrete injector/provider implementation and global property producer, runtime returned token validation and finite consumers. No tokens or private environment values were read.

**R26-152 — ACCEPT (UNRESOLVED)**

Actual runtimeBootstrapTokenProvider aliases globalThis, truthiness-tests an injected provider and calls it without an implementation binding. Fallback token is read/deleted and load calls trim/getSession; the type cast does not establish runtime provider or token identity. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Hash-bound concrete injector/provider implementation and global property producer, runtime returned token validation and finite consumers. No tokens or private environment values were read.

**R26-153 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-154 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-155 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-156 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-157 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-158 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-159 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-160 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-161 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-162 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-163 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-164 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-165 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-166 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-167 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Caller passes globalThis and exactly the literal fetch key to vi.spyOn imported from vitest. Actual entry/re-export wiring reaches installed @vitest/spy.spyOn. getDescriptor uses that key; restoration redefines/deletes that key. Original implementation, static descriptors, receiver and mock state can be retained. No concrete require/eval/Function acquisition is selected by these observed namespace arguments. Only this selected reference role is accepted; callbacks, fetch behavior and the rest of the installed Vitest closure are not accepted. Receiver retention is real and allowed here.

**R26-168 — ACCEPT (UNRESOLVED)**

Actual imported spawn creates a separate executor with the preserved argv/cwd/env AST. Concrete source entry or -e template and tsx loader acquisition remain without a separately adjudicated physical module closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Bind the exact launcher, argv/template, effective cwd and loader/entry module targets to their hash-bound relevant module graph. Inherited env expressions are preserved statically, not read or executed.

**R26-169 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local child const comes from the actual imported spawn binding. A literal data event on stdout/stderr has a callback that only adds String(chunk) to local output. Node22 Readable.on delegates to Stream.on and may resume the stream; this is an event/data role, with no new loader/evaluator selection in the callback. Spawn and returned handle dispositions remain unresolved; this does not attest to launched-program behavior or actual child completion.

**R26-170 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local child const comes from the actual imported spawn binding. A literal data event on stdout/stderr has a callback that only adds String(chunk) to local output. Node22 Readable.on delegates to Stream.on and may resume the stream; this is an event/data role, with no new loader/evaluator selection in the callback. Spawn and returned handle dispositions remain unresolved; this does not attest to launched-program behavior or actual child completion.

**R26-171 — ACCEPT (UNRESOLVED)**

Actual returned object exposes the live spawn child handle together with output/exit helpers. Current evidence for event/data consumers does not adjudicate the callers selecting kill/events or any executor-related capability on the escaped handle. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Finite downstream caller/member uses of this returned child handle and the separate launched-entry/loader module plan.

**R26-172 — ACCEPT (UNRESOLVED)**

Actual imported spawn creates a separate executor with the preserved argv/cwd/env AST. Concrete source entry or -e template and tsx loader acquisition remain without a separately adjudicated physical module closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Bind the exact launcher, argv/template, effective cwd and loader/entry module targets to their hash-bound relevant module graph. Inherited env expressions are preserved statically, not read or executed.

**R26-173 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local child const comes from the actual imported spawn binding. A literal data event on stdout/stderr has a callback that only adds String(chunk) to local output. Node22 Readable.on delegates to Stream.on and may resume the stream; this is an event/data role, with no new loader/evaluator selection in the callback. Spawn and returned handle dispositions remain unresolved; this does not attest to launched-program behavior or actual child completion.

**R26-174 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local child const comes from the actual imported spawn binding. A literal data event on stdout/stderr has a callback that only adds String(chunk) to local output. Node22 Readable.on delegates to Stream.on and may resume the stream; this is an event/data role, with no new loader/evaluator selection in the callback. Spawn and returned handle dispositions remain unresolved; this does not attest to launched-program behavior or actual child completion.

**R26-175 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Actual spawn handle selects only kill with the literal SIGKILL. Trusted Node22 ChildProcess.kill converts the signal and invokes the existing native handle kill; it may emit error. This site does not acquire or launch a module. Termination behavior only in the finite reference sense; no process was spawned or killed by this review.

**R26-176 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Actual child const comes from imported spawn. once selects a literal error or close event. Shown callbacks reject the enclosing Promise or resolve exit/code/signal/output metadata, clearing a timer where present. Trusted Node22 ChildProcess.once is the actual EventEmitter.once implementation. Callback/event role only; upstream executor and returned child handles are not accepted by this row.

**R26-177 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Actual child const comes from imported spawn. once selects a literal error or close event. Shown callbacks reject the enclosing Promise or resolve exit/code/signal/output metadata, clearing a timer where present. Trusted Node22 ChildProcess.once is the actual EventEmitter.once implementation. Callback/event role only; upstream executor and returned child handles are not accepted by this row.

**R26-178 — ACCEPT (UNRESOLVED)**

Actual imported spawn creates a separate executor with the preserved argv/cwd/env AST. Concrete source entry or -e template and tsx loader acquisition remain without a separately adjudicated physical module closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Bind the exact launcher, argv/template, effective cwd and loader/entry module targets to their hash-bound relevant module graph. Inherited env expressions are preserved statically, not read or executed.

**R26-179 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local child const comes from the actual imported spawn binding. A literal data event on stdout/stderr has a callback that only adds String(chunk) to local output. Node22 Readable.on delegates to Stream.on and may resume the stream; this is an event/data role, with no new loader/evaluator selection in the callback. Spawn and returned handle dispositions remain unresolved; this does not attest to launched-program behavior or actual child completion.

**R26-180 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local child const comes from the actual imported spawn binding. A literal data event on stdout/stderr has a callback that only adds String(chunk) to local output. Node22 Readable.on delegates to Stream.on and may resume the stream; this is an event/data role, with no new loader/evaluator selection in the callback. Spawn and returned handle dispositions remain unresolved; this does not attest to launched-program behavior or actual child completion.

**R26-181 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Actual child const comes from imported spawn. once selects a literal error or close event. Shown callbacks reject the enclosing Promise or resolve exit/code/signal/output metadata, clearing a timer where present. Trusted Node22 ChildProcess.once is the actual EventEmitter.once implementation. Callback/event role only; upstream executor and returned child handles are not accepted by this row.

**R26-182 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Actual child const comes from imported spawn. once selects a literal error or close event. Shown callbacks reject the enclosing Promise or resolve exit/code/signal/output metadata, clearing a timer where present. Trusted Node22 ChildProcess.once is the actual EventEmitter.once implementation. Callback/event role only; upstream executor and returned child handles are not accepted by this row.

**R26-183 — ACCEPT (UNRESOLVED)**

Actual imported spawn creates a separate executor with the preserved argv/cwd/env AST. Concrete source entry or -e template and tsx loader acquisition remain without a separately adjudicated physical module closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Bind the exact launcher, argv/template, effective cwd and loader/entry module targets to their hash-bound relevant module graph. Inherited env expressions are preserved statically, not read or executed.

**R26-184 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local child const comes from the actual imported spawn binding. A literal data event on stdout/stderr has a callback that only adds String(chunk) to local output. Node22 Readable.on delegates to Stream.on and may resume the stream; this is an event/data role, with no new loader/evaluator selection in the callback. Spawn and returned handle dispositions remain unresolved; this does not attest to launched-program behavior or actual child completion.

**R26-185 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local child const comes from the actual imported spawn binding. A literal data event on stdout/stderr has a callback that only adds String(chunk) to local output. Node22 Readable.on delegates to Stream.on and may resume the stream; this is an event/data role, with no new loader/evaluator selection in the callback. Spawn and returned handle dispositions remain unresolved; this does not attest to launched-program behavior or actual child completion.

**R26-186 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Actual child const comes from imported spawn. once selects a literal error or close event. Shown callbacks reject the enclosing Promise or resolve exit/code/signal/output metadata, clearing a timer where present. Trusted Node22 ChildProcess.once is the actual EventEmitter.once implementation. Callback/event role only; upstream executor and returned child handles are not accepted by this row.

**R26-187 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Actual child const comes from imported spawn. once selects a literal error or close event. Shown callbacks reject the enclosing Promise or resolve exit/code/signal/output metadata, clearing a timer where present. Trusted Node22 ChildProcess.once is the actual EventEmitter.once implementation. Callback/event role only; upstream executor and returned child handles are not accepted by this row.

**R26-188 — ACCEPT (UNRESOLVED)**

Actual imported spawn creates a separate executor with the preserved argv/cwd/env AST. Concrete source entry or -e template and tsx loader acquisition remain without a separately adjudicated physical module closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Bind the exact launcher, argv/template, effective cwd and loader/entry module targets to their hash-bound relevant module graph. Inherited env expressions are preserved statically, not read or executed.

**R26-189 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local child const comes from the actual imported spawn binding. A literal data event on stdout/stderr has a callback that only adds String(chunk) to local output. Node22 Readable.on delegates to Stream.on and may resume the stream; this is an event/data role, with no new loader/evaluator selection in the callback. Spawn and returned handle dispositions remain unresolved; this does not attest to launched-program behavior or actual child completion.

**R26-190 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local child const comes from the actual imported spawn binding. A literal data event on stdout/stderr has a callback that only adds String(chunk) to local output. Node22 Readable.on delegates to Stream.on and may resume the stream; this is an event/data role, with no new loader/evaluator selection in the callback. Spawn and returned handle dispositions remain unresolved; this does not attest to launched-program behavior or actual child completion.

**R26-191 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Actual child const comes from imported spawn. once selects a literal error or close event. Shown callbacks reject the enclosing Promise or resolve exit/code/signal/output metadata, clearing a timer where present. Trusted Node22 ChildProcess.once is the actual EventEmitter.once implementation. Callback/event role only; upstream executor and returned child handles are not accepted by this row.

**R26-192 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Actual child const comes from imported spawn. once selects a literal error or close event. Shown callbacks reject the enclosing Promise or resolve exit/code/signal/output metadata, clearing a timer where present. Trusted Node22 ChildProcess.once is the actual EventEmitter.once implementation. Callback/event role only; upstream executor and returned child handles are not accepted by this row.

**R26-193 — ACCEPT (UNRESOLVED)**

Actual returned object exposes the live spawn child handle together with output/exit helpers. Current evidence for event/data consumers does not adjudicate the callers selecting kill/events or any executor-related capability on the escaped handle. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Finite downstream caller/member uses of this returned child handle and the separate launched-entry/loader module plan.

**R26-194 — ACCEPT (UNRESOLVED)**

Actual imported spawn creates a separate executor with the preserved argv/cwd/env AST. Concrete source entry or -e template and tsx loader acquisition remain without a separately adjudicated physical module closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Bind the exact launcher, argv/template, effective cwd and loader/entry module targets to their hash-bound relevant module graph. Inherited env expressions are preserved statically, not read or executed.

**R26-195 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local child const comes from the actual imported spawn binding. A literal data event on stdout/stderr has a callback that only adds String(chunk) to local output. Node22 Readable.on delegates to Stream.on and may resume the stream; this is an event/data role, with no new loader/evaluator selection in the callback. Spawn and returned handle dispositions remain unresolved; this does not attest to launched-program behavior or actual child completion.

**R26-196 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local child const comes from the actual imported spawn binding. A literal data event on stdout/stderr has a callback that only adds String(chunk) to local output. Node22 Readable.on delegates to Stream.on and may resume the stream; this is an event/data role, with no new loader/evaluator selection in the callback. Spawn and returned handle dispositions remain unresolved; this does not attest to launched-program behavior or actual child completion.

**R26-197 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Actual child const comes from imported spawn. once selects a literal error or close event. Shown callbacks reject the enclosing Promise or resolve exit/code/signal/output metadata, clearing a timer where present. Trusted Node22 ChildProcess.once is the actual EventEmitter.once implementation. Callback/event role only; upstream executor and returned child handles are not accepted by this row.

**R26-198 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Actual child const comes from imported spawn. once selects a literal error or close event. Shown callbacks reject the enclosing Promise or resolve exit/code/signal/output metadata, clearing a timer where present. Trusted Node22 ChildProcess.once is the actual EventEmitter.once implementation. Callback/event role only; upstream executor and returned child handles are not accepted by this row.

**R26-199 — ACCEPT (UNRESOLVED)**

Actual returned object exposes the live spawn child handle together with output/exit helpers. Current evidence for event/data consumers does not adjudicate the callers selecting kill/events or any executor-related capability on the escaped handle. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Finite downstream caller/member uses of this returned child handle and the separate launched-entry/loader module plan.

**R26-200 — ACCEPT (UNRESOLVED)**

Actual imported spawn creates a separate executor with the preserved argv/cwd/env AST. Concrete source entry or -e template and tsx loader acquisition remain without a separately adjudicated physical module closure. UNRESOLVED is explicitly retained; acceptance of the I0 unknown disposition grants no positive runtime/module-reference proof.

Missing proof: Bind the exact launcher, argv/template, effective cwd and loader/entry module targets to their hash-bound relevant module graph. Inherited env expressions are preserved statically, not read or executed.

**R26-201 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local child const comes from the actual imported spawn binding. A literal data event on stdout/stderr has a callback that only adds String(chunk) to local output. Node22 Readable.on delegates to Stream.on and may resume the stream; this is an event/data role, with no new loader/evaluator selection in the callback. Spawn and returned handle dispositions remain unresolved; this does not attest to launched-program behavior or actual child completion.

**R26-202 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local child const comes from the actual imported spawn binding. A literal data event on stdout/stderr has a callback that only adds String(chunk) to local output. Node22 Readable.on delegates to Stream.on and may resume the stream; this is an event/data role, with no new loader/evaluator selection in the callback. Spawn and returned handle dispositions remain unresolved; this does not attest to launched-program behavior or actual child completion.

**R26-203 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Actual child const comes from imported spawn. once selects a literal error or close event. Shown callbacks reject the enclosing Promise or resolve exit/code/signal/output metadata, clearing a timer where present. Trusted Node22 ChildProcess.once is the actual EventEmitter.once implementation. Callback/event role only; upstream executor and returned child handles are not accepted by this row.

**R26-204 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Actual child const comes from imported spawn. once selects a literal error or close event. Shown callbacks reject the enclosing Promise or resolve exit/code/signal/output metadata, clearing a timer where present. Trusted Node22 ChildProcess.once is the actual EventEmitter.once implementation. Callback/event role only; upstream executor and returned child handles are not accepted by this row.

**R26-205 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local shutdown const is created by createShutdownController imported from @cvg/shared. Package import/default export points to dist/index.js, which re-exports lifecycle.js; src and actual dist callee bodies both implement install using source.once. The returned value is discarded; callback gets signal, not source. Actual options at the six sites use the default SIGTERM/SIGINT set. close/flush/log/exit callbacks are separate lifecycle effects; they are not a universal callback-absence obligation nor accepted execution of shutdown.

**R26-206 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local shutdown const is created by createShutdownController imported from @cvg/shared. Package import/default export points to dist/index.js, which re-exports lifecycle.js; src and actual dist callee bodies both implement install using source.once. The returned value is discarded; callback gets signal, not source. Actual options at the six sites use the default SIGTERM/SIGINT set. close/flush/log/exit callbacks are separate lifecycle effects; they are not a universal callback-absence obligation nor accepted execution of shutdown.

**R26-207 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local shutdown const is created by createShutdownController imported from @cvg/shared. Package import/default export points to dist/index.js, which re-exports lifecycle.js; src and actual dist callee bodies both implement install using source.once. The returned value is discarded; callback gets signal, not source. Actual options at the six sites use the default SIGTERM/SIGINT set. close/flush/log/exit callbacks are separate lifecycle effects; they are not a universal callback-absence obligation nor accepted execution of shutdown.

**R26-208 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local shutdown const is created by createShutdownController imported from @cvg/shared. Package import/default export points to dist/index.js, which re-exports lifecycle.js; src and actual dist callee bodies both implement install using source.once. The returned value is discarded; callback gets signal, not source. Actual options at the six sites use the default SIGTERM/SIGINT set. close/flush/log/exit callbacks are separate lifecycle effects; they are not a universal callback-absence obligation nor accepted execution of shutdown.

**R26-209 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Local shutdown const is created by createShutdownController imported from @cvg/shared. Package import/default export points to dist/index.js, which re-exports lifecycle.js; src and actual dist callee bodies both implement install using source.once. The returned value is discarded; callback gets signal, not source. Actual options at the six sites use the default SIGTERM/SIGINT set. close/flush/log/exit callbacks are separate lifecycle effects; they are not a universal callback-absence obligation nor accepted execution of shutdown.

**R26-210 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

The reflected prototype has only strict comparisons with Object.prototype/null in the actual function. Its identity is neither invoked nor forwarded; the comparison chooses a JSON/object guard branch. Actual caller bodies are inspected, not inferred from the object type annotation. The guard accepts/rejects shape; it does not certify getters, Proxy traps or external handlers as an arbitrary-JavaScript sandbox.

**R26-211 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

The reflected prototype has only strict comparisons with Object.prototype/null in the actual function. Its identity is neither invoked nor forwarded; the comparison chooses a JSON/object guard branch. Actual caller bodies are inspected, not inferred from the object type annotation. The guard accepts/rejects shape; it does not certify getters, Proxy traps or external handlers as an arbitrary-JavaScript sandbox.

**R26-212 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

The reflected prototype has only strict comparisons with Object.prototype/null in the actual function. Its identity is neither invoked nor forwarded; the comparison chooses a JSON/object guard branch. Actual caller bodies are inspected, not inferred from the object type annotation. The guard accepts/rejects shape; it does not certify getters, Proxy traps or external handlers as an arbitrary-JavaScript sandbox.

**R26-213 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Own descriptor is checked for a value field; accessors fail. That value is only passed to the same stableSerialize body, which rejects function/undefined/symbol/bigint before object recursion and returns JSON text, subsequently parsed by cloneJsonValue. No reflected callable is invoked, returned as a callable, or used as a module specifier at these sites. Data consumption only, not a proof that unknown input objects, Proxy traps or capability implementation callbacks are free of side effects.

**R26-214 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Own descriptor is checked for a value field; accessors fail. That value is only passed to the same stableSerialize body, which rejects function/undefined/symbol/bigint before object recursion and returns JSON text, subsequently parsed by cloneJsonValue. No reflected callable is invoked, returned as a callable, or used as a module specifier at these sites. Data consumption only, not a proof that unknown input objects, Proxy traps or capability implementation callbacks are free of side effects.

**R26-215 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Own descriptor is checked for a value field; accessors fail. That value is only passed to the same stableSerialize body, which rejects function/undefined/symbol/bigint before object recursion and returns JSON text, subsequently parsed by cloneJsonValue. No reflected callable is invoked, returned as a callable, or used as a module specifier at these sites. Data consumption only, not a proof that unknown input objects, Proxy traps or capability implementation callbacks are free of side effects.

**R26-216 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

Own descriptor is checked for a value field; accessors fail. That value is only passed to the same stableSerialize body, which rejects function/undefined/symbol/bigint before object recursion and returns JSON text, subsequently parsed by cloneJsonValue. No reflected callable is invoked, returned as a callable, or used as a module specifier at these sites. Data consumption only, not a proof that unknown input objects, Proxy traps or capability implementation callbacks are free of side effects.

**R26-217 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

The reflected prototype has only strict comparisons with Object.prototype/null in the actual function. Its identity is neither invoked nor forwarded; the comparison chooses a JSON/object guard branch. Actual caller bodies are inspected, not inferred from the object type annotation. The guard accepts/rejects shape; it does not certify getters, Proxy traps or external handlers as an arbitrary-JavaScript sandbox.

**R26-218 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

The reflected prototype has only strict comparisons with Object.prototype/null in the actual function. Its identity is neither invoked nor forwarded; the comparison chooses a JSON/object guard branch. Actual caller bodies are inspected, not inferred from the object type annotation. The guard accepts/rejects shape; it does not certify getters, Proxy traps or external handlers as an arbitrary-JavaScript sandbox.

**R26-219 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

The reflected prototype has only strict comparisons with Object.prototype/null in the actual function. Its identity is neither invoked nor forwarded; the comparison chooses a JSON/object guard branch. Actual caller bodies are inspected, not inferred from the object type annotation. The guard accepts/rejects shape; it does not certify getters, Proxy traps or external handlers as an arbitrary-JavaScript sandbox.

**R26-220 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

The reflected prototype has only strict comparisons with Object.prototype/null in the actual function. Its identity is neither invoked nor forwarded; the comparison chooses a JSON/object guard branch. Actual caller bodies are inspected, not inferred from the object type annotation. The guard accepts/rejects shape; it does not certify getters, Proxy traps or external handlers as an arbitrary-JavaScript sandbox.

**R26-221 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

The reflected prototype has only strict comparisons with Object.prototype/null in the actual function. Its identity is neither invoked nor forwarded; the comparison chooses a JSON/object guard branch. Actual caller bodies are inspected, not inferred from the object type annotation. The guard accepts/rejects shape; it does not certify getters, Proxy traps or external handlers as an arbitrary-JavaScript sandbox.

**R26-222 — ACCEPT (ACCEPTED_FINITE_POSITIVE)**

The reflected prototype has only strict comparisons with Object.prototype/null in the actual function. Its identity is neither invoked nor forwarded; the comparison chooses a JSON/object guard branch. Actual caller bodies are inspected, not inferred from the object type annotation. The guard accepts/rejects shape; it does not certify getters, Proxy traps or external handlers as an arbitrary-JavaScript sandbox.

