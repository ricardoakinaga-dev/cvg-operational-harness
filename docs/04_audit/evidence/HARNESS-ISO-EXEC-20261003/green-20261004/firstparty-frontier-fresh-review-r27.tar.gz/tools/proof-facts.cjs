'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const out=path.resolve(__dirname,'..'),copy=path.join(out,'source-copy'),ts=require(path.join(copy,'node_modules/typescript/lib/typescript.js'));
if(!process.version.startsWith('v22.'))throw Error('Node22 required');
const H=x=>crypto.createHash('sha256').update(x).digest('hex'),raw=JSON.parse(fs.readFileSync(path.join(out,'raw-independent-ast.json'),'utf8')),props=JSON.parse(fs.readFileSync(path.join(out,'inputs/proposed-dispositions.json'),'utf8')).dispositions;
const sfs=new Map();function load(file){if(!sfs.has(file)){const text=fs.readFileSync(path.join(copy,file),'utf8');const sf=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true,file.endsWith('.tsx')?ts.ScriptKind.TSX:file.endsWith('.json')?ts.ScriptKind.JSON:file.endsWith('.ts')?ts.ScriptKind.TS:ts.ScriptKind.JS);sfs.set(file,sf)}return sfs.get(file)}
function walk(n){const a=[n];ts.forEachChild(n,c=>{a.push(...walk(c))});return a}
function frag(file,pred){const sf=load(file),found=walk(sf).filter(pred);if(!found.length)throw Error('Missing fragment '+file);return found.map(n=>{const start=n.getStart(sf),end=n.end,text=n.getText(sf);return {file,fileSha256:H(sf.text),kind:ts.SyntaxKind[n.kind],start,end,lineStart:sf.getLineAndCharacterOfPosition(start).line+1,lineEnd:sf.getLineAndCharacterOfPosition(end).line+1,text,textSha256:H(text)}})}
const fun=name=>n=>ts.isFunctionDeclaration(n)&&n.name?.text===name;
const fragments={};
for(const [key,file,names] of [
 ['harness','packages/harness/src/capability-boundary.ts',['stableSerialize','isPlainRecord','cloneJsonValue','executeBound','normalizeToolResult','normalizeDescriptor','cloneDescriptor']],
 ['harnessDist','packages/harness/dist/capability-boundary.js',['stableSerialize','isPlainRecord','cloneJsonValue','executeBound']],
 ['canonical','packages/shared/src/canonical.ts',['isPlainObject','canonicalizeJson']],
 ['canonicalDist','packages/shared/dist/canonical.js',['isPlainObject','canonicalizeJson']],
 ['tool','packages/platform/src/tool-invocation-boundary.ts',['isPlainRecord','parseToolInput','normalizePluginHandlerResult','cloneBoundedValue']],
 ['toolDist','packages/platform/dist/tool-invocation-boundary.js',['isPlainRecord','parseToolInput','normalizePluginHandlerResult','cloneBoundedValue']],
 ['webhook','apps/api/src/webhook-security.ts',['canonicalJson','buildWebhookSigningPayload']],
 ['lifecycle','packages/shared/src/lifecycle.ts',['createShutdownController']],
 ['lifecycleDist','packages/shared/dist/lifecycle.js',['createShutdownController']],
 ['approvalCaller','packages/approval-engine/src/contracts.ts',['computeApprovalPayloadHash']],
 ['spy','node_modules/@vitest/spy/dist/index.js',['spyOn','getDescriptor','createMockInstance','createMock','copyOriginalStaticProperties','getAllProperties']],
 ['expectCreator','node_modules/vitest/dist/chunks/test.DNmyFkvJ.js',['createExpect']],
 ['any','node_modules/@vitest/expect/dist/index.js',[]]
]){fragments[key]=names.flatMap(name=>frag(file,fun(name)));if(key==='any')fragments[key]=frag(file,n=>ts.isClassDeclaration(n)&&['Any','AsymmetricMatcher'].includes(n.name?.text));}

fragments.vitestEntry=frag('node_modules/vitest/dist/index.js',n=>ts.isExportDeclaration(n));
fragments.vitestWiring=frag('node_modules/vitest/dist/chunks/test.DNmyFkvJ.js',n=>ts.isImportDeclaration(n)&&['@vitest/spy','@vitest/expect'].includes(n.moduleSpecifier.text) || ts.isVariableDeclaration(n)&&['vitest','vi','JestAsymmetricMatchers','globalExpect'].includes(n.name.getText()) || ts.isExportDeclaration(n) || ts.isShorthandPropertyAssignment(n)&&n.name.text==='spyOn');
fragments.anyCreator=frag('node_modules/@vitest/expect/dist/index.js',n=>ts.isVariableDeclaration(n)&&n.name.getText()==='JestAsymmetricMatchers');
fragments.sharedEntry=frag('packages/shared/dist/index.js',n=>ts.isExportDeclaration(n)&&n.moduleSpecifier.text==='./lifecycle.js');
fragments.sharedManifest=frag('packages/shared/package.json',n=>ts.isSourceFile(n));

const normalize=s=>s.replace(/\s+/g,''),hasImport=(r,name,from)=>r.imports.some(i=>new RegExp('\\b'+name+'\\b').test(i.text)&&i.text.includes("from '"+from+"'"));
function binding(r,name){return r.bindings.find(b=>b.name===name)}
const facts=[];
for(let i=0;i<raw.rows.length;i++){
 const r=raw.rows[i],p=props[i],sf=load(r.file),n=walk(sf).find(n=>n.getStart(sf)===r.ast.start&&n.end===r.ast.end&&ts.SyntaxKind[n.kind]===r.ast.kind);if(!n)throw Error('AST relocation failed');
 const checks={exactNodeAndHash:Object.values(r.checks).every(Boolean)},role=p.role,iv=r.invocation,ivargs=iv?.arguments.map(a=>normalize(a.text))||[];
 if(role==='GLOBAL_FETCH_SPY')Object.assign(checks,{calleeIsLiteralSpy:normalize(iv.callee)==='vi.spyOn',onlyFetchSelected:ivargs.length===2&&ivargs[0]==='globalThis'&&["'fetch'",'"fetch"'].includes(ivargs[1]),viImportedFromVitest:hasImport(r,'vi','vitest')});
 else if(role==='FUNCTION_IDENTITY_AS_MATCHER_SAMPLE')Object.assign(checks,{constructorPassedAsIdentity:normalize(iv.callee)==='expect.any'&&ivargs.length===1&&ivargs[0]==='Function',expectImportedFromVitest:hasImport(r,'expect','vitest'),actualAnyHasFunctionTypeBranch:fragments.any.some(x=>normalize(x.text).includes('if(this.sample===Function){returntypeofother=="function"||typeofother==="function";}'))});
 else if(role==='PROTOTYPE_BOOLEAN_GUARD'){
  const proto=binding(r,'prototype');let functionNode=n;while(functionNode&&!ts.isFunctionLike(functionNode))functionNode=functionNode.parent;
  const body=functionNode.getText(sf),uses=proto?.uses||[];
  Object.assign(checks,{runtimeIntrinsicRead:body.includes('Object.getPrototypeOf(value)'),comparisonsOnly:uses.length?uses.every(u=>u.parent.kind==='BinaryExpression'&&/===|!==/.test(u.parent.text)):r.ast.text==='Object.getPrototypeOf(value)',booleanGuard:/(prototype === Object\.prototype \|\| prototype === null|prototype !== Object\.prototype && prototype !== null)/.test(body)});
 }
 else if(role==='DESCRIPTOR_JSON_DATA'){
  let f=n;while(f&&!ts.isFunctionDeclaration(f))f=f.parent;const body=f.getText(sf);
  Object.assign(checks,{inStableSerializer:f.name.text==='stableSerialize',actualDescriptorRuntimeGuard:body.includes('Object.getOwnPropertyDescriptor(value, key)')&&/!\('value' in property\)/.test(body),functionRejectedBeforeRecursion:body.includes("typeof value !== 'object'")&&body.includes("throw new Error('Value is not JSON serializable')"),descriptorValueRecursesToSameCallee:body.includes('stableSerialize(property.value, state, depth + 1)'),cloneReturnsParsedData:fragments[r.file.includes('/dist/')?'harnessDist':'harness'].some(x=>x.text.includes('JSON.parse(stableSerialize(value))'))});
 }
 else if(role==='SPAWN_SYNC_DATA_CONSUMER'){
  const root=r.ast.text.split('.')[0],b=binding(r,root);
  Object.assign(checks,{runtimeProducerSpawnSync:b?.declarations.some(d=>/\bspawnSync\(/.test(d.text))===true,actualBuiltinImport:hasImport(r,'spawnSync','node:child_process'),selectedDataField:/^(result|child)\.(error|status|stderr|stdout(?:\.trim\(\))?)$/.test(r.ast.text),metadataConsumer:/^(expect|JSON\.parse)$/.test(normalize(iv.callee)) || (normalize(iv.callee)==='result.stdout.trim' && ts.isCallExpression(n.parent) && n.parent.expression.getText(sf)==='JSON.parse')});
 }
 else if(['CHILD_STDIO_EVENT','CHILD_EXIT_ERROR_EVENT','CHILD_TERMINATION'].includes(role)){
  Object.assign(checks,{actualSpawnProducer:binding(r,'child')?.declarations.some(d=>/\bspawn\(/.test(d.text))===true,actualBuiltinImport:hasImport(r,'spawn','node:child_process')});
  if(role==='CHILD_STDIO_EVENT')Object.assign(checks,{literalDataEvent:ivargs[0]==="'data'",selectedStream:/^child\.(stdout|stderr)\??\.on$/.test(normalize(iv.callee)),callbackOnlyStringConcatenation:/output\s*\+=\s*String\(chunk\)/.test(iv.arguments[1].text)&&!/(eval\(|Function\(|import\(|require\()/.test(iv.arguments[1].text)});
  if(role==='CHILD_EXIT_ERROR_EVENT')Object.assign(checks,{selectedOnce:normalize(iv.callee)==='child.once',literalEvent:["'error'","'close'"].includes(ivargs[0]),callbackMetadataOrPromiseRejection:!/(eval\(|Function\(|import\(|require\(|spawn\()/.test(iv.arguments[1].text)&&/resolve|reject/.test(iv.arguments[1].text)});
  if(role==='CHILD_TERMINATION')Object.assign(checks,{literalTerminationOnly:normalize(iv.callee)==='child.kill'&&ivargs.length===1&&ivargs[0]==="'SIGKILL'"});
 }
 else if(role==='PROCESS_TO_SELECTED_SIGNAL_SOURCE')Object.assign(checks,{exactInstallCall:normalize(iv.callee)==='shutdown.install'&&ivargs.length===1&&ivargs[0]==='process',actualLocalFactory:binding(r,'shutdown')?.declarations.some(d=>d.text.includes('createShutdownController('))===true,importSharedFactory:hasImport(r,'createShutdownController','@cvg/shared'),calleeUsesOnceAndIgnoresReturn:fragments.lifecycle[0].text.includes('source.once(signal, () => {')&&fragments.lifecycleDist[0].text.includes('source.once(signal, () => {')});
 else if(role==='BIND_PROCESS_ONCE_RECEIVER')Object.assign(checks,{receiverOnly:normalize(iv.callee)==='process.once.bind'&&ivargs.length===1&&ivargs[0]==='process'});
 else if(['SPY_PROCESS_ONCE','SPY_PROCESS_EXIT'].includes(role))Object.assign(checks,{literalProcessMemberSpy:normalize(iv.callee)==='vi.spyOn'&&ivargs[0]==='process'&&ivargs[1]===(role==='SPY_PROCESS_ONCE'?"'once'":"'exit'"),actualViImport:hasImport(r,'vi','vitest')});
 else if(role==='RETURN_PROCESS_FROM_SIGNAL_MOCK')Object.assign(checks,{explicitReceiverReturn:ts.isReturnStatement(n.parent)&&n.parent.expression===n,insideLiteralOnceMock:iv.callee.replace(/\s/g,'').includes("vi.spyOn(process,'once').mockImplementation"),consumerInstallDiscardsResult:fragments.lifecycle[0].text.includes('source.once(signal, () => {')});
 else if(role==='DECLARED_INSTALLED_MODULE_REFERENCE'){
  const mf=JSON.parse(sf.text),fields=['dependencies','devDependencies','peerDependencies','optionalDependencies'].filter(k=>Object.hasOwn(mf[k]||{},p.observation.specifier));Object.assign(checks,{actualManifestDeclaration:fields.length>0&&ts.isPropertyAssignment(n)&&n.name.text===p.observation.specifier,notRuntimeClosureProof:p.proposedDisposition==='UNRESOLVED'});
 }
 else if(role==='PROCESS_LAUNCH')Object.assign(checks,{actualExecutorCall:['spawn','spawnSync'].includes(normalize(iv.callee)),actualBuiltinBinding:hasImport(r,normalize(iv.callee),'node:child_process'),unresolved:p.proposedDisposition==='UNRESOLVED'});
 else if(role==='EXECUTOR_ALIAS_TO_PROMISIFY')Object.assign(checks,{actualExecutorTransferred:normalize(iv.callee)==='promisify'&&ivargs[0]==='execFile',actualExecutorImport:hasImport(r,'execFile','node:child_process'),unresolved:p.proposedDisposition==='UNRESOLVED'});
 else if(role==='REFLECT_GET_DYNAMIC_STORE_MEMBER')Object.assign(checks,{runtimeReflectedCallablePath:r.contexts.some(c=>c.text.includes('Reflect.get(target, property, receiver)')),variableKeyPreserved:r.contexts.some(c=>c.text.includes('property')),notPromoted:p.proposedDisposition==='UNRESOLVED'});
 else if(role==='CHILD_HANDLE_RETURN')Object.assign(checks,{actualHandleAlias:binding(r,'child')?.declarations.some(d=>/\bspawn\(/.test(d.text))===true||sf.text.includes('const child = spawn('),returnedObjectHandle:r.parent.kind==='ShorthandPropertyAssignment'&&r.parent.text==='child',notPromoted:p.proposedDisposition==='UNRESOLVED'});
 else if(p.category==='BOOTSTRAP_GLOBAL_CAPABILITY')Object.assign(checks,{actualGlobalRuntimeProviderPath:sf.text.includes('const runtime = globalThis as')&&sf.text.includes('return runtime.__CVG_OPERATOR_BOOTSTRAP_TOKEN_PROVIDER__()')&&sf.text.includes('delete runtime.__CVG_OPERATOR_BOOTSTRAP_TOKEN__'),typeCastNotEvidence:p.proposedDisposition==='UNRESOLVED'});
 else throw Error('Unhandled role '+role);
 facts.push({id:r.id,role,checks,allMatched:Object.values(checks).every(Boolean)});
}
// Selected positive/negative AST-only controls for the evidence-role discriminator.
const cases=[
 ['literal-fetch',"vi.spyOn(globalThis,'fetch')",'SPY_FETCH'],['dynamic-key',"vi.spyOn(globalThis,key)",'UNKNOWN'],['literal-eval',"vi.spyOn(globalThis,'eval')",'UNKNOWN'],
 ['prototype-compare',"const p=Object.getPrototypeOf(x); p===Object.prototype",'BOOLEAN_PROTOTYPE'],['prototype-evaluate',"const p=Object.getPrototypeOf(x);p.constructor('x')",'UNKNOWN'],
 ['function-sample',"expect.any(Function)",'MATCHER_SAMPLE'],['function-call',"Function('x')",'UNKNOWN'],['new-function',"new Function('x')",'UNKNOWN']
];
function discriminate(code){const sf=ts.createSourceFile('control.ts',code,ts.ScriptTarget.Latest,true),nodes=walk(sf);const inv=nodes.find(ts.isCallExpression);if(inv&&normalize(inv.expression.getText(sf))==='vi.spyOn'&&inv.arguments[0]?.getText(sf)==='globalThis'&&inv.arguments[1]?.getText(sf)==="'fetch'")return 'SPY_FETCH';if(inv&&normalize(inv.expression.getText(sf))==='expect.any'&&inv.arguments[0]?.getText(sf)==='Function')return 'MATCHER_SAMPLE';if(nodes.some(n=>ts.isBinaryExpression(n)&&n.operatorToken.kind===ts.SyntaxKind.EqualsEqualsEqualsToken&&n.right.getText(sf)==='Object.prototype')&&!nodes.some(n=>ts.isCallExpression(n)&&n.expression.getText(sf).includes('.constructor')))return 'BOOLEAN_PROTOTYPE';return 'UNKNOWN'}
const controls=cases.map(([name,code,expected])=>({name,code,expected,actual:discriminate(code),matched:discriminate(code)===expected}));
fs.writeFileSync(path.join(out,'raw-proof-facts.json'),JSON.stringify({effectiveNode:process.version,parserVersion:ts.version,fragments,facts,controls},null,2));console.log(JSON.stringify({rows:facts.length,matched:facts.filter(x=>x.allMatched).length,issues:facts.filter(x=>!x.allMatched),controls:controls.length,controlsMatched:controls.filter(x=>x.matched).length}));
