from pathlib import Path
import json,hashlib,os
OUT=Path(__file__).resolve().parent.parent
R30=OUT.parent.parent/'firstparty-dependency-resolution-r30'
H=lambda b:hashlib.sha256(b).hexdigest()
bl=json.loads((OUT/'baseline.json').read_text());src=Path(bl['source']);dest=OUT/'inputs/r30';dest.mkdir(exist_ok=True)
names=['authority.json','resolutions.json','condition-probes.json','condition-probes.log','condition-probes.mjs','config.json','firstparty-dependency-resolver-r30.json','firstparty-dependency-resolver-r30.log','firstparty-dependency-resolver-r30-before.json','firstparty-dependency-resolver-r30-after.json','internal_modules_esm_utils.txt','internal_modules_helpers.txt','resolve.mjs']
for name in names:
 p=R30/name;raw=p.read_bytes();(dest/name).write_bytes(raw)
 if not any(x['path']==str(p) for x in bl['packetInputs']):bl['packetInputs'].append({'path':str(p),'sha256':H(raw),'bytes':len(raw),'mode':oct(p.stat().st_mode&0o777)})
r=json.loads((dest/'resolutions.json').read_text());rec={x['file']:x for x in bl['readSet']}
for row in r['results']:
 entries=[row['sourceManifest']]+[x['entry'] for x in row['resolutions'].values() if x['status']=='RESOLVED']+[x['manifest'] for x in row['packages']]
 for e in entries:
  p=src/e['path'];assert str(p.resolve())==e['realPath'];raw=p.read_bytes();assert H(raw)==e['sha256']
  if e['path'] not in rec:
   rec[e['path']]={'file':e['path'],'sha256':H(raw),'bytes':len(raw),'mode':oct(p.stat().st_mode&0o777),'realpath':str(p.resolve()),'symlink':os.readlink(p) if p.is_symlink() else None,'readRole':'R30 resolution entry/exports identity only; not closure acceptance'}
   target=OUT/'source-copy'/e['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
bl['readSet']=sorted(rec.values(),key=lambda x:x['file']);(OUT/'baseline.json').write_text(json.dumps(bl,indent=2)+'\n')
print(json.dumps({'r30Rows':len(r['results']),'readSetFiles':len(rec),'packetInputsCopied':len(names)}))
