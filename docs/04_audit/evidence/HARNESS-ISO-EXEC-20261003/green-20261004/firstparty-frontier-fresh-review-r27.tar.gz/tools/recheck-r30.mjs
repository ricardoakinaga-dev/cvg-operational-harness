import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {createRequire} from 'node:module';import {pathToFileURL,fileURLToPath} from 'node:url';
const out=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const r30=JSON.parse(fs.readFileSync(path.join(out,'inputs/r30/resolutions.json'),'utf8'));
const props=JSON.parse(fs.readFileSync(path.join(out,'inputs/proposed-dispositions.json'),'utf8')).dispositions.filter(r=>r.category==='PACKAGE_METADATA');
if(!process.version.startsWith('v22.'))throw Error('Node22 required');
const sha=x=>crypto.createHash('sha256').update(x).digest('hex'),rows=[];
for(const [i,r] of r30.results.entries()){
 const p=props[i];if(r.id!==p.id||JSON.stringify(r.observation)!==JSON.stringify(p.observation))throw Error('row binding mismatch');
 const manifest=path.join(r30.source,p.binding.file),entry={id:r.id,manifestHashMatched:sha(fs.readFileSync(manifest))===p.binding.fileSha256,modes:{}};
 for(const mode of ['cjs','esm']){
  let actual;try{const target=mode==='cjs'?createRequire(pathToFileURL(manifest)).resolve(p.observation.specifier):import.meta.resolve(p.observation.specifier,pathToFileURL(manifest).href);const filename=target.startsWith('file:')?fileURLToPath(target):target;actual={status:'RESOLVED',resolved:target,realPath:fs.realpathSync(filename),sha256:sha(fs.readFileSync(filename))};}catch(e){actual={status:'UNRESOLVED',code:e.code}}
  const expected=r.resolutions[mode];const matched=actual.status===expected.status&&(actual.status==='RESOLVED'?actual.resolved===expected.resolved&&actual.realPath===expected.entry.realPath&&actual.sha256===expected.entry.sha256:actual.code===expected.code);
  entry.modes[mode]={actual,matched};if(!matched)throw Error('resolution mismatch '+r.id+mode);
 }
 entry.packageHashes=r.packages.map(pkg=>({path:pkg.manifest.path,sha256:sha(fs.readFileSync(path.join(r30.source,pkg.manifest.path))),matched:sha(fs.readFileSync(path.join(r30.source,pkg.manifest.path)))===pkg.manifest.sha256}));if(entry.packageHashes.some(x=>!x.matched))throw Error('manifest drift');rows.push(entry);
}
const conditionSources=JSON.parse(fs.readFileSync(path.join(out,'inputs/r30/condition-probes.json'),'utf8')).nativeSources;
const native=process.binding('natives'),nativeSourceChecks=Object.entries(conditionSources).map(([key,data])=>({key,expectedSha256:data.sha256,actualSha256:sha(native[key]),matched:data.sha256===sha(native[key])}));
const before=fs.readFileSync(path.join(out,'inputs/r30/firstparty-dependency-resolver-r30-before.json')),after=fs.readFileSync(path.join(out,'inputs/r30/firstparty-dependency-resolver-r30-after.json'));const externalCapture={beforeSha256:sha(before),afterSha256:sha(after),identical:sha(before)===sha(after),recordedFiles:Object.keys(JSON.parse(before)).length,independentlyRehashedWholeCapture:false};
const result={node:process.version,flags:process.execArgv,method:'Own independent createRequire.resolve and import.meta.resolve probes; no target imports/evaluation. Manifest/entry physical paths and hashes rechecked. Producer full capture comparison verifies supplied capture equality only, not whole-tree identity.',rows,nativeSourceChecks,externalCapture,transitiveClosureAccepted:false,payloadsExecuted:false};fs.writeFileSync(path.join(out,'raw-r30-recheck.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({rows:rows.length,modeResultsMatched:rows.flatMap(x=>Object.values(x.modes)).filter(x=>x.matched).length,nativeSourcesMatched:nativeSourceChecks.filter(x=>x.matched).length,producerCapture:externalCapture,payloadsExecuted:false,closureAccepted:false}));
