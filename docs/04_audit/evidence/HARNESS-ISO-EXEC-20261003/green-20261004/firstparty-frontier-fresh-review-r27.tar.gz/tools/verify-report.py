import json,hashlib,collections,os
from pathlib import Path
OUT=Path(__file__).resolve().parent.parent
H=lambda b:hashlib.sha256(b).hexdigest()
J=lambda n:json.loads((OUT/n).read_text())
r=J('report.json');a=J('raw-independent-ast.json');f=J('raw-proof-facts.json');p=J('inputs/proposed-dispositions.json');o=J('inputs/observations.json');s=J('Sourceintegrity.json');probe=J('raw-trusted-probes.json')
checks=[]
def check(name,v):
 checks.append({'name':name,'matched':bool(v)})
 if not v:raise AssertionError(name)
check('222 exact unique IDs',len(r['rows'])==222 and len({x['id'] for x in r['rows']})==222)
check('order and observations preserved',[x['observation'] for x in r['rows']]==o['rows'])
check('ACCEPT finite scope',r['verdict']=='ACCEPT' and not any(r['scopeFlags'][x] for x in ['frontierAccepted','wholeClosureAccepted','installedVendorBlanketWaiver','releaseGranted']))
check('140 positives and 82 unknowns',sum(x['acceptedPositive'] for x in r['rows'])==140 and sum(x['independentDisposition']=='UNRESOLVED' for x in r['rows'])==82)
for i,(row,raw,fact,prop) in enumerate(zip(r['rows'],a['rows'],f['facts'],p['dispositions'])):
 check(row['id']+' identity',row['id']==raw['id']==fact['id']==prop['id'] and row['index']==i+1)
 check(row['id']+' independent span',row['binding']['ast']==raw['ast'] and all(raw['checks'].values()))
 check(row['id']+' role evidence',fact['allMatched'] and row['independentProofChecks']==fact['checks'] and row['judgment'])
 check(row['id']+' scope',row['acceptedPositive']==(prop['proposedDisposition']=='PROPOSED_I0_POSITIVE') and (not row['acceptedPositive'])==bool(row['concreteMissingConditions']))
 check(row['id']+' evidence refs',all((OUT/ref.split('#')[0]).is_file() for ref in row['evidenceRefs']))
# Ensure exact observations were not collapsed just because they share file/line/reason.
check('observation multiset unchanged',collections.Counter(json.dumps(x,sort_keys=True) for x in o['rows'])==collections.Counter(json.dumps(x['observation'],sort_keys=True) for x in r['rows']))
check('src/dist capability observations retained',sum(x['artifactRole']=='dist' for x in r['rows'])==13 and sum('capability-boundary' in x['binding']['file'] for x in r['rows'])==14)
check('AST controls distinguish cases',len(f['controls'])==8 and all(x['matched'] for x in f['controls']))
check('builtin controls executed',len(probe['controls'])==5 and all(x['pass'] for x in probe['controls']))
r30=J('raw-r30-recheck.json')
check('54 independent R30 identity rows',len(r30['rows'])==54 and all(x['manifestHashMatched'] for x in r30['rows']))
check('108 independent R30 mode results',sum(x['matched'] for r in r30['rows'] for x in r['modes'].values())==108)
check('R30 native conditions sources',len(r30['nativeSourceChecks'])==2 and all(x['matched'] for x in r30['nativeSourceChecks']))
check('R30 has no closure acceptance',not r30['transitiveClosureAccepted'] and not r30['payloadsExecuted'] and all(not x['supplementalDependencyIdentity']['closureAccepted'] for x in r['rows'] if x['proofRole']=='DECLARED_INSTALLED_MODULE_REFERENCE'))
check('Node22 effective',a['effectiveNode'].startswith('v22.') and probe['effectiveNode'].startswith('v22.'))
check('source sentinel current',s['unchanged'] and all(H((Path(s['sourceReadonly'])/x['file']).read_bytes())==x['before']['sha256'] and str((Path(s['sourceReadonly'])/x['file']).resolve())==x['before']['realpath'] for x in s['files']))
check('link sentinel current',all(os.readlink(Path(s['sourceReadonly'])/x['path'])==x['before']['link'] and str((Path(s['sourceReadonly'])/x['path']).resolve())==x['before']['realpath'] for x in s['links']))
check('markdown contains every row twice',all((OUT/'report.md').read_text().count(x['id'])>=2 for x in r['rows']))
(OUT/'deliverable-verification.json').write_text(json.dumps({'schema':'fresh-i1-deliverable-check-v1','checks':checks,'total':len(checks),'matched':sum(x['matched'] for x in checks),'sourceIntegrityCurrent':True},indent=2)+'\n')
print(json.dumps({'total':len(checks),'matched':sum(x['matched'] for x in checks),'sourceIntegrityCurrent':True}))
