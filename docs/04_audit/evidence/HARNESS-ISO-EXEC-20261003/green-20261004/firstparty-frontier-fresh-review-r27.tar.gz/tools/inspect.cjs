'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const out=path.resolve(__dirname,'..'), copy=path.join(out,'source-copy');
const ts=require(path.join(copy,'node_modules/typescript/lib/typescript.js'));
if (!process.version.startsWith('v22.')) throw Error('Node22 required');
const H=x=>crypto.createHash('sha256').update(x).digest('hex');
const proposals=JSON.parse(fs.readFileSync(path.join(out,'inputs/proposed-dispositions.json'),'utf8')).dispositions;
const baseline=JSON.parse(fs.readFileSync(path.join(out,'baseline.json'),'utf8'));
const files=new Map(),all=new Map();
for(const rec of baseline.readSet){if(!/\.(?:[cm]?js|tsx?|json)$/.test(rec.file)||rec.file.endsWith('typescript.js'))continue;
 const text=fs.readFileSync(path.join(copy,rec.file),'utf8');
 if(text.length>2e6)throw Error('file budget');
 const sf=rec.file.endsWith('.json')?ts.parseJsonText(rec.file,text):ts.createSourceFile(rec.file,text,ts.ScriptTarget.Latest,true,rec.file.endsWith('.tsx')?ts.ScriptKind.TSX:rec.file.endsWith('.ts')?ts.ScriptKind.TS:ts.ScriptKind.JS);
 ts.setParentRecursive(sf, true); files.set(rec.file,sf); const nodes=[]; function walk(n){nodes.push(n);ts.forEachChild(n,walk)} walk(sf);if(nodes.length>150000)throw Error('node budget');all.set(rec.file,nodes);
}
const host={getSourceFile:n=>files.get(n),getDefaultLibFileName:()=>'',writeFile:()=>{throw Error('emit forbidden')},getCurrentDirectory:()=>copy,getDirectories:()=>[],fileExists:n=>files.has(n),readFile:n=>files.get(n)?.text,useCaseSensitiveFileNames:()=>true,getCanonicalFileName:n=>n,getNewLine:()=> '\n'};
const program=ts.createProgram([...files.keys()].filter(x=>!x.endsWith('.json')),{noResolve:true,noLib:true,allowJs:true,checkJs:false,noEmit:true},host),checker=program.getTypeChecker();
const span=(n,sf)=>{const start=n.getStart(sf),end=n.end,lc=sf.getLineAndCharacterOfPosition(start),text=sf.text.slice(start,end);return {kind:ts.SyntaxKind[n.kind],start,end,utf8Start:Buffer.byteLength(sf.text.slice(0,start)),utf8End:Buffer.byteLength(sf.text.slice(0,end)),line:lc.line+1,column:lc.character+1,text,textSha256:H(text)}};
const parents=(n,pred)=>{for(let a=n.parent;a;a=a.parent)if(pred(a))return a;return null};
const context=(n,sf)=>{const a=[];for(let p=n.parent;p;p=p.parent)if(ts.isFunctionLike(p)){a.push(span(p,sf));if(a.length===2)break}return a};
const declarations=(n,sf)=>{const names=[];function w(a){if(ts.isIdentifier(a)&& !(ts.isPropertyAccessExpression(a.parent)&&a.parent.name===a))names.push(a);ts.forEachChild(a,w)}w(n);
 return [...new Map(names.map(a=>{const sym=checker.getSymbolAtLocation(a);return [a.text,{name:a.text,declarations:(sym?.declarations||[]).map(d=>span(d,d.getSourceFile())),uses:sym?(all.get(sf.fileName)||[]).filter(b=>ts.isIdentifier(b)&&checker.getSymbolAtLocation(b)===sym&&!sym.declarations?.includes(b.parent)).map(b=>({...span(b,sf),parent:span(b.parent,sf)})):[]}]})).values()];};
const counter=new Map(),rows=[],issues=[];
for(const p of proposals){const sf=files.get(p.binding.file),want=p.binding.ast;
 if(!sf)throw Error('Missing source');
 // Independently enumerate syntax nodes by spelling/kind/line; do not seek using proposed offsets.
 const matches=all.get(sf.fileName).filter(n=>!(ts.isIdentifier(n) && (ts.isPropertyAccessExpression(n.parent) || ts.isElementAccessExpression(n.parent))) && ts.SyntaxKind[n.kind]===want.kind&&n.getText(sf)===want.text&&sf.getLineAndCharacterOfPosition(n.getStart(sf)).line+1===want.line);
 const key=JSON.stringify([sf.fileName,want.kind,want.line,want.text]);const ordinal=(counter.get(key)||0)+1;counter.set(key,ordinal);
 const n=matches[ordinal-1];if(!n)throw Error('Occurrence missing '+p.id);const actual=span(n,sf),bytes=fs.readFileSync(path.join(copy,sf.fileName));
 const checks={fileHash:H(bytes)===p.binding.fileSha256,kind:actual.kind===want.kind,start:actual.start===want.start,end:actual.end===want.end,line:actual.line===want.line,column:actual.column===want.column,utf8Start:actual.utf8Start===want.utf8Start,utf8End:actual.utf8End===want.utf8End,textHash:actual.textSha256===want.textSha256,observationLine:!/:\d+$/.test(p.observation.file)||Number(p.observation.file.match(/:(\d+)$/)[1])===actual.line};
 if(Object.values(checks).some(x=>!x))issues.push({id:p.id,checks});
 const invoke=ts.isCallExpression(n)||ts.isNewExpression(n)?n:parents(n,a=>ts.isCallExpression(a)||ts.isNewExpression(a));
 const sfImports=sf.statements.filter(ts.isImportDeclaration).map(x=>span(x,sf));
 rows.push({id:p.id,index:p.index,observation:p.observation,file:sf.fileName,fileSha256:H(bytes),independentOccurrence:ordinal,matchingOccurrences:matches.length,checks,ast:actual,parent:span(n.parent,sf),invocation:invoke?{...span(invoke,sf),callee:invoke.expression.getText(sf),arguments:invoke.arguments?.map(a=>span(a,sf))||[]}:null,contexts:context(n,sf),bindings:declarations(invoke||n,sf),imports:sfImports,localCalls:context(n,sf).filter(x=>/^FunctionDeclaration$/.test(x.kind)).map(x=>{const f=all.get(sf.fileName).find(a=>a.getStart(sf)===x.start&&a.end===x.end),name=f?.name?.text;return {name,calls:all.get(sf.fileName).filter(a=>ts.isCallExpression(a)&&ts.isIdentifier(a.expression)&&a.expression.text===name).map(a=>span(a,sf))}})});
}
const parsed=[...files].map(([file,sf])=>({file,sha256:H(sf.text),nodes:all.get(file).length,parseDiagnostics:sf.parseDiagnostics.map(d=>({start:d.start,length:d.length,message:ts.flattenDiagnosticMessageText(d.messageText,' ')}))}));
fs.writeFileSync(path.join(out,'raw-independent-ast.json'),JSON.stringify({effectiveNode:process.version,parserVersion:ts.version,method:'Independent AST enumeration by kind/spelling/line and occurrence; offsets/hashes then compared. Local symbols bound without resolving imports, loading libs, emitting or evaluating candidate code.',issues,parsedFiles:parsed,rows},null,2));
console.log(JSON.stringify({effectiveNode:process.version,parser:ts.version,files:files.size,rows:rows.length,issues,parseDiagnostics:parsed.filter(x=>x.parseDiagnostics.length).map(x=>({file:x.file,errors:x.parseDiagnostics.length}))}));
