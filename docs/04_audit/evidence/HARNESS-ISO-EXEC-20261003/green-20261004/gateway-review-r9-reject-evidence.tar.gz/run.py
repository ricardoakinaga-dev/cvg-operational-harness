from pathlib import Path
import subprocess,json,time,sys,os
p=Path('/home/ricardo/.cache/cvg-harness-green-20261004/gateway-review-r9');o=p/'output';node='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node'
label=sys.argv[1];args=sys.argv[2:];env={'PATH':str(Path(node).parent)+':/usr/bin:/bin','TMPDIR':str(o/'tmp'),'TMP':str(o/'tmp'),'TEMP':str(o/'tmp'),'XDG_CACHE_HOME':str(o/'cache'),'TSX_CACHE_DIR':str(o/'cache/tsx'),'OPENSSL_CONF':str(o/'openssl.cnf'),'CI':'1','TZ':'UTC'}
started=time.time();entry={'label':label,'argv':args,'cwd':str(o/'ownruntime'),'environment':env,'started':started}
with (o/'logs'/f'{label}.log').open('w') as f:
 try:
  r=subprocess.run(args,cwd=o/'ownruntime',env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240);entry['exitCode']=r.returncode
 except subprocess.TimeoutExpired:entry['exitCode']='TIMEOUT'
entry['elapsedSeconds']=time.time()-started
with (o/'commands.jsonl').open('a') as f:f.write(json.dumps(entry)+'\n')
print(json.dumps(entry));print((o/'logs'/f'{label}.log').read_text()[-5000:])
