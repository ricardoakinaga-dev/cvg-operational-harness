from pathlib import Path
import shutil,json,hashlib,os
p=Path('/home/ricardo/.cache/cvg-harness-green-20261004/gateway-review-r9');s=p/'source';o=p/'output';r=o/'ownruntime';r.mkdir(exist_ok=True)
for f in ['package.json','tsconfig.base.json','vitest.config.mts']:
 shutil.copy2(s/f,r/f)
for family in ['packages','products','legacy/packages']:
 for package in (s/family).iterdir():
  if not package.is_dir():continue
  dest=r/family/package.name;dest.mkdir(parents=True,exist_ok=True)
  for part in ['src','scripts','fixtures','package.json','tsconfig.json']:
   f=package/part
   if f.is_dir():shutil.copytree(f,dest/part)
   elif f.is_file():shutil.copy2(f,dest/part)
shutil.copytree(s/'node_modules',r/'node_modules',symlinks=True)
for link in (r/'node_modules/@cvg').iterdir():
 if link.is_symlink() and not link.resolve().is_relative_to(r):raise Exception('external link')
for d in ['tmp','cache','probes','logs','manifests']: (o/d).mkdir(exist_ok=True)
# Physical public artifact; intentionally no src, symlinks, workspace or tsconfig paths.
c=o/'consumer';c.mkdir(exist_ok=True);(c/'package.json').write_text('{"type":"module","private":true}')
for pkg in ['model-gateway','shared']:
 dest=c/'node_modules/@cvg'/pkg;dest.mkdir(parents=True)
 shutil.copy2(s/'packages'/pkg/'package.json',dest/'package.json');shutil.copytree(s/'packages'/pkg/'dist',dest/'dist')
shutil.copytree(s/'node_modules/zod',c/'node_modules/zod')
# Dedicated build configs keep source and tests byte-preserved.
for pkg in ['shared','model-gateway']:
 config={'extends':str(r/'tsconfig.base.json'),'compilerOptions':{'rootDir':str(r/'packages'/pkg/'src'),'outDir':str(r/'packages'/pkg/'dist'),'composite':False,'incremental':False,'paths':{},'baseUrl':str(r),'skipLibCheck':False},'include':[str(r/'packages'/pkg/'src/**/*.ts')],'exclude':[str(r/'packages'/pkg/'src/__tests__')]}
 (o/f'build-{pkg}.json').write_text(json.dumps(config,indent=2))
# Regressions retain original config, environment annotations and aliases; writable cache relocated.
(o/'vitest.review.mts').write_text("import original from './ownruntime/vitest.config.mts'; export default {...original, cacheDir:"+json.dumps(str(o/'cache/vite'))+", test:{...original.test, coverage:{...original.test?.coverage, enabled:false}}};")
(o/'openssl.cnf').write_text('[req]\ndistinguished_name=dn\n[dn]\n')
def manifest(root):
 rows=[]
 for f in sorted(root.rglob('*')):
  if f.is_file():
   st=f.stat();rows.append({'path':str(f.relative_to(root)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':st.st_size,'ino':st.st_ino,'nlink':st.st_nlink})
 return rows
(o/'manifests/frozen-public.json').write_text(json.dumps(manifest(c),indent=2))
print('private runtime and physical dist-only consumer prepared')
