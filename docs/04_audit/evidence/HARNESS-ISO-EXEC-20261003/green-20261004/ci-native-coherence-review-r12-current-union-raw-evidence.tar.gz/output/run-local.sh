#!/bin/bash
set -eu
out=/home/ricardo/.cache/cvg-harness-green-20261004/ci-native-coherence-review-r12/output
env -i PATH=/home/ricardo/.nvm/versions/node/v22.23.2/bin:/usr/bin:/bin TMPDIR="$out/tmp" REVIEW_GUARD_LOG="$out/guard-events.jsonl" REVIEW_PG_LOG="$out/pg-identities.jsonl" REVIEW_GUARD_PHASE="$1" NODE_OPTIONS="--dns-result-order=verbatim --require=$out/guard.cjs --import=$out/pg-bootstrap.mjs" strace -f -qq -e trace=network -o "$out/$1-network.trace" python3 "$out/guard-launch.py" node --import tsx "$out/$2" > "$out/$1.log" 2>&1
