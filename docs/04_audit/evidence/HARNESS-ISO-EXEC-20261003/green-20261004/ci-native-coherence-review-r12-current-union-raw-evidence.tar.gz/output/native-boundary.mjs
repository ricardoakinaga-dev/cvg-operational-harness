import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {spawnSync} from 'node:child_process';
const root=process.cwd(),out=path.resolve('../native-boundaries');fs.mkdirSync(out,{recursive:true});
const {snapshotSchema}=await import('file://'+root+'/scripts/hiso-reports.mjs');
const manifest=JSON.parse(fs.readFileSync(root+'/scripts/critical-coverage-manifest.json'));const paths=[...new Set(manifest.groups.flatMap(g=>g.paths))],target=manifest.groups.find(g=>g.id==='approval');
const dims=['statements','branches','functions','lines'];const metrics=()=>Object.fromEntries(dims.map(k=>[k,{total:100,covered:100,skipped:0,pct:100}]));const cases=[];
for(const total of [100000,9007199254700003,Number.MAX_SAFE_INTEGER])for(const delta of [-1n,0n,1n]){
const covered=Number(BigInt(total)*95n/100n+delta),diff=BigInt(covered)*100n-BigInt(total)*95n,expected=diff>=0n?'PASS':'FAIL',id=total+'_'+String(delta),d=path.join(out,id);
fs.mkdirSync(path.join(d,'certification'),{recursive:true});fs.mkdirSync(path.join(d,'coverage'),{recursive:true});
for(const p of ['scripts/critical-coverage.mjs','scripts/lib/coverage-gate.mjs','scripts/critical-coverage-manifest.json']){fs.mkdirSync(path.dirname(path.join(d,p)),{recursive:true});fs.copyFileSync(path.join(root,p),path.join(d,p));}
const summary={total:metrics(),...Object.fromEntries(paths.map(p=>[p,metrics()]))};for(const p of target.paths)summary[p].branches={total:0,covered:0,skipped:0,pct:null};summary[target.paths[0]].branches={total,covered,skipped:0,pct:Number((covered/total*100).toFixed(2))};
fs.writeFileSync(path.join(d,'coverage/coverage-summary.json'),JSON.stringify(summary,null,2)+'\n');
const cli=spawnSync(process.execPath,['scripts/critical-coverage.mjs'],{cwd:d,encoding:'utf8',timeout:20000});fs.writeFileSync(path.join(d,'stdout.log'),cli.stdout??'');fs.writeFileSync(path.join(d,'stderr.log'),cli.stderr??'');
let error;try{assert.equal(cli.status,expected==='PASS'?0:1);const rep=JSON.parse(fs.readFileSync(path.join(d,'certification/critical-coverage.json')));assert.equal(rep.verdict,expected);if(expected==='PASS')snapshotSchema(rep,'coverage-critical');else{rep.verdict='PASS';rep.failures=[];rep.critical.pass=true;rep.critical.failures=[];assert.throws(()=>snapshotSchema(rep,'coverage-critical'),/raw_threshold/)}}catch(e){error=String(e)}
cases.push({id,total,covered,exactDifference:String(diff),expected,exitCode:cli.status,status:error?'FAIL':'PASS',error});
}
const result={total:cases.length,passed:cases.filter(c=>c.status==='PASS').length,failed:cases.filter(c=>c.status==='FAIL').length,cases};fs.writeFileSync('../native-boundaries.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));process.exitCode=result.failed?1:0;
