import os,json,shutil,stat
from pathlib import Path
P=Path('/home/ricardo/.cache/cvg-harness-green-20261004/ci-native-coherence-review-r12');S=P/'source';R=P/'output/runtime';R.mkdir()
x=json.loads((P/'frozen-inventory.json').read_text())
for k,v in x.items():
 dst=R/k;dst.parent.mkdir(parents=True,exist_ok=True)
 if v['kind']=='link':
  target=v['target'];assert not os.path.isabs(target);assert (dst.parent/target).resolve().is_relative_to(R);os.symlink(target,dst)
 else:
  fd=os.open(S/k,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
  with os.fdopen(fd,'rb') as src,open(dst,'wb') as out:shutil.copyfileobj(src,out)
  os.chmod(dst,stat.S_IMODE(os.lstat(S/k).st_mode))
print('Physical copy complete',len(x))
