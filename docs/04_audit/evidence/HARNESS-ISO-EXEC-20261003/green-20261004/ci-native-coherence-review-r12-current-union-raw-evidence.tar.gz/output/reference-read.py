import os,json,hashlib,sys,stat
from pathlib import Path
P=Path('/home/ricardo/.cache/cvg-harness-green-20261004/ci-native-coherence-review-r12');R=P/'reference-baseline';O=P/'output'
def read(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb') as f:return f.read()
inv=json.loads(read(P/'reference-baseline-inventory.json'));meta={};actual={}
for rel in inv['files']:
 p=R/rel
 for parent in [p,*p.parents]:
  if not parent.is_relative_to(R):break
  st=os.lstat(parent);meta[str(parent.relative_to(R))]={k:getattr(st,k) for k in ['st_mode','st_ino','st_dev','st_nlink','st_uid','st_gid','st_size','st_atime_ns','st_mtime_ns','st_ctime_ns','st_blocks','st_blksize','st_rdev']}
 data=read(p);actual[rel]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 assert all(actual[rel][k]==inv['files'][rel][k] for k in ['sha256','bytes'])
 if sys.argv[1]=='before':
  dst=O/'reference-baseline'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
result={'stage':sys.argv[1],'hashesMatched':True,'files':actual,'metadata':meta}
if sys.argv[1]=='after':result['metadataMatchesBefore']=json.loads((O/'reference-before.json').read_text())['metadata']==meta
(O/('reference-'+sys.argv[1]+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='metadata'}))
