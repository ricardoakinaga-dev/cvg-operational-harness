import os,sys
from pathlib import Path
S=Path('/home/ricardo/.cache/cvg-harness-green-20261004/ci-native-coherence-review-r12/source')
for name in sys.argv[1:]:
 print('\nFILE '+name)
 fd=os.open(S/name,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 with os.fdopen(fd,'r') as f:print(f.read())
