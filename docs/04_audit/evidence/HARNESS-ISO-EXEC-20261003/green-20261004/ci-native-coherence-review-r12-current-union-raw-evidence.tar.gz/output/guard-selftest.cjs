const assert=require('node:assert/strict');let n=0;
for(const f of [()=>require('node:net').connect(443,'synthetic.invalid'),()=>require('node:dns').lookup('synthetic.invalid'),()=>fetch('https://synthetic.invalid'),()=>require('node:https').get('https://synthetic.invalid'),()=>require('node:dgram').createSocket('udp4')]){assert.throws(f,/REVIEW_NETWORK_DENIED/);n++}
console.log(JSON.stringify({intentionalGuardSelftest:true,blocked:n}));
