import fs from 'node:fs';import path from 'node:path';
const {sourceFiles,digest,validateContract,contract,sha}=await import('file://'+process.cwd()+'/scripts/hiso-contract.mjs');
const {approvedCoverageInventory}=await import('file://'+process.cwd()+'/scripts/hiso-inventory.mjs');
validateContract(process.cwd());const inputs=sourceFiles(process.cwd()),frozen=JSON.parse(fs.readFileSync('../../frozen-inventory.json'));
const mismatches=inputs.filter(i=>frozen[i.path]?.sha256!==i.sha256||frozen[i.path]?.bytes!==i.size);
const result={currentNativeInputCount:inputs.length,currentNativeInputDigest:digest(inputs),allLiteralHashesMatchFrozen:mismatches.length===0,mismatches,approvedCoveragePaths:approvedCoverageInventory(process.cwd()).length,specLiteralSHA256:sha(fs.readFileSync('docs/02_spec/0180_shared_transport_ci_security.md')),specSHA256FromConfig:contract.approvedSpecSha256,scopes:contract.scopes.map(s=>({id:s.id,owner:s.owner,gates:s.gates.length,policies:s.gates.filter(g=>['unit','postgres','chaos'].includes(g.id)).map(g=>({id:g.id,skipPolicy:g.skipPolicy}))})),inputs};
fs.writeFileSync('../current-inputs.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({...result,inputs:undefined}));if(mismatches.length)process.exitCode=1;
