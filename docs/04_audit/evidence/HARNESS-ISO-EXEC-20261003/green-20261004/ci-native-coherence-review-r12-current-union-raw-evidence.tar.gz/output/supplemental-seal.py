import os,stat,json,hashlib,sys
from pathlib import Path
P=Path('/home/ricardo/.cache/cvg-harness-green-20261004/ci-native-coherence-review-r12');S=P/'supplemental-current-native';O=P/'output';R=O/'runtime'
def read(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb') as f:return f.read()
def listing(p):
 fd=os.open(p,os.O_RDONLY|os.O_DIRECTORY|os.O_NOATIME)
 try:return sorted(os.listdir(fd))
 finally:os.close(fd)
meta={};actual={}
def visit(p,rel):
 st=os.lstat(p);meta[rel]={k:getattr(st,k) for k in ['st_mode','st_ino','st_dev','st_nlink','st_uid','st_gid','st_size','st_atime_ns','st_mtime_ns','st_ctime_ns','st_blocks','st_blksize','st_rdev']}
 if stat.S_ISDIR(st.st_mode):
  for n in listing(p):visit(p/n,n if rel=='.' else rel+'/'+n)
 else:
  assert stat.S_ISREG(st.st_mode),str(p)
  b=read(p);actual[rel]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
visit(S,'.')
authorityBytes=read(P/'supplemental-current-native-inventory.json');authority=json.loads(authorityBytes)
st=os.lstat(P/'supplemental-current-native-inventory.json');meta['@authority-inventory']={k:getattr(st,k) for k in ['st_mode','st_ino','st_dev','st_nlink','st_uid','st_gid','st_size','st_atime_ns','st_mtime_ns','st_ctime_ns','st_blocks','st_blksize','st_rdev']}
assert actual==authority['supplementalInputs'] and len(actual)==71
result={'stage':sys.argv[1],'inventorySHA256':hashlib.sha256(authorityBytes).hexdigest(),'files':len(actual),'metadataEntries':len(meta),'directoryCount':len(meta)-len(actual)-1,'inventoryMatchesAuthority':True,'inventory':actual,'metadata':meta}
if sys.argv[1]=='before':
 frozen=json.loads(read(P/'frozen-inventory.json'))
 assert not (actual.keys()&frozen.keys()),'supplement overlaps base'
 for rel in actual:
  dst=R/rel;assert not dst.exists(),str(dst);dst.parent.mkdir(parents=True,exist_ok=True)
  dst.write_bytes(read(S/rel));os.chmod(dst,stat.S_IMODE(os.lstat(S/rel).st_mode))
 (O/'supplemental-authority-inventory.json').write_bytes(authorityBytes)
 for name in ['report.md','report.json','current-inputs.json']:
  dst=O/('base-only-'+name)
  assert not dst.exists();dst.write_bytes((O/name).read_bytes())
if sys.argv[1]=='after':
 before=json.loads((O/'supplemental-before.json').read_text());result['metadataMatchesBefore']=meta==before['metadata'];result['inventoryMatchesBefore']=actual==before['inventory'];assert result['metadataMatchesBefore'] and result['inventoryMatchesBefore']
(O/('supplemental-'+sys.argv[1]+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['inventory','metadata']}))
