const fs=require('node:fs');const {syncBuiltinESMExports}=require('node:module');
const log=(kind,args)=>fs.appendFileSync(process.env.REVIEW_GUARD_LOG,JSON.stringify({pid:process.pid,phase:process.env.REVIEW_GUARD_PHASE||'review',kind,args:args.map(x=>typeof x==='string'?x:typeof x)})+'\n');
const deny=kind=>(...args)=>{log(kind,args);throw Object.assign(new Error('REVIEW_NETWORK_DENIED:'+kind),{code:'REVIEW_NETWORK_DENIED'})};
const net=require('node:net');const original=net.Socket.prototype.connect;
net.Socket.prototype.connect=function(...args){const a=Array.isArray(args[0])?args[0][0]:args[0];if((typeof a==='string'&&!/^\d+$/.test(a))||(a&&typeof a==='object'&&typeof a.path==='string')){log('local.ipc',[typeof a==='string'?a:a.path]);return original.apply(this,args)}return deny('net.connect')(...args)};
for(const mod of ['node:http','node:https']){const m=require(mod);m.request=deny(mod+'.request');m.get=deny(mod+'.get')}
const dns=require('node:dns');for(const k of Object.keys(dns))if(typeof dns[k]==='function'&&(k==='lookup'||k.startsWith('resolve')||k==='reverse'))dns[k]=deny('dns.'+k);
for(const k of Object.keys(dns.promises))if(typeof dns.promises[k]==='function'&&(k==='lookup'||k.startsWith('resolve')||k==='reverse'))dns.promises[k]=deny('dns.promises.'+k);
require('node:tls').connect=deny('tls.connect');require('node:dgram').createSocket=deny('dgram.createSocket');global.fetch=deny('fetch');syncBuiltinESMExports();
