#!/bin/bash
set -eu
out=/home/ricardo/.cache/cvg-harness-green-20261004/ci-native-coherence-review-r12/output
ex="$out/extension"
env -i PATH=/home/ricardo/.nvm/versions/node/v22.23.2/bin:/usr/bin:/bin TMPDIR="$ex/tmp" XDG_CACHE_HOME="$ex/cache" npm_config_cache="$ex/cache" REVIEW_GUARD_LOG="$ex/guard-events.jsonl" REVIEW_PG_LOG="$ex/pg-identities.jsonl" REVIEW_GUARD_PHASE="$1" NODE_OPTIONS="--dns-result-order=verbatim --require=$out/guard.cjs --import=$out/pg-bootstrap.mjs" strace -f -qq -e trace=network -o "$ex/$1-network.trace" python3 "$out/guard-launch.py" node "${@:2}" > "$ex/$1.log" 2>&1
