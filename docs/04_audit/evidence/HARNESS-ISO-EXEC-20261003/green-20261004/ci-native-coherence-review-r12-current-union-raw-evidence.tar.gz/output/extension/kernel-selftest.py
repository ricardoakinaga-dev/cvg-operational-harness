import socket,json
blocked=[]
for family in [socket.AF_INET,socket.AF_INET6]:
 try:
  socket.socket(family)
  raise AssertionError('guard ineffective')
 except PermissionError:blocked.append(str(family))
print(json.dumps({'intentionalGuardSelftest':True,'kernelFamiliesBlocked':blocked}))
