import json,hashlib,os,sys
from pathlib import Path
P=Path('/home/ricardo/.cache/cvg-harness-green-20261004/ci-native-coherence-review-r12/output')
index=json.loads((P/'artifact-index.json').read_text());actual={}
for row in index['artifacts']:
 f=P/row['path'];st=os.lstat(f);actual[row['path']]={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':st.st_size,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns,'inode':st.st_ino}
result={'stage':sys.argv[1],'artifacts':actual,'originalIndexContentDifferences':[row['path'] for row in index['artifacts'] if actual[row['path']]['sha256']!=row['sha256']]}
if sys.argv[1]=='after':
 before=json.loads((P/'extension/primary-before.json').read_text());result['unchangedSincePreservationInstruction']=actual==before['artifacts'];assert result['unchangedSincePreservationInstruction']
(P/('extension/primary-'+sys.argv[1]+'.json')).write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k!='artifacts'})
