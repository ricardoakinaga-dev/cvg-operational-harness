export class Client {async connect(){throw new Error('REVIEW_PG_MOCK_ONLY_NO_CONNECTION')} async query(){throw new Error('REVIEW_PG_MOCK_ONLY_NO_QUERY')} async end(){}}
export default {Client};
