import fs from 'node:fs';import assert from 'node:assert/strict';import {registerHooks} from 'node:module';import {Client} from './pg-mock.mjs';
const mock=new URL('./pg-mock.mjs',import.meta.url).href;
registerHooks({resolve(s,c,next){if(s==='pg')return{url:mock,shortCircuit:true};return next(s,c)}});
const admitted=await import('pg');assert.equal(admitted.Client,Client,'abort: ineffective ESM pg mock');
fs.appendFileSync(process.env.REVIEW_PG_LOG,JSON.stringify({pid:process.pid,phase:process.env.REVIEW_GUARD_PHASE,ClientIdentityVerified:true,beforeNativeImports:true})+'\n');
