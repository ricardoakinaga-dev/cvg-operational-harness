const fs=require('node:fs'),ts=require('./runtime/node_modules/typescript'),crypto=require('node:crypto'),util=require('node:util'),assert=require('node:assert/strict');
const printer=ts.createPrinter({removeComments:true});const hash=s=>crypto.createHash('sha256').update(s).digest('hex');const canonical=v=>JSON.stringify(v);
const parse=(p)=>ts.createSourceFile(p,fs.readFileSync(p,'utf8'),ts.ScriptTarget.Latest,true);
const ruleAst=parse('runtime/scripts/hiso-variant.mjs');let ruleInit;
function search(n){if(ts.isVariableDeclaration(n)&&n.name.getText(ruleAst)==='rules')ruleInit=n.initializer;ts.forEachChild(n,search)}search(ruleAst);
function evaluate(n,vars,env={}){
 if(!n)throw Error('absent');
 if(ts.isStringLiteral(n)||ts.isNoSubstitutionTemplateLiteral(n))return n.text;
 if(ts.isNumericLiteral(n))return Number(n.text);if(ts.isTemplateExpression(n))return n.head.text+n.templateSpans.map(t=>String(evaluate(t.expression,vars,env))+t.literal.text).join('');
 if(ts.isParenthesizedExpression(n))return evaluate(n.expression,vars,env);
 if(n.kind===ts.SyntaxKind.NullKeyword)return null;
 if(n.kind===ts.SyntaxKind.TrueKeyword)return true;
 if(n.kind===ts.SyntaxKind.FalseKeyword)return false;
 if(ts.isArrowFunction(n)||ts.isFunctionExpression(n))return '<opaque-function-not-executed>';
 if(ts.isIdentifier(n)){const name=n.text;if(Object.hasOwn(env,name))return env[name];if(name==='undefined')return undefined;if(name==='NaN')return NaN;if(name==='Infinity')return Infinity;if(name==='contract'||name==='r10Contract')return JSON.parse(fs.readFileSync('runtime/scripts/hiso-ci-scopes.json'));if(name==='rules')return evaluate(ruleInit,new Map());if(vars.has(name))return evaluate(vars.get(name),vars,env);throw Error('unresolved identifier '+name)}
 if(ts.isArrayLiteralExpression(n))return n.elements.flatMap(e=>ts.isSpreadElement(e)?evaluate(e.expression,vars,env):[evaluate(e,vars,env)]);
 if(ts.isObjectLiteralExpression(n)){const out={};for(const p of n.properties){if(!ts.isPropertyAssignment(p))throw Error('not literal property');out[p.name.text]=evaluate(p.initializer,vars,env)}return out}
 if(ts.isPropertyAccessExpression(n)){if(n.expression.getText()==='Number'&&n.name.text==='MAX_SAFE_INTEGER')return Number.MAX_SAFE_INTEGER;return evaluate(n.expression,vars,env)[n.name.text]}
 if(ts.isPrefixUnaryExpression(n)){const v=evaluate(n.operand,vars,env);if(n.operator===ts.SyntaxKind.MinusToken)return -v;throw Error('unapproved unary')}
 if(ts.isBinaryExpression(n)){const a=evaluate(n.left,vars,env),b=evaluate(n.right,vars,env);if(n.operatorToken.kind===ts.SyntaxKind.PlusToken)return a+b;if(n.operatorToken.kind===ts.SyntaxKind.AsteriskAsteriskToken)return a**b;throw Error('unapproved binary')}
 throw Error('no executable baseline expression: '+n.getText().slice(0,100));
}
function analysis(file){const ast=parse(file),vars=new Map();function collect(n){if(ts.isVariableDeclaration(n)&&ts.isIdentifier(n.name)&&n.initializer)vars.set(n.name.text,n.initializer);ts.forEachChild(n,collect)}collect(ast);
 const norm=n=>printer.printNode(ts.EmitHint.Unspecified,n,ast),assertions=[];function a(n){if(ts.isCallExpression(n)&&/^expect(?:\(|\.)/.test(n.expression.getText(ast)))assertions.push(norm(n));ts.forEachChild(n,a)}a(ast);
 const cases=[],declarations=[];
 function walk(n,suites=[],env={}){
  if(ts.isFunctionDeclaration(n))return;
  if(ts.isForOfStatement(n)){const vals=evaluate(n.expression,vars,env),name=n.initializer.declarations[0].name.text;for(const val of vals)walk(n.statement,suites,{...env,[name]:val});return}
  if(ts.isCallExpression(n)){
   const exp=n.expression.getText(ast);
   if(exp==='describe'){const title=evaluate(n.arguments[0],vars,env),fn=n.arguments[1];walk(fn.body,[...suites,title],env);return}
   if(exp==='it'||exp==='test'||exp.startsWith('it.each(')||exp.startsWith('test.each(')){
    const title=evaluate(n.arguments[0],vars,env),fn=n.arguments[1],each=ts.isCallExpression(n.expression),data=each?evaluate(n.expression.arguments[0],vars,env):[[]];
    declarations.push({suites,title,each,caseCount:data.length,registrationAST:norm(n.expression),callbackSHA256:hash(norm(fn))});
    for(const d of data){const row=Array.isArray(d)?d:[d];cases.push({suites,title:each?util.format(title,...row.slice(0,(title.match(/%[sdjifoOc]/g)||[]).length)):title})}return;
   }
   return;
  }
  if(ts.isArrowFunction(n)||ts.isFunctionExpression(n))return;
  ts.forEachChild(n,c=>walk(c,suites,env));
 }
 walk(ast);return{caseCount:cases.length,assertionASTCount:assertions.length,assertionASTSHA256:hash(canonical(assertions)),declarations,cases,assertions};}
const result={method:'TypeScript AST only; literals/finite it.each tables/for-of registration expansion. Functions represented as opaque values, never invoked. Assertion call AST and complete test callback AST normalized with comments removed. Obsolete tests never imported or run.',tests:[],mutationDelta:[],inventoryEqual:false,pass:false};
const native=JSON.parse(fs.readFileSync('focused-tests.json'));
for(const f of ['tests/hiso-ci-scopes.test.js','tests/hiso-snapshot-membership-own.test.js']){
 const baseline=analysis('reference-baseline/'+f),current=analysis('runtime/'+f),actual=native.testResults.find(t=>t.name.endsWith('/'+f)).assertionResults.map(t=>({suites:t.ancestorTitles,title:t.title}));
 const sort=rows=>rows.map(canonical).sort();
 const v={file:f,baselineCaseCount:baseline.caseCount,currentCaseCount:current.caseCount,nativeCaseCount:actual.length,namesEqual:canonical(baseline.cases)===canonical(current.cases),staticNamesMatchNative:canonical(sort(current.cases))===canonical(sort(actual)),assertionsEqual:canonical(baseline.assertions)===canonical(current.assertions),testRegistrationsAndCallbacksEqual:canonical(baseline.declarations)===canonical(current.declarations),baselineAssertionASTCount:baseline.assertionASTCount,currentAssertionASTCount:current.assertionASTCount,baselineAssertionASTSHA256:baseline.assertionASTSHA256,currentAssertionASTSHA256:current.assertionASTSHA256,baseline,current};result.tests.push(v);
}
const old=JSON.parse(fs.readFileSync('reference-baseline/scripts/mutation-manifest.json')),now=JSON.parse(fs.readFileSync('runtime/scripts/mutation-manifest.json')),frozen=JSON.parse(fs.readFileSync('../frozen-inventory.json'));
for(let i=0;i<old.mutations.length;i++)for(const k of new Set([...Object.keys(old.mutations[i]),...Object.keys(now.mutations[i])]))if(canonical(old.mutations[i][k])!==canonical(now.mutations[i][k]))result.mutationDelta.push({id:now.mutations[i].id,domain:now.mutations[i].domain,field:k,old:old.mutations[i][k],current:now.mutations[i][k],matchesCurrentFrozenSource:now.mutations[i].sourceSha256===frozen[now.mutations[i].source].sha256});
const stripped=c=>({...c,mutations:c.mutations.map(m=>({...m,sourceSha256:m.domain==='coverage'?'<approved-current-source-hash>':m.sourceSha256}))});result.catalogAllOtherSemanticsEqual=canonical(stripped(old))===canonical(stripped(now));
result.inventoryEqual=fs.readFileSync('reference-baseline/scripts/hiso-baseline-inventory.json').equals(fs.readFileSync('runtime/scripts/hiso-baseline-inventory.json'));
result.pass=result.tests.every(t=>t.namesEqual&&t.staticNamesMatchNative&&t.assertionsEqual&&t.testRegistrationsAndCallbacksEqual&&t.baselineCaseCount===t.nativeCaseCount)&&result.mutationDelta.length===3&&result.mutationDelta.every(d=>d.domain==='coverage'&&d.field==='sourceSha256'&&d.matchesCurrentFrozenSource)&&result.catalogAllOtherSemanticsEqual&&result.inventoryEqual;
fs.writeFileSync('authority-ast-comparison.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({...result,tests:result.tests.map(({baseline,current,...t})=>t)},null,2));process.exitCode=result.pass?0:1;
