import ctypes,os,sys
s=ctypes.CDLL('libseccomp.so.2',use_errno=True)
s.seccomp_init.argtypes=[ctypes.c_uint32];s.seccomp_init.restype=ctypes.c_void_p
s.seccomp_syscall_resolve_name.argtypes=[ctypes.c_char_p];s.seccomp_syscall_resolve_name.restype=ctypes.c_int
class Cmp(ctypes.Structure):_fields_=[('arg',ctypes.c_uint),('op',ctypes.c_int),('datum_a',ctypes.c_uint64),('datum_b',ctypes.c_uint64)]
s.seccomp_rule_add_array.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_int,ctypes.c_uint,ctypes.POINTER(Cmp)]
s.seccomp_load.argtypes=[ctypes.c_void_p]
ctx=s.seccomp_init(0x7fff0000);assert ctx
for domain in [2,10]:
 c=Cmp(0,4,domain,0);assert s.seccomp_rule_add_array(ctx,0x50001,s.seccomp_syscall_resolve_name(b'socket'),1,ctypes.byref(c))==0
assert s.seccomp_load(ctx)==0
os.execvp(sys.argv[1],sys.argv[1:])
