import os,stat,json,hashlib,sys
from pathlib import Path
P=Path('/home/ricardo/.cache/cvg-harness-green-20261004/ci-native-coherence-review-r12'); S=P/'source'; O=P/'output'
def read(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb') as f:return f.read()
def listing(p):
 fd=os.open(p,os.O_RDONLY|os.O_DIRECTORY|os.O_NOATIME)
 try:return sorted(os.listdir(fd))
 finally:os.close(fd)
inv={};meta={}
def visit(p,rel):
 st=os.lstat(p);meta[rel]={k:getattr(st,k) for k in ['st_mode','st_ino','st_dev','st_nlink','st_uid','st_gid','st_size','st_atime_ns','st_mtime_ns','st_ctime_ns','st_blocks','st_blksize','st_rdev']}
 if stat.S_ISDIR(st.st_mode):
  for n in listing(p):visit(p/n,n if rel=='.' else rel+'/'+n)
 elif stat.S_ISLNK(st.st_mode):inv[rel]={'kind':'link','target':os.readlink(p)}
 elif stat.S_ISREG(st.st_mode):inv[rel]={'bytes':st.st_size,'kind':'file','sha256':hashlib.sha256(read(p)).hexdigest()}
 else:raise RuntimeError(str(p))
visit(S,'.')
frozen=json.loads(read(P/'frozen-inventory.json'))
result={'stage':sys.argv[1],'entries':len(inv),'metadataEntries':len(meta),'directories':len(meta)-len(inv),'frozenLiteralSHA256':hashlib.sha256(read(P/'frozen-inventory.json')).hexdigest(),'matchesFrozen':inv==frozen,'inventoryDifferences':[k for k in sorted(inv.keys()|frozen.keys()) if inv.get(k)!=frozen.get(k)]}
for name,obj in [('inventory',inv),('metadata',meta),('seal',result)]:
 (O/(sys.argv[1]+'-'+name+'.json')).write_text(json.dumps(obj,sort_keys=True,indent=2)+'\n')
if sys.argv[1]=='after':
 before=json.loads((O/'before-metadata.json').read_text());result['metadataDifferences']=[k for k in sorted(meta.keys()|before.keys()) if meta.get(k)!=before.get(k)];(O/'after-seal.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
