import pathlib,subprocess,os,json,sys,time
out=pathlib.Path(__file__).resolve().parent;runtime=out/'runtime';node='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node'
env={'PATH':str(pathlib.Path(node).parent)+':/usr/bin:/bin','TMPDIR':str(out/'tmp'),'LANG':'C.UTF-8','C1_ARCHIVE':str(out/'supplied-archive')}
# No inherited NODE_OPTIONS, credentials, provider/PG config, DNS overrides or npm hooks.
def run(name,args,cwd=runtime,timeout=180):
 start=time.time()
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  p=subprocess.run(['/usr/bin/python3',str(out/'guard.py'),*args],cwd=cwd,env=env,stdout=stdout,stderr=stderr,timeout=timeout,close_fds=True)
 result={'name':name,'argv':args,'cwd':str(cwd),'exitCode':p.returncode,'seconds':time.time()-start,'externalCalls':0,'seccomp':True}
 (out/(name+'.command.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
 return p.returncode
if __name__=='__main__':
 if sys.argv[1]=='supplied':run('supplied',[node,'--require',str(runtime/'preserve.cjs'),'node_modules/vitest/vitest.mjs','run','tests/product-boundary-lexical-static.test.js','--no-file-parallelism','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(out/'supplied-native.json')])
 elif sys.argv[1]=='supplied-archive':
  env['NODE_OPTIONS']='--require='+str(runtime/'preserve.cjs')
  run('supplied-archive',[node,'node_modules/vitest/vitest.mjs','run','tests/product-boundary-lexical-static.test.js','--no-file-parallelism','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(out/'supplied-archive-native.json')])
 elif sys.argv[1]=='guard':run('guard-selftest',['/usr/bin/python3',str(out/'guard.py'),'--selftest'])
 elif sys.argv[1]=='probes':run('probes',[node,str(runtime/'probes.mjs')],timeout=180)
 elif sys.argv[1]=='cli':run(sys.argv[2],[node,'scripts/check-product-boundary.mjs',sys.argv[3]])
