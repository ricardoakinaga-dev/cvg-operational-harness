import pathlib,json,hashlib,os,stat
p=pathlib.Path(__file__).resolve().parent.parent;o=p/'output';r=o/'runtime';inv=json.loads((p/'frozen-inventory.json').read_text());pre=json.loads((o/'metadata-pre.json').read_text());post=json.loads((o/'metadata-post.json').read_text())
def digest(f):
 h=hashlib.sha256()
 with f.open('rb') as stream:
  for b in iter(lambda:stream.read(1048576),b''):h.update(b)
 return h.hexdigest()
summary={}
for group,test in {'allSource':lambda x:True,'deps':lambda x:'node_modules' in x.split('/'),'dist':lambda x:'dist' in x.split('/')}.items():
 keys=[k for k in pre if test(k)];summary[group]={'entries':len(keys),'directories':sum(pre[k]['kind']=='directory' for k in keys),'files':sum(pre[k]['kind']=='file' for k in keys),'links':sum(pre[k]['kind']=='link' for k in keys),'exactChanges':[k for k in keys if pre[k]!=post.get(k)]}
(o/'integrity-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
links=[];archive=[]
for base in [o/'fresh-fixtures',o/'supplied-archive',r]:
 def walk(base):
  for x in sorted(base.iterdir()):
   s=x.lstat();rel=str(x.relative_to(o))
   if stat.S_ISLNK(s.st_mode):
    target=os.readlink(x);resolved=x.resolve();entry={'path':rel,'target':target,'canonicalTarget':str(resolved),'withinOutput':resolved.is_relative_to(o),'exists':resolved.exists()};links.append(entry)
    if not str(x).startswith(str(r)):archive.append({'path':rel,'kind':'link','target':target})
   elif stat.S_ISDIR(s.st_mode):walk(x)
   elif not str(x).startswith(str(r)):archive.append({'path':rel,'kind':'file','bytes':s.st_size,'sha256':digest(x)})
 walk(base)
(o/'links-index.json').write_text(json.dumps({'links':len(links),'outsideOutput':sum(not x['withinOutput'] for x in links),'entries':links},indent=2)+'\n')
(o/'archive-index.json').write_text(json.dumps({'entries':len(archive),'fixturesExecuted':False,'archive':archive},indent=2)+'\n')
copy=[]
for rel,v in inv.items():
 f=r/rel
 if not (f.exists() or f.is_symlink()):continue
 if v['kind']=='link':ok=f.is_symlink() and os.readlink(f)==v['target']
 else:ok=f.is_file() and digest(f)==v['sha256']
 copy.append({'path':rel,'kind':v['kind'],'exactContentOrLiteralLink':ok})
(o/'runtime-copy-integrity.json').write_text(json.dumps({'entries':len(copy),'mismatches':[x for x in copy if not x['exactContentOrLiteralLink']],'copies':copy},indent=2)+'\n')
print(json.dumps({'metadata':summary,'archiveEntries':len(archive),'outputLinks':len(links),'outsideOutput':sum(not x['withinOutput'] for x in links),'copiedEntries':len(copy),'copyMismatches':sum(not x['exactContentOrLiteralLink'] for x in copy)}))
