import os,sys,json,stat,hashlib,pathlib
packet=pathlib.Path(__file__).resolve().parent.parent
src=packet/'source'; out=packet/'output'
def snapshot():
 result={}
 def walk(p):
  s=p.lstat();rel=str(p.relative_to(src)) or '.'
  v={k:getattr(s,'st_'+k) for k in ['mode','size','mtime_ns','ctime_ns','dev','ino','nlink']}
  if stat.S_ISLNK(s.st_mode):v.update(kind='link',target=os.readlink(p))
  elif stat.S_ISREG(s.st_mode):
   h=hashlib.sha256()
   with p.open('rb') as f:
    for b in iter(lambda:f.read(1048576),b''):h.update(b)
   v.update(kind='file',sha256=h.hexdigest())
  elif stat.S_ISDIR(s.st_mode):v['kind']='directory'
  else:v['kind']='other'
  result[rel]=v
  if v['kind']=='directory':
   for q in sorted(p.iterdir()):walk(q)
 walk(src)
 return result
phase=sys.argv[1];now=snapshot();(out/('metadata-'+phase+'.json')).write_text(json.dumps(now,sort_keys=True,indent=2)+'\n')
frozen=json.loads((packet/'frozen-inventory.json').read_text()); actual={p:({'kind':'link','target':v['target']} if v['kind']=='link' else {'kind':'file','bytes':v['size'],'sha256':v['sha256']}) for p,v in now.items() if v['kind']!='directory'}
diff=[p for p in set(actual)|set(frozen) if actual.get(p)!=frozen.get(p)]
r={'phase':phase,'frozenEntries':len(frozen),'actualEntries':len(actual),'directories':sum(v['kind']=='directory' for v in now.values()),'freezeDifferences':sorted(diff)}
if phase=='post':
 pre=json.loads((out/'metadata-pre.json').read_text());r['exactPrePostDifferences']=[p for p in sorted(set(pre)|set(now)) if pre.get(p)!=now.get(p)]
(out/('integrity-'+phase+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
