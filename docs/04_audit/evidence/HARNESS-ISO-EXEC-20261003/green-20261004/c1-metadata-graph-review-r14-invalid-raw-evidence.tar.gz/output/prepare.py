import pathlib,shutil,json,os
p=pathlib.Path(__file__).resolve().parent.parent;s=p/'source';o=p/'output';r=o/'runtime';r.mkdir(exist_ok=True)
paths=['node_modules','scripts/check-product-boundary.mjs','scripts/boundary-manifests.mjs','scripts/boundary-lexical.mjs','scripts/boundary-code-execution.mjs','scripts/tsconfig-path-grammar.mjs','tests/product-boundary-lexical-static.test.js','package.json','vitest.config.mts']
for rel in paths:
 dest=r/rel;dest.parent.mkdir(parents=True,exist_ok=True)
 if (s/rel).is_dir():shutil.copytree(s/rel,dest,symlinks=True)
 else:shutil.copy2(s/rel,dest)
(o/'tmp').mkdir(exist_ok=True)
# Preserve supplied bytes while keeping their temporary fixture tree as evidence.
# Test runner rmSync is neutralized only for tmp tree cleanup through trusted preload.
(o/'runtime-copy.json').write_text(json.dumps({'physicalRuntime':str(r),'copied':paths,'fixturesExecuted':False,'original253':'hash-only;not copied or run'},indent=2)+'\n')
