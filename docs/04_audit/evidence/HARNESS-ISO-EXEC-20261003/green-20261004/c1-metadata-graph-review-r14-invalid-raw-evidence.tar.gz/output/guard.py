import ctypes,ctypes.util,os,sys,errno,socket,json
lib=ctypes.CDLL(ctypes.util.find_library('seccomp'),use_errno=True)
lib.seccomp_init.argtypes=[ctypes.c_uint32];lib.seccomp_init.restype=ctypes.c_void_p
lib.seccomp_syscall_resolve_name.argtypes=[ctypes.c_char_p];lib.seccomp_syscall_resolve_name.restype=ctypes.c_int
class Arg(ctypes.Structure):_fields_=[('arg',ctypes.c_uint),('op',ctypes.c_uint),('datum_a',ctypes.c_uint64),('datum_b',ctypes.c_uint64)]
lib.seccomp_rule_add_array.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_int,ctypes.c_uint,ctypes.POINTER(Arg)];lib.seccomp_rule_add_array.restype=ctypes.c_int
lib.seccomp_load.argtypes=[ctypes.c_void_p];lib.seccomp_load.restype=ctypes.c_int
lib.seccomp_release.argtypes=[ctypes.c_void_p]
ctx=lib.seccomp_init(0x7fff0000)
if not ctx:raise RuntimeError('seccomp_init')
for name in ['socket','socketpair']:
 nr=lib.seccomp_syscall_resolve_name(name.encode());a=Arg(0,1,socket.AF_UNIX,0)
 if nr<0 or lib.seccomp_rule_add_array(ctx,0x50000|errno.EPERM,nr,1,ctypes.byref(a))!=0:raise RuntimeError('seccomp_rule')
if lib.seccomp_load(ctx)!=0:raise RuntimeError('seccomp_load')
lib.seccomp_release(ctx)
if sys.argv[1]=='--selftest':
 rows=[]
 for family in [socket.AF_INET,socket.AF_INET6,socket.AF_PACKET,socket.AF_NETLINK]:
  try:s=socket.socket(family,socket.SOCK_DGRAM);s.close();rows.append({'family':family,'blocked':False})
  except OSError as e:rows.append({'family':family,'blocked':e.errno==errno.EPERM,'errno':e.errno})
 a,b=socket.socketpair();a.send(b'local');assert b.recv(5)==b'local';a.close();b.close()
 assert all(r['blocked'] for r in rows)
 print(json.dumps({'verified':True,'blocked':rows,'unixIPC':True,'externalCalls':0,'policy':'socket/socketpair domain must equal AF_UNIX; inherited by exec/process/threads'}))
else:os.execv(sys.argv[1],sys.argv[1:])
