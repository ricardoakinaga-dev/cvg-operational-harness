import os,stat,hashlib,json,sys
from pathlib import Path
P=Path(__file__).resolve().parent.parent
S=P/'source'
def snapshot():
 out={}
 def walk(p):
  st=p.lstat(); k=str(p.relative_to(S))
  v={x:getattr(st,'st_'+x) for x in ['mode','size','mtime_ns','ctime_ns','dev','ino','nlink']}
  if stat.S_ISLNK(st.st_mode):v.update(kind='link',target=os.readlink(p))
  elif stat.S_ISDIR(st.st_mode):v['kind']='directory'
  elif stat.S_ISREG(st.st_mode):v.update(kind='file',sha256=hashlib.file_digest(open(p,'rb'),'sha256').hexdigest())
  else:v['kind']='special'
  out[k]=v
  if v['kind']=='directory':
   for n in sorted(os.listdir(p)):walk(p/n)
 walk(S);return out
stage=sys.argv[1]; current=snapshot(); (P/'output'/f'{stage}-invariance.json').write_text(json.dumps(current,sort_keys=True,indent=2))
if stage=='pre':
 frozen=json.load(open(P/'frozen-inventory.json')); delta=[]
 for k,v in frozen.items():
  c=current.get(k,{})
  if v['kind']!=c.get('kind') or (v['kind']=='file' and (v['sha256']!=c.get('sha256') or v['bytes']!=c.get('size'))) or (v['kind']=='link' and v['target']!=c.get('target')):delta.append(k)
 extra=[k for k,v in current.items() if v['kind']!='directory' and k not in frozen]
 result={'frozenEntries':len(frozen),'files':sum(v['kind']=='file' for v in current.values()),'links':sum(v['kind']=='link' for v in current.values()),'directories':sum(v['kind']=='directory' for v in current.values()),'freezeDifferences':delta,'extra':extra}
else:
 before=json.load(open(P/'output'/'pre-invariance.json'));result={'differences':[k for k in set(before)|set(current) if before.get(k)!=current.get(k)]}
(P/'output'/f'{stage}-invariance-summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
