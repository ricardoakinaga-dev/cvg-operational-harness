import fs from 'node:fs';import path from 'node:path';import {auditProductBoundary} from './runtime/scripts/check-product-boundary.mjs';
const output=path.dirname(new URL(import.meta.url).pathname);const fields=['dependencies','devDependencies','optionalDependencies','peerDependencies'];const observations=[];
function make(id){const root=path.join(output,'cases',id);const put=(rel,value)=>{const p=path.join(root,rel);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof value==='string'?value:JSON.stringify(value,null,2));};for(const p of ['apps','legacy','packages/core/src','products/consumer/src'])fs.mkdirSync(path.join(root,p),{recursive:true});put('package.json',{private:true,type:'module',workspaces:['packages/*','products/*']});put('packages/core/package.json',{name:'@inert/core',type:'module'});put('products/consumer/package.json',{name:'@inert/consumer',type:'module'});put('products/consumer/src/index.mts','export const label="consumer";');put('packages/core/src/index.mts','import "../../../auxiliary/actor/src/entry.mts";');put('auxiliary/actor/package.json',{name:'@inert/actor',type:'module'});put('auxiliary/actor/src/entry.mts','export const label="neutral";');put('tsconfig.base.json',{compilerOptions:{module:'NodeNext',moduleResolution:'NodeNext',target:'ESNext',allowJs:true}});return {root,put};}
function probe(id,expected,change){const v=make(id);change(v);let audit,error;try{audit=auditProductBoundary(v.root)}catch(e){error=e.message}const actual=error?'ERROR':audit.status;const ok=expected==='BLOCKED'?actual!=='PASS':expected===actual;const record={id,expected,actual,ok,fixturesExecuted:false,root:path.relative(output,v.root),audit,error};observations.push(record);fs.writeFileSync(path.join(output,'raw',id+'.json'),JSON.stringify(record,null,2));}
for(const field of fields){
 for(const kind of ['direct','alias-range','alias-tag','file-encoded','link','file-localhost','file-absolute','local-transitive','cycle-product','cycle-unknown','local-neutral-unknown']){
  const id=field+'-'+kind;const exp=kind.endsWith('unknown')?'INCOMPLETE':'FAIL';probe(id,exp,({root,put})=>{
   let deps;
   if(kind==='direct')deps={'@inert/consumer':'workspace:*'};
   if(kind==='alias-range')deps={label:'npm:@inert/consumer@^1.0.0'};
   if(kind==='alias-tag')deps={label:'npm:@inert/consumer@next'};
   if(kind==='file-encoded')deps={label:'file:../../../../products/%63onsumer'};
   if(kind==='link')deps={label:'link:../../../../products/consumer'};
   if(kind==='file-localhost')deps={label:'file://localhost'+root+'/products/consumer'};
   if(kind==='file-absolute')deps={label:'file:'+root+'/products/consumer'};
   if(['local-transitive','cycle-product','cycle-unknown','local-neutral-unknown'].includes(kind)){
    deps={label:'file:../../../../auxiliary/target'};put('auxiliary/target/package.json',{name:'@inert/target',type:'module',...(kind.startsWith('cycle')?{[field]:{back:'file:../actor'}}:{})});put('auxiliary/target/src/index.mts','export const label="target";');if(!kind.endsWith('unknown'))put('auxiliary/target/dist/nested/package.json',{[field]:{label:'npm:@inert/consumer@1.0.0'}});
   }
   put('auxiliary/actor/dist/nested/package.json',{[field]:deps});
  });
 }
 for(const reached of [true,false])probe(field+'-'+(reached?'reached':'opaque')+'-nested-invalid',reached?'BLOCKED':'PASS',({put})=>{if(!reached)put('packages/core/src/index.mts','export const label="neutral";');put('auxiliary/actor/dist/cache/deep/package.json',{[field]:[]});});
 probe(field+'-already-censused','FAIL',({put})=>{put('packages/core/src/index.mts','export const label="neutral";');put('packages/core/dist/deep/package.json',{[field]:{'@inert/consumer':'*'}});});
 probe(field+'-installed-registry-closure','FAIL',({put})=>{put('auxiliary/actor/dist/nested/package.json',{[field]:{'external-label':'1.0.0'}});put('node_modules/external-label/package.json',{name:'external-label',type:'module',version:'1.0.0',[field]:{'@inert/consumer':'*'}});put('node_modules/external-label/index.mjs','export const label="dependency";');});
 probe(field+'-installed-alias-closure','FAIL',({put})=>{put('auxiliary/actor/dist/nested/package.json',{[field]:{alias:'npm:external-label@^1.0.0'}});put('node_modules/alias/package.json',{name:'external-label',type:'module',version:'1.0.0',[field]:{'@inert/consumer':'*'}});put('node_modules/alias/index.mjs','export const label="dependency";');});
 probe(field+'-unknown-workspace','INCOMPLETE',({put})=>{put('auxiliary/actor/dist/package.json',{[field]:{'@inert/missing':'workspace:*'}});});
}
probe('positive-root-ancestry-opaque','PASS',({put})=>{put('packages/core/src/index.mts','import "../../../loose/label.mts";');put('loose/label.mts','export const label="loose";');put('archive/opaque/package.json',[]);});
probe('positive-valid-dist-census','PASS',({put})=>{put('auxiliary/actor/dist/cache/package.json',{type:'module'});});
for(const extension of ['js','mjs','cjs','jsx','ts','mts'])probe('bad-grammar-'+extension,'INCOMPLETE',({put})=>put('auxiliary/actor/src/entry.mts','import "./broken.'+extension+'";')||put('auxiliary/actor/src/broken.'+extension,'export const label = ;'));
probe('missing-local-package-metadata','BLOCKED',({put})=>{put('auxiliary/actor/dist/package.json',{dependencies:{label:'file:../../../auxiliary/target'}});put('auxiliary/target/label.mts','export const label="empty";');});
probe('nearest-nested-context','FAIL',({put})=>{put('auxiliary/actor/src/package.json',{dependencies:{'@inert/consumer':'*'}});});
probe('unresolved-runtime','INCOMPLETE',({put})=>put('auxiliary/actor/src/entry.mts','import "not-installed-label";'));
probe('nonliteral-module','INCOMPLETE',({put})=>put('auxiliary/actor/src/entry.mts','const label="neutral";import(label);'));
probe('unreached-parse-diagnostic','PASS',({put})=>{put('packages/core/src/index.mts','export const label="neutral";');put('products/consumer/src/index.mts','export const label = ;');});
probe('reached-reflection-stays-blocking','INCOMPLETE',({put})=>put('auxiliary/actor/src/entry.mts','export const label=Object.getPrototypeOf({});'));
probe('opaque-reflection-does-not-taint-core','PASS',({put})=>{put('packages/core/src/index.mts','export const label="neutral";');put('products/consumer/src/index.mts','export const label=Object.getPrototypeOf({});');});
probe('installed-source-dependency-transitive','FAIL',({put})=>{put('packages/core/src/index.mts','import "external-entry";');put('node_modules/external-entry/package.json',{name:'external-entry',type:'module',main:'index.mjs',dependencies:{'external-next':'1.0.0'}});put('node_modules/external-entry/index.mjs','export const label="entry";');put('node_modules/external-next/package.json',{name:'external-next',type:'module',dependencies:{'@inert/consumer':'*'}});put('node_modules/external-next/index.mjs','export const label="next";');});
fs.writeFileSync(path.join(output,'probe-index.json'),JSON.stringify(observations,null,2));console.log(JSON.stringify({cases:observations.length,passed:observations.filter(x=>x.ok).length,mismatches:observations.filter(x=>!x.ok)},null,2));
