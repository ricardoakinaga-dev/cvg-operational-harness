import os,shutil,json,hashlib
from pathlib import Path
O=Path(__file__).resolve().parent;S=O.parent/'source'; R=O/'runtime';R.mkdir(exist_ok=True)
log=[]
def cp(p,q):
 q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);log.append({'source':str(p.relative_to(S)),'destination':str(q.relative_to(O)),'sha256':hashlib.file_digest(open(p,'rb'),'sha256').hexdigest()})
def deps(p,q):
 q.mkdir(exist_ok=True)
 for n in os.scandir(p):
  x=Path(n.path);y=q/n.name
  if n.is_symlink():
   if p.name=='.bin': y.symlink_to(os.readlink(x))
   continue
  if n.name.lower() in ['docs','doc','documentation','test','tests','__tests__','examples','.git'] or n.name.lower().startswith(('readme','license','changelog','history','notice','authors')) or x.suffix.lower() in ['.md','.mdx','.rst']:continue
  if n.is_dir():deps(x,y)
  elif n.is_file():cp(x,y)
deps(S/'node_modules',R/'node_modules')
for name in ['check-product-boundary.mjs','boundary-manifests.mjs','boundary-lexical.mjs','boundary-code-execution.mjs','tsconfig-path-grammar.mjs']:cp(S/'scripts'/name,R/'scripts'/name)
cp(S/'tests/product-boundary-lexical-static.test.js',R/'tests/product-boundary-lexical-static.test.js')
(R/'package.json').write_text(json.dumps({'type':'module','private':True}))
(O/'copy-index.json').write_text(json.dumps(log,indent=2));print('physicalRuntimeFiles',len(log))
for name in ['tmp','home','cache','raw','cases']: (O/name).mkdir(exist_ok=True)
