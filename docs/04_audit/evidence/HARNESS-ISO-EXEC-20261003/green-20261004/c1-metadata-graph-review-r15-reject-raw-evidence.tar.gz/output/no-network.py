import ctypes,ctypes.util,errno,json,os,socket,subprocess,sys,time
from pathlib import Path
O=Path(__file__).resolve().parent
lib=ctypes.CDLL(ctypes.util.find_library('seccomp'),use_errno=True)
lib.seccomp_init.argtypes=[ctypes.c_uint32];lib.seccomp_init.restype=ctypes.c_void_p
lib.seccomp_syscall_resolve_name.argtypes=[ctypes.c_char_p];lib.seccomp_syscall_resolve_name.restype=ctypes.c_int
class ArgCmp(ctypes.Structure):_fields_=[('arg',ctypes.c_uint),('op',ctypes.c_uint),('datum_a',ctypes.c_uint64),('datum_b',ctypes.c_uint64)]
lib.seccomp_rule_add_array.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_int,ctypes.c_uint,ctypes.POINTER(ArgCmp)]
lib.seccomp_load.argtypes=[ctypes.c_void_p];lib.seccomp_release.argtypes=[ctypes.c_void_p]
ctx=lib.seccomp_init(0x7fff0000)
# Permit AF_UNIX infrastructure only. Deny creation of all other socket domains.
for call in ['socket','socketpair']:
 c=ArgCmp(0,1,socket.AF_UNIX,0) # SCMP_CMP_NE
 rc=lib.seccomp_rule_add_array(ctx,0x50000|errno.EPERM,lib.seccomp_syscall_resolve_name(call.encode()),1,ctypes.byref(c))
 if rc:raise RuntimeError(('rule',call,rc))
rc=lib.seccomp_load(ctx);lib.seccomp_release(ctx)
if rc:raise RuntimeError(('load',rc))
checks=[]
for family in [socket.AF_INET,socket.AF_INET6,socket.AF_NETLINK,socket.AF_PACKET]:
 try:
  s=socket.socket(family,socket.SOCK_DGRAM);s.close();checks.append({'family':int(family),'blocked':False})
 except OSError as e:checks.append({'family':int(family),'blocked':e.errno==errno.EPERM,'errno':e.errno})
a,b=socket.socketpair();a.close();b.close()
assert all(x['blocked'] for x in checks)
label=sys.argv[1];argv=sys.argv[2:]
env={'PATH':'/home/ricardo/.nvm/versions/node/v22.23.2/bin:/usr/bin:/bin','HOME':str(O/'home'),'TMPDIR':str(O/'tmp'),'TMP':str(O/'tmp'),'TEMP':str(O/'tmp'),'XDG_CACHE_HOME':str(O/'cache'),'CI':'1','NO_COLOR':'1'}
t=time.time(); p=subprocess.run(argv,cwd=O,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(O/'raw'/f'{label}.stdout').write_bytes(p.stdout);(O/'raw'/f'{label}.stderr').write_bytes(p.stderr)
e={'argv':argv,'exitCode':p.returncode,'durationSeconds':time.time()-t,'seccomp':{'loaded':True,'inheritedByAllChildren':True,'socketDomainAllowlist':['AF_UNIX'],'selftest':checks,'unixSocketpair':True},'environment':env}
(O/'raw'/f'{label}.execution.json').write_text(json.dumps(e,indent=2));print(json.dumps({'label':label,'exitCode':p.returncode,'durationSeconds':e['durationSeconds'],'seccompSelftest':checks}));sys.exit(p.returncode)
