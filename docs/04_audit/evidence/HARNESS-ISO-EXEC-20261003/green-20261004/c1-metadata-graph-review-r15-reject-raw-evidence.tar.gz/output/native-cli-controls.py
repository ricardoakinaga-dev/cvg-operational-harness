import json,subprocess,time
from pathlib import Path
O=Path(__file__).resolve().parent;node='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node'
probes=json.load(open(O/'probe-index.json')); selected=[p for p in probes if not p['ok'] or p['id'] in ['dependencies-direct','dependencies-alias-range','dependencies-local-transitive','dependencies-cycle-unknown','dependencies-already-censused','positive-root-ancestry-opaque','positive-valid-dist-census','missing-local-package-metadata','nonliteral-module','bad-grammar-mjs','unreached-parse-diagnostic','reached-reflection-stays-blocking']]
results=[]
for p in selected:
 argv=[node,str(O/'runtime/scripts/check-product-boundary.mjs'),str(O/p['root'])];t=time.time();run=subprocess.run(argv,cwd=O,capture_output=True,text=True)
 label='cli-'+p['id'];(O/'raw'/f'{label}.stdout').write_text(run.stdout);(O/'raw'/f'{label}.stderr').write_text(run.stderr)
 audit=json.loads(run.stdout) if run.stdout else None
 result={'id':p['id'],'expected':p['expected'],'actual':audit['status'] if audit else 'ERROR','exitCode':run.returncode,'argv':argv,'durationSeconds':time.time()-t,'apiCliAgree':(audit==p.get('audit') if audit else run.returncode==2 and run.stderr.strip()==p.get('error')),'stdout':'raw/'+label+'.stdout','stderr':'raw/'+label+'.stderr'};results.append(result)
(O/'native-exactcases.json').write_text(json.dumps(results,indent=2));print(json.dumps({'nativeCliCases':len(results),'apiCliAgreement':sum(x['apiCliAgree'] for x in results),'exitCodes':{str(k):sum(x['exitCode']==k for x in results) for k in [0,1,2]}},indent=2))
