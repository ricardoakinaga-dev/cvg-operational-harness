// Trusted verification guard: bounded API-level trace, not a syscall monitor.
const fs = require('node:fs');
const path = require('node:path');
const { threadId } = require('node:worker_threads');
const { syncBuiltinESMExports } = require('node:module');
const out = __dirname;
const save = fs.writeFileSync.bind(fs);
const record = { threadId, node: process.version, executable: process.execPath, cwd: process.cwd(), networkAttempts: 0, processAttempts: 0, outsidePathAttempts: 0, deniedSamples: [], calls: {}, samples: [] };
function denied(kind) {
 return function () { record[kind]++; throw new Error('critic boundary: '+kind); };
}
for (const [mod,names] of [
 ['node:net',['connect','createConnection']], ['node:tls',['connect']],
 ['node:http',['request','get']], ['node:https',['request','get']],
 ['node:dgram',['createSocket']], ['node:dns',['lookup','resolve','resolve4','resolve6']],
]) {const m=require(mod);for(const n of names)if(typeof m[n]==='function')m[n]=denied('networkAttempts');}
require('node:net').Socket.prototype.connect=denied('networkAttempts');
if (globalThis.fetch) globalThis.fetch=denied('networkAttempts');
for(const n of ['spawn','spawnSync','fork','exec','execSync','execFile','execFileSync'])require('node:child_process')[n]=denied('processAttempts');
const readOps=['readFile','readFileSync','readdir','readdirSync','stat','statSync','lstat','lstatSync','access','accessSync','realpath','realpathSync','readlink','readlinkSync'];
const writeOps=['writeFile','writeFileSync','appendFile','appendFileSync','mkdir','mkdirSync','unlink','unlinkSync','rmdir','rmdirSync','rm','rmSync','chmod','chmodSync','utimes','utimesSync','open','openSync','rename','renameSync','copyFile','copyFileSync'];
function check(op,arg) {
 if(typeof arg==='number')return;
 if(arg instanceof URL)arg=require('node:url').fileURLToPath(arg);
 if(Buffer.isBuffer(arg))arg=arg.toString();
 if(typeof arg!=='string')return;
 const p=path.resolve(arg);record.calls[op]=(record.calls[op]||0)+1;
 if(record.samples.length<48)record.samples.push({op,path:p});
 // Existing trusted Store lock reads Linux boot identity. Keep this exact
 // native read, without replacing lock semantics or fixture behavior.
 if(op==='readFileSync'&&p==='/proc/sys/kernel/random/boot_id'){record.bootIdentityReads=(record.bootIdentityReads||0)+1;return;}
 if(p!==out&&!p.startsWith(out+path.sep)){record.outsidePathAttempts++;if(record.deniedSamples.length<32)record.deniedSamples.push({op,path:p});throw new Error('critic boundary: outside output '+p);}
}
for(const obj of [fs,fs.promises])for(const op of [...readOps,...writeOps]){
 const original=obj[op];if(typeof original!=='function')continue;
 obj[op]=function(...args){check(op,args[0]);if(/^(rename|copyFile)/.test(op))check(op,args[1]);return original.apply(this,args)};
}
syncBuiltinESMExports();
const flush=()=>save(path.join(out,'logs','boundary-'+threadId+'.json'),JSON.stringify(record,null,2));
module.exports=flush;
process.once('exit',flush);
