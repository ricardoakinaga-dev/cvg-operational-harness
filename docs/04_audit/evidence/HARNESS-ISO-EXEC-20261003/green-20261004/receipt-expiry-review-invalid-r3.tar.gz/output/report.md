# Crítico I1 — TTL semanticR9-R3

Veredito: **INVALID**, restrito à validade desta revisão TTL. A sessão leu uma skill procedural externa antes de authority/freeze; isso desvia da exigência de autoridade primeiro e leitura limitada ao packet. Não houve leitura de julgamentos anteriores nem de conteúdo do repositório Root. Nenhum release, produção, SLO ou cobertura global é concedido. A skill não foi usada como evidência sobre o candidato. Uma nova revisão deve começar diretamente por authority/freeze para emitir um receipt válido.

## Evidência semântica observada

Freeze SHA-256 f732c9fdfb9742d6b55727fa1001ccbf9f00e94f303951537006c03ccb696317 conferido; 21.191 entradas congeladas coincidiram. Snapshots de Source/original incluem também suas duas raízes: 21.193 entradas com bytes SHA-256, modos, mtime em nanossegundos, links e diretórios. Antes/depois idênticos. Runtime físico preexistente comparado: 19.198 arquivos com bytes iguais; nenhum link apontava para fora dele. Testes executados somente nesse runtime com /home/ricardo/.nvm/versions/node/v22.23.2/bin/node. Identidade v22.23.2 foi exibida em stdout antes da verificação. Config nova, helpers, caches, logs e TMPDIR ficaram em output. Docs permaneceram opacos, apenas sujeitos a hashes.

Sete supplied own e nove probes adversariais passaram (16/16) na execução final. Logs mantêm execuções anteriores e a falha induzida por uma guarda excessivamente restritiva. Essa guarda bloqueou /proc/sys/kernel/random/boot_id usado pelo lock real do Store. Foi corrigida para permitir exclusivamente essa leitura nativa existente, sem alteração de Store ou fixtures. Config manteve timeout de 15.000 ms e os bytes dos supplied tests não foram modificados. A tentativa de copiar um JSON de falha usou caminho relativo incorreto e não criou o arquivo; o log completo da falha foi preservado.

## Argumento da invariante

O limite começa em Infinity. Admissão finita toma o mínimo entre o limite anterior e receivedAt+86400000, inclusive se a recepção retrocede. Matching só pode deixar um limite pessimista. Cada poda visita as deliveries, ignora matched, remove exatamente pelo predicado original now-receivedAt>86400000 e recompõe o mínimo entre unmatched restantes. NaN nunca expira pelo predicado original e não contamina o limite. Datas parseadas suportadas são milissegundos inteiros dentro de ±8,64e15; somar TTL continua dentro do domínio inteiro exato de Number, mesmo quando o expiry supera o máximo representável por Date. Diferenças perto da fronteira TTL também são exatas; diferenças extremas arredondadas continuam muito maiores que TTL.

O Store copia o número primitivo para validação, junto com Map copies dos índices. Validação não publica o limite nem a poda antes do journal append. Replay parte de emptyVertical e reaplica eventos, reconstruindo o limite. Diffs dos dois originais estão preservados em store.diff e vertical-state.diff. Não há nova propriedade serializada, evento, mudança de schema ou fsync introduzida pelo diff.

## Traces finitos e limites

101 casos de Date/extremos/NaN/boundary compararam projeção original e candidata. NaN foi testado diretamente na projeção; Store rejeitou dois timestamps inválidos antes de modificar bytes ou sequência. Trace determinístico com 1.200 eventos cobriu backdating, 92 completions e 109 marcações sintéticas de matched; um probe separado exercitou matching real com causalidade/dispatch/replay. Cap 1000, admissão bloqueada no TTL exato, admissão após poda e dedup permanente também coincidiram com o original. Batch rollback preservou bytes/estado e fronteiras após replay.

Dois probes de failed fsync não publicaram estado otimista em memória. Uma linha completa já escrita foi reaplicada ao reabrir. Isso registra a possibilidade de replay e não promete que um fsync falho tenha persistido a linha.

Supplied trace: 1000 receipts, 1001 eventos pré-expiry, zero visitas TTL antes da expiração e 1000 visitas na poda. Probe escalonado: N=64, visitas por poda 64..1, total 2080. Portanto skip TTL é O(1), cada poda necessária é O(N), e expiry escalonado pode produzir O(N²) total. A admissão ainda possui a contagem de capacidade preexistente, e outras rotinas podem percorrer índices. Não há alegação de linearidade global ou estabilidade de timing.

Guarda final instrumentou APIs Node no processo principal e nos dois workers: zero tentativas de rede e zero de processos filhos. Bloqueou 26 sondagens do bootstrap fora de output (detecção nativa e resolução de módulos/config); workers tiveram zero paths bloqueados, com 25 leituras nativas de boot identity do Store. As amostras são limitadas e contagens agregadas. Essa guarda não é monitor de syscalls nem prova de isolamento do SO. Não foram usados PG, instalações, providers, subagents ou push.

Artefatos: verdict.json, inputs-before/after.json, freeze-validation.json, runtime-validation.json, adversarial-trace.json, logs, config, guards e helpers. Manifesto finito inclui runtime e todos os outputs, exceto seus próprios dois arquivos de manifesto/selo, explicitamente autoexcluídos para evitar recursão.
