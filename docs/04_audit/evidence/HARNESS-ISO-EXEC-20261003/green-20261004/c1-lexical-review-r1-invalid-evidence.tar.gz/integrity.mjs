import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const root=path.resolve('source');
const hash=(buffer)=>crypto.createHash('sha256').update(buffer).digest('hex');
const expected=JSON.parse(fs.readFileSync('frozen-inventory.json'));
const inventoryHash=hash(fs.readFileSync('frozen-inventory.json'));
const actual={}, stats={}, mismatches=[], externalLinks=[];
function walk(dir){ for(const name of fs.readdirSync(dir).sort()){const absolute=path.join(dir,name), rel=path.relative(root,absolute); const s=fs.lstatSync(absolute); stats[rel]={dev:s.dev,ino:s.ino,nlink:s.nlink,mode:s.mode,size:s.size,mtimeMs:s.mtimeMs}; if(s.isDirectory()){walk(absolute);continue;} if(s.isSymbolicLink()){const target=fs.readlinkSync(absolute); actual[rel]={kind:'link',target};const resolved=path.resolve(path.dirname(absolute),target); if(!resolved.startsWith(root+path.sep)) externalLinks.push({path:rel,target,resolved});} else if(s.isFile()) actual[rel]={kind:'file',bytes:s.size,sha256:hash(fs.readFileSync(absolute))};else actual[rel]={kind:'other'};}}
walk(root);
for(const key of new Set([...Object.keys(expected),...Object.keys(actual)])){if(!expected[key]||!actual[key]||expected[key].kind!==actual[key].kind||expected[key].sha256!==actual[key].sha256||expected[key].bytes!==actual[key].bytes||expected[key].target!==actual[key].target) mismatches.push(key);}
const phase=process.argv[2];
const snapshot={phase,at:new Date().toISOString(),inventoryHash,expectedEntries:Object.keys(expected).length,entries:Object.keys(actual).length,files:Object.values(actual).filter(v=>v.kind==='file').length,links:Object.values(actual).filter(v=>v.kind==='link').length,mismatches,externalLinks,actual,stats};
fs.writeFileSync(`output/integrity-${phase}.json`,JSON.stringify(snapshot,null,2)+'\n');
let changes=[];
if(phase==='after'){const before=JSON.parse(fs.readFileSync('output/integrity-before.json'));for(const key of new Set([...Object.keys(before.stats),...Object.keys(stats)]))if(JSON.stringify(before.stats[key])!==JSON.stringify(stats[key])||JSON.stringify(before.actual[key])!==JSON.stringify(actual[key]))changes.push(key);}
const summary={phase,inventoryHash,expectedEntries:snapshot.expectedEntries,entries:snapshot.entries,files:snapshot.files,links:snapshot.links,mismatches,externalLinks,changes};fs.writeFileSync(`output/integrity-${phase}-summary.json`,JSON.stringify(summary,null,2)+'\n');console.log(JSON.stringify({...summary,mismatches:mismatches.slice(0,10),changes:changes.slice(0,10)}));
