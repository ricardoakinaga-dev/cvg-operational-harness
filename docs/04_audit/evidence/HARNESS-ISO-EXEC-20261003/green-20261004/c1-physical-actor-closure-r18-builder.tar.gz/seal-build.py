from pathlib import Path
import sys,json,os,hashlib,collections,re,difflib,datetime,stat
b=Path(__file__).parent;sys.path.insert(0,str(b));import snapshot
c=snapshot.C;src=snapshot.S;logs=b/'logs'
write=lambda p,v:(b/p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
hashbytes=lambda x:hashlib.sha256(x).hexdigest()
sha=lambda p:hashbytes(p.read_bytes())
sourceAfter=snapshot.walk(src);write('source-after.json',sourceAfter)
sourceBefore=json.loads((b/'source-before.json').read_text());old={r['path']:r for r in sourceBefore};new={r['path']:r for r in sourceAfter}
literalKeys=['kind','sha256','target','st_mode','st_uid','st_gid','st_size','st_atime_ns','st_mtime_ns','st_ctime_ns','st_ino','st_dev','st_nlink']
sourceDiff=[{'path':p,'fields':[k for k in literalKeys if old.get(p,{}).get(k)!=new.get(p,{}).get(k)]} for p in sorted(set(old)|set(new)) if any(old.get(p,{}).get(k)!=new.get(p,{}).get(k) for k in literalKeys)]
assert not sourceDiff,sourceDiff[:3]
write('source-literal-invariance.json',{'entriesBefore':len(old),'entriesAfter':len(new),'fields':literalKeys,'differences':sourceDiff,'literalInvariant':not sourceDiff,'sourceCategories':dict(collections.Counter(r['category'] for r in sourceAfter))})
rows=snapshot.walk(c);write('candidate-after.json',rows);current={r['path']:r for r in rows};prepared={r['path']:r for r in json.loads((b/'candidate-before-prepared.json').read_text())}
allowed=['scripts/check-product-boundary.mjs','scripts/boundary-manifests.mjs','tests/product-boundary-lexical-static.test.js']
changed=[p for p in sorted(set(prepared)|set(current)) if prepared.get(p,{}).get('sha256')!=current.get(p,{}).get('sha256') or prepared.get(p,{}).get('target')!=current.get(p,{}).get('target')]
assert changed==sorted(allowed),changed
physicalKeys=['kind','sha256','target','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ino','st_dev','st_nlink']
categories={}
for category in ['deps','dist']:
 a={p:r for p,r in prepared.items() if r['category']==category};z={p:r for p,r in current.items() if r['category']==category}
 delta=[{'path':p,'fields':[k for k in physicalKeys if a.get(p,{}).get(k)!=z.get(p,{}).get(k)]} for p in sorted(set(a)|set(z)) if any(a.get(p,{}).get(k)!=z.get(p,{}).get(k) for k in physicalKeys)]
 access=[{'path':p,'beforeAtimeNs':a[p]['st_atime_ns'],'afterAtimeNs':z[p]['st_atime_ns']} for p in a if p in z and a[p]['st_atime_ns']!=z[p]['st_atime_ns']]
 assert not delta,delta[:3]
 categories[category]={'entries':len(a),'byteAndPhysicalIdentityInvariant':True,'verifiedFields':physicalKeys,'differences':delta,'accessTimeChanges':access,'limitation':'Candidate access timestamps reflect trusted read/check machinery; no byte/mode/mtime/inode/link changes. Source including deps/dist remains fully literal invariant.'}
write('candidate-scope-invariance.json',{'changedFileBytes':changed,'allowedEdits':allowed,'categories':categories})
assert all((c/p).resolve().is_relative_to(c) for p,r in current.items() if r['kind']=='link')
assert all(not snapshot.private(part) for p in current for part in Path(p).parts)
copyMissing=[p for p,r in new.items() if r['kind']=='file' and not snapshot.opaque(Path(p)) and p not in current]
assert not copyMissing,copyMissing[:3]
opaqueMissing=[p for p,r in new.items() if r['kind']=='file' and snapshot.opaque(Path(p)) and p not in current]
write('copy-policy.json',{'privateExcluded':sorted(snapshot.PRIVATE)+['.env*'],'opaqueNarratives':'hash-only; no narrative bytes copied or inspected','opaqueOmittedFiles':len(opaqueMissing),'missingRequiredNonOpaqueFiles':copyMissing,'physicalDependenciesInternalLinks':True,'noDependencyInstallation':True,'preparationRepair':'copy-preparation-repair.json','preparedDependencyBaseline':'candidate-before-prepared.json','initialFailureRawPreserved':'logs/before-native.json'})
# Patch and exact current/before identity binding.
identities=[];patch=''
for p in allowed:
 before=(b/'sealed-before'/p).read_bytes();after=(c/p).read_bytes()
 assert hashbytes(before)==old[p]['sha256']
 identities.append({'path':p,'beforeSha256':hashbytes(before),'currentSha256':hashbytes(after),'beforeBytes':len(before),'currentBytes':len(after)})
 patch+=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+p,tofile='b/'+p))
(b/'build.patch').write_text(patch)
assert json.loads((b/'code-freeze.json').read_text())['files']=={r['path']:r['currentSha256'] for r in identities}
# Actual native case inventory, including original native machinery and static appendix.
readlog=lambda n:json.loads((logs/(n+'.json')).read_text())
first=readlog('before-r18');before=readlog('before-r18-final');after=readlog('final-native');inherited=readlog('before-native-prepared')
assert after['numPassedTests']==1185 and after['numFailedTests']==0 and after['numPendingTests']==0 and after['success']
assert inherited['numPassedTests']==1046 and inherited['numFailedTests']==0
basecases=[t for suite in inherited['testResults'] for t in suite['assertionResults']]
newBefore={t['fullName']:t for suite in before['testResults'] for t in suite['assertionResults'] if t['status'] in ['passed','failed']}
firstCases={t['fullName']:t for suite in first['testResults'] for t in suite['assertionResults'] if t['status'] in ['passed','failed']}
assert len(newBefore)==139 and all(firstCases[n]['status']==t['status'] for n,t in newBefore.items())
caseRows=[];byFinding={}
for suite in after['testResults']:
 for t in suite['assertionResults']:
  group='R18' if t['fullName'] in newBefore else 'R17_STATIC_PREFIX793' if Path(suite['name']).name=='product-boundary-lexical-static.test.js' else 'ORIGINAL253'
  row={'suite':Path(suite['name']).name,'fullName':t['fullName'],'group':group,'afterStatus':t['status'],'durationMs':t['duration']}
  if group=='R18':
   row['beforeStatus']=newBefore[t['fullName']]['status'];f=re.search(r'\bF[1-5]\b',t['title']).group();row['finding']=f
   byFinding.setdefault(f,collections.Counter()).update([row['beforeStatus']])
  caseRows.append(row)
assert len({(r['suite'],r['fullName']) for r in caseRows})==1185
assert collections.Counter(r['group'] for r in caseRows)=={'R18':139,'R17_STATIC_PREFIX793':793,'ORIGINAL253':253}
assert len({t['fullName'] for t in basecases}&set(newBefore))==0
write('case-inventory.json',{'expandedNativeCases':caseRows,'groups':dict(collections.Counter(r['group'] for r in caseRows)),'newControlsDisjoint':True,'R18BeforeByFinding':{f:dict(v) for f,v in byFinding.items()},'beforeFailures':109,'beforePasses':30,'afterNewPasses':139,'focusedBeforePending793':'Intentional name-filtered reproduction only; full final run has zero pending/skipped.'})
inputsBefore=json.loads((logs/'before-r18-final-observations.json-inputs.json').read_text());inputsAfter=json.loads((logs/'final-native-observations.json-inputs.json').read_text())
inputKey=lambda v:{r['id']:sorted(r['entries'],key=lambda e:e['path']) for r in v}
assert len(inputsBefore)==len(inputsAfter)==139 and inputKey(inputsBefore)==inputKey(inputsAfter)
inputRows=[]
for fixture in inputsAfter:
 for entry in fixture['entries']:
  inputRows.append({'fixture':fixture['id'],'path':entry['path'],'kind':'symlink' if 'link' in entry else 'inert-text','sha256':hashbytes(entry.get('text',entry.get('link')).encode()),'bytes':len(entry.get('text',entry.get('link')).encode())})
write('inert-input-inventory.json',{'fixtureCount':139,'entryCount':len(inputRows),'beforeAfterExactIdentity':True,'fixturesExecuted':False,'nativeResolverOnly':True,'inputsBefore':'logs/before-r18-final-observations.json-inputs.json','inputsAfter':'logs/final-native-observations.json-inputs.json','entries':inputRows})
# Installed diagnostics: exact multiset, no exception or trust approval.
installedBefore=json.loads((logs/'before-installed.stdout.log').read_text());installedAfter=json.loads((logs/'final-installed.stdout.log').read_text())
encode=lambda d:json.dumps(d,sort_keys=True,separators=(',',':'));bc=collections.Counter(map(encode,installedBefore['diagnostics']));ac=collections.Counter(map(encode,installedAfter['diagnostics']));missing=list((bc-ac).elements());extras=list((ac-bc).elements());assert not missing and len(extras)==1
assert installedAfter['status']=='INCOMPLETE' and not installedAfter['passed'] and len(installedAfter['diagnostics'])==2958
exclude={'UNVERIFIED_INSTALLED_DEPENDENCY','UNVERIFIED_LOCAL_DEPENDENCY','UNRESOLVED_INSTALLED_LOCAL_DEPENDENCY','UNVERIFIED_WORKSPACE_DEPENDENCY'}
legacy=[d for d in installedBefore['diagnostics'] if d['reason'] not in exclude];legacyPaths=sorted({re.sub(r':\d+$','',d['file']) for d in legacy});assert len(legacy)==1610 and len(legacyPaths)==267
legacyShas=[{'path':p,'beforeSourceSha256':old[p]['sha256'],'currentCandidateSha256':current[p]['sha256'],'match':old[p]['sha256']==current[p]['sha256']} for p in legacyPaths];assert all(r['match'] for r in legacyShas)
localRows=[d for d in installedAfter['diagnostics'] if d['reason']=='UNRESOLVED_INSTALLED_LOCAL_DEPENDENCY'];assert len(localRows)==1
for d in localRows:
 assert current[d['file']]['sha256']==d['manifestSha256']
 assert current[d['installedActor']['manifest']]['sha256']==d['installedActor']['manifestSha256']
 assert not (c/d['target']).exists()
 assert d['manifestSha256']=='fb5acf595b68e1c19a2b61a6741c302c775fa4d360d944ce7d7b8f78ee3eee7e'
write('installed-retention.json',{'beforeCount':2957,'afterCount':2958,'missingCount':0,'extraCount':1,'extras':list(map(json.loads,extras)),'rawExactMultisetRetention':True,'normalizedFileLineRule':'terminal :line separated from physical relative path','R17LegacySubsetCount':1610,'legacyPhysicalFileCount':267,'legacySources':legacyShas,'unresolvedLocalRows':localRows,'beforeReasonCounts':dict(collections.Counter(d['reason'] for d in installedBefore['diagnostics'])),'afterReasonCounts':dict(collections.Counter(d['reason'] for d in installedAfter['diagnostics'])),'historicalLimitation':'Own sealed R17 baseline all2957 is exactly retained, including1610 unknowns and267 matching files. Historic pre-R17 raw outside packet; no inherited critic acceptance.'})
checks={name:int((logs/(name+'.exit')).read_text()) for name in ['before-type','before-lint','before-installed','before-native-prepared','before-r18','before-r18-final','final-native','final-installed','final-type','final-lint','final-format','final-node-version']}
assert all(checks[n]==0 for n in ['before-type','before-lint','before-native-prepared','final-native','final-type','final-lint','final-format','final-node-version'])
assert checks['before-installed']==checks['before-r18']==checks['before-r18-final']==checks['final-installed']==1
assert (logs/'final-node-version.stdout.log').read_text().strip()=='v22.23.2'
for name in ['final-installed','final-type','final-lint','final-format']:
 binding=json.loads((logs/(name+'.code-binding.json')).read_text());assert binding['invariant'] and binding['beforeSha256']=={r['path']:r['currentSha256'] for r in identities}
ast=json.loads((b/'assertion-inventory.json').read_text());assert ast['prefixByteExact'] and ast['appendAssertionAstPreserved'] and ast['nativeResolverBodyUnmodified']
for p in ast['original253']:assert ast['original253'][p]['byteSha256']==old[p]['sha256']==current[p]['sha256']
manifest={'task':'C1 T2 R18 physical actor closure','status':'BUILDER_CODE_FROZEN_READY_FOR_FRESH_CRITIC','evidenceLevel':'I0 builder only; no independent acceptance or integration/release grant','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':str(src),'candidate':str(c),'output':str(b),'node':{'path':'/home/ricardo/.nvm/versions/node/v22.23.2/bin/node','version':'v22.23.2'},'editedFiles':identities,'staticPrefix':{'cases':793,'bytes':114477,'sha256':ast['sealed793']['byteSha256'],'byteExact':True},'tests':{'original253':253,'prefix793':793,'new139':139,'total':1185,'passed':1185,'failed':0,'skipped':0,'beforeNewFail':109,'beforeNewPass':30,'assertionAstUnchanged':True,'nativeResolverBodyUnmodified':True},'installed':{'before':2957,'after':2958,'status':'INCOMPLETE','exit':1,'violations':0,'sourceFiles':installedAfter['sourceFiles'],'coreFiles':installedAfter['coreFiles'],'workspaceCount':installedAfter['workspaceCount'],'edgeCountBefore':installedBefore['edgeCount'],'edgeCountAfter':installedAfter['edgeCount'],'all2957Retained':True,'all1610ImplementationUnknownsRetained':True,'physical267SourcesMatch':True},'checks':checks,'sourceLiteralInvariant':True,'candidateDepsDistBytePhysicalInvariant':True,'copyPolicy':'copy-policy.json','inertInputs':{'fixtureCount':139,'entryCount':len(inputRows),'beforeAfterExactIdentity':True,'executed':False},'artifacts':{'patch':'build.patch','report':'report.md','reportJson':'report.json','caseInventory':'case-inventory.json','assertions':'assertion-inventory.json','installedRetention':'installed-retention.json','artifactInventory':'artifact-inventory.json','seal':'seal.json'},'limitations':['Installed scan deliberately remains blocking INCOMPLETE;2958 diagnostic obligations remain.','R17 critic formally INVALID, technical findings independently reproduced; no inherited acceptance.','No Root/Main/Integrated/product edits or Root narrative reads; Lead owns integration, PG/CI, persistence and fresh review.','Candidate opaque narrative files omitted and hashed only;2 omitted generated History JS files restored byte-exact during preparation; initial825/1046 uncollected221 baseline raw preserved, prepared1046/1046 passed.','Candidate read atimes can change; bytes, modes, mtimes, inodes and links invariant for prepared deps/dist; Source all literal stats and SHAs unchanged.','Own R17 baseline exact retention is proved; separate historic raw outside this packet.']}
write('buildmanifest.json',manifest);write('report.json',manifest)
(b/'report.md').write_text('''# R18 — factual bounded builder report

Code frozen for a fresh independent critic. Builder I0 evidence only; installed status remains **INCOMPLETE / exit 1**. No integration or release acceptance.

## Result and scope

Only `scripts/check-product-boundary.mjs`, `scripts/boundary-manifests.mjs`, and an appendix after the sealed793-case static prefix changed. Source R17, Main, Root, Integrated, product, dependencies and lockfile were not edited. Root claim/task authority came from the user packet; no Root narratives or user environment files were inspected. No network, providers, PG, dependency install or subagents were used.

- F1: every file/link declaration retains its strict local successor and its declaring-key physical installed successor across all four fields. Local declarations cannot create registry tolerance.
- F2: effective source resolution identifies the innermost physical Node package boundary, including scoped/nested JSON-less actors, and connects recursively owned metadata. Root ancestry remains opaque; no invented root-manifest hash.
- F3: metadata-nearest actors remain governed while trusted native require/import resolution adds actual runtime successors, with conditions and no entrypoint execution. Unknown implementation stays blocking.
- F4: lexical local path segments/ancestors, including encoded segments and dot segments, are checked before canonicalization can hide a symlink.
- F5: local closure cycles are provisional until the outer read settles a fixed point; incomplete/failed descendants propagate through cyclic ancestors. Validated shape caching is not approval.

## Independent before/after evidence

The R17 critic was formally INVALID and supplied advisory technical findings only. The builder independently reproduced109 failures and30 compatible controls among139 new inert cases before implementation. A second sealed-Source reproduction with final corpus logging gave the same109/30 outcomes. The assertions' AST hash is unchanged. All139 now pass; before/after1262 input entries across139 fixtures have exact identity. New fixtures were AST/text/JSON data, never executed or imported. The original253 trusted native cases and native resolver body retain exact bytes/identity; the resolver only selects targets.

Final native suite: **1185 PASS =253 original +793 sealed prefix +139 new**, zero skipped/pending. Static file:932 PASS. Prepared before baseline:1046 PASS. Types, full repository lint and edited-file formatting: exit0. Exact Node:v22.23.2; own TMPDIR/cache used. Commands, raw native JSON/stdout/stderr/exit logs, expanded case inventory, corpus and assertion hashes are indexed.

Installed before:2957 INCOMPLETE; after:2958 INCOMPLETE, exit1, zero known violations. **All2957 raw diagnostic rows retained exactly as a multiset**, including1610 implementation unknowns; all267 implicated physical files retain Source SHA. One added row records `node_modules/eslint/package.json`'s declared `eslint` installed successor. The published ESLint missing local reference remains individually manifest/path/field/hash linked and blocking, with packageSHA `fb5acf595b68e1c19a2b61a6741c302c775fa4d360d944ce7d7b8f78ee3eee7e`. No skip, exception, vendor/field filter or trust grant was introduced. No optimistic installed PASS.

## Copy preparation and invariance

Opaque documentary bytes were omitted and hashed only. Initial preparation incorrectly classified two generated jsdom History JS files as documentary; this caused221 original cases not to collect, yielding825 passes and a worker import error. Initial raw logs are preserved. Copying those two files exactly from Source into the new candidate completed preparation; no existing dependency bytes were patched, and prepared1046 passed. `copy-preparation-repair.json` and the prepared dependency inventory bind this correction.

Source inventory, including Source deps/dist, is fully literal invariant across all recorded stat fields and hashes. Prepared candidate dependencies/dist retain bytes, modes, mtimes, inodes and link identity; read atime differences are disclosed rather than erased. Only the three authorized files have changed bytes. All dependency symlinks resolve internally and no private artifacts were copied.

## Artifacts and limits

`buildmanifest.json` binds exact Source-before/current SHAs, checks and frozen code. `build.patch` is the coherent R17-to-current patch. `case-inventory.json`, `inert-input-inventory.json`, `assertion-inventory.json`, `installed-retention.json`, literal/scope inventories and raw logs supply the finite evidence. `artifact-inventory.json` indexes file bytes/SHA and `seal.json` hashes that index, manifest, report and patch; seal self-reference exclusions are explicit.

This report proves the bounded builder's fixes and diagnostic retention.2958 installed obligations remain unresolved. Historic raw before sealed R17 is outside this packet; no inherited acceptance is asserted. Fresh independent review and Lead's separate CI/PG, persistence and integration decisions remain required. The two Integrated R17 product timing failures reported by Lead were outside this lane and were not changed here.
''')
authority=json.loads((b/'authority.json').read_text());authority['status']=manifest['status'];write('authority.json',authority)
# Raw and artifact indexing, excluding only the self-referential sealing files.
excluded={'artifact-inventory.json','seal.json','seal.sha256'}
artifacts=[]
for p in sorted(b.rglob('*')):
 if p.is_file() and p.relative_to(b).as_posix() not in excluded:
  artifacts.append({'path':p.relative_to(b).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p),'kind':'raw-log' if p.is_relative_to(logs) else 'inert-corpus' if 'inputs' in p.name else 'builder-artifact'})
assert len([r for r in artifacts if r['path'].startswith('logs/')])>20
write('artifact-inventory.json',{'finite':True,'excludedSelfReference':sorted(excluded),'artifactCount':len(artifacts),'totalBytes':sum(r['bytes'] for r in artifacts),'artifacts':artifacts})
seal={'status':'SEALED_READY_FOR_FRESH_CRITIC','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'artifactCount':len(artifacts),'inventorySha256':sha(b/'artifact-inventory.json'),'buildmanifestSha256':sha(b/'buildmanifest.json'),'patchSha256':sha(b/'build.patch'),'reportSha256':sha(b/'report.md'),'codeFrozen':json.loads((b/'code-freeze.json').read_text())['files'],'excludedSelfReference':sorted(excluded),'installed':{'count':2958,'status':'INCOMPLETE','exit':1},'claim':'Bounded builder evidence only; no release or independent acceptance'}
write('seal.json',seal);(b/'seal.sha256').write_text(sha(b/'seal.json')+'  seal.json\n')
print(json.dumps({'status':seal['status'],'artifacts':len(artifacts),'installed':seal['installed'],'edited':changed,'manifest':str(b/'buildmanifest.json'),'patch':str(b/'build.patch'),'report':str(b/'report.md'),'seal':str(b/'seal.json')}))
