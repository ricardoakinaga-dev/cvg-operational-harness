# R18 — factual bounded builder report

Code frozen for a fresh independent critic. Builder I0 evidence only; installed status remains **INCOMPLETE / exit 1**. No integration or release acceptance.

## Result and scope

Only `scripts/check-product-boundary.mjs`, `scripts/boundary-manifests.mjs`, and an appendix after the sealed793-case static prefix changed. Source R17, Main, Root, Integrated, product, dependencies and lockfile were not edited. Root claim/task authority came from the user packet; no Root narratives or user environment files were inspected. No network, providers, PG, dependency install or subagents were used.

- F1: every file/link declaration retains its strict local successor and its declaring-key physical installed successor across all four fields. Local declarations cannot create registry tolerance.
- F2: effective source resolution identifies the innermost physical Node package boundary, including scoped/nested JSON-less actors, and connects recursively owned metadata. Root ancestry remains opaque; no invented root-manifest hash.
- F3: metadata-nearest actors remain governed while trusted native require/import resolution adds actual runtime successors, with conditions and no entrypoint execution. Unknown implementation stays blocking.
- F4: lexical local path segments/ancestors, including encoded segments and dot segments, are checked before canonicalization can hide a symlink.
- F5: local closure cycles are provisional until the outer read settles a fixed point; incomplete/failed descendants propagate through cyclic ancestors. Validated shape caching is not approval.

## Independent before/after evidence

The R17 critic was formally INVALID and supplied advisory technical findings only. The builder independently reproduced109 failures and30 compatible controls among139 new inert cases before implementation. A second sealed-Source reproduction with final corpus logging gave the same109/30 outcomes. The assertions' AST hash is unchanged. All139 now pass; before/after1262 input entries across139 fixtures have exact identity. New fixtures were AST/text/JSON data, never executed or imported. The original253 trusted native cases and native resolver body retain exact bytes/identity; the resolver only selects targets.

Final native suite: **1185 PASS =253 original +793 sealed prefix +139 new**, zero skipped/pending. Static file:932 PASS. Prepared before baseline:1046 PASS. Types, full repository lint and edited-file formatting: exit0. Exact Node:v22.23.2; own TMPDIR/cache used. Commands, raw native JSON/stdout/stderr/exit logs, expanded case inventory, corpus and assertion hashes are indexed.

Installed before:2957 INCOMPLETE; after:2958 INCOMPLETE, exit1, zero known violations. **All2957 raw diagnostic rows retained exactly as a multiset**, including1610 implementation unknowns; all267 implicated physical files retain Source SHA. One added row records `node_modules/eslint/package.json`'s declared `eslint` installed successor. The published ESLint missing local reference remains individually manifest/path/field/hash linked and blocking, with packageSHA `fb5acf595b68e1c19a2b61a6741c302c775fa4d360d944ce7d7b8f78ee3eee7e`. No skip, exception, vendor/field filter or trust grant was introduced. No optimistic installed PASS.

## Copy preparation and invariance

Opaque documentary bytes were omitted and hashed only. Initial preparation incorrectly classified two generated jsdom History JS files as documentary; this caused221 original cases not to collect, yielding825 passes and a worker import error. Initial raw logs are preserved. Copying those two files exactly from Source into the new candidate completed preparation; no existing dependency bytes were patched, and prepared1046 passed. `copy-preparation-repair.json` and the prepared dependency inventory bind this correction.

Source inventory, including Source deps/dist, is fully literal invariant across all recorded stat fields and hashes. Prepared candidate dependencies/dist retain bytes, modes, mtimes, inodes and link identity; read atime differences are disclosed rather than erased. Only the three authorized files have changed bytes. All dependency symlinks resolve internally and no private artifacts were copied.

## Artifacts and limits

`buildmanifest.json` binds exact Source-before/current SHAs, checks and frozen code. `build.patch` is the coherent R17-to-current patch. `case-inventory.json`, `inert-input-inventory.json`, `assertion-inventory.json`, `installed-retention.json`, literal/scope inventories and raw logs supply the finite evidence. `artifact-inventory.json` indexes file bytes/SHA and `seal.json` hashes that index, manifest, report and patch; seal self-reference exclusions are explicit.

This report proves the bounded builder's fixes and diagnostic retention.2958 installed obligations remain unresolved. Historic raw before sealed R17 is outside this packet; no inherited acceptance is asserted. Fresh independent review and Lead's separate CI/PG, persistence and integration decisions remain required. The two Integrated R17 product timing failures reported by Lead were outside this lane and were not changed here.
