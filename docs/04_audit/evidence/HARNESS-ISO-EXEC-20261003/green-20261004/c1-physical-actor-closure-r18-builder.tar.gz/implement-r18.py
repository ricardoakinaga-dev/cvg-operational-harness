from pathlib import Path
c=Path('/home/ricardo/.cache/cvg-harness-green-20261004/c1-physical-actor-closure-r18-candidate')
p=c/'scripts/boundary-manifests.mjs';s=p.read_text()
s=s.replace('  const closureStates = new Map()', '''  const closureStates = new Map()
  const closureEdges = new Map()
  const directIncomplete = new Set()
  let readingDepth = 0
  const censusManifests = new Map()''')
a=s.index('  function read(filename, options = {}) {');b=s.index('  function installedActor(',a)
s=s[:a]+'''  function settleClosures() {
    // Only settle after the outer read: a visiting cycle is provisional, never
    // evidence of a complete reachable frontier. Propagate failure/incomplete
    // through the entire local closure, including strongly connected actors.
    let changed = true
    while (changed) {
      changed = false
      for (const [filename, state] of closureStates) {
        if (state.status === 'failed') continue
        const children = [...(closureEdges.get(filename) ?? [])]
          .map((child) => closureStates.get(child))
        const failed = children.find((child) => child?.status === 'failed')
        const status = failed ? 'failed' :
          directIncomplete.has(filename) ||
          children.some((child) => child?.status === 'incomplete')
            ? 'incomplete' : 'complete'
        if (state.status !== status) {
          closureStates.set(filename, failed
            ? {status, error: failed.error} : {status})
          if (failed) cache.delete(filename)
          changed = true
        }
      }
    }
  }
  function read(filename, options = {}) {
    filename = path.resolve(filename)
    const state = closureStates.get(filename)
    if (state?.status === 'failed') throw state.error
    readingDepth++
    try {
      const value = readShape(filename, options)
      if (state) return value
      closureStates.set(filename, { status: 'visiting' })
      const children = new Set()
      closureEdges.set(filename, children)
      for (const field of manifestDependencyFields)
        for (const [name, version] of Object.entries(value[field] ?? {}))
          if (/^(file|link):/.test(version.trim())) {
            const ref = localEdge(filename, field, name, version)
            if (ref.unresolved) {
              directIncomplete.add(filename)
              continue
            }
            children.add(ref.manifest)
            read(ref.manifest, { requireName: true })
            for (const child of census(path.dirname(ref.manifest)))
              children.add(child)
          }
      closureStates.set(filename, { status: 'provisional' })
      return value
    } catch (error) {
      cache.delete(filename)
      closureStates.set(filename, { status: 'failed', error })
      throw error
    } finally {
      if (--readingDepth === 0) settleClosures()
    }
  }
''' + s[b:]
a=s.index('  function localDirectory(')
s=s[:a]+'''  function lexicalLocalPath(filename, suffix) {
    // Inspect the requested spelling before URL dot normalization or realpath
    // can hide a symlink. Encoded path segments retain this same obligation.
    let spelling = suffix.replace(/\\\\/g, '/')
    if (spelling.startsWith('//')) spelling = spelling.replace(/^\\/\\/[^/]*/, '')
    let parts
    try {
      parts = spelling.split('/').map((part) => {
        const decoded = decodeURIComponent(part)
        if (decoded.includes('/') || decoded.includes('\\0'))
          reject(filename, 'local_dependency')
        return decoded
      })
    } catch { reject(filename, 'local_dependency') }
    let cursor
    if (spelling.startsWith('/')) {
      const rootParts = root.split(path.sep)
      if (rootParts.some((part, index) => parts[index] !== part))
        reject(filename, 'local_dependency')
      parts = parts.slice(rootParts.length)
      cursor = root
    } else cursor = path.dirname(filename)
    for (const part of parts) {
      if (!part || part === '.') continue
      cursor = part === '..' ? path.dirname(cursor) : path.join(cursor, part)
      if (!inside(root, cursor)) reject(filename, 'local_dependency')
      try {
        const stat = fs.lstatSync(cursor)
        if (stat.isSymbolicLink() || !stat.isDirectory())
          reject(filename, 'local_dependency')
      } catch (error) {
        if (error.code !== 'ENOENT') throw error
        return cursor
      }
    }
  }
''' + s[a:]
s=s.replace("    if (!inside(root, target)) reject(filename, 'local_dependency')\n    return target", "    if (!inside(root, target)) reject(filename, 'local_dependency')\n    const missing = lexicalLocalPath(filename, suffix)\n    if (missing && fs.existsSync(target)) reject(filename, 'local_dependency')\n    return target")
s=s.replace("    const resolved = fs.realpathSync(target)", "    const requestedManifest = path.join(target, 'package.json')\n    const stat = fs.lstatSync(requestedManifest)\n    if (stat.isSymbolicLink() || !stat.isFile())\n      reject(requestedManifest, 'physical_file_required')\n    const resolved = fs.realpathSync(target)",1)
a=s.index('      // Only a real registry declaration');b=s.index('      return {\n        context,',a)
registration=s[a:b]
# Extract exact registry provenance registration; runtime binding reuses it only
# for an actual declared-key directory containing the trusted native target.
s=s[:a]+'''      registerInstalled(filename, name, {field, version}, context)
''' + s[b:]
a=s.index('  function installedPackage(')
regBody=registration.replace('      // Only','    // Only')
# Use existing registration logic, independent of nearest-directory lookup.
regBody=regBody.replace("      const manifest", "    const manifest")
s=s[:a]+'''  function registerInstalled(filename, name, {field, version}, context) {
    const manifest = path.join(context, 'package.json')
''' + regBody + '''  }
  function physicalPackage(target) {
    if (!inside(root, target)) reject(target, 'outside_repository')
    const parts = path.relative(root, target).split(path.sep)
    for (let index = parts.length - 2; index >= 0; index--) {
      if (parts[index] !== 'node_modules') continue
      const scoped = parts[index + 1]?.startsWith('@')
      const end = index + (scoped ? 3 : 2)
      const name = parts.slice(index + 1, end).join('/')
      if (end >= parts.length || !packageName(name))
        reject(target, 'physical_installed_directory_required')
      const context = path.join(root, ...parts.slice(0, end))
      if (fs.realpathSync(context) !== context || !fs.lstatSync(context).isDirectory())
        reject(context, 'physical_installed_directory_required')
      return context
    }
  }
  function runtimePackage(filename, name, options, target) {
    const context = physicalPackage(target)
    if (!context) return undefined
    for (const parent of createRequire(filename).resolve.paths(name) ?? []) {
      if (!inside(root, parent)) continue
      const candidate = path.join(parent, name)
      try { fs.lstatSync(candidate) } catch (error) {
        if (error.code === 'ENOENT') continue
        throw error
      }
      const selected = fs.realpathSync(candidate)
      if (!inside(root, selected) || !fs.statSync(selected).isDirectory())
        reject(candidate, 'physical_installed_directory_required')
      if (selected === context && inside(selected, target)) {
        registerInstalled(filename, name, options, context)
        break
      }
    }
    return context
  }
''' + s[a:]
# A cached census must still supply all owned manifest paths to its callers.
s=s.replace("    if (censused.has(directory)) return result\n    censused.add(directory)", "    if (censused.has(directory)) {\n      for (const file of censusManifests.get(directory) ?? []) result.add(file)\n      return result\n    }\n    censused.add(directory)\n    const owned = new Set()\n    censusManifests.set(directory, owned)")
s=s.replace('if (entry.isDirectory()) census(file, result)', 'if (entry.isDirectory()) census(file, owned)')
s=s.replace('          result.add(file)', '          owned.add(file)')
s=s.replace('      return result\n    } catch (error) {\n      censused.delete(directory)', '      for (const file of owned) result.add(file)\n      return result\n    } catch (error) {\n      censusManifests.delete(directory)\n      censused.delete(directory)')
s=s.replace('    installedPackage,\n    cache,', '    installedPackage,\n    physicalPackage,\n    runtimePackage,\n    cache,')
p.write_text(s)
p=c/'scripts/check-product-boundary.mjs';s=p.read_text()
s=s.replace("            reportDiagnostic(pkgFile, ref.unresolved)\n            continue\n          }\n          const targetPkg", "            reportDiagnostic(pkgFile, ref.unresolved)\n          } else {\n          const targetPkg")
s=s.replace("          governActor(context)\n        } else {", "          governActor(context)\n          }\n        } else {")
a=s.index('          // A declared workspace edge supplements');b=s.index('  const governActor',a)
common=s[a:b]
# Move physical successor logic outside the local/workspace branch; every family.
common=common.replace('        }\n      }\n  }\n','')
s=s[:a]+'''        }
''' + common + '''          for (const mode of ['require', 'import'])
            runtimeReferences.push({file:pkgFile, location:path.relative(root,pkgFile),
              specifier:name, mode, manifestEdge:{field,version, nearest:installed.context}})
      }
  }
''' + s[b:]
# Bind native/effective Node physical boundary before nearest manifest ancestry.
needle='    let context = path.dirname(target)'
s=s.replace(needle,'''    const installedContext = metadata.physicalPackage(target)
    if (installedContext) {
      const manifest = path.join(installedContext, 'package.json')
      edge(file, fs.existsSync(manifest) ? manifest : installedContext)
      governActor(installedContext)
    }
    let context = path.dirname(target)''',1)
s=s.replace("      if (context === root) break\n      context = path.dirname(context)", "      if (context === (installedContext ?? root)) break\n      context = path.dirname(context)",1)
# Metadata native targets do not enqueue arbitrary installed implementations:
# census their metadata and keep their independent unknown implementation row.
needle="      if (typeof target === 'string')\n        localTarget(ref.file, ref.location, ref.specifier, target)"
replace="""      if (ref.manifestEdge) {
        const complete = Array.isArray(targets) && targets.length === pending.length &&
          targets.every((value) => value === null || typeof value === 'string')
        if (!complete) reportDiagnostic(ref.file, {file:ref.location, specifier:ref.specifier,
          dependencyField:ref.manifestEdge.field, mode:ref.mode,
          reason:'UNVERIFIED_INSTALLED_RUNTIME_RESOLUTION'})
        else if (typeof target === 'string') {
          const physical = fs.realpathSync(target)
          if (!inside(root,physical)) reportDiagnostic(ref.file,{file:ref.location,
            specifier:ref.specifier, mode:ref.mode, reason:'MODULE_OUTSIDE_REPOSITORY'})
          else {
            edge(ref.file,physical)
            let context = metadata.runtimePackage(ref.file,ref.specifier,
              ref.manifestEdge,physical)
            if (!context) {
              context = path.dirname(physical)
              while (context !== root && !fs.existsSync(path.join(context,'package.json')))
                context = path.dirname(context)
            }
            const manifest = path.join(context,'package.json')
            edge(ref.file,fs.existsSync(manifest) ? manifest : context)
            const workspace = [...workspaces.values()].find(item => item.workspace === context)
            if (context !== ref.manifestEdge.nearest && !workspace)
              reportDiagnostic(ref.file,{file:ref.location,specifier:ref.specifier,
                mode:ref.mode,reason:'UNVERIFIED_INSTALLED_DEPENDENCY'})
            governActor(context)
          }
        }
        continue
      }
      if (typeof target === 'string')
        localTarget(ref.file, ref.location, ref.specifier, target)"""
assert needle in s;s=s.replace(needle,replace)
p.write_text(s)
