from pathlib import Path
import os,stat,hashlib,json,time,re
B=Path('/home/ricardo/.cache/cvg-harness-green-20261004/c1-physical-actor-closure-r18-builder');S=B.with_name('c1-installed-unresolved-r17-candidate');C=B.with_name('c1-physical-actor-closure-r18-candidate')
PRIVATE={'.git','.gauntlet','.agent','coverage','certification','.cache','.vite','test-results','playwright-report'}
def private(n):return n in PRIVATE or n.startswith('.env')
def opaque(rel):return rel.parts[0]=='docs' or rel.suffix.lower() in {'.md','.rst'} or (rel.suffix.lower() not in {'.js','.mjs','.cjs','.ts','.mts','.cts','.tsx','.jsx','.json','.map','.node','.wasm'} and bool(re.match(r'^(readme|license|licence|notice|copying|changelog|history|authors|contributors)([._-]|$)',rel.name,re.I)))
def metadata(st):return {k:getattr(st,k) for k in ['st_mode','st_uid','st_gid','st_size','st_atime_ns','st_mtime_ns','st_ctime_ns','st_ino','st_dev','st_nlink']}
def walk(root,copy=None):
 rows=[]
 def visit(rel):
  p=root/rel;st=p.lstat(); row={'path':rel.as_posix(),**metadata(st),'category':'deps' if 'node_modules' in rel.parts else 'dist' if 'dist' in rel.parts else 'source'}
  if stat.S_ISDIR(st.st_mode):
   row['kind']='directory'; rows.append(row)
   if copy is not None:(copy/rel).mkdir(exist_ok=True)
   fd=os.open(p,os.O_RDONLY|os.O_DIRECTORY|os.O_NOATIME)
   try:
    names=sorted(os.listdir(fd))
    for n in names:
     if private(n):continue
     visit(rel/n)
   finally:os.close(fd)
  elif stat.S_ISLNK(st.st_mode):
   # Relatime prevents readlink from changing a recently frozen symlink atime.
   assert st.st_atime_ns>=max(st.st_mtime_ns,st.st_ctime_ns) and time.time_ns()-st.st_atime_ns<86400*10**9,('symlink_atime_not_frozen',p)
   target=os.readlink(p);row.update(kind='link',target=target);rows.append(row)
   if copy is not None:
    dest=copy/rel
    if os.path.isabs(target):target=os.path.relpath(copy/Path(target).relative_to(root),dest.parent)
    dest.symlink_to(target)
    assert dest.resolve().is_relative_to(copy),(dest,dest.resolve())
  elif stat.S_ISREG(st.st_mode):
   fd=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
   h=hashlib.sha256(); out=None
   if copy is not None and not opaque(rel):out=(copy/rel).open('wb')
   try:
    while True:
     buf=os.read(fd,1024*1024)
     if not buf:break
     h.update(buf)
     if out:out.write(buf)
   finally:
    os.close(fd)
    if out:out.close();os.chmod(copy/rel,stat.S_IMODE(st.st_mode));os.utime(copy/rel,ns=(st.st_atime_ns,st.st_mtime_ns))
   row.update(kind='file',sha256=h.hexdigest(),copyPolicy='hash_only_opaque' if opaque(rel) else 'physical_copy');rows.append(row)
  else:raise RuntimeError(('unsupported_entry',p))
 visit(Path('.'));return rows
if __name__=='__main__':
 if not C.exists():
  C.mkdir()
  for n in ['logs','tmp','cache']:(B/n).mkdir()
  rows=walk(S,C)
  (B/'source-before.json').write_text(json.dumps(rows,indent=2)+'\n')
  (B/'candidate-before.json').write_text(json.dumps(walk(C),indent=2)+'\n')
  (B/'authority.json').write_text(json.dumps({'source':str(S),'candidate':str(C),'output':str(B),'task':'Authorized T2 R18; Root claim and short spec supplied as registered by Lead, no Root reads','node':'/home/ricardo/.nvm/versions/node/v22.23.2/bin/node','readScope':'Source code and exact authorized R17 critic report/probes; other narratives hash-only, no byte copies','writeScope':['scripts/check-product-boundary.mjs','scripts/boundary-manifests.mjs','resolver if necessary','append after 793-case static prefix'], 'privateExcluded':sorted(PRIVATE)+['.env*'],'opaqueCopyExcluded':'docs/**, Markdown/RST, README/LICENSE/NOTICE/COPYING/history variants','reviewAuthority':'Formal INVALID report is advisory only; locally reproduce F1-F5 before changes','qualityBar':['retain local plus installed successors','source-resolved JSON-less physical actor census','metadata nearest plus native import/require runtime successors','strict lexical symlink recusal','SCC incomplete fixed point','original253 and sealed793 prefix byteexact','installed unknowns blocking; no release acceptance'],'status':'BUILD_IN_PROGRESS'},indent=2)+'\n')
  print({'entries':len(rows),'opaqueHashOnlyFiles':sum(r.get('copyPolicy')=='hash_only_opaque' for r in rows),'copy':str(C)})
