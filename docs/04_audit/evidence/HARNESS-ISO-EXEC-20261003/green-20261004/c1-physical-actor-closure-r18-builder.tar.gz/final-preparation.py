from pathlib import Path
import os,subprocess,json,hashlib
b=Path(__file__).parent;c=b.parent/'c1-physical-actor-closure-r18-candidate';src=b.parent/'c1-installed-unresolved-r17-candidate'
paths=['scripts/check-product-boundary.mjs','scripts/boundary-manifests.mjs','tests/product-boundary-lexical-static.test.js']
env={'PATH':'/home/ricardo/.nvm/versions/node/v22.23.2/bin:/usr/bin:/bin','HOME':'/home/ricardo','TMPDIR':str(b/'tmp'),'XDG_CACHE_HOME':str(b/'cache')}
p=c/paths[-1];s=p.read_bytes();n=114477
assert hashlib.sha256(s[:n]).hexdigest()=='89ea51f0c6c21c3a93245342933076aa7371bff63d93f16dce05f29916edc379'
r=subprocess.run(['/home/ricardo/.nvm/versions/node/v22.23.2/bin/node','node_modules/prettier/bin/prettier.cjs','--stdin-filepath',paths[-1]],input=s[n:],cwd=c,env=env,capture_output=True)
assert r.returncode==0,r.stderr
p.write_bytes(s[:n]+r.stdout);(b/'append-r18-formatted.txt').write_bytes(r.stdout)
current={f:(c/f).read_bytes() for f in paths}
original={}
for f in paths:
 fd=os.open(src/f,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb') as stream:original[f]=stream.read()
(b/'sealed-before').mkdir(exist_ok=True)
for f,v in original.items():
 q=b/'sealed-before'/f;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(v)
try:
 for f,v in original.items():(c/f).write_bytes(v)
 for name,args in [('before-type',['node_modules/typescript/bin/tsc','-p','tsconfig.typecheck.json','--noEmit']),('before-lint',['node_modules/eslint/bin/eslint.js',*paths])]:
  subprocess.run(['/usr/bin/python3',str(b/'run-check.py'),name,*args],check=True)
finally:
 for f,v in current.items():(c/f).write_bytes(v)
print('Current restored and Source793 prefix exact:',len(original[paths[-1]]))
