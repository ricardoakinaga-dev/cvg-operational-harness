import sys,os,pathlib,subprocess,json,time,hashlib
b=pathlib.Path(__file__).parent
c=b.parent/'c1-physical-actor-closure-r18-candidate'
name=sys.argv[1];args=sys.argv[2:]
env={'PATH':'/home/ricardo/.nvm/versions/node/v22.23.2/bin:/usr/bin:/bin','HOME':'/home/ricardo','TMPDIR':str(b/'tmp'),'XDG_CACHE_HOME':str(b/'cache'),'CVG_R18_RESULTS':str(b/'logs'/f'{name}-observations.json')}
cmd=['/home/ricardo/.nvm/versions/node/v22.23.2/bin/node',*args]
codepaths=['scripts/check-product-boundary.mjs','scripts/boundary-manifests.mjs','tests/product-boundary-lexical-static.test.js']
codehashes=lambda:{f:hashlib.sha256((c/f).read_bytes()).hexdigest() for f in codepaths}
before=codehashes()
(b/'logs'/f'{name}.command.json').write_text(json.dumps({'cwd':str(c),'argv':cmd,'environment':env,'codeBeforeSha256':before},indent=2)+'\n')
with (b/'logs'/f'{name}.stdout.log').open('wb') as out,(b/'logs'/f'{name}.stderr.log').open('wb') as err:
 start=time.monotonic();p=subprocess.run(cmd,cwd=c,env=env,stdout=out,stderr=err)
(b/'logs'/f'{name}.exit').write_text(str(p.returncode)+'\n')
(b/'logs'/f'{name}.code-binding.json').write_text(json.dumps({'beforeSha256':before,'afterSha256':codehashes(),'invariant':before==codehashes()},indent=2)+'\n')
print(json.dumps({'name':name,'exit':p.returncode,'seconds':time.monotonic()-start}))
