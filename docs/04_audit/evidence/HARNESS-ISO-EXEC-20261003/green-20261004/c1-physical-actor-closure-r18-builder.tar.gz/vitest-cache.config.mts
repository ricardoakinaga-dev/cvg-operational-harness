import base from '../c1-physical-actor-closure-r18-candidate/vitest.config.mts'
export default {...base, cacheDir:'/home/ricardo/.cache/cvg-harness-green-20261004/c1-physical-actor-closure-r18-builder/cache/vite'}
