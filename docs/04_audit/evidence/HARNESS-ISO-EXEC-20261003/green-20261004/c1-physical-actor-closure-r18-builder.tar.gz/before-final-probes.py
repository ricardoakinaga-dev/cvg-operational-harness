from pathlib import Path
import subprocess
b=Path(__file__).parent;c=b.parent/'c1-physical-actor-closure-r18-candidate';paths=['scripts/check-product-boundary.mjs','scripts/boundary-manifests.mjs'];current={f:(c/f).read_bytes() for f in paths}
try:
 for f in paths:(c/f).write_bytes((b/'sealed-before'/f).read_bytes())
 subprocess.run(['/usr/bin/python3',str(b/'run-check.py'),'before-r18-final','node_modules/vitest/vitest.mjs','run','tests/product-boundary-lexical-static.test.js','--config',str(b/'vitest-cache.config.mts'),'-t','R18 independent','--reporter=json','--outputFile='+str(b/'logs/before-r18-final.json')],check=True)
finally:
 for f,v in current.items():(c/f).write_bytes(v)
print('Restored current implementation after sealed Source baseline reproduction')
