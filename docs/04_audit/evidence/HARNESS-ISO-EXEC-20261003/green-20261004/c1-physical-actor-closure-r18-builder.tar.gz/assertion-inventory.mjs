import fs from 'node:fs'
import path from 'node:path'
import {createRequire} from 'node:module'
import {createHash} from 'node:crypto'
const b=path.dirname(new URL(import.meta.url).pathname)
const c=path.join(path.dirname(b),'c1-physical-actor-closure-r18-candidate')
const ts=createRequire(path.join(c,'package.json'))('typescript')
const hash=(x)=>createHash('sha256').update(x).digest('hex')
function canonical(n){const children=[];ts.forEachChild(n,x=>{children.push(canonical(x))});return [n.kind, n.text??n.escapedText??null,children]}
function inventory(text,filename){
 const source=ts.createSourceFile(filename,text,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS)
 const assertions=[],calls=[],sensitive=[]
 function visit(n){
  if(ts.isCallExpression(n)){
   if(ts.isIdentifier(n.expression)&&n.expression.text==='expect') assertions.push(canonical(n))
   if(ts.isPropertyAccessExpression(n.expression)&&['skip','todo','only'].includes(n.expression.name.text))calls.push(n.expression.getText(source))
   if(ts.isIdentifier(n.expression)&&['eval','Function','spawn','spawnSync','exec','execFile','execFileSync','Worker'].includes(n.expression.text))sensitive.push(n.expression.getText(source))
  }
  ts.forEachChild(n,visit)
 }
 visit(source)
 return {parseErrors:source.parseDiagnostics.length,expectCallCount:assertions.length,expectAstSha256:hash(JSON.stringify(assertions)),skipTodoOnlyCalls:calls,sensitiveExecutableCalls:sensitive,byteSha256:hash(text)}
}
const test='tests/product-boundary-lexical-static.test.js'
const before=fs.readFileSync(path.join(b,'sealed-before',test),'utf8')
const after=fs.readFileSync(path.join(c,test),'utf8')
const firstAppend=fs.readFileSync(path.join(b,'append-r18.txt'),'utf8')
const currentAppend=after.slice(before.length)
const rows={sealed793:inventory(before,test),current793Prefix:inventory(after.slice(0,before.length),test),beforeR18Append:inventory(firstAppend,test),currentR18Append:inventory(currentAppend,test),prefixBytes:Buffer.byteLength(before),prefixByteExact:after.startsWith(before)}
rows.appendAssertionAstPreserved=rows.beforeR18Append.expectAstSha256===rows.currentR18Append.expectAstSha256
rows.original253={}
for(const f of ['tests/product-boundary.test.js','tests/product-boundary-code-execution.test.js'])rows.original253[f]=inventory(fs.readFileSync(path.join(c,f),'utf8'),f)
const originalResolver=ts.createSourceFile('before.mjs',fs.readFileSync(path.join(b,'sealed-before/scripts/check-product-boundary.mjs'),'utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.JS)
const currentResolver=ts.createSourceFile('after.mjs',fs.readFileSync(path.join(c,'scripts/check-product-boundary.mjs'),'utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.JS)
function nativeBody(sf){let text;function visit(n){if(ts.isNoSubstitutionTemplateLiteral(n)&&n.text.includes('refs.map(({file,specifier,mode})'))text=n.text;ts.forEachChild(n,visit)}visit(sf);if(!text)throw Error('native resolver missing');return hash(text)}
rows.nativeResolverBeforeSha256=nativeBody(originalResolver);rows.nativeResolverCurrentSha256=nativeBody(currentResolver);rows.nativeResolverBodyUnmodified=rows.nativeResolverBeforeSha256===rows.nativeResolverCurrentSha256
fs.writeFileSync(path.join(b,'assertion-inventory.json'),JSON.stringify(rows,null,2)+'\n')
console.log(JSON.stringify(rows))
