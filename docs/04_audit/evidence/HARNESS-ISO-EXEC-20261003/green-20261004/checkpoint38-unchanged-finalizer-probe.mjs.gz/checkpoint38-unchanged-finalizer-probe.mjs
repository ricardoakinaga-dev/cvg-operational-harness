import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { gunzipSync } from 'node:zlib'


const root = '/home/ricardo/.cache/cvg-harness-green-20261004/hiso-neutral-ci10-r4'
const evidence = path.join(root, 'docs/04_audit/evidence/PR009-20260927-r2')
const proof = JSON.parse(fs.readFileSync(path.join(evidence, 'proof.json')))
const gate = JSON.parse(
  fs.readFileSync(path.join(evidence, 'e2e-gate-entry.json'))
)

function finalizeWith(
  hashes,
  {
    corruptXml = false,
    corruptLog = false,
    replaceExecutionId,
    extraGates = []
  } = {}
) {
  const directory = fs.mkdtempSync(
    path.join(os.tmpdir(), 'cvg-ci-e2e-finalizer-')
  )
  try {
    fs.mkdirSync(path.join(directory, 'gates'), { recursive: true })
    const log = gunzipSync(fs.readFileSync(path.join(evidence, 'e2e.log.gz')))
    fs.writeFileSync(
      path.join(directory, 'gates/e2e.log'),
      corruptLog ? Buffer.concat([log, Buffer.from('\n')]) : log
    )
    const artifactSha256 = { ...hashes }
    for (const [name, relativePath] of [
      ['e2e-test-report.json', 'certification/e2e-test-report.json'],
      ['playwright-results.xml', 'playwright-results.xml']
    ]) {
      const target = path.join(directory, 'gate-outputs/e2e', relativePath)
      fs.mkdirSync(path.dirname(target), { recursive: true })
      let bytes = fs.readFileSync(path.join(evidence, name))
      if (replaceExecutionId) {
        bytes = Buffer.from(
          bytes
            .toString('utf8')
            .replaceAll(proof.executionId, replaceExecutionId)
        )
        artifactSha256[relativePath] = createHash('sha256')
          .update(bytes)
          .digest('hex')
      }
      fs.writeFileSync(
        target,
        corruptXml && name === 'playwright-results.xml'
          ? Buffer.concat([bytes, Buffer.from('\n')])
          : bytes
      )
    }
    fs.writeFileSync(
      path.join(directory, 'ci-bar-state.json'),
      JSON.stringify({
        runId: proof.runId,
        candidateId: proof.candidateId,
        nodeVersion: '22.23.2',
        npmVersion: '10',
        startedAt: new Date().toISOString(),
        candidateFiles: [],
        gates: [
          {
            ...gate,
            executionId: replaceExecutionId ?? gate.executionId,
            artifactSha256
          },
          ...extraGates
        ]
      })
    )
    const observed = spawnSync(
      process.execPath,
      ['scripts/ci-bar.mjs', 'finalize'],
      {
        cwd: root,
        env: { ...process.env, CI_ARTIFACT_DIR: directory },
        encoding: 'utf8'
      }
    )
    console.log(JSON.stringify({status:observed.status,stdout:observed.stdout,stderr:observed.stderr,signal:observed.signal,error:observed.error?.message},null,2));return null
  } finally {
    fs.rmSync(directory, { recursive: true, force: true })
  }
}


finalizeWith(gate.artifactSha256)
