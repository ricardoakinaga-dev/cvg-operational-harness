// @vitest-environment node
// Every fixture is inert source text. Only the parser and analyzer consume it.
// Never import a fixture or execute its evaluator/process/worker/vm expressions.
import fs from 'node:fs'
import path from 'node:path'
import { tmpdir } from 'node:os'
import ts from 'typescript'
import { afterAll, describe, expect, it } from 'vitest'
import { auditProductBoundary } from '../scripts/check-product-boundary.mjs'
import { createBoundaryLexical } from '../scripts/boundary-lexical.mjs'
const output = fs.mkdtempSync(path.join(tmpdir(), 'cvg-c1-lexical-static-'))
afterAll(() => fs.rmSync(output, { recursive: true, force: true }))
const observations = []
function inspect(id, text, extension = 'mts') {
  const root = path.join(output, 'inert-fixtures', id)
  const write = (relative, content) => {
    const file = path.join(root, relative)
    fs.mkdirSync(path.dirname(file), { recursive: true })
    fs.writeFileSync(file, content)
  }
  for (const dir of ['packages/core/src', 'apps', 'legacy', 'products'])
    fs.mkdirSync(path.join(root, dir), { recursive: true })
  write(
    'package.json',
    JSON.stringify({
      private: true,
      type: 'module',
      workspaces: ['packages/*']
    })
  )
  write(
    'packages/core/package.json',
    JSON.stringify({ name: '@synthetic/core', type: 'module' })
  )
  write(
    'tsconfig.base.json',
    JSON.stringify({
      compilerOptions: {
        module: 'NodeNext',
        moduleResolution: 'NodeNext',
        target: 'ESNext',
        allowJs: true
      }
    })
  )
  write(
    'packages/core/src/neutral.ts',
    'export interface Data {label:string};export const label="synthetic";'
  )
  const file = `packages/core/src/entry.${extension}`
  write(file, text)
  const source = ts.createSourceFile(
    path.join(root, file),
    text,
    ts.ScriptTarget.Latest,
    true
  )
  expect(source.parseDiagnostics, id).toEqual([])
  const audit = auditProductBoundary(root)
  observations.push({
    id,
    text,
    parseErrors: source.parseDiagnostics.length,
    fixturesExecuted: false,
    ...audit
  })
  fs.writeFileSync(
    path.join(output, 'new-static-results.json'),
    JSON.stringify(observations, null, 2) + '\n'
  )
  return audit
}

// R20: properties are classified through their whole access expression. Their
// spelling must not ask the checker to infer the receiver's semantic type.
describe('R20 binding queries stop at the lexical boundary', () => {
  it('binds the actual installed TypeScript receiver without querying type.flags', () => {
    const filename = ts.sys.getExecutingFilePath()
    const text = fs.readFileSync(filename, 'utf8')
    const fragment = 'const moduleType = type.flags & 403701760'
    const start = text.indexOf(fragment)
    expect(start).toBeGreaterThanOrEqual(0)
    const position = start + fragment.indexOf('flags')
    const source = ts.createSourceFile(
      filename,
      text,
      ts.ScriptTarget.Latest,
      true
    )
    expect(source.parseDiagnostics).toEqual([])
    let property
    const visit = (node) => {
      if (ts.isIdentifier(node) && node.getStart(source) === position)
        property = node
      ts.forEachChild(node, visit)
    }
    visit(source)
    expect(property?.text).toBe('flags')
    expect(property?.parent.getText(source)).toBe('type.flags')
    const lexical = createBoundaryLexical(ts, source, true)
    expect(lexical.identity(property)).toBeUndefined()
    const declarations = lexical.identity(
      property.parent.expression
    ).declarations
    expect(declarations.map((node) => node.kind)).toEqual([
      ts.SyntaxKind.VariableDeclaration
    ])
    expect(declarations[0].name.getText(source)).toBe('type')
  })
  it.each([
    'require',
    'process',
    'import',
    'eval',
    'Function',
    'createRequire'
  ])('keeps %s property names distinct from lexical references', (name) => {
    const source = ts.createSourceFile(
      '/inert/property-identity.mts',
      `const ${name === 'import' ? 'local' : name} = "label"; const value = subject.${name};`,
      ts.ScriptTarget.Latest,
      true
    )
    const lexical = createBoundaryLexical(ts, source)
    let property
    const visit = (node) => {
      if (ts.isPropertyAccessExpression(node)) property = node.name
      ts.forEachChild(node, visit)
    }
    visit(source)
    expect(lexical.identity(property)).toBeUndefined()
    expect(lexical.identity(property.parent.expression)).toBe(
      lexical.global('subject')
    )
  })
  it.each([
    'const data={require:"label",process:"label",import:"label"};export const value=data.require+data.process+data.import',
    'function domain(require=()=>"label"){const data={require};return data.require("synthetic")};export const value=domain',
    'const data={Function:"label",eval:"label"};export const value=data.Function+data.eval'
  ])('retains inert semantic properties: %s', (text) => {
    const audit = inspect('r20-property-neutral-' + observations.length, text)
    expect(audit.status).toBe('PASS')
    expect(audit.diagnostics).toEqual([])
    expect(audit.violations).toEqual([])
  })
  it.each([
    [
      'const load=require;load("../../../products/shift/marker.js")',
      'CORE_DEPENDS_ON_PRODUCT'
    ],
    [
      'const data={require};export const value=data',
      'UNVERIFIED_MODULE_LOADER_ESCAPE'
    ],
    [
      'export {createRequire as load} from "node:module"',
      'UNVERIFIED_MODULE_LOADER_EXPORT'
    ],
    [
      'import {createRequire as make} from "node:module";const load=make(import.meta.url);load("../../../products/shift/marker.js")',
      'CORE_DEPENDS_ON_PRODUCT'
    ],
    [
      'function domain(value=process){const process={};return value};export const value=domain',
      'UNVERIFIED_MODULE_LOADER_ESCAPE'
    ]
  ])(
    'preserves real loader/shorthand/export/default identities: %s',
    (text, reason) => {
      const id = 'r20-lexical-capability-' + observations.length
      const root = path.join(output, 'inert-fixtures', id)
      fs.mkdirSync(path.join(root, 'products/shift'), { recursive: true })
      fs.writeFileSync(
        path.join(root, 'products/shift/marker.js'),
        'throw new Error("R20_MUST_NOT_EXECUTE")'
      )
      const audit = inspect(id, text)
      expect(audit.passed).toBe(false)
      expect(
        [...audit.violations, ...audit.diagnostics].some(
          (item) => item.reason === reason
        )
      ).toBe(true)
    }
  )
})

describe('R20 necessary binding analysis remains explicitly unavailable', () => {
  const cases = [
    [
      'getSymbolAtLocation',
      'const handle=unknown;handle',
      (node) => ts.isExpressionStatement(node.parent)
    ],
    [
      'getShorthandAssignmentValueSymbol',
      'const handle=unknown;const data={handle}',
      (node) => ts.isShorthandPropertyAssignment(node.parent)
    ],
    [
      'getExportSpecifierLocalTargetSymbol',
      'const handle=unknown;export {handle as value}',
      (node) =>
        ts.isExportSpecifier(node.parent) && node.parent.propertyName === node
    ],
    [
      'resolveName',
      'const handle=unknown;function label(value=handle){function handle(){}return value}',
      (node) => ts.isParameter(node.parent) && node.parent.initializer === node
    ]
  ]
  function fixture(operation, text, select, error) {
    const source = ts.createSourceFile(
      '/inert/r20-unavailable.mts',
      text,
      ts.ScriptTarget.Latest,
      true
    )
    let identifier
    const visit = (node) => {
      if (ts.isIdentifier(node) && node.text === 'handle' && select(node))
        identifier = node
      ts.forEachChild(node, visit)
    }
    visit(source)
    const facade = {
      ...ts,
      createProgram(...args) {
        const checker = ts.createProgram(...args).getTypeChecker()
        return {
          getTypeChecker: () =>
            new Proxy(checker, {
              get(target, name) {
                return name === operation
                  ? () => {
                      throw error
                    }
                  : target[name]
              }
            })
        }
      }
    }
    return { facade, source, identifier }
  }
  it.each(cases)(
    'reports stack exhaustion in %s without assigning global identity',
    (operation, text, select) => {
      const error = new RangeError('Maximum call stack size exceeded')
      const { facade, source, identifier } = fixture(
        operation,
        text,
        select,
        error
      )
      const diagnostics = []
      const lexical = createBoundaryLexical(
        facade,
        source,
        false,
        (diagnostic) => diagnostics.push(diagnostic)
      )
      const identity = lexical.identity(identifier)
      expect(identity.unavailable.reason).toBe(
        'UNAVAILABLE_LEXICAL_BINDING_ANALYSIS'
      )
      expect(identity).not.toBe(lexical.global('handle'))
      expect(identity.global).toBeUndefined()
      expect(identity.declarations).toBeUndefined()
      expect(lexical.identity(identifier)).toBe(identity)
      expect(diagnostics).toEqual([
        {
          reason: 'UNAVAILABLE_LEXICAL_BINDING_ANALYSIS',
          file: '/inert/r20-unavailable.mts',
          operation,
          identifier: 'handle',
          position: identifier.getStart(source),
          error: 'Maximum call stack size exceeded'
        }
      ])
    }
  )
  it.each([
    new TypeError('checker defect'),
    new RangeError('different range failure')
  ])('propagates unrelated checker errors: %s', (error) => {
    const { facade, source, identifier } = fixture(...cases[0], error)
    const diagnostics = []
    const lexical = createBoundaryLexical(facade, source, false, (diagnostic) =>
      diagnostics.push(diagnostic)
    )
    expect(() => lexical.identity(identifier)).toThrow(error)
    expect(diagnostics).toEqual([])
  })
  it('requires an incomplete reporter and preserves the original stack as cause', () => {
    const error = new RangeError('Maximum call stack size exceeded')
    const { facade, source, identifier } = fixture(...cases[0], error)
    const lexical = createBoundaryLexical(facade, source)
    let caught
    try {
      lexical.identity(identifier)
    } catch (failure) {
      caught = failure
    }
    expect(caught.message).toContain(
      'boundary_lexical_analysis_incomplete:/inert/r20-unavailable.mts:getSymbolAtLocation:'
    )
    expect(caught.cause).toBe(error)
  })
})
