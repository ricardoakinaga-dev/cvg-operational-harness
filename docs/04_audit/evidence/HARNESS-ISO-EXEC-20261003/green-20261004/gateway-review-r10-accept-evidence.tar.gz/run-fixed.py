import subprocess,os,json,pathlib,time,sys
O=pathlib.Path('/home/ricardo/.cache/cvg-harness-green-20261004/gateway-review-r10/output')
NODE='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node'
env={'PATH':'/home/ricardo/.nvm/versions/node/v22.23.2/bin:/usr/bin:/bin','TMPDIR':str(O/'tmp'),'TZ':'UTC','TSX_CACHE_DIR':str(O/'tsx-cache'),'CI':'1'}
name=sys.argv[1]
commands={
 'regression-synthetic-rerun':[NODE,str(O/'regression/node_modules/vitest/vitest.mjs'),'run','products/shift-assistant/src/__tests__/synthetic-openai.test.ts','--no-file-parallelism','--maxWorkers=1','--reporter=json','--outputFile='+str(O/'regression-synthetic-rerun-results.json')],
 'regression':[NODE,str(O/'regression/node_modules/vitest/vitest.mjs'),'run','packages/model-gateway/src/__tests__','packages/shared/src/__tests__','products/shift-assistant/src/__tests__','--no-file-parallelism','--maxWorkers=1','--reporter=json','--outputFile='+str(O/'regression-results.json')],
 'frozen-probes':[NODE,str(O/'frozen-consumer/probe.mjs')],
 'rebuilt-probes':[NODE,str(O/'rebuilt-consumer/probe.mjs')],
 'frozen-durable':[NODE,str(O/'frozen-consumer/durable-suite.mjs')],
 'rebuilt-durable':[NODE,str(O/'rebuilt-consumer/durable-suite.mjs')],
 'frozen-additional':[NODE,str(O/'frozen-consumer/additional.mjs')],
 'rebuilt-additional':[NODE,str(O/'rebuilt-consumer/additional.mjs')],
 'types':[NODE,str(O/'regression/node_modules/typescript/bin/tsc'),'-p',str(O/'frozen-consumer/typecheck.json')],
 'types-rebuilt':[NODE,str(O/'regression/node_modules/typescript/bin/tsc'),'-p',str(O/'rebuilt-consumer/typecheck.json')]
}
cwd=O/'regression' if name.startswith('regression') else O/('rebuilt-consumer' if name.startswith('rebuilt') or name=='types-rebuilt' else 'frozen-consumer')
start=time.time()
with (O/(name+'.log')).open('w') as log:r=subprocess.run(commands[name],cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
record={'name':name,'command':commands[name],'cwd':str(cwd),'env':env,'exitCode':r.returncode,'durationSeconds':time.time()-start,'log':name+'.log'}
with (O/'commands.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
print(json.dumps(record))
sys.exit(r.returncode)
