from pathlib import Path
import json,os,hashlib,re
P=Path('/home/ricardo/.cache/cvg-harness-green-20261004/gateway-review-r10'); O=P/'output'
def inventory(root,relative):
 result={}
 for d,dirs,files in os.walk(root,followlinks=False):
  for name in dirs+files:
   f=Path(d)/name;rel=f.relative_to(relative).as_posix();st=f.lstat()
   if f.is_symlink():result[rel]={'kind':'symlink','target':os.readlink(f),'inode':st.st_ino,'dev':st.st_dev,'mode':st.st_mode,'nlink':st.st_nlink}
   elif f.is_file():result[rel]={'kind':'file','bytes':st.st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'inode':st.st_ino,'dev':st.st_dev,'mode':st.st_mode,'nlink':st.st_nlink}
 return result
a=inventory(P/'source',P/'source');b=json.loads((O/'before-manifest.json').read_text());changes=[k for k in set(a)|set(b) if a.get(k)!=b.get(k)];(O/'after-manifest.json').write_text(json.dumps(a,indent=2)+'\n')
cm={}
for name in ['frozen-consumer/node_modules','rebuilt-consumer/node_modules','recompile']:cm.update(inventory(O/name,O))
cb=json.loads((O/'consumer-before-manifest.json').read_text());cc=[k for k in set(cm)|set(cb) if ({**cm.get(k,{}),'kind':'link' if cm.get(k,{}).get('kind')=='symlink' else cm.get(k,{}).get('kind')})!=cb.get(k)];(O/'consumer-after-manifest.json').write_text(json.dumps(cm,indent=2)+'\n')
# Count the same full unit + E2E path denominator specified by the packet authority.
tests=[k for k in b if re.search(r'\.(test|spec)\.(ts|tsx|js)$',k) and not k.startswith('node_modules/') and '/dist/' not in k];(O/'test-path-inventory.json').write_text(json.dumps(tests,indent=2)+'\n')
protected={};protectedChanges=[]
for rel in b:
 if '/__tests__/' in rel and any(rel.startswith(x) for x in ['packages/model-gateway/','packages/shared/','products/shift-assistant/']):
  f=O/'regression'/rel;expected=b[rel].get('sha256');observed=hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None
  protected[rel]={'frozenSha256':expected,'copySha256':observed,'equal':expected==observed,'copyMode':oct(f.stat().st_mode&0o777),'frozenMode':oct(b[rel]['mode']&0o777)}
  if expected!=observed:protectedChanges.append(rel)
(O/'protected-regression-manifest.json').write_text(json.dumps(protected,indent=2)+'\n')
summary={'sourceEntries':len(a),'regularFiles':sum(x['kind']=='file' for x in a.values()),'symlinks':sum(x['kind']=='symlink' for x in a.values()),'sourceChanges':changes,'consumerInputEntries':len(cm),'consumerChanges':cc,'protectedRegressionEntries':len(protected),'protectedChanges':protectedChanges,'testPaths':len(tests),'unitPaths':sum('.test.' in x for x in tests),'e2ePaths':sum('.spec.' in x for x in tests),'externalLinkTargets':[k for k in a if a[k]['kind']=='symlink' and not (P/'source'/k).resolve().is_relative_to(P)]}
(O/'integrity-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
