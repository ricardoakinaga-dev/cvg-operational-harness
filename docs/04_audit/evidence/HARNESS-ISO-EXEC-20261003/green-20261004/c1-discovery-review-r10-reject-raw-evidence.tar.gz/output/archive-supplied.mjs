import fs from 'node:fs';
import path from 'node:path';
import {syncBuiltinESMExports} from 'node:module';
const nativeRm=fs.rmSync;
fs.rmSync=function(p,options){
 if(typeof p==='string' && path.basename(p).startsWith('cvg-c1-lexical-static-')){
  const to=path.join(process.env.REVIEW_OUTPUT,'raw','supplied-fixtures',path.basename(p));
  fs.mkdirSync(path.dirname(to),{recursive:true});fs.cpSync(p,to,{recursive:true,preserveTimestamps:true});
 }
 return nativeRm(p,options);
};
syncBuiltinESMExports();
