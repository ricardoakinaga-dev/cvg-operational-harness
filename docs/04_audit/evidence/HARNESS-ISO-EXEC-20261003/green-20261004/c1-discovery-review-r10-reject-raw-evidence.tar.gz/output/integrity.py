import os,sys,json,hashlib,stat,pathlib
base=pathlib.Path(__file__).resolve().parent.parent
phase=sys.argv[1]
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def inventory(root):
 out={}
 def walk(p):
  s=p.lstat();rel=str(p.relative_to(root))
  v={'kind':'symlink' if stat.S_ISLNK(s.st_mode) else 'dir' if stat.S_ISDIR(s.st_mode) else 'file','mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'size':s.st_size,'dev':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink}
  if v['kind']=='symlink':v['target']=os.readlink(p)
  elif v['kind']=='file':v['sha256']=sha(p)
  out[rel]=v
  if v['kind']=='dir':
   for x in sorted(p.iterdir()):walk(x)
 walk(root);return out
snap={'source':inventory(base/'source'),'inputs':{n:{'sha256':sha(base/n),'mtime_ns':(base/n).stat().st_mtime_ns,'ctime_ns':(base/n).stat().st_ctime_ns,'size':(base/n).stat().st_size} for n in ['authority.json','freeze.json','frozen-inventory.json']}}
path=base/'output'/('integrity-'+phase+'.json');path.write_text(json.dumps(snap,sort_keys=True,indent=2)+'\n')
frozen=json.loads((base/'frozen-inventory.json').read_text());diff=[]
for k,v in frozen.items():
 a=snap['source'].get(k)
 if a is None or a['kind']!=('symlink' if v['kind']=='link' else v['kind']) or (v['kind']=='file' and (a['size']!=v['bytes'] or a['sha256']!=v['sha256'])) or (v['kind']=='link' and a['target']!=v.get('target')):diff.append(k)
summary={'phase':phase,'snapshot_sha256':sha(path),'source_entries':len(snap['source']),'source_files':sum(v['kind']=='file' for v in snap['source'].values()),'frozen_sha_matches':sha(base/'frozen-inventory.json')==json.loads((base/'freeze.json').read_text())['inventorySha256'],'frozen_differences':diff}
if phase=='after':
 before=json.loads((base/'output/integrity-before.json').read_text());summary['before_after_identical']=before==snap;summary['changed_entries']=[k for k in set(before['source'])|set(snap['source']) if before['source'].get(k)!=snap['source'].get(k)];summary['inputs_unchanged']=before['inputs']==snap['inputs']
(base/'output'/('integrity-'+phase+'-summary.json')).write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
