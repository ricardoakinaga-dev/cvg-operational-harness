import pathlib,subprocess,json,sys,time,hashlib
base=pathlib.Path(__file__).resolve().parent;node='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node'
name=sys.argv[1];args=sys.argv[2:]
env={'PATH':'/home/ricardo/.nvm/versions/node/v22.23.2/bin:/usr/bin:/bin','HOME':str(base/'home'),'TMPDIR':str(base/'tmp'),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','REVIEW_OUTPUT':str(base),'CI':'1','NO_COLOR':'1'}
if name=='supplied':env['NODE_OPTIONS']='--import='+str(base/'archive-supplied.mjs')
cmd=['/usr/bin/unshare','--user','--map-root-user','--net','/usr/bin/strace','-f','-qq','-e','trace=network','-o',str(base/'raw'/f'{name}-network.strace'),node,*args]
t=time.time()
with (base/'raw'/f'{name}.stdout.log').open('w') as out,(base/'raw'/f'{name}.stderr.log').open('w') as err:
 r=subprocess.run(cmd,cwd=base/'runtime',env=env,stdout=out,stderr=err)
record={'command':cmd,'env':env,'cwd':str(base/'runtime'),'exit':r.returncode,'duration_seconds':time.time()-t,'network_namespace':'isolated empty network namespace','fixture_execution':False,'original_253_execution':False}
(base/'raw'/f'{name}-execution.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
