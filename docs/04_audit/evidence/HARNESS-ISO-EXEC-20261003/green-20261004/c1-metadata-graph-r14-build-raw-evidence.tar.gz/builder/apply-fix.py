from pathlib import Path
p=Path('/home/ricardo/.cache/cvg-harness-green-20261004/c1-metadata-graph-r14-candidate/scripts/check-product-boundary.mjs');s=p.read_text()
insert='''  const governedActors = new Set()
  const linkedManifests = new Set()
  // Shape validation and graph reachability are separate obligations. Every
  // governed actor manifest must retain its dependencies, even after census
  // was memoized by an earlier workspace or local metadata reference.
  const manifestEdges = (pkgFile) => {
    if (linkedManifests.has(pkgFile)) return
    linkedManifests.add(pkgFile)
    const pkg = metadata.read(pkgFile)
    for (const field of manifestDependencyFields)
      for (const [name, version] of Object.entries(pkg[field] ?? {})) {
        const specifier = version.trim()
        if (/^(file|link):/.test(specifier)) {
          const targetPkg = metadata.localPackage(pkgFile, version)
          edge(pkgFile, targetPkg)
          const context = path.dirname(targetPkg)
          const dependency = [...workspaces.values()].find(
            (item) => item.workspace === context
          )
          if (dependency) edge(pkgFile, workspaceNode(dependency))
          else reportDiagnostic(pkgFile, {
            file: path.relative(root, pkgFile),
            specifier: name,
            reason: 'UNVERIFIED_LOCAL_DEPENDENCY'
          })
          governActor(context)
        } else {
          let targetName = name
          if (specifier.startsWith('npm:')) {
            const alias = specifier.slice(4), separator = alias.lastIndexOf('@')
            targetName = separator > 0 ? alias.slice(0, separator) : alias
          }
          const dependency = workspaces.get(targetName)
          if (dependency) edge(pkgFile, workspaceNode(dependency))
        }
      }
  }
  const governActor = (context) => {
    if (governedActors.has(context)) return
    governedActors.add(context)
    const pkgFile = path.join(context, 'package.json')
    metadata.read(pkgFile)
    if (context !== root) metadata.census(context)
    const manifests = context === root ? [pkgFile] : [...metadata.cache.keys()].filter(
      (file) => inside(context, file) &&
        !path.relative(context, file).split(path.sep).some(
          (part) => ['node_modules', '.git'].includes(part)
        )
    )
    for (const filename of manifests) {
      if (filename !== pkgFile) edge(pkgFile, filename)
      manifestEdges(filename)
    }
  }
'''
anchor='  const runtimeReferences = []\n';assert s.count(anchor)==1;s=s.replace(anchor,insert+anchor)
a=s.index('        metadata.read(pkgFile)\n',s.index('  const localTarget ='));z=s.index('        break\n',a)
s=s[:a]+'''        // Root ancestry alone does not govern documentary archives. A reached
        // nonRoot physical actor owns all of its recursively censused metadata.
        edge(file, pkgFile)
        governActor(context)
'''+s[z:]
a=s.index('    for (const field of manifestDependencyFields) {',s.index('  // Ask Node'))
# This is the workspace dependency loop, not the newly inserted helper.
z=s.index('  function reference(',a)
assert s[z-4:z]=='  }\n'
s=s[:a]+'    governActor(item.workspace)\n  }\n'+s[z:]
p.write_text(s)
