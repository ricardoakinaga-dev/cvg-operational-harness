
// R14: governed recursive metadata retains its dependency graph and frontier.
describe('R14 reached actor manifest graph completeness', () => {
  const fields = ['dependencies', 'devDependencies', 'optionalDependencies', 'peerDependencies']
  function actorFixture(id, field, kind, reached, workspace = false) {
    const root = path.join(output, 'r14-inert', id)
    const put = (rel, value) => {
      const p = path.join(root, rel)
      fs.mkdirSync(path.dirname(p), {recursive:true})
      fs.writeFileSync(p, typeof value === 'string' ? value : JSON.stringify(value))
    }
    for (const d of ['packages/core/src','apps','legacy','products']) fs.mkdirSync(path.join(root,d),{recursive:true})
    put('package.json', {private:true,type:'module',workspaces:['packages/*','products/*']})
    put('packages/core/package.json', {name:'@synthetic/core',type:'module'})
    put('products/consumer/package.json',{name:'@synthetic/consumer',type:'module'})
    put('products/consumer/src/index.mts','export const label="consumer";')
    put('tsconfig.base.json',{compilerOptions:{module:'NodeNext',moduleResolution:'NodeNext',target:'ESNext',allowJs:true}})
    const actor = workspace ? 'packages/core' : 'auxiliary/bridge'
    put('packages/core/src/index.mts', reached && !workspace ? 'import "../../../auxiliary/bridge/src/index.mts";' : 'export const label="neutral";')
    if (!workspace) {put(actor+'/package.json',{name:'@synthetic/bridge',type:'module'});put(actor+'/src/index.mts','export const label="bridge";')}
    const nested = actor+'/dist/nested'
    const relativeProduct = workspace ? '../../../../products/consumer' : '../../../../products/consumer'
    let deps
    if (kind === 'direct') deps = {'@synthetic/consumer':'1.0.0'}
    if (kind === 'alias') deps = {alias:'npm:@synthetic/consumer@^1.0.0'}
    if (kind === 'local') deps = {alias:'file:'+relativeProduct}
    if (kind === 'link') deps = {alias:'link:'+relativeProduct}
    if (kind === 'transitive' || kind === 'unknown' || kind === 'cycle') {
      deps = {neutral:'file:../../../../auxiliary/target'}
      put('auxiliary/target/package.json',{name:'@synthetic/target',type:'module',...(kind==='cycle'?{[field]:{back:'file:../bridge'}}:{})})
      put('auxiliary/target/src/index.mts','export const label="target";')
      if (kind === 'transitive') put('auxiliary/target/dist/package.json',{[field]:{'@synthetic/consumer':'1.0.0'}})
    }
    put(nested+'/package.json',{[field]:deps})
    return auditProductBoundary(root)
  }
  const known = fields.flatMap(field=>['direct','alias','local','link','transitive'].map(kind=>[field,kind]))
  it.each(known)('%s/%s reached nested product remains FAIL', (field,kind)=>{
    expect(actorFixture('reached-'+field+'-'+kind,field,kind,true).status).toBe('FAIL')
  })
  it.each(known)('%s/%s opaque actor does not enter core closure', (field,kind)=>{
    expect(actorFixture('opaque-'+field+'-'+kind,field,kind,false).status).toBe('PASS')
  })
  it.each(fields)('%s nested unknown local frontier remains INCOMPLETE', field=>{
    const audit = actorFixture('unknown-'+field,field,'unknown',true)
    expect(audit.status).toBe('INCOMPLETE')
    expect(audit.diagnostics.some(d=>d.reason==='UNVERIFIED_LOCAL_DEPENDENCY')).toBe(true)
  })
  it.each(fields)('%s opaque unknown local frontier stays separate', field=>{
    expect(actorFixture('opaque-unknown-'+field,field,'unknown',false).status).toBe('PASS')
  })
  it.each(fields)('%s already-censused workspace nested dependency stays reachable', field=>{
    expect(actorFixture('workspace-'+field,field,'direct',true,true).status).toBe('FAIL')
  })
  it.each(fields)('%s cyclic local frontier terminates and remains blocked', field=>{
    expect(actorFixture('cycle-'+field,field,'cycle',true).status).toBe('INCOMPLETE')
  })
})
