

// R11 fixtures are inert JSON/source labels and lexical symbols, never imported.
describe('R11 declared/local closure and shorthand labels', () => {
  function fixture(id, change = () => {}) {
    const root = path.join(output, 'r11-inert-fixtures', id)
    const put = (rel, value) => {const p=path.join(root,rel);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof value==='string'?value:JSON.stringify(value))}
    for(const d of ['packages/core/src','apps','legacy','products/consumer/src']) fs.mkdirSync(path.join(root,d),{recursive:true})
    const data={root:{private:true,type:'module',workspaces:['packages/*','products/*']},core:{name:'@synthetic/core',type:'module'},consumer:{name:'@synthetic/consumer',type:'module'}}
    put('packages/core/src/index.mjs','export const label="synthetic";')
    put('products/consumer/src/index.mjs','export const label="synthetic";')
    change(data,put)
    put('package.json',data.root);put('packages/core/package.json',data.core);put('products/consumer/package.json',data.consumer)
    return root
  }
  const owners=['root','core','consumer']
  it.each(owners.flatMap(owner=>['file:missing','bad tag','https://example.invalid/value','git+ssh://example.invalid/value'].map(version=>[owner+'-'+version,v=>{v[owner].dependencies={'alias-neutral':'npm:neutral@'+version}}])))('%s blocks invalid registry alias', (id,change)=>{
    expect(()=>auditProductBoundary(fixture(id,change)),id).toThrow()
  })
  it.each(['latest','^1.2.3','>=1 <2','1.0.0-beta.1+build','*','1.2'])('%s retains valid registry alias',(version)=>{
    expect(auditProductBoundary(fixture('alias-valid-'+version,v=>{v.root.dependencies={'alias-neutral':'npm:neutral@'+version}})).status).toBe('PASS')
  })
  it.each(['tools','examples','config','scripts','packages/core/dist'])('%s validates owned physical metadata',(dir)=>{
    expect(()=>auditProductBoundary(fixture('global-'+dir,(_v,put)=>put(dir+'/unused/package.json',[]))),dir).toThrow()
  })
  it.each([
    ['product','import "../../../products/consumer/src/index.mjs";','FAIL'],
    ['unknown','export const label=opaque.constructor;','INCOMPLETE'],
    ['parse','export const label = ;','INCOMPLETE'],
    ['env','export const label=process.env.SHIFT_ACCOUNT_REF;','FAIL'],
    ['neutral','export const label="synthetic";','PASS']
  ])('declared tools source %s is part of closure',(id,text,status)=>{
    const root=fixture('declared-'+id,(v,put)=>{v.root.workspaces.push('tools/*');v.core.dependencies={'@synthetic/aux':'*'};put('tools/aux/package.json',{name:'@synthetic/aux',type:'module'});put('tools/aux/src/index.mjs',text)})
    expect(auditProductBoundary(root).status,id).toBe(status)
  })
  it.each(['root','consumer'])('nested local refs from %s are validated',(owner)=>{
    const root=fixture('nested-'+owner,(v,put)=>{v[owner].dependencies={'alias-outer':'file:'+(owner==='root'?'local/outer':'../../local/outer')};put('local/outer/package.json',{name:'@synthetic/outer',dependencies:{'alias-inner':'file:../missing'}})})
    expect(()=>auditProductBoundary(root)).toThrow()
  })
  it('valid local metadata cycles terminate without dropping references',()=>{
    const root=fixture('local-cycle',(v,put)=>{v.root.dependencies={'alias-outer':'file:local/outer'};put('local/outer/package.json',{name:'@synthetic/outer',dependencies:{'alias-inner':'file:../inner'}});put('local/inner/package.json',{name:'@synthetic/inner',dependencies:{'alias-outer':'file:../outer'}})})
    expect(auditProductBoundary(root).status).toBe('PASS')
  })
  it.each(['mts','cts'])('shorthand fallback in %s preserves its own identifier symbol',(ext)=>{
    const text='function f(Seed){let token;({token=Seed}={});return Seed}'
    const source=ts.createSourceFile('entry.'+ext,text,ts.ScriptTarget.Latest,true);expect(source.parseDiagnostics).toEqual([])
    const lexical=createBoundaryLexical(ts,source,ext==='cts');const nodes=[]
    const visit=node=>{if(ts.isIdentifier(node)&&node.text==='Seed')nodes.push(node);ts.forEachChild(node,visit)};visit(source);expect(nodes).toHaveLength(3)
    expect(lexical.identity(nodes[0])).toBe(lexical.identity(nodes[1]));expect(lexical.identity(nodes[1])).toBe(lexical.identity(nodes[2]))
  })
  it('shorthand fallback retains executor reference as an inert label',()=>{
    expect(inspect('r11-shorthand-executor','const Seed=Function;let token;({token=Seed}={});export {token};').status).toBe('INCOMPLETE')
  })
})
