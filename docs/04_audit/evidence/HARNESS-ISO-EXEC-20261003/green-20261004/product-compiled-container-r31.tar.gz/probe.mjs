#!/usr/bin/env node
import fs from 'node:fs'
import { spawnSync } from 'node:child_process'
import { randomUUID } from 'node:crypto'
import { requireThat, sha } from 'file:///home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r19/scripts/hiso-contract.mjs'

const image = JSON.parse(fs.readFileSync('image.json', 'utf8'))
requireThat(
  image.candidateId === process.env.CI_CANDIDATE_ID &&
    image.runId === process.env.CI_RUN_ID,
  'product_image_binding'
)
const name = 'cvg-r31-product-' + randomUUID()
// This code runs INSIDE the actual candidate container. Network none permits
// only its own loopback mocks; /data is an isolated, ephemeral synthetic tmpfs.
const code = `
import fs from 'node:fs';import assert from 'node:assert/strict';import {createServer} from 'node:http';import {spawn} from 'node:child_process';import {createHash} from 'node:crypto';
let sends=0,modelCalls=0;const sent=[];
const wa=createServer((req,res)=>{void(async()=>{let body='';for await(const chunk of req)body+=chunk;sent.push(JSON.parse(body));sends++;res.setHeader('content-type','application/json');res.end(JSON.stringify({id:'synthetic-'+sends}))})()});
const model=createServer((req,res)=>{req.resume();modelCalls++;res.end('{}')});
const bind=s=>new Promise(r=>s.listen(0,'127.0.0.1',()=>r('http://127.0.0.1:'+s.address().port)));
const waUrl=await bind(wa),modelUrl=await bind(model);
const secret='hiso-synthetic-webhook-fixture-123456';
const child=spawn('/usr/local/bin/node',['/app/shift-assistant.mjs'],{env:{NODE_ENV:'production',SHIFT_PROVIDER:'waha',SHIFT_MEMBERS:'5511900000001=Synthetic;5511900000009=Gestor*',SHIFT_WEBHOOK_SECRET:secret,SHIFT_DATA_DIR:'/data',SHIFT_PORT:'0',SHIFT_HOST:'127.0.0.1',WAHA_URL:waUrl,WAHA_API_KEY:'synthetic-only',WHISPER_URL:'http://127.0.0.1:1',LLM_BASE_URL:modelUrl,LLM_LOCATION:'local',LLM_MODEL:'synthetic'},stdio:['ignore','pipe','pipe']});
let text='',errors='';child.stderr.on('data',c=>{errors+=c});
const timer=setTimeout(()=>child.kill('SIGKILL'),15000);
try {
const port=await new Promise((resolve,reject)=>{child.on('error',reject);child.once('exit',()=>reject(new Error('product exited before ready; synthetic-only stderr: '+errors)));child.stdout.on('data',c=>{text+=c;for(const line of text.split('\\n'))try{const v=JSON.parse(line);if(v.event==='shift.started')resolve(v.port)}catch{}})});
assert.equal((await fetch('http://127.0.0.1:'+port+'/health')).status,200);
const status=fs.readFileSync('/proc/self/status','utf8');
assert.equal(process.getuid(),10001);assert.equal(process.getgid(),10001);
assert(status.match(/CapEff:[ \t]+0+[ \t]*$/m));assert(status.match(/NoNewPrivs:[ \t]+1/m));
assert.throws(()=>fs.appendFileSync('/app/shift-assistant.mjs','MUST_NOT_WRITE'),e=>e.code==='EROFS');
assert.equal(fs.existsSync('/bin/sh'),false);assert.equal(fs.existsSync('/usr/bin/npm'),false);assert.equal(fs.existsSync('/usr/local/bin/npm'),false);
assert.equal(fs.readFileSync('/sys/fs/cgroup/memory.max','utf8').trim(),'536870912');assert.equal(fs.readFileSync('/sys/fs/cgroup/pids.max','utf8').trim(),'64');

const response=await fetch('http://127.0.0.1:'+port+'/webhooks/waha',{method:'POST',headers:{'content-type':'application/json','x-cvg-webhook-secret':secret},body:JSON.stringify({event:'message',payload:{id:'hiso-synthetic-help',from:'5511900000001@c.us',body:'/ajuda'}})});assert.equal(response.status,200);
await new Promise(r=>setTimeout(r,250));assert(sends>0);assert.equal(modelCalls,0);assert.equal(process.getuid(),10001);
const raw="SYN-Alfa ID SYN-A01 leito SYN-L01 espécie: canina. tutor: SYN-Tutor-A. motivo: observação fictícia de admissão.";
const say=async(id,body)=>{const response=await fetch('http://127.0.0.1:'+port+'/webhooks/waha',{method:'POST',headers:{'content-type':'application/json','x-cvg-webhook-secret':secret},body:JSON.stringify({event:'message',payload:{id,from:'5511900000001@c.us',body}})});assert.equal(response.status,200)};
const until=async(f)=>{const deadline=Date.now()+4000;while(!f()){assert(Date.now()<deadline,'synthetic effect deadline');await new Promise(r=>setTimeout(r,10))}};
await say('hiso-production-raw-note',raw);await until(()=>sent.some(v=>String(v.text).startsWith('RASCUNHO')&&String(v.text).includes(raw)&&String(v.text).includes('ok nota ')));
const preview=sent.find(v=>String(v.text).startsWith('RASCUNHO')&&String(v.text).includes(raw)&&String(v.text).includes('ok nota ')).text;assert(preview.includes(raw));
const token=preview.match(/ok nota ([a-f0-9]{12}-r[0-9]+-[a-f0-9]{12})/)?.[1];assert(token);assert(!sent.some(v=>String(v.text).includes('Nota confirmada.')));
await say('hiso-production-explicit-confirm','ok nota '+token);await until(()=>sent.some(v=>String(v.text).includes('Nota confirmada.')));assert.equal(modelCalls,0);
assert.equal(child.spawnargs.includes('/app/shift-assistant.mjs'),true);

console.log(JSON.stringify({status:'PASS',health:200,syntheticDemo:'help-raw-note-explicit-confirm',nodeEnv:'production',rawSourcePreserved:true,automaticConfirmation:false,sends,modelCalls,uid:process.getuid(),bundleSha256:createHash('sha256').update(fs.readFileSync('/app/shift-assistant.mjs')).digest('hex')}));
}finally{clearTimeout(timer);child.kill('SIGTERM');await new Promise(r=>{if(child.exitCode!==null)r();else{child.once('exit',r);setTimeout(()=>child.kill('SIGKILL'),1000).unref()}});wa.closeAllConnections();model.closeAllConnections();await Promise.all([new Promise(r=>wa.close(r)),new Promise(r=>model.close(r))]);}
`
try {
  const result = spawnSync(
    'docker',
    [
      'run',
      '--name',
      name,
      '--network',
      'none',
      '--read-only',
      '--memory=512m',
      '--cpus=1',
      '--pids-limit=64',
      '--tmpfs',
      '/tmp:rw,noexec,nosuid,nodev,size=64m,mode=1777',
      '--tmpfs',
      '/data:uid=10001,gid=10001,mode=0700',
      '--cap-drop=ALL',
      '--security-opt',
      'no-new-privileges',
      image.imageId,
      '/usr/local/bin/node',
      '--input-type=module',
      '-e',
      code
    ],
    { encoding: 'utf8', timeout: 60000, maxBuffer: 8 * 1024 * 1024 }
  )
  process.stdout.write(result.stdout ?? '')
  process.stderr.write(result.stderr ?? '')
  requireThat(result.status === 0, 'product_container_smoke_failed')
  const smoke = JSON.parse(result.stdout.trim().split('\n').at(-1))
  requireThat(
    smoke.status === 'PASS' && smoke.modelCalls === 0 && smoke.health === 200,
    'product_container_smoke_evidence'
  )
  const inspection=spawnSync('docker',['inspect',name],{encoding:'utf8',timeout:10000});
  requireThat(inspection.status===0,'own_container_inspect');
  const inspected=JSON.parse(inspection.stdout)[0];
  fs.writeFileSync('container-inspect.json',JSON.stringify({Id:inspected.Id,Image:inspected.Image,Config:inspected.Config,HostConfig:inspected.HostConfig,State:inspected.State},null,2)+'\n');
  fs.writeFileSync(
    'image-smoke.json',
    JSON.stringify(
      {
        ...smoke,
        imageId: image.imageId,
        runId: image.runId,
        candidateId: image.candidateId,
        probeSha256: sha(code),
        network: 'none',
        readOnly: true,
        syntheticDataTmpfs: true
      },
      null,
      2
    ) + '\n'
  )
} finally {
  spawnSync('docker', ['rm', '-f', name], { encoding: 'utf8', timeout: 10000 })
}
