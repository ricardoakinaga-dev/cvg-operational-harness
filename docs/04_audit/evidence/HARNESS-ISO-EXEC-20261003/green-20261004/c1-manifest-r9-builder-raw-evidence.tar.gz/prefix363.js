// @vitest-environment node
// Every fixture is inert source text. Only the parser and analyzer consume it.
// Never import a fixture or execute its evaluator/process/worker/vm expressions.
import fs from 'node:fs'
import path from 'node:path'
import { tmpdir } from 'node:os'
import ts from 'typescript'
import { afterAll, describe, expect, it } from 'vitest'
import { auditProductBoundary } from '../scripts/check-product-boundary.mjs'
import { createBoundaryLexical } from '../scripts/boundary-lexical.mjs'
const output = fs.mkdtempSync(path.join(tmpdir(), 'cvg-c1-lexical-static-'))
afterAll(() => fs.rmSync(output, { recursive: true, force: true }))
const observations = []
function inspect(id, text, extension = 'mts') {
  const root = path.join(output, 'inert-fixtures', id)
  const write = (relative, content) => {
    const file = path.join(root, relative)
    fs.mkdirSync(path.dirname(file), { recursive: true })
    fs.writeFileSync(file, content)
  }
  for (const dir of ['packages/core/src', 'apps', 'legacy', 'products'])
    fs.mkdirSync(path.join(root, dir), { recursive: true })
  write(
    'package.json',
    JSON.stringify({
      private: true,
      type: 'module',
      workspaces: ['packages/*']
    })
  )
  write(
    'packages/core/package.json',
    JSON.stringify({ name: '@synthetic/core', type: 'module' })
  )
  write(
    'tsconfig.base.json',
    JSON.stringify({
      compilerOptions: {
        module: 'NodeNext',
        moduleResolution: 'NodeNext',
        target: 'ESNext',
        allowJs: true
      }
    })
  )
  write(
    'packages/core/src/neutral.ts',
    'export interface Data {label:string};export const label="synthetic";'
  )
  const file = `packages/core/src/entry.${extension}`
  write(file, text)
  const source = ts.createSourceFile(
    path.join(root, file),
    text,
    ts.ScriptTarget.Latest,
    true
  )
  expect(source.parseDiagnostics, id).toEqual([])
  const audit = auditProductBoundary(root)
  observations.push({
    id,
    text,
    parseErrors: source.parseDiagnostics.length,
    fixturesExecuted: false,
    ...audit
  })
  fs.writeFileSync(
    path.join(output, 'new-static-results.json'),
    JSON.stringify(observations, null, 2) + '\n'
  )
  return audit
}
const neutral = [
  [
    'neutral-data',
    'const data={eval:"label",Function:"label"}; export const label=data.eval;',
    'mts'
  ],
  [
    'neutral-type-query',
    'export type Identity=typeof Function; export const value=1;',
    'mts'
  ],
  [
    'neutral-worker-metadata',
    'import {isMainThread} from "node:worker_threads"; export const value=isMainThread;',
    'mts'
  ],
  [
    'neutral-namespace-metadata',
    'import * as threads from "node:worker_threads"; export const value=threads.isMainThread;',
    'mts'
  ],
  [
    'neutral-type-import',
    'import type {Worker} from "node:worker_threads"; export type Identity=Worker;',
    'mts'
  ],
  [
    'constructor-data',
    'const data={constructor:"label"}; export const label=data.constructor;',
    'mts'
  ],
  [
    'constructor-element-data',
    'const data={constructor:"label"}; export const label=data["constructor"];',
    'mts'
  ],
  ['function-name-metadata', 'export const label=Function.name;', 'mts'],
  ['eval-length-metadata', 'export const arity=eval.length;', 'mts'],
  [
    'parameter-shadow',
    'export function describe(Function:string){return Function;}',
    'mts'
  ],
  ['block-shadow', '{const Function="label"; const label=Function;}', 'mts'],
  [
    'catch-shadow',
    'try {throw "label";} catch(Function){const label=Function;}',
    'mts'
  ],
  [
    'block-shadow-return',
    'export function describe(){const Function="label"; return Function;}',
    'mts'
  ],
  [
    'catch-shadow-return',
    'export function describe(){try {throw "label";} catch(Function){return Function;}}',
    'mts'
  ],
  ['class-declaration', 'export class Function { readonly value=1; }', 'mts'],
  [
    'sibling-scope-alias',
    'import {Worker as handle} from "node:worker_threads"; export function describe(handle:string){return handle;}',
    'mts'
  ],
  [
    'block-scope-alias',
    'import {Worker as handle} from "node:worker_threads"; {const handle="label"; const label=handle;}',
    'mts'
  ],
  [
    'sibling-body-alias',
    'import {Worker as handle} from "node:worker_threads"; export function describe(){const handle="label"; return handle;}',
    'mts'
  ],
  ['type-alias-name', 'export type Function={name:string};', 'mts'],
  ['interface-name', 'export interface Function {name:string;}', 'mts'],
  [
    'ambient-function',
    'declare function Function(value:string):string;',
    'mts'
  ],
  [
    'ambient-namespace',
    'declare namespace Function {const version:string;}',
    'mts'
  ],
  [
    'type-export-name',
    'export type {Data as Function} from "./neutral.js";',
    'mts'
  ],
  [
    'value-export-name',
    'export {label as Function} from "./neutral.js";',
    'mts'
  ],
  [
    'local-export-name',
    'const label="synthetic"; export {label as Function};',
    'mts'
  ],
  ['namespace-export-name', 'export * as Function from "./neutral.js";', 'mts'],
  [
    'type-worker-export-name',
    'export type {Worker as Function} from "node:worker_threads";',
    'mts'
  ],
  [
    'metadata-import-collision',
    'import {isMainThread as Function} from "node:worker_threads"; export const value=Function;',
    'mts'
  ],
  [
    'module-public-metadata-export',
    'export {builtinModules,isBuiltin} from "node:module";',
    'mts'
  ],
  [
    'module-public-metadata-indirect',
    'import {builtinModules,isBuiltin} from "node:module"; export {builtinModules,isBuiltin};',
    'mts'
  ],
  [
    'local-loader-name',
    'export function describe(require:string){return require;}',
    'mts'
  ],
  [
    'local-process-name',
    'export function describe(process:string){return process;}',
    'mts'
  ],
  [
    'type-local-import',
    'import type {Data} from "./neutral.js"; export type Identity=Data;',
    'mts'
  ],
  [
    'dts-control',
    'export interface Function {name:string;} export declare function eval(value:string):string;',
    'd.ts'
  ],
  [
    'lexical-global-in-other-scope',
    'function describe(Function:string){return Function;} export const label=Function.name;',
    'mts'
  ],
  [
    'loop-shadow',
    'import {Worker as handle} from "node:worker_threads";for(const handle of ["label"]){ console.log(handle) }',
    'mts'
  ],
  [
    'named-function-expression',
    'const describe=function Function(){return "label"};export {describe};',
    'mts'
  ],
  [
    'class-expression-name',
    'const describe=class Function {value=1};export {describe};',
    'mts'
  ],
  [
    'type-parameter',
    'function describe<Function>(value:Function){return value}',
    'mts'
  ],
  [
    'implements-erased',
    'interface Function{}; export class Data implements Function {value=1}',
    'mts'
  ],
  [
    'method-property-names',
    'export const data={Function(){return "label"},eval:1};',
    'mts'
  ],
  [
    'binding-alias-property-name',
    'const {Function:label}={Function:"label"};export {label};',
    'mts'
  ],
  [
    'safe-module-renamed',
    'export {builtinModules as Function,isBuiltin as eval} from "node:module"',
    'mts'
  ],
  [
    'scalar-constructor-direct',
    'export const label=({constructor:"label"}).constructor',
    'mts'
  ],
  [
    'scalar-constructor-last',
    'const data={constructor:1,constructor:"label"};export const label=data.constructor',
    'mts'
  ],
  [
    'scalar-constructor-binding',
    'const data={constructor:"label"};const {constructor:label}=data;export {label}',
    'mts'
  ],
  ['metadata-wrapped', 'export const label=(Function as unknown).name', 'mts'],
  [
    'global-this-metadata',
    'export const label=globalThis.Function.name',
    'mts'
  ],
  [
    'loader-import-shadow',
    'import {createRequire as handle} from "node:module";export function describe(handle:string){return handle}',
    'mts'
  ],
  [
    'process-import-shadow',
    'import process from "node:process";export function describe(process:string){return process}',
    'mts'
  ],
  [
    'filename-other-scope',
    'import {createRequire} from "node:module";function describe(__filename:string){return __filename};const load=createRequire(__filename);load("node:fs")',
    'cts'
  ]
]
const unknown = [
  [
    'global-not-removed',
    'function describe(Function:string){return Function};export const capability=Function',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'type-alias-does-not-shadow',
    'type Function={value:string};export const capability=Function',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'interface-does-not-shadow',
    'interface Function{value:string};export const capability=Function',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'sibling-executor-use',
    'import {Worker as handle} from "node:worker_threads";function describe(handle:string){return handle};export const capability=handle',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'global-loader-elsewhere',
    'function describe(require:string){return require};export const load=require',
    'UNVERIFIED_MODULE_LOADER_ESCAPE'
  ],
  [
    'global-process-elsewhere',
    'function describe(process:string){return process};export const host=process',
    'UNVERIFIED_MODULE_LOADER_ESCAPE'
  ],
  [
    'real-reassignment',
    'let handle="label";handle=Function;export {handle}',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'reassignment-join',
    'let handle=Function;handle="label";export {handle}',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'conditional-join',
    'const handle=condition?Function:"label";export {handle}',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'logical-assignment',
    'let handle;handle ||= Function;export {handle}',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'parameter-default',
    'export function describe(handle=Function){return handle}',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'extends-runtime',
    'export class Data extends Function {}',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'decorator-runtime',
    '@Function export class Data {}',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'parameter-decorator',
    'class Data {method(@Function label:string){}}',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'computed-runtime',
    'export class Data {[Function.name + String(eval)]=1}',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'default-runtime',
    'export function describe(label=eval){return label}',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'class-field-runtime',
    'export class Data {value=Function}',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'class-static-runtime',
    'export class Data {static {forward(Function)}}',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'object-shorthand-escape',
    'export const data={Function}',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'scalar-unknown-constructor',
    'export function describe(data:any){return data.constructor}',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'constructor-write',
    'const data={constructor:"label"};data.constructor=unknown;export const label=data.constructor',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'constructor-alias-mutation',
    'const data={constructor:"label"};const alias=data;alias.constructor=unknown;export const label=data.constructor',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'constructor-object-escape',
    'const data={constructor:"label"};forward(data);export const label=data.constructor',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'constructor-export-escape',
    'export const data={constructor:"label"};export const label=data.constructor',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'constructor-destructure-write',
    'const data={constructor:"label"};({value:data.constructor}=other);export const label=data.constructor',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'constructor-getter',
    'const data={get constructor(){return unknown}};export const label=data.constructor',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'constructor-spread',
    'const data={constructor:"label",...unknown};export const label=data.constructor',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'constructor-duplicate-unknown',
    'const data={constructor:"label",constructor:unknown};export const label=data.constructor',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'constructor-prototype',
    'const data={__proto__:unknown,constructor:"label"};export const label=data.constructor',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'metadata-write',
    'Function.name=unknown;export const label=Function.name',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'capability-unknown-property',
    'export const capability=Function[unknown]',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'module-factory-export',
    'export {createRequire as builtinModules} from "node:module"',
    'UNVERIFIED_MODULE_LOADER_EXPORT'
  ],
  [
    'module-star-export',
    'export * from "node:module"',
    'UNVERIFIED_MODULE_LOADER_EXPORT'
  ],
  [
    'module-namespace-export',
    'export * as builtinModules from "node:module"',
    'UNVERIFIED_MODULE_LOADER_EXPORT'
  ],
  [
    'module-unknown-export',
    'export {register as isBuiltin} from "node:module"',
    'UNVERIFIED_MODULE_LOADER_EXPORT'
  ],
  [
    'loader-real-reassignment',
    'let handle="label";handle=require;export {handle}',
    'UNVERIFIED_MODULE_LOADER_ESCAPE'
  ],
  [
    'process-real-reassignment',
    'let handle="label";handle=process;export {handle}',
    'UNVERIFIED_MODULE_LOADER_ESCAPE'
  ],
  [
    'missing-type-edge',
    'import type {Data} from "./missing.js";export type Value=Data',
    'UNRESOLVED_MODULE_REFERENCE'
  ],
  [
    'missing-runtime-edge',
    'import {label} from "./missing.js";export {label}',
    'UNRESOLVED_MODULE_REFERENCE'
  ],
  [
    'missing-optional-edge',
    'try{require("missing-optional-package")}catch{}',
    'UNRESOLVED_MODULE_REFERENCE'
  ]
]
neutral.push(
  [
    'nested-binding-metadata',
    'const {process:{getBuiltinModule:get}}=globalThis;get("node:module").createRequire(__filename)("node:fs")',
    'cts'
  ],
  [
    'module-binding-metadata',
    'const {require:load}=module;load("node:fs")',
    'cts'
  ],
  [
    'const-function-metadata',
    'const alias=Function;export const label=alias.name',
    'mts'
  ],
  [
    'const-eval-metadata',
    'const alias=eval;export const arity=alias.length',
    'mts'
  ],
  [
    'closure-shadows-import',
    'import {Worker as handle} from "node:worker_threads";function describe(handle:string){return ()=>handle};export {describe}',
    'mts'
  ]
)
unknown.push(
  [
    'dts-retains-executable',
    'export const capability=Function',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'metadata-uncertain-join',
    'let alias=Function;alias=unknown;export const capability=alias.name',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'metadata-global-rebind',
    'Function=unknown;export const capability=Function.name',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'metadata-global-property-rebind',
    'globalThis.Function=unknown;export const capability=globalThis.Function.name',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'constructor-iteration-write',
    'const data={constructor:"label"};for(data.constructor of values){};export const capability=data.constructor',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'constructor-method-escape',
    'const data={constructor:"label",method:unknown};data.method();export const capability=data.constructor',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'assignment-pattern-capability',
    'let alias;({value:alias}={value:Function});export {alias}',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'assignment-pattern-loader',
    'let alias;({require:alias}=module);export {alias}',
    'UNVERIFIED_MODULE_LOADER_ESCAPE'
  ],
  [
    'default-pattern-loader',
    'const {value:alias=require}=unknown;export {alias}',
    'UNVERIFIED_MODULE_LOADER_ESCAPE'
  ],
  [
    'conditional-loader',
    'const alias=flag?require:unknown;export {alias}',
    'UNVERIFIED_MODULE_LOADER_ESCAPE'
  ],
  [
    'logical-process-join',
    'let alias;alias ||= process;export {alias}',
    'UNVERIFIED_MODULE_LOADER_ESCAPE'
  ]
)
neutral.push(
  [
    'ambient-declaration-only',
    'declare const Function:string;export type Label=typeof Function',
    'mts'
  ],
  [
    'cjs-nested-var-shadow',
    'function describe(){var require="label";return require}',
    'cts'
  ]
)
unknown.push(
  [
    'ambient-does-not-shadow-global',
    'declare function Function(value:string):string;export const capability=Function',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'ambient-variable-keeps-global',
    'declare const eval:string;export const capability=eval',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'type-import-keeps-global',
    'import type {Worker as Function} from "node:worker_threads";export const capability=Function',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'type-loader-import-keeps-global',
    'import type {builtinModules as require} from "node:module";export const capability=require',
    'UNVERIFIED_MODULE_LOADER_ESCAPE'
  ],
  [
    'cjs-wrapper-var-require',
    'var require;export const capability=require',
    'UNVERIFIED_MODULE_LOADER_ESCAPE'
  ],
  [
    'cjs-wrapper-var-module',
    'var module;export const capability=module',
    'UNVERIFIED_MODULE_LOADER_ESCAPE'
  ],
  [
    'cjs-wrapper-var-filename-write',
    'import {createRequire} from "node:module";var __filename="unknown";const load=createRequire(__filename)',
    'UNVERIFIED_MODULE_LOADER_BASE'
  ]
)
neutral.push(
  [
    'bigint-own-constructor',
    'const data={constructor:42n};export const value=data.constructor',
    'mts'
  ],
  [
    'bigint-own-constructor-alias',
    'const scalar=42n;const data={constructor:scalar};export const value=data.constructor',
    'mts'
  ],
  [
    'parameter-outer-scalar',
    'const Function="outer";export function label(value=Function){function Function(){return "body"}return value}',
    'mts'
  ]
)
unknown.push(
  [
    'parameter-default-global-capability',
    'export function label(value=Function){function Function(){return "body"}return value}',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'parameter-default-imported-capability',
    'import {Worker} from "node:worker_threads";export function label(value=Worker){function Worker(){return "body"}return value}',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ],
  [
    'nested-parameter-default-global',
    'export function label(value=(inner=Function)=>inner){function Function(){return "body"}return value}',
    'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
  ]
)
describe('C1 lexical precision, exclusively static source evidence', () => {
  it.each(neutral)('accepts neutral syntax: %s', (id, text, extension) => {
    const audit = inspect(id, text, extension)
    expect(audit.diagnostics, id).toEqual([])
    expect(audit.violations, id).toEqual([])
    expect(audit.status).toBe('PASS')
    expect(audit.passed).toBe(true)
  })
  it.each(unknown)('preserves uncertainty: %s', (id, text, reason) => {
    const audit = inspect(
      id,
      text,
      id.startsWith('dts-') ? 'd.ts' : id.startsWith('cjs-') ? 'cts' : 'mts'
    )
    expect(audit.status).toBe('INCOMPLETE')
    expect(audit.passed).toBe(false)
    expect(
      audit.diagnostics.some((item) => item.reason === reason),
      id
    ).toBe(true)
  })
  it('separates the neutral outer parameter initializer from body declarations', () => {
    const source = ts.createSourceFile(
      '/inert/parameter-environment.mts',
      'const token="outer";export function label(value=token){function token(){return "body"}return token}',
      ts.ScriptTarget.Latest,
      true
    )
    const lexical = createBoundaryLexical(ts, source)
    const identifiers = []
    const visit = (node) => {
      if (ts.isIdentifier(node) && node.text === 'token') identifiers.push(node)
      ts.forEachChild(node, visit)
    }
    visit(source)
    const outer = identifiers.find((node) =>
      ts.isVariableDeclaration(node.parent)
    )
    const initializer = identifiers.find((node) => ts.isParameter(node.parent))
    const body = identifiers.find((node) =>
      ts.isFunctionDeclaration(node.parent)
    )
    const returned = identifiers.find((node) =>
      ts.isReturnStatement(node.parent)
    )
    expect(lexical.identity(initializer)).toBe(lexical.identity(outer))
    expect(lexical.identity(returned)).toBe(lexical.identity(body))
    expect(lexical.identity(initializer)).not.toBe(lexical.identity(body))
  })
  it('binds declaration identities, local exports, hoisting and value/type namespaces', () => {
    const text =
      'import {Worker as handle} from "node:worker_threads";function describe(handle:string){return handle};export {handle as Function};function other(){return handle;var handle="label"};type Function={label:string};const value=Function;const data={handle};'
    const source = ts.createSourceFile(
      '/inert/identity.mts',
      text,
      ts.ScriptTarget.Latest,
      true
    )
    const lexical = createBoundaryLexical(ts, source)
    const ids = []
    const visit = (node) => {
      if (ts.isIdentifier(node) && ['handle', 'Function'].includes(node.text))
        ids.push(node)
      ts.forEachChild(node, visit)
    }
    visit(source)
    const imported = ids.find(
      (node) => node.text === 'handle' && ts.isImportSpecifier(node.parent)
    )
    const parameter = ids.find((node) => ts.isParameter(node.parent))
    const returns = ids.filter((node) => ts.isReturnStatement(node.parent))
    const hoisted = ids.find((node) => ts.isVariableDeclaration(node.parent))
    const exported = ids.find(
      (node) => node.text === 'handle' && ts.isExportSpecifier(node.parent)
    )
    const globalUse = ids.find(
      (node) =>
        node.text === 'Function' && ts.isVariableDeclaration(node.parent)
    )
    const shorthand = ids.find((node) =>
      ts.isShorthandPropertyAssignment(node.parent)
    )
    expect(lexical.identity(parameter)).not.toBe(lexical.identity(imported))
    expect(lexical.identity(returns[0])).toBe(lexical.identity(parameter))
    expect(lexical.identity(returns[1])).toBe(lexical.identity(hoisted))
    expect(lexical.identity(exported)).toBe(lexical.identity(imported))
    expect(lexical.identity(shorthand)).toBe(lexical.identity(imported))
    expect(lexical.identity(globalUse)).toBe(lexical.global('Function'))
  })
})

describe('inert parameter/body environments', () => {
  const cases = [
    [
      'default-var',
      'function f(token="param",value=()=>token){var token="body";return token}',
      true
    ],
    [
      'default-function',
      'function f(token="param",value=()=>token){function token(){}return token}',
      true
    ],
    [
      'destructuring-var',
      'function f({token},value=()=>token){var token="body";return token}',
      true
    ],
    ['simple-var', 'function f(token){var token;return token}', false]
  ]
  for (const [label, text, separate] of cases)
    for (const ext of ['mjs', 'mts'])
      it(label + ':' + ext, () => {
        const source = ts.createSourceFile(
          '/inert/' + label + '.' + ext,
          text,
          ts.ScriptTarget.Latest,
          true
        )
        expect(source.parseDiagnostics).toEqual([])
        const lexical = createBoundaryLexical(ts, source)
        const ids = []
        const visit = (n) => {
          if (ts.isIdentifier(n) && n.text === 'token') ids.push(n)
          ts.forEachChild(n, visit)
        }
        visit(source)
        const param = ids[0]
        const body = ids.find(
          (n) =>
            ts.isVariableDeclaration(n.parent) ||
            ts.isFunctionDeclaration(n.parent)
        )
        const returned = ids.find((n) => ts.isReturnStatement(n.parent))
        expect(lexical.identity(returned)).toBe(lexical.identity(body))
        if (separate) {
          expect(lexical.identity(param)).not.toBe(lexical.identity(body))
          expect(
            lexical
              .identity(param)
              .declarations.every(
                (d) => ts.isParameter(d) || ts.isBindingElement(d)
              )
          ).toBe(true)
          if (ts.isVariableDeclaration(body.parent)) {
            const transfer = lexical.initialTransfers.find(
              ([target]) => target === body
            )
            expect(transfer?.[1]).toBe(param)
          } else expect(lexical.initialTransfers).toEqual([])
          const closure = ids.find((n) => ts.isArrowFunction(n.parent))
          expect(lexical.identity(closure)).toBe(lexical.identity(param))
        } else expect(lexical.identity(param)).toBe(lexical.identity(body))
      })
})

// R4 additions: neutral AST text and symbolic labels only; no fixture execution.
describe('R4 binding ownership and initialization, inert AST evidence', () => {
  const proofs = []
  const cases = [
    [
      'body-array',
      'function f([token="parameter"],value=()=>token){var [token]=["body"];return token}',
      [0, 0, 1, 1],
      1
    ],
    [
      'body-object',
      'function f({token="parameter"},value=()=>token){var {token}={token:"body"};return token}',
      [0, 0, 1, 1],
      1
    ],
    [
      'body-computed',
      'const key="label";function f({token="parameter"},value=()=>token){var {[key]:token}={label:"body"};return token}',
      [0, 0, 1, 1],
      1
    ],
    [
      'body-nested-array',
      'function f([token="parameter"],value=()=>token){var [[token]]=[["body"]];return token}',
      [0, 0, 1, 1],
      1
    ],
    [
      'body-nested-object',
      'function f({token="parameter"},value=()=>token){var {data:{token}}={data:{token:"body"}};return token}',
      [0, 0, 1, 1],
      1
    ],
    [
      'catch-only',
      'function f(token="parameter"){try{}catch(token){read(token)}return token}',
      [0, 1, 1, 0],
      0
    ],
    [
      'catch-with-var',
      'function f(token="parameter"){var token;try{}catch(token){read(token)}return token}',
      [0, 1, 2, 2, 1],
      1
    ],
    [
      'catch-destructured',
      'function f(token="parameter"){try{}catch({token}){read(token)}return token}',
      [0, 1, 1, 0],
      0
    ],
    [
      'simple-function',
      'function f(token){function token(){}return token}',
      [0, 0, 0],
      0,
      true
    ],
    [
      'simple-var-function',
      'function f(token){var token;function token(){}return token}',
      [0, 0, 0, 0],
      0,
      true
    ],
    [
      'simple-function-var',
      'function f(token){function token(){}var token;return token}',
      [0, 0, 0, 0],
      0,
      true
    ],
    [
      'simple-last-function',
      'function f(token){function token(){return "first"}var token;function token(){return "last"}return token}',
      [0, 0, 0, 0, 0],
      0,
      true
    ],
    [
      'default-var-function',
      'function f(token="parameter",value=()=>token){var token;function token(){}return token}',
      [0, 0, 1, 1, 1],
      0,
      true
    ],
    [
      'default-function-var',
      'function f(token="parameter",value=()=>token){function token(){}var token;return token}',
      [0, 0, 1, 1, 1],
      0,
      true
    ],
    [
      'simple-rest-sharing',
      'function f(...token){var [token]=["body"];return token}',
      [0, 0, 0],
      0
    ],
    [
      'simple-pattern-sharing',
      'function f({token}){var {token}={token:"body"};return token}',
      [0, 0, 0],
      0
    ],
    [
      'nested-default',
      'function f({data:{token="parameter"}},value=()=>token){var {token}={token:"body"};return token}',
      [0, 0, 1, 1],
      1
    ],
    [
      'runtime-computed-param',
      'const key="label";function f({[key]:token}){var [token]=["body"];return token}',
      [0, 1, 1],
      1
    ],
    [
      'block-let',
      'function f(token="parameter",value=()=>token){var [token]=["body"];{let token="block";read(token)}return token}',
      [0, 0, 1, 2, 2, 1],
      1
    ],
    [
      'block-function',
      'function f(token="parameter"){var [token]=["body"];{function token(){}read(token)}return token}',
      [0, 1, 2, 2, 1],
      1
    ],
    [
      'nested-closure',
      'function f(token="parameter",value=()=>token){var [token]=["body"];return ()=>token}',
      [0, 0, 1, 1],
      1
    ],
    [
      'nested-shadow',
      'function f(token="parameter",value=()=>token){var [token]=["body"];function g(token){return token}return token}',
      [0, 0, 1, 2, 2, 1],
      1
    ],
    [
      'outer-default',
      'const token="outer";function f(value=()=>token){var [token]=["body"];return token}',
      [0, 0, 1, 1],
      0
    ],
    [
      'nested-parameter-environment',
      'function f(token="outer"){var [token]=["body"];function g(token="inner",value=()=>token){var {token}={token:"inner-body"};return token}return token}',
      [0, 1, 2, 2, 3, 3, 1],
      2
    ]
  ]
  const typed = [
    [
      'erased-computed-type',
      'function f(token:{["label"]:string}){var token;return token}',
      [0, 0, 0],
      0
    ],
    [
      'erased-nested-type',
      'function f(token:Array<{["label"]:string}>){var token;return token}',
      [0, 0, 0],
      0
    ],
    [
      'erased-type-query',
      'const key="label";function f(token:{[key]:string}){var token;return token}',
      [0, 0, 0],
      0
    ],
    [
      'typed-simple-function',
      'function f(token:{["label"]:string}){function token(){}return token}',
      [0, 0, 0],
      0,
      true
    ],
    [
      'typed-runtime-default',
      'function f(token:{["label"]:string}={label:"parameter"}){var [token]=["body"];return token}',
      [0, 1, 1],
      1
    ],
    [
      'typed-nested-pattern',
      'function f({token}:{token:{["label"]:string}}){var {token}={token:"body"};return token}',
      [0, 0, 0],
      0
    ]
  ]
  const variants = cases
    .flatMap((item) => ['mjs', 'mts'].map((ext) => [ext, ...item]))
    .concat(typed.map((item) => ['mts', ...item]))
  it.each(variants)(
    '%s: %s',
    (ext, id, text, groups, transfers, functionWins = false) => {
      const source = ts.createSourceFile(
        '/inert/r4-' + id + '.' + ext,
        text,
        ts.ScriptTarget.Latest,
        true
      )
      expect(source.parseDiagnostics).toEqual([])
      const lexical = createBoundaryLexical(ts, source)
      const ids = [],
        functions = []
      const visit = (node) => {
        if (
          ts.isIdentifier(node) &&
          node.text === 'token' &&
          !lexical.erased(node) &&
          !(ts.isPropertyAssignment(node.parent) && node.parent.name === node)
        )
          ids.push(node)
        if (ts.isFunctionDeclaration(node) && node.name?.text === 'token')
          functions.push(node)
        ts.forEachChild(node, visit)
      }
      visit(source)
      const keys = ids.map(lexical.identity)
      const cells = [...new Set(keys)]
      const actual = keys.map((key) => cells.indexOf(key))
      const edges = lexical.initialTransfers.map(([target, parameter]) => [
        lexical.identity(target),
        lexical.identity(parameter)
      ])
      const labels = new Map(cells.map((key) => [key, new Set()]))
      for (const [target, parameter] of edges) {
        labels.get(parameter).add('parameter-initial-label')
        for (const label of labels.get(parameter)) labels.get(target).add(label)
        labels.get(target).add('body-write-label')
      }
      proofs.push({
        id,
        ext,
        text,
        fixturesExecuted: false,
        parseErrors: source.parseDiagnostics.length,
        expected: groups,
        actual,
        expectedTransfers: transfers,
        edges: edges.map(([target, parameter]) => ({
          target: cells.indexOf(target),
          parameter: cells.indexOf(parameter),
          selfEdge: target === parameter
        })),
        declarations: cells.map((key) =>
          key.declarations?.map((d) => ({
            kind: ts.SyntaxKind[d.kind],
            start: d.getStart(source)
          }))
        ),
        symbolicLabels: cells.map((key) => [...labels.get(key)]),
        functionInitialization: cells.map(
          (key) => key.initialFunction?.getStart(source) ?? null
        )
      })
      fs.writeFileSync(
        path.join(tmpdir(), 'r4-neutral-proofs.json'),
        JSON.stringify(proofs, null, 2) + '\n'
      )
      expect(actual, id).toEqual(groups)
      expect(edges.length, id).toBe(transfers)
      for (const [target, parameter] of edges) {
        expect(target).not.toBe(parameter)
        expect(labels.get(parameter).has('body-write-label')).toBe(false)
        expect(labels.get(target).has('parameter-initial-label')).toBe(true)
        expect(
          target.declarations.every(
            (d) => !ts.isParameter(d) && !ts.isCatchClause(d.parent)
          )
        ).toBe(true)
      }
      if (functionWins) {
        const effective = lexical.identity(functions.at(-1).name)
        expect(effective.initialFunction).toBe(functions.at(-1))
        expect(effective.declarations).toContain(functions.at(-1))
      }
    }
  )
})

describe('R4 directed initial copies in both capability fixed points', () => {
  it.each([
    ['check-product-boundary.mjs', 'bind', 'parameter'],
    ['boundary-code-execution.mjs', 'record', 'classify(parameter)']
  ])('%s copies parameter values to body identities', (file, callee, value) => {
    const source = ts.createSourceFile(
      file,
      fs.readFileSync(new URL('../scripts/' + file, import.meta.url), 'utf8'),
      ts.ScriptTarget.Latest,
      true
    )
    const loops = []
    const visit = (node) => {
      if (
        ts.isForOfStatement(node) &&
        node.expression.getText(source) === 'lexical.initialTransfers'
      )
        loops.push(node)
      ts.forEachChild(node, visit)
    }
    visit(source)
    expect(loops).toHaveLength(1)
    const loop = loops[0]
    expect(loop.initializer.getText(source)).toBe('const [body, parameter]')
    const call = loop.statement.expression
    expect(call.expression.getText(source)).toBe(callee)
    expect(call.arguments.map((node) => node.getText(source))).toEqual([
      'identity(body)',
      value
    ])
    let ancestor = loop.parent
    while (ancestor && !ts.isWhileStatement(ancestor))
      ancestor = ancestor.parent
    expect(ancestor?.expression.getText(source)).toBe('changed')
    // The inspected AST fixes direction; this symbolic algebra never evaluates
    // fixture text, and does not claim actual capability integration coverage.
    const parameter = {},
      body = {},
      labels = new Map([
        [parameter, new Set(['initial-label'])],
        [body, new Set()]
      ])
    for (const label of labels.get(parameter)) labels.get(body).add(label)
    labels.get(body).add('body-write-label')
    expect([...labels.get(parameter)]).toEqual(['initial-label'])
    expect([...labels.get(body)]).toEqual(['initial-label', 'body-write-label'])
  })
})

// R5: neutral AST and symbolic labels only; no fixture is executed.
import { assignedValues, valueBranches } from '../scripts/boundary-lexical.mjs'
import { auditDynamicCodeExecution } from '../scripts/boundary-code-execution.mjs'
describe('R5 catch initializer write ownership', () => {
  const fixtures = [
    [
      'optional-catch',
      'const seed="label";function f(token="parameter"){try{}catch{var token=seed;read(token)}return token}',
      true,
      true
    ],
    [
      'nested-optional-catch',
      'const seed="label";function f(token="parameter"){try{}catch(token){try{}catch{var token=seed;read(token)}}return token}',
      true,
      false
    ],
    [
      'separated',
      'const seed="label";function f(token="parameter"){try{}catch(token){var token=seed;read(token)}return token}',
      true,
      false
    ],
    [
      'shared',
      'const seed="label";function f(token){try{}catch(token){var token=seed;read(token)}return token}',
      true,
      false
    ],
    [
      'no-param',
      'const seed="label";function f(value="parameter"){try{}catch(token){var token=seed;read(token)}return token}',
      true,
      false
    ],
    [
      'control',
      'const seed="label";function f(token="parameter"){var token=seed;read(token);return token}',
      true,
      true
    ],
    [
      'no-return',
      'const seed="label";function f(token="parameter"){try{}catch(token){var token=seed;read(token)}}',
      true,
      null
    ],
    [
      'different-catch',
      'const seed="label";function f(token="parameter"){try{}catch(other){var token=seed;read(token)}return token}',
      true,
      true
    ],
    [
      'outer-catch',
      'const seed="label";function f(token="parameter"){try{}catch(token){try{}catch(other){var token=seed;read(token)}}return token}',
      true,
      false
    ],
    [
      'nested-function',
      'const seed="label";function f(token="parameter"){try{}catch(token){function inner(){var token=seed;read(token);return token}}}',
      true,
      true
    ],
    [
      'block-let',
      'const seed="label";function f(token="parameter"){try{}catch(other){let token=seed;read(token)}return token}',
      true,
      false
    ]
  ]
  for (const extension of ['mjs', 'mts'])
    it.each(fixtures)(
      '%s resolves only the actual write cell (' + extension + ')',
      (id, text, expectedRead, expectedReturn) => {
        const source = ts.createSourceFile(
          'inert.' + extension,
          text,
          ts.ScriptTarget.Latest,
          true
        )
        expect(source.parseDiagnostics).toHaveLength(0)
        const lexical = createBoundaryLexical(ts, source),
          nodes = []
        const visit = (node) => {
          nodes.push(node)
          ts.forEachChild(node, visit)
        }
        visit(source)
        const seed = nodes.find(
          (n) =>
            ts.isVariableDeclaration(n) && n.name.getText(source) === 'seed'
        ).name
        const labels = new Set([lexical.identity(seed)])
        const literal = (n) =>
          n && ts.isStringLiteralLike(n) ? n.text : undefined
        const match = (n) =>
          ts.isIdentifier(n) && labels.has(lexical.identity(n))
        const write = lexical.writeIdentity ?? lexical.identity
        let changed = true
        while (changed) {
          changed = false
          const bind = (key, value) => {
            if (valueBranches(ts, value).some(match) && !labels.has(key)) {
              labels.add(key)
              changed = true
            }
          }
          for (const [body, parameter] of lexical.initialTransfers)
            bind(lexical.identity(body), parameter)
          for (const node of nodes.filter((n) => !lexical.erased(n))) {
            if (
              (ts.isVariableDeclaration(node) || ts.isParameter(node)) &&
              node.initializer
            )
              assignedValues(
                ts,
                node.name,
                node.initializer,
                literal,
                (name, value) => bind(write(name), value)
              )
            if (
              ts.isBinaryExpression(node) &&
              node.operatorToken.kind >= ts.SyntaxKind.FirstAssignment &&
              node.operatorToken.kind <= ts.SyntaxKind.LastAssignment
            )
              assignedValues(
                ts,
                node.left,
                node.right,
                literal,
                (name, value) => bind(lexical.identity(name), value)
              )
          }
        }
        const read = nodes.find(
          (n) =>
            ts.isIdentifier(n) &&
            n.text === 'token' &&
            ts.isCallExpression(n.parent)
        )
        const returned = nodes.find(
          (n) =>
            ts.isIdentifier(n) &&
            n.text === 'token' &&
            ts.isReturnStatement(n.parent)
        )
        expect(labels.has(lexical.identity(read))).toBe(expectedRead)
        if (expectedReturn !== null)
          expect(labels.has(lexical.identity(returned))).toBe(expectedReturn)
        const diagnostics = []
        const injected = {
          ...lexical,
          global: (name) =>
            name === 'Function' ? lexical.identity(seed) : lexical.global(name)
        }
        auditDynamicCodeExecution({
          ts,
          source,
          lexical: injected,
          runtimeNodes: nodes.filter((n) => !lexical.erased(n)),
          typeOnly: lexical.erased,
          literal,
          isLoader: () => false,
          isBuiltinGetter: () => false,
          isGlobal: () => false,
          isDeclarationName: lexical.isDeclarationName,
          loaderDiagnostic: (node, reason) =>
            diagnostics.push({ start: node.getStart(source), reason })
        })
        expect(diagnostics.some((d) => d.start === read.getStart(source))).toBe(
          expectedRead
        )
        if (expectedReturn !== null)
          expect(
            diagnostics.some((d) => d.start === returned.getStart(source))
          ).toBe(expectedReturn)
      }
    )
  it.each(['check-product-boundary.mjs', 'boundary-code-execution.mjs'])(
    '%s uses write identity for initialized declarations',
    (file) => {
      const text = fs.readFileSync(
        new URL('../scripts/' + file, import.meta.url),
        'utf8'
      )
      expect(text).toContain('writeIdentity(name)')
      expect(text).toContain('identity(body)')
    }
  )
})

// R6: static blocks and erased TS wrappers, all fixtures remain inert text.
describe('R6 static block and transparent value wrappers', () => {
  const fixtures = [
    [
      'static-local',
      'const seed="label";try{}catch(token){class C{static{var token=seed;read(token)}}}'
    ],
    [
      'static-optional',
      'const seed="label";try{}catch(token){class C{static{try{}catch{var token=seed;read(token)}}}}'
    ],
    [
      'static-inner-catch',
      'const seed="label";try{}catch(token){class C{static{try{}catch(token){var token=seed;read(token)}}}}'
    ],
    [
      'static-object-default',
      'const seed="label";try{}catch(token){class C{static{var {token=seed}={};read(token)}}}'
    ],
    [
      'static-array-default',
      'const seed="label";try{}catch(token){class C{static{var [token=seed]=[];read(token)}}}'
    ],
    [
      'method-control',
      'const seed="label";try{}catch(token){class C{static m(){var token=seed;read(token)}}}'
    ],
    [
      'satisfies-alias',
      'const seed="label";const token=seed satisfies unknown;read(token)'
    ],
    [
      'satisfies-nested',
      'const seed="label";const token=((seed satisfies unknown) as unknown);read(token)'
    ],
    [
      'satisfies-default',
      'const seed="label";const {token=(seed satisfies unknown)}={};read(token)'
    ]
  ]
  it.each(fixtures)('%s preserves neutral symbolic flow', (id, text) => {
    const source = ts.createSourceFile(
      'inert.mts',
      text,
      ts.ScriptTarget.Latest,
      true
    )
    expect(source.parseDiagnostics).toHaveLength(0)
    const lexical = createBoundaryLexical(ts, source),
      nodes = []
    const visit = (node) => {
      nodes.push(node)
      ts.forEachChild(node, visit)
    }
    visit(source)
    const seed = nodes.find(
      (n) => ts.isVariableDeclaration(n) && n.name.getText(source) === 'seed'
    ).name
    const seedKey = lexical.identity(seed),
      labels = new Set([seedKey])
    const literal = (n) => (n && ts.isStringLiteralLike(n) ? n.text : undefined)
    const match = (n) => ts.isIdentifier(n) && labels.has(lexical.identity(n))
    let changed = true
    while (changed) {
      changed = false
      const bind = (key, value) => {
        if (valueBranches(ts, value).some(match) && !labels.has(key)) {
          labels.add(key)
          changed = true
        }
      }
      for (const [body, parameter] of lexical.initialTransfers)
        bind(lexical.identity(body), parameter)
      for (const node of nodes.filter((n) => !lexical.erased(n))) {
        if (
          (ts.isVariableDeclaration(node) || ts.isParameter(node)) &&
          node.initializer
        )
          assignedValues(
            ts,
            node.name,
            node.initializer,
            literal,
            (name, value) => bind(lexical.writeIdentity(name), value)
          )
      }
    }
    const read = nodes.find(
      (n) =>
        ts.isIdentifier(n) &&
        n.text === 'token' &&
        ts.isCallExpression(n.parent)
    )
    expect(labels.has(lexical.identity(read)), id).toBe(true)
    const diagnostics = []
    auditDynamicCodeExecution({
      ts,
      source,
      lexical: {
        ...lexical,
        global: (name) => (name === 'Function' ? seedKey : lexical.global(name))
      },
      runtimeNodes: nodes.filter((n) => !lexical.erased(n)),
      typeOnly: lexical.erased,
      literal,
      isLoader: () => false,
      isBuiltinGetter: () => false,
      isGlobal: () => false,
      isDeclarationName: lexical.isDeclarationName,
      loaderDiagnostic: (node) => diagnostics.push(node.getStart(source))
    })
    expect(diagnostics.includes(read.getStart(source)), id).toBe(true)
  })
  it.each([
    [
      'scalar-cast',
      'const obj={constructor:"label"};(obj as object).constructor',
      'PASS'
    ],
    [
      'scalar-satisfies',
      'const obj={constructor:"label"};(obj satisfies object).constructor',
      'PASS'
    ],
    [
      'inline-satisfies',
      '({constructor:"label"} satisfies object).constructor',
      'PASS'
    ],
    [
      'scalar-wrapped',
      'const obj={constructor:"label"};((obj as object)!).constructor',
      'PASS'
    ],
    [
      'wrapped-alias',
      'const obj={constructor:"label"};const alias=obj as object;alias.constructor',
      'INCOMPLETE'
    ],
    [
      'wrapped-call',
      'const obj={constructor:"label"};consume(obj as object);obj.constructor',
      'INCOMPLETE'
    ],
    [
      'wrapped-mutation',
      'const obj={constructor:"label"};(obj as any).constructor=other;obj.constructor',
      'INCOMPLETE'
    ],
    [
      'satisfies-mutation',
      'const obj={constructor:"label"};(obj satisfies object).constructor=other;obj.constructor',
      'INCOMPLETE'
    ],
    [
      'wrapped-getter',
      'const obj={get constructor(){return "label"}};(obj as object).constructor',
      'INCOMPLETE'
    ],
    [
      'wrapped-spread',
      'const obj={...other,constructor:"label"};(obj as object).constructor',
      'INCOMPLETE'
    ],
    [
      'wrapped-export',
      'export const obj={constructor:"label"};(obj as object).constructor',
      'INCOMPLETE'
    ]
  ])('%s keeps scalar proof without admitting escapes', (id, text, status) => {
    expect(inspect('r6-' + id, text, 'mts').status, id).toBe(status)
  })
})

describe('R7 erased write wrappers and static CJS ownership', () => {
  const wrappers = [
    ['as', (value) => `(${value} as any)`],
    ['satisfies', (value) => `(${value} satisfies unknown)`],
    ['non-null', (value) => `(${value}!)`],
    ['assertion', (value) => `(<unknown>${value})`]
  ]
  it.each(
    wrappers.flatMap(([name, wrap]) => [
      [name + '-assignment', `${wrap('obj.constructor')}=replacement`],
      [name + '-array-pattern', `[${wrap('obj.constructor')}]=[replacement]`],
      [
        name + '-object-pattern',
        `({value:${wrap('obj.constructor')}}={value:replacement})`
      ],
      [name + '-compound', `${wrap('obj.constructor')}+=replacement`],
      [name + '-update', `${wrap('obj.constructor')}++`],
      [name + '-for-of', `for(${wrap('obj.constructor')} of [replacement]){}`]
    ])
  )('%s invalidates scalar object proof', (id, mutation) => {
    const text = `declare const replacement:unknown;const obj={constructor:"label"};${mutation};obj.constructor`
    expect(inspect('r7-' + id, text, 'mts').status, id).toBe('INCOMPLETE')
  })
  it.each(
    wrappers.flatMap(([name, wrap]) => [
      [
        name + '-read',
        `const obj={constructor:"label"};${wrap('obj.constructor')}`
      ],
      [
        name + '-pattern-read',
        `const obj={constructor:"label"};const {constructor:value}=${wrap('obj')};value`
      ]
    ])
  )('%s preserves scalar reads', (id, text) => {
    expect(inspect('r7-' + id, text, 'mts').status, id).toBe('PASS')
  })
  it.each(
    ['require', 'module', 'exports', '__filename', '__dirname'].flatMap(
      (name) => ['cjs', 'mjs'].map((extension) => [name, extension])
    )
  )('%s in %s static block has own cell', (name, extension) => {
    const source = ts.createSourceFile(
      `entry.${extension}`,
      `class C{static{var ${name}="label";read(${name})}}observe(${name})`,
      ts.ScriptTarget.Latest,
      true
    )
    expect(source.parseDiagnostics).toEqual([])
    const lexical = createBoundaryLexical(ts, source, extension === 'cjs')
    const nodes = []
    const visit = (node) => {
      if (ts.isIdentifier(node) && node.text === name) nodes.push(node)
      ts.forEachChild(node, visit)
    }
    visit(source)
    expect(nodes).toHaveLength(3)
    expect(lexical.identity(nodes[0])).toBe(lexical.identity(nodes[1]))
    expect(lexical.identity(nodes[1])).not.toBe(lexical.identity(nodes[2]))
    expect(lexical.identity(nodes[1])).not.toBe(lexical.global(name))
  })
  it.each(['cjs', 'mjs'])('%s static module scalar is safe', (extension) => {
    expect(
      inspect(
        'r7-static-module-' + extension,
        'class C{static{var module="label";read(module)}}',
        extension
      ).status
    ).toBe('PASS')
  })
})

describe('R8 selected bindings, receiver stability and reached diagnostics', () => {
  const wrappers = [
    ['plain', (v) => v],
    ['paren', (v) => `(${v})`],
    ['as', (v) => `(${v} as any)`],
    ['satisfies', (v) => `(${v} satisfies unknown)`],
    ['non-null', (v) => `(${v}!)`],
    ['assertion', (v) => `(<unknown>${v})`],
    ['nested', (v) => `(((${v} as any)!) satisfies unknown)`]
  ]
  it.each(
    wrappers.flatMap(([name, wrap]) => [
      [
        name + '-selected',
        `declare const record:{constructor:unknown};let token;({constructor:${wrap('token')}}=record);export {token};`
      ],
      [
        name + '-selected-nested',
        `declare const record:{data:{constructor:unknown}};let token;({data:{constructor:${wrap('token')}}}=record);export {token};`
      ],
      [
        name + '-selected-default',
        `declare const record:{constructor:unknown};let token;({constructor:${wrap('token')}="label"}=record);export {token};`
      ],
      [
        name + '-selected-param',
        `export function collect(record:{constructor:unknown}){let token;({constructor:${wrap('token')}}=record);return token;}`
      ]
    ])
  )('%s keeps unknown selected constructor', (id, text) => {
    expect(inspect('r8-' + id, text).status, id).toBe('INCOMPLETE')
  })
  it.each(
    wrappers.flatMap(([name, wrap]) => [
      [
        name + '-method-call',
        `export function read(method:any){const obj={constructor:"label",method};${wrap('obj.method')}();return obj.constructor;}`
      ],
      [
        name + '-method-tag',
        `export function read(method:any){const obj={constructor:"label",method};${wrap('obj.method')}\`label\`;return obj.constructor;}`
      ],
      [
        name + '-method-new',
        `export function read(method:any){const obj={constructor:"label",method};new ${wrap('obj.method')}();return obj.constructor;}`
      ]
    ])
  )('%s invalidates receiver scalar proof', (id, text) => {
    expect(inspect('r8-' + id, text).status, id).toBe('INCOMPLETE')
  })
  it.each(
    ['require', 'module', 'exports', '__filename', '__dirname'].flatMap(
      (name) => ['cjs', 'cts', 'mjs', 'mts'].map((ext) => [name, ext])
    )
  )('%s pattern var in %s preserves wrapper cell', (name, ext) => {
    const source = ts.createSourceFile(
      `entry.${ext}`,
      `var {value:${name}}={value:"label"};read(${name})`,
      ts.ScriptTarget.Latest,
      true
    )
    expect(source.parseDiagnostics).toEqual([])
    const commonJs = ['cjs', 'cts'].includes(ext)
    const lexical = createBoundaryLexical(ts, source, commonJs)
    const nodes = []
    const visit = (node) => {
      if (ts.isIdentifier(node) && node.text === name) nodes.push(node)
      ts.forEachChild(node, visit)
    }
    visit(source)
    expect(nodes).toHaveLength(2)
    expect(lexical.identity(nodes[0])).toBe(lexical.identity(nodes[1]))
    if (commonJs) expect(lexical.identity(nodes[1])).toBe(lexical.global(name))
    else expect(lexical.identity(nodes[1])).not.toBe(lexical.global(name))
  })
  it.each(['require', 'module', 'exports', '__filename', '__dirname'])(
    '%s catch binding stays separate in CJS',
    (name) => {
      const source = ts.createSourceFile(
        'entry.cjs',
        `try{}catch(${name}){read(${name})}observe(${name})`,
        ts.ScriptTarget.Latest,
        true
      )
      expect(source.parseDiagnostics).toEqual([])
      const lexical = createBoundaryLexical(ts, source, true)
      const nodes = []
      const visit = (node) => {
        if (ts.isIdentifier(node) && node.text === name) nodes.push(node)
        ts.forEachChild(node, visit)
      }
      visit(source)
      expect(nodes).toHaveLength(3)
      expect(lexical.identity(nodes[0])).toBe(lexical.identity(nodes[1]))
      expect(lexical.identity(nodes[1])).not.toBe(lexical.global(name))
      expect(lexical.identity(nodes[2])).toBe(lexical.global(name))
    }
  )
  it.each(['cjs', 'cts'])(
    '%s module pattern var retains conservative wrapper policy',
    (ext) => {
      expect(
        inspect(
          'r8-module-pattern-' + ext,
          'var {value:module}={value:"label"};read(module)',
          ext
        ).status
      ).toBe('INCOMPLETE')
    }
  )
  function reached(
    id,
    {
      core = 'export const label="synthetic";',
      dependency,
      legacy = 'export const value=opaque.constructor;',
      product = 'export const value=opaque.constructor;',
      vendor = false
    } = {}
  ) {
    const root = path.join(output, 'reached-fixtures', id)
    const put = (relative, text) => {
      const file = path.join(root, relative)
      fs.mkdirSync(path.dirname(file), { recursive: true })
      fs.writeFileSync(file, text)
    }
    for (const dir of [
      'packages/core/src',
      'apps',
      'legacy/packages/fixture/src',
      'products/consumer/src'
    ])
      fs.mkdirSync(path.join(root, dir), { recursive: true })
    put(
      'package.json',
      JSON.stringify({
        private: true,
        type: 'module',
        workspaces: ['packages/*', 'legacy/packages/*', 'products/*']
      })
    )
    put(
      'packages/core/package.json',
      JSON.stringify({
        name: '@synthetic/core',
        type: 'module',
        ...(dependency ? { dependencies: { [dependency]: '*' } } : {})
      })
    )
    put(
      'legacy/packages/fixture/package.json',
      JSON.stringify({ name: '@synthetic/legacy', type: 'module' })
    )
    put(
      'products/consumer/package.json',
      JSON.stringify({ name: '@synthetic/consumer', type: 'module' })
    )
    if (core !== null) put('packages/core/src/index.mjs', core)
    put('legacy/packages/fixture/src/index.mjs', legacy)
    put('products/consumer/src/index.mjs', product)
    if (vendor)
      put(
        'node_modules/neutral/index.mjs',
        'export const value=opaque.constructor;'
      )
    return auditProductBoundary(root)
  }
  it.each([
    ['unreachable-product-and-legacy', {}, 'PASS'],
    [
      'core-unknown',
      { core: 'export const value=opaque.constructor;' },
      'INCOMPLETE'
    ],
    ['empty-core', { core: null }, 'INCOMPLETE'],
    [
      'relative-legacy',
      { core: 'import "../../../legacy/packages/fixture/src/index.mjs";' },
      'INCOMPLETE'
    ],
    ['dependency-legacy', { dependency: '@synthetic/legacy' }, 'INCOMPLETE'],
    [
      'relative-product',
      { core: 'import "../../../products/consumer/src/index.mjs";' },
      'FAIL'
    ],
    ['dependency-product', { dependency: '@synthetic/consumer' }, 'FAIL'],
    ['core-missing-import', { core: 'import "./missing.mjs";' }, 'INCOMPLETE'],
    [
      'reachable-vendor',
      {
        core: 'import "../../../node_modules/neutral/index.mjs";',
        vendor: true
      },
      'INCOMPLETE'
    ],
    ['unreachable-vendor', { vendor: true }, 'PASS'],
    ['unreachable-parse-error', { product: 'const = ;' }, 'PASS']
  ])('%s diagnoses only effective core closure', (id, options, status) => {
    const result = reached('r8-' + id, options)
    expect(result.status, id).toBe(status)
    if (status === 'PASS') expect(result.diagnostics, id).toEqual([])
    if (status === 'FAIL')
      expect(
        result.violations.some((v) => v.reason === 'CORE_DEPENDS_ON_PRODUCT'),
        id
      ).toBe(true)
    if (status === 'INCOMPLETE')
      expect(result.diagnostics.length, id).toBeGreaterThan(0)
  })
})
