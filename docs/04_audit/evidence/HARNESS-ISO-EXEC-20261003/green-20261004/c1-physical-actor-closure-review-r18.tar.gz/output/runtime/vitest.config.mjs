export default {test:{include:["tests/product-boundary-lexical-static.test.js"],environment:"node",maxWorkers:1,minWorkers:1,fileParallelism:false,testTimeout:30000,hookTimeout:30000}};
