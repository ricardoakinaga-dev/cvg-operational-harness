# I1 · C1 · R18

**ACCEPT somente para soundness do gate dentro do escopo congelado.** Nenhum falso PASS foi reproduzido nos probes próprios. Unknowns instalados continuam bloqueantes; este resultado não concede aceite installed/global, isolamento geral do repositório ou produção.

## Autoridade e artefato

Authority e freeze foram os primeiros conteúdos lidos. O SHA-256 efetivo de frozen-inventory.json é 34d8249975d6ce29b7f87643437ef9d91ef9c15fed3ede38de65b44d0cd5f9d6, igual ao solicitado. Foram usados apenas artefatos do packet e Node22 v22.23.2. A constituição e as quatro SPEC/ADR autorizadas são os únicos documentos narrativos acessados; a regra específica da revisão substitui o fluxo geral de leitura/atualização de ledgers e claims. Outros documentos foram tratados como hashes opacos. Não foram usados julgamentos, relatórios ou códigos de saída anteriores como aceite.

Os cinco módulos físicos do checker, copiados sem alteração de bytes para runtime/scripts, foram inspecionados e submetidos a --check também em source. A cópia do arquivo static atual recebeu apenas a remoção do primeiro cleanup afterAll, para preservar evidência; assertions e checker não foram alterados. Runtime, helpers, caches, fixtures inertes e logs nasceram dentro de output. LICENSE/NOTICE/README e equivalentes de licença de dependências foram copiados/fingerprintados como bytes opacos, sem interpretação narrativa.

## Evidência independente

| Exercício atual | Resultado |
| --- | --- |
| API, probes próprios inertes | 100/100 expectativas satisfeitas |
| API direta do manifest reader: ciclos/releituras nos quatro campos | 4/4, estados incomplete preservados |
| CLI física atual | 5/5: PASS=0, FAIL/INCOMPLETE=1, erro de metadata=2 |
| Controles static fornecidos, native Vitest em runtime privado | 932/932, zero falhas e zero skips |
| Node22 --check dos módulos congelados | 5/5 |
| Testemunhas locais independentes: campo/valor e duas hashes | 12/12 válidas |

Os probes próprios cobrem dependencies, devDependencies, optionalDependencies e peerDependencies. Exercitam arestas workspace e instalação física simultâneas, file/link para produto, atores ativos e pais de workspaces fora dos quatro roots usuais, metadata recursiva em dist, instalações hoisted/nested, contexto JSONless, local ausente, symlinks lexicais com .. e segmentos codificados, dangling manifest e saída de root, ciclos válidos e ciclos com frontier desconhecida. Um input JS de sintaxe inválida permanece SOURCE_PARSE_ERROR; o probe lexical de parameter/body hoisting permanece bloqueante.

Probes com produto chegam a FAIL. Instalações desconhecidas neutras chegam a INCOMPLETE com UNVERIFIED_INSTALLED_DEPENDENCY. Contextos instalados fisicamente comprovados com local ausente preservam UNRESOLVED_INSTALLED_LOCAL_DEPENDENCY; a ausência da root manifest em JSONless não cria witness fictício. Repository local ausente, metadata inválida e symlink lexical recusam por erro.

## Inspeção de código

check-product-boundary.mjs:113–121 censusa atores ativos; :159–199 valida pais/workspaces; :228–297 acrescenta successors físicos sem substituir arestas declaradas; :302–326 governa metadata recursiva do contexto; :399–439 vincula source efetiva ao ator; :442–563 resolve runtime por helper confiável sem importar o target; :671–685 mantém falha de parser nativo bloqueante; :1542–1581 decide sobre a closure efetivamente alcançada pelo core. boundary-manifests.mjs separa shape, visiting/provisional/complete/incomplete/failed, verifica a grafia lexical de file/link antes da normalização, usa lookup Node do declaring actor e conserva hashes/proveniência no unresolved. Os probes de ciclo verificam esta separação no API público com releituras. As linhas citadas servem para localização, não como prova isolada.

## Integridade, traces e limites

A comparação antes/depois encontrou zero alterações e zero diferenças verificáveis contra o inventário. O snapshot inclui 21357 entradas, incluindo diretórios, modes, sizes, link targets e mtimes. A comparação exclui atime porque leituras autorizadas podem alterá-lo. 138 entradas tiveram bytes deliberadamente não lidos pelo guard (fixtures e arquivos environment); nelas, integridade usa metadata, sem afirmar igualdade criptográfica dos bytes. O original de 253 fixtures executáveis não foi lido, copiado ou executado; o teste code-execution original e o teste original de fronteira foram excluídos da leitura de conteúdo pelo guard. Nenhum payload dos 932 novos controles foi executado: só o runner/analisador confiável consumiu textos/AST/JSON.

api-read-trace.json registra chamadas fs instrumentadas do helper principal. trusted-child-trace.json registra --check e o resolver Node confiável; CLI e validações congeladas têm registros separados. opaque-reads-* e runtime-copy-trace.json registram fingerprints, sem conteúdo narrativo. review-access-trace.json registra a inspeção deliberada. Estes registros são finitos e não são enforcement de syscalls; não interceptam todas as leituras internas de Node, Vitest ou subprocessos. A prova de preservação de source é a comparação física, independente dessa limitação.

Não foi rodado gate global do frozen source, nem os 253 fixtures originais: essa revisão isolada não autoriza tais execuções. A matriz é finita, não uma prova formal de completude de JavaScript ou de sandbox de execução arbitrária. Falhas de testes/probes atuais: nenhuma; erros esperados de negativos foram preservados nos resultados e stderr da CLI.

## Reprodução e entrega

Para repetir uma CLI sem executar o conteúdo do fixture, use o Node aprovado com output/runtime/scripts/check-product-boundary.mjs e, como argumento, output/probes/neutral (exit 0), output/probes/direct-product-dependencies (exit 1), output/probes/installed-missing-dependencies (exit 1), output/probes/active-dist-invalid-dependencies (exit 2) ou output/probes/native-syntax-error (exit 1). Todos são diretórios físicos de dados inertes preservados. Os inputs e resultados completos estão nos respectivos arquivos JSON; stdout/stderr da CLI e logs da suíte permanecem em output.

manifest-seal.json sela os arquivos, diretórios e links de output, exceto ele próprio; não se tenta criar um hash recursivo do próprio selo. O resultado é local e circunscrito. O próximo responsável pode consumir esta evidência mantendo installed unknowns blocking e sem inferir release.
