'use strict';
const fs=require('node:fs'),crypto=require('node:crypto');
const base='/home/ricardo/.cache/cvg-harness-green-20261004/c1-existing-dynamic-frontier-audit-r1',out=base+'/output',root=base+'/source/';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const reads=[],writes=[];
function read(p){if(!p.startsWith(root)&&!p.startsWith(out+'/')&&!['authority.json','freeze.json','frozen-inventory.json','diagnostic-inputs.json'].some(n=>p===base+'/'+n))throw Error('read guard');if(!fs.lstatSync(p).isFile())throw Error('nonregular read');const b=fs.readFileSync(p);reads.push({path:p,sha256:sha(b),bytes:b.length});return b;}
function json(p){return JSON.parse(read(p));}
function save(n,x){if(n.includes('/')||n.includes('..'))throw Error('write guard');const p=out+'/'+n;fs.writeFileSync(p,JSON.stringify(x,null,2)+'\n');writes.push(p);}
const inv=json(base+'/frozen-inventory.json'),input=json(base+'/diagnostic-inputs.json'),freeze=json(base+'/freeze.json'),authority=json(base+'/authority.json');
const classification=json(out+'/family-classification.json'),summary=json(out+'/family-summary.json'),templates=json(out+'/recurring-helper-families.json'),evidence=json(out+'/source-evidence.json'),report=json(out+'/report.json'),regressions=json(out+'/required-inert-regressions.json'),comparison=json(out+'/inventory-comparison.json'),parsed=json(out+'/ast-line-candidates.json');
const checks=[];function assert(name,value){if(!value)throw Error('validation '+name);checks.push({name,result:'MATCH'});}
assert('literal inventory hash',sha(read(base+'/frozen-inventory.json'))===freeze.inventorySha256);
assert('all 1610 unique original identities preserved',input.diagnostics.length===1610&&Object.keys(classification.byOriginalOrdinal).length===1610&&new Set(input.diagnostics.map(d=>d.ordinal)).size===1610&&input.diagnostics.every(d=>Object.keys(d).every(k=>JSON.stringify(d[k])===JSON.stringify(classification.byOriginalOrdinal[d.ordinal][k]))));
const rows=Object.values(classification.byOriginalOrdinal),classified=rows.filter(d=>d.status==='FAMILY_CLASSIFIED');
assert('totals and all residual pending',classified.length===1406&&rows.filter(d=>d.status==='PENDING').length===204&&classified.every(d=>d.safetyDisposition==='UNVERIFIED')&&rows.every(d=>['FAMILY_CLASSIFIED','PENDING'].includes(d.status)));
assert('reported family denominator',summary.classifiedIdentityCounts.reduce((n,[,c])=>n+c,0)===1406&&JSON.stringify(report.counts)===JSON.stringify(classification.totals));
assert('267 source parsers without syntax errors',parsed.parseDiagnostics.length===267&&parsed.parseDiagnostics.every(d=>d.count===0));
assert('no source content or metadata difference',comparison.differences.length===0&&comparison.individualInventoryHashMatches===273&&comparison.individualDiagnosticSourceHashMatches===267);
const ts=require(out+'/trusted-typescript/lib/typescript.js');
for(const e of evidence.evidence){const b=read(root+e.path);assert('evidence SHA/span '+e.id,sha(b)===e.sourceSha256&&b.toString('utf8').slice(e.span.start,e.span.end)===e.text);}
for(const group of templates.templates){const expected=group.sites[0].helper==='__createBinding'?7:3;assert('per-site exact identity cardinality '+group.key,group.sites.every(s=>s.historicalOrdinals.length===expected&&s.historicalOrdinals.every(o=>classification.byOriginalOrdinal[o].path===s.path&&classification.byOriginalOrdinal[o].sourceSha256===s.sourceSha256))&&group.metadataIdentityCount===group.sites.reduce((n,s)=>n+s.historicalOrdinals.length,0));}
assert('exact templates totals',templates.templates.length===2&&templates.templates[0].physicalSites===67&&templates.templates[0].metadataIdentityCount===469&&templates.templates[1].physicalSites===47&&templates.templates[1].metadataIdentityCount===141);
for(const r of regressions.regressions){const sf=ts.createSourceFile(r.id+'.ts',r.code,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);assert('inert regression syntax '+r.id,sf.parseDiagnostics.length===0&&r.executed===false);}
assert('seven core identities retained unverified',[1,2,3,4,5,6,7].every(o=>classification.byOriginalOrdinal[o].path==='packages/harness/src/capability-boundary.ts'&&classification.byOriginalOrdinal[o].safetyDisposition==='UNVERIFIED'));
assert('no acceptance exception',report.proposal.acceptanceExceptions.length===0&&report.verdict==='STATIC_DIAGNOSTIC_ONLY_NO_ACCEPTANCE'&&report.verification.currentCheckerRun===false&&report.verification.fullSuiteRun===false);
save('artifact-validation.json',{runtime:process.version,parserVersion:ts.version,kind:'Artifact self-consistency and inert parser checks only',checks,checkCount:checks.length,scannerExecuted:false,fixtureExecuted:false});
save('io-finalize.json',{reads,writes,sourceExecuted:false});
const authoredTools=['audit-static.cjs','classify-static.cjs','build-report.cjs','finalize-evidence.cjs'].map(n=>{const b=read(out+'/'+n);return {path:out+'/'+n,sha256:sha(b),bytes:b.length,purpose:'Authored static audit program; not original fixture code'};});
const parser=read(out+'/trusted-typescript/lib/typescript.js');
const inputs=['authority.json','freeze.json','frozen-inventory.json','diagnostic-inputs.json'].map(n=>{const b=read(base+'/'+n);return {path:base+'/'+n,bytes:b.length,sha256:sha(b)};});
const artifacts=fs.readdirSync(out,{withFileTypes:true}).filter(d=>d.isFile()&&d.name!=='evidence-manifest.json').map(d=>{const b=read(out+'/'+d.name);return {path:out+'/'+d.name,bytes:b.length,sha256:sha(b)};}).sort((a,b)=>a.path.localeCompare(b.path));
save('evidence-manifest.json',{
  task:authority.task,kind:'FINITE_MANIFEST_AND_AUTHORED_PATH_GUARDS_NOT_SYSCALL_TRACE',
  runtime:{path:authority.runtime,version:process.version},trustedParser:{path:out+'/trusted-typescript/lib/typescript.js',version:ts.version,sha256:sha(parser),bytes:parser.length,trust:'Physically supplied trusted parser, expressly permitted by task'},
  exactPacketInputs:inputs,exactFrozenReadSet:Object.entries(inv).map(([p,metadata])=>({path:root+p,literalFrozenMetadata:metadata})),allowedNarrativeDocuments:authority.allowedNarrativeDocuments,
  authoredExecutableSet:authoredTools,outputArtifacts:artifacts,
  commandToolPolicy:{workingTreeAccess:'none; all explicit filesystem targets inside packet',commandsUsed:['ls explicit packet/output/trusted-typescript directory metadata','cat exact authority/freeze and three allowed narrative documents plus frozen checker text','rg/sed exact frozen source paths','Node 22.23.2 authored static audit programs or small JSON-reading commands','apply_patch output-only authored programs'],indirectPayloadExecution:'none; source text is fed only to TypeScript parser or JSON/text processing',payloadCopyAsProgram:false},
  guards:{read:'Authored read wrappers permit explicit packet JSON inputs, source subtree and output subtree; actual finite source set enumerated above and reconciled against literal inventory before/after. Nonregular files refused by inventory and report/finalization reads.',write:'Single output filename only; no traversal. No source write APIs used.',symbolHost:'Memory-backed source map; noLib/noResolve; resolveModuleNames returns undefined for all names; no ts.sys module resolution fallback',failClosed:'Source SHA mismatch, nonliteral inventory mismatch, invalid evidence span, original identity mismatch, or artifact cardinality inconsistency throws; ambiguous family groups PENDING'},
  actionEvidence:{originalFixtureExecutions:0,originalCheckerExecutions:0,fixtureEvalVmWorkerProcessExecutions:0,networkDnsPgProviderToolActions:0,subagents:0,sourceWriteActions:0,evidenceLevel:'Explicit submitted actions and guarded audit scripts, not operating-system telemetry'},
  sourceIntegrityEvidence:['inventory-before.json','inventory-after.json','inventory-comparison.json'],readWriteEvidence:['io-before.json','io-after.json','io-parse.json','io-classify.json','io-report.json','io-finalize.json'],
  finalizationNote:'This manifest intentionally excludes its own digest to avoid self-reference; no runtime acceptance or global pass is asserted.'
});
console.log(JSON.stringify({artifactChecks:checks.length,artifacts:artifacts.length,classified:classified.length,pending:rows.length-classified.length,sourceDifferences:comparison.differences.length,manifestWritten:true}));
