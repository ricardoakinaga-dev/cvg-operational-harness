'use strict';
// Independent attribution, not the checker, not a proof engine, not acceptance.
const fs=require('node:fs'),crypto=require('node:crypto');
const base='/home/ricardo/.cache/cvg-harness-green-20261004/c1-existing-dynamic-frontier-audit-r1',out=base+'/output',root=base+'/source/';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const io={reads:[],writes:[],sourceExecuted:false,networkActions:[],fixtureProcessActions:[]};
function read(p){if(!p.startsWith(root)&&!p.startsWith(out+'/')&&p!==base+'/diagnostic-inputs.json'&&p!==base+'/frozen-inventory.json')throw Error('guard read');const b=fs.readFileSync(p);io.reads.push({path:p,bytes:b.length,sha256:sha(b)});return b;}
function save(n,x){if(n.includes('/')||n.includes('..'))throw Error('guard write');fs.writeFileSync(out+'/'+n,JSON.stringify(x,null,2)+'\n');io.writes.push(out+'/'+n);}
const ts=require(out+'/trusted-typescript/lib/typescript.js'),input=JSON.parse(read(base+'/diagnostic-inputs.json')),inventory=JSON.parse(read(base+'/frozen-inventory.json'));
const files=new Map();
for(const rel of Object.keys(inventory).filter(p=>/\.(?:[cm]?js|tsx?|cts|mts)$/.test(p))){const b=read(root+rel);if(sha(b)!==inventory[rel].sha256)throw Error('SHA');files.set(rel,ts.createSourceFile(rel,b.toString('utf8'),ts.ScriptTarget.Latest,true,rel.endsWith('.tsx')?ts.ScriptKind.TSX:rel.endsWith('.ts')?ts.ScriptKind.TS:ts.ScriptKind.JS));}
// Closed compiler host: symbols only, zero module resolution or host I/O.
const host={getSourceFile:n=>files.get(n),getDefaultLibFileName:()=>'',writeFile:()=>{throw Error('compiler write');},getCurrentDirectory:()=>'',getDirectories:()=>[],fileExists:n=>files.has(n),readFile:n=>files.get(n)?.text,getCanonicalFileName:n=>n,useCaseSensitiveFileNames:()=>true,getNewLine:()=> '\n',resolveModuleNames:names=>names.map(()=>undefined)};
const program=ts.createProgram([...files.keys()],{allowJs:true,noResolve:true,noLib:true,target:ts.ScriptTarget.Latest,module:ts.ModuleKind.CommonJS},host),checker=program.getTypeChecker();
const census=[],matches=new Map(),reflection=new Set(['get','construct','getPrototypeOf','getOwnPropertyDescriptor','getOwnPropertyDescriptors']);
const unwrap=n=>{while(n&&(ts.isParenthesizedExpression(n)||ts.isAsExpression(n)||ts.isSatisfiesExpression(n)||ts.isTypeAssertionExpression(n)||ts.isNonNullExpression(n)||ts.isAwaitExpression(n)))n=n.expression;return n;};
const literal=n=>n&&ts.isStringLiteralLike(n)?n.text:undefined;
const prop=n=>ts.isPropertyAccessExpression(n)?n.name.text:ts.isElementAccessExpression(n)?literal(n.argumentExpression):undefined;
const access=n=>n&&(ts.isPropertyAccessExpression(n)||ts.isElementAccessExpression(n));
const symbol=n=>checker.getSymbolAtLocation(n);
const globalName=n=>{n=unwrap(n);if(!n||!ts.isIdentifier(n))return;const s=symbol(n);if(!s?.declarations?.length)return n.text;};
function span(n,sf){const start=n.getStart(sf),end=n.getEnd(),a=sf.getLineAndCharacterOfPosition(start),b=sf.getLineAndCharacterOfPosition(end);return {kind:ts.SyntaxKind[n.kind],start,end,line:a.line+1,column:a.character+1,endLine:b.line+1,endColumn:b.character+1,text:n.getText(sf)};}
function container(n,sf){for(let p=n;p;p=p.parent){if(ts.isFunctionDeclaration(p)||ts.isMethodDeclaration(p))return p.name?.getText(sf)||'<anonymous>';if(ts.isVariableDeclaration(p)&&p.initializer&&['__createBinding','__copyProps','__getOwnPropDesc'].includes(p.name.getText(sf)))return p.name.getText(sf);}return '<other>';}
function fingerprint(n){const parts=[];function visit(x){parts.push(ts.SyntaxKind[x.kind]);if(ts.isIdentifier(x)||ts.isStringLiteralLike(x)||ts.isNumericLiteral(x))parts.push(x.text);ts.forEachChild(x,visit);}visit(n);return sha(JSON.stringify(parts));}
const seed=(family,n)=>({family,origins:new Set([n])});
function combine(a,b){if(!a)return b;if(!b)return a;return {family:a.family===b.family?a.family:'MIXED_PROVENANCE',origins:new Set([...a.origins,...b.origins])};}
for(const [rel,sf] of files){
  const nodes=[];function walk(n){nodes.push(n);ts.forEachChild(n,walk);}walk(sf);
  const provenance=new Map();
  const bind=(name,value)=>{if(!ts.isIdentifier(name)||!value)return false;const s=symbol(name);if(!s)return false;const old=provenance.get(s),next=combine(old,value);if(old?.family===next.family&&old.origins.size===next.origins.size)return false;provenance.set(s,next);return true;};
  for(const n of nodes){if(ts.isImportDeclaration(n)&&['child_process','node:child_process','vm','node:vm','worker_threads','node:worker_threads'].includes(literal(n.moduleSpecifier))){const b=n.importClause?.namedBindings;if(b&&ts.isNamedImports(b))for(const e of b.elements)bind(e.name,seed('EXECUTION_MODULE_BINDING',e));}}
  function classify(n,depth=0){n=unwrap(n);if(!n||depth>48)return;
    if(ts.isIdentifier(n)){const global=globalName(n);if(['Function','eval'].includes(global))return seed('EVALUATOR_VALUE',n);return provenance.get(symbol(n));}
    if(access(n)){const key=prop(n),g=globalName(n.expression);
      if(['Object','Reflect'].includes(g)&&reflection.has(key))return seed('REFLECTION_'+key,n);
      if(key==='constructor')return seed('CONSTRUCTOR_PROPERTY',n);
      return classify(n.expression,depth+1);
    }
    if(ts.isCallExpression(n)||ts.isNewExpression(n))return classify(n.expression,depth+1);
    if(ts.isConditionalExpression(n))return combine(classify(n.whenTrue,depth+1),classify(n.whenFalse,depth+1));
    if(ts.isBinaryExpression(n)&&[ts.SyntaxKind.BarBarToken,ts.SyntaxKind.AmpersandAmpersandToken,ts.SyntaxKind.QuestionQuestionToken,ts.SyntaxKind.CommaToken].includes(n.operatorToken.kind))return n.operatorToken.kind===ts.SyntaxKind.CommaToken?classify(n.right,depth+1):combine(classify(n.left,depth+1),classify(n.right,depth+1));
  }
  let changed=true,rounds=0;while(changed&&rounds++<128){changed=false;for(const n of nodes){if(ts.isVariableDeclaration(n)&&n.initializer)changed=bind(n.name,classify(n.initializer))||changed;if(ts.isBinaryExpression(n)&&n.operatorToken.kind===ts.SyntaxKind.EqualsToken)changed=bind(n.left,classify(n.right))||changed;}}
  const emitted=new Map();
  for(const n of nodes){
    // Census counts AST nodes, independent of historical diagnostic multiplicity.
    let motif;
    if(ts.isCallExpression(n)&&access(n.expression)&&['Object','Reflect'].includes(globalName(n.expression.expression))&&reflection.has(prop(n.expression)))motif='REFLECTION_'+prop(n.expression);
    else if(access(n)&&prop(n)==='constructor')motif='CONSTRUCTOR_PROPERTY';
    else if((ts.isCallExpression(n)||ts.isNewExpression(n))&&['Function','eval'].includes(globalName(n.expression)))motif='DIRECT_EVALUATOR_CALL';
    else if(ts.isCallExpression(n)&&globalName(n.expression)==='require'&&literal(n.arguments[0])===undefined)motif='NONLITERAL_REQUIRE_CALL';
    if(motif)census.push({path:rel,sourceSha256:inventory[rel].sha256,family:motif,container:container(n,sf),...span(n,sf)});
    if(!(ts.isIdentifier(n)||access(n)||ts.isCallExpression(n)))continue;
    const p=n.parent;
    if(ts.isIdentifier(n)&&((access(p)&&p.name===n)||(ts.isVariableDeclaration(p)&&p.name===n)||(ts.isParameter(p)&&p.name===n)||(ts.isBindingElement(p)&&p.name===n)||(ts.isImportSpecifier(p))||(ts.isFunctionDeclaration(p)&&p.name===n)||(ts.isPropertyAssignment(p)&&p.name===n)||(ts.isMethodDeclaration(p)&&p.name===n)))continue;
    const value=classify(n);if(!value)continue;
    let v=n;while(v.parent&&unwrap(v.parent)===v)v=v.parent;
    const owner=v.parent;
    if(owner&&ts.isVariableDeclaration(owner)&&owner.initializer===v&&!owner.parent?.parent?.modifiers?.some(m=>m.kind===ts.SyntaxKind.ExportKeyword))continue;
    if(owner&&ts.isBinaryExpression(owner)&&owner.operatorToken.kind===ts.SyntaxKind.EqualsToken&&owner.right===v&&ts.isIdentifier(owner.left))continue;
    const target=owner&&(ts.isCallExpression(owner)||ts.isNewExpression(owner))&&owner.expression===v?owner:n;
    const start=target.getStart(sf);
    if(!emitted.has(start))emitted.set(start,{family:value.family,anchor:span(target,sf),container:container(target,sf),origins:[...value.origins].map(x=>({...span(x,sf),container:container(x,sf)})),attribution:'Independent finite lexical provenance; family diagnosis only; not a safety proof'});
  }
  matches.set(rel,[...emitted.values()]);
}
const groups=new Map();for(const d of input.diagnostics){const k=d.path+':'+d.line+':'+d.reason;if(!groups.has(k))groups.set(k,[]);groups.get(k).push(d);}
const keyed={};
for(const ds of groups.values()){
  const d=ds[0], candidates=(matches.get(d.path)||[]).filter(m=>m.anchor.line===d.line);
  const uniqueFamilies=[...new Set(candidates.map(m=>m.family))];
  const classifyGroup=d.reason==='UNVERIFIED_DYNAMIC_CODE_EXECUTION'&&candidates.length===ds.length&&uniqueFamilies.length===1&&uniqueFamilies[0]!=='MIXED_PROVENANCE';
  for(const x of ds)keyed[x.ordinal]={...x,status:classifyGroup?'FAMILY_CLASSIFIED':'PENDING',...(classifyGroup?{family:uniqueFamilies[0],safetyDisposition:'UNVERIFIED',anchorBinding:candidates.length===1&&ds.length===1?'UNIQUE_AST_SPAN':'LINE_GROUP_CANDIDATE_SET_NO_ORDINAL_ORDER_ASSERTION',lineGroupOrdinals:ds.map(t=>t.ordinal),astCandidates:candidates}: {pendingReason:'No unique family attribution from the bounded lexical model; requires further evidence'})};
}
// Loader classification is restricted to unambiguous direct syntax, not symbols hidden in vendor bundles.
for(const d of input.diagnostics.filter(d=>d.reason!=='UNVERIFIED_DYNAMIC_CODE_EXECUTION')){
  const sf=files.get(d.path);const found=[];function walk(n){const s=span(n,sf);if(s.line===d.line){
    if(d.reason==='UNVERIFIED_MODULE_LOADER_ESCAPE'&&ts.isIdentifier(n)&&['globalThis','global','window','self','process'].includes(globalName(n))&&ts.isCallExpression(n.parent)&&n.parent.arguments.includes(n))found.push({family:'AMBIENT_OBJECT_PASSED_TO_CALL',anchor:s,context:span(n.parent,sf)});
    if(d.reason==='UNVERIFIED_MODULE_LOADER_PROPERTY'&&ts.isElementAccessExpression(n)&&['globalThis','global','window','self'].includes(globalName(n.expression)))found.push({family:'COMPUTED_AMBIENT_PROPERTY',anchor:s});
    if(d.reason==='NON_LITERAL_MODULE_REFERENCE'&&ts.isCallExpression(n))found.push({family:'NONLITERAL_MODULE_REFERENCE_CALL',anchor:s});
  }ts.forEachChild(n,walk);}walk(sf);
  if(found.length===1)keyed[d.ordinal]={...d,status:'FAMILY_CLASSIFIED',family:found[0].family,safetyDisposition:'UNVERIFIED',anchorBinding:'UNIQUE_AST_SPAN',astCandidates:found};
}
const count=xs=>Object.entries(xs.reduce((a,x)=>(a[x.family]=(a[x.family]||0)+1,a),{})).sort((a,b)=>b[1]-a[1]);
const classified=Object.values(keyed).filter(x=>x.status==='FAMILY_CLASSIFIED');
const templates=[];
for(const [rel,sf] of files){function visit(n){if(ts.isVariableDeclaration(n)&&['__createBinding','__copyProps'].includes(n.name.getText(sf))&&n.initializer)templates.push({path:rel,sourceSha256:inventory[rel].sha256,helper:n.name.getText(sf),astFingerprintSha256:fingerprint(n.initializer),span:span(n,sf)});ts.forEachChild(n,visit);}visit(sf);}
for(const t of templates)t.historicalOrdinals=classified.filter(d=>d.path===t.path&&d.family==='REFLECTION_getOwnPropertyDescriptor'&&d.astCandidates.every(c=>c.container===t.helper)).map(d=>d.ordinal);
const templateGroups=new Map();for(const t of templates){const k=t.helper+':'+t.astFingerprintSha256;if(!templateGroups.has(k))templateGroups.set(k,[]);templateGroups.get(k).push(t);}
save('recurring-helper-families.json',{definition:'Exact TypeScript AST preorder kind/identifier/string/numeric spelling fingerprint of initializer; excludes trivia, includes identifier spelling. Counts are frozen physical sites, not dependency closures.',templates:[...templateGroups].map(([k,sites])=>({key:k,physicalSites:sites.length,metadataIdentityCount:sites.reduce((n,t)=>n+t.historicalOrdinals.length,0),sites})).sort((a,b)=>b.physicalSites-a.physicalSites),descriptorIdentitySubfamilies:count(classified.filter(d=>d.family==='REFLECTION_getOwnPropertyDescriptor').map(d=>({family:[...new Set(d.astCandidates.map(c=>c.container))].sort().join('|')})))});
save('family-classification.json',{schema:'bounded-static-family-attribution/v1',scope:input.scope,runtime:process.version,parserVersion:ts.version,notAcceptance:true,totals:{historicalIdentities:input.diagnostics.length,classified:classified.length,pending:input.diagnostics.length-classified.length},byOriginalOrdinal:keyed});
save('family-census.json',{scope:'All 270 frozen code files parsed as text; motif census is not a completed scanner run',sourceFileCount:files.size,astNodeCounts:count(census),classifiedIdentityCounts:count(classified),astOccurrences:census});
save('family-summary.json',{totals:{historical:input.diagnostics.length,classified:classified.length,pending:input.diagnostics.length-classified.length},classifiedIdentityCounts:count(classified),astNodeCounts:count(census),families:count(classified).map(([family,count])=>({family,count,files:[...new Set(classified.filter(x=>x.family===family).map(x=>x.path))].length,representatives:classified.filter(x=>x.family===family).slice(0,4)}))});
save('io-classify.json',io);
console.log(JSON.stringify({classified:classified.length,pending:input.diagnostics.length-classified.length,counts:count(classified),census:count(census)}));
