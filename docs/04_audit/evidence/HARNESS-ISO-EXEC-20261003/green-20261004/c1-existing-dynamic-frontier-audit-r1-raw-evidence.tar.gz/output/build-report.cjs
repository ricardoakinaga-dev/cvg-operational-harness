'use strict';
const fs=require('node:fs'),crypto=require('node:crypto');
const base='/home/ricardo/.cache/cvg-harness-green-20261004/c1-existing-dynamic-frontier-audit-r1',out=base+'/output',root=base+'/source/';
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const reads=[],writes=[];
function read(p){if(!p.startsWith(root)&&!p.startsWith(out+'/')&&!['authority.json','freeze.json','frozen-inventory.json','diagnostic-inputs.json'].some(n=>p===base+'/'+n))throw Error('read guard');if(!fs.lstatSync(p).isFile())throw Error('nonregular');const b=fs.readFileSync(p);reads.push({path:p,sha256:hash(b),bytes:b.length});return b;}
function save(n,x,raw=false){if(n.includes('/')||n.includes('..'))throw Error('write guard');fs.writeFileSync(out+'/'+n,raw?x:JSON.stringify(x,null,2)+'\n');writes.push(out+'/'+n);}
const json=n=>JSON.parse(read(out+'/'+n)),inv=JSON.parse(read(base+'/frozen-inventory.json')),input=JSON.parse(read(base+'/diagnostic-inputs.json'));
const authority=JSON.parse(read(base+'/authority.json')),freeze=JSON.parse(read(base+'/freeze.json'));
const families=json('family-classification.json'),summary=json('family-summary.json'),helpers=json('recurring-helper-families.json'),census=json('family-census.json');
const ts=require(out+'/trusted-typescript/lib/typescript.js');
const evidence=[];
function anchor(id,rel,kind,line,textPrefix){
  const b=read(root+rel);if(hash(b)!==inv[rel].sha256)throw Error('hash');
  const sf=ts.createSourceFile(rel,b.toString('utf8'),ts.ScriptTarget.Latest,true,rel.endsWith('.ts')?ts.ScriptKind.TS:ts.ScriptKind.JS),found=[];
  function visit(n){const start=n.getStart(sf),lc=sf.getLineAndCharacterOfPosition(start);if(ts.SyntaxKind[n.kind]===kind&&lc.line+1===line&&(!textPrefix||n.getText(sf).startsWith(textPrefix)))found.push(n);ts.forEachChild(n,visit);}visit(sf);
  if(found.length>1&&new Set(found.map(n=>n.getStart(sf))).size===1){found.sort((a,b)=>a.getEnd()-b.getEnd());found.splice(1);}
  if(found.length!==1)throw Error('anchor '+id+' matches '+found.length);
  const n=found[0],start=n.getStart(sf),end=n.getEnd(),a=sf.getLineAndCharacterOfPosition(start),z=sf.getLineAndCharacterOfPosition(end);
  evidence.push({id,path:rel,sourceSha256:inv[rel].sha256,sourceBytes:inv[rel].bytes,span:{kind,start,end,line:a.line+1,column:a.character+1,endLine:z.line+1,endColumn:z.character+1},text:n.getText(sf),historicalOrdinals:input.diagnostics.filter(d=>d.path===rel&&d.line>=a.line+1&&d.line<=z.line+1).map(d=>d.ordinal)});
}
const core='packages/harness/src/capability-boundary.ts';
anchor('core-descriptor',core,'CallExpression',595,'Object.getOwnPropertyDescriptor');
anchor('core-descriptor-guards',core,'IfStatement',596);
anchor('core-descriptor-value',core,'PropertyAccessExpression',600,'property.value');
anchor('core-prototype',core,'CallExpression',628,'Object.getPrototypeOf');
anchor('core-prototype-comparison',core,'ReturnStatement',629);
anchor('core-serializer',core,'FunctionDeclaration',537,'function stableSerialize');
anchor('core-plain-record',core,'FunctionDeclaration',623,'function isPlainRecord');
anchor('checker-reflection-set','scripts/boundary-code-execution.mjs','VariableDeclaration',46,'reflection');
anchor('checker-capability-seeds','scripts/boundary-code-execution.mjs','VariableDeclaration',53,'capabilities');
anchor('checker-classify','scripts/boundary-code-execution.mjs','VariableDeclaration',255,'classify');
anchor('ts-binding-template','node_modules/zod/v4/locales/en.cjs','VariableDeclaration',2,'__createBinding');
anchor('esbuild-copy-template','node_modules/@tanstack/query-core/build/modern/index.cjs','VariableDeclaration',10,'__copyProps');
anchor('esbuild-reflection-alias','node_modules/@tanstack/query-core/build/modern/index.cjs','VariableDeclaration',3,'__getOwnPropDesc');
anchor('proxy-forwarder','packages/platform/src/__tests__/controlled-preset-hardening.test.ts','CallExpression',106,'Reflect.get');
anchor('test-child-launch','packages/model-gateway/src/__tests__/bounded-observer-options.test.ts','CallExpression',14,'spawnSync');
anchor('function-matcher-escape','packages/persistence/src/__tests__/outbox-edge.test.ts','CallExpression',119,'expect.any');
anchor('global-spy-escape','apps/web/src/__tests__/app.test.tsx','CallExpression',50,'vi.spyOn');
anchor('fastify-constructor-metadata','node_modules/fastify/fastify.js','PropertyAccessExpression',585,'fn.constructor.name');
anchor('rfdc-constructor-invocation','node_modules/rfdc/index.js','NewExpression',9);
anchor('schema-runtime-compiler','node_modules/fast-json-stringify/index.js','NewExpression',239);
anchor('ajv-runtime-compiler','node_modules/ajv-formats/node_modules/ajv/dist/compile/index.js','NewExpression',89);
anchor('vite-async-constructor','node_modules/vite/dist/node/module-runner.js','PropertyAccessExpression',23);
anchor('vite-async-execution','node_modules/vite/dist/node/module-runner.js','NewExpression',1021);
anchor('vite-dynamic-import','node_modules/vite/dist/node/module-runner.js','CallExpression',1024,'import');
anchor('vite-resolver-reference','node_modules/vite/dist/node/module-runner.js','CallExpression',1073,'import.meta.resolve');
anchor('pino-resolver-reference','node_modules/pino/lib/transport.js','CallExpression',273,'createRequire(context).resolve');
anchor('computed-global','node_modules/vitest/dist/chunks/test.DNmyFkvJ.js','ElementAccessExpression',4105,'globalThis');
save('source-evidence.json',{coordinates:'UTF-16 TypeScript offsets [start,end); lines and columns 1-based. SHA-256 over original bytes, not AST text.',evidence});
const regressions=[];
function regression(id,expectation,code,why,contract='trusted pristine intrinsics + closed compiler graph'){const sf=ts.createSourceFile(id+'.ts',code,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);if(sf.parseDiagnostics.length)throw Error('regression syntax '+id);regressions.push({id,expectation,code,why,requiredContract:contract,syntaxParsed:true,executed:false});}
regression('P01-own-scalar-descriptor','PROVE_INERT',`const o = { x: 1 }; const d = Object.getOwnPropertyDescriptor(o, 'x'); const flag = d !== undefined && 'value' in d && d.enumerable; const x = d?.value;`,'Own scalar data field, finite literal key, descriptor booleans/value are scalar.');
regression('P02-finite-key-union','PROVE_INERT',`const o = { x: 1, y: 'ok' }; const key = cond ? 'x' : 'y'; const v = Reflect.get(o, key);`,'Both candidate keys proven own scalar data fields, no fallback.');
regression('P03-closed-prototype-observation','PROVE_INERT',`const o = { x: 1 }; const p = Object.getPrototypeOf(o); const ok = p === Object.prototype || p === null;`,'Prototype token stays opaque and is consumed only in strict comparisons.');
regression('P04-closed-descriptor-table','PROVE_INERT',`const o = { a: 1, b: false }; const ds = Object.getOwnPropertyDescriptors(o); const e = ds.a.enumerable; const v = ds.b.value;`,'Finite descriptor table and scalar projections.');
regression('P05-shadowed-intrinsic-binding','ANALYZE_LOCAL_BODY',`function f() { const Object = { getPrototypeOf: (x: unknown) => null }; return Object.getPrototypeOf(1); }`,'Spelling is not intrinsic identity; local body is analyzed under ordinary rules.','No intrinsic shortcut; local lexical body analysis');
regression('P06-existing-own-constructor-scalar','PRESERVE_EXISTING_PROOF',`const o = { constructor: 'label' }; const v = o.constructor;`,'Existing own scalar field proof must remain available.');
regression('P07-observation-after-unknown-origin','KEEP_ORIGIN_UNKNOWN_SUPPRESS_DERIVED_EXECUTOR_LABEL_ONLY',`function f(input: unknown) { const p = Object.getPrototypeOf(input); return p === null; }`,'Comparison does not invoke or export p, but the reflection effect on unknown input remains.','Pristine intrinsic result semantics; unknown/proxy input still refused at origin');
regression('N01-proxy-trap','REFUSE_UNKNOWN_EFFECT',`const p = new Proxy({}, { getOwnPropertyDescriptor() { return callback(); } }); const d = Object.getOwnPropertyDescriptor(p, 'x');`,'Descriptor reads can execute traps.');
regression('N02-getter-dispatch','REFUSE_UNKNOWN_EFFECT',`const o = { get x() { return callback(); } }; const v = Reflect.get(o, 'x');`,'Getter body is an effect boundary; no scalar field assumption.');
regression('N03-descriptor-executor-value','REFUSE_CAPABILITY_ESCAPE',`const o = { run: Function }; const d = Object.getOwnPropertyDescriptor(o, 'run'); d!.value('return loader(target)')();`,'Descriptor.value must retain the executor capability.');
regression('N04-descriptor-accessor-value','REFUSE_CAPABILITY_ESCAPE',`const o = { get x() { return loader(target); } }; const d = Object.getOwnPropertyDescriptor(o, 'x'); const g = d!.get; g!();`,'Getter descriptor is not interchangeable with data descriptor.');
regression('N05-prototype-constructor','REFUSE_CAPABILITY_ACCESS',`const p = Object.getPrototypeOf(() => {}); const c = p.constructor; c('return globalThis')();`,'Opaque prototype may not be dereferenced to acquire Function.');
regression('N06-function-constructor-chain','REFUSE_CAPABILITY_ACCESS',`const c = (() => {}).constructor; c('return loader(target)')();`,'Function prototype constructor is an evaluator.');
regression('N07-async-generator-constructors','REFUSE_CAPABILITY_ACCESS',`const a = (async () => {}).constructor; const g = (function* () {}).constructor; new a('return loader(target)'); new g('return loader(target)');`,'Alternate evaluator constructors stay tainted.');
regression('N08-alias-mutation','REFUSE_INVALIDATED_SHAPE',`const o = { x: 1 }; const a = o; (a as any).x = Function; const d = Object.getOwnPropertyDescriptor(o, 'x'); d!.value('return globalThis')();`,'Const does not make object fields immutable.');
regression('N09-callback-escape','REFUSE_INVALIDATED_SHAPE',`const o = { x: 1 }; unknownConsumer(o); const v = Reflect.get(o, 'x');`,'Unknown callee may mutate or retain the object.');
regression('N10-missing-inherited-key','REFUSE_PROTOTYPE_FALLBACK',`const o = { x: 1 }; const v = Reflect.get(o, 'constructor');`,'Missing own field reaches the prototype; do not exclude the word constructor.');
regression('N11-dynamic-key','REFUSE_UNBOUNDED_KEY',`const o = { x: 1 }; const v = Reflect.get(o, externalKey);`,'No finite key set means no closed property proof.');
regression('N12-global-symbol-slot','REFUSE_UNPROVEN_AMBIENT_SLOT',`const key = Symbol.for('state'); const x = globalThis[key];`,'A constant symbol is not proof of an inert ambient slot.');
regression('N13-global-object-handoff','REFUSE_CAPABILITY_ESCAPE',`unknownConsumer(globalThis, 'fetch');`,'Literal second argument does not constrain a callee holding the full global object.');
regression('N14-process-object-handoff','REFUSE_CAPABILITY_ESCAPE',`unknownConsumer(process);`,'No test/dev or API-name exemption for process namespaces.');
regression('N15-constructor-metadata-unknown','REFUSE_UNKNOWN_EFFECT',`function f(x: any) { return x.constructor.name === 'AsyncFunction'; }`,'Unknown receiver can install a getter or Proxy trap; metadata use alone is insufficient.');
regression('N16-global-intrinsic-reassignment','REFUSE_INTRINSIC_IDENTITY',`Object.getOwnPropertyDescriptor = replacement; const o = { x: 1 }; const d = Object.getOwnPropertyDescriptor(o, 'x');`,'Trusted native identity must not be inferred from spelling.');
regression('N17-local-reflection-shadow','REFUSE_UNKNOWN_LOCAL_BODY',`const Reflect = { get: unknownCallback }; const x = Reflect.get({ x: 1 }, 'x');`,'Shadowed APIs require lexical/body analysis.');
regression('N18-module-getter-forwarding','REFUSE_UNPROVEN_EXPORT_SUMMARY',`function copy(to: object, from: any, key: string) { Object.defineProperty(to, key, { get: () => from[key] }); }`,'Export getter forwarding needs a module/export/callback summary.');
regression('N19-dynamic-module-target','REFUSE_NONLITERAL_REFERENCE',`import(externalTarget);`,'Never expand arbitrary module access.');
regression('N20-runtime-codegen-even-literal','KEEP_EXECUTOR_DIAGNOSTIC',`new Function('return 1');`,'This proposal does not introduce an evaluator exception.');
regression('N21-child-worker-vm','KEEP_EXECUTOR_DIAGNOSTIC',`import { spawnSync } from 'node:child_process'; import { Worker } from 'node:worker_threads'; import { runInNewContext } from 'node:vm'; spawnSync(executable, argv); new Worker(code, { eval: true }); runInNewContext(code);`,'Actual execution capabilities remain refused independently of benign return-field reads.');
regression('N22-destructuring-rebind','REFUSE_INVALIDATED_SHAPE',`const o = { x: 1 }; ({ x: o.x } = externalObject); const d = Object.getOwnPropertyDescriptor(o, 'x');`,'Assignment-pattern leaves must invalidate data-field proof.');
regression('N23-reflection-alias-export','REFUSE_CAPABILITY_ESCAPE',`const get = Reflect.get; export { get };`,'Do not certify a general exported reflection capability.');
regression('N24-construct-unknown-target','REFUSE_UNKNOWN_EFFECT',`Reflect.construct(externalConstructor, [], externalNewTarget);`,'Construct invokes target body and can observe newTarget.prototype.');
regression('N25-plain-prototype-is-not-no-proxy','REFUSE_UNKNOWN_EFFECT',`function f(x: any) { if (Object.getPrototypeOf(x) === Object.prototype) return Object.getOwnPropertyDescriptor(x, 'x'); }`,'A Proxy can report a plain prototype and still trap descriptors.');
regression('N26-syntax-cap-exhaustion','REFUSE_PROOF_BUDGET_EXHAUSTION',`const key = externallyComputedFiniteLookingKey; Reflect.get({ x: 1 }, key);`,'Add generated inert AST families exceeding depth/node/key caps; fail closed, never truncate to safe.');
save('required-inert-regressions.json',{status:'PROPOSED_NOT_EXECUTED',purpose:'Builder feeds these strings to checker/parser only; never eval, vm, import, spawn or worker them. Expectations describe future proof rules, not current acceptance.',regressions});
const before=json('inventory-before.json'),after=json('inventory-after.json'),differences=[];
for(let i=0;i<before.entries.length;i++){const a=before.entries[i],b=after.entries[i];for(const k of Object.keys(a))if(JSON.stringify(a[k])!==JSON.stringify(b[k]))differences.push({path:a.path,field:k,before:a[k],after:b[k]});}
if(differences.length)throw Error('source changed');
const verification={frozenInventorySha256:freeze.inventorySha256,literalBeforeEntries:before.literalEntries,literalAfterEntries:after.literalEntries,individualInventoryHashMatches:273,individualDiagnosticSourceHashMatches:267,metadataCompared:Object.keys(before.entries[0]),differences,zeroSourceMutationObserved:true,currentCheckerRun:false,fullSuiteRun:false};
save('inventory-comparison.json',verification);
const proposal={status:'BOUNDED_PROPOSAL_ONLY',acceptanceExceptions:[],implementationScope:['scripts/boundary-code-execution.mjs value/effect classification','scripts/check-product-boundary.mjs integration only to retain refusal for residual unknown effects','new inert scanner input regressions; no executable fixtures'],steps:[
  {id:'B1',action:'Separate operation effect from returned value shape. Preserve executor/loader capability taint on actual returned fields; model descriptors/prototypes as structured or opaque values instead of applying one executor bit to everything.',limits:'Unknown intrinsic identity or unknown receiver retains origin effect and refusal. No blanket Object/Reflect exemption.'},
  {id:'B2',action:'Extend existing own-scalar stableInitializer proof to closed data shapes and finite key sets. Record receiver allocation, lexical identity, aliases, every write and escape; conservative rejection is acceptable.',limits:'Own property only; no spreads, computed definitions, __proto__, accessors, methods, Proxy/external inputs, unknown calls, writes or exports in first implementation.'},
  {id:'B3',action:'Add intrinsic operation summaries only behind an explicit pristine-intrinsics authority. getOwnPropertyDescriptor returns optional descriptor with boolean metadata and value/get/set capability summaries. getPrototypeOf returns opaque prototype tokens. Reflect.get returns the proven own data field.',limits:'Keep arbitrary construct, prototype dereference, general reflection exports and dynamic evaluator/module references unverified.'},
  {id:'B4',action:'Propagate through lexical aliases and assignments to a monotone finite fixed point; use budget exhaustion => Unknown. Suggested bounds: 16 keys/unions, depth 64, 4096 local proof nodes; these are proposed constants requiring builder review.',limits:'Do not turn partial traversal into proof; preserve assignment-pattern/default-parameter and shadowing behavior.'},
  {id:'B5',action:'For CommonJS helper metadata, analyze exact helper bodies and exact literal source namespace export summaries. Preserve forwarded getter/value capabilities.',limits:'A matching helper fingerprint establishes syntax, not trusted from/to objects or export semantics. Existing module closure and effect summaries are necessary.'},
  {id:'B6',action:'Validate parser-only regression matrix before any attempt at scoped scanner runs in builder-owned snapshot. Bind any eliminated ordinal to its new proof certificate, source hash and assumptions.',limits:'No projected elimination count, no installed-tree verdict, no acceptance exceptions and no pass on residual Unknown.'}
],contractsNeeded:[
  'Trusted pristine Object/Reflect/Symbol and descriptor allocation semantics must be enforced by trusted bootstrap/realm policy or shown by a complete relevant closure; lexical global spelling, const alias and absence of writes in one file are insufficient.',
  'Core serialization inputs must be recursively JSON data created by a trusted parse/allocation boundary, never attacker-defined Proxy/accessor objects. Object.getPrototypeOf equality and Object.freeze do not prove this.',
  'Module helper inputs require exact runtime physical closure, export/getter summaries, and mutation/callback analysis. Declaration files and package labels cannot certify runtime.',
  'Process/worker/codegen/toolchain execution requires an explicit restricted execution/module policy if the overall contract is intended to permit it; generated-code text may be analyzed inertly but unknown callbacks/options/global access remain unresolved.'
]};
const report={task:authority.task,mode:authority.mode,verdict:'STATIC_DIAGNOSTIC_ONLY_NO_ACCEPTANCE',runtime:process.version,parserVersion:ts.version,authority:authority,verification,counts:families.totals,familyCounts:summary.classifiedIdentityCounts,exactHelperFamilies:helpers.templates.map(t=>({key:t.key,physicalSites:t.physicalSites,metadataIdentityCount:t.metadataIdentityCount})),core:{path:core,sha256:inv[core].sha256,originalOrdinals:[1,2,3,4,5,6,7],descriptorCause:[1,2,3,4],prototypeCause:[5,6,7],falsePositiveStatus:'Derived executor taint is overconservative for observations. Whole-call inertness is not proven for unknown values/Proxies or mutable intrinsics.',sourceEvidenceIds:evidence.filter(e=>e.id.startsWith('core-')).map(e=>e.id)},priority:[
  {priority:'P0',cause:'Actual evaluator/codegen and execution capabilities; dynamic import/resolver targets and ambient namespace escapes',evidence:['schema-runtime-compiler','ajv-runtime-compiler','vite-async-constructor','vite-async-execution','vite-dynamic-import','vite-resolver-reference','pino-resolver-reference','test-child-launch','global-spy-escape','rfdc-constructor-invocation'],claim:'Verified AST mechanisms, not proof of runtime invocation or a forbidden product import.'},
  {priority:'P1',cause:'Coarse reflection return taint and repeated helper metadata',evidence:['checker-reflection-set','checker-classify','ts-binding-template','esbuild-copy-template','core-descriptor','core-prototype'],claim:'Concrete bounded abstraction improvement available; prerequisites block blanket discharge.'},
  {priority:'P2',cause:'Unknown-object constructor metadata, matcher callbacks, reflection proxy forwarding and computed global slots',evidence:['fastify-constructor-metadata','function-matcher-escape','proxy-forwarder','computed-global'],claim:'Intent looks observational in representative sources, but local syntax cannot prove effects/callee restrictions.'}
],proposal,limitations:[
  '1,610 identities are historical input. No original scanner or original fixture program was executed.',
  '1,406 family classifications are structural attributions, not eliminated diagnostics; 204 remain PENDING.',
  '787 classified identities have unique AST span binding; 619 use homogeneous line-group candidate sets, without asserting same-line ordinal order.',
  'The independent provenance model intentionally covers only a finite syntactic subset; it is not the checker and not a sound acceptance verifier. Cardinality or family ambiguities remain PENDING.',
  'No current installed completion, global pass, release, or runtime closure proof is claimed. No scope exclusion based on vendor/test/dev/field/reflection labels.',
  'The finite action manifest and guards provide scoped evidence, not kernel syscall tracing. No original payload was executed.'
],artifacts:{sourceEvidence:'source-evidence.json',classification:'family-classification.json',helperFamilies:'recurring-helper-families.json',regressions:'required-inert-regressions.json',comparison:'inventory-comparison.json',manifest:'evidence-manifest.json'}};
save('report.json',report);
const ref=id=>{const e=evidence.find(e=>e.id===id);return '`'+e.path+':'+e.span.line+':'+e.span.column+'` ['+e.span.start+','+e.span.end+')';};
const rows=summary.classifiedIdentityCounts.map(([f,n])=>'| `'+f+'` | '+n+' | '+summary.families.find(x=>x.family===f).files+' |').join('\n');
const evTable=evidence.map(e=>'| '+e.id+' | `'+e.path+'` | '+e.span.line+':'+e.span.column+' | ['+e.span.start+','+e.span.end+') | `'+e.sourceSha256+'` |').join('\n');
const md=`# C1 existing dynamic frontier — bounded static diagnostic sidecar

**Result: a finite proof rule can reduce reflection false positives for closed data, while preserving refusal of arbitrary module access. The supplied core and vendor calls cannot all be discharged by that rule without additional contract evidence.** This is independent static diagnosis and a proposal, not BUILD or acceptance.

## Scope and integrity

Authority and freeze were read first. The literal frozen inventory hash is \`${freeze.inventorySha256}\`. Both snapshots enumerate exactly **273 files**: 267 diagnostic-bound sources, three checker sources, and the exact three permitted narrative documents. Every file individually matches frozen SHA-256 and byte length; every diagnostic source matches its machine identity. Before/after contents and captured metadata match, including mode, owner, inode, links, size, and nanosecond timestamps. See [snapshots](inventory-before.json), [after](inventory-after.json), and [comparison](inventory-comparison.json).

Node **${process.version}** and the physically supplied TypeScript **${ts.version}** parsed source text. All 267 diagnostic-bound files parse without syntax diagnostics. The helper census additionally parses the three frozen checker files. No original checker, fixture, test suite, generated string, worker or subprocess payload was executed. The output programs import only authored audit logic, Node builtins, and the trusted parser. No Root, other packets, history, prior verdicts, extra narrative documents, environment inspection, DNS/network, PG/provider or subagents were used. The packet's narrow scope governs over broader repository ledger/claim instructions; no repository writes occurred.

The **1,610** entries are historical machine identities, not a completed current scan. **1,406** received a structural family classification; **204 remain PENDING**. No entry receives acceptance or a safety exception. [Classification](family-classification.json) preserves original ordinal/path/line/reason/source SHA exactly. Of classified entries, 787 bind to unique AST spans; 619 bind to homogeneous same-line candidate sets. Same-line ordinal order is deliberately not invented. Offsets use TypeScript UTF-16 [start,end), with 1-based lines/columns. The attribution model is a finite diagnostic heuristic, not the original checker or a sound acceptance engine. Mixed family or unequal candidate-count groups remain PENDING.

## Largest verified structural families

Counts below are exact counts of historical identities attributed by the stated bounded model, not counts resolved, or independent executions. Every row retains exact hashes, origin and use spans in [classification](family-classification.json). [AST census](family-census.json) separately counts physical syntax nodes; alias propagation and repeated reads explain different denominators.

| Family | Classified historical identities | Distinct frozen paths |
| --- | ---: | ---: |
${rows}

The strongest exact recurring templates are:

- **TypeScript \`__createBinding\`: 67 physical initializer sites with identical AST fingerprint \`e42bd0b93708e45de4f84c7e765147aee460a4b704e7a6e48a2c7611799458f6\`**. Each contributes seven descriptor-origin identities, total **469**. Representative: ${ref('ts-binding-template')}. The code obtains a descriptor, tests presence/\`get\`/writable/configurable, replaces it with an enumerable getter when needed, and calls \`Object.defineProperty\`. Metadata checks and the forwarding getter are separate boundaries.
- **esbuild \`__copyProps\`: 47 physical initializer sites with identical AST fingerprint \`f2fb2d11533374de2ed0dff17795493443b8e0150f30257fd8ca22dec64819e8\`**. Each contributes three descriptor-origin identities, total **141**. Representative: ${ref('esbuild-copy-template')}, with alias ${ref('esbuild-reflection-alias')}. The helper derives \`enumerable\` from a descriptor but creates a getter reading \`from[key]\`. That getter can transport capabilities or execute accessors.

These two templates alone explain **610 of the 803** descriptor-family attributions. Exact normalized AST initializers, fingerprints, per-file SHA, spans and all 114 physical sites are in [recurring families](recurring-helper-families.json). Normalization ignores trivia but preserves node kinds and identifier/string/numeric spelling. A fingerprint proves repeated structure, not receiver safety. The direct syntax census finds 177 constructor accesses, 117 direct descriptor calls, 43 prototype calls, 14 direct Function calls/new expressions, 12 Reflect.get calls, nine descriptor-table calls, and five Reflect.construct calls. These figures cover frozen files only.

The checker explicitly seeds Object/Reflect as reflection, labels selected methods as executor, then labels calls through those methods and their propagated values as executor. \`classify\` propagates a single bit through aliases, property reads and calls. Consequently a descriptor's \`enumerable\`, a descriptor presence test and a returned prototype's equality test inherit the same label as executable code. Exact checker definitions: ${ref('checker-reflection-set')}, ${ref('checker-capability-seeds')}, ${ref('checker-classify')}.

## Core capability boundary: all seven identities

Frozen \`${core}\` SHA-256: \`${inv[core].sha256}\`.

| Original ordinals | Verified syntax | Diagnosis |
| --- | --- | --- |
| 1 | ${ref('core-descriptor')} | Unknown receiver descriptor operation seeded as executor. |
| 2, 3 | ${ref('core-descriptor-guards')} | Two occurrences of the local descriptor in presence and data-descriptor checks inherit executor taint; same-line spans remain a candidate set. |
| 4 | ${ref('core-descriptor-value')} | Descriptor value passed recursively to serialization; value content cannot be assumed scalar merely because the descriptor exists. |
| 5 | ${ref('core-prototype')} | Unknown receiver prototype reflection seeded as executor. |
| 6, 7 | ${ref('core-prototype-comparison')} | Two uses of prototype in strict equality comparisons inherit executor taint. |

Verified defenses include primitive type checks, array/plain-object branches, depth/node/string/shape budgets, cycle detection, dangerous-key rejection, and rejecting descriptors without a \`value\` field. The plain-record predicate catches errors and compares the prototype with Object.prototype/null. None of these establish **non-Proxy input**: a Proxy can report a plain prototype and later trap ownKeys/getOwnPropertyDescriptor. Array reads can also invoke index getters. Recursing into descriptor.value guards eventual value type but does not retroactively make earlier traps inert. Native descriptor inspection does not invoke an ordinary receiver getter, but a Proxy trap is a different mechanism.

Thus ordinals 2/3 and 6/7 are verified observational uses for which unconditional executor value taint is overconservative under pristine native semantics. Ordinal 4 requires a descriptor.value capability/content summary. Ordinals 1/5 retain unknown reflection effects until input provenance and intrinsic identity are established. **Zero of seven is accepted here.** A value/effect split can suppress derived executor labels while keeping an origin refusal; that is diagnostic precision, not a whole-file pass.

## Prioritize actual capability boundaries

1. **Keep real evaluator and execution paths refused.** The AST census contains 14 direct Function call/new sites. Examples: ${ref('schema-runtime-compiler')} consumes generated code; ${ref('ajv-runtime-compiler')} consumes sourceCode after an optional code-processing callback. Vite obtains an async function constructor at ${ref('vite-async-constructor')} and constructs/invokes it using supplied code at ${ref('vite-async-execution')}. ${ref('test-child-launch')} launches a Node executable through spawnSync with a fixture URL and dynamic arguments. Benign result.status/stdout checks do not remove the launch boundary. These are verified mechanisms, not evidence that they ran or imported the forbidden product.
2. **Keep nonliteral target/resolver and general capability handoffs unknown.** Vite's ${ref('vite-dynamic-import')} takes filepath; ${ref('vite-resolver-reference')} embeds runtime specifier/importer. Pino's ${ref('pino-resolver-reference')} uses a caller-derived createRequire base and origin. The latter two ordinal families remain PENDING in automatic classification; these exact AST findings do not require inventing their loader alias provenance. Global handoff ${ref('global-spy-escape')} supplies all of globalThis to a callee. A string 'fetch' cannot constrain what that callee can read. Of 68 directly attributed ambient-object argument identities, 58 are vi.spyOn(globalThis, ...); the other ten are descriptor/property operations on globalThis. No matcher/library exemption follows. Process handoffs similarly need the callee/argument contract and remain PENDING when the bounded matcher cannot bind them.
3. **Split constructor observation from construction, without a field exemption.** Fastify's ${ref('fastify-constructor-metadata')} compares constructor.name with AsyncFunction; observational intent is verified, but fn is externally supplied and its constructor property can be accessor-backed. rfdc's ${ref('rfdc-constructor-invocation')} actually invokes cur.constructor. A prototype/evaluator chain and an unknown newTarget remain different, unresolved effects.
4. **Reflection and matcher families need specific summaries.** ${ref('proxy-forwarder')} is inside a Proxy handler and returns bound methods or arbitrary target fields; the code gives no own-scalar proof. ${ref('function-matcher-escape')} passes Function to expect.any: likely intent is type matching, but the callee receives an executor value and cannot be certified from its name. ${ref('computed-global')} uses a symbolic ambient slot: even a finite constant symbol proves a key, not inert contents or exclusive ownership. Reflect.construct invokes a target body and observes newTarget; it is not a scalar-read API.

## Bounded implementation proposal

The first change should be a **value/effect split**, not an expanded allowlist. Keep an effect/capability result for the operation, and a separate abstract result shape: primitive, closed own data record, optional descriptor, finite descriptor table, opaque prototype token, known module namespace with export summaries, capability set, or Unknown. A descriptor has guaranteed boolean metadata under native semantics, while its value/get/set fields retain receiver-field capabilities. An opaque prototype can be compared by identity; dereferencing or exporting it returns Unknown unless separately proven.

Extend the existing stable own-scalar proof narrowly: fresh local object allocation, only explicit own scalar data fields, finite literal key union, lexical binding identity, all references audited for writes/aliases/callback escapes, no computed definitions/spreads/__proto__/accessors/methods in the initial rule. Const is a binding constraint, not object immutability. Prove every receiver/key alternative; property absence must not silently fall through to prototypes. A known loader/evaluator field stays tainted even in a perfectly closed object. Alias/assignment transfer must preserve shadowing and assignment-pattern writes.

For native descriptor/prototype summaries, require **trusted intrinsic identity and semantics**, not global spelling or type declarations. With that authority, descriptor booleans and presence tests can be modeled accurately even when an unknown receiver leaves an origin effect. Closed receivers permit full inertness for descriptor lookup or own-data Reflect.get. Unknown receivers, Proxy potential, getter dispatch, arbitrary construction, exported reflection functions, runtime code generation, and unknown module targets remain refused.

Use bounded monotone transfer and fail closed on exhaustion. Proposed implementation limits are 16 keys/union alternatives, depth 64 and 4096 local proof nodes, subject to builder review. A budget limit produces Unknown, never a truncated proof. First integrate in boundary-code-execution.mjs and preserve residual effect refusal through check-product-boundary.mjs. Do not broaden literal module resolution or infer safety from declaration closures.

For the 114 helper sites, metadata can be summarized from exact helper bodies, but clearing the helper as a whole needs exact runtime namespace/export/getter summaries and non-Proxy/mutation provenance for its receivers. Match the supported structure and prove each argument; do not skip a helper name, path, package or fingerprint. The helper name can also be shadowed or rebound, and a module export can be a getter returning a loader.

**Why the current seven core identities cannot all be eliminated from this packet alone:** stableSerialize accepts unknown values; the plain-record check is structural and cannot distinguish a Proxy. The packet contains no enforced pristine-realm policy or trusted recursive JSON-only allocation contract for all callers. Dependencies and callback consumers may mutate globals or carry capabilities. A contract/runtime policy must establish these properties, or a much larger relevant closure must be proven. JSON types, tests/dev labels, Object.freeze and a locally stable alias do not supply that proof. A future contract is a separate reviewed change, not authority granted by this sidecar.

## Required inert regressions and handoff

[Regression matrix](required-inert-regressions.json) contains **${regressions.length} inert source strings**, all syntax-parsed and never executed. Seven positive/observation cases exercise own scalar descriptors, finite keys, opaque prototype comparisons, descriptor tables, lexical shadowing, the existing own-constructor scalar rule, and retaining an unknown origin while removing a derived executor label. Negative cases cover Proxy traps, getters, descriptor-carried Function/getter capabilities, prototype and async/generator constructor chains, alias mutation/destructuring writes, callback escapes, missing/dynamic keys, symbolic ambient slots, global/process handoffs, unknown constructor metadata, intrinsic rebinding, module getter forwarding, dynamic imports, code generation, process/worker/vm entrypoints, exported reflection aliases, unknown construct targets, false plain-object assumptions and proof budget exhaustion.

These expectations are proposed proof behavior under stated contracts. They are not passing tests of the present checker. The builder should feed strings to AST/checker input only, preserve failing negative outcomes and existing literal-loader positive controls, then bind any eliminated identity to a certificate containing source SHA, AST span, receiver/key/value/effect facts, dependencies, assumptions and exhausted-bound handling. A local focal parser/checker review is sufficient for this diagnostic handoff; this task does not authorize a full suite, acceptance exceptions, current-installed completion or a global pass.

## Exact representative source evidence

Every claimed family has per-ordinal candidate spans/source SHA in [machine classification](family-classification.json), physical AST sites in [census](family-census.json), and helper sites in [recurring families](recurring-helper-families.json). Representative files inspected directly span core, tests and vendor. Full inert source excerpts and enclosing scope are in [source evidence](source-evidence.json).

| Evidence ID | Frozen source path | Line:column | UTF-16 span | Exact source SHA-256 |
| --- | --- | --- | --- | --- |
${evTable}

## Action evidence and limits

[Finite evidence manifest](evidence-manifest.json) enumerates allowed physical inputs, exact source hashes, executable audit tools, trusted parser hash, and output artifacts. Read/write guards restrict authored audit programs to packet inputs/source/output and output-only writes; the TypeScript symbol host is memory-backed with no module resolution or filesystem fallback. Command-level reads use explicit packet paths. This is a finite manifest/guard audit, **not syscall tracing**, and does not invent a kernel-observed I/O=0 result. Action evidence shows no original fixture execution or requested external-service action. Authority, freeze and diagnostic input hashes are recorded in the manifest. Source contents and literal metadata match before/after.

Next action is the builder's review of the value/effect proposal and regression matrix, retaining 204 PENDING identities and all unresolved origin effects. This report grants no acceptance decision, exception, release or inferred resolution of the historical 1,610.
`;
save('report.md',md,true);
save('io-report.json',{runtime:process.version,parserVersion:ts.version,reads,writes,sourceExecuted:false});
console.log(JSON.stringify({evidence:evidence.length,regressions:regressions.length,reportWritten:true,verificationDifferences:differences.length}));
