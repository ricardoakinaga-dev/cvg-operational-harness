'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const base = '/home/ricardo/.cache/cvg-harness-green-20261004/c1-existing-dynamic-frontier-audit-r1';
const out = base + '/output';
const source = base + '/source';
const reads = [];
const writes = [];
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
function read(p) {
  if (!(p.startsWith(source + '/') || ['authority.json','freeze.json','frozen-inventory.json','diagnostic-inputs.json'].some(n => p === base + '/' + n) || p.startsWith(out + '/'))) throw Error('read guard: ' + p);
  const st = fs.lstatSync(p, {bigint:true});
  if (!st.isFile()) throw Error('nonregular read: ' + p);
  const b = fs.readFileSync(p); reads.push({path:p, bytes:b.length,sha256:sha(b)}); return b;
}
function write(n,x) { const p=out+'/'+n; if (!p.startsWith(out+'/') || n.includes('..')) throw Error('write guard'); fs.writeFileSync(p,JSON.stringify(x,null,2)+'\n'); writes.push(p); }
const authority = JSON.parse(read(base+'/authority.json'));
const freeze = JSON.parse(read(base+'/freeze.json'));
const inventoryBytes = read(base+'/frozen-inventory.json');
if (sha(inventoryBytes)!==freeze.inventorySha256) throw Error('inventory hash');
const inventory = JSON.parse(inventoryBytes);
const input = JSON.parse(read(base+'/diagnostic-inputs.json'));
function literalPaths(dir=source, prefix='') {
  const items=[]; for (const d of fs.readdirSync(dir,{withFileTypes:true})) {
    const rel=prefix+d.name; if(d.isDirectory())items.push(...literalPaths(dir+'/'+d.name,rel+'/'));else items.push(rel);
  } return items.sort();
}
function snapshot(stage) {
  const actual = literalPaths();
  const expected = Object.keys(inventory).sort();
  if(JSON.stringify(actual)!==JSON.stringify(expected))throw Error('literal inventory mismatch');
  const entries = actual.map(rel=>{
    const p=source+'/'+rel, st=fs.lstatSync(p,{bigint:true}), b=read(p), h=sha(b), exp=inventory[rel];
    if (b.length!==exp.bytes || h!==exp.sha256) throw Error('source hash mismatch '+rel);
    return {path:rel,frozenMetadata:exp,bytes:b.length,sha256:h,mode:st.mode.toString(),uid:st.uid.toString(),gid:st.gid.toString(),dev:st.dev.toString(),ino:st.ino.toString(),nlink:st.nlink.toString(),size:st.size.toString(),mtimeNs:st.mtimeNs.toString(),ctimeNs:st.ctimeNs.toString(),birthtimeNs:st.birthtimeNs.toString(),atimeNs:st.atimeNs.toString()};
  });
  const data={stage,inventorySha256:sha(inventoryBytes),literalEntries:actual.length,diagnosticSources:Object.keys(input.sourceInventory).length,entries};
  write('inventory-'+stage+'.json',data);return data;
}
const stage=process.argv[2]||'before';
if(stage==='before' || stage==='after') {snapshot(stage);write('io-'+stage+'.json',{runtime:process.version,guard:'read only packet inputs/source/output; regular files only; output writes only; no fixture imports',reads,writes});process.exit(0);}
const ts = require(out + '/trusted-typescript/lib/typescript.js');
const sourceFiles = new Map();
for (const [rel,expected] of Object.entries(input.sourceInventory)) {
  const b=read(source+'/'+rel); if(sha(b)!==expected.sha256 || b.length!==expected.bytes) throw Error('diagnostic source mismatch');
  const text=b.toString('utf8');const sf=ts.createSourceFile(rel,text,ts.ScriptTarget.Latest,true,rel.endsWith('tsx')?ts.ScriptKind.TSX:rel.endsWith('ts')?ts.ScriptKind.TS:ts.ScriptKind.JS);
  sourceFiles.set(rel,sf);
}
function nodeInfo(n,sf) {
  const start=n.getStart(sf),end=n.getEnd(),lc=sf.getLineAndCharacterOfPosition(start),elc=sf.getLineAndCharacterOfPosition(end);
  return {kind:ts.SyntaxKind[n.kind],start,end,startLine:lc.line+1,startColumn:lc.character+1,endLine:elc.line+1,endColumn:elc.character+1,text:n.getText(sf)};
}
const nodeKinds=new Set([ts.SyntaxKind.ElementAccessExpression,ts.SyntaxKind.PropertyAccessExpression,ts.SyntaxKind.CallExpression,ts.SyntaxKind.NewExpression,ts.SyntaxKind.Identifier,ts.SyntaxKind.VariableDeclaration,ts.SyntaxKind.BindingElement,ts.SyntaxKind.ExportAssignment]);
const nodesByFile=new Map();
for(const [rel,sf] of sourceFiles){const nodes=[];function walk(n){if(nodeKinds.has(n.kind))nodes.push(nodeInfo(n,sf));ts.forEachChild(n,walk);}walk(sf);nodesByFile.set(rel,nodes);}
const mapped=input.diagnostics.map(d=>({...d,candidates:nodesByFile.get(d.path).filter(n=>n.startLine===d.line)}));
write('ast-line-candidates.json',{runtime:process.version,parserVersion:ts.version,diagnostics:mapped,parseDiagnostics:[...sourceFiles].map(([p,sf])=>({path:p,count:sf.parseDiagnostics.length,diagnostics:sf.parseDiagnostics.map(d=>({start:d.start,length:d.length,code:d.code,message:ts.flattenDiagnosticMessageText(d.messageText,' ')}))}))});
const count=(xs,key)=>Object.entries(xs.reduce((a,x)=>{const k=key(x);a[k]=(a[k]||0)+1;return a;},{})).sort((a,b)=>b[1]-a[1]);
write('exploration.json',{byReason:count(input.diagnostics,d=>d.reason),byPath:count(input.diagnostics,d=>d.path),byCandidateKinds:count(mapped,d=>[...new Set(d.candidates.map(n=>n.kind))].join(',')),multiCandidates:mapped.filter(d=>d.candidates.length>1).length});
write('io-parse.json',{runtime:process.version,parserVersion:ts.version,reads,writes,sourceExecuted:false});
console.log(JSON.stringify({parsed:sourceFiles.size,diagnostics:mapped.length,parseErrors:[...sourceFiles].filter(([,sf])=>sf.parseDiagnostics.length).map(([p,sf])=>[p,sf.parseDiagnostics.length]),topFiles:count(input.diagnostics,d=>d.path).slice(0,15),topShapes:count(mapped,d=>[...new Set(d.candidates.map(n=>n.kind))].join(',')).slice(0,15)}));
