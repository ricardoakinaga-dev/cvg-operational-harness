# C1 existing dynamic frontier — bounded static diagnostic sidecar

**Result: a finite proof rule can reduce reflection false positives for closed data, while preserving refusal of arbitrary module access. The supplied core and vendor calls cannot all be discharged by that rule without additional contract evidence.** This is independent static diagnosis and a proposal, not BUILD or acceptance.

## Scope and integrity

Authority and freeze were read first. The literal frozen inventory hash is `9c0ee4f6a7d7c3cb4499a7b797db6223f9fe8f628dede59799a3cb268261f75a`. Both snapshots enumerate exactly **273 files**: 267 diagnostic-bound sources, three checker sources, and the exact three permitted narrative documents. Every file individually matches frozen SHA-256 and byte length; every diagnostic source matches its machine identity. Before/after contents and captured metadata match, including mode, owner, inode, links, size, and nanosecond timestamps. See [snapshots](inventory-before.json), [after](inventory-after.json), and [comparison](inventory-comparison.json).

Node **v22.23.2** and the physically supplied TypeScript **6.0.3** parsed source text. All 267 diagnostic-bound files parse without syntax diagnostics. The helper census additionally parses the three frozen checker files. No original checker, fixture, test suite, generated string, worker or subprocess payload was executed. The output programs import only authored audit logic, Node builtins, and the trusted parser. No Root, other packets, history, prior verdicts, extra narrative documents, environment inspection, DNS/network, PG/provider or subagents were used. The packet's narrow scope governs over broader repository ledger/claim instructions; no repository writes occurred.

The **1,610** entries are historical machine identities, not a completed current scan. **1,406** received a structural family classification; **204 remain PENDING**. No entry receives acceptance or a safety exception. [Classification](family-classification.json) preserves original ordinal/path/line/reason/source SHA exactly. Of classified entries, 787 bind to unique AST spans; 619 bind to homogeneous same-line candidate sets. Same-line ordinal order is deliberately not invented. Offsets use TypeScript UTF-16 [start,end), with 1-based lines/columns. The attribution model is a finite diagnostic heuristic, not the original checker or a sound acceptance engine. Mixed family or unequal candidate-count groups remain PENDING.

## Largest verified structural families

Counts below are exact counts of historical identities attributed by the stated bounded model, not counts resolved, or independent executions. Every row retains exact hashes, origin and use spans in [classification](family-classification.json). [AST census](family-census.json) separately counts physical syntax nodes; alias propagation and repeated reads explain different denominators.

| Family | Classified historical identities | Distinct frozen paths |
| --- | ---: | ---: |
| `REFLECTION_getOwnPropertyDescriptor` | 803 | 142 |
| `CONSTRUCTOR_PROPERTY` | 210 | 52 |
| `REFLECTION_getPrototypeOf` | 122 | 36 |
| `EVALUATOR_VALUE` | 69 | 28 |
| `AMBIENT_OBJECT_PASSED_TO_CALL` | 68 | 20 |
| `EXECUTION_MODULE_BINDING` | 52 | 10 |
| `REFLECTION_get` | 31 | 9 |
| `REFLECTION_construct` | 24 | 3 |
| `COMPUTED_AMBIENT_PROPERTY` | 18 | 4 |
| `REFLECTION_getOwnPropertyDescriptors` | 8 | 4 |
| `NONLITERAL_MODULE_REFERENCE_CALL` | 1 | 1 |

The strongest exact recurring templates are:

- **TypeScript `__createBinding`: 67 physical initializer sites with identical AST fingerprint `e42bd0b93708e45de4f84c7e765147aee460a4b704e7a6e48a2c7611799458f6`**. Each contributes seven descriptor-origin identities, total **469**. Representative: `node_modules/zod/v4/locales/en.cjs:2:5` [18,489). The code obtains a descriptor, tests presence/`get`/writable/configurable, replaces it with an enumerable getter when needed, and calls `Object.defineProperty`. Metadata checks and the forwarding getter are separate boundaries.
- **esbuild `__copyProps`: 47 physical initializer sites with identical AST fingerprint `f2fb2d11533374de2ed0dff17795493443b8e0150f30257fd8ca22dec64819e8`**. Each contributes three descriptor-origin identities, total **141**. Representative: `node_modules/@tanstack/query-core/build/modern/index.cjs:10:5` [345,705), with alias `node_modules/@tanstack/query-core/build/modern/index.cjs:3:5` [57,107). The helper derives `enumerable` from a descriptor but creates a getter reading `from[key]`. That getter can transport capabilities or execute accessors.

These two templates alone explain **610 of the 803** descriptor-family attributions. Exact normalized AST initializers, fingerprints, per-file SHA, spans and all 114 physical sites are in [recurring families](recurring-helper-families.json). Normalization ignores trivia but preserves node kinds and identifier/string/numeric spelling. A fingerprint proves repeated structure, not receiver safety. The direct syntax census finds 177 constructor accesses, 117 direct descriptor calls, 43 prototype calls, 14 direct Function calls/new expressions, 12 Reflect.get calls, nine descriptor-table calls, and five Reflect.construct calls. These figures cover frozen files only.

The checker explicitly seeds Object/Reflect as reflection, labels selected methods as executor, then labels calls through those methods and their propagated values as executor. `classify` propagates a single bit through aliases, property reads and calls. Consequently a descriptor's `enumerable`, a descriptor presence test and a returned prototype's equality test inherit the same label as executable code. Exact checker definitions: `scripts/boundary-code-execution.mjs:46:9` [1069,1210), `scripts/boundary-code-execution.mjs:53:9` [1219,1396), `scripts/boundary-code-execution.mjs:255:9` [8292,10463).

## Core capability boundary: all seven identities

Frozen `packages/harness/src/capability-boundary.ts` SHA-256: `eaaf55a07ffaf0dee25bf6e007bee39f05f4a8c3cbd9c56accd2a4745f15dc31`.

| Original ordinals | Verified syntax | Diagnosis |
| --- | --- | --- |
| 1 | `packages/harness/src/capability-boundary.ts:595:24` [18005,18048) | Unknown receiver descriptor operation seeded as executor. |
| 2, 3 | `packages/harness/src/capability-boundary.ts:596:7` [18055,18170) | Two occurrences of the local descriptor in presence and data-descriptor checks inherit executor taint; same-line spans remain a candidate set. |
| 4 | `packages/harness/src/capability-boundary.ts:600:51` [18239,18253) | Descriptor value passed recursively to serialization; value content cannot be assumed scalar merely because the descriptor exists. |
| 5 | `packages/harness/src/capability-boundary.ts:628:23` [18968,18996) | Unknown receiver prototype reflection seeded as executor. |
| 6, 7 | `packages/harness/src/capability-boundary.ts:629:5` [19001,19060) | Two uses of prototype in strict equality comparisons inherit executor taint. |

Verified defenses include primitive type checks, array/plain-object branches, depth/node/string/shape budgets, cycle detection, dangerous-key rejection, and rejecting descriptors without a `value` field. The plain-record predicate catches errors and compares the prototype with Object.prototype/null. None of these establish **non-Proxy input**: a Proxy can report a plain prototype and later trap ownKeys/getOwnPropertyDescriptor. Array reads can also invoke index getters. Recursing into descriptor.value guards eventual value type but does not retroactively make earlier traps inert. Native descriptor inspection does not invoke an ordinary receiver getter, but a Proxy trap is a different mechanism.

Thus ordinals 2/3 and 6/7 are verified observational uses for which unconditional executor value taint is overconservative under pristine native semantics. Ordinal 4 requires a descriptor.value capability/content summary. Ordinals 1/5 retain unknown reflection effects until input provenance and intrinsic identity are established. **Zero of seven is accepted here.** A value/effect split can suppress derived executor labels while keeping an origin refusal; that is diagnostic precision, not a whole-file pass.

## Prioritize actual capability boundaries

1. **Keep real evaluator and execution paths refused.** The AST census contains 14 direct Function call/new sites. Examples: `node_modules/fast-json-stringify/index.js:239:23` [6604,6664) consumes generated code; `node_modules/ajv-formats/node_modules/ajv/dist/compile/index.js:89:30` [3710,3789) consumes sourceCode after an optional code-processing callback. Vite obtains an async function constructor at `node_modules/vite/dist/node/module-runner.js:23:23` [665,696) and constructs/invokes it using supplied code at `node_modules/vite/dist/node/module-runner.js:1021:9` [41986,42140). `packages/model-gateway/src/__tests__/bounded-observer-options.test.ts:14:20` [368,922) launches a Node executable through spawnSync with a fixture URL and dynamic arguments. Benign result.status/stdout checks do not remove the launch boundary. These are verified mechanisms, not evidence that they ran or imported the forbidden product.
2. **Keep nonliteral target/resolver and general capability handoffs unknown.** Vite's `node_modules/vite/dist/node/module-runner.js:1024:10` [42391,42407) takes filepath; `node_modules/vite/dist/node/module-runner.js:1073:9` [44182,44274) embeds runtime specifier/importer. Pino's `node_modules/pino/lib/transport.js:273:21` [6956,6994) uses a caller-derived createRequire base and origin. The latter two ordinal families remain PENDING in automatic classification; these exact AST findings do not require inventing their loader alias provenance. Global handoff `apps/web/src/__tests__/app.test.tsx:50:5` [1260,1289) supplies all of globalThis to a callee. A string 'fetch' cannot constrain what that callee can read. Of 68 directly attributed ambient-object argument identities, 58 are vi.spyOn(globalThis, ...); the other ten are descriptor/property operations on globalThis. No matcher/library exemption follows. Process handoffs similarly need the callee/argument contract and remain PENDING when the bounded matcher cannot bind them.
3. **Split constructor observation from construction, without a field exemption.** Fastify's `node_modules/fastify/fastify.js:585:11` [18501,18520) compares constructor.name with AsyncFunction; observational intent is verified, but fn is externally supplied and its constructor property can be accessor-backed. rfdc's `node_modules/rfdc/index.js:9:10` [137,204) actually invokes cur.constructor. A prototype/evaluator chain and an unknown newTarget remain different, unresolved effects.
4. **Reflection and matcher families need specific summaries.** `packages/platform/src/__tests__/controlled-preset-hardening.test.ts:106:23` [3246,3285) is inside a Proxy handler and returns bound methods or arbitrary target fields; the code gives no own-scalar proof. `packages/persistence/src/__tests__/outbox-edge.test.ts:119:47` [3854,3874) passes Function to expect.any: likely intent is type matching, but the callee receives an executor value and cannot be certified from its name. `node_modules/vitest/dist/chunks/test.DNmyFkvJ.js:4105:31` [141754,141779) uses a symbolic ambient slot: even a finite constant symbol proves a key, not inert contents or exclusive ownership. Reflect.construct invokes a target body and observes newTarget; it is not a scalar-read API.

## Bounded implementation proposal

The first change should be a **value/effect split**, not an expanded allowlist. Keep an effect/capability result for the operation, and a separate abstract result shape: primitive, closed own data record, optional descriptor, finite descriptor table, opaque prototype token, known module namespace with export summaries, capability set, or Unknown. A descriptor has guaranteed boolean metadata under native semantics, while its value/get/set fields retain receiver-field capabilities. An opaque prototype can be compared by identity; dereferencing or exporting it returns Unknown unless separately proven.

Extend the existing stable own-scalar proof narrowly: fresh local object allocation, only explicit own scalar data fields, finite literal key union, lexical binding identity, all references audited for writes/aliases/callback escapes, no computed definitions/spreads/__proto__/accessors/methods in the initial rule. Const is a binding constraint, not object immutability. Prove every receiver/key alternative; property absence must not silently fall through to prototypes. A known loader/evaluator field stays tainted even in a perfectly closed object. Alias/assignment transfer must preserve shadowing and assignment-pattern writes.

For native descriptor/prototype summaries, require **trusted intrinsic identity and semantics**, not global spelling or type declarations. With that authority, descriptor booleans and presence tests can be modeled accurately even when an unknown receiver leaves an origin effect. Closed receivers permit full inertness for descriptor lookup or own-data Reflect.get. Unknown receivers, Proxy potential, getter dispatch, arbitrary construction, exported reflection functions, runtime code generation, and unknown module targets remain refused.

Use bounded monotone transfer and fail closed on exhaustion. Proposed implementation limits are 16 keys/union alternatives, depth 64 and 4096 local proof nodes, subject to builder review. A budget limit produces Unknown, never a truncated proof. First integrate in boundary-code-execution.mjs and preserve residual effect refusal through check-product-boundary.mjs. Do not broaden literal module resolution or infer safety from declaration closures.

For the 114 helper sites, metadata can be summarized from exact helper bodies, but clearing the helper as a whole needs exact runtime namespace/export/getter summaries and non-Proxy/mutation provenance for its receivers. Match the supported structure and prove each argument; do not skip a helper name, path, package or fingerprint. The helper name can also be shadowed or rebound, and a module export can be a getter returning a loader.

**Why the current seven core identities cannot all be eliminated from this packet alone:** stableSerialize accepts unknown values; the plain-record check is structural and cannot distinguish a Proxy. The packet contains no enforced pristine-realm policy or trusted recursive JSON-only allocation contract for all callers. Dependencies and callback consumers may mutate globals or carry capabilities. A contract/runtime policy must establish these properties, or a much larger relevant closure must be proven. JSON types, tests/dev labels, Object.freeze and a locally stable alias do not supply that proof. A future contract is a separate reviewed change, not authority granted by this sidecar.

## Required inert regressions and handoff

[Regression matrix](required-inert-regressions.json) contains **33 inert source strings**, all syntax-parsed and never executed. Seven positive/observation cases exercise own scalar descriptors, finite keys, opaque prototype comparisons, descriptor tables, lexical shadowing, the existing own-constructor scalar rule, and retaining an unknown origin while removing a derived executor label. Negative cases cover Proxy traps, getters, descriptor-carried Function/getter capabilities, prototype and async/generator constructor chains, alias mutation/destructuring writes, callback escapes, missing/dynamic keys, symbolic ambient slots, global/process handoffs, unknown constructor metadata, intrinsic rebinding, module getter forwarding, dynamic imports, code generation, process/worker/vm entrypoints, exported reflection aliases, unknown construct targets, false plain-object assumptions and proof budget exhaustion.

These expectations are proposed proof behavior under stated contracts. They are not passing tests of the present checker. The builder should feed strings to AST/checker input only, preserve failing negative outcomes and existing literal-loader positive controls, then bind any eliminated identity to a certificate containing source SHA, AST span, receiver/key/value/effect facts, dependencies, assumptions and exhausted-bound handling. A local focal parser/checker review is sufficient for this diagnostic handoff; this task does not authorize a full suite, acceptance exceptions, current-installed completion or a global pass.

## Exact representative source evidence

Every claimed family has per-ordinal candidate spans/source SHA in [machine classification](family-classification.json), physical AST sites in [census](family-census.json), and helper sites in [recurring families](recurring-helper-families.json). Representative files inspected directly span core, tests and vendor. Full inert source excerpts and enclosing scope are in [source evidence](source-evidence.json).

| Evidence ID | Frozen source path | Line:column | UTF-16 span | Exact source SHA-256 |
| --- | --- | --- | --- | --- |
| core-descriptor | `packages/harness/src/capability-boundary.ts` | 595:24 | [18005,18048) | `eaaf55a07ffaf0dee25bf6e007bee39f05f4a8c3cbd9c56accd2a4745f15dc31` |
| core-descriptor-guards | `packages/harness/src/capability-boundary.ts` | 596:7 | [18055,18170) | `eaaf55a07ffaf0dee25bf6e007bee39f05f4a8c3cbd9c56accd2a4745f15dc31` |
| core-descriptor-value | `packages/harness/src/capability-boundary.ts` | 600:51 | [18239,18253) | `eaaf55a07ffaf0dee25bf6e007bee39f05f4a8c3cbd9c56accd2a4745f15dc31` |
| core-prototype | `packages/harness/src/capability-boundary.ts` | 628:23 | [18968,18996) | `eaaf55a07ffaf0dee25bf6e007bee39f05f4a8c3cbd9c56accd2a4745f15dc31` |
| core-prototype-comparison | `packages/harness/src/capability-boundary.ts` | 629:5 | [19001,19060) | `eaaf55a07ffaf0dee25bf6e007bee39f05f4a8c3cbd9c56accd2a4745f15dc31` |
| core-serializer | `packages/harness/src/capability-boundary.ts` | 537:1 | [15932,18390) | `eaaf55a07ffaf0dee25bf6e007bee39f05f4a8c3cbd9c56accd2a4745f15dc31` |
| core-plain-record | `packages/harness/src/capability-boundary.ts` | 623:1 | [18759,19095) | `eaaf55a07ffaf0dee25bf6e007bee39f05f4a8c3cbd9c56accd2a4745f15dc31` |
| checker-reflection-set | `scripts/boundary-code-execution.mjs` | 46:9 | [1069,1210) | `4c750071ac1347ffa68e6c62e3082e5507cc94571e83089eb7bd21eb7435540a` |
| checker-capability-seeds | `scripts/boundary-code-execution.mjs` | 53:9 | [1219,1396) | `4c750071ac1347ffa68e6c62e3082e5507cc94571e83089eb7bd21eb7435540a` |
| checker-classify | `scripts/boundary-code-execution.mjs` | 255:9 | [8292,10463) | `4c750071ac1347ffa68e6c62e3082e5507cc94571e83089eb7bd21eb7435540a` |
| ts-binding-template | `node_modules/zod/v4/locales/en.cjs` | 2:5 | [18,489) | `ba4269302deae584b126d90f7219e1f2b88242d7f505fc6dcfdf444b4f131587` |
| esbuild-copy-template | `node_modules/@tanstack/query-core/build/modern/index.cjs` | 10:5 | [345,705) | `73464852ad5bc9baf432594dc6237626511ad0f48862f93607a9889186c5618b` |
| esbuild-reflection-alias | `node_modules/@tanstack/query-core/build/modern/index.cjs` | 3:5 | [57,107) | `73464852ad5bc9baf432594dc6237626511ad0f48862f93607a9889186c5618b` |
| proxy-forwarder | `packages/platform/src/__tests__/controlled-preset-hardening.test.ts` | 106:23 | [3246,3285) | `2a404eef7cf995acef37041f8e34fe9f835cd98cfa03d700a33d1cddc06016a0` |
| test-child-launch | `packages/model-gateway/src/__tests__/bounded-observer-options.test.ts` | 14:20 | [368,922) | `48c366857107c6936b38e7634587f1c437e0395895d21656199e091bd5232970` |
| function-matcher-escape | `packages/persistence/src/__tests__/outbox-edge.test.ts` | 119:47 | [3854,3874) | `af64482e9642bb0de42f892118393e4bf8d7affc14d2fa0f37083b03456338df` |
| global-spy-escape | `apps/web/src/__tests__/app.test.tsx` | 50:5 | [1260,1289) | `947fb2514aa0c136530e482c8ac65a200d095fdf501edef2d8107943c4c445d8` |
| fastify-constructor-metadata | `node_modules/fastify/fastify.js` | 585:11 | [18501,18520) | `31a0ebd3ee5fd9f525ccb37c312e3b94757cf53bfa481f41ee364ce75d83c0ae` |
| rfdc-constructor-invocation | `node_modules/rfdc/index.js` | 9:10 | [137,204) | `276defbca175e8293ccaa08fcf1de4d8071c096e606bd8e156976c7550bdb0b7` |
| schema-runtime-compiler | `node_modules/fast-json-stringify/index.js` | 239:23 | [6604,6664) | `7f5a7050f353f4fd0db6ed03a59c2f5408c91910d0c7bbce091d02fabe9cb1cc` |
| ajv-runtime-compiler | `node_modules/ajv-formats/node_modules/ajv/dist/compile/index.js` | 89:30 | [3710,3789) | `05b34da22814f3787bfa3ac68dad59c9047f56e55a607e0a20719ebf5afe69ac` |
| vite-async-constructor | `node_modules/vite/dist/node/module-runner.js` | 23:23 | [665,696) | `c9515eb9c6c77d5212c581b7c9ec45caa3a909e7da3b57b3405546df10a10b92` |
| vite-async-execution | `node_modules/vite/dist/node/module-runner.js` | 1021:9 | [41986,42140) | `c9515eb9c6c77d5212c581b7c9ec45caa3a909e7da3b57b3405546df10a10b92` |
| vite-dynamic-import | `node_modules/vite/dist/node/module-runner.js` | 1024:10 | [42391,42407) | `c9515eb9c6c77d5212c581b7c9ec45caa3a909e7da3b57b3405546df10a10b92` |
| vite-resolver-reference | `node_modules/vite/dist/node/module-runner.js` | 1073:9 | [44182,44274) | `c9515eb9c6c77d5212c581b7c9ec45caa3a909e7da3b57b3405546df10a10b92` |
| pino-resolver-reference | `node_modules/pino/lib/transport.js` | 273:21 | [6956,6994) | `c4857be63a0392312c9010fc222e7216fee0c216ef8dbcf133c61158528ab091` |
| computed-global | `node_modules/vitest/dist/chunks/test.DNmyFkvJ.js` | 4105:31 | [141754,141779) | `f07fc8036b066834143b14748bd70c436a6a2f15f648455af8d3a003a4eafc94` |

## Action evidence and limits

[Finite evidence manifest](evidence-manifest.json) enumerates allowed physical inputs, exact source hashes, executable audit tools, trusted parser hash, and output artifacts. Read/write guards restrict authored audit programs to packet inputs/source/output and output-only writes; the TypeScript symbol host is memory-backed with no module resolution or filesystem fallback. Command-level reads use explicit packet paths. This is a finite manifest/guard audit, **not syscall tracing**, and does not invent a kernel-observed I/O=0 result. Action evidence shows no original fixture execution or requested external-service action. Authority, freeze and diagnostic input hashes are recorded in the manifest. Source contents and literal metadata match before/after.

Next action is the builder's review of the value/effect proposal and regression matrix, retaining 204 PENDING identities and all unresolved origin effects. This report grants no acceptance decision, exception, release or inferred resolution of the historical 1,610.
