import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {buildCoverageReport} from '../runtime/scripts/lib/coverage-gate.mjs';
import {snapshotSchema,verifySnapshots,gateTestReport,testReport} from '../runtime/scripts/hiso-reports.mjs';
import {validateReport,snapshotOutputs} from '../runtime/scripts/hiso-ci.mjs';
import {caseOccurrences} from '../runtime/scripts/hiso-inventory.mjs';
import {contract,contractHash,digest,files,scopeContract,sha,VERSION} from '../runtime/scripts/hiso-contract.mjs';
import {verifyScope,sealFor,aggregateCoverage} from '../runtime/scripts/hiso-verifier.mjs';
const out=path.resolve('..'); const vectors=JSON.parse(fs.readFileSync(path.join(out,'controls/control-vectors.json')));
const critical=JSON.parse(fs.readFileSync('scripts/critical-coverage-manifest.json'));
const result={node:process.versions.node,coverage:[],unit:[],passOnly:[],scopeSkipParity:[]};
const write=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,JSON.stringify(v,null,2)+'\n')};
const admit=(f)=>{try{const value=f();return {admitted:true,value};}catch(e){return {admitted:false,error:e.message};}};
const metrics=(total,covered)=>Object.fromEntries(['statements','branches','functions','lines'].map(k=>[k,{total,covered,skipped:0,pct:total?Number(((covered/total)*100).toFixed(2)):100}]));
function verify(id,report,inventory=[],executed=[],policy='none'){
 const d=path.join(out,'tmp',id+'-consumer'); const p='gate-outputs/'+id+'/report.json'; write(path.join(d,p),report);
 return verifySnapshots({gate:{id,skipPolicy:policy},entry:{outputs:[{path:p}]},directory:d,manifest:{testInventory:inventory,executedTestInventory:executed},expected:{requiredTestIds:inventory.map(t=>t.id)}});
}
for(const vector of vectors.coverage){
 const d=path.join(out,'raw/controls/coverage',vector.id); const paths=[...new Set(critical.groups.flatMap(g=>g.paths))];
 const summary=Object.fromEntries(paths.map(p=>[p,metrics(vector.total,vector.covered)])); summary.total=metrics(vector.total,vector.covered);
 if(vector.mode==='global-covered-exceeds-total')summary.total=metrics(100,101);
 if(vector.mode==='invalid-critical-file')summary[critical.groups.find(g=>g.paths.length>1).paths[0]].branches={total:100,covered:101,skipped:0,pct:101};
 if(vector.mode==='weighted')for(const group of critical.groups){if(group.paths.length>1){const [a,b,...rest]=group.paths;summary[a]=metrics(10,0);summary[b]=metrics(990,950);for(const p of rest)summary[p]=metrics(0,0);}}
 write(path.join(d,'summary.json'),summary); write('coverage/coverage-summary.json',summary);
 const built=buildCoverageReport(summary,critical); write(path.join(d,'function-report.json'),built);
 const cli=spawnSync(process.execPath,['scripts/critical-coverage.mjs'],{encoding:'utf8',env:process.env});
 fs.writeFileSync(path.join(d,'cli.stdout.log'),cli.stdout??'');fs.writeFileSync(path.join(d,'cli.stderr.log'),cli.stderr??'');
 const emitted=JSON.parse(fs.readFileSync('certification/critical-coverage.json'));write(path.join(d,'cli-report.json'),emitted);
 const schema=admit(()=>snapshotSchema(emitted,'coverage-critical'));delete schema.value;
 const snapshot=admit(()=>verify('coverage-critical',emitted));delete snapshot.value;
 const producer=admit(()=>validateReport({id:'coverage-critical',skipPolicy:'governed',artifacts:['certification/critical-coverage.json']},process.cwd(),{}));
 const aggregate=admit(()=>aggregateCoverage([Object.fromEntries(paths.map(p=>[p,summary[p]]))],paths));delete aggregate.value;
 const row={...vector,functionVerdict:built.verdict,cliExitCode:cli.status,emittedVerdict:emitted.verdict,schema,snapshot,producer,aggregate,rawDirectory:path.relative(out,d),branchProjection:emitted.critical.groups.map(g=>({id:g.id,branches:g.metrics.branches}))};
 result.coverage.push(row); write(path.join(d,'observed.json'),row);
}
const row=(file,name)=>({file,name,kind:'COLLECTED_NOT_EXECUTED'});
const required=caseOccurrences([row('tests/own-a.test.js','same'),row('tests/own-a.test.js','same'),row('tests/own-a.test.js','other'),row('tests/own-b.test.js','other file')]);
function native(rows){const names=[...new Set(rows.map(t=>t.file))];return {success:true,numTotalTests:rows.length,numPassedTests:rows.filter(t=>(t.status??'passed')==='passed').length,numFailedTests:0,numFailedTestSuites:0,numPendingTests:rows.filter(t=>['pending','skipped'].includes(t.status)).length,numTodoTests:rows.filter(t=>t.status==='todo').length,testResults:names.map(file=>({name:'/synthetic/'+file,status:'passed',assertionResults:rows.filter(t=>t.file===file).map(t=>({ancestorTitles:[],title:t.name,status:t.status??'passed'}))}))};}
for(const vector of vectors.unit){
 let rows=structuredClone(required),inventory=structuredClone(required);
 if(vector.id==='reordered')rows.reverse();
 if(vector.id==='missing-file')rows=rows.filter(t=>!t.file.endsWith('own-b.test.js'));
 if(vector.id==='renamed-file')rows[3].file='tests/different.test.js';
 if(vector.id==='renamed-name')rows[0].name='changed';
 if(vector.id==='missing-occurrence')rows.splice(1,1);
 if(vector.id==='extra-occurrence')rows.push(structuredClone(rows[0]));
 if(vector.id==='forged-id')inventory[0].id='b'.repeat(64);
 if(vector.id==='forged-occurrence')inventory[0].occurrence=7;
 if(vector.id.includes('pending'))rows[0].status='pending';
 if(vector.id==='governed-todo')rows[0].status='todo';
 const report=native(rows),policy=vector.policy??'none';const d=path.join(out,'raw/controls/unit',vector.id); const working=path.join(d,'working'),snapshotDir=path.join(d,'emission');fs.mkdirSync(snapshotDir,{recursive:true});write(path.join(working,'unit.json'),report);write(path.join(d,'required.json'),inventory);
 const gate={id:'unit',skipPolicy:policy,artifacts:['unit.json']}; const producer=admit(()=>{const skips=validateReport(gate,working,{},'',inventory);const outputs=snapshotOutputs(working,snapshotDir,gate);return {skips,outputs};});
 let executed=[];try{executed=testReport(report,[...new Set(inventory.map(t=>t.file))],policy);}catch{}
 const snapshot=admit(()=>verify('unit',report,inventory,executed,policy));delete snapshot.value;
 const observed={...vector,producer,snapshot,emittedFiles:files(snapshotDir).length,rawDirectory:path.relative(out,d)};result.unit.push(observed);write(path.join(d,'observed.json'),observed);
}
const pkg=JSON.parse(fs.readFileSync('package.json'));const postgres=pkg.scripts['test:postgres'].split(/\s+/).filter(t=>t.endsWith('.test.ts'));
const chaos=fs.readdirSync('packages/chaos/src/__tests__').filter(p=>p.endsWith('.test.ts')).map(p=>'packages/chaos/src/__tests__/'+p);
for(const [id,paths] of [['postgres',postgres],['chaos',chaos]])for(const status of ['passed','pending','todo']){
 const inventory=caseOccurrences(paths.map(p=>row(p,'inert native case'))); const rows=structuredClone(inventory);rows[0].status=status;const report=native(rows);const gate={id,skipPolicy:'none',artifacts:[id+'.json']};const d=path.join(out,'raw/controls/pass-only',id+'-'+status);write(path.join(d,id+'.json'),report);
 const producer=admit(()=>validateReport(gate,d,{},'',inventory));const snapshot=admit(()=>verify(id,report,inventory,[],'none'));delete snapshot.value;
 const observed={id,status,expect:status==='passed'?'PASS':'FAIL',producer,snapshot,rawDirectory:path.relative(out,d)};result.passOnly.push(observed);write(path.join(d,'observed.json'),observed);
}
// Complete output/seal bindings reach verifyScope's unit status check. Other
// snapshots are inert placeholders; no complete-scope PASS is claimed here.
for(const status of ['passed','pending','todo']){
 const scope=scopeContract('harness-neutral');const d=path.join(out,'raw/controls/scope-skip',status);fs.mkdirSync(d,{recursive:true});
 const selected=structuredClone(required);selected[0].status=status;const report=native(selected);const executed=testReport(report,[...new Set(required.map(t=>t.file))],'governed');const H='a'.repeat(64);
 const m={schemaVersion:1,contract:VERSION,contractHash,scope:scope.id,owner:scope.owner,candidateId:H,sourceSha256:H,sourceMatch:true,sourceAfterSha256:H,variantSourceMatch:true,variantSourceAfterSha256:H,runId:'own-inert-parity',attempt:'1',derivedVariantId:H,derivedMappingHash:H,ownerMappingHash:H,lockSha256:H,mode:'LOCAL_CONTENT_HASHES',startedAt:'2026-10-05T00:00:00.000Z',finishedAt:'2026-10-05T00:00:01.000Z',versions:{node:process.versions.node},testInventory:required,testInventoryHash:digest(required),testInventoryStatus:'COLLECTED_NOT_EXECUTED',executedTestInventory:executed,executedTestInventoryHash:digest(executed),coverage:{'inert.ts':metrics(10,10)},gates:[],seals:[],status:'PASS'};
 for(const g of scope.gates){const log='inert scope binding '+g.id+'\n';const lp='gates/'+g.id+'.log';fs.mkdirSync(path.dirname(path.join(d,lp)),{recursive:true});fs.writeFileSync(path.join(d,lp),log);const outputs=[];
  for(const p of g.artifacts??[]){const op='gate-outputs/'+g.id+'/'+p;write(path.join(d,op),g.id==='unit'?report:{inert:true});const b=fs.readFileSync(path.join(d,op));outputs.push({path:op,sha256:sha(b),size:b.length});}
  const e={schemaVersion:1,id:g.id,command:g.command,status:'PASS',exitCode:0,cause:null,scope:scope.id,runId:m.runId,candidateId:H,startedAt:m.startedAt,finishedAt:m.finishedAt,skipped:g.id==='unit'&&status!=='passed'?1:0,outputs,logSha256:sha(log)};m.gates.push(e);m.seals.push(sealFor(m,e));
 }
 m.outputs=files(d);write(path.join(d,'manifest.json'),m);const expected={...m,requiredTestIds:required.map(t=>t.id)};write(path.join(out,'raw/controls/scope-skip',status+'-expected.json'),expected);
 const observation=admit(()=>verifyScope({manifest:m,directory:d,expected}));delete observation.value;
 result.scopeSkipParity.push({status,originalPolicy:scope.gates.find(g=>g.id==='unit').skipPolicy,observation,rawDirectory:path.relative(out,d),limitation:'Reaches unit admission with complete content bindings; subsequent unrelated snapshots are placeholders, so all-passed control reaches an unrelated placeholder snapshot instead of full scope PASS.'});
}
write(path.join(out,'raw/controls/results.json'),result);console.log(JSON.stringify({coverage:result.coverage.map(x=>({id:x.id,expected:x.expect,actual:x.emittedVerdict,exit:x.cliExitCode,schema:x.schema.admitted,snapshot:x.snapshot.admitted})),unit:result.unit.map(x=>({id:x.id,expected:x.expect,producer:x.producer.admitted,snapshot:x.snapshot.admitted,emission:x.emittedFiles})),passOnly:result.passOnly,scopeSkipParity:result.scopeSkipParity}));
