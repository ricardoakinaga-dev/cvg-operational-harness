import fs from 'node:fs';import path from 'node:path';import {spawnSync} from 'node:child_process';
import {contract,contractHash,digest,sha,sourceFiles,VERSION} from '../runtime/scripts/hiso-contract.mjs';
import {CI_BAR_GATES,CI_BAR_VERSION} from '../runtime/scripts/ci-bar-contract.mjs';
import {createGateSeal,encodeGateSeal,gateStepId,verifyGateSeals,runnerIdentity} from '../runtime/scripts/ci-bar-provenance.mjs';
import {caseOccurrences} from '../runtime/scripts/hiso-inventory.mjs';
import {gateTestReport,verifySnapshots} from '../runtime/scripts/hiso-reports.mjs';
const out=path.resolve('../raw/legacy-emission');fs.mkdirSync(out,{recursive:true});
const write=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,JSON.stringify(v,null,2)+'\n')};
const inventoryProof=JSON.parse(fs.readFileSync('../raw/native-inventory.json'));const H='a'.repeat(64),candidate=digest(sourceFiles(process.cwd()));
const focused=JSON.parse(fs.readFileSync('../raw/focused.json'));const first=focused.testResults[0];
const required=caseOccurrences(first.assertionResults.slice(0,3).map(t=>({file:path.relative(process.cwd(),first.name).split(path.sep).join('/'),name:[...t.ancestorTitles,t.title].join(' > '),kind:'COLLECTED_NOT_EXECUTED'})));
// These are finite in-memory contract fixtures. No CI execution, attestation,
// provider, database, application evaluator or offensive code runs.
for(const scenario of ['complete-unit','omitted-unit-case']){
 const base=path.join(out,scenario),original=path.join(base,'legacy-input'),target=path.join(base,'emitted');fs.mkdirSync(original,{recursive:true});
 const syntheticEnv={...process.env,GITHUB_RUN_ID:'777',GITHUB_RUN_ATTEMPT:'1',GITHUB_SHA:'f'.repeat(40),GITHUB_REPOSITORY:'synthetic/fixture',GITHUB_WORKFLOW:'Inert fixture',CI_RUN_ID:'run-777-1',GITHUB_OUTPUT:path.join(base,'step-output.txt'),HISO_PG_VERSION_OUTPUT:path.join(base,'pg.json')};
 const github=runnerIdentity(syntheticEnv);const state={runId:'run-777-1',candidateId:H,nodeVersion:process.versions.node,gates:[]};const rows=scenario==='complete-unit'?required:required.slice(1);
 const report={success:true,numTotalTests:rows.length,numPassedTests:rows.length,numFailedTests:0,numFailedTestSuites:0,testResults:[{name:path.join(process.cwd(),required[0].file),status:'passed',assertionResults:rows.map(t=>({ancestorTitles:[],title:t.name,status:'passed'}))}]};
 fs.writeFileSync(path.join(original,'runtime.txt'),'inert fixture node='+process.versions.node+'\n');
 for(const gate of CI_BAR_GATES.filter(g=>g.id!=='artifacts')){
  const log='inert fixture receipt; no gate execution: '+gate.id+'\n';const lp='gates/'+gate.id+'.log';fs.mkdirSync(path.dirname(path.join(original,lp)),{recursive:true});fs.writeFileSync(path.join(original,lp),log);
  const entry={id:gate.id,status:'PASS',exitCode:0,runId:state.runId,candidateId:H,nodeVersion:state.nodeVersion,outputFailures:[],log:lp,logSha256:sha(log)};
  for(const artifact of gate.artifacts??[])write(path.join(original,'gate-outputs',gate.id,artifact),gate.id==='unit'?report:{inertPlaceholder:true});
  if(gate.id==='e2e')Object.assign(entry,{executionId:'inert-execution',testCount:1,testInventorySha256:H,artifactSha256:Object.fromEntries(gate.artifacts.map(p=>[p,sha(fs.readFileSync(path.join(original,'gate-outputs',gate.id,p)))]))});
  state.gates.push(entry);
 }
 const steps=Object.fromEntries(CI_BAR_GATES.filter(g=>g.id!=='artifacts').map(g=>[gateStepId(g.id),{outcome:'success',conclusion:'success',outputs:{seal:encodeGateSeal(createGateSeal({id:g.id,state,artifactDir:original,github}))}}]));
 const seals=verifyGateSeals({state,artifactDir:original,steps,github});
 const expected={schemaVersion:1,contract:VERSION,contractHash,candidateId:candidate,sourceSha256:candidate,ownerMappingHash:H,runId:'run-777-1',attempt:'1',sha:'f'.repeat(40),startedAt:'2026-10-05T00:00:00.000Z',coveragePaths:inventoryProof.coverage,coverageSources:inventoryProof.coverageSources,testInventory:required,scopes:{}};
 for(const s of contract.scopes)expected.scopes[s.id]={schemaVersion:1,contract:VERSION,contractHash,scope:s.id,candidateId:candidate,sourceSha256:candidate,ownerMappingHash:H,runId:expected.runId,attempt:'1',derivedVariantId:candidate,derivedMappingHash:H,lockSha256:H,testInventoryHash:digest(required),requiredTestIds:required.map(t=>t.id),coveragePaths:expected.coveragePaths,coverageSources:expected.coverageSources};
 const legacy={contract:CI_BAR_VERSION,verdict:'PASS',provenance:{mode:'GITHUB_STEP_OUTPUT_SEALED'},runId:state.runId,candidateId:H,npmVersion:'inert-fixture',startedAt:expected.startedAt,gates:[...state.gates,{id:'artifacts',status:'PASS'}]};
 write(path.join(original,'ci-bar-state.json'),state);write(path.join(original,'ci-bar-manifest.json'),legacy);write(path.join(base,'expected.json'),expected);write(path.join(base,'pg.json'),{schemaVersion:1,status:'PASS',version:160000,runId:state.runId,candidateId:H});write(path.join(base,'steps.json'),steps);
 syntheticEnv.CI_BAR_STEPS_JSON=JSON.stringify(steps);syntheticEnv.LEGACY_MANIFEST_SHA256=sha(fs.readFileSync(path.join(original,'ci-bar-manifest.json')));
 const args=['scripts/hiso-import-legacy.mjs',original,path.join(base,'expected.json'),target];const cli=spawnSync(process.execPath,args,{env:syntheticEnv,encoding:'utf8'});fs.writeFileSync(path.join(base,'cli.stdout.log'),cli.stdout??'');fs.writeFileSync(path.join(base,'cli.stderr.log'),cli.stderr??'');
 const m=JSON.parse(fs.readFileSync(path.join(target,'manifest.json')));let unitConsumer;
 try{verifySnapshots({gate:contract.scopes.find(s=>s.id==='transition-regression').gates.find(g=>g.id==='unit'),entry:m.gates.find(g=>g.id==='unit'),directory:target,manifest:m,expected:expected.scopes['transition-regression']});unitConsumer={admitted:true};}catch(e){unitConsumer={admitted:false,error:e.message};}
 write(path.join(base,'observation.json'),{scenario,command:[process.execPath,...args],exitCode:cli.status,sealFailures:seals.failures,verifiedGateCount:seals.verifiedGateCount,requiredCases:required.length,reportedCases:rows.length,importedStatus:m.status,emittedUnitSnapshot:fs.existsSync(path.join(target,'gate-outputs/unit/certification/unit-test-report.json')),unitConsumer,scope:'Only importer/unit admission is tested. Other native gate snapshots are intentionally inert placeholders, so this does not establish a real CI/legacy/aggregate PASS.'});
 console.log(JSON.stringify({scenario,exitCode:cli.status,importedStatus:m.status,requiredCases:required.length,reportedCases:rows.length,unitConsumer}));
}
