import fs from 'node:fs';import path from 'node:path';
import {buildCoverageReport} from '../runtime/scripts/lib/coverage-gate.mjs';
import {snapshotSchema,verifySnapshots} from '../runtime/scripts/hiso-reports.mjs';
import {validateReport,snapshotOutputs} from '../runtime/scripts/hiso-ci.mjs';
import {files} from '../runtime/scripts/hiso-contract.mjs';
const out=path.resolve('../raw/extra-controls-r2');fs.mkdirSync(out,{recursive:true});const write=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,JSON.stringify(v,null,2)+'\n')};
const observe=fn=>{try{fn();return {admitted:true};}catch(e){return {admitted:false,error:e.message};}};
const critical=JSON.parse(fs.readFileSync('scripts/critical-coverage-manifest.json'));
const metrics=()=>Object.fromEntries(['statements','lines','branches','functions'].map(k=>[k,{total:100000,covered:94999,skipped:0,pct:95}]));
const summary=Object.fromEntries([...new Set(critical.groups.flatMap(g=>g.paths))].map(p=>[p,metrics()]));summary.total=metrics();const report=buildCoverageReport(summary,critical);report.verdict='PASS';report.failures=[];report.critical.pass=true;report.critical.failures=[];
const d=path.join(out,'rounded-forged-pass');write(path.join(d,'input.json'),report);const expected={id:'rounded-forged-pass',expect:'REJECT',schema:observe(()=>snapshotSchema(report,'coverage-critical'))};
const ep='gate-outputs/coverage-critical/report.json';write(path.join(d,ep),report);expected.snapshot=observe(()=>verifySnapshots({gate:{id:'coverage-critical',skipPolicy:'governed'},entry:{outputs:[{path:ep}]},directory:d,manifest:{},expected:{}}));expected.producer=observe(()=>validateReport({id:'coverage-critical',skipPolicy:'governed',artifacts:['input.json']},d,{}));write(path.join(d,'observation.json'),expected);
const pg=[];
for(const version of [160000,169999,159999,170000,160000.5,0,9007199254740992,'160000',null]){
 const dir=path.join(out,'pg-'+typeof version+'-'+String(version));const report={schemaVersion:1,status:'PASS',version,runId:'own-json-only',candidateId:'a'.repeat(64),synthetic:true,command:'SHOW server_version_num'};write(path.join(dir,'pg.json'),report);const gate={id:'postgres-version',skipPolicy:'none',artifacts:['pg.json']};const binding={runId:report.runId,candidateId:report.candidateId};const emissions=path.join(dir,'emissions');fs.mkdirSync(emissions,{recursive:true});
 const producer=observe(()=>{validateReport(gate,dir,binding);snapshotOutputs(dir,emissions,gate)});const schema=observe(()=>snapshotSchema(report,gate.id));const p='gate-outputs/postgres-version/pg.json';write(path.join(dir,p),report);const snapshot=observe(()=>verifySnapshots({gate,entry:{outputs:[{path:p}]},directory:dir,manifest:binding,expected:{}}));const result={version,expected:Number.isSafeInteger(version)&&version>=160000&&version<170000?'PASS':'REJECT',producer,schema,snapshot,emittedFiles:files(emissions).length};pg.push(result);write(path.join(dir,'observation.json'),result);
}
write(path.join(out,'results.json'),{forgedRawThreshold:expected,postgresVersionJsonOnly:pg});console.log(JSON.stringify({forgedRawThreshold:expected,postgresVersionJsonOnly:pg}));
