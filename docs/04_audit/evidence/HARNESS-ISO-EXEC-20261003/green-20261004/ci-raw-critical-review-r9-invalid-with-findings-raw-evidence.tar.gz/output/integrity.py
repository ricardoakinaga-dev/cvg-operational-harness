import os,json,hashlib,stat
from pathlib import Path
p=Path(__file__).resolve().parent.parent; s=p/'source'
def collect(root):
 data={}
 for base,dirs,files in os.walk(root,followlinks=False):
  for name in ['.']+dirs+files:
   f=Path(base) if name=='.' else Path(base)/name
   rel=str(f.relative_to(root)); st=f.lstat()
   row={'mode':st.st_mode,'uid':st.st_uid,'gid':st.st_gid,'size':st.st_size,'mtimeNs':st.st_mtime_ns,'ctimeNs':st.st_ctime_ns,'inode':st.st_ino,'device':st.st_dev,'nlink':st.st_nlink}
   if f.is_symlink(): row.update(kind='symlink',target=os.readlink(f),sha256=hashlib.sha256(os.readlink(f).encode()).hexdigest())
   elif f.is_file():
    h=hashlib.sha256()
    with f.open('rb') as stream:
     for block in iter(lambda:stream.read(1024*1024),b''): h.update(block)
    row.update(kind='file',sha256=h.hexdigest())
   else: row['kind']='directory'
   data[rel]=row
 return data
if __name__=='__main__':
 import sys
 label=sys.argv[1]; data=collect(s)
 inputs={x:collect(p)[x] for x in []}
 for x in ['authority.json','freeze.json','frozen-inventory.json']:
  f=p/x; st=f.stat(); inputs[x]={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'mtimeNs':st.st_mtime_ns,'ctimeNs':st.st_ctime_ns,'size':st.st_size}
 result={'source':data,'packetInputs':inputs}
 (p/'output'/f'integrity-{label}.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
 frozen=json.loads((p/'frozen-inventory.json').read_text()); diffs=[]
 for name,row in frozen.items():
  actual=data.get(name)
  if not actual: diffs.append({'path':name,'issue':'missing'}); continue
  for key in ['kind','sha256','target']:
   if key in row and (row[key] if not (key=='kind' and row[key]=='link') else 'symlink')!=actual.get(key): diffs.append({'path':name,'key':key,'expected':row[key],'actual':actual.get(key)})
  if 'bytes' in row and row['bytes']!=actual['size']: diffs.append({'path':name,'key':'bytes'})
 extra=[x for x,row in data.items() if row['kind']!='directory' and x not in frozen]
 summary={'inventoryEntries':len(frozen),'actualNonDirectories':sum(r['kind']!='directory' for r in data.values()),'directories':sum(r['kind']=='directory' for r in data.values()),'dependencyEntries':sum(x.startswith('node_modules/') and r['kind']!='directory' for x,r in data.items()),'nonDependencyEntries':sum(not x.startswith('node_modules/') and r['kind']!='directory' for x,r in data.items()),'freezeInventoryShaMatch':hashlib.sha256((p/'frozen-inventory.json').read_bytes()).hexdigest()==json.loads((p/'freeze.json').read_text())['inventorySha256'],'differences':diffs,'extras':extra}
 if label=='after':
  before=json.loads((p/'output'/'integrity-before.json').read_text()); summary['beforeAfterDifferences']=[k for k in set(before['source'])|set(data) if before['source'].get(k)!=data.get(k)]; summary['packetInputsUnchanged']=before['packetInputs']==inputs
 (p/'output'/f'integrity-{label}-summary.json').write_text(json.dumps(summary,indent=2)+'\n'); print(json.dumps(summary))
