import fs from 'node:fs'
import path from 'node:path'
import {
  canonical,
  contract,
  contractHash,
  digest,
  dispatch,
  exact,
  files,
  requireThat,
  safePath,
  scopeContract,
  sha,
  VERSION
} from './hiso-contract.mjs'
import { envelope, verifySnapshots } from './hiso-reports.mjs'
import { isRemoteTrust } from './hiso-remote-trust.mjs'
import {
  expectedShape,
  manifestShape,
  producerShape,
  record
} from './hiso-validation.mjs'

const keys = [
  'schemaVersion',
  'contract',
  'contractHash',
  'scope',
  'candidateId',
  'sourceSha256',
  'runId',
  'attempt',
  'derivedVariantId',
  'derivedMappingHash',
  'ownerMappingHash'
]
export function sealFor(manifest, entry) {
  return {
    schemaVersion: 1,
    kind: 'hiso-gate-content-seal-v1',
    ...Object.fromEntries(keys.map((k) => [k, manifest[k]])),
    gateId: entry.id,
    entrySha256: digest(entry)
  }
}

export function verifyScope({ manifest, directory, expected, producer }) {
  envelope(manifest, 'manifest')
  envelope(expected, 'expected-scope')
  if (producer) envelope(producer, 'producer')
  for (const seal of manifest.seals ?? []) envelope(seal, 'seal')
  for (const gate of manifest.gates ?? []) envelope(gate, 'gate')
  dispatch(manifest.contract)
  requireThat(
    manifest.contract === VERSION && manifest.contractHash === contractHash,
    'contract_hash'
  )
  const s = scopeContract(manifest.scope)
  for (const k of keys) requireThat(manifest[k] === expected[k], `binding:${k}`)
  requireThat(manifest.owner === s.owner, 'owner_binding')
  requireThat(
    manifest.sourceMatch === true &&
      manifest.sourceAfterSha256 === expected.sourceSha256 &&
      manifest.variantSourceMatch === true &&
      manifest.variantSourceAfterSha256 === expected.derivedVariantId,
    'source_after_binding'
  )
  requireThat(manifest.status === 'PASS', `scope_not_pass:${manifest.scope}`)
  exact(
    manifest.gates.map((g) => g.id),
    s.gates.map((g) => g.id),
    'gate_inventory'
  )
  exact(
    manifest.seals.map((g) => g.gateId),
    s.gates.map((g) => g.id),
    'seal_inventory'
  )
  const actual = files(directory).filter((f) => f.path !== 'manifest.json')
  requireThat(
    canonical(actual) === canonical(manifest.outputs),
    'complete_output_inventory'
  )
  for (const gate of s.gates) {
    const entry = manifest.gates.find((g) => g.id === gate.id)
    requireThat(
      entry.status === 'PASS' && entry.exitCode === 0 && entry.cause === null,
      `gate_not_pass:${gate.id}`
    )
    requireThat(
      canonical(entry.command) === canonical(gate.command),
      `command_binding:${gate.id}`
    )
    requireThat(
      entry.runId === manifest.runId &&
        entry.scope === manifest.scope &&
        entry.candidateId === manifest.candidateId,
      `gate_binding:${gate.id}`
    )
    requireThat(
      entry.startedAt >= manifest.startedAt &&
        entry.finishedAt >= entry.startedAt &&
        entry.finishedAt <= manifest.finishedAt,
      'gate_time_binding'
    )
    requireThat(
      canonical(manifest.seals.find((g) => g.gateId === gate.id)) ===
        canonical(sealFor(manifest, entry)),
      `seal_binding:${gate.id}`
    )
    const log = manifest.outputs.find((f) => f.path === `gates/${gate.id}.log`)
    requireThat(log && log.sha256 === entry.logSha256, 'log_binding')
    exact(
      entry.outputs.map((f) => f.path),
      (gate.artifacts ?? []).map((p) => `gate-outputs/${gate.id}/${p}`),
      `gate_output_inventory:${gate.id}`
    )
    for (const output of entry.outputs)
      requireThat(
        manifest.outputs.some((f) => canonical(f) === canonical(output)),
        `snapshot_binding:${gate.id}:${output.path}`
      )
    for (const output of entry.outputs)
      requireThat(output.size > 0, `empty_snapshot:${gate.id}`)
    if (gate.skipPolicy === 'none')
      requireThat(entry.skipped === 0, `skip_policy:${gate.id}`)
  }
  requireThat(
    manifest.testInventoryHash === digest(manifest.testInventory) &&
      manifest.testInventoryHash === expected.testInventoryHash,
    'test_inventory_binding'
  )
  requireThat(
    manifest.testInventoryStatus === 'COLLECTED_NOT_EXECUTED',
    'test_inventory_not_collected'
  )
  requireThat(
    manifest.executedTestInventoryHash ===
      digest(manifest.executedTestInventory),
    'executed_test_inventory_binding'
  )
  const unitGate = s.gates.find((g) => g.id === 'unit')
  if (unitGate) {
    requireThat(
      manifest.executedTestInventory.every(
        (t) =>
          t.status === 'passed' ||
          (unitGate.skipPolicy === 'governed' &&
            ['pending', 'skipped', 'todo'].includes(t.status))
      ),
      'unit_execution_status'
    )
    requireThat(
      manifest.gates.find((g) => g.id === 'unit').skipped ===
        manifest.executedTestInventory.filter((t) => t.status !== 'passed')
          .length,
      'unit_execution_skip_count'
    )
    exact(
      manifest.executedTestInventory.map((t) =>
        digest({ file: t.file, name: t.name, occurrence: t.occurrence })
      ),
      expected.requiredTestIds,
      'unit_execution_inventory'
    )
  }
  if (s.gates.some((g) => g.id === 'coverage'))
    requireThat(
      manifest.coverage && Object.keys(manifest.coverage).length > 0,
      'coverage_missing'
    )
  for (const gate of s.gates) {
    envelope(
      manifest.seals.find((s) => s.gateId === gate.id),
      'seal'
    )
    verifySnapshots({
      gate,
      entry: manifest.gates.find((g) => g.id === gate.id),
      directory,
      manifest,
      expected
    })
  }
  if (s.gates.some((g) => g.id === 'coverage'))
    aggregateCoverage(
      [manifest.coverage],
      Object.keys(manifest.coverage),
      expected.coverageSources?.filter((s) =>
        Object.hasOwn(manifest.coverage, s.path)
      )
    )
  requireThat(manifest.lockSha256 === expected.lockSha256, 'lock_binding')
  requireThat(/^22\./.test(manifest.versions.node), 'node22')
  if (producer) {
    envelope(producer, 'producer')
    requireThat(manifest.mode === 'GITHUB_JOB_OUTPUT_BOUND', 'remote_mode')
    requireThat(
      producer.result === 'success' &&
        producer.manifestSha256 ===
          sha(fs.readFileSync(path.join(directory, 'manifest.json'))) &&
        producer.sealSetSha256 === digest(manifest.seals),
      'producer_outputs'
    )
  } else
    requireThat(manifest.mode === 'LOCAL_CONTENT_HASHES', 'local_not_remote')
  return true
}

const metrics = ['statements', 'branches', 'functions', 'lines']
export function aggregateCoverage(reports, expectedPaths, sources) {
  const merged = new Map()
  for (const report of reports)
    for (const [p, entry] of Object.entries(report)) {
      if (p === 'total') continue
      safePath(p)
      if (merged.has(p))
        requireThat(
          canonical(merged.get(p)) === canonical(entry),
          `coverage_duplicate_conflict:${p}`
        )
      else merged.set(p, entry)
    }
  exact([...merged.keys()], expectedPaths, 'coverage_source_inventory')
  const totals = Object.fromEntries(
    metrics.map((k) => [k, { total: 0, covered: 0, skipped: 0, pct: 0 }])
  )
  for (const [p, e] of merged)
    for (const k of metrics) {
      const v = e[k]
      requireThat(
        v &&
          Number.isSafeInteger(v.total) &&
          Number.isSafeInteger(v.covered) &&
          Number.isSafeInteger(v.skipped) &&
          v.total >= 0 &&
          v.covered >= 0 &&
          v.covered <= v.total &&
          v.skipped === 0,
        `coverage_denominator:${p}:${k}`
      )
      totals[k].total += v.total
      totals[k].covered += v.covered
    }
  requireThat(
    totals.statements.total > 0 && totals.lines.total > 0,
    'coverage_empty_executable_denominator'
  )
  if (sources) {
    exact(
      sources.map((s) => s.path),
      expectedPaths,
      'coverage_canonical_sources'
    )
    for (const source of sources) {
      requireThat(
        /^[a-f0-9]{64}$/.test(source.sha256) &&
          typeof source.executable === 'boolean',
        'coverage_source_identity'
      )
      if (source.executable)
        requireThat(
          merged.get(source.path).statements.total > 0 &&
            merged.get(source.path).lines.total > 0,
          `coverage_executable_zero:${source.path}`
        )
    }
  }
  for (const k of metrics) {
    const t = totals[k]
    requireThat(t.total > 0, `coverage_empty_global_denominator:${k}`)
    requireThat(
      Number.isSafeInteger(t.total) && Number.isSafeInteger(t.covered),
      `coverage_sum_overflow:${k}`
    )
    t.pct = (100 * t.covered) / t.total
  }
  return {
    sources: [...merged.keys()].sort(),
    totals,
    pass: metrics.every((k) => totals[k].pct >= contract.coverage.thresholds[k])
  }
}

export function verifySecurity(report, expected) {
  requireThat(
    report?.status === 'PASS' && report.workflow === contract.security.workflow,
    'security_workflow'
  )
  envelope(report, 'security')
  requireThat(
    report.sha === expected.sha &&
      report.runId === expected.securityRunId &&
      report.attempt === expected.securityAttempt,
    'security_run_binding'
  )
  exact(
    report.jobs.map((j) => j.name),
    contract.security.requiredJobs,
    'security_jobs'
  )
  for (const job of report.jobs)
    requireThat(
      job.status === 'completed' &&
        job.conclusion === 'success' &&
        Number.isSafeInteger(job.id) &&
        job.id > 0,
      'security_job_not_pass'
    )
  requireThat(
    Number.isSafeInteger(report.workflowId) &&
      report.workflowId > 0 &&
      typeof report.collectedAt === 'string' &&
      Number.isFinite(Date.parse(report.collectedAt)) &&
      report.collectedAt >= expected.startedAt,
    'security_freshness'
  )
}

export function verifyProvenance(
  provenance,
  expected,
  required = contract.requiredGlobal.filter((x) => x !== 'security')
) {
  envelope(provenance, 'provenance')
  exact(
    provenance.checks?.map((c) => c.id),
    required,
    'global_provenance_inventory'
  )
  requireThat(
    provenance.mode === 'INDEPENDENT_GITHUB_ATTESTATION_VERIFIED' &&
      provenance.sourceSha === expected.sha &&
      provenance.runId === expected.runId &&
      provenance.attempt === expected.attempt,
    'provenance_binding'
  )
  for (const c of provenance.checks) {
    record(c, 'provenance-check')
    requireThat(
      c.status === 'PASS' &&
        typeof c.evidenceSha256 === 'string' &&
        /^[0-9a-f]{64}$/.test(c.evidenceSha256),
      `provenance_not_pass:${c.id}`
    )
  }
}

// Local content validation is separate from external trust. Neither this
// preflight nor synthetic inputs can grant remote PASS or an attestation.
export function preflightScopes({ scopes, expected, producerResults }) {
  expectedShape(expected)
  record(producerResults, 'producers')
  exact(
    Object.keys(producerResults),
    contract.scopes.map((s) => s.id),
    'producer_inventory'
  )
  requireThat(Array.isArray(scopes), 'type:scopes')
  exact(
    scopes.map((s) => s.manifest?.scope),
    contract.scopes.map((s) => s.id),
    'aggregate_scopes'
  )
  for (const s of scopes) {
    manifestShape(s.manifest)
    const id = s.manifest.scope,
      e = expected.scopes[id],
      p = producerResults[id]
    producerShape(p)
    for (const key of [
      'candidateId',
      'sourceSha256',
      'ownerMappingHash',
      'runId',
      'attempt',
      'contract',
      'contractHash'
    ])
      requireThat(e[key] === expected[key], `aggregate_common_binding:${key}`)
    requireThat(
      canonical(e.coveragePaths) === canonical(expected.coveragePaths) &&
        canonical(e.coverageSources) === canonical(expected.coverageSources) &&
        e.testInventoryHash === digest(expected.testInventory) &&
        canonical(s.manifest.testInventory) ===
          canonical(expected.testInventory),
      'aggregate_inventory_binding'
    )
    verifyScope({ ...s, expected: e, producer: p })
  }
  const coverage = aggregateCoverage(
    contract.coverage.owners.map((id) => {
      const m = scopes.find((s) => s.manifest.scope === id).manifest
      requireThat(m.coverage, 'coverage_missing')
      return m.coverage
    }),
    expected.coveragePaths,
    expected.coverageSources
  )
  requireThat(coverage.pass, 'coverage_threshold')
}

export function preflightRemoteEvidence(input) {
  preflightScopes(input)
  const { security, provenance, expected } = input
  envelope(security, 'security')
  requireThat(
    Number.isSafeInteger(expected.securityRunId) &&
      expected.securityRunId > 0 &&
      Number.isSafeInteger(expected.securityAttempt) &&
      expected.securityAttempt > 0,
    'type:expected:security_context'
  )
  requireThat(
    Number.isSafeInteger(security.runId) &&
      security.runId > 0 &&
      Number.isSafeInteger(security.attempt) &&
      security.attempt > 0 &&
      Array.isArray(security.jobs),
    'type:security'
  )
  verifySecurity(security, expected)
  verifyProvenance(provenance, expected)
}

export function aggregate({
  scopes,
  expected,
  security,
  provenance,
  producerResults,
  mode = 'local',
  trust
}) {
  const failures = []
  const capture = (fn) => {
    try {
      fn()
    } catch (e) {
      failures.push(e.message)
    }
  }
  capture(() => {
    envelope(expected, 'expected')
    requireThat(mode === 'local' || mode === 'remote', 'trust_mode')
    if (mode === 'remote') {
      requireThat(isRemoteTrust(trust), 'external_trust_required')
      exact(
        Object.keys(producerResults ?? {}),
        contract.scopes.map((s) => s.id),
        'producer_inventory'
      )
      requireThat(
        canonical(trust.producers) === canonical(producerResults),
        'external_producer_binding'
      )
      requireThat(
        trust.sourceSha === expected.sha &&
          trust.runId === expected.runId &&
          trust.attempt === expected.attempt,
        'external_run_binding'
      )
      requireThat(
        canonical(trust.security) === canonical(security) &&
          canonical(trust.provenance) === canonical(provenance),
        'external_reports_binding'
      )
    } else
      requireThat(
        !producerResults || Object.keys(producerResults).length === 0,
        'local_remote_producers'
      )
  })
  capture(() =>
    exact(
      scopes.map((s) => s.manifest.scope),
      contract.scopes.map((s) => s.id),
      'aggregate_scopes'
    )
  )
  for (const s of scopes)
    capture(() => {
      const e = expected.scopes[s.manifest.scope]
      requireThat(e, 'unregistered_scope')
      requireThat(
        e.candidateId === expected.candidateId &&
          e.sourceSha256 === expected.sourceSha256 &&
          e.ownerMappingHash === expected.ownerMappingHash,
        'aggregate_common_binding'
      )
      verifyScope({
        ...s,
        expected: e,
        producer:
          mode === 'remote' ? producerResults?.[s.manifest.scope] : undefined
      })
    })
  let coverage = null
  capture(() => {
    coverage = aggregateCoverage(
      contract.coverage.owners.map((owner) => {
        const m = scopes.find((s) => s.manifest.scope === owner)?.manifest
        requireThat(m?.coverage, 'coverage_missing')
        return m.coverage
      }),
      expected.coveragePaths,
      expected.coverageSources
    )
    requireThat(coverage.pass, 'coverage_threshold')
  })
  capture(() => verifySecurity(security, expected))
  capture(() => {
    exact(
      provenance?.checks?.map((c) => c.id),
      contract.requiredGlobal.filter((x) => x !== 'security'),
      'global_provenance_inventory'
    )
    envelope(provenance, 'provenance')
    requireThat(
      provenance.mode === 'INDEPENDENT_GITHUB_ATTESTATION_VERIFIED' &&
        provenance.sourceSha === expected.sha &&
        provenance.runId === expected.runId &&
        provenance.attempt === expected.attempt,
      'provenance_binding'
    )
    for (const c of provenance.checks)
      requireThat(
        c.status === 'PASS' && /^[0-9a-f]{64}$/.test(c.evidenceSha256),
        `provenance_not_pass:${c.id}`
      )
  })
  return {
    schemaVersion: 1,
    contract: VERSION,
    contractHash,
    candidateId: expected.candidateId,
    sourceSha256: expected.sourceSha256,
    ownerMappingHash: expected.ownerMappingHash,
    runId: expected.runId,
    attempt: expected.attempt,
    mode,
    remoteCiPass: mode === 'remote' && failures.length === 0,
    externalGates:
      mode === 'local' ? 'NOT_RUN' : failures.length ? 'FAIL' : 'PASS',
    status: failures.length
      ? 'FAIL'
      : mode === 'remote'
        ? 'PASS'
        : 'LOCAL_VERIFIED',
    failures,
    coverage,
    manifestDigests: scopes.map((s) => ({
      scope: s.manifest.scope,
      sha256: sha(fs.readFileSync(path.join(s.directory, 'manifest.json')))
    }))
  }
}
