import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
import {pathToFileURL,fileURLToPath} from 'node:url';
const out='/home/ricardo/.cache/cvg-harness-green-20261004/firstparty-dependency-resolution-r30';
const source='/home/ricardo/.cache/cvg-harness-green-20261004/c1-nonbinding-label-r22/candidate';
const rows=JSON.parse(fs.readFileSync(path.join(out,'observations.json'),'utf8'));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const record=p=>{const bytes=fs.readFileSync(p);return {path:path.relative(source,p),realPath:fs.realpathSync(p),sha256:hash(bytes),bytes:bytes.length}};
const results=[];
for(const row of rows){
 const manifest=path.join(source,row.observation.file);const specifier=row.observation.specifier;
 const result={id:row.id,observation:row.observation,sourceManifest:record(manifest),sourceAst:row.binding.ast,conditions:{cjs:['require','node','node-addons',...(process.features.require_module?['module-sync']:[])],esm:['node','import',...(process.features.require_module?['module-sync']:[]),'node-addons'],defaultFallbackAlwaysEligible:true,customConditions:[],node:process.version,flags:process.execArgv,ambientNodeOptions:false},resolutions:{},packages:[]};
 if(result.sourceManifest.sha256!==row.binding.fileSha256)throw new Error('Source hash mismatch '+row.id);
 const req=createRequire(pathToFileURL(manifest));
 for(const mode of ['cjs','esm']){
  try{const resolved=mode==='cjs'?req.resolve(specifier):import.meta.resolve(specifier,pathToFileURL(manifest).href);const filename=resolved.startsWith('file:')?fileURLToPath(resolved):resolved;
   const entry=record(filename);result.resolutions[mode]={status:'RESOLVED',resolved,entry};
   let dir=path.dirname(entry.realPath);let found=false;
   while(dir!==path.dirname(dir)){
    const candidate=path.join(dir,'package.json');if(fs.existsSync(candidate)){const data=JSON.parse(fs.readFileSync(candidate,'utf8'));if(data.name && (data.name===specifier || specifier.startsWith(data.name+'/'))){result.packages.push({mode,manifest:record(candidate),name:data.name,version:data.version,type:data.type??null,main:data.main??null,module:data.module??null,types:data.types??data.typings??null,exports:data.exports??null,imports:data.imports??null,dependencies:data.dependencies??{},optionalDependencies:data.optionalDependencies??{},peerDependencies:data.peerDependencies??{}});found=true;break;}}
    dir=path.dirname(dir);
   }
   if(!found)result.resolutions[mode].packageManifestStatus='NOT_FOUND';
  }catch(e){result.resolutions[mode]={status:'UNRESOLVED',code:e.code??null,message:e.message};}
 }
 result.transitiveClosureAcceptance=false;results.push(result);
}
fs.writeFileSync(path.join(out,'resolutions.json'),JSON.stringify({task:'FIRSTPARTY_DEPENDENCY_RESOLUTION_R30',node:process.version,source,rows:results.length,resolverOnly:true,payloadsExecuted:false,results},null,2)+'\n');
console.log(JSON.stringify({rows:results.length,esmResolved:results.filter(r=>r.resolutions.esm.status==='RESOLVED').length,cjsResolved:results.filter(r=>r.resolutions.cjs.status==='RESOLVED').length,closureAccepted:false}));
