// Resolver anchor only; targets never imported.
