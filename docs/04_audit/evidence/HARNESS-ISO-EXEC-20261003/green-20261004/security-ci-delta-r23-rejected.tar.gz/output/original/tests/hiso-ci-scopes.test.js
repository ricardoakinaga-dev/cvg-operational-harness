// @vitest-environment node
import fs from 'node:fs'
import os from 'node:os'
import { spawnSync } from 'node:child_process'
import path from 'node:path'
import { createRequire } from 'node:module'
import { afterEach, describe, expect, it } from 'vitest'
import { CI_BAR_GATES, CI_BAR_VERSION } from '../scripts/ci-bar-contract.mjs'
import {
  contract,
  contractHash,
  digest,
  dispatch,
  files,
  scopeContract,
  VERSION,
  sourceFiles,
  sha
} from '../scripts/hiso-contract.mjs'
import {
  aggregate,
  aggregateCoverage,
  sealFor,
  verifyScope,
  verifySecurity,
  preflightScopes,
  preflightRemoteEvidence
} from '../scripts/hiso-verifier.mjs'
import { ownerMapping, projectLock, rules } from '../scripts/hiso-variant.mjs'
import { sanitizedEnv } from '../scripts/hiso-ci.mjs'
import {
  approvedCoverageInventory,
  coverageInventory,
  caseOccurrences,
  coverageSourceInventory
} from '../scripts/hiso-inventory.mjs'
import {
  envelope,
  testReport,
  coverageReport,
  verifySnapshots,
  gateTestInventory
} from '../scripts/hiso-reports.mjs'
import {
  isRemoteTrust,
  verifyAttestationStatements,
  artifactDigest,
  verifyImmutableArtifact,
  collectRemoteTrust
} from '../scripts/hiso-remote-trust.mjs'

import { buildCoverageReport } from '../scripts/lib/coverage-gate.mjs'
import { computeMetrics } from '../packages/agent-evals/src/metrics.ts'
import {
  copyProjectionConfigs,
  expectedCoveragePaths,
  linkPrivateParser
} from './fixtures/hiso-r6-measurement.mjs'

it('binds the original coverage source denominator to the approved inventory', () => {
  const root = path.resolve(import.meta.dirname, '..')
  const baseline = JSON.parse(
    fs.readFileSync(path.join(root, contract.baselineInventory.path))
  )
  const neutral = !JSON.parse(
    fs.readFileSync(path.join(root, 'package.json'))
  ).workspaces.includes('products/*')
  const paths = [...baseline.coveragePaths, ...baseline.newCoveragePaths]
    .filter((p) => !neutral || !p.startsWith('products/shift-assistant/'))
    .sort()
  expect(
    neutral ? coverageInventory(root) : approvedCoverageInventory(root)
  ).toEqual(paths)
  expect(() => approvedCoverageInventory(root, [])).toThrow(
    'approved_coverage_source_inventory'
  )
})
it('preserves every legacy executable and marker in the separate transition job', () => {
  const root = path.resolve(import.meta.dirname, '..')
  const workflow = fs.readFileSync(
    path.join(root, '.github/workflows/harness-isolation.yml'),
    'utf8'
  )
  const old = fs.readFileSync(
    path.join(root, '.github/workflows/verify.yml'),
    'utf8'
  )
  for (const match of old.matchAll(
    /run: node scripts\/ci-bar\.mjs (?:gate [a-z-]+|init|finalize)/g
  ))
    expect(workflow).toContain(match[0])
  for (const match of old.matchAll(/id: gate_[a-z_]+/g))
    expect(workflow).toContain(match[0])
  for (const scope of contract.scopes) {
    expect(workflow).toContain(`  ${scope.id}:\n    if: always()`)
    const block = workflow
      .split(`  ${scope.id}:\n`)[1]
      .split(/\n  [a-z][a-z-]*:/)[0]
    expect(block).toContain('if: always()')
    expect(block).toContain('HISO_INPUT_JOB_RESULT: ${{ needs.inputs.result }}')
    expect(block).toContain('HISO_SETUP_RESULT: ${{ job.status }}')
    expect(block).toContain('if-no-files-found: error')
  }
  for (const match of workflow.matchAll(/uses: ([^\s]+)/g)) {
    expect(match[1]).toMatch(/@[a-f0-9]{40}$/)
    expect(
      fs.readFileSync(path.join(root, '.github/workflows/verify.yml'), 'utf8') +
        fs.readFileSync(
          path.join(root, '.github/workflows/security.yml'),
          'utf8'
        )
    ).toContain(match[1])
  }
  expect(workflow).toContain(
    'playwright install --with-deps chromium firefox webkit'
  )
  expect(workflow.match(/image: postgres:16-alpine/g)).toHaveLength(2)
  expect(workflow).not.toContain('continue-on-error: true')
  expect(workflow).toContain('node scripts/hiso-import-legacy.mjs')
})

const dirs = []
afterEach(() => {
  for (const d of dirs.splice(0)) fs.rmSync(d, { recursive: true, force: true })
})
const H = 'a'.repeat(64)
function fixture(scope = 'consumer-contract') {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'hiso-negative-'))
  dirs.push(directory)
  const startedAt = '2026-10-04T00:00:00.000Z',
    finishedAt = '2026-10-04T00:00:01.000Z'
  const manifest = {
    schemaVersion: 1,
    contract: VERSION,
    contractHash,
    scope,
    owner: scopeContract(scope).owner,
    candidateId: H,
    sourceSha256: H,
    sourceMatch: true,
    sourceAfterSha256: H,
    variantSourceMatch: true,
    variantSourceAfterSha256: H,
    runId: 'synthetic-fixture-run',
    attempt: '1',
    derivedVariantId: H,
    derivedMappingHash: H,
    ownerMappingHash: H,
    lockSha256: H,
    mode: 'LOCAL_CONTENT_HASHES',
    startedAt,
    finishedAt,
    versions: { node: '22.23.2' },
    testInventory: [],
    testInventoryHash: digest([]),
    testInventoryStatus: 'COLLECTED_NOT_EXECUTED',
    executedTestInventory: [],
    executedTestInventoryHash: digest([]),
    coverage: null,
    gates: [],
    seals: [],
    status: 'PASS'
  }
  for (const g of scopeContract(scope).gates) {
    const log = `synthetic fixture ${g.id}\n`
    fs.mkdirSync(path.join(directory, 'gates'), { recursive: true })
    fs.writeFileSync(path.join(directory, 'gates', g.id + '.log'), log)
    const entry = {
      schemaVersion: 1,
      id: g.id,
      command: g.command,
      status: 'PASS',
      exitCode: 0,
      cause: null,
      scope,
      runId: manifest.runId,
      candidateId: H,
      startedAt,
      finishedAt,
      skipped: 0,
      logSha256: digest(log),
      outputs: []
    }
    // Log binding is a byte hash, distinct from canonical JSON hash.
    entry.logSha256 = files(directory).find(
      (x) => x.path === `gates/${g.id}.log`
    ).sha256
    for (const p of g.artifacts ?? []) {
      const target = `gate-outputs/${g.id}/${p}`
      fs.mkdirSync(path.dirname(path.join(directory, target)), {
        recursive: true
      })
      const report =
        g.id === 'public-smoke' || g.id === 'd009-consumer'
          ? {
              schemaVersion: 1,
              status: 'PASS',
              sourceFree: true,
              declarations: true,
              clinicalCalls: 0,
              unknownCalls: 0,
              budgetDenied: true,
              normalizer: true
            }
          : {
              schemaVersion: 1,
              status: 'PASS',
              synthetic: true,
              declarations: [],
              mapping: []
            }
      fs.writeFileSync(
        path.join(directory, target),
        JSON.stringify(report) + '\n'
      )
      entry.outputs.push(files(directory).find((f) => f.path === target))
    }
    manifest.gates.push(entry)
    manifest.seals.push(sealFor(manifest, entry))
  }
  manifest.outputs = files(directory)
  fs.writeFileSync(
    path.join(directory, 'manifest.json'),
    JSON.stringify(manifest)
  )
  const expected = {
    ...structuredClone(manifest),
    requiredTestIds: [],
    coveragePaths: ['packages/synthetic-fixture.ts']
  }
  if (scopeContract(scope).gates.some((g) => g.id === 'coverage'))
    manifest.coverage = { 'packages/synthetic-fixture.ts': coverage(1, 1) }
  return { directory, manifest, expected }
}
const check = (f) => verifyScope(f)
function reseal(f, gateId, value) {
  const gate = f.manifest.gates.find((g) => g.id === gateId)
  const p = gate.outputs.find((o) => o.path.endsWith('.json')).path
  fs.writeFileSync(path.join(f.directory, p), JSON.stringify(value) + '\n')
  const current = files(f.directory).find((o) => o.path === p)
  gate.outputs = gate.outputs.map((o) => (o.path === p ? current : o))
  f.manifest.outputs = files(f.directory).filter(
    (o) => o.path !== 'manifest.json'
  )
  f.manifest.seals = f.manifest.gates.map((g) => sealFor(f.manifest, g))
  fs.writeFileSync(
    path.join(f.directory, 'manifest.json'),
    JSON.stringify(f.manifest)
  )
}
describe('R2 defeated reproductions remain regression controls', () => {
  it.each([undefined, 0, 2, 999, '1'])(
    'rejects schema %s before dispatch',
    (version) => {
      const f = fixture()
      f.manifest.schemaVersion = version
      expect(() => check(f)).toThrow('schema_version:manifest')
      expect(() => envelope({ schemaVersion: version }, 'expected')).toThrow(
        'schema_version:expected'
      )
    }
  )
  it.each(['FAIL', 'NOT_RUN', 'SKIP'])(
    'rejects a coherently sealed %s snapshot',
    (status) => {
      const f = fixture()
      reseal(f, 'd009-consumer', {
        schemaVersion: 1,
        status,
        verdict: 'FAIL',
        testResults: []
      })
      expect(() => check(f)).toThrow('snapshot_not_pass')
    }
  )
  it('rejects unknown report schema even when hashes and gate seals match', () => {
    const f = fixture()
    reseal(f, 'd009-consumer', {
      schemaVersion: 999,
      status: 'PASS',
      sourceFree: true,
      declarations: true,
      clinicalCalls: 0,
      unknownCalls: 0,
      budgetDenied: true,
      normalizer: true
    })
    expect(() => check(f)).toThrow('schema_version:d009-consumer')
  })
  it('rejects zero coverage across the original and thirty-eight explicitly added test paths without inflating legitimate zero per-file metrics', () => {
    const baseline = JSON.parse(
      fs.readFileSync(
        new URL('../scripts/hiso-baseline-inventory.json', import.meta.url)
      )
    )
    const root = path.resolve(import.meta.dirname, '..')
    const paths = expectedCoveragePaths(root, 'retained')
    expect(paths).toHaveLength(281)
    expect(baseline.tests).toHaveLength(371)
    expect(baseline.newTests).toHaveLength(46)
    expect(() =>
      aggregateCoverage(
        [Object.fromEntries(paths.map((p) => [p, coverage(0, 0)]))],
        paths
      )
    ).toThrow('coverage_empty_executable_denominator')
    const one = coverage(10, 10),
      zero = coverage(0, 0)
    one.branches = zero.branches
    one.functions = zero.functions
    const sources = [
      { path: 'packages/a.ts', sha256: H, executable: true },
      { path: 'packages/branched-function.ts', sha256: H, executable: true },
      { path: 'packages/types.ts', sha256: H, executable: false }
    ]
    expect(
      aggregateCoverage(
        [
          {
            'packages/a.ts': one,
            'packages/branched-function.ts': coverage(2, 2),
            'packages/types.ts': zero
          }
        ],
        sources.map((s) => s.path),
        sources
      ).pass
    ).toBe(true)
    expect(() =>
      aggregateCoverage(
        [
          {
            'packages/a.ts': one,
            'packages/branched-function.ts': coverage(2, 2),
            'packages/types.ts': zero
          }
        ],
        sources.map((s) => s.path),
        sources.map((s) => ({ ...s, executable: true }))
      )
    ).toThrow('coverage_executable_zero')
  })
  it('derives exact test identities and coverage from the sealed JSON rather than a manifest projection', () => {
    const report = {
      success: true,
      numTotalTests: 1,
      numPassedTests: 1,
      numFailedTests: 0,
      numFailedTestSuites: 0,
      testResults: [
        {
          name: '/external/tests/synthetic.test.js',
          status: 'passed',
          assertionResults: [
            {
              ancestorTitles: ['synthetic'],
              title: 'real case',
              status: 'passed'
            }
          ]
        }
      ]
    }
    const rows = testReport(report, ['tests/synthetic.test.js'])
    expect(rows[0].name).toBe('synthetic > real case')
    const f = fixture()
    const gate = { id: 'unit', skipPolicy: 'none' }
    reseal(f, 'd009-consumer', report)
    const entry = f.manifest.gates.find((g) => g.id === 'd009-consumer')
    f.manifest.testInventory = [{ file: 'tests/synthetic.test.js' }]
    f.manifest.executedTestInventory = rows
    expect(
      verifySnapshots({
        gate,
        entry,
        directory: f.directory,
        manifest: f.manifest,
        expected: f.expected
      }).tests
    ).toEqual(rows)
    f.manifest.executedTestInventory = []
    expect(() =>
      verifySnapshots({
        gate,
        entry,
        directory: f.directory,
        manifest: f.manifest,
        expected: f.expected
      })
    ).toThrow('unit_execution_inventory_snapshot')
    const c = {
      total: coverage(10, 10),
      '/external/packages/a.ts': coverage(10, 10)
    }
    expect(coverageReport(c, ['packages/a.ts'])).toEqual({
      'packages/a.ts': coverage(10, 10)
    })
    reseal(f, 'd009-consumer', c)
    const coverageGate = { id: 'coverage' },
      expected = { coveragePaths: ['packages/a.ts'] }
    f.manifest.coverage = { 'packages/a.ts': coverage(9, 9) }
    expect(() =>
      verifySnapshots({
        gate: coverageGate,
        entry: f.manifest.gates.find((g) => g.id === 'd009-consumer'),
        directory: f.directory,
        manifest: f.manifest,
        expected
      })
    ).toThrow('coverage_snapshot_projection')
  })
  it.each(['failed', 'pending', 'skipped', 'todo'])(
    'rejects test status %s without execution',
    (status) => {
      const r = {
        success: true,
        numTotalTests: 1,
        numPassedTests: 0,
        numFailedTests: 0,
        numFailedTestSuites: 0,
        testResults: [
          {
            name: 'tests/a.test.js',
            status: 'passed',
            assertionResults: [{ ancestorTitles: [], title: 'a', status }]
          }
        ]
      }
      expect(() => testReport(r, ['tests/a.test.js'])).toThrow()
    }
  )
  it('cannot obtain global PASS from local assertions or a serialized remote trust object', () => {
    const options = {
      scopes: [],
      expected: { schemaVersion: 1, scopes: {}, coveragePaths: [] },
      producerResults: {},
      security: null,
      provenance: null
    }
    const local = aggregate(options),
      remote = aggregate({
        ...options,
        mode: 'remote',
        trust: { verified: true }
      })
    expect(local.status).not.toBe('PASS')
    expect(local.remoteCiPass).toBe(false)
    expect(local.externalGates).toBe('NOT_RUN')
    expect(isRemoteTrust({ verified: true })).toBe(false)
    expect(remote.failures).toContain('hiso:external_trust_required')
  })
  it('binds external verified attestation statements to subject, signer, source and exact run', () => {
    const context = {
      subjectSha256: H,
      repository: 'fixture/repository',
      sourceSha: 'b'.repeat(40),
      runId: '123',
      attempt: '2'
    }
    const statement = {
      _type: 'https://in-toto.io/Statement/v1',
      predicateType: 'https://slsa.dev/provenance/v1',
      subject: [{ name: 'manifest.json', digest: { sha256: H } }],
      predicate: {
        runDetails: {
          builder: {
            id: 'https://github.com/fixture/repository/.github/workflows/harness-isolation.yml@refs/heads/main'
          },
          metadata: {
            invocationId:
              'https://github.com/fixture/repository/actions/runs/123/attempts/2'
          }
        },
        buildDefinition: {
          externalParameters: {
            workflow: {
              path: '.github/workflows/harness-isolation.yml',
              repository: 'https://github.com/fixture/repository'
            }
          },
          resolvedDependencies: [
            {
              uri: 'git+https://github.com/fixture/repository@refs/heads/main',
              digest: { gitCommit: context.sourceSha }
            }
          ]
        }
      }
    }
    expect(
      verifyAttestationStatements(
        [{ verificationResult: { statement } }],
        context
      )
    ).toBe(true)
    for (const key of Object.keys(context))
      expect(() =>
        verifyAttestationStatements([{ verificationResult: { statement } }], {
          ...context,
          [key]: 'wrong'
        })
      ).toThrow('attestation_subject_signer_source_run')
    expect(() => verifyAttestationStatements([{ statement }], context)).toThrow(
      'attestation_verified_statement_required'
    )
  })
  it('keeps the real D009 executor outside the removed product and production smoke manager mandatory', () => {
    const command = scopeContract('consumer-contract').gates.find(
      (g) => g.id === 'd009-consumer'
    ).command
    expect(command).toEqual(['node', ['scripts/hiso-public-smoke.mjs']])
    const runner = fs.readFileSync(
      new URL('../scripts/hiso-ci.mjs', import.meta.url),
      'utf8'
    )
    expect(runner).not.toContain('D009_CONSUMER_BRANCH_NOT_IN_SNAPSHOT')
    const smoke = fs.readFileSync(
      new URL('../scripts/hiso-product-image.mjs', import.meta.url),
      'utf8'
    )
    expect(smoke).toContain("NODE_ENV:'production'")
    expect(smoke).toContain('Gestor Ficticio*')
    for (const assertion of [
      'assert(sends>0)',
      'assert.equal(modelCalls,0)',
      'assert.equal(process.getuid(),10001)'
    ])
      expect(smoke).toContain(assertion)
  })
})
describe('hiso exact contracts and isolated evidence', () => {
  it('preserves the legacy inventory and refuses unknown versions', () => {
    expect(dispatch(CI_BAR_VERSION).gates).toBe(CI_BAR_GATES)
    expect(dispatch(VERSION)).toBe(contract)
    expect(() => dispatch('hiso-ci-scopes-v2')).toThrow('unknown_contract')
    expect(
      contract.scopes
        .find((s) => s.id === 'transition-regression')
        .gates.slice(0, CI_BAR_GATES.length)
        .map((g) => g.id)
    ).toEqual(CI_BAR_GATES.map((g) => g.id))
  })
  it('accepts only a complete explicitly synthetic local fixture', () => {
    expect(check(fixture())).toBe(true)
  })
  it('retains repeated baseline titles as distinct ordered cases, including declared skips', () => {
    const rows = caseOccurrences([
      {
        file: 'tests/synthetic.test.js',
        name: 'same title',
        collectionState: 'skipped'
      },
      {
        file: 'tests/synthetic.test.js',
        name: 'same title',
        collectionState: 'pending'
      }
    ])
    expect(rows).toHaveLength(2)
    expect(rows.map((t) => t.occurrence)).toEqual([1, 2])
    expect(new Set(rows.map((t) => t.id)).size).toBe(2)
    expect(rows[0].collectionState).toBe('skipped')
  })
  it('rejects duplicate execution identities against the complete approved multiplicity', () => {
    const f = fixture('harness-neutral')
    const rows = caseOccurrences([
      { file: 'tests/synthetic.test.js', name: 'same title', status: 'passed' },
      { file: 'tests/synthetic.test.js', name: 'same title', status: 'passed' }
    ])
    f.expected.requiredTestIds = rows.map((t) => t.id)
    f.manifest.executedTestInventory = [rows[0], rows[0]]
    f.manifest.executedTestInventoryHash = digest(
      f.manifest.executedTestInventory
    )
    expect(() => check(f)).toThrow('unit_execution_inventory')
  })
  it.each([
    'sourceMatch',
    'sourceAfterSha256',
    'variantSourceMatch',
    'variantSourceAfterSha256'
  ])('rejects altered post-run source proof %s', (key) => {
    const f = fixture()
    f.manifest[key] = 'wrong'
    expect(() => check(f)).toThrow('source_after_binding')
  })
  it.each(['NOT_RUN', undefined])(
    'refuses absent or uncollected testcase inventory %s',
    (status) => {
      const f = fixture()
      f.manifest.testInventoryStatus = status
      expect(() => check(f)).toThrow('test_inventory_not_collected')
    }
  )
  for (const s of contract.scopes)
    for (const gate of s.gates) {
      it(`refuses missing gate/seal ${s.id}/${gate.id}`, () => {
        const f = fixture(s.id)
        f.manifest.gates = f.manifest.gates.filter((g) => g.id !== gate.id)
        expect(() => check(f)).toThrow('gate_inventory')
        const g = fixture(s.id)
        g.manifest.seals = g.manifest.seals.filter((g) => g.gateId !== gate.id)
        expect(() => check(g)).toThrow('seal_inventory')
      })
    }
  it.each([
    'runId',
    'attempt',
    'candidateId',
    'sourceSha256',
    'derivedVariantId',
    'derivedMappingHash',
    'ownerMappingHash',
    'scope',
    'contractHash'
  ])('rejects stale or cross-scope %s', (key) => {
    const f = fixture()
    f.manifest[key] = key === 'scope' ? 'shift-product' : 'wrong'
    expect(() => check(f)).toThrow()
  })
  it('refuses duplicate gates and seals even with an otherwise valid count', () => {
    const f = fixture()
    f.manifest.gates[1] = f.manifest.gates[0]
    expect(() => check(f)).toThrow('gate_inventory')
    const g = fixture()
    g.manifest.seals[1] = g.manifest.seals[0]
    expect(() => check(g)).toThrow('seal_inventory')
  })
  it.each(['FAIL', 'NOT_RUN', 'SKIP'])(
    'refuses %s despite zero process exit',
    (status) => {
      const f = fixture()
      f.manifest.gates[0].status = status
      expect(() => check(f)).toThrow('gate_not_pass')
    }
  )
  it('rejects missing, changed and unlisted output bytes', () => {
    const f = fixture()
    fs.unlinkSync(path.join(f.directory, 'gates/runtime.log'))
    expect(() => check(f)).toThrow('complete_output_inventory')
    const g = fixture()
    fs.writeFileSync(path.join(g.directory, 'gates/runtime.log'), 'replaced')
    expect(() => check(g)).toThrow('complete_output_inventory')
    const h = fixture()
    fs.writeFileSync(path.join(h.directory, 'extra'), 'unlisted')
    expect(() => check(h)).toThrow('complete_output_inventory')
  })
  it('rejects a symlink directory before traversing it', () => {
    const f = fixture()
    fs.symlinkSync(os.tmpdir(), path.join(f.directory, 'external'))
    expect(() => check(f)).toThrow('symlink')
  })
  it('rejects a coherently resealed entry from a different scope', () => {
    const f = fixture()
    f.manifest.gates[0].scope = 'shift-product'
    f.manifest.seals[0] = sealFor(f.manifest, f.manifest.gates[0])
    expect(() => check(f)).toThrow('gate_binding')
  })
  it('requires exact commands and zero skips', () => {
    const f = fixture()
    f.manifest.gates[0].command = ['true', []]
    expect(() => check(f)).toThrow('command_binding')
    const g = fixture()
    const e = g.manifest.gates.find(
      (x) =>
        scopeContract(g.manifest.scope).gates.find((y) => y.id === x.id)
          .skipPolicy === 'none'
    )
    e.skipped = 1
    g.manifest.seals = g.manifest.gates.map((x) => sealFor(g.manifest, x))
    expect(() => check(g)).toThrow('skip_policy')
  })
  it('does not treat self-produced hashes as remote provenance', () => {
    const f = fixture()
    f.producer = {
      schemaVersion: 1,
      result: 'success',
      manifestSha256: H,
      sealSetSha256: digest(f.manifest.seals)
    }
    expect(() => check(f)).toThrow('remote_mode')
  })
  it('does not omit exact combined-workspace assertions', () => {
    const p = 'tests/workspace-scripts.test.js',
      m = ownerMapping([
        { path: p, sha256: H, size: 10 },
        { path: 'packages/x/src/__tests__/x.test.ts', sha256: H, size: 5 },
        {
          path: 'products/shift-assistant/src/__tests__/x.test.ts',
          sha256: H,
          size: 5
        }
      ])
    expect(m.map((x) => x.owner)).toEqual([
      'transition-regression',
      'harness-neutral',
      'shift-product'
    ])
    expect(m.every((x) => x.transitionRequired)).toBe(true)
    expect(rules.transitionOnly.find((x) => x.path === p).reason).toContain(
      'both original tests'
    )
  })
  it('retains third-party versions and integrities while projecting workspace links', () => {
    const entry = {
      schemaVersion: 1,
      version: '1.0.0',
      integrity: 'sha512-fixed',
      resolved: 'https://registry.npmjs.org/x/-/x-1.0.0.tgz'
    }
    const lock = {
      lockfileVersion: 3,
      packages: {
        '': {
          workspaces: ['packages/*', 'products/*'],
          dependencies: { x: '1.0.0' }
        },
        'node_modules/x': entry,
        'node_modules/@cvg/product': {
          resolved: 'products/shift-assistant',
          link: true
        },
        'products/shift-assistant': { name: '@cvg/product' }
      }
    }
    const projected = projectLock(lock, { workspaces: ['packages/*'] })
    expect(projected.packages['node_modules/x']).toEqual(entry)
    expect(projected.packages['node_modules/@cvg/product']).toBeUndefined()
    expect(lock.packages['products/shift-assistant']).toBeDefined()
    expect(() =>
      projectLock(
        {
          ...lock,
          packages: {
            ...lock.packages,
            'packages/neutral': { dependencies: { '@cvg/product': '1.0.0' } }
          }
        },
        { workspaces: ['packages/*'] }
      )
    ).toThrow('retained_dependency_on_product')
  })
  it('keeps local execution free of provider secrets, SHIFT config and seal-writing environment', () => {
    const e = sanitizedEnv(
      {
        SHIFT_TEST: 'secret',
        OPENAI_API_KEY: 'secret',
        GITHUB_ACTIONS: 'true',
        GITHUB_OUTPUT: '/outside',
        PATH: '/private',
        TEST_DATABASE_URL: 'synthetic-url'
      },
      '/tmp/private',
      '/tmp/cache'
    )
    expect(e.SHIFT_TEST).toBeUndefined()
    expect(e.OPENAI_API_KEY).toBeUndefined()
    expect(e.GITHUB_ACTIONS).toBeUndefined()
    expect(e.GITHUB_OUTPUT).toBeUndefined()
    expect(e.TEST_DATABASE_URL).toBe('synthetic-url')
  })
})
const metrics = ['statements', 'branches', 'functions', 'lines']
const coverage = (total, covered) =>
  Object.fromEntries(
    metrics.map((k) => [k, { total, covered, skipped: 0, pct: 99 }])
  )
describe('canonical coverage and aggregate obligations', () => {
  it('weights de-normalized counts rather than percentages', () => {
    const r = aggregateCoverage(
      [
        { 'packages/a.ts': coverage(100, 80) },
        { 'products/shift-assistant/a.ts': coverage(1, 1) }
      ],
      ['packages/a.ts', 'products/shift-assistant/a.ts']
    )
    expect(r.totals.lines.pct).toBeCloseTo((100 * 81) / 101)
    expect(r.pass).toBe(false)
  })
  it('deduplicates identical canonical sources and rejects conflicting duplicates', () => {
    expect(
      aggregateCoverage(
        [
          { 'packages/a.ts': coverage(10, 10) },
          { 'packages/a.ts': coverage(10, 10) }
        ],
        ['packages/a.ts']
      ).totals.lines.total
    ).toBe(10)
    expect(() =>
      aggregateCoverage(
        [
          { 'packages/a.ts': coverage(10, 10) },
          { 'packages/a.ts': coverage(20, 20) }
        ],
        ['packages/a.ts']
      )
    ).toThrow('duplicate_conflict')
  })
  it('rejects deleted coverage sources and invalid denominators', () => {
    expect(() => aggregateCoverage([{}], ['packages/a.ts'])).toThrow(
      'coverage_source_inventory'
    )
    expect(() =>
      aggregateCoverage(
        [{ 'packages/a.ts': coverage(1, 2) }],
        ['packages/a.ts']
      )
    ).toThrow('coverage_denominator')
  })
  it('refuses missing scope, Security or independent provenance', () => {
    const result = aggregate({
      scopes: [],
      expected: { scopes: {}, coveragePaths: [] },
      security: null,
      provenance: null
    })
    expect(result.status).toBe('FAIL')
    expect(result.failures).toEqual(
      expect.arrayContaining([
        'hiso:aggregate_scopes',
        'hiso:security_workflow',
        'hiso:global_provenance_inventory'
      ])
    )
  })
  it('rejects old same-SHA Security runs and skipped scanners', () => {
    const e = {
      sha: 'f'.repeat(40),
      securityRunId: 123,
      securityAttempt: 2,
      startedAt: '2026-10-04T00:00:00Z'
    }
    const report = {
      schemaVersion: 1,
      status: 'PASS',
      workflow: contract.security.workflow,
      workflowId: 99,
      sha: e.sha,
      runId: 123,
      attempt: 2,
      collectedAt: '2026-10-04T00:01:00Z',
      jobs: contract.security.requiredJobs.map((name, i) => ({
        name,
        id: 10 + i,
        status: 'completed',
        conclusion: 'success'
      }))
    }
    expect(() => verifySecurity(report, e)).not.toThrow()
    expect(() => verifySecurity({ ...report, attempt: 1 }, e)).toThrow(
      'security_run_binding'
    )
    report.jobs[0].conclusion = 'skipped'
    expect(() => verifySecurity(report, e)).toThrow('security_job_not_pass')
  })
})

it('requires immutable external artifact identity, digest, source, run name and freshness', () => {
  const expected = {
    name: 'hiso-consumer-contract-123-2',
    id: '456',
    digest: H,
    sourceSha: 'c'.repeat(40),
    startedAt: '2026-10-04T00:00:00Z'
  }
  const artifact = {
    id: 456,
    name: expected.name,
    digest: 'sha256:' + H,
    workflow_run: { head_sha: expected.sourceSha },
    created_at: '2026-10-04T00:01:00Z',
    expired: false
  }
  expect(artifactDigest(H)).toBe('sha256:' + H)
  expect(artifactDigest('sha256:' + H)).toBe('sha256:' + H)
  expect(verifyImmutableArtifact(artifact, expected)).toBe(true)
  for (const delta of [
    { id: 0 },
    { id: 457 },
    { name: 'hiso-consumer-contract-122-1' },
    { digest: 'sha256:' + 'b'.repeat(64) },
    { expired: true },
    { workflow_run: { head_sha: 'wrong' } },
    { created_at: '2026-10-03T23:00:00Z' }
  ])
    expect(() =>
      verifyImmutableArtifact({ ...artifact, ...delta }, expected)
    ).toThrow('external_immutable_artifact')
  expect(() => artifactDigest('self-assertion')).toThrow(
    'immutable_artifact_digest_format'
  )
})

// These are validation controls, not executed CI artifacts or attestations.
// They are synthetic, content-sealed, and deliberately stop at an I/O sentinel.
function remoteValidationFixture() {
  const root = path.resolve(import.meta.dirname, '..')
  const inputs = sourceFiles(root),
    candidateId = digest(inputs)
  const runId = 'run-123-2',
    attempt = '2'
  const startedAt = '2026-10-04T00:00:00.000Z',
    finishedAt = '2026-10-04T00:00:01.000Z'
  const sources = coverageSourceInventory(root, inputs),
    paths = sources.map((s) => s.path)
  const metrics = Object.fromEntries(paths.map((p) => [p, coverage(1, 1)]))
  const unitInventory = caseOccurrences([
    {
      file: 'tests/synthetic.test.js',
      name: 'synthetic validation case',
      status: 'passed'
    }
  ])
  const scripts = JSON.parse(
    fs.readFileSync(path.join(root, 'package.json'), 'utf8')
  ).scripts
  const postgresFiles = scripts['test:postgres']
    .split(/\s+/)
    .filter((p) => p.endsWith('.test.ts'))
  const chaosFiles = fs
    .readdirSync(path.join(root, 'packages/chaos/src/__tests__'))
    .filter((p) => p.endsWith('.test.ts'))
    .map((p) => `packages/chaos/src/__tests__/${p}`)
  const inventory = caseOccurrences([
    ...unitInventory.map(({ file, name, status }) => ({ file, name, status })),
    ...[...new Set([...postgresFiles, ...chaosFiles])].map((file) => ({
      file,
      name: 'synthetic gate validation case',
      status: 'passed'
    }))
  ])
  const nativeFor = (rows) => ({
    success: true,
    numTotalTests: rows.length,
    numPassedTests: rows.length,
    numFailedTests: 0,
    numPendingTests: 0,
    numTodoTests: 0,
    numTotalTestSuites: new Set(rows.map((t) => t.file)).size,
    numPassedTestSuites: new Set(rows.map((t) => t.file)).size,
    numFailedTestSuites: 0,
    numPendingTestSuites: 0,
    testResults: [...new Set(rows.map((t) => t.file))].map((file) => ({
      name: file,
      status: 'passed',
      assertionResults: rows
        .filter((t) => t.file === file)
        .map((t) => ({ ancestorTitles: [], title: t.name, status: 'passed' }))
    }))
  })
  const native = nativeFor(unitInventory)
  const selectedNative = Object.fromEntries(
    ['postgres', 'chaos'].map((id) => [
      id,
      nativeFor(gateTestInventory(id, inventory))
    ])
  )
  // Measurement repair: use the coverage producer and authoritative critical
  // manifest rather than a sparse synthetic group that a real producer rejects.
  const summary = { total: coverage(paths.length, paths.length), ...metrics }
  const criticalManifest = JSON.parse(
    fs.readFileSync(
      path.join(root, 'scripts/critical-coverage-manifest.json'),
      'utf8'
    )
  )
  const criticalReport = buildCoverageReport(summary, criticalManifest)
  // Pure producer metrics over inert outcome data, without running any agent or
  // evaluator. Defaults are the same immutable thresholds used by runEvalSuite.
  const evalMetrics = computeMetrics([
    {
      scenarioId: 'synthetic',
      category: 'synthetic',
      adversarial: true,
      outcome: {
        intent: 'synthetic',
        proposedCapabilities: [],
        escalation: 'none',
        refused: false,
        structuredValid: true,
        latencyMs: 1,
        costUsd: 0
      },
      success: true,
      failures: []
    }
  ])
  const evalThresholds = JSON.parse(
    fs.readFileSync(
      path.join(root, 'packages/agent-evals/src/eval-thresholds.json'),
      'utf8'
    )
  )
  const base = {
    schemaVersion: 1,
    contract: VERSION,
    contractHash,
    candidateId,
    sourceSha256: candidateId,
    ownerMappingHash: H,
    runId,
    attempt
  }
  const expected = {
    ...base,
    sha: 'b'.repeat(40),
    startedAt,
    coveragePaths: paths,
    coverageSources: sources,
    testInventory: inventory,
    scopes: {},
    securityRunId: 42,
    securityAttempt: 1
  }
  const pg = {
    schemaVersion: 1,
    kind: 'rem21-010-postgres-proof',
    contract: 'rem21-010-v1',
    runId,
    candidateId,
    node: 'v22.23.2',
    verdict: 'PASS',
    scope: { production: false, realData: false },
    workload: { status: 'PASS' },
    backupRestore: { status: 'PASS' },
    migrationRecovery: { status: 'PASS' },
    integrity: { status: 'PASS' },
    corruptionGate: { status: 'PASS', detected: true },
    rpoRto: { measured: false, verdict: 'RPO_RTO_NOT_MEASURED_IN_PRODUCTION' }
  }
  const obs = {
    schemaVersion: 1,
    kind: 'rem21-011-observability-proof',
    contract: 'rem21-011-v1',
    runId,
    candidateId,
    node: 'v22.23.2',
    verdict: 'PASS',
    scope: { production: false, realData: false },
    collector: { status: 'PASS' },
    redaction: { status: 'PASS', leaked: false },
    cardinality: { status: 'PASS', unapprovedLabels: 0 },
    exporterFault: { status: 'PASS', noThrow: true, alerted: true },
    slos: { status: 'PASS', productionClaim: false },
    readinessIsolation: { status: 'PASS', changedByExporterFailure: false }
  }
  const browsers = ['chromium', 'firefox', 'webkit']
  const browser = {
    schemaVersion: 1,
    kind: 'rem21-014-browser-proof',
    contract: 'rem21-014-v1',
    runId,
    candidateId,
    node: 'v22.23.2',
    verdict: 'PASS',
    scope: {
      production: false,
      realData: false,
      externalServices: false,
      identityMode: 'trusted'
    },
    browsers: {
      declared: browsers,
      executed: browsers,
      byProject: Object.fromEntries(
        browsers.map((b) => [b, { failed: 0, skipped: 0, passed: 1 }])
      )
    },
    tests: { total: 3, passed: 3, failed: 0, skipped: 0, flaky: 0 },
    axe: { blockingViolations: 0, minorViolations: 0, checkedTests: 1 },
    playwright: { exitCode: 0, rawReportPresent: true }
  }
  const image = {
    schemaVersion: 1,
    kind: 'cvg-runtime-image',
    contract: 'rem21-016-v1',
    runId,
    candidateId,
    imageId: 'sha256:' + H,
    baseImageRef: 'synthetic@sha256:' + H,
    configUser: 'cvg',
    cmd: ['node', 'apps/api/dist/main.js'],
    smoke: { status: 'PASS', live: 200, ready: 200 }
  }
  const executionId = '123e4567-e89b-12d3-a456-426614174000'
  const e2e = {
    config: { metadata: { cvgE2e: { runId, candidateId, executionId } } },
    suites: [
      {
        file: 'synthetic.spec.ts',
        specs: [
          {
            file: 'synthetic.spec.ts',
            title: 'validation',
            ok: true,
            tests: [
              {
                expectedStatus: 'passed',
                status: 'expected',
                results: [{ status: 'passed', retry: 0, errors: [] }]
              }
            ]
          }
        ]
      }
    ],
    errors: [],
    stats: {
      startTime: startedAt,
      duration: 100,
      expected: 1,
      skipped: 0,
      unexpected: 0,
      flaky: 0
    }
  }
  const xml = `<testsuites id="${runId}" name="candidateId=${candidateId};executionId=${executionId}" tests="1" failures="0" skipped="0" errors="0"><testsuite name="synthetic.spec.ts" tests="1" failures="0" skipped="0" errors="0"><testcase classname="synthetic.spec.ts" name="validation"/></testsuite></testsuites>`
  const mutationAuthority = JSON.parse(
    fs.readFileSync(path.join(root, 'scripts/mutation-manifest.json'), 'utf8')
  )
  const scopes = [],
    producerResults = {}
  for (const c of contract.scopes) {
    const f = fixture(c.id),
      m = f.manifest
    const binding = {
      ...base,
      scope: c.id,
      derivedVariantId: H,
      derivedMappingHash: H,
      lockSha256: H,
      testInventoryHash: digest(inventory),
      requiredTestIds: unitInventory.map((t) => t.id),
      coveragePaths: paths,
      coverageSources: sources
    }
    expected.scopes[c.id] = binding
    Object.assign(m, binding, {
      testInventory: inventory,
      executedTestInventory: unitInventory,
      executedTestInventoryHash: digest(unitInventory),
      mode: 'GITHUB_JOB_OUTPUT_BOUND',
      sourceAfterSha256: candidateId,
      variantSourceAfterSha256: H
    })
    m.coverage = c.gates.some((g) => g.id === 'coverage') ? metrics : null
    for (const g of m.gates) {
      g.candidateId = candidateId
      g.runId = runId
      if (g.id === 'e2e')
        fs.writeFileSync(
          path.join(f.directory, 'gates/e2e.log'),
          `[e2e-evidence] runId=${runId} candidateId=${candidateId} executionId=${executionId} tests=1 PASS\n`
        )
      g.logSha256 = sha(
        fs.readFileSync(path.join(f.directory, `gates/${g.id}.log`))
      )
      for (const o of g.outputs) {
        let r = {
          schemaVersion: 1,
          status: 'PASS',
          syntheticValidationOnly: true,
          verdict: 'PASS'
        }
        if (g.id === 'unit') r = native
        if (['postgres', 'chaos'].includes(g.id)) r = selectedNative[g.id]
        if (g.id === 'coverage')
          r = { total: coverage(paths.length, paths.length), ...metrics }
        if (g.id === 'postgres-proof') r = pg
        if (g.id === 'observability-proof') r = obs
        if (g.id === 'browser-proof') r = browser
        if (g.id === 'image' && o.path.endsWith('/runtime-image.json'))
          r = image
        if (g.id === 'image' && o.path.endsWith('/image.json'))
          r = {
            schemaVersion: 1,
            status: 'PASS',
            runId,
            candidateId,
            syntheticValidationOnly: true
          }
        if (g.id === 'postgres-version')
          r = {
            schemaVersion: 1,
            status: 'PASS',
            version: 160000,
            runId,
            candidateId
          }
        if (['public-smoke', 'd009-consumer'].includes(g.id))
          r = {
            schemaVersion: 1,
            status: 'PASS',
            sourceFree: true,
            declarations: true,
            clinicalCalls: 0,
            unknownCalls: 0,
            budgetDenied: true,
            normalizer: true
          }
        if (g.id === 'mutation')
          r = {
            schemaVersion: 2,
            contract: 'rem21-013-v1',
            verdict: 'PASS',
            syntheticValidationOnly: true
          }
        if (g.id === 'licenses')
          r = { schemaVersion: 2, syntheticValidationOnly: true }
        if (g.id === 'certify' && o.path.endsWith('/candidate-manifest.json'))
          r = {
            schemaVersion: 'aaa-candidate-v1',
            syntheticValidationOnly: true
          }
        if (g.id === 'inventory')
          r = {
            schemaVersion: 1,
            declarations: [],
            mapping: [],
            syntheticValidationOnly: true
          }
        if (g.id === 'coverage-critical') r = criticalReport
        if (g.id === 'mutation')
          r = {
            schemaVersion: 2,
            kind: 'aud21-risk-mutation-guard',
            contract: 'rem21-013-v1',
            runId,
            candidateId,
            verdict: 'PASS',
            manifestSha256: digest(mutationAuthority),
            selected: mutationAuthority.mutations.length,
            killed: mutationAuthority.mutations.length,
            survived: 0,
            timedOut: 0,
            errors: 0,
            domains: [
              ...new Set(mutationAuthority.mutations.map((m) => m.domain))
            ].sort(),
            mutations: mutationAuthority.mutations.map((m) => ({
              id: m.id,
              domain: m.domain,
              mode: m.mode,
              source: m.source,
              sourceSha256: m.sourceSha256,
              from: m.from,
              to: m.to,
              testFiles: m.testFiles ?? [],
              budgetMs: m.budgetMs,
              status: 'KILLED',
              exitCode: 1,
              durationMs: 0
            })),
            syntheticValidationOnly: true
          }
        if (g.id === 'skip')
          r = {
            schemaVersion: 1,
            kind: 'aud20-skip-inventory',
            runId,
            candidateId,
            verdict: 'PASS',
            totals: { skippedTests: 0, skippedFiles: 0, failures: 0 },
            skips: [],
            failures: [],
            reports: [],
            reportCountByGate: { unit: 1, postgres: 1, chaos: 1, e2e: 1 },
            skippedTestsByGate: { unit: 0, postgres: 0, chaos: 0, e2e: 0 },
            syntheticValidationOnly: true
          }
        if (g.id === 'evals')
          r = {
            suiteId: 'synthetic',
            agentId: 'synthetic',
            startedAt,
            finishedAt,
            verdict: 'PASS',
            metrics: evalMetrics,
            thresholds: evalThresholds,
            failures: [],
            syntheticValidationOnly: true
          }
        if (g.id === 'load')
          r = {
            schemaVersion: 1,
            kind: 'phase10-load-report',
            events: 1,
            processed: 1,
            loss: 0,
            duplicates: 0,
            workers: 1,
            enqueueMs: 0,
            drainMs: 0,
            totalMs: 0,
            throughputPerSecond: 0,
            latencyMs: { p50: 0, p95: 0, p99: 0, max: 0 },
            syntheticValidationOnly: true
          }
        if (g.id === 'restore')
          r = {
            schemaVersion: 1,
            kind: 'phase10-restore-report',
            snapshotFormatVersion: 1,
            snapshotDigestPrefix: 'synthetic',
            snapshotSha256: H,
            captureMs: 0,
            restoreMs: 0,
            integrity: {
              digestMatches: true,
              outboxPreserved: true,
              tenantIsolation: true,
              restoredEvents: 1
            },
            rpoMeasured: false,
            rtoMeasuredSec: 0,
            rpoRtoVerdict: 'NOT_VALIDATED_ON_PRODUCTION_INFRASTRUCTURE',
            syntheticValidationOnly: true
          }
        if (g.id === 'sbom')
          r = {
            bomFormat: 'CycloneDX',
            specVersion: '1.5',
            version: 1,
            serialNumber: 'urn:uuid:' + executionId,
            metadata: { syntheticValidationOnly: true },
            components: []
          }
        if (g.id === 'licenses')
          r = {
            schemaVersion: 2,
            total: 1,
            internalCount: 1,
            deniedCount: 0,
            unknownCount: 0,
            unclassifiedCount: 0,
            invalidExceptions: [],
            denied: [],
            unknown: [],
            unclassified: [],
            syntheticValidationOnly: true
          }
        if (g.id === 'image' && o.path.endsWith('/image.json'))
          r = {
            schemaVersion: 1,
            status: 'PASS',
            runId,
            candidateId,
            imageId: 'sha256:' + H,
            baseRef: 'synthetic@sha256:' + H,
            config: {},
            dockerfileSha256: H,
            syntheticValidationOnly: true
          }
        if (g.id === 'image-smoke')
          r = {
            schemaVersion: 1,
            status: 'PASS',
            runId,
            candidateId,
            imageId: 'sha256:' + H,
            health: 200,
            modelCalls: 0,
            uid: 10001,
            sends: 1,
            network: 'none',
            readOnly: true,
            syntheticDataTmpfs: true,
            probeSha256: H,
            syntheticValidationOnly: true
          }
        if (g.id === 'certify') {
          const candidate = {
            schemaVersion: 'aaa-candidate-v1',
            createdAt: startedAt,
            git: { head: 'synthetic', branch: 'synthetic', dirty: false },
            files: [
              { path: 'synthetic.ts', sha256: H, size: 0, tracked: false }
            ],
            candidateId,
            scope: {
              excludedPrefixes: [],
              excludedFiles: [],
              note: 'SYNTHETIC VALIDATION ONLY; no execution'
            },
            syntheticValidationOnly: true
          }
          if (o.path.endsWith('/candidate-manifest.json')) r = candidate
          else if (o.path.endsWith('/phase10-result.json'))
            r = {
              schemaVersion: 1,
              phase: '10',
              kind: 'phase10-result',
              commit: 'synthetic',
              candidate,
              runId,
              timestamp: startedAt,
              scores: {},
              findings: { P0: [], P1: [], P2: [] },
              gates: [],
              externalGates: {
                modelProvider: 'NOT_VALIDATED',
                channel: 'NOT_VALIDATED',
                externalIdentity: 'NOT_VALIDATED',
                humanSignoff: 'NOT_VALIDATED'
              },
              metrics: {},
              certification: 'NO_GO',
              decision: 'NO_GO',
              remainingBlockers: ['SYNTHETIC VALIDATION ONLY; no execution'],
              syntheticValidationOnly: true
            }
          else
            r = {
              schemaVersion: 1,
              phase: '10',
              kind: 'phase10-manifest',
              commit: 'synthetic',
              timestamp: startedAt,
              artifacts: [],
              decision: 'NO_GO',
              certification: 'NO_GO',
              candidateId,
              runId,
              syntheticValidationOnly: true
            }
        }
        if (g.id === 'e2e') r = e2e
        fs.writeFileSync(
          path.join(f.directory, o.path),
          o.path.endsWith('.xml') ? xml : JSON.stringify(r)
        )
        const b = fs.readFileSync(path.join(f.directory, o.path))
        o.sha256 = sha(b)
        o.size = b.length
      }
    }
    m.outputs = files(f.directory).filter((o) => o.path !== 'manifest.json')
    m.seals = m.gates.map((g) => sealFor(m, g))
    fs.writeFileSync(path.join(f.directory, 'manifest.json'), JSON.stringify(m))
    producerResults[c.id] = {
      schemaVersion: 1,
      result: 'success',
      artifactId: '3',
      artifactDigest: H,
      manifestSha256: sha(
        fs.readFileSync(path.join(f.directory, 'manifest.json'))
      ),
      sealSetSha256: digest(m.seals)
    }
    scopes.push({ directory: f.directory, manifest: m })
  }
  const security = {
    schemaVersion: 1,
    status: 'PASS',
    workflow: contract.security.workflow,
    sha: expected.sha,
    runId: 42,
    attempt: 1,
    workflowId: 12,
    collectedAt: finishedAt,
    jobs: contract.security.requiredJobs.map((name, i) => ({
      name,
      id: i + 1,
      status: 'completed',
      conclusion: 'success'
    }))
  }
  const provenance = {
    schemaVersion: 1,
    mode: 'INDEPENDENT_GITHUB_ATTESTATION_VERIFIED',
    sourceSha: expected.sha,
    runId,
    attempt,
    checks: contract.requiredGlobal
      .filter((x) => x !== 'security')
      .map((id) => ({ id, status: 'PASS', evidenceSha256: H }))
  }
  return { scopes, expected, producerResults, security, provenance }
}
function resealRemote(input, scope, gateId, value) {
  const f = input.scopes.find((s) => s.manifest.scope === scope)
  reseal(f, gateId, value)
  const p = input.producerResults[scope]
  p.manifestSha256 = sha(
    fs.readFileSync(path.join(f.directory, 'manifest.json'))
  )
  p.sealSetSha256 = digest(f.manifest.seals)
}
async function remoteSentinel(input) {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'hiso-preio-'))
  dirs.push(directory)
  const expectedFile = path.join(directory, 'expected.json')
  fs.writeFileSync(expectedFile, JSON.stringify(input.expected))
  const env = { ...process.env },
    oldFetch = globalThis.fetch
  let calls = 0,
    error
  Object.assign(process.env, {
    GITHUB_ACTIONS: 'true',
    GH_TOKEN: 'synthetic-placeholder',
    GITHUB_REPOSITORY: 'synthetic/repository',
    GITHUB_JOB: 'aggregate',
    GITHUB_SHA: input.expected.sha,
    GITHUB_RUN_ID: '123',
    GITHUB_RUN_ATTEMPT: '2',
    HISO_NEEDS_JSON: JSON.stringify({
      inputs: {
        result: 'success',
        outputs: { expected_sha256: sha(fs.readFileSync(expectedFile)) }
      }
    })
  })
  globalThis.fetch = async () => {
    calls++
    throw new Error('SYNTHETIC_FETCH_SENTINEL')
  }
  try {
    await collectRemoteTrust({
      ...input,
      expectedFile,
      output: path.join(directory, 'trust')
    })
  } catch (e) {
    error = e.message
  } finally {
    globalThis.fetch = oldFetch
    for (const k of Object.keys(process.env))
      if (!(k in env)) delete process.env[k]
    Object.assign(process.env, env)
  }
  return { calls, error }
}
describe('CI-R3 complete pre-I/O validation', () => {
  it('validates all four sealed synthetic namespaces and reaches only an in-memory sentinel', async () => {
    const f = remoteValidationFixture()
    expect(() => preflightScopes(f)).not.toThrow()
    expect(() => preflightRemoteEvidence(f)).not.toThrow()
    expect(await remoteSentinel(f)).toEqual({
      calls: 1,
      error: 'SYNTHETIC_FETCH_SENTINEL'
    })
    expect(isRemoteTrust(JSON.parse(JSON.stringify({ verified: true })))).toBe(
      false
    )
  })
  it('retains native license exceptions while refusing contradictory counts before fetch', async () => {
    const f = remoteValidationFixture()
    const report = {
      schemaVersion: 2,
      total: 2,
      internalCount: 1,
      deniedCount: 0,
      unknownCount: 1,
      unclassifiedCount: 0,
      invalidExceptions: [],
      denied: [],
      unknown: ['synthetic-exempt-dependency@1.0.0'],
      unclassified: [],
      syntheticValidationOnly: true
    }
    resealRemote(f, 'transition-regression', 'licenses', report)
    expect(await remoteSentinel(f)).toEqual({
      calls: 1,
      error: 'SYNTHETIC_FETCH_SENTINEL'
    })
    resealRemote(f, 'transition-regression', 'licenses', {
      ...report,
      unknownCount: 2
    })
    const denied = await remoteSentinel(f)
    expect(denied.calls).toBe(0)
    expect(denied.error).toContain('snapshot_types:licenses')
  })
  const corruptions = [
    ['expected schema', (f) => (f.expected.schemaVersion = 999)],
    ['expected contract', (f) => (f.expected.contract = 'unknown')],
    ['expected type', (f) => (f.expected.attempt = 2)],
    ['expected scope map', (f) => (f.expected.scopes = [])],
    [
      'expected scope schema',
      (f) => (f.expected.scopes['transition-regression'].schemaVersion = 999)
    ],
    [
      'expected scope contract',
      (f) => (f.expected.scopes['transition-regression'].contract = 'unknown')
    ],
    [
      'expected scope type',
      (f) =>
        (f.expected.scopes['transition-regression'].requiredTestIds = 'invalid')
    ],
    ['manifest schema', (f) => (f.scopes[3].manifest.schemaVersion = 999)],
    ['manifest contract', (f) => (f.scopes[3].manifest.contract = 'unknown')],
    ['manifest type', (f) => (f.scopes[3].manifest.finishedAt = 123)],
    ['manifest outputs', (f) => (f.scopes[3].manifest.outputs[0].size = '12')],
    [
      'producer schema',
      (f) => (f.producerResults['transition-regression'].schemaVersion = 999)
    ],
    [
      'producer contract',
      (f) => (f.producerResults['transition-regression'].contract = 'unknown')
    ],
    [
      'producer type',
      (f) => (f.producerResults['transition-regression'].artifactId = true)
    ],
    [
      'producers inventory',
      (f) => delete f.producerResults['transition-regression']
    ],
    ['gate schema', (f) => (f.scopes[3].manifest.gates[0].schemaVersion = 999)],
    [
      'gate contract',
      (f) => (f.scopes[3].manifest.gates[0].contract = 'unknown')
    ],
    ['gate type', (f) => (f.scopes[3].manifest.gates[0].skipped = '0')],
    ['seal schema', (f) => (f.scopes[3].manifest.seals[0].schemaVersion = 999)],
    [
      'seal contract',
      (f) => (f.scopes[3].manifest.seals[0].contract = 'unknown')
    ],
    ['seal type', (f) => (f.scopes[3].manifest.seals[0].entrySha256 = 0)],
    [
      'snapshot schema',
      (f) =>
        resealRemote(f, 'transition-regression', 'unit', { schemaVersion: 999 })
    ],
    [
      'snapshot contract',
      (f) =>
        resealRemote(f, 'transition-regression', 'unit', {
          contract: 'unknown'
        })
    ],
    [
      'snapshot type',
      (f) => resealRemote(f, 'transition-regression', 'unit', [])
    ],
    ['security schema', (f) => (f.security.schemaVersion = 999)],
    ['security contract', (f) => (f.security.contract = 'unknown')],
    ['security type', (f) => (f.security.runId = '42')],
    ['security job type', (f) => (f.security.jobs[0].id = '1')],
    ['provenance schema', (f) => (f.provenance.schemaVersion = 999)],
    ['provenance contract', (f) => (f.provenance.contract = 'unknown')],
    ['provenance type', (f) => (f.provenance.checks[0].evidenceSha256 = 0)],
    [
      'global zero branches',
      (f) => {
        for (const s of f.scopes)
          if (s.manifest.coverage)
            for (const v of Object.values(s.manifest.coverage))
              v.branches = { total: 0, covered: 0, skipped: 0, pct: 100 }
      }
    ]
  ]
  it.each(corruptions)('denies %s before any remote I/O', async (_, change) => {
    const f = remoteValidationFixture()
    change(f)
    const r = await remoteSentinel(f)
    expect(r.calls).toBe(0)
    expect(r.error).toBeTruthy()
    expect(r.error).not.toBe('SYNTHETIC_FETCH_SENTINEL')
  })
})

describe('CI-R3 native counters and weighted canonical denominators', () => {
  const report = () => ({
    success: true,
    numTotalTests: 1,
    numPassedTests: 1,
    numFailedTests: 0,
    numPendingTests: 0,
    numTodoTests: 0,
    numTotalTestSuites: 1,
    numPassedTestSuites: 1,
    numFailedTestSuites: 0,
    numPendingTestSuites: 0,
    testResults: [
      {
        name: 'tests/a.test.js',
        status: 'passed',
        assertionResults: [
          { ancestorTitles: [], title: 'case', status: 'passed' }
        ]
      }
    ]
  })
  it.each([
    'numPendingTests',
    'numTodoTests',
    'numFailedTests',
    'numPendingTestSuites',
    'numFailedTestSuites',
    'numPassedTestSuites',
    'numTotalTestSuites'
  ])('rejects contradictory %s', (key) => {
    const r = report()
    r[key] =
      key.includes('PassedTestSuites') || key.includes('TotalTestSuites')
        ? 0
        : 12
    expect(() => testReport(r, ['tests/a.test.js'])).toThrow()
    r[key] = '0'
    expect(() => testReport(r, ['tests/a.test.js'])).toThrow()
  })
  it('retains a native 3510-case / 372-file report with 900 nested suites', () => {
    const r = report()
    r.testResults = Array.from({ length: 372 }, (_, i) => ({
      name: `tests/${i}.test.js`,
      status: 'passed',
      assertionResults: Array.from({ length: i === 0 ? 171 : 9 }, (_, j) => ({
        ancestorTitles: ['nested'],
        title: `case${j}`,
        status: 'passed'
      }))
    }))
    r.numTotalTests = 3510
    r.numPassedTests = 3510
    r.numTotalTestSuites = 900
    r.numPassedTestSuites = 900
    const known = r.testResults.map((f) => f.name)
    expect(testReport(r, known)).toHaveLength(3510)
    r.schemaVersion = 999
    expect(() => testReport(r, known)).toThrow('schema_version')
  })
  it('accepts native governed skips only when the optional counters agree', () => {
    const r = report()
    r.numTotalTests = 3
    r.numPendingTests = 1
    r.numTodoTests = 1
    r.testResults[0].assertionResults.push(
      { ancestorTitles: [], title: 'skip', status: 'skipped' },
      { ancestorTitles: [], title: 'todo', status: 'todo' }
    )
    expect(testReport(r, ['tests/a.test.js'], 'governed')).toHaveLength(3)
    expect(() => testReport(r, ['tests/a.test.js'])).toThrow('required_skip')
    r.numTodoTests = 0
    expect(() => testReport(r, ['tests/a.test.js'], 'governed')).toThrow(
      'numTodoTests'
    )
  })
  it.each(['statements', 'branches', 'functions', 'lines'])(
    'denies global zero %s for all 281 canonical sources',
    (metric) => {
      const root = path.resolve(import.meta.dirname, '..'),
        sources = coverageSourceInventory(root),
        paths = sources.map((s) => s.path)
      expect(paths).toEqual(expectedCoveragePaths(root))
      const c = Object.fromEntries(paths.map((p) => [p, coverage(1, 1)]))
      for (const v of Object.values(c))
        v[metric] = { total: 0, covered: 0, skipped: 0, pct: 100 }
      expect(() => aggregateCoverage([c], paths, sources)).toThrow(
        /coverage_empty/
      )
    }
  )
  it('keeps legitimate type-only and per-file branch/function zero with positive global totals', () => {
    const c = {
      'packages/types.ts': coverage(0, 0),
      'packages/a.ts': coverage(1000, 900),
      'packages/b.ts': coverage(1, 1)
    }
    c['packages/b.ts'].branches = { total: 0, covered: 0, skipped: 0, pct: 100 }
    c['packages/b.ts'].functions = {
      total: 0,
      covered: 0,
      skipped: 0,
      pct: 100
    }
    const sources = Object.keys(c).map((p) => ({
      path: p,
      sha256: H,
      executable: p !== 'packages/types.ts'
    }))
    const r = aggregateCoverage([c], Object.keys(c), sources)
    expect(r.pass).toBe(true)
    expect(r.totals.statements.total).toBe(1001)
    expect(r.totals.branches.total).toBe(1000)
    expect(r.totals.statements.pct).toBe((100 * 901) / 1001)
  })
})

it('denies every coherently resealed JSON snapshot schema before a remote fetch', async () => {
  const f = remoteValidationFixture()
  let checked = 0
  for (const scope of f.scopes)
    for (const gate of scope.manifest.gates)
      for (const output of gate.outputs) {
        if (!output.path.endsWith('.json')) continue
        const report = JSON.parse(
          fs.readFileSync(path.join(scope.directory, output.path))
        )
        const old = structuredClone(report)
        report.schemaVersion = 999
        // Every output inventory, content seal, and producer digest is updated.
        // Rejection must be semantic, rather than a mismatching byte hash.
        const bytes = JSON.stringify(report)
        fs.writeFileSync(path.join(scope.directory, output.path), bytes)
        output.sha256 = sha(bytes)
        output.size = Buffer.byteLength(bytes)
        scope.manifest.outputs = files(scope.directory).filter(
          (o) => o.path !== 'manifest.json'
        )
        scope.manifest.seals = scope.manifest.gates.map((g) =>
          sealFor(scope.manifest, g)
        )
        fs.writeFileSync(
          path.join(scope.directory, 'manifest.json'),
          JSON.stringify(scope.manifest)
        )
        const producer = f.producerResults[scope.manifest.scope]
        producer.manifestSha256 = sha(
          fs.readFileSync(path.join(scope.directory, 'manifest.json'))
        )
        producer.sealSetSha256 = digest(scope.manifest.seals)
        const observed = await remoteSentinel(f)
        expect(observed.calls, `${scope.manifest.scope}/${output.path}`).toBe(0)
        expect(
          observed.error,
          `${scope.manifest.scope}/${output.path}`
        ).toContain('schema_version')
        const restored = JSON.stringify(old)
        fs.writeFileSync(path.join(scope.directory, output.path), restored)
        output.sha256 = sha(restored)
        output.size = Buffer.byteLength(restored)
        scope.manifest.outputs = files(scope.directory).filter(
          (o) => o.path !== 'manifest.json'
        )
        scope.manifest.seals = scope.manifest.gates.map((g) =>
          sealFor(scope.manifest, g)
        )
        fs.writeFileSync(
          path.join(scope.directory, 'manifest.json'),
          JSON.stringify(scope.manifest)
        )
        producer.manifestSha256 = sha(
          fs.readFileSync(path.join(scope.directory, 'manifest.json'))
        )
        producer.sealSetSha256 = digest(scope.manifest.seals)
        checked++
      }
  expect(checked).toBe(52)
  expect(await remoteSentinel(f)).toEqual({
    calls: 1,
    error: 'SYNTHETIC_FETCH_SENTINEL'
  })
})

it('validates all namespaces before the first provenance CLI signature subprocess', () => {
  const f = remoteValidationFixture(),
    root = path.resolve(import.meta.dirname, '..')
  const directory = fs.mkdtempSync(
    path.join(os.tmpdir(), 'hiso-signature-preio-')
  )
  dirs.push(directory)
  const input = path.join(directory, 'input'),
    output = path.join(directory, 'output'),
    bin = path.join(directory, 'bin'),
    sentinel = path.join(directory, 'signature-calls.jsonl')
  fs.mkdirSync(bin, { recursive: true })
  fs.writeFileSync(
    path.join(bin, 'gh'),
    `#!${process.execPath}\nimport fs from 'node:fs';fs.appendFileSync(process.env.HISO_SIGNATURE_SENTINEL, 'SYNTHETIC_SIGNATURE_SENTINEL\\n');process.exit(77)\n`,
    { mode: 0o700 }
  )
  const ef = path.join(input, 'hiso-inputs-123-2/expected.json')
  fs.mkdirSync(path.dirname(ef), { recursive: true })
  fs.writeFileSync(ef, JSON.stringify(f.expected))
  const needs = {
    attest: { result: 'success' },
    inputs: {
      result: 'success',
      outputs: { expected_sha256: sha(fs.readFileSync(ef)) }
    }
  }
  for (const s of f.scopes) {
    fs.cpSync(s.directory, path.join(input, `hiso-${s.manifest.scope}-123-2`), {
      recursive: true
    })
    const p = f.producerResults[s.manifest.scope]
    needs[s.manifest.scope] = {
      result: 'success',
      outputs: {
        artifact_id: p.artifactId,
        artifact_digest: p.artifactDigest,
        manifest_sha256: p.manifestSha256,
        seal_set_sha256: p.sealSetSha256
      }
    }
  }
  const env = {
    ...process.env,
    GITHUB_ACTIONS: 'true',
    GH_TOKEN: 'synthetic-placeholder',
    GITHUB_REPOSITORY: 'synthetic/repository',
    GITHUB_SHA: f.expected.sha,
    GITHUB_RUN_ID: '123',
    GITHUB_RUN_ATTEMPT: '2',
    HISO_NEEDS_JSON: JSON.stringify(needs),
    HISO_SIGNATURE_SENTINEL: sentinel,
    PATH: bin + path.delimiter + process.env.PATH
  }
  const run = () =>
    spawnSync(
      process.execPath,
      ['scripts/hiso-provenance.mjs', input, output],
      { cwd: root, env, encoding: 'utf8' }
    )
  const subject = path.join(
      input,
      'hiso-transition-regression-123-2/manifest.json'
    ),
    m = JSON.parse(fs.readFileSync(subject))
  fs.writeFileSync(subject, JSON.stringify({ ...m, schemaVersion: 999 }))
  const denied = run()
  expect(denied.status).toBe(1)
  expect(denied.stderr).toContain('schema_version:manifest')
  expect(fs.existsSync(sentinel)).toBe(false)
  fs.writeFileSync(subject, JSON.stringify(m))
  const valid = run()
  expect(valid.status).toBe(1)
  expect(valid.stderr).toContain('independent_attestation_verification_failed')
  expect(fs.readFileSync(sentinel, 'utf8').trim()).toBe(
    'SYNTHETIC_SIGNATURE_SENTINEL'
  )
  expect(
    JSON.parse(fs.readFileSync(path.join(output, 'provenance.json'))).status
  ).toBe('FAIL')
})

// Private, synthetic sources exercise the complete approved denominator without
// changing a candidate file. The dependency link only supplies the TS parser.
function syntheticCoverageRoot() {
  const root = path.resolve(import.meta.dirname, '..')
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'hiso-ci-r4-source-'))
  dirs.push(directory)
  const write = (p, text) => {
    fs.mkdirSync(path.dirname(path.join(directory, p)), { recursive: true })
    fs.writeFileSync(path.join(directory, p), text)
  }
  copyProjectionConfigs(root, directory)
  const paths = expectedCoveragePaths(root)
  for (const p of paths) write(p, 'export interface SyntheticOnly {}\n')
  linkPrivateParser(root, directory)
  return { directory, paths, write }
}
describe('CI-R4 fresh source and immutable input controls', () => {
  it('detects equal-size source replacement with retained mtime across independent calls and frozen inputs', () => {
    const f = syntheticCoverageRoot(),
      p = f.paths[0]
    const first = 'export type Synthetic = string;'.padEnd(80, ' ')
    const changed = 'export const Synthetic = 1;'.padEnd(80, ' ')
    f.write(p, first)
    fs.utimesSync(path.join(f.directory, p), 1700000000, 1700000000)
    const stat = fs.statSync(path.join(f.directory, p))
    const inputs = Object.freeze(sourceFiles(f.directory).map(Object.freeze))
    const before = coverageSourceInventory(f.directory, inputs)
    expect(before.map((source) => source.path)).toEqual(f.paths)
    expect(before.find((s) => s.path === p)).toEqual({
      path: p,
      sha256: sha(first),
      executable: false
    })
    f.write(p, changed)
    fs.utimesSync(path.join(f.directory, p), stat.atime, stat.mtime)
    expect(fs.statSync(path.join(f.directory, p)).size).toBe(stat.size)
    expect(fs.statSync(path.join(f.directory, p)).mtimeMs).toBe(stat.mtimeMs)
    const after = coverageSourceInventory(f.directory)
    expect(after.find((s) => s.path === p)).toEqual({
      path: p,
      sha256: sha(changed),
      executable: true
    })
    expect(coverageSourceInventory(f.directory, inputs)).toEqual(after)
    expect(digest(sourceFiles(f.directory))).not.toBe(digest(inputs))
    f.write(p, first)
    expect(coverageSourceInventory(f.directory, inputs)).toEqual(before)
  })
  it('matches isolated transpilation for runtime, erased and ambiguous TypeScript syntax', () => {
    const f = syntheticCoverageRoot()
    const texts = [
      'export interface I {}; export type T = string;',
      'declare const value: number; declare class C {}',
      'export function overload(x: string): void;',
      'import type { T } from "./other"; export type { T };',
      'import "./side-effect"; export {};',
      'export const value = 1; export function fn() { return value }',
      'export class C { value = 1 };',
      'export const enum E { value = 1 }',
      'namespace N { export interface I {} }',
      'namespace N { export const value = 1 }',
      'import value = require("./other"); export = value;',
      'export default 1;',
      'declare namespace N { const value: number }',
      'export const value = (<number>1);'
    ]
    const selected = f.paths
      .filter((p) => p.endsWith('.ts'))
      .slice(0, texts.length)
    expect(selected).toHaveLength(texts.length)
    expect(selected.every(Boolean)).toBe(true)
    selected.forEach((p, i) => f.write(p, texts[i]))
    const ts = createRequire(path.join(f.directory, 'package.json'))(
      'typescript'
    )
    const actual = coverageSourceInventory(f.directory)
    expect(actual.map((source) => source.path)).toEqual(f.paths)
    selected.forEach((p, i) => {
      const emitted = ts.transpileModule(texts[i], {
        compilerOptions: {
          target: ts.ScriptTarget.ES2022,
          module: ts.ModuleKind.ESNext
        },
        fileName: p
      }).outputText
      const ast = ts.createSourceFile(p, emitted, ts.ScriptTarget.Latest, true)
      const executable = ast.statements.some(
        (s) =>
          !ts.isExportDeclaration(s) &&
          !ts.isImportDeclaration(s) &&
          !ts.isEmptyStatement(s)
      )
      expect(
        actual.find((s) => s.path === p),
        p
      ).toEqual({
        path: p,
        sha256: sha(texts[i]),
        executable
      })
    })
  })
  it('rechecks a coherently resealed payload on the same previously valid fixture reference before fetch', async () => {
    const f = remoteValidationFixture()
    expect(await remoteSentinel(f)).toEqual({
      calls: 1,
      error: 'SYNTHETIC_FETCH_SENTINEL'
    })
    const scope = f.scopes.find(
      (s) => s.manifest.scope === 'transition-regression'
    )
    const output = scope.manifest.gates.find((g) => g.id === 'licenses')
      .outputs[0]
    const original = JSON.parse(
      fs.readFileSync(path.join(scope.directory, output.path))
    )
    resealRemote(f, 'transition-regression', 'licenses', {
      ...original,
      schemaVersion: 999
    })
    const denied = await remoteSentinel(f)
    expect(denied.calls).toBe(0)
    expect(denied.error).toContain('schema_version:licenses')
    resealRemote(f, 'transition-regression', 'licenses', original)
    expect(await remoteSentinel(f)).toEqual({
      calls: 1,
      error: 'SYNTHETIC_FETCH_SENTINEL'
    })
  })
})
