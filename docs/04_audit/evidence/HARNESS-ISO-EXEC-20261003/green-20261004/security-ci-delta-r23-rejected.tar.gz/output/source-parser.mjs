import { stripVTControlCharacters } from 'node:util'
export function parseVitestSummary(log, label) {
  // Node's terminal stripper leaves parts of OSC titles containing spaces.
  // Remove complete OSC strings first; an unfinished OSC cannot yield evidence.
  const withoutOsc = log.replace(
    /(?:\u001b\]|\u009d)[\s\S]*?(?:\u0007|\u001b\\|\u009c)/g,
    ''
  )
  if (/(?:\u001b\]|\u009d)/.test(withoutOsc)) return null
  const line = stripVTControlCharacters(withoutOsc)
    .split('\n')
    .map((entry) => entry.trim())
    .find((entry) => entry.startsWith(label))
  if (!line) return null
  const counts = { passed: 0, failed: 0, skipped: 0 }
  for (const match of line.matchAll(/(\d+)\s+(passed|failed|skipped)/g)) {
    counts[match[2]] += Number(match[1])
  }
  const totalMatch = /\((\d+)\)\s*$/.exec(line)
  return {
    ...counts,
    total: totalMatch
      ? Number(totalMatch[1])
      : counts.passed + counts.failed + counts.skipped
  }
}

