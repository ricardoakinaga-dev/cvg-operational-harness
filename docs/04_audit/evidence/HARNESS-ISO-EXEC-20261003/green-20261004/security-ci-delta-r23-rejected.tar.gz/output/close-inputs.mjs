import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';import {strict as assert} from 'node:assert';
const a=JSON.parse(fs.readFileSync('authority.json'));const sha=x=>createHash('sha256').update(x).digest('hex');
const before=JSON.parse(fs.readFileSync('output/raw/input-snapshot-before.json'));
for(const p of ['.nvmrc','scripts/phase10-verify.mjs']){
 const row={path:p,role:'referenced-immutable'};
 for(const [variant,root] of [['source',a.sourceReadonly],['original',a.originalReadonly]]){
  const bytes=fs.readFileSync(path.join(root,p));const target=path.join(a.write,variant,p);
  fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,bytes);
  row[variant]={exists:true,sha256:sha(bytes),size:bytes.length};
 }
 row.sameBytes=row.source.sha256===row.original.sha256;assert.equal(row.sameBytes,true);before.files.push(row);
}
const rebind=JSON.parse(fs.readFileSync('output/raw/catalog-rebind.json'));
for(const r of rebind.rebinds)before.files.push({path:r.path,role:'catalog-rebind-target',source:{...r.source,exists:true},original:{...r.original,exists:true},sameBytes:r.referencedFileUnchanged});
const toolRows=[['node22','/home/ricardo/.nvm/versions/node/v22.23.2/bin/node'],['gitleaks',a.scanner],['strictConfig',a.strictScannerConfig],['emptyIgnore',a.emptyIgnore]];
const tools=toolRows.map(([name,p])=>{const bytes=fs.readFileSync(p);return {name,path:p,sha256:sha(bytes),size:bytes.length}});
const after=before.files.map(r=>{
 const row={path:r.path,role:r.role};
 for(const [variant,root] of [['source',a.sourceReadonly],['original',a.originalReadonly]]){
  const file=path.join(root,r.path);const exists=fs.existsSync(file);const bytes=exists?fs.readFileSync(file):null;
  row[variant]={exists,...(exists?{sha256:sha(bytes),size:bytes.length}:{})};
  assert.deepEqual(row[variant],r[variant],`immutable input changed: ${variant}/${r.path}`);
 }
 return row;
});
assert.equal(sha(fs.readFileSync('authority.json')),before.authoritySha256);assert.equal(sha(fs.readFileSync(a.deltaReadonly)),before.bindingSha256);
const oldInventory=JSON.parse(fs.readFileSync('output/original/scripts/hiso-baseline-inventory.json'));const inventory=JSON.parse(fs.readFileSync('output/source/scripts/hiso-baseline-inventory.json'));
assert.equal(oldInventory.newTests.length,46);assert.equal(inventory.newTests.length,47);
assert.deepEqual(inventory.newTests.filter(x=>x!=='tests/certification-summary-ansi-own.test.js'),oldInventory.newTests);
assert.deepEqual({...inventory,newTests:oldInventory.newTests},oldInventory);
const catalogOld=JSON.parse(fs.readFileSync('output/original/scripts/skip-catalog.json'));const catalogNew=JSON.parse(fs.readFileSync('output/source/scripts/skip-catalog.json'));
assert.equal(rebind.rebinds.length,4);assert.ok(rebind.rebinds.every(x=>x.hashOnlyChange&&x.newBindingMatches&&x.referencedFileUnchanged));
assert.deepEqual(catalogNew.entries.map(({sourceSha256,...rest})=>rest),catalogOld.entries.map(({sourceSha256,...rest})=>rest));
assert.deepEqual({...catalogNew,entries:catalogOld.entries},catalogOld);
const scanFiles=[];
function visit(dir){for(const d of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,d.name);if(d.isDirectory())visit(p);else scanFiles.push(path.relative('output/strict-fivepath',p));}}
visit('output/strict-fivepath');const expected=before.files.filter(x=>x.role==='delta').map(x=>x.path).sort();assert.deepEqual(scanFiles.sort(),expected);
for(const p of scanFiles)assert.equal(sha(fs.readFileSync(path.join('output/strict-fivepath',p))),sha(fs.readFileSync(path.join('output/source',p))));
assert.equal(fs.readFileSync('output/scan-tools/empty.gitleaksignore').length,0);assert.equal(fs.readFileSync('output/scan-tools/strict-default.toml','utf8'),'[extend]\nuseDefault = true\n');
const result={at:new Date().toISOString(),node:process.version,allRelevantInputsStable:true,freezePolicy:'five changed inputs plus named referenced immutable libs/configs/rebind targets only; generated Source certification/cache outputs not enumerated or frozen',files:after,tools,authoritySha256:before.authoritySha256,bindingSha256:before.bindingSha256,metadataChecks:{baselineNewTests:[46,47],inventoryOnlySingleAddition:true,catalogHashOnlyChanges:4,allReboundTargetsUnchangedVsR19:true,scanExactlyFivePaths:true,strictConfigOnlyDefaultRules:true,emptyIgnoreBytes:0}};
fs.writeFileSync('output/raw/input-snapshot-after.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({node:result.node,allRelevantInputsStable:result.allRelevantInputsStable,frozenPaths:after.length,metadataChecks:result.metadataChecks,tools}));
