import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
const a=JSON.parse(fs.readFileSync('authority.json','utf8'));
const bindingBytes=fs.readFileSync(a.deltaReadonly);
const b=JSON.parse(bindingBytes);
const sha=x=>createHash('sha256').update(x).digest('hex');
const out=a.write;
const refs=['scripts/lib/coverage-gate.mjs','scripts/lib/e2e-report-binding.mjs','scripts/lib/skip-governance.mjs','package.json','.github/codeql/active-source.yml','.github/workflows/security.yml'];
fs.mkdirSync(path.join(out,'raw'),{recursive:true});
fs.mkdirSync(path.join(out,'inputs'),{recursive:true});
fs.copyFileSync('authority.json',path.join(out,'inputs/authority.json'));
fs.writeFileSync(path.join(out,'inputs/source-binding-scoped.json'),JSON.stringify({beforeFiles:b.beforeFiles,afterFiles:b.afterFiles,removed:b.removed,differences:b.differences,candidateId:b.candidate.candidateId,bindingSha256:sha(bindingBytes)},null,2)+'\n');
const rows=[];
for(const p of [...b.differences.map(x=>x.path),...refs]) {
 const row={path:p,role:b.differences.some(x=>x.path===p)?'delta':'referenced-immutable'};
 for(const [label,root] of [['source',a.sourceReadonly],['original',a.originalReadonly]]){
  const file=path.join(root,p);
  if(!fs.existsSync(file)){row[label]={exists:false};continue;}
  const bytes=fs.readFileSync(file);
  const target=path.join(out,label,p);
  fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,bytes);
  row[label]={exists:true,sha256:sha(bytes),size:bytes.length};
 }
 row.sameBytes=row.source.exists&&row.original.exists&&row.source.sha256===row.original.sha256;
 const expected=b.differences.find(x=>x.path===p)||b.candidate.files.find(x=>x.path===p);
 row.bindingMatches=row.source.sha256===expected?.sha256&&row.source.size===expected?.size;
 rows.push(row);
}
fs.writeFileSync(path.join(out,'raw/input-snapshot-before.json'),JSON.stringify({at:new Date().toISOString(),node:process.version,authoritySha256:sha(fs.readFileSync('authority.json')),bindingSha256:sha(bindingBytes),files:rows},null,2)+'\n');
for(const row of rows.filter(x=>x.role==='delta'))console.log(JSON.stringify(row));
console.log(JSON.stringify({referencePaths:refs,allReferencesUnchanged:rows.filter(x=>x.role!=='delta').every(x=>x.sameBytes&&x.bindingMatches)}));
