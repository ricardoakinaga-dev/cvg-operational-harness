import fs from 'node:fs';import {strict as assert} from 'node:assert';import {performance} from 'node:perf_hooks';import {createHash} from 'node:crypto';
import {parseVitestSummary as current} from './source-parser.mjs';
import {parseVitestSummary as old} from './original-parser.mjs';
import {deriveGateOutcome} from './source-gate.mjs';
assert.match(process.version,/^v22\./);
const rawDir='output/raw';const sha=s=>createHash('sha256').update(s).digest('hex');
const results=[];
const record=x=>{results.push(x);console.log(JSON.stringify(x))};
const pass={passed:1,failed:0,skipped:0,total:1};const fail={passed:0,failed:1,skipped:0,total:1};
const cases=[
 ['plain-first-failure','Tests 1 failed (1)\nTests 999 passed (999)',fail],
 ['SGR-with-C1','\x9b31mTests 1 failed (1)\x9b0m\nTests 999 passed (999)',fail],
 ['OSC-ESC-ST','\x1b]0;with spaces\x1b\\Tests 1 failed (1)\nTests 999 passed (999)',fail],
 ['OSC-C1-ST','\x9d0;with spaces\x9cTests 1 failed (1)\nTests 999 passed (999)',fail],
 ['OSC-inline-no-count-fabrication','Tests 1 \x1b]0;999 passed\x07failed (1)',fail],
 ['OSC-after-valid-summary-unclosed','Tests 1 passed (1)\n\x1b]0;unclosed',null],
 ['OSC-before-later-summary-unclosed','\x1b]0;unclosed\nTests 1 passed (1)',null],
 ['OSC-complete-with-summary-in-payload','\x1b]0;Tests 99 passed (99)\x07\nTests 1 failed (1)',fail],
 ['OSC-empty','\x1b]\x07Tests 1 failed (1)',fail],
 ['OSC-hyperlink-close','\x1b]8;;https://example.invalid/path with spaces\x1b\\Tests 1 failed (1)\x1b]8;;\x1b\\',fail],
 ['shell-metacharacters-data','$(touch OWN_CANARY); `touch OWN_CANARY`;\nTests 1 failed (1)',fail],
 ['NUL-prefix-cannot-select-later','\x00Tests 1 failed (1)',null],
 ['zero-passed','Tests 0 passed (0)',{passed:0,failed:0,skipped:0,total:0}],
 ['skip-preserved','Tests 1 passed | 1 skipped (2)',{passed:1,failed:0,skipped:1,total:2}],
 ['missing-summary','random',null]
];
for(const [name,input,expected] of cases){const actual=current(input,'Tests');assert.deepEqual(actual,expected,name);record({type:'functional',name,input,actual,expected,status:'PASS'});}
const gate={id:'unit',exitCode:0,metrics:{filesPassed:1,filesFailed:0,filesSkipped:0,testsPassed:1,testsFailed:0,testsSkipped:0}};
for(const [name,log,exitCode,expected] of [
 ['decorated-pass','\x1b[32mTest Files 1 passed (1)\x1b[0m\n\x1b[32mTests 1 passed (1)\x1b[0m',0,true],
 ['unclosed-OSC-rejected','Test Files 1 passed (1)\nTests 1 passed (1)\n\x1b]0;unfinished',0,false],
 ['failure-not-masked','Test Files 1 passed (1)\n\x1b]0;title with spaces\x1b\\Tests 1 failed (1)\nTests 999 passed (999)',0,false],
 ['nonzero-exit-rejected','Test Files 1 passed (1)\nTests 1 passed (1)',1,false],
 ['metrics-disagreement-rejected','Test Files 2 passed (2)\nTests 1 passed (1)',0,false],
 ['skips-rejected','Test Files 1 passed (1)\nTests 1 passed | 1 skipped (2)',0,false]
]){
 const actual=deriveGateOutcome({gate:{...gate,exitCode},entry:{kind:'vitest',skipPolicy:'none'},artifactReader(){throw new Error('Unexpected artifact read')},log:Buffer.from(log),result:{}});
 assert.equal(actual.pass,expected,name);record({type:'gate-dataflow',name,input:log,actual,expectedPass:expected,status:'PASS'});
}
assert.equal(fs.existsSync('OWN_CANARY'),false);
for(let i=0;i<50;i++){current('Tests 1 passed (1)','Tests');old('Tests 1 passed (1)','Tests');}
const timing=[];
// Finite 3 samples at each size. Max input <132KiB, no subprocesses, no unbounded loop.
for(const n of [1024,2048,4096,8192,16384,32768]){
 const input='\x1b]0;'.repeat(n)+'\nTest Files 1 passed (1)\nTests 1 passed (1)';
 const filename=`${rawDir}/osc-unclosed-${n}.bin`;fs.writeFileSync(filename,input);
 const row={type:'timing',name:'repeated-unclosed-OSC',openers:n,bytes:Buffer.byteLength(input),sha256:sha(input),file:filename,sourceMs:[],originalMs:[]};
 for(let sample=0;sample<3;sample++){
  let t=performance.now();const previous=old(input,'Tests');row.originalMs.push(performance.now()-t);assert.deepEqual(previous,pass);
  t=performance.now();const actual=current(input,'Tests');row.sourceMs.push(performance.now()-t);assert.equal(actual,null);
 }
 row.sourceMedianMs=[...row.sourceMs].sort((a,b)=>a-b)[1];row.originalMedianMs=[...row.originalMs].sort((a,b)=>a-b)[1];
 timing.push(row);record(row);
}
for(const [name,input] of [
 ['repeated-openers-terminated','\x1b]0;'.repeat(32768)+'\x07\nTests 1 failed (1)'],
 ['long-SGR-unterminated','\x1b['+'1;'.repeat(32768)+'\nTests 1 failed (1)'],
 ['long-plain-log','x'.repeat(131072)+'\nTests 1 failed (1)']
]){const t=performance.now();const actual=current(input,'Tests');assert.deepEqual(actual,fail);record({type:'timing-control',name,bytes:Buffer.byteLength(input),durationMs:performance.now()-t,actual,status:'PASS'});}
fs.writeFileSync(`${rawDir}/probes.json`,JSON.stringify({node:process.version,results,timing,functionalPass:true,gateDataflowPass:true},null,2)+'\n');
