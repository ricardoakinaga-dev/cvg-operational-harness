import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';import {strict as assert} from 'node:assert';
const out='output',sha=b=>createHash('sha256').update(b).digest('hex');
const a=JSON.parse(fs.readFileSync('authority.json'));const report=JSON.parse(fs.readFileSync(`${out}/report.json`));const last=JSON.parse(fs.readFileSync(`${out}/raw/input-snapshot-after.json`));const manifest=JSON.parse(fs.readFileSync(`${out}/manifest.json`));
assert.match(process.version,/^v22\./);assert.equal(report.verdict,'REJECT');assert.equal(report.findings.length,1);assert.equal(report.findings[0].id,'R23-SEC-001');assert.equal(report.changedInputs.length,5);
let verifiedArtifacts=0;
for(const item of manifest.artifacts){const bytes=fs.readFileSync(path.join(out,item.path));assert.equal(sha(bytes),item.sha256,item.path);assert.equal(bytes.length,item.size,item.path);verifiedArtifacts++;}
for(const item of last.files){for(const [variant,root] of [['source',a.sourceReadonly],['original',a.originalReadonly]]){
 const absolute=path.join(root,item.path);const exists=fs.existsSync(absolute);assert.equal(exists,item[variant].exists,`${variant}/${item.path}`);
 if(exists){const bytes=fs.readFileSync(absolute);assert.equal(sha(bytes),item[variant].sha256,`${variant}/${item.path}`);assert.equal(bytes.length,item[variant].size);const copy=fs.readFileSync(path.join(out,variant,item.path));assert.equal(sha(copy),sha(bytes));}
}}
assert.equal(sha(fs.readFileSync('authority.json')),last.authoritySha256);assert.equal(sha(fs.readFileSync(a.deltaReadonly)),last.bindingSha256);
const regression=fs.readFileSync(`${out}/raw/copied-regression.stdout`,'utf8');assert.ok(regression.includes('"cases":23,"assertions":30,"status":"PASS"'));
for(const p of ['preparation','extraction','copied-regression','probes','confirmation','close-inputs'])assert.equal(fs.readFileSync(`${out}/raw/${p}.stderr`).length,0,p);
const input=fs.readFileSync(`${out}/raw/osc-unclosed-32768.bin`);assert.equal(input.length,131115);assert.equal(sha(input),report.findings[0].inputRecipe.inputSha256);
const result={at:new Date().toISOString(),status:'PASS',node:process.version,verdict:'REJECT',findingId:'R23-SEC-001',previousManifestArtifactHashesVerified:verifiedArtifacts,relevantImmutablePathsRechecked:last.files.length,sourceAndR19CopiesMatch:true,sourceAndR19RelevantInputsUnchanged:true,authorityAndBindingUnchanged:true,maxSyntheticInputBytes:input.length,fullAuditOrNewProbe:false,allSubstantiveRawStderrEmpty:true};
fs.writeFileSync(`${out}/raw/final-verification.json`,JSON.stringify(result,null,2)+'\n');
const artifacts=[];function walk(dir){for(const d of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,d.name);if(d.isDirectory())walk(p);else if(path.relative(out,p)!=='manifest.json'){const b=fs.readFileSync(p);artifacts.push({path:path.relative(out,p),sha256:sha(b),size:b.length});}}}walk(out);artifacts.sort((x,y)=>x.path.localeCompare(y.path));
manifest.artifacts=artifacts;manifest.finalVerifiedAt=result.at;manifest.finalVerification='raw/final-verification.json';fs.writeFileSync(`${out}/manifest.json`,JSON.stringify(manifest,null,2)+'\n');
for(const item of manifest.artifacts){assert.equal(sha(fs.readFileSync(path.join(out,item.path))),item.sha256);}
console.log(JSON.stringify({...result,finalArtifactCount:manifest.artifacts.length,manifestSha256:sha(fs.readFileSync(`${out}/manifest.json`))}));
