# REJECT — scoped R23 CI delta security review

One reproduced finding blocks acceptance of this five-path delta: **R23-SEC-001 (MEDIUM, CWE-1333)**, quadratic synchronous OSC handling in `scripts/lib/certification-rules.mjs:559–563`. This verdict is limited to CI parser availability; it is not a whole-candidate or production decision.

## Reproduction and impact

Node **v22.23.2** executed a verbatim parser slice in this output directory. The synthetic input is `"\x1b]0;".repeat(32768) + "\nTest Files 1 passed (1)\nTests 1 passed (1)"`, **131115 bytes**, SHA-256 `d4ad81b8a3305c1f28d58195bc13ea44bedd083373a0eabe4944e2ede32edae2`. The raw sample is [raw/osc-unclosed-32768.bin](raw/osc-unclosed-32768.bin). No Source execution was used.

The lazy, unanchored OSC regex scans the remaining suffix again for every unmatched opener while seeking a terminator. The incomplete-null guard runs after replacement, so it cannot prevent that CPU work. Repeated ESC openers with no terminator produce approximately 4× runtime per doubling. Three samples were taken at each size; these are medians in milliseconds:

| OSC openers | UTF-8 bytes | R23 parser ms | R19 parser ms |
| ---: | ---: | ---: | ---: |
| 1024 | 4139 | 2.074 | 0.007 |
| 2048 | 8235 | 8.126 | 0.012 |
| 4096 | 16427 | 31.630 | 0.023 |
| 8192 | 32811 | 127.572 | 0.025 |
| 16384 | 65579 | 485.990 | 0.023 |
| 32768 | 131115 | 1981.480 | 0.027 |

The unchanged Vitest gate invokes the parser twice. The exact own-copy gate function took **4094.146 ms** for this 128 KiB input before returning `gate_inventory_unparsable:unit`. A same-size terminated-OSC control took 0.281 ms; a plain-log control took 0.379 ms. Repeated unterminated C1 OSC also reproduced the slow path. These results support polynomial input amplification rather than general machine slowness. No larger-input runtime was measured or claimed.

The relevant boundary is captured test-output bytes to synchronous CI evidence verification. An emitter or malformed fixture must influence those bytes; remote API exploitation and acceptance bypass were not reproduced. The raw artifact reader (`phase10-verify.mjs:73–82`) and `verifyGateEvidence` (`certification-rules.mjs:1299–1336`) pass the log to the unchanged Vitest branch (`:616–637`), which performs the two whole-log parser calls. Evidence hashes and run bindings do not constrain the control-sequence scan cost.

Recommended correction: a bounded linear OSC state-machine scan with fail-closed behavior for incomplete strings, preserving first-summary/count semantics. No implementation was changed. See [raw/probes.json](raw/probes.json), [raw/confirmation.json](raw/confirmation.json), [raw/extraction.json](raw/extraction.json) and the [parser diff](raw/diff-scripts__lib__certification-rules.mjs.patch).

## Actual delta bytes and metadata

The five advertised paths were byte-compared against R19 and their R23 SHA-256/size matched the supplied binding. No full candidate-tree diff is claimed. Exact inputs:

| Path | R19 SHA-256 | R23 SHA-256 |
| --- | --- | --- |
| `scripts/hiso-baseline-inventory.json` | 666bf95f73ffb3052e671e1af90d3d4694b4db642f59e8cdd3e6570e4802c13e | fe13e77e64d987b840755f8f23ee00b277ef8d5d7288d79835dea99cd5fbee36 |
| `scripts/lib/certification-rules.mjs` | 9ea6fff312b6429aaeba191698cea553f823aa92bedfc3045974d87ed642b7dc | 5d9975fb908ca91813798ba85530d2489dfbbbd2704592b4d3d3cdac96e1289f |
| `scripts/skip-catalog.json` | 3aee15d5e2018554f147099a83fea0afad7d7ecb9c9bba18bf1ee281500acd9e | 7f727bd9407a418bf7fb58679ad59976c26d07cd5c09809d1d493ff7fd42740e |
| `tests/certification-summary-ansi-own.test.js` | absent | 043e37c22c7dd9d9df33a65fb5ef6e8a77135216133ffcbe41b76b12285c1ea8 |
| `tests/hiso-ci-scopes.test.js` | 7b93eaf64a4daca0530da29b618732f8e5e13a2f090591e58c4e1d282b4572a1 | f19ca7a5f28747755540b0dc160f190470666f2030b5eb7453bf52e5420effe1 |

The inventory adds only the new regression path and the inventory assertion changes 46 to 47. The skip catalog changes only four `sourceSha256` values (SKIP-PG-004/008/012/014); every new value matches actual target bytes. Those target files are byte-identical to R19, and skip counts, reasons, owners, gates and expirations are unchanged. See [raw/catalog-rebind.json](raw/catalog-rebind.json). All five changed files plus 12 named immutable references remained stable when re-read; generated certification/cache outputs were excluded. See [raw/input-snapshot-after.json](raw/input-snapshot-after.json).

## Other checks

- The copied regression body passed **23 cases / 30 assertions** using an own small Node assertion adapter; this is not a Vitest/full-suite execution.
- **15 independent control probes** and **6 Vitest gate probes** passed. They covered SGR/C1 decorations, OSC BEL/ST and hyperlink handling, count preservation, incomplete OSC, first-failing summary, skips, exit-code and metric disagreements, and shell metacharacters remaining data.
- The exact-fivepath strict Gitleaks scan with the authorized **8.28.0** binary returned **0 findings / exit 0**. Only default rules were extended; redaction was 100%, ignore file empty, inline allows disabled. [Raw scanner report](raw/gitleaks-fivepath.json) and [stderr](raw/gitleaks-fivepath.stderr) are preserved.
- The new normalizer introduces no executable input, shell, filesystem, path-selection or network sink. Existing unrelated spawn helpers were not executed.

## Authority and coverage limits

First read: `/home/ricardo/.cache/cvg-harness-green-20261004/security-ci-delta-fresh-review-r23/authority.json`, explicit workdir `/home/ricardo/.cache/cvg-harness-green-20261004/security-ci-delta-fresh-review-r23`, authority SHA-256 `e68242cb9851717012535575b5a0c16dbe1e08bdc7af25cde2c892794d007333`. Source: `/home/ricardo/.cache/cvg-harness-green-20261004/candidate-ci-final-r23`; R19: `/home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r19`; delta binding SHA-256: `05bf04fa7a04a96998fb5b22ae0e62ed8308db8499bf16e2595c4a03ced29164`. [report.json](report.json) records all source, reference, extraction and tool hashes. [manifest.json](manifest.json) binds output artifacts.

- Review scope is exactly the five advertised changed paths versus R19, plus narrowly referenced immutable libraries/configs and four catalog binding targets. Actual bytes for these paths were compared. A full filesystem/candidate tree comparison was not performed; the packet advertises five deltas.
- No whole CodeQL rescan, original-finding review, global security judgment, release certification, or production approval. Existing prior reviewer reports were not consulted.
- No source files executed or mutated. Only own output parser/function slices and the copied regression body with an own assertion adapter executed. No provider, PostgreSQL, network, package install, private environment file access, worker, or subprocess calls from probe code.
- Substantive probes ran Node v22.23.2. Default Node v24.20.0 was used only for initial readonly version discovery; no substantive Node24 probe.
- Native certification in Source was allowed to continue. Generated outputs, certification caches, and logs were not frozen, compared, or used as review input.
- Finite probes only: max pathological input 131115 bytes, three timing samples at each of six sizes, one gate confirmation. Timings above these sizes and other Node versions were not measured.
- The semantic adapter runs only the new 23 regression cases; full Vitest, full suite, E2E, certify, SBOM and license commands were not executed.
- Tool binaries were hashed during evidence closure; no claim of scanner binary immutability from an earlier pre-scan hash is made. Scanner config/ignore copies were verified against authority paths.

Raw stdout/stderr, all finite synthetic input samples, initial setup failures and successful retries are retained in [raw/execution-ledger.json](raw/execution-ledger.json) and [raw/setup-attempts.json](raw/setup-attempts.json). Root governance, coordination files and prior reviewer judgments were not read. All writes are inside the authority output directory.
