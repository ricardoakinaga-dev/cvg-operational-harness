import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
const sha=s=>createHash('sha256').update(s).digest('hex');
const slices=[];
for(const variant of ['source','original']){
 const text=fs.readFileSync(`output/${variant}/scripts/lib/certification-rules.mjs`,'utf8');
 const start=text.indexOf('export function parseVitestSummary(');const end=text.indexOf('export function parsePlaywrightSummary(',start);
 const slice=text.slice(start,end);
 fs.writeFileSync(`output/${variant}-parser.mjs`,"import { stripVTControlCharacters } from 'node:util'\n"+slice);
 slices.push({variant,startByte:Buffer.byteLength(text.slice(0,start)),endByte:Buffer.byteLength(text.slice(0,end)),sliceSha256:sha(slice),transform:'verbatim parseVitestSummary slice plus node:util import only; no Source import'});
 if(variant==='source'){
  const begin=text.indexOf('function deriveGateOutcome(');const finish=text.indexOf('export function verifyGateEvidence(',begin);
  // This verbatim function calls only the Vitest branch in the own harness; all other branch dependencies remain unbound.
  const gate=text.slice(begin,finish);
  fs.writeFileSync('output/source-gate.mjs',"import { parseVitestSummary } from './source-parser.mjs'\nexport "+gate);
  slices.push({variant,kind:'deriveGateOutcome',sliceSha256:sha(gate),transform:'verbatim function, add export, import own parser; no other branches exercised'});
 }
}
const body=fs.readFileSync('output/source/tests/certification-summary-ansi-own.test.js','utf8').replace(/^import .*\n/gm,'');
const adapter=`import {strict as assert} from 'node:assert';\nimport {parseVitestSummary} from './source-parser.mjs';\nlet cases=0,assertions=0;\nconst expect=(actual)=>({toEqual(expected){assert.deepEqual(actual,expected);assertions++},toBeNull(){assert.equal(actual,null);assertions++}});\nconst describe=(_name,fn)=>fn();\nconst it=(name,fn)=>{fn();cases++;console.log(JSON.stringify({status:'PASS',name}));};\nit.each=(rows)=>(name,fn)=>{for(const row of rows)it(name,()=>fn(...(Array.isArray(row)?row:[row])))};\n`;
fs.writeFileSync('output/copied-regression-adapter.mjs',adapter+body+"\nconsole.log(JSON.stringify({node:process.version,cases,assertions,status:'PASS',mode:'finite copied regression using own assertion adapter; not Vitest suite'}));\n");
fs.writeFileSync('output/raw/extraction.json',JSON.stringify(slices,null,2)+'\n');
const a=JSON.parse(fs.readFileSync('authority.json'));
const old=JSON.parse(fs.readFileSync('output/original/scripts/skip-catalog.json'));const current=JSON.parse(fs.readFileSync('output/source/scripts/skip-catalog.json'));
const refs=[];
for(let i=0;i<current.entries.length;i++){
 const x=current.entries[i],y=old.entries[i];
 if(x.sourceSha256===y.sourceSha256)continue;
 const withoutHash=({sourceSha256,...rest})=>rest;
 const fieldsOnly=JSON.stringify(withoutHash(x))===JSON.stringify(withoutHash(y));
 const row={id:x.id,path:x.file,oldBinding:y.sourceSha256,newBinding:x.sourceSha256,hashOnlyChange:fieldsOnly};
 for(const [variant,root] of [['source',a.sourceReadonly],['original',a.originalReadonly]]){
  const bytes=fs.readFileSync(path.join(root,x.file));
  const dest=path.join(a.write,variant,x.file);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,bytes);
  row[variant]={sha256:sha(bytes),size:bytes.length};
 }
 row.newBindingMatches=row.newBinding===row.source.sha256;
 row.referencedFileUnchanged=row.source.sha256===row.original.sha256;
 refs.push(row);
}
fs.writeFileSync('output/raw/catalog-rebind.json',JSON.stringify({entryCount:current.entries.length,rebinds:refs,allOtherMetadataEqual:JSON.stringify({...old,entries:current.entries})===JSON.stringify(current)},null,2)+'\n');
console.log(JSON.stringify({extracted:slices,catalogRebinds:refs}));
