import fs from 'node:fs';
import path from 'node:path';
import {packet,read,sha} from './snapshot.mjs';
const out=path.join(packet,'output');
const write=(p,v)=>{const dest=path.join(out,p);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,typeof v==='string'||Buffer.isBuffer(v)?v:JSON.stringify(v,null,2)+'\n');};
const json=p=>JSON.parse(read(p));
const checks=[];
function check(id,pass,evidence){checks.push({id,status:pass?'PASS':'FAIL',evidence});}
function missing(id,evidence){checks.push({id,status:'MISSING_EVIDENCE',evidence});}
function canonical(v){if(Array.isArray(v))return '['+v.map(canonical).join(',')+']';if(v&&typeof v==='object')return '{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+canonical(v[k])).join(',')+'}';return JSON.stringify(v);}
const equal=(a,b)=>canonical(a)===canonical(b);
function diff(a,b,p=''){if(equal(a,b))return [];if(a&&b&&typeof a==='object'&&typeof b==='object'&&!Array.isArray(a)&&!Array.isArray(b))return [...new Set([...Object.keys(a),...Object.keys(b)])].flatMap(k=>diff(a[k],b[k],p+'/'+k.replaceAll('~','~0').replaceAll('/','~1')));return [{path:p,before:a,after:b}];}
const current=json('source/tests/fixtures/hiso-r6-projection.json'),before=json('projection-fixture-before-c1.json');
const manifest=json('source/package.json'),lock=json('source/package-lock.json'),oldManifest=json('reference-before/package.json'),oldLock=json('reference-before/package-lock.json');
const manifestDiff=diff(oldManifest,manifest),lockDiff=diff(oldLock,lock);
write('raw/package-lock-diff.json',{manifest:manifestDiff,lock:lockDiff});
check('root-declaration-only',manifestDiff.length===1&&manifestDiff[0].path==='/devDependencies/semver'&&manifestDiff[0].before===undefined&&manifestDiff[0].after==='7.7.4'&&lockDiff.length===1&&lockDiff[0].path==='/packages//devDependencies/semver'&&lockDiff[0].before===undefined&&lockDiff[0].after==='7.7.4',{manifestDiff,lockDiff});
const thirdParty=Object.keys(oldLock.packages).filter(p=>p.startsWith('node_modules/')&&!oldLock.packages[p].link);
check('third-party-lock-inventory-version-integrity-unchanged',equal(Object.keys(oldLock.packages),Object.keys(lock.packages))&&thirdParty.every(p=>equal(oldLock.packages[p],lock.packages[p])),{records:thirdParty.length,semver:lock.packages['node_modules/semver'],installationExecuted:false});
check('workspaces-unchanged',equal(oldManifest.workspaces,manifest.workspaces)&&equal(oldLock.packages[''].workspaces,lock.packages[''].workspaces),{workspaces:manifest.workspaces});
const expectedPaths=['package.json','package-lock.json','tsconfig.json','tsconfig.typecheck.json','vitest.config.mts','config/workspace-dependency-policy.json','docs/doc-link-policy.json'];
check('exact-seven-config-paths',equal(current.configPaths,expectedPaths)&&equal(before.configPaths,expectedPaths)&&['retained','neutral'].every(mode=>equal(Object.keys(current[mode]).sort(),[...expectedPaths].sort())),{paths:current.configPaths});
const fixtureDiff=diff(before,current);write('raw/fixture-diff.json',fixtureDiff.map(d=>({path:d.path,beforeSha256:sha(String(d.before)),afterSha256:sha(String(d.after)),beforeBytes:Buffer.byteLength(String(d.before)),afterBytes:Buffer.byteLength(String(d.after))})));
const expectedDiff=['retained','neutral'].flatMap(mode=>['package.json','package-lock.json'].flatMap(p=>['content','sha256'].map(field=>'/'+mode+'/'+p+'/'+field))).sort();
check('fixture-only-eight-authorized-fields',equal(fixtureDiff.map(d=>d.path).sort(),expectedDiff),{paths:fixtureDiff.map(d=>d.path)});
check('five-other-configs-and-fixed-bindings-unchanged',['retained','neutral'].every(mode=>expectedPaths.slice(2).every(p=>equal(before[mode][p],current[mode][p])))&&equal(before.rulesHash,current.rulesHash)&&equal(before.nativeEvalArtifact,current.nativeEvalArtifact)&&equal(before.configPaths,current.configPaths),{rulesHash:current.rulesHash,nativeEvalArtifactSha256:current.nativeEvalArtifact.sha256});
const identities=[];
for(const mode of ['retained','neutral'])for(const p of expectedPaths){const actual=read((mode==='retained'?'source/':'generated-neutral/')+p),record=current[mode][p];const result={mode,path:p,bytes:actual.length,actualSha256:sha(actual),fixtureSha256:record.sha256,literalEqual:actual.equals(Buffer.from(record.content)),hashValid:sha(record.content)===record.sha256};identities.push(result);check('literal-'+mode+'-'+p,result.literalEqual&&result.hashValid,result);}
write('raw/config-identities.json',identities);
for(const mode of ['retained','neutral'])for(const p of ['package.json','package-lock.json']){const changes=diff(JSON.parse(before[mode][p].content),JSON.parse(current[mode][p].content));const expected=p==='package.json'?'/devDependencies/semver':'/packages//devDependencies/semver';check('record-semantic-delta-'+mode+'-'+p,changes.length===1&&changes[0].path===expected&&changes[0].before===undefined&&changes[0].after==='7.7.4',changes);}
for(const p of ['tests/hiso-ci-scopes.test.js','tests/hiso-snapshot-membership-own.test.js']){const a=read('source/'+p),b=read('reference-before/'+p);check('assertions-and-helper-source-unchanged-'+p,a.equals(b),{sourceSha256:sha(a),referenceSha256:sha(b),bytes:a.length,comparison:'entire literal file; includes every assertion and embedded helper source; never imported or executed'});}
const baseline=json('source/scripts/hiso-baseline-inventory.json'),contract=json('source/scripts/hiso-ci-scopes.json');
const lexical='tests/product-boundary-lexical-static.test.js';
const coverage=[...baseline.coveragePaths,...baseline.newCoveragePaths];
check('current-inventory-cardinality-and-lexical-entry',baseline.tests.length===371&&new Set(baseline.tests.map(x=>x.path)).size===371&&baseline.newTests.length===44&&new Set(baseline.newTests).size===44&&equal(baseline.newTests,[...baseline.newTests].sort())&&baseline.newTests.filter(p=>p===lexical).length===1&&coverage.length===281&&new Set(coverage).size===281,{originalTests:baseline.tests.length,newTests:baseline.newTests.length,coveragePaths:baseline.coveragePaths.length,newCoveragePaths:baseline.newCoveragePaths.length,totalCoverage:coverage.length,lexicalEntry:lexical});
const reconstructed=structuredClone(baseline);reconstructed.newTests=reconstructed.newTests.filter(p=>p!==lexical);
write('raw/baseline-limits.json',{currentSha256:sha(read('source/scripts/hiso-baseline-inventory.json')),contractDeclaredSha256:contract.baselineInventory.sha256,reconstructedHypothesisSha256:sha(JSON.stringify(reconstructed,null,2)+'\n'),hypotheticalBeforeNewTests:reconstructed.newTests.length,referenceBeforeInventoryProvided:false,meaning:'A reconstruction is not a before authority; neither equality nor exclusivity of the historical 43-to-44 delta is established.'});
missing('before-baseline-original371-coverage281-and-exclusive43-to44-delta',{required:'literal reference-before/scripts/hiso-baseline-inventory.json or independently bound prior baseline',provided:false,currentCountsVerified:true,currentVersusContractHashMatches:sha(read('source/scripts/hiso-baseline-inventory.json'))===contract.baselineInventory.sha256,scope:'inventory preservation prerequisite only; no general source/gate verdict'});
// Exact physical producer copy, with a finite import closure. Only its rules,
// rulesHash and projectLock exports are accessed; no original fixture is imported.
const producerInputs=['hiso-variant.mjs','hiso-contract.mjs','ci-bar-contract.mjs','hiso-ci-scopes.json'];
const copyManifest=[];
for(const p of producerInputs){const bytes=read('source/scripts/'+p);write('trusted-producer/scripts/'+p,bytes);copyManifest.push({source:'source/scripts/'+p,copy:'trusted-producer/scripts/'+p,sha256:sha(bytes),bytes:bytes.length});}
write('raw/producer-copy-manifest.json',copyManifest);
const importClosure=[];
for(const p of producerInputs.filter(p=>p.endsWith('.mjs'))){const text=read('source/scripts/'+p).toString();const imports=[...text.matchAll(/^import\s+[\s\S]*?\bfrom\s+['"]([^'"]+)['"]/gm)].map(m=>m[1]);importClosure.push({path:p,imports});check('finite-builtin-import-closure-'+p,imports.every(s=>s.startsWith('node:')||producerInputs.includes(s.replace(/^\.\//,''))),{imports});}
write('raw/import-closure.json',importClosure);
const {rules,rulesHash,projectLock}=await import('./trusted-producer/scripts/hiso-variant.mjs');
check('independent-rules-digest',sha(canonical(rules))===rulesHash&&rulesHash===current.rulesHash,{independentSha256:sha(canonical(rules)),producerRulesHash:rulesHash,fixtureRulesHash:current.rulesHash});
const serialize=v=>JSON.stringify(v,null,2)+'\n';
const projectedManifest=structuredClone(manifest);projectedManifest.workspaces=projectedManifest.workspaces.filter(p=>p!==rules.workspace);for(const key of rules.scripts)delete projectedManifest.scripts[key];
const projectedLock=projectLock(lock,projectedManifest);
const independent={'package.json':serialize(projectedManifest),'package-lock.json':serialize(projectedLock)};
const policy=json('source/'+rules.workspacePolicy);policy.workspacePatterns=policy.workspacePatterns.filter(p=>p!==rules.workspace);independent[rules.workspacePolicy]=serialize(policy);
const doc=json('source/'+rules.docPolicyProjection.path);doc.movedTargets=doc.movedTargets.filter(m=>!rules.docPolicyProjection.mappings.some(r=>r.old===m.old&&r.new===m.new));independent[rules.docPolicyProjection.path]=serialize(doc);
const ts=json('source/tsconfig.json');ts.references=ts.references.filter(x=>x.path!=='products/shift-assistant');independent['tsconfig.json']=serialize(ts);
const typecheck=json('source/tsconfig.typecheck.json');typecheck.include=typecheck.include.filter(x=>!rules.typecheck.includes(x));independent['tsconfig.typecheck.json']=serialize(typecheck);
// Independently select literal lines. Do not execute the configuration payload.
let vitest=read('source/vitest.config.mts').toString();
for(const value of rules.vitest){const rows=vitest.split('\n');const matches=rows.filter(row=>row.trim()==="'"+value+"',"||row.trim()==="'"+value+"'");check('literal-vitest-projection-selection-'+value,matches.length===1,{literalRows:matches});vitest=rows.filter(row=>!matches.includes(row)).join('\n');}
vitest=vitest.replace('    include: [','    exclude: '+JSON.stringify([...rules.vitestDefaultExcludes,...rules.transitionOnly.map(x=>x.path)])+',\n    include: [');independent['vitest.config.mts']=vitest;
for(const p of expectedPaths){write('independent-neutral/'+p,independent[p]);const generated=read('generated-neutral/'+p);const physical=fs.readFileSync(path.join(out,'independent-neutral',p));check('independently-reproduced-neutral-'+p,physical.equals(generated)&&physical.equals(Buffer.from(current.neutral[p].content)),{reproducedSha256:sha(physical),generatedSha256:sha(generated),fixtureSha256:current.neutral[p].sha256,bytes:physical.length});}
check('projectLock-pure-input-preservation',equal(lock,json('source/package-lock.json'))&&equal(manifest,json('source/package.json')),{pureInputsUnmodified:true,prepareVariantCalled:false});
// Inert JSON mutation probes evaluate an independent SHA identity predicate
// corresponding to the statically inspected seven_config_binding guard.
const measurement=read('source/tests/fixtures/hiso-r6-measurement.mjs').toString();
const strictBody=`const matches = ['retained', 'neutral'].filter((mode) =>\n    frozen.configPaths.every(\n      (p) =>\n        fs.existsSync(path.join(root, p)) &&\n        sha(fs.readFileSync(path.join(root, p))) === frozen[mode][p].sha256\n    )\n  )\n  check(matches.length === 1, 'seven_config_binding')`;
check('measurement-static-strict-seven-identities',measurement.includes(strictBody)&&measurement.includes("check(rulesHash === frozen.rulesHash, 'rules_binding')"),{sourceSha256:sha(measurement),expectedGuardSha256:sha(strictBody),execution:'none; exact text inspection only'});
write('raw/measurement-guard.txt',strictBody+'\n');
const probes=[];
const bindings=(configs,frozen=current)=>['retained','neutral'].filter(mode=>frozen.configPaths.every(p=>typeof configs[p]==='string'&&sha(configs[p])===frozen[mode][p].sha256));
for(const mode of ['retained','neutral']){
 const base=Object.fromEntries(expectedPaths.map(p=>[p,current[mode][p].content]));
 check('inert-identity-positive-control-'+mode,equal(bindings(base),[mode]),{matchedModes:bindings(base)});
 const specs=[
 {id:'changed-semver-version',file:'package.json',pointer:['devDependencies','semver'],value:'7.7.5'},
 {id:'root-dev-dictionary',file:'package.json',pointer:['devDependencies','inert-review-probe'],value:'0.0.0'},
 {id:'third-party-lock-version',file:'package-lock.json',pointer:['packages','node_modules/semver','version'],value:'0.0.0'},
 {id:'third-party-lock-integrity',file:'package-lock.json',pointer:['packages','node_modules/semver','integrity'],value:'sha512-inert'},
 {id:'lock-root-dev-dictionary',file:'package-lock.json',pointer:['packages','','devDependencies','inert-review-probe'],value:'0.0.0'},
 {id:'workspaces',file:'package.json',pointer:['workspaces'],value:['inert-review/*']},
 {id:'unknown-config-bytes',file:'tsconfig.json',pointer:['inertReview'],value:true},
 {id:'missing-required-config',file:'tsconfig.json',missing:true},
 {id:'legacy-fixture-hash-mismatch',legacy:true}
 ];
 for(const spec of specs){const configs=structuredClone(base);if(spec.missing)delete configs[spec.file];else if(!spec.legacy){const obj=JSON.parse(configs[spec.file]);let parent=obj;for(const key of spec.pointer.slice(0,-1))parent=parent[key];parent[spec.pointer.at(-1)]=spec.value;configs[spec.file]=serialize(obj);}
 const matches=bindings(configs,spec.legacy?before:current);const result={mode,...spec,expected:'REJECT',observed:matches.length===1?'ACCEPT':'REJECT',matchedModes:matches,baseFixtureSha256:sha(read('source/tests/fixtures/hiso-r6-projection.json')),evaluation:'independent inert byte/hash predicate; original measurement module and tests never executed'};probes.push(result);check('inert-probe-'+mode+'-'+spec.id,result.observed==='REJECT',result);
 }
}
write('probes/inert-json-probes.json',probes);
write('raw-checks.json',{node:process.version,checks});
const failed=checks.filter(x=>x.status==='FAIL'),missingChecks=checks.filter(x=>x.status==='MISSING_EVIDENCE');
const verdict=failed.length?'REJECT':missingChecks.length?'INVALID':'ACCEPT';
write('review.json',{task:json('authority.json').task,verdict,scope:'configuration-fixture identity only; never installed/global/gate/release acceptance',fixtureIdentityChecks:failed.length?'FAIL':'PASS',checks:{passed:checks.filter(x=>x.status==='PASS').length,failed:failed.length,missingEvidence:missingChecks.length},missing:missingChecks,failed,actions:{runtime:process.version,producerExecuted:['rules initialization','rulesHash initialization','projectLock(currentLock, independentlyProjectedManifest)'],originalTestExecutions:0,originalFixtureExecutions:0,prepareVariantExecutions:0,installs:0,networkDnsPgProviderActions:0,rootWrites:0,otherPacketReads:0,historyPriorReviewReads:0,privateEnvReads:0,subagents:0,pushDeploy:0,writes:'packet/output only'},limits:['Reference-before baseline inventory absent: historical 371 records, all 281 coverage paths and exclusive 43-to-44 lexical addition cannot be compared to a frozen prior inventory.','Current count/list validity verified; hypothetical reconstructed old inventory is not treated as authority.','Only independent inert identity probes executed; exact source guard inspected statically. No original tests, native evaluator, parser resolution, actual variant preparation or full Source validation.','Trusted Node22 executable discovered using literal runtime metadata outside packet; no private environment content read. Initial PATH node --version observed Node24 only; all review code and permitted producer execution used explicit Node22 path.','Input files are mode 664/directories 775, not permission-locked read-only; they are treated as read-only and metadata/content preservation checked.','No installation state, installed dependency tree, PGV8 run, gate/global/release decision was evaluated.']});
console.log(JSON.stringify({verdict,passed:checks.filter(x=>x.status==='PASS').length,failed,missing:missingChecks.map(x=>x.id)}));
