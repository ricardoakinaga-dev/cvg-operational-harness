import fs from 'node:fs'
import path from 'node:path'
import { createHash } from 'node:crypto'
import { fileURLToPath } from 'node:url'
import { createRequire } from 'node:module'
import { CI_BAR_GATES, CI_BAR_VERSION } from './ci-bar-contract.mjs'

export const VERSION = 'hiso-ci-scopes-v1'
export const sha = (bytes) => createHash('sha256').update(bytes).digest('hex')
export function canonical(value) {
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`
  if (value && typeof value === 'object')
    return `{${Object.keys(value)
      .sort()
      .filter((k) => value[k] !== undefined)
      .map((k) => `${JSON.stringify(k)}:${canonical(value[k])}`)
      .join(',')}}`
  return JSON.stringify(value)
}
export const digest = (value) => sha(canonical(value))
export const contract = JSON.parse(
  fs.readFileSync(new URL('./hiso-ci-scopes.json', import.meta.url), 'utf8')
)
export const contractHash = digest(contract)
export function requireThat(condition, reason) {
  if (!condition) throw new Error(`hiso:${reason}`)
}
export function dispatch(version) {
  if (version === VERSION) {
    requireThat(contract.schemaVersion === 1, 'schema_version:contract')
    return contract
  }
  if (version === CI_BAR_VERSION)
    return { contract: CI_BAR_VERSION, gates: CI_BAR_GATES }
  throw new Error(`hiso:unknown_contract:${version}`)
}
export function scopeContract(scope) {
  const entry = contract.scopes.find((x) => x.id === scope)
  requireThat(entry, `unknown_scope:${scope}`)
  return entry
}
export function exact(actual, expected, reason) {
  requireThat(
    Array.isArray(actual) &&
      actual.length === expected.length &&
      new Set(actual).size === expected.length &&
      [...actual].sort().join('\0') === [...expected].sort().join('\0'),
    reason
  )
}
export function safePath(p) {
  requireThat(
    typeof p === 'string' &&
      p.length > 0 &&
      !p.includes('\\') &&
      !path.posix.isAbsolute(p) &&
      p.split('/').every((s) => s && s !== '.' && s !== '..'),
    `unsafe_path:${p}`
  )
  return p
}
export function files(root, prefix = '') {
  requireThat(!fs.lstatSync(root).isSymbolicLink(), `symlink:${root}`)
  return fs
    .readdirSync(path.join(root, prefix), { withFileTypes: true })
    .sort((a, b) => a.name.localeCompare(b.name))
    .flatMap((e) => {
      const p = prefix ? `${prefix}/${e.name}` : e.name
      requireThat(!e.isSymbolicLink(), `symlink:${p}`)
      if (e.isDirectory()) return files(root, p)
      requireThat(e.isFile(), `not_file:${p}`)
      const bytes = fs.readFileSync(path.join(root, p))
      return [{ path: p, sha256: sha(bytes), size: bytes.length }]
    })
    .sort((a, b) => a.path.localeCompare(b.path))
}
// Omit only owned generated outputs. Nested directories with generated-looking
// names are ordinary inputs unless the compiler maps their exact output path.
const rootGenerated = new Set([
  'node_modules',
  '.git',
  'coverage',
  'test-results',
  'playwright-report',
  'blob-report'
])
const fixedRootReports = new Set([
  'image-smoke.json',
  'image.json',
  'inventory.json',
  'playwright-results.xml',
  'postgres-version.json',
  'public-smoke.json'
])
const artifactLeaves = new Set(
  contract.scopes
    .flatMap((s) => s.gates.flatMap((g) => g.artifacts ?? []))
    .filter(
      (p) =>
        /^certification\/[a-z0-9-]+(?:\.[a-z0-9-]+)*\.json$/.test(p) ||
        fixedRootReports.has(p)
    )
)
// Read the real public producer's declarative configuration without running it.
// Only literals, root/workspace identifiers and path.join are admitted; drift to
// an executable expression fails closed instead of widening output exclusions.
function publicConfigurations(root, ts) {
  const producer = path.join(root, 'scripts/build-public-workspace.mjs')
  if (!fs.existsSync(producer)) return []
  const ast = ts.createSourceFile(
    producer,
    fs.readFileSync(producer, 'utf8'),
    ts.ScriptTarget.Latest,
    true
  )
  const declarations = []
  const visit = (node) => {
    if (
      ts.isVariableDeclaration(node) &&
      node.name.getText(ast) === 'configuration'
    )
      declarations.push(node.initializer)
    ts.forEachChild(node, visit)
  }
  visit(ast)
  requireThat(
    declarations.length === 1 && ts.isObjectLiteralExpression(declarations[0]),
    'source_public_config'
  )
  const manifest = JSON.parse(
    fs.readFileSync(path.join(root, 'package.json'), 'utf8')
  )
  const workspaces = new Map()
  for (const pattern of manifest.workspaces) {
    requireThat(pattern.endsWith('/*'), 'source_public_workspace_pattern')
    const parent = safePath(pattern.slice(0, -2))
    if (!fs.existsSync(path.join(root, parent))) continue
    for (const entry of fs.readdirSync(path.join(root, parent), {
      withFileTypes: true
    })) {
      if (!entry.isDirectory()) continue
      const workspace = `${parent}/${entry.name}`
      const pkgPath = path.join(root, workspace, 'package.json')
      if (!fs.existsSync(pkgPath)) continue
      const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'))
      workspaces.set(pkg.name, { workspace, pkg })
    }
  }
  const targets = new Set()
  const wrapper = path.join(root, 'scripts/hiso-public-build.mjs')
  if (fs.existsSync(wrapper)) {
    const source = ts.createSourceFile(
      wrapper,
      fs.readFileSync(wrapper, 'utf8'),
      ts.ScriptTarget.Latest,
      true
    )
    const find = (node) => {
      if (
        ts.isForOfStatement(node) &&
        ts.isArrayLiteralExpression(node.expression)
      )
        for (const item of node.expression.elements) {
          requireThat(ts.isStringLiteral(item), 'source_public_targets')
          targets.add(safePath(item.text))
        }
      ts.forEachChild(node, find)
    }
    find(source)
  }
  for (const gate of contract.scopes.flatMap((scope) => scope.gates)) {
    const [program, args] = gate.command ?? []
    if (
      program === 'node' &&
      args?.[0] === 'scripts/build-public-workspace.mjs'
    ) {
      requireThat(args.length === 2, 'source_public_gate_command')
      targets.add(safePath(args[1]))
    }
  }
  requireThat(targets.size > 0, 'source_public_targets')
  const selected = new Map(),
    visiting = new Set()
  const select = (item) => {
    requireThat(item && !visiting.has(item.pkg.name), 'source_public_closure')
    if (selected.has(item.pkg.name)) return
    visiting.add(item.pkg.name)
    for (const name of Object.keys(item.pkg.dependencies ?? {}))
      if (workspaces.has(name)) select(workspaces.get(name))
    visiting.delete(item.pkg.name)
    selected.set(item.pkg.name, item)
  }
  for (const target of targets)
    select([...workspaces.values()].find((item) => item.workspace === target))
  return [...selected.values()].map(({ workspace }) => {
    const value = (node) => {
      if (ts.isStringLiteral(node)) return node.text
      if (node.kind === ts.SyntaxKind.TrueKeyword) return true
      if (node.kind === ts.SyntaxKind.FalseKeyword) return false
      if (ts.isNumericLiteral(node)) return Number(node.text)
      if (ts.isIdentifier(node) && ['root', 'workspace'].includes(node.text))
        return node.text === 'root' ? root : workspace
      if (ts.isArrayLiteralExpression(node)) return node.elements.map(value)
      if (ts.isObjectLiteralExpression(node))
        return Object.fromEntries(
          node.properties.map((property) => {
            requireThat(
              ts.isPropertyAssignment(property),
              'source_public_property'
            )
            const key = property.name.getText(ast).replace(/^['"]|['"]$/g, '')
            return [key, value(property.initializer)]
          })
        )
      if (
        ts.isCallExpression(node) &&
        node.expression.getText(ast) === 'path.join'
      )
        return path.join(...node.arguments.map(value))
      requireThat(false, 'source_public_expression')
    }
    const raw = Object.fromEntries(
      declarations[0].properties
        .filter((p) => p.name?.getText(ast) !== 'references')
        .map((property) => {
          requireThat(
            ts.isPropertyAssignment(property),
            'source_public_property'
          )
          return [property.name.getText(ast), value(property.initializer)]
        })
    )
    const config = ts.parseJsonConfigFileContent(
      raw,
      ts.sys,
      root,
      {},
      path.join(root, workspace, 'tsconfig.public.json')
    )
    requireThat(!config.errors.length, 'source_public_config')
    return config
  })
}
function emittedOutputs(root) {
  const output = new Set()
  const ts = createRequire(import.meta.url)('typescript')
  const configs = publicConfigurations(root, ts)
  const runtime = path.join(root, 'tsconfig.runtime.json')
  if (fs.existsSync(runtime)) {
    const runtimeConfig = ts.readConfigFile(runtime, ts.sys.readFile)
    requireThat(!runtimeConfig.error, 'source_runtime_config')
    for (const reference of runtimeConfig.config.references ?? []) {
      const relative = safePath(reference.path.replace(/^\.\//, ''))
      const target = path.join(root, relative)
      const filename = target.endsWith('.json')
        ? target
        : path.join(target, 'tsconfig.json')
      const config = ts.getParsedCommandLineOfConfigFile(
        filename,
        {},
        {
          ...ts.sys,
          onUnRecoverableConfigFileDiagnostic: () =>
            requireThat(false, 'source_emit_config')
        }
      )
      requireThat(config && !config.errors.length, 'source_emit_config')
      configs.push(config)
    }
  }
  const add = (generated) => {
    const rel = path.relative(root, generated).split(path.sep).join('/')
    safePath(rel)
    output.add(rel)
  }
  for (const config of configs) {
    if (config.options.noEmit) continue
    for (const source of config.fileNames)
      for (const generated of ts.getOutputFileNames(config, source, false)) {
        add(generated)
      }
    const info = ts.getTsBuildInfoEmitOutputFilePath(config.options)
    if (info) add(info)
  }
  return output
}
export function sourceFiles(root, prefix = '') {
  const generated = emittedOutputs(root)
  const walk = (prefix) =>
    fs
      .readdirSync(path.join(root, prefix), { withFileTypes: true })
      .sort((a, b) => a.name.localeCompare(b.name))
      .flatMap((e) => {
        const p = prefix ? `${prefix}/${e.name}` : e.name
        if (
          (!prefix && rootGenerated.has(e.name)) ||
          (e.isFile() && (artifactLeaves.has(p) || generated.has(p)))
        )
          return []
        requireThat(!e.isSymbolicLink(), `source_symlink:${p}`)
        if (e.isDirectory()) return walk(p)
        requireThat(e.isFile(), `source_not_file:${p}`)
        requireThat(e.name !== '.env', `private_env_present:${p}`)
        const b = fs.readFileSync(path.join(root, p))
        return [{ path: p, sha256: sha(b), size: b.length }]
      })
  return walk(prefix).sort((a, b) => a.path.localeCompare(b.path))
}
export function validateContract(
  root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
) {
  requireThat(contract.schemaVersion === 1, 'schema_version:contract')
  dispatch(contract.contract)
  exact(
    contract.scopes.map((x) => x.id),
    [
      'harness-neutral',
      'consumer-contract',
      'shift-product',
      'transition-regression'
    ],
    'scope_contract_inventory'
  )
  requireThat(contract.legacy.contract === CI_BAR_VERSION, 'legacy_version')
  requireThat(
    canonical(
      contract.legacy.gates.map((g) => {
        const old = { ...g }
        delete old.owner
        delete old.required
        if (old.skipPolicy !== 'none') delete old.skipPolicy
        return old
      })
    ) === canonical(CI_BAR_GATES),
    'legacy_inventory_drift'
  )
  for (const [p, h] of Object.entries(contract.legacy.sourceHashes))
    requireThat(
      sha(fs.readFileSync(path.join(root, safePath(p)))) === h,
      `legacy_source_drift:${p}`
    )
  requireThat(
    sha(
      fs.readFileSync(
        path.join(root, 'docs/02_spec/0180_shared_transport_ci_security.md')
      )
    ) === contract.approvedSpecSha256,
    'spec_digest'
  )
  for (const s of contract.scopes)
    exact(
      s.gates.map((g) => g.id),
      [...new Set(s.gates.map((g) => g.id))],
      `duplicate_contract_gate:${s.id}`
    )
  const baselineBytes = fs.readFileSync(
    path.join(root, contract.baselineInventory.path)
  )
  requireThat(
    sha(baselineBytes) === contract.baselineInventory.sha256,
    'baseline_inventory_input_hash'
  )
  const baseline = JSON.parse(baselineBytes)
  requireThat(baseline.schemaVersion === 1, 'schema_version:baseline')
  for (const f of baseline.tests)
    requireThat(
      sha(fs.readFileSync(path.join(root, safePath(f.path)))) === f.sha256,
      `baseline_test_changed_or_removed:${f.path}`
    )
  const observed = sourceFiles(root)
    .filter(
      (f) =>
        /^(tests|packages|legacy|apps|products)\//.test(f.path) &&
        /\.(test|spec)\.(js|ts|tsx)$/.test(f.path)
    )
    .map((f) => f.path)
  exact(
    observed,
    [...baseline.tests.map((f) => f.path), ...baseline.newTests],
    'approved_test_source_inventory'
  )
  for (const p of [...baseline.coveragePaths, ...baseline.newCoveragePaths])
    requireThat(
      fs.existsSync(path.join(root, safePath(p))),
      `baseline_coverage_source_removed:${p}`
    )
  return {
    contractHash,
    scopes: contract.scopes.map((s) => ({
      id: s.id,
      gateCount: s.gates.length
    })),
    legacySealedGateCount: CI_BAR_GATES.filter((g) => g.id !== 'artifacts')
      .length
  }
}
