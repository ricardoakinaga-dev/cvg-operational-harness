import fs from 'node:fs'
import path from 'node:path'
import {
  canonical,
  digest,
  requireThat,
  safePath,
  scopeContract,
  sha,
  sourceFiles
} from './hiso-contract.mjs'

export const rules = {
  version: 'without-shift-v1',
  removeTrees: ['products/shift-assistant'],
  workspace: 'products/*',
  workspacePolicy: 'config/workspace-dependency-policy.json',
  docPolicyProjection: {
    path: 'docs/doc-link-policy.json',
    version: 'exact-removed-consumer-moves-v1',
    mappings: [
      {
        old: 'apps/worker/src/shift-assistant/__tests__/shift-assistant-e2e.test.ts',
        new: 'products/shift-assistant/src/__tests__/shift-assistant-e2e.test.ts'
      },
      {
        old: 'apps/worker/src/shift-assistant/__tests__/shift-assistant.test.ts',
        new: 'products/shift-assistant/src/__tests__/shift-assistant.test.ts'
      },
      {
        old: 'apps/worker/src/shift-assistant/assistant.ts',
        new: 'products/shift-assistant/src/assistant.ts'
      },
      {
        old: 'apps/worker/src/shift-assistant/commands.ts',
        new: 'products/shift-assistant/src/commands.ts'
      },
      {
        old: 'apps/worker/src/shift-assistant/compose.ts',
        new: 'products/shift-assistant/src/compose.ts'
      },
      {
        old: 'apps/worker/src/shift-assistant/config.ts',
        new: 'products/shift-assistant/src/config.ts'
      },
      {
        old: 'apps/worker/src/shift-assistant/domain.ts',
        new: 'products/shift-assistant/src/domain.ts'
      },
      {
        old: 'apps/worker/src/shift-assistant/egress.ts',
        new: 'products/shift-assistant/src/egress.ts'
      },
      {
        old: 'apps/worker/src/shift-assistant/main.ts',
        new: 'products/shift-assistant/src/main.ts'
      },
      {
        old: 'apps/worker/src/shift-assistant/organizer.ts',
        new: 'products/shift-assistant/src/organizer.ts'
      },
      {
        old: 'apps/worker/src/shift-assistant/sandbox/chat.ts',
        new: 'products/shift-assistant/src/sandbox/chat.ts'
      },
      {
        old: 'apps/worker/src/shift-assistant/sandbox/demo.ts',
        new: 'products/shift-assistant/src/sandbox/demo.ts'
      },
      {
        old: 'apps/worker/src/shift-assistant/sandbox/services.ts',
        new: 'products/shift-assistant/src/sandbox/services.ts'
      },
      {
        old: 'apps/worker/src/shift-assistant/server.ts',
        new: 'products/shift-assistant/src/server.ts'
      },
      {
        old: 'apps/worker/src/shift-assistant/store.ts',
        new: 'products/shift-assistant/src/store.ts'
      },
      {
        old: 'apps/worker/src/shift-assistant/transcriber.ts',
        new: 'products/shift-assistant/src/transcriber.ts'
      },
      {
        old: 'apps/worker/src/shift-assistant/whatsapp.ts',
        new: 'products/shift-assistant/src/whatsapp.ts'
      },
      {
        old: 'deploy/shift-assistant/.env.example',
        new: 'products/shift-assistant/deploy/.env.example'
      },
      {
        old: 'deploy/shift-assistant/Dockerfile',
        new: 'products/shift-assistant/deploy/Dockerfile'
      },
      {
        old: 'deploy/shift-assistant/compose.yaml',
        new: 'products/shift-assistant/deploy/compose.yaml'
      }
    ]
  },
  scripts: [
    'test:shift-assistant',
    'build:shift-assistant',
    'demo:shift-assistant',
    'chat:shift-assistant'
  ],
  typecheck: ['products/**/*.ts', 'products/**/*.tsx'],
  vitest: [
    'products/**/*.test.ts',
    'products/**/*.test.tsx',
    'products/**/*.ts',
    'products/**/*.tsx'
  ],
  vitestDefaultExcludes: ['**/node_modules/**', '**/.git/**'],
  transitionOnly: [
    {
      path: 'tests/workspace-scripts.test.js',
      reason:
        'Exact combined workspace metadata assertions; both original tests run unchanged in transition-regression.'
    },
    {
      path: 'tests/doc-source-moves.test.js',
      reason:
        'Source/document move topology includes the physical product; runs unchanged in transition-regression.'
    }
  ]
}
export const rulesHash = digest(rules)
const json = (r, p) => JSON.parse(fs.readFileSync(path.join(r, p), 'utf8'))
const write = (r, p, v) =>
  fs.writeFileSync(path.join(r, p), JSON.stringify(v, null, 2) + '\n')

// Lock v3 projection follows npm's node_modules ancestor resolution, retaining
// the full approved third-party inventory (including optional platform packages).
// Only the removed workspace and links to it disappear; no re-resolution occurs.
export function projectLock(lock, manifest, removed = rules.removeTrees) {
  requireThat(
    lock.lockfileVersion === 3 && lock.packages?.[''],
    'lock_v3_required'
  )
  const projected = structuredClone(lock)
  const remove = new Set(removed)
  const removedNames = new Set(
    Object.entries(lock.packages)
      .filter(([, e]) => e.link && remove.has(e.resolved))
      .map(([p]) => p.split('node_modules/').at(-1))
  )
  for (const [p, entry] of Object.entries(projected.packages)) {
    if (remove.has(p) || (entry.link && remove.has(entry.resolved)))
      delete projected.packages[p]
    else
      requireThat(
        !entry.link || !entry.resolved?.startsWith('products/'),
        `unmapped_product_link:${p}`
      )
  }
  projected.packages[''].workspaces = manifest.workspaces
  for (const [p, entry] of Object.entries(projected.packages)) {
    if (p && !entry.link && p.startsWith('node_modules/'))
      requireThat(
        canonical(entry) === canonical(lock.packages[p]),
        `third_party_drift:${p}`
      )
    for (const name of Object.keys({
      ...entry.dependencies,
      ...entry.devDependencies,
      ...entry.optionalDependencies,
      ...entry.peerDependencies
    })) {
      requireThat(
        !removedNames.has(name),
        `retained_dependency_on_product:${p}:${name}`
      )
      // npm optional peers may be legitimately absent in the approved lock.
      let parent = p
      let resolved
      for (;;) {
        const candidate = `${parent ? parent + '/' : ''}node_modules/${name}`
        if (
          path.posix.basename(parent) !== 'node_modules' &&
          projected.packages[candidate]
        ) {
          resolved = candidate
          break
        }
        if (!parent) break
        parent = path.posix.dirname(parent)
        if (parent === '.') parent = ''
      }
      if (!resolved) {
        requireThat(
          entry.optionalDependencies?.[name] ||
            entry.peerDependenciesMeta?.[name]?.optional,
          `unresolved_dependency:${p}:${name}`
        )
        continue
      }
      const dep = projected.packages[resolved]
      if (dep.link)
        requireThat(
          projected.packages[dep.resolved],
          `dangling_link:${resolved}`
        )
    }
  }
  return projected
}

export function prepareVariant(source, target, scope) {
  scopeContract(scope)
  requireThat(
    path.resolve(source) !== path.resolve(target) &&
      !path.resolve(target).startsWith(path.resolve(source) + path.sep),
    'variant_inside_source'
  )
  requireThat(!fs.existsSync(target), 'variant_must_be_fresh')
  const before = sourceFiles(source)
  fs.mkdirSync(target, { recursive: true })
  const neutral = ['harness-neutral', 'consumer-contract'].includes(scope)
  const retained = []
  const removed = []
  for (const f of before) {
    safePath(f.path)
    if (
      neutral &&
      rules.removeTrees.some((p) => f.path === p || f.path.startsWith(p + '/'))
    ) {
      removed.push(f)
      continue
    }
    const dest = path.join(target, f.path)
    fs.mkdirSync(path.dirname(dest), { recursive: true })
    fs.copyFileSync(path.join(source, f.path), dest)
    retained.push(f.path)
  }
  const transforms = []
  const record = (p, fn) => {
    const old = fs.readFileSync(path.join(target, p))
    fn()
    transforms.push({
      path: p,
      before: sha(old),
      after: sha(fs.readFileSync(path.join(target, p)))
    })
  }
  if (neutral) {
    const manifest = json(target, 'package.json')
    requireThat(
      manifest.workspaces.includes(rules.workspace),
      'workspace_missing_before_transform'
    )
    manifest.workspaces = manifest.workspaces.filter(
      (p) => p !== rules.workspace
    )
    for (const key of rules.scripts) {
      requireThat(
        typeof manifest.scripts[key] === 'string',
        `missing_product_script:${key}`
      )
      delete manifest.scripts[key]
    }
    record('package.json', () => write(target, 'package.json', manifest))
    record('package-lock.json', () =>
      write(
        target,
        'package-lock.json',
        projectLock(json(target, 'package-lock.json'), manifest)
      )
    )
    record(rules.workspacePolicy, () => {
      const policy = json(target, rules.workspacePolicy)
      requireThat(
        policy.workspacePatterns.filter((p) => p === rules.workspace).length ===
          1,
        'policy_workspace_path_drift'
      )
      policy.workspacePatterns = policy.workspacePatterns.filter(
        (p) => p !== rules.workspace
      )
      write(target, rules.workspacePolicy, policy)
    })
    record(rules.docPolicyProjection.path, () => {
      const policy = json(target, rules.docPolicyProjection.path)
      requireThat(
        policy.schemaVersion === 1 && Array.isArray(policy.movedTargets),
        'doc_policy_schema'
      )
      const matches = policy.movedTargets.filter((m) =>
        rules.docPolicyProjection.mappings.some(
          (r) => r.old === m.old && r.new === m.new
        )
      )
      requireThat(
        matches.every((m) =>
          rules.removeTrees.some((tree) => m.new.startsWith(tree + '/'))
        ),
        'doc_policy_projection_outside_removed_tree'
      )
      policy.movedTargets = policy.movedTargets.filter(
        (m) => !matches.includes(m)
      )
      write(target, rules.docPolicyProjection.path, policy)
      transforms.push({
        kind: 'document-policy-exact-removed-mappings',
        version: rules.docPolicyProjection.version,
        removedMappings: matches,
        retainedMappings: policy.movedTargets
      })
    })
    record('tsconfig.json', () => {
      const c = json(target, 'tsconfig.json')
      c.references = c.references.filter(
        (x) => x.path !== 'products/shift-assistant'
      )
      write(target, 'tsconfig.json', c)
    })
    record('tsconfig.typecheck.json', () => {
      const c = json(target, 'tsconfig.typecheck.json')
      c.include = c.include.filter((x) => !rules.typecheck.includes(x))
      write(target, 'tsconfig.typecheck.json', c)
    })
    record('vitest.config.mts', () => {
      let content = fs.readFileSync(
        path.join(target, 'vitest.config.mts'),
        'utf8'
      )
      for (const p of rules.vitest) {
        const line = new RegExp(
          `^[ ]+'${p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}'[,]?\\n`,
          'gm'
        )
        requireThat(
          [...content.matchAll(line)].length === 1,
          `exact_array_path_not_found:${p}`
        )
        content = content.replace(line, '')
      }
      requireThat(content.includes('    include: ['), 'vitest_include_missing')
      content = content.replace(
        '    include: [',
        `    exclude: ${JSON.stringify([...rules.vitestDefaultExcludes, ...rules.transitionOnly.map((x) => x.path)])},\n    include: [`
      )
      fs.writeFileSync(path.join(target, 'vitest.config.mts'), content)
    })
  }
  if (scope === 'shift-product') {
    // Select product paths only; all thresholds/exclusions/tooling stay inherited.
    const content =
      "import baseline from './vitest.config.mts'\nexport default {...baseline, test:{...baseline.test, include:['products/**/*.test.ts','products/**/*.test.tsx'], coverage:{...baseline.test.coverage, include:['products/**/*.ts','products/**/*.tsx']}}}\n"
    fs.writeFileSync(path.join(target, 'hiso-product.vitest.mts'), content)
    transforms.push({
      path: 'hiso-product.vitest.mts',
      before: null,
      after: sha(content)
    })
  }
  const after = sourceFiles(target)
  return {
    schemaVersion: 1,
    scope,
    originalCandidateId: digest(before),
    sourceSha256: digest(before),
    transformVersion: neutral ? rules.version : 'retained-v1',
    rulesHash,
    retained,
    removed,
    transforms,
    manifestBefore: sha(fs.readFileSync(path.join(source, 'package.json'))),
    manifestAfter: sha(fs.readFileSync(path.join(target, 'package.json'))),
    lockBefore: sha(fs.readFileSync(path.join(source, 'package-lock.json'))),
    lockAfter: sha(fs.readFileSync(path.join(target, 'package-lock.json'))),
    derivedVariantId: digest(after),
    derivedMappingHash: digest({ rulesHash, removed, transforms }),
    files: after
  }
}

export function ownerMapping(inputs) {
  const tests = inputs.filter(
    (f) =>
      /^(tests|packages|legacy|apps|products)\//.test(f.path) &&
      /\.(test|spec)\.(js|ts|tsx)$/.test(f.path)
  )
  return tests.map((f) => ({
    ...f,
    canonicalPath: f.path,
    owner: f.path.startsWith('products/shift-assistant/')
      ? 'shift-product'
      : rules.transitionOnly.some((x) => x.path === f.path)
        ? 'transition-regression'
        : 'harness-neutral',
    transitionRequired: true,
    reason:
      rules.transitionOnly.find((x) => x.path === f.path)?.reason ??
      'Physical source ownership; transition additionally executes full baseline.'
  }))
}
