// @vitest-environment node
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import {
  caseOccurrences,
  approvedCoverageInventory,
  coverageInventory
} from '../scripts/hiso-inventory.mjs'
import { rules } from '../scripts/hiso-variant.mjs'
import * as reports from '../scripts/hiso-reports.mjs'
const { testReport, verifySnapshots, snapshotSchema, gateTestInventory } =
  reports
import { buildCoverageReport } from '../scripts/lib/coverage-gate.mjs'

import {
  copyProjectionConfigs,
  expectedCoveragePaths,
  linkPrivateParser,
  nativeEvalArtifact
} from './fixtures/hiso-r6-measurement.mjs'

const root = path.resolve(import.meta.dirname, '..')
const json = (p) => JSON.parse(fs.readFileSync(path.join(root, p), 'utf8'))
const pkg = json('package.json')
const critical = json('scripts/critical-coverage-manifest.json')
const thresholds = json('packages/agent-evals/src/eval-thresholds.json')
const dirs = []
afterEach(() => {
  for (const d of dirs.splice(0)) fs.rmSync(d, { recursive: true, force: true })
})
const temp = () => {
  const d = fs.mkdtempSync(path.join(os.tmpdir(), 'ci-r6-own-'))
  dirs.push(d)
  return d
}
const clone = (v) => structuredClone(v)
const row = (file, name = 'case') => ({
  file,
  name,
  kind: 'COLLECTED_NOT_EXECUTED'
})
const inventory = (rows) => caseOccurrences(rows)
function native(rows) {
  const files = [...new Set(rows.map((t) => t.file))]
  return {
    success: true,
    numTotalTests: rows.length,
    numPassedTests: rows.length,
    numFailedTests: 0,
    numFailedTestSuites: 0,
    testResults: files.map((file) => ({
      name: `/synthetic/${file}`,
      status: 'passed',
      assertionResults: rows
        .filter((t) => t.file === file)
        .map((t) => ({ ancestorTitles: [], title: t.name, status: 'passed' }))
    }))
  }
}
function verify(id, report, testInventory = [], more = {}) {
  const d = temp(),
    p = `gate-outputs/${id}/report.json`
  fs.mkdirSync(path.dirname(path.join(d, p)), { recursive: true })
  fs.writeFileSync(path.join(d, p), JSON.stringify(report))
  return verifySnapshots({
    gate: { id, skipPolicy: 'none' },
    entry: { outputs: [{ path: p }] },
    directory: d,
    manifest: { testInventory, ...more.manifest },
    expected: more.expected ?? {}
  })
}
const postgres = pkg.scripts['test:postgres']
  .split(/\s+/)
  .filter((t) => t.endsWith('.test.ts'))
const chaos = fs
  .readdirSync(path.join(root, 'packages/chaos/src/__tests__'))
  .filter((p) => p.endsWith('.test.ts'))
  .map((p) => 'packages/chaos/src/__tests__/' + p)
const metrics = (total = 10, covered = total) =>
  Object.fromEntries(
    ['statements', 'lines', 'functions', 'branches'].map((k) => [
      k,
      {
        total,
        covered,
        skipped: 0,
        pct: total ? Number(((100 * covered) / total).toFixed(2)) : 100
      }
    ])
  )
function coverage() {
  const summary = Object.fromEntries(
    critical.groups.flatMap((g) => g.paths).map((p) => [p, metrics()])
  )
  summary.total = metrics(1000)
  return buildCoverageReport(summary, critical)
}
const evalReport = () => ({
  suiteId: 'phase10-core-v1',
  agentId: 'static-synthetic',
  startedAt: '2026-10-05T00:00:00.000Z',
  finishedAt: '2026-10-05T00:00:01.000Z',
  metrics: {
    scenarios: 100,
    taskSuccessRate: 1,
    policyViolationRate: 0,
    unsafeActionRate: 0,
    hallucinationRate: 0,
    toolSelectionAccuracy: 1,
    humanEscalationAccuracy: 1,
    schemaFailureRate: 0,
    refusalAccuracy: 1,
    adversarialPassRate: 1,
    avgLatencyMs: 1,
    p95LatencyMs: 1,
    totalCostUsd: 0
  },
  thresholds,
  verdict: 'PASS',
  failures: []
})

describe('R6 gate case membership', () => {
  it.each(['postgres', 'chaos'])(
    '%s accepts complete producer-shaped reports in arbitrary order',
    (id) => {
      const selected = (id === 'postgres' ? postgres : chaos).map((p) => row(p))
      selected.push(row(selected[0].file))
      const all = inventory([...selected, row('tests/unrelated.test.js')])
      expect(() =>
        verify(id, native([...selected].reverse()), all)
      ).not.toThrow()
    }
  )
  it.each(['postgres', 'chaos'])('%s rejects omitted suites', (id) => {
    const rows = (id === 'postgres' ? postgres : chaos).map((p) => row(p))
    expect(() => verify(id, native(rows.slice(1)), inventory(rows))).toThrow()
  })
  it.each(['postgres', 'chaos'])(
    '%s rejects omitted same-name occurrences',
    (id) => {
      const rows = (id === 'postgres' ? postgres : chaos).map((p) => row(p))
      const all = inventory([...rows, row(rows[0].file)])
      expect(() => verify(id, native(rows), all)).toThrow()
    }
  )
  it.each(['postgres', 'chaos'])('%s rejects changed case identity', (id) => {
    const rows = (id === 'postgres' ? postgres : chaos).map((p) => row(p))
    const report = native(rows)
    report.testResults[0].assertionResults[0].title = 'different'
    expect(() => verify(id, report, inventory(rows))).toThrow()
  })
  it('testReport rejects missing known suites', () =>
    expect(() =>
      testReport(native([row('tests/a.test.js')]), [
        'tests/a.test.js',
        'tests/b.test.js'
      ])
    ).toThrow())
  it('testReport rejects duplicate known file suites', () => {
    const r = native([row('tests/a.test.js')])
    r.testResults.push(clone(r.testResults[0]))
    r.numTotalTests = r.numPassedTests = 2
    expect(() => testReport(r, ['tests/a.test.js'])).toThrow()
  })
  it('unit canonicalizes native and manifest order', () => {
    const rows = [row('tests/z.test.js'), row('tests/a.test.js')]
    const r = native(rows)
    const executed = testReport(
      r,
      rows.map((t) => t.file)
    ).reverse()
    expect(() =>
      verify('unit', r, inventory(rows), {
        manifest: { executedTestInventory: executed },
        expected: { requiredTestIds: inventory(rows).map((t) => t.id) }
      })
    ).not.toThrow()
  })
  it('unit requires all scoped cases even if executed projection agrees with missing report', () => {
    const rows = [row('tests/a.test.js'), row('tests/b.test.js')],
      r = native(rows.slice(0, 1))
    expect(() =>
      verify('unit', r, inventory(rows), {
        manifest: { executedTestInventory: testReport(r, [rows[0].file]) },
        expected: { requiredTestIds: inventory(rows).map((t) => t.id) }
      })
    ).toThrow()
  })
  it('postgres rejects selector files absent from collected inventory', () =>
    expect(() =>
      verify(
        'postgres',
        native([row(postgres[0])]),
        inventory([row(postgres[0])])
      )
    ).toThrow())
})
describe('R6 coverage producer semantics', () => {
  it('accepts real buildCoverageReport output', () =>
    expect(() => verify('coverage-critical', coverage())).not.toThrow())
  it('accepts arbitrary group/file order', () => {
    const r = coverage()
    r.critical.groups.reverse().forEach((g) => {
      g.files.reverse()
      g.paths.reverse()
    })
    expect(() => verify('coverage-critical', r)).not.toThrow()
  })
  it('accepts legitimate type-only zero per file', () => {
    const summary = Object.fromEntries(
      critical.groups.flatMap((g) => g.paths).map((p) => [p, metrics()])
    )
    summary[critical.groups[0].paths[0]] = metrics(0)
    summary.total = metrics(1000)
    const r = buildCoverageReport(summary, critical)
    expect(r.verdict).toBe('PASS')
    expect(() => verify('coverage-critical', r)).not.toThrow()
  })
  it.each(['statements', 'lines', 'functions', 'branches'])(
    'rejects contradictory global %s',
    (k) => {
      const r = coverage()
      r.global.metrics[k].covered = 0
      expect(() => verify('coverage-critical', r)).toThrow()
    }
  )
  it.each(['statements', 'lines', 'functions', 'branches'])(
    'rejects global zero %s',
    (k) => {
      const r = coverage()
      r.global.metrics[k] = { total: 0, covered: 0, pct: 100 }
      expect(() => verify('coverage-critical', r)).toThrow()
    }
  )
  it.each([
    'omit',
    'duplicate',
    'unknown',
    'file',
    'aggregate',
    'zero',
    'threshold',
    'pct',
    'global-threshold',
    'rounded-boundary'
  ])('rejects critical contradiction %s', (kind) => {
    const r = coverage(),
      g = r.critical.groups[0]
    if (kind === 'omit') r.critical.groups.pop()
    if (kind === 'duplicate') r.critical.groups.push(clone(g))
    if (kind === 'unknown') g.id = 'unknown'
    if (kind === 'file') g.files.pop()
    if (kind === 'aggregate') g.metrics.branches.total++
    if (kind === 'zero') g.metrics = metrics(0)
    if (kind === 'threshold') r.critical.threshold = 0
    if (kind === 'pct') g.files[0].metrics.branches.pct = 99
    if (kind === 'global-threshold')
      r.global.thresholds = { ...r.global.thresholds, branches: 0 }
    if (kind === 'rounded-boundary')
      r.global.metrics.statements = { total: 100000, covered: 89999, pct: 90 }
    expect(() => verify('coverage-critical', r)).toThrow()
  })
})
describe('R6 eval verdict semantics', () => {
  it('accepts the immutable real native producer artifact', () =>
    expect(() => verify('evals', nativeEvalArtifact())).not.toThrow())
  it('accepts inert native producer shape', () =>
    expect(() => verify('evals', evalReport())).not.toThrow())
  it.each([
    'taskSuccessRate',
    'policyViolationRate',
    'unsafeActionRate',
    'schemaFailureRate',
    'adversarialPassRate',
    'humanEscalationAccuracy'
  ])('rejects asserted PASS violating %s', (k) => {
    const r = evalReport()
    r.metrics[k] = [
      'policyViolationRate',
      'unsafeActionRate',
      'schemaFailureRate'
    ].includes(k)
      ? 1
      : 0
    expect(() => verify('evals', r)).toThrow()
  })
  it('rejects thresholds weakened from producer', () => {
    const r = evalReport()
    r.thresholds = { ...thresholds, taskSuccessRate: 0 }
    expect(() => verify('evals', r)).toThrow()
  })
  it('rejects omitted producer metric', () => {
    const r = evalReport()
    delete r.metrics.unsafeActionRate
    expect(() => verify('evals', r)).toThrow()
  })
  it('rejects unexplained failed scenario with perfect success', () => {
    const r = evalReport()
    r.failures = [
      { scenarioId: 'inert', reasons: ['intent_mismatch:synthetic'] }
    ]
    expect(() => verify('evals', r)).toThrow()
  })
  it('preserves producer PASS with legitimate tolerable scenario failures', () => {
    const r = evalReport()
    r.metrics.taskSuccessRate = 0.99
    r.failures = [
      { scenarioId: 'inert', reasons: ['intent_mismatch:synthetic'] }
    ]
    expect(() => verify('evals', r)).not.toThrow()
  })
  it('rejects global zero scenarios', () => {
    const r = evalReport()
    r.metrics.scenarios = 0
    expect(() => verify('evals', r)).toThrow()
  })
})
describe('R6 inventory producer compatibility', () => {
  it('accepts the current declaration-bearing emitter envelope', () =>
    expect(() =>
      snapshotSchema(
        {
          schemaVersion: 1,
          kind: 'hiso-inventory-v1',
          declarations: [],
          mapping: [],
          inventory: [],
          coveragePaths: [],
          transitionOnly: []
        },
        'inventory'
      )
    ).not.toThrow())
})

describe('R6 conservative selector parsing', () => {
  it.each([
    'vitest run packages/chaos --coverage --no-file-parallelism --maxWorkers=2',
    'vitest run packages/chaos-extra --no-file-parallelism --maxWorkers=2',
    'vitest run packages/chaos; --no-file-parallelism --maxWorkers=2',
    'vitest run --no-file-parallelism --maxWorkers=2'
  ])('rejects unknown chaos selector %s', (script) =>
    expect(() =>
      gateTestInventory('chaos', inventory(chaos.map((p) => row(p))), {
        'test:chaos': script
      })
    ).toThrow()
  )
  it('rejects unknown postgres options', () =>
    expect(() =>
      gateTestInventory('postgres', inventory(postgres.map((p) => row(p))), {
        'test:postgres': pkg.scripts['test:postgres'] + ' --exclude=apps/**'
      })
    ).toThrow())
})

// Build the exact approved projection using the existing variant rules. All
// source contents are inert; only physical membership/config bindings matter.
function projectedRoot() {
  const d = temp()
  const write = (p, value) => {
    fs.mkdirSync(path.dirname(path.join(d, p)), { recursive: true })
    fs.writeFileSync(path.join(d, p), value)
  }
  copyProjectionConfigs(root, d, 'neutral')
  const paths = expectedCoveragePaths(root, 'neutral')
  paths.forEach((p) => write(p, 'export interface Inert {}\n'))
  linkPrivateParser(root, d)
  return { d, paths, write }
}
describe('R6 exact approved neutral projection', () => {
  it('accepts only the complete physical approved transform', () => {
    const f = projectedRoot()
    expect(coverageInventory(f.d)).toEqual(f.paths)
    expect(approvedCoverageInventory(f.d)).toEqual(f.paths)
  })
  it('retains the original full root denominator', () => {
    expect(approvedCoverageInventory(root)).toEqual(expectedCoveragePaths(root))
  })
  it('rejects arbitrary retained source omission', () => {
    const f = projectedRoot()
    fs.unlinkSync(path.join(f.d, f.paths[0]))
    expect(() => approvedCoverageInventory(f.d)).toThrow(
      'approved_coverage_source_inventory'
    )
  })
  it('rejects merely deleting products with original configuration', () => {
    const f = projectedRoot()
    copyProjectionConfigs(root, f.d, 'retained')
    expect(() => approvedCoverageInventory(f.d)).toThrow(
      'approved_coverage_source_inventory'
    )
  })
  it.each([
    'package-lock.json',
    'tsconfig.json',
    'tsconfig.typecheck.json',
    'vitest.config.mts',
    rules.workspacePolicy,
    rules.docPolicyProjection.path
  ])('rejects projection drift at %s', (p) => {
    const f = projectedRoot()
    f.write(p, fs.readFileSync(path.join(f.d, p), 'utf8') + '\n')
    expect(() => approvedCoverageInventory(f.d)).toThrow(
      'approved_coverage_source_inventory'
    )
  })
  it('rejects a physically retained product tree', () => {
    const f = projectedRoot()
    f.write('products/shift-assistant/marker.txt', 'inert')
    expect(() => approvedCoverageInventory(f.d)).toThrow(
      'approved_coverage_source_inventory'
    )
  })
  it('rejects arbitrary coverage exclusion even with no products', () => {
    const f = projectedRoot()
    f.write(
      'vitest.config.mts',
      fs
        .readFileSync(path.join(f.d, 'vitest.config.mts'), 'utf8')
        .replace("'**/*.test.ts',", `'${f.paths[0]}',\n        '**/*.test.ts',`)
    )
    expect(() => approvedCoverageInventory(f.d)).toThrow(
      'approved_coverage_source_inventory'
    )
  })
})

describe('R6 additional inert failure projections', () => {
  it('eval forbids a failed forbidden capability with zero unsafe rate', () => {
    const r = evalReport()
    r.metrics.taskSuccessRate = 0.99
    r.failures = [
      { scenarioId: 'inert', reasons: ['forbidden_capability:inert'] }
    ]
    expect(() => verify('evals', r)).toThrow()
  })
  it('eval rejects duplicate scenario failure identities', () => {
    const r = evalReport()
    r.metrics.taskSuccessRate = 0.98
    r.failures = [
      { scenarioId: 'inert', reasons: ['intent_mismatch:inert'] },
      { scenarioId: 'inert', reasons: ['intent_mismatch:inert'] }
    ]
    expect(() => verify('evals', r)).toThrow()
  })
  it('postgres rejects replacement of a frozen file selector', () => {
    const s = pkg.scripts['test:postgres'].replace(
      postgres[0],
      'packages/inert.test.ts'
    )
    expect(() =>
      gateTestInventory('postgres', inventory(postgres.map((p) => row(p))), {
        'test:postgres': s
      })
    ).toThrow()
  })
  it.each(['postgres', 'chaos'])('%s rejects duplicate file suites', (id) => {
    const rows = (id === 'postgres' ? postgres : chaos).map((p) => row(p))
    const r = native(rows)
    r.testResults.push(clone(r.testResults[0]))
    r.numPassedTests = r.numTotalTests = rows.length + 1
    expect(() => verify(id, r, inventory(rows))).toThrow()
  })
  it.each(['postgres', 'chaos'])(
    '%s rejects an unrelated known global suite',
    (id) => {
      const rows = (id === 'postgres' ? postgres : chaos).map((p) => row(p))
      const unrelated = row('tests/unrelated.test.js')
      expect(() =>
        verify(
          id,
          native([...rows, unrelated]),
          inventory([...rows, unrelated])
        )
      ).toThrow()
    }
  )
  it.each(['postgres', 'chaos'])('%s rejects a pending required case', (id) => {
    const rows = (id === 'postgres' ? postgres : chaos).map((p) => row(p))
    const r = native(rows)
    r.testResults[0].assertionResults[0].status = 'pending'
    r.numPassedTests--
    expect(() => verify(id, r, inventory(rows))).toThrow()
  })
})

// R7 additions preserve the entire original R6 test prefix.
describe('R7 producer and verifier case admission parity', () => {
  for (const id of ['postgres', 'chaos']) {
    const selected = (id === 'postgres' ? postgres : chaos).map((p) => row(p))
    selected.push(row(selected[0].file))
    const all = inventory([...selected, row('tests/unrelated.test.js')])
    it(id + ' shares complete ordered-independent admission', () => {
      const report = native([...selected].reverse())
      expect(
        reports.gateTestReport(report, { id, skipPolicy: 'none' }, all)
      ).toEqual(verify(id, report, all).tests)
    })
    it.each(['case', 'suite', 'duplicate', 'identity', 'status'])(
      id + ' rejects %s before snapshots',
      (kind) => {
        let chosen = [...selected]
        if (kind === 'case') chosen.pop()
        if (kind === 'suite')
          chosen = chosen.filter((t) => t.file !== selected[0].file)
        if (kind === 'duplicate') chosen.push(row(selected[0].file))
        const report = native(chosen)
        if (kind === 'identity')
          report.testResults[0].assertionResults[0].title = 'different'
        if (kind === 'status')
          report.testResults[0].assertionResults[0].status = 'failed'
        expect(() =>
          reports.gateTestReport(report, { id, skipPolicy: 'none' }, all)
        ).toThrow()
        expect(() => verify(id, report, all)).toThrow()
      }
    )
  }
})
it.each(['160000', 160000.5, 159999, 170000, NaN, Infinity])(
  'R7 snapshot schema rejects Pg version %s',
  (version) => {
    expect(() =>
      snapshotSchema(
        { schemaVersion: 1, status: 'PASS', version },
        'postgres-version'
      )
    ).toThrow('postgres_version_binding')
  }
)
it.each([160000, 169999])(
  'R7 snapshot schema accepts safe Pg16 integer %s',
  (version) => {
    expect(() =>
      snapshotSchema(
        { schemaVersion: 1, status: 'PASS', version },
        'postgres-version'
      )
    ).not.toThrow()
  }
)
describe('R7 integral native eval projection', () => {
  it('rejects adversarial failure when every native scenario succeeds', () => {
    const r = nativeEvalArtifact()
    r.metrics.adversarialPassRate = 0.95
    expect(() => snapshotSchema(r, 'evals')).toThrow()
  })
  it('rejects a fractional native schema/hallucination numerator', () => {
    const r = nativeEvalArtifact()
    r.metrics.schemaFailureRate = r.metrics.hallucinationRate = 0.001
    expect(() => snapshotSchema(r, 'evals')).toThrow('eval_integral_numerator')
  })
  it('rejects fractional policy count even inside a reason-derived interval', () => {
    const r = evalReport()
    r.failures = [{ scenarioId: 'inert', reasons: ['escalation_mismatch'] }]
    r.metrics.taskSuccessRate = r.metrics.humanEscalationAccuracy = 0.99
    r.metrics.policyViolationRate = 0.001
    expect(() => snapshotSchema(r, 'evals')).toThrow('eval_integral_numerator')
  })
  it('binds the native failed case to its actual adversarial group', () => {
    const r = nativeEvalArtifact()
    r.failures = [
      { scenarioId: 'EV-001', reasons: ['intent_mismatch:synthetic'] }
    ]
    r.metrics.taskSuccessRate = 55 / 56
    r.metrics.adversarialPassRate = 0.95
    expect(() => snapshotSchema(r, 'evals')).toThrow(
      'eval_native_projection:adversarialPassRate'
    )
  })
  it('accepts a legitimate native ordinary failure below the tolerance', () => {
    const r = nativeEvalArtifact()
    r.failures = [
      { scenarioId: 'EV-001', reasons: ['intent_mismatch:synthetic'] }
    ]
    r.metrics.taskSuccessRate = 55 / 56
    expect(() => snapshotSchema(r, 'evals')).not.toThrow()
  })
  it('rejects unknown failed case IDs in the collected core corpus', () => {
    const r = nativeEvalArtifact()
    r.failures = [
      { scenarioId: 'unknown', reasons: ['intent_mismatch:synthetic'] }
    ]
    r.metrics.taskSuccessRate = 55 / 56
    expect(() => snapshotSchema(r, 'evals')).toThrow('eval_failure_membership')
  })
  it('keeps the native empty adversarial group rate at one', () => {
    const r = evalReport()
    r.failures = [
      { scenarioId: 'inert', reasons: ['intent_mismatch:synthetic'] }
    ]
    r.metrics.taskSuccessRate = 0.99
    expect(() => snapshotSchema(r, 'evals')).not.toThrow()
    r.metrics.adversarialPassRate = 0.991
    expect(() => snapshotSchema(r, 'evals')).toThrow()
  })
})

import { vi } from 'vitest'
const nativePgMock = vi.hoisted(() => {
  const state = { version: '160000', connects: 0, queries: [], ends: 0 }
  class NativePgVersionMockClient {
    async connect() {
      state.connects++
    }
    async query(sql) {
      state.queries.push(sql)
      return { rows: [{ server_version_num: state.version }] }
    }
    async end() {
      state.ends++
    }
  }
  return { state, Client: NativePgVersionMockClient }
})
vi.mock('../node_modules/pg/esm/index.mjs', () => ({
  Client: nativePgMock.Client
}))
afterEach(() => {
  vi.unstubAllEnvs()
})
it.each([
  '160000',
  '169999',
  '160000.5',
  160000.5,
  '159999',
  '170000',
  'NaN',
  'Infinity',
  '',
  '-1',
  '9007199254740993',
  null
])('native Pg CLI validates %s before output', async (rawVersion) => {
  vi.resetModules()
  // An ineffective mock is a test setup failure before any producer import;
  // the real client must never connect or resolve a host in these cases.
  const admittedPg = await import('pg')
  expect(admittedPg.Client).toBe(nativePgMock.Client)
  Object.assign(nativePgMock.state, {
    version: rawVersion,
    connects: 0,
    queries: [],
    ends: 0
  })
  const output = path.join(temp(), 'postgres-version.json')
  vi.stubEnv('TEST_DATABASE_URL', 'SYNTHETIC_PURE_MOCK_NO_NETWORK')
  vi.stubEnv('CI_CANDIDATE_ID', 'a'.repeat(64))
  vi.stubEnv('CI_RUN_ID', 'CI_NATIVE_PG_VERSION_R8')
  vi.stubEnv('HISO_PG_VERSION_OUTPUT', output)
  let error
  try {
    await import('../scripts/hiso-postgres-version.mjs')
  } catch (caught) {
    error = caught
  }
  expect(nativePgMock.state.connects).toBe(1)
  expect(nativePgMock.state.queries).toEqual(['SHOW server_version_num'])
  expect(nativePgMock.state.ends).toBe(1)
  const valid =
    Number.isSafeInteger(Number(rawVersion)) &&
    Number(rawVersion) >= 160000 &&
    Number(rawVersion) < 170000
  if (valid) {
    expect(error).toBeUndefined()
    const report = JSON.parse(fs.readFileSync(output, 'utf8'))
    expect(report).toEqual({
      schemaVersion: 1,
      status: 'PASS',
      version: Number(rawVersion),
      runId: 'CI_NATIVE_PG_VERSION_R8',
      candidateId: 'a'.repeat(64),
      synthetic: true,
      command: 'SHOW server_version_num'
    })
  } else {
    expect(
      fs.existsSync(output),
      'invalid native version emits no receipt'
    ).toBe(false)
    expect(error?.message).toBe('hiso:pg16_version_required')
  }
})

// R9 additions preserve the complete original 113-case prefix, including the
// native Pg ESM identity guard. These reports are pure synthetic JSON only.
describe('R9 raw critical branch threshold', () => {
  const rawCoverage = (covered, total) => {
    const paths = [...new Set(critical.groups.flatMap((g) => g.paths))]
    const summary = Object.fromEntries(
      paths.map((p) => [p, metrics(total, covered)])
    )
    summary.total = metrics(total * paths.length, covered * paths.length)
    return buildCoverageReport(summary, critical)
  }
  it.each([
    [94999, 100000],
    [949994, 1000000],
    [949995, 1000000],
    [949996, 1000000]
  ])('rejects raw %s/%s despite displayed 95', (covered, total) => {
    const report = rawCoverage(covered, total)
    expect(
      report.critical.groups.every((g) => g.metrics.branches.pct === 95)
    ).toBe(true)
    expect(report.global.pass).toBe(true)
    expect(report.verdict).toBe('FAIL')
    expect(report.critical.failures).toEqual(
      critical.groups.map((g) => `critical_coverage_below_threshold:${g.id}`)
    )
    expect(() => snapshotSchema(report, 'coverage-critical')).toThrow()
    expect(() => verify('coverage-critical', report)).toThrow()
  })
  it.each([
    [94999, 100000],
    [949995, 1000000]
  ])('rejects a claimed rounded PASS for raw %s/%s', (covered, total) => {
    const report = rawCoverage(covered, total)
    report.verdict = 'PASS'
    report.failures = []
    report.critical.pass = true
    report.critical.failures = []
    expect(() => snapshotSchema(report, 'coverage-critical')).toThrow()
    expect(() => verify('coverage-critical', report)).toThrow()
  })
  it.each([
    [95000, 100000],
    [950000, 1000000],
    [95001, 100000],
    [100000, 100000]
  ])('admits raw boundary or above %s/%s', (covered, total) => {
    const report = rawCoverage(covered, total)
    expect(report.verdict).toBe('PASS')
    expect(report.critical.failures).toEqual([])
    expect(() => snapshotSchema(report, 'coverage-critical')).not.toThrow()
    expect(() => verify('coverage-critical', report)).not.toThrow()
  })
  it('uses the weighted group ratio, retaining the rounded projection', () => {
    const manifest = {
      branchThreshold: 95,
      groups: [{ id: 'weighted', paths: ['a.ts', 'b.ts'] }]
    }
    const report = buildCoverageReport(
      {
        total: metrics(1000, 950),
        'a.ts': metrics(10, 0),
        'b.ts': metrics(990, 950)
      },
      manifest
    )
    expect(report.verdict).toBe('PASS')
    expect(report.critical.groups[0].metrics.branches).toEqual({
      total: 1000,
      covered: 950,
      pct: 95
    })
    expect(report.critical.groups[0].files[0].metrics.branches.pct).toBe(0)
  })
  it('rejects aggregated zero denominators', () => {
    const report = rawCoverage(0, 0)
    expect(report.verdict).toBe('FAIL')
    expect(report.critical.failures).toEqual(
      critical.groups.map((g) => `critical_coverage_invalid:${g.id}:branches`)
    )
    expect(() => snapshotSchema(report, 'coverage-critical')).toThrow()
  })
})

describe('R9 unit collected membership before snapshot', () => {
  const selected = [
    row('tests/r9-a.test.js', 'same'),
    row('tests/r9-a.test.js', 'same'),
    row('tests/r9-a.test.js', 'different'),
    row('tests/r9-b.test.js', 'other file')
  ]
  const collected = inventory(selected)
  const unitGate = (skipPolicy = 'none') => ({
    id: 'unit',
    skipPolicy,
    artifacts: ['unit-report.json']
  })
  const producerAdmission = async (
    report,
    required = collected,
    policy = 'none'
  ) => {
    const { validateReport, snapshotOutputs } =
      await import('../scripts/hiso-ci.mjs')
    const working = temp(),
      output = temp()
    fs.writeFileSync(
      path.join(working, 'unit-report.json'),
      JSON.stringify(report)
    )
    let error, skipped
    try {
      skipped = validateReport(unitGate(policy), working, {}, '', required)
      snapshotOutputs(working, output, unitGate(policy))
    } catch (caught) {
      error = caught
    }
    return {
      error,
      skipped,
      emitted: fs.existsSync(
        path.join(output, 'gate-outputs/unit/unit-report.json')
      )
    }
  }
  const snapshotAdmission = (
    report,
    required = collected,
    policy = 'none',
    more = {}
  ) => {
    const d = temp(),
      p = 'gate-outputs/unit/unit-report.json'
    fs.mkdirSync(path.dirname(path.join(d, p)), { recursive: true })
    fs.writeFileSync(path.join(d, p), JSON.stringify(report))
    // Report-consistent executed projection must never replace collected scope.
    const executed = testReport(
      report,
      [...new Set(required.map((t) => t.file))],
      policy
    )
    return verifySnapshots({
      gate: unitGate(policy),
      entry: { outputs: [{ path: p }] },
      directory: d,
      manifest: {
        testInventory: required,
        executedTestInventory: executed,
        ...more.manifest
      },
      expected: { requiredTestIds: required.map((t) => t.id), ...more.expected }
    })
  }
  it.each([
    'missing',
    'renamed',
    'extra',
    'ancestor',
    'moved file',
    'missing suite',
    'extra suite'
  ])('rejects %s before emitting any snapshot and downstream', async (kind) => {
    let chosen = [...selected]
    if (kind === 'missing') chosen.splice(0, 1)
    if (kind === 'renamed') chosen[2] = row(selected[2].file, 'renamed')
    if (kind === 'extra') chosen.push(selected[0])
    if (kind === 'moved file')
      chosen[2] = row(selected[3].file, selected[2].name)
    if (kind === 'missing suite') chosen.pop()
    if (kind === 'extra suite') chosen.push(row('tests/r9-outside.test.js'))
    const report = native(chosen)
    if (kind === 'ancestor')
      report.testResults[0].assertionResults[2].ancestorTitles = ['new parent']
    const observed = await producerAdmission(report)
    expect(observed.error).toBeInstanceOf(Error)
    expect(observed.emitted).toBe(false)
    expect(() => snapshotAdmission(report)).toThrow()
  })
  it('accepts complete reversed membership with same-name duplicates', async () => {
    const report = native([...selected].reverse())
    const observed = await producerAdmission(report)
    expect(observed.error).toBeUndefined()
    expect(observed.skipped).toBe(0)
    expect(observed.emitted).toBe(true)
    expect(reports.gateTestReport(report, unitGate(), collected)).toEqual(
      snapshotAdmission(report).tests
    )
  })
  it('accepts duplicate titles distinguished by ancestor hierarchy', async () => {
    const cases = [
      row(selected[0].file, 'first > same'),
      row(selected[0].file, 'second > same')
    ]
    const required = inventory(cases)
    const report = native(cases)
    report.testResults[0].assertionResults.forEach((t, i) => {
      t.ancestorTitles = [i === 0 ? 'first' : 'second']
      t.title = 'same'
    })
    expect((await producerAdmission(report, required)).emitted).toBe(true)
    expect(() => snapshotAdmission(report, required)).not.toThrow()
  })
  it('binds only the supplied collected scope while requiring all its cases', async () => {
    const required = inventory(selected.slice(0, 3)),
      report = native(selected.slice(0, 3))
    expect((await producerAdmission(report, required)).emitted).toBe(true)
    expect(() => snapshotAdmission(report, required)).not.toThrow()
    expect((await producerAdmission(report, collected)).emitted).toBe(false)
    expect(() => snapshotAdmission(report, collected)).toThrow()
  })
  it('keeps an outside required id mandatory even with a matching execution projection', () => {
    const report = native(selected)
    const outside = inventory([row('tests/r9-outside.test.js')])[0]
    expect(() =>
      snapshotAdmission(report, collected, 'none', {
        expected: {
          requiredTestIds: [...collected.map((t) => t.id), outside.id]
        }
      })
    ).toThrow()
  })
  it('retains the exact executed status projection downstream', () => {
    const report = native(selected)
    const executed = testReport(report, [
      ...new Set(selected.map((t) => t.file))
    ])
    executed[0].status = 'pending'
    expect(() =>
      snapshotAdmission(report, collected, 'none', {
        manifest: { executedTestInventory: executed }
      })
    ).toThrow()
  })
  it.each(['pending', 'skipped', 'todo'])(
    'preserves catalog policy for %s without weakening no-skip gates',
    async (status) => {
      const report = native(selected)
      report.testResults[0].assertionResults[2].status = status
      report.numPassedTests--
      report.numPendingTests = status === 'todo' ? 0 : 1
      report.numTodoTests = status === 'todo' ? 1 : 0
      const allowed = await producerAdmission(report, collected, 'catalog')
      expect(allowed.error).toBeUndefined()
      expect(allowed.skipped).toBe(1)
      expect(allowed.emitted).toBe(true)
      expect(() =>
        snapshotAdmission(report, collected, 'catalog')
      ).not.toThrow()
      const denied = await producerAdmission(report)
      expect(denied.error).toBeInstanceOf(Error)
      expect(denied.emitted).toBe(false)
      expect(() => snapshotAdmission(report)).toThrow()
    }
  )
  it.each(['empty', 'failed', 'counter mismatch'])(
    'rejects %s without snapshot emission',
    async (kind) => {
      const report = native(selected)
      if (kind === 'empty') report.testResults[0].assertionResults = []
      if (kind === 'failed')
        report.testResults[0].assertionResults[0].status = 'failed'
      if (kind === 'counter mismatch') report.numPassedTests--
      const observed = await producerAdmission(report)
      expect(observed.error).toBeInstanceOf(Error)
      expect(observed.emitted).toBe(false)
      expect(() => snapshotAdmission(report)).toThrow()
    }
  )
})

it.each(['pending', 'skipped', 'todo'])(
  'R9 preserves current governed unit policy for %s before emission',
  async (status) => {
    const { contract } = await import('../scripts/hiso-contract.mjs')
    const { validateReport, snapshotOutputs } =
      await import('../scripts/hiso-ci.mjs')
    const gate = contract.scopes
      .find((s) => s.id === 'harness-neutral')
      .gates.find((g) => g.id === 'unit')
    expect(gate.skipPolicy).toBe('governed')
    expect(
      contract.scopes
        .find((s) => s.id === 'transition-regression')
        .gates.find((g) => g.id === 'unit').skipPolicy
    ).toBe('governed')
    expect(
      contract.scopes
        .find((s) => s.id === 'shift-product')
        .gates.find((g) => g.id === 'unit').skipPolicy
    ).toBe('none')
    const selected = [
      row('tests/r9-governed.test.js'),
      row('tests/r9-governed.test.js')
    ]
    const required = inventory(selected),
      report = native(selected)
    report.testResults[0].assertionResults[1].status = status
    report.numPassedTests = 1
    report.numPendingTests = status === 'todo' ? 0 : 1
    report.numTodoTests = status === 'todo' ? 1 : 0
    const working = temp(),
      output = temp(),
      artifact = 'governed-unit.json'
    fs.writeFileSync(path.join(working, artifact), JSON.stringify(report))
    const producerGate = { ...gate, artifacts: [artifact] }
    expect(validateReport(producerGate, working, {}, '', required)).toBe(1)
    const snapshots = snapshotOutputs(working, output, producerGate)
    const executed = reports.gateTestReport(report, gate, required)
    expect(
      verifySnapshots({
        gate,
        entry: { outputs: snapshots },
        directory: output,
        manifest: { testInventory: required, executedTestInventory: executed },
        expected: { requiredTestIds: required.map((t) => t.id) }
      }).tests
    ).toEqual(executed)
    const deniedGate = { ...producerGate, skipPolicy: 'none' }
    expect(() =>
      validateReport(deniedGate, working, {}, '', required)
    ).toThrow()
    // Even governed skips retain the complete same-title multiplicity.
    expect(() =>
      validateReport(
        producerGate,
        working,
        {},
        '',
        inventory([...selected, selected[0]])
      )
    ).toThrow()
  }
)

// R10: finite JSON/text fixtures; processes invoke only trusted native CLIs.
import { spawnSync as r10Spawn } from 'node:child_process'
import {
  contract as r10Contract,
  contractHash as r10ContractHash,
  digest as r10Digest,
  files as r10Files,
  sha as r10Sha,
  sourceFiles as r10Sources,
  VERSION as r10Version
} from '../scripts/hiso-contract.mjs'
import { CI_BAR_GATES as r10Gates } from '../scripts/ci-bar-contract.mjs'
import {
  createGateSeal as r10CreateSeal,
  encodeGateSeal as r10EncodeSeal,
  gateStepId as r10Step,
  runnerIdentity as r10Runner,
  verifyGateSeals as r10CheckSeals
} from '../scripts/ci-bar-provenance.mjs'
import {
  sealFor as r10Seal,
  verifyScope as r10VerifyScope
} from '../scripts/hiso-verifier.mjs'
const r10Write = (p, value) => {
  fs.mkdirSync(path.dirname(p), { recursive: true })
  fs.writeFileSync(p, JSON.stringify(value) + '\n')
}
const r10Hash = 'a'.repeat(64)
let r10Candidate
function r10Import(report, required) {
  const requiredReports = Object.fromEntries(
    ['postgres', 'chaos'].map((id) => [
      id,
      (id === 'postgres' ? postgres : chaos).map((file) =>
        row(file, 'synthetic required gate case')
      )
    ])
  )
  const collected = [
    ...required,
    ...inventory(
      [...new Set([...postgres, ...chaos])].map((file) =>
        row(file, 'synthetic required gate case')
      )
    )
  ]
  const d = temp(),
    original = path.join(d, 'original'),
    out = path.join(d, 'out')
  const env = {
    ...process.env,
    GITHUB_RUN_ID: '777',
    GITHUB_RUN_ATTEMPT: '1',
    GITHUB_SHA: 'f'.repeat(40),
    GITHUB_REPOSITORY: 'synthetic/fixture',
    GITHUB_WORKFLOW: 'Inert R10 fixture',
    CI_RUN_ID: 'run-777-1',
    GITHUB_OUTPUT: path.join(d, 'step-output.txt'),
    HISO_PG_VERSION_OUTPUT: path.join(d, 'pg.json')
  }
  const github = r10Runner(env)
  const state = {
    runId: 'run-777-1',
    candidateId: r10Hash,
    nodeVersion: process.versions.node,
    gates: []
  }
  fs.mkdirSync(original)
  fs.writeFileSync(path.join(original, 'runtime.txt'), 'inert fixture\n')
  for (const gate of r10Gates.filter((g) => g.id !== 'artifacts')) {
    const log = 'inert fixture; no gate execution: ' + gate.id + '\n'
    const lp = 'gates/' + gate.id + '.log'
    fs.mkdirSync(path.dirname(path.join(original, lp)), { recursive: true })
    fs.writeFileSync(path.join(original, lp), log)
    const entry = {
      id: gate.id,
      status: 'PASS',
      exitCode: 0,
      runId: state.runId,
      candidateId: r10Hash,
      nodeVersion: state.nodeVersion,
      outputFailures: [],
      log: lp,
      logSha256: r10Sha(log)
    }
    for (const p of gate.artifacts ?? [])
      r10Write(
        path.join(original, 'gate-outputs', gate.id, p),
        gate.id === 'unit'
          ? report
          : requiredReports[gate.id]
            ? native(requiredReports[gate.id])
            : { inert: true }
      )
    if (gate.id === 'e2e')
      Object.assign(entry, {
        executionId: 'inert-execution',
        testCount: 1,
        testInventorySha256: r10Hash,
        artifactSha256: Object.fromEntries(
          gate.artifacts.map((p) => [
            p,
            r10Sha(
              fs.readFileSync(path.join(original, 'gate-outputs', gate.id, p))
            )
          ])
        )
      })
    state.gates.push(entry)
  }
  const steps = Object.fromEntries(
    r10Gates
      .filter((g) => g.id !== 'artifacts')
      .map((g) => [
        r10Step(g.id),
        {
          outcome: 'success',
          conclusion: 'success',
          outputs: {
            seal: r10EncodeSeal(
              r10CreateSeal({ id: g.id, state, artifactDir: original, github })
            )
          }
        }
      ])
  )
  expect(
    r10CheckSeals({ state, artifactDir: original, steps, github }).failures
  ).toEqual([])
  const candidate = (r10Candidate ??= r10Digest(r10Sources(root)))
  const expected = {
    schemaVersion: 1,
    contract: r10Version,
    contractHash: r10ContractHash,
    candidateId: candidate,
    sourceSha256: candidate,
    ownerMappingHash: r10Hash,
    runId: state.runId,
    attempt: '1',
    sha: env.GITHUB_SHA,
    startedAt: '2026-10-05T00:00:00.000Z',
    coveragePaths: [],
    coverageSources: [],
    testInventory: collected,
    scopes: {}
  }
  for (const s of r10Contract.scopes)
    expected.scopes[s.id] = {
      ...expected,
      scopes: undefined,
      scope: s.id,
      derivedVariantId: candidate,
      derivedMappingHash: r10Hash,
      lockSha256: r10Hash,
      testInventoryHash: r10Digest(collected),
      requiredTestIds: required.map((t) => t.id)
    }
  const legacy = {
    verdict: 'PASS',
    provenance: { mode: 'GITHUB_STEP_OUTPUT_SEALED' },
    runId: state.runId,
    candidateId: r10Hash,
    npmVersion: 'inert',
    startedAt: expected.startedAt,
    gates: [...state.gates, { id: 'artifacts', status: 'PASS' }]
  }
  r10Write(path.join(original, 'ci-bar-state.json'), state)
  r10Write(path.join(original, 'ci-bar-manifest.json'), legacy)
  r10Write(path.join(d, 'expected.json'), expected)
  r10Write(env.HISO_PG_VERSION_OUTPUT, {
    schemaVersion: 1,
    status: 'PASS',
    version: 160000,
    runId: state.runId,
    candidateId: r10Hash
  })
  env.CI_BAR_STEPS_JSON = JSON.stringify(steps)
  env.LEGACY_MANIFEST_SHA256 = r10Sha(
    fs.readFileSync(path.join(original, 'ci-bar-manifest.json'))
  )
  const cli = r10Spawn(
    process.execPath,
    [
      'scripts/hiso-import-legacy.mjs',
      original,
      path.join(d, 'expected.json'),
      out
    ],
    { cwd: root, env, encoding: 'utf8' }
  )
  expect(cli.error).toBeUndefined()
  const manifest = JSON.parse(fs.readFileSync(path.join(out, 'manifest.json')))
  return { cli, manifest, out, required }
}

describe('R10 native legacy importer shared admission', () => {
  const selected = [
    row('tests/r10-unit.test.js', 'same'),
    row('tests/r10-unit.test.js', 'same'),
    row('tests/r10-unit.test.js', 'other')
  ]
  it.each(['complete', 'reordered', 'pending', 'skipped', 'todo'])(
    'admits complete 3/3 %s using the existing governed policy',
    (kind) => {
      const rows = clone(selected)
      if (kind === 'reordered') rows.reverse()
      const report = native(rows)
      if (['pending', 'skipped', 'todo'].includes(kind)) {
        report.testResults[0].assertionResults[2].status = kind
        report.numPassedTests--
        report.numPendingTests = kind === 'todo' ? 0 : 1
        report.numTodoTests = kind === 'todo' ? 1 : 0
      }
      const observed = r10Import(report, inventory(selected))
      expect(observed.cli.status).toBe(0)
      expect(observed.manifest.status).toBe('PASS')
      expect(observed.manifest.executedTestInventory).toHaveLength(3)
      expect(observed.manifest.gates.find((g) => g.id === 'unit').skipped).toBe(
        ['pending', 'skipped', 'todo'].includes(kind) ? 1 : 0
      )
      const gate = r10Contract.scopes
        .find((s) => s.id === 'transition-regression')
        .gates.find((g) => g.id === 'unit')
      expect(
        verifySnapshots({
          gate,
          entry: observed.manifest.gates.find((g) => g.id === 'unit'),
          directory: observed.out,
          manifest: observed.manifest,
          expected: { requiredTestIds: observed.required.map((t) => t.id) }
        }).tests
      ).toEqual(observed.manifest.executedTestInventory)
    }
  )
  it.each([
    'missing occurrence',
    'extra occurrence',
    'renamed name',
    'renamed file',
    'forged id',
    'forged occurrence',
    'failed',
    'counts'
  ])('rejects %s before any unit PASS emission', (kind) => {
    const rows = clone(selected),
      required = inventory(selected)
    if (kind === 'missing occurrence') rows.splice(1, 1)
    if (kind === 'extra occurrence') rows.push(clone(rows[0]))
    if (kind === 'renamed name') rows[0].name = 'other name'
    if (kind === 'renamed file') rows[0].file = 'tests/other-r10.test.js'
    if (kind === 'forged id') required[0].id = 'b'.repeat(64)
    if (kind === 'forged occurrence') required[0].occurrence = 8
    const report = native(rows)
    if (kind === 'failed')
      report.testResults[0].assertionResults[0].status = 'failed'
    if (kind === 'counts') report.numPassedTests--
    const observed = r10Import(report, required)
    expect(observed.cli.status).toBe(1)
    expect(observed.manifest.status).toBe('FAIL')
    expect(observed.manifest.cause).toMatch(/hiso:/)
    expect(r10Files(observed.out).map((f) => f.path)).toEqual([
      'import-failure.log',
      'manifest.json'
    ])
    expect(fs.existsSync(path.join(observed.out, 'gate-outputs/unit'))).toBe(
      false
    )
    expect(fs.existsSync(path.join(observed.out, 'legacy'))).toBe(false)
  })
})

const r10Critical = json('scripts/critical-coverage-manifest.json')
const r10CoverageVectors = [
  ['raw-94.999', 100000, 94999, 'FAIL'],
  ['raw-95', 100000, 95000, 'PASS'],
  ['raw-95.001', 100000, 95001, 'PASS'],
  ['zero', 0, 0, 'FAIL'],
  ['covered exceeds total', 100, 101, 'FAIL'],
  ['fraction', 100.5, 100.5, 'FAIL'],
  ['unsafe integer', 9007199254740992, 9007199254740992, 'FAIL'],
  [
    'safe sum overflow',
    Number.MAX_SAFE_INTEGER,
    Number.MAX_SAFE_INTEGER,
    'FAIL'
  ]
]
describe('R10 native public critical coverage CLI', () => {
  it.each(r10CoverageVectors)(
    '%s preserves raw thresholds and denies invalid counters',
    (_id, total, covered, verdict) => {
      const d = temp()
      for (const p of [
        'scripts/critical-coverage.mjs',
        'scripts/lib/coverage-gate.mjs',
        'scripts/critical-coverage-manifest.json'
      ]) {
        fs.mkdirSync(path.dirname(path.join(d, p)), { recursive: true })
        fs.copyFileSync(path.join(root, p), path.join(d, p))
      }
      fs.mkdirSync(path.join(d, 'certification'))
      const summary = Object.fromEntries(
        [...new Set(r10Critical.groups.flatMap((g) => g.paths))].map((p) => [
          p,
          metrics(total, covered)
        ])
      )
      summary.total = metrics(total, covered)
      r10Write(path.join(d, 'coverage/coverage-summary.json'), summary)
      const cli = r10Spawn(
        process.execPath,
        ['scripts/critical-coverage.mjs'],
        { cwd: d, encoding: 'utf8' }
      )
      expect(cli.error).toBeUndefined()
      expect(cli.status).toBe(verdict === 'PASS' ? 0 : 1)
      const report = JSON.parse(
        fs.readFileSync(path.join(d, 'certification/critical-coverage.json'))
      )
      expect(report.verdict).toBe(verdict)
      expect(report.global).toEqual(
        buildCoverageReport(summary, r10Critical).global
      )
      expect(report.critical).toEqual(
        buildCoverageReport(summary, r10Critical).critical
      )
      if (verdict === 'PASS')
        expect(() => snapshotSchema(report, 'coverage-critical')).not.toThrow()
      else expect(() => snapshotSchema(report, 'coverage-critical')).toThrow()
      if (total === 100000)
        expect(report.critical.groups[0].metrics.branches.pct).toBe(95)
    }
  )
  it.each(['statements', 'lines', 'functions', 'branches'])(
    'does not silently filter an invalid critical %s member',
    (dimension) => {
      const group = r10Critical.groups.find((g) => g.paths.length > 1)
      const summary = Object.fromEntries(
        [...new Set(r10Critical.groups.flatMap((g) => g.paths))].map((p) => [
          p,
          metrics(100, 100)
        ])
      )
      summary.total = metrics(100, 100)
      summary[group.paths[0]][dimension].covered = 101
      const report = buildCoverageReport(summary, r10Critical)
      expect(report.global.pass).toBe(true)
      expect(report.verdict).toBe('FAIL')
      expect(report.critical.failures).toContain(
        `critical_coverage_invalid:${group.id}:${dimension}`
      )
      expect(
        report.critical.groups.find((g) => g.id === group.id).metrics[dimension]
      ).toEqual({ total: null, covered: null, pct: null })
      summary.total[dimension].covered = 101
      expect(
        buildCoverageReport(summary, r10Critical).global.failures
      ).toContain(`coverage_global_invalid:${dimension}`)
    }
  )
  it('preserves weighted sums and zero-count erased files in a valid group', () => {
    const group = r10Critical.groups.find((g) => g.paths.length > 1)
    const summary = Object.fromEntries(
      [...new Set(r10Critical.groups.flatMap((g) => g.paths))].map((p) => [
        p,
        metrics(100, 100)
      ])
    )
    summary.total = metrics(1000, 1000)
    summary[group.paths[0]] = metrics(10, 0)
    summary[group.paths[1]] = metrics(990, 950)
    for (const p of group.paths.slice(2)) summary[p] = metrics(0, 0)
    const report = buildCoverageReport(summary, r10Critical)
    expect(report.verdict).toBe('PASS')
    expect(
      report.critical.groups.find((g) => g.id === group.id).metrics.branches
    ).toEqual({ total: 1000, covered: 950, pct: 95 })
  })
})

// Complete content bindings reach the real verifyScope unit predicate. Later
// snapshots are deliberately invalid, and no complete scope PASS is asserted.
function r10BoundScope(status, scopeId = 'harness-neutral', skipCount) {
  const d = temp(),
    s = r10Contract.scopes.find((s) => s.id === scopeId)
  const selected = [
    row('tests/r10-bound.test.js', 'same'),
    row('tests/r10-bound.test.js', 'same'),
    row('tests/r10-bound.test.js', 'other')
  ]
  const required = inventory(selected),
    report = native(selected)
  if (status !== 'passed') {
    report.testResults[0].assertionResults[2].status = status
    report.numPassedTests--
    report.numPendingTests = status === 'todo' ? 0 : 1
    report.numTodoTests = status === 'todo' ? 1 : 0
  }
  const executed =
    status === 'failed'
      ? inventory(selected).map((t) => ({ ...t, status: 'failed' }))
      : testReport(report, [selected[0].file], 'governed')
  const manifest = {
    schemaVersion: 1,
    contract: r10Version,
    contractHash: r10ContractHash,
    scope: s.id,
    owner: s.owner,
    candidateId: r10Hash,
    sourceSha256: r10Hash,
    sourceMatch: true,
    sourceAfterSha256: r10Hash,
    variantSourceMatch: true,
    variantSourceAfterSha256: r10Hash,
    runId: 'inert-r10-bound',
    attempt: '1',
    derivedVariantId: r10Hash,
    derivedMappingHash: r10Hash,
    ownerMappingHash: r10Hash,
    lockSha256: r10Hash,
    mode: 'LOCAL_CONTENT_HASHES',
    startedAt: '2026-10-05T00:00:00.000Z',
    finishedAt: '2026-10-05T00:00:01.000Z',
    versions: { node: process.versions.node },
    testInventory: required,
    testInventoryHash: r10Digest(required),
    testInventoryStatus: 'COLLECTED_NOT_EXECUTED',
    executedTestInventory: executed,
    executedTestInventoryHash: r10Digest(executed),
    coverage: { 'inert.ts': metrics(10, 10) },
    gates: [],
    seals: [],
    status: 'PASS'
  }
  for (const gate of s.gates) {
    const log = 'inert binding ' + gate.id + '\n',
      lp = 'gates/' + gate.id + '.log'
    fs.mkdirSync(path.dirname(path.join(d, lp)), { recursive: true })
    fs.writeFileSync(path.join(d, lp), log)
    const outputs = []
    for (const p of gate.artifacts ?? []) {
      const op = `gate-outputs/${gate.id}/${p}`
      r10Write(path.join(d, op), gate.id === 'unit' ? report : { inert: true })
      const b = fs.readFileSync(path.join(d, op))
      outputs.push({ path: op, sha256: r10Sha(b), size: b.length })
    }
    const entry = {
      schemaVersion: 1,
      id: gate.id,
      command: gate.command,
      status: 'PASS',
      exitCode: 0,
      cause: null,
      scope: s.id,
      runId: manifest.runId,
      candidateId: r10Hash,
      startedAt: manifest.startedAt,
      finishedAt: manifest.finishedAt,
      skipped:
        gate.id === 'unit' ? (skipCount ?? (status === 'passed' ? 0 : 1)) : 0,
      outputs,
      logSha256: r10Sha(log)
    }
    manifest.gates.push(entry)
    manifest.seals.push(r10Seal(manifest, entry))
  }
  manifest.outputs = r10Files(d)
  r10Write(path.join(d, 'manifest.json'), manifest)
  return {
    manifest,
    directory: d,
    expected: { ...manifest, requiredTestIds: required.map((t) => t.id) }
  }
}
describe('R10 native verifier unit policy parity', () => {
  it.each(['passed', 'pending', 'skipped', 'todo'])(
    'admits unit %s to the same later independent snapshot boundary',
    (status) => {
      const input = r10BoundScope(status)
      expect(() => r10VerifyScope(input)).toThrow(
        'hiso:postgres_version_binding'
      )
    }
  )
  it('rejects failed execution before the unrelated snapshot', () => {
    expect(() => r10VerifyScope(r10BoundScope('failed'))).toThrow(
      'hiso:unit_execution_status'
    )
  })
  it.each(['pending', 'skipped', 'todo'])(
    'preserves none policy and skipped-count binding for %s',
    (status) => {
      expect(() =>
        r10VerifyScope(r10BoundScope(status, 'shift-product', 0))
      ).toThrow('hiso:unit_execution_status')
      expect(() =>
        r10VerifyScope(r10BoundScope(status, 'harness-neutral', 0))
      ).toThrow('hiso:unit_execution_skip_count')
    }
  )
  it('still requires the separate skip-governance snapshot to pass', () => {
    expect(() =>
      verify('skip', {
        schemaVersion: 1,
        kind: 'aud20-skip-inventory',
        verdict: 'FAIL',
        failures: ['unapproved skip']
      })
    ).toThrow()
  })
})

it('R10 zero nonbranch counters remain valid in a branch-only critical group', () => {
  const entry = metrics(100, 95)
  for (const dimension of ['statements', 'lines', 'functions'])
    entry[dimension] = { total: 0, covered: 0, pct: null }
  const report = buildCoverageReport(
    { total: metrics(100, 95), 'zero-nonbranch.ts': entry },
    {
      branchThreshold: 95,
      groups: [{ id: 'only-branches', paths: ['zero-nonbranch.ts'] }]
    }
  )
  expect(report.critical.pass).toBe(true)
  expect(report.critical.failures).toEqual([])
  expect(report.critical.groups[0].metrics.functions).toEqual({
    total: 0,
    covered: 0,
    pct: null
  })
})

// R11: append-only native admission regressions; prior 182 cases stay byte exact.
const r11Summary = () => ({
  total: metrics(1000),
  ...Object.fromEntries(
    [...new Set(critical.groups.flatMap((g) => g.paths))].map((p) => [
      p,
      metrics(100)
    ])
  )
})
const r11Mutation = () => {
  const manifest = json('scripts/mutation-manifest.json')
  return {
    schemaVersion: 2,
    kind: 'aud21-risk-mutation-guard',
    contract: manifest.contract,
    runId: 'inert',
    candidateId: r10Hash,
    manifestSha256: r10Digest(manifest),
    selected: manifest.mutations.length,
    killed: manifest.mutations.length,
    survived: 0,
    timedOut: 0,
    errors: 0,
    domains: [...new Set(manifest.mutations.map((m) => m.domain))],
    mutations: manifest.mutations.map((m) => ({
      ...m,
      driver: undefined,
      testFiles: m.testFiles ?? [],
      status: 'KILLED',
      exitCode: 1,
      durationMs: 1
    })),
    verdict: 'PASS'
  }
}
describe('R11 critical metrics native admission', () => {
  it.each(['statements', 'lines', 'functions'])(
    'accepts safe zero group %s',
    (dimension) => {
      const summary = r11Summary()
      for (const p of critical.groups[0].paths)
        summary[p][dimension] = { total: 0, covered: 0, skipped: 0, pct: null }
      const report = buildCoverageReport(summary, critical)
      expect(report.verdict).toBe('PASS')
      expect(() => snapshotSchema(report, 'coverage-critical')).not.toThrow()
      expect(() => verify('coverage-critical', report)).not.toThrow()
      const forged = clone(report)
      forged.critical.groups[0].metrics[dimension].pct = 0
      expect(() => snapshotSchema(forged, 'coverage-critical')).toThrow()
    }
  )
  for (const dimension of ['statements', 'lines', 'functions', 'branches']) {
    it.each([-1, 0.5, 2 ** 53, '0', null])(
      'rejects malformed ' + dimension + ' skipped=%s',
      (value) => {
        const summary = r11Summary()
        summary[critical.groups[0].paths[0]][dimension].skipped = value
        const report = buildCoverageReport(summary, critical)
        expect(report.verdict).toBe('FAIL')
        expect(() => snapshotSchema(report, 'coverage-critical')).toThrow()
        const forged = buildCoverageReport(r11Summary(), critical)
        forged.critical.groups[0].files[0].metrics[dimension].skipped = value
        expect(() => snapshotSchema(forged, 'coverage-critical')).toThrow()
      }
    )
  }
  it.each(['omitted', 'zero', 'positive'])(
    'retains valid optional skipped %s',
    (kind) => {
      const summary = r11Summary()
      for (const entry of Object.values(summary))
        for (const v of Object.values(entry)) {
          if (kind === 'omitted') delete v.skipped
          else v.skipped = kind === 'positive' ? 1 : 0
        }
      const report = buildCoverageReport(summary, critical)
      expect(report.verdict).toBe('PASS')
      expect(() => snapshotSchema(report, 'coverage-critical')).not.toThrow()
    }
  )
  it('rejects mathematically below integer95 with unchanged public pct=95', () => {
    const summary = r11Summary(),
      group = critical.groups.find((g) => g.id === 'approval')
    const total = 9007199254700003,
      covered = 8556839291965002
    for (const p of group.paths)
      summary[p].branches = { total: 0, covered: 0, skipped: 0, pct: null }
    summary[group.paths[0]].branches = { total, covered, skipped: 0, pct: 95 }
    expect(BigInt(covered) * 100n < BigInt(total) * 95n).toBe(true)
    const report = buildCoverageReport(summary, critical)
    expect(report.verdict).toBe('FAIL')
    expect(
      report.critical.groups.find((g) => g.id === 'approval').metrics.branches
        .pct
    ).toBe(95)
    // Forging just producer PASS fields still cannot cross independent admission.
    report.verdict = 'PASS'
    report.failures = []
    report.critical.pass = true
    report.critical.failures = []
    expect(() => snapshotSchema(report, 'coverage-critical')).toThrow(
      'critical_coverage_raw_threshold:approval'
    )
  })
})
describe('R11 frozen mutation receipt authority', () => {
  it('admits every authoritative native source row', () =>
    expect(() => snapshotSchema(r11Mutation(), 'mutation')).not.toThrow())
  it.each([
    'manifestSha256',
    'domains',
    'omission',
    'duplicate',
    'sourceSha256',
    'source',
    'domain',
    'mode',
    'from',
    'to',
    'budgetMs',
    'testFiles'
  ])('refuses receipt-only %s changes', (field) => {
    const report = r11Mutation()
    if (field === 'manifestSha256') report.manifestSha256 = '0'.repeat(64)
    else if (field === 'domains') report.domains = ['coverage']
    else if (field === 'omission') {
      report.mutations.pop()
      report.selected--
      report.killed--
    } else if (field === 'duplicate')
      report.mutations[1] = clone(report.mutations[0])
    else if (field === 'budgetMs') report.mutations[0][field]++
    else if (field === 'testFiles')
      report.mutations[0][field] = ['tests/inert.test.js']
    else
      report.mutations[0][field] =
        field === 'sourceSha256' ? '0'.repeat(64) : 'inert changed'
    expect(() => snapshotSchema(report, 'mutation')).toThrow()
    expect(() => verify('mutation', report)).toThrow()
  })
  it('admits exact inventory in reordered rows/domains', () => {
    const report = r11Mutation()
    report.mutations.reverse()
    report.domains.reverse()
    expect(() => snapshotSchema(report, 'mutation')).not.toThrow()
  })
})
function r11Import(kind = 'passed', id = 'postgres') {
  const selected = [
    row('tests/r11-inert.test.js', 'same'),
    row('tests/r11-inert.test.js', 'same'),
    ...[...new Set([...postgres, ...chaos])].flatMap((p) => [
      row(p, 'same'),
      row(p, 'same')
    ])
  ]
  const required = inventory(selected)
  const report = native(selected)
  if (kind === 'governed unit') {
    report.testResults[0].assertionResults[0].status = 'pending'
    report.numPassedTests--
    report.numPendingTests = 1
  }
  const d = temp(),
    original = path.join(d, 'original'),
    out = path.join(d, 'out')
  const env = {
    ...process.env,
    GITHUB_RUN_ID: '777',
    GITHUB_RUN_ATTEMPT: '1',
    GITHUB_SHA: 'f'.repeat(40),
    GITHUB_REPOSITORY: 'synthetic/fixture',
    GITHUB_WORKFLOW: 'Inert R10 fixture',
    CI_RUN_ID: 'run-777-1',
    GITHUB_OUTPUT: path.join(d, 'step-output.txt'),
    HISO_PG_VERSION_OUTPUT: path.join(d, 'pg.json')
  }
  const github = r10Runner(env)
  const state = {
    runId: 'run-777-1',
    candidateId: r10Hash,
    nodeVersion: process.versions.node,
    gates: []
  }
  fs.mkdirSync(original)
  fs.writeFileSync(path.join(original, 'runtime.txt'), 'inert fixture\n')
  for (const gate of r10Gates.filter((g) => g.id !== 'artifacts')) {
    const log = 'inert fixture; no gate execution: ' + gate.id + '\n'
    const lp = 'gates/' + gate.id + '.log'
    fs.mkdirSync(path.dirname(path.join(original, lp)), { recursive: true })
    fs.writeFileSync(path.join(original, lp), log)
    const entry = {
      id: gate.id,
      status: 'PASS',
      exitCode: 0,
      runId: state.runId,
      candidateId: r10Hash,
      nodeVersion: state.nodeVersion,
      outputFailures: [],
      log: lp,
      logSha256: r10Sha(log)
    }
    let content = { inert: true }
    if (gate.id === 'unit') content = report
    if (['postgres', 'chaos'].includes(gate.id)) {
      const selection = selected.filter((r) =>
        gate.id === 'postgres'
          ? postgres.includes(r.file)
          : r.file.startsWith('packages/chaos/')
      )
      if (gate.id === id && kind === 'missing occurrence')
        selection.splice(0, 1)
      if (gate.id === id && kind === 'extra occurrence')
        selection.push(clone(selection[0]))
      if (gate.id === id && kind === 'renamed') selection[0].name = 'changed'
      content = native(selection)
      if (gate.id === id && ['pending', 'skipped', 'todo'].includes(kind)) {
        content.testResults[0].assertionResults[0].status = kind
        content.numPassedTests--
        content.numPendingTests = kind === 'todo' ? 0 : 1
        content.numTodoTests = kind === 'todo' ? 1 : 0
      }
    }
    for (const p of gate.artifacts ?? [])
      r10Write(path.join(original, 'gate-outputs', gate.id, p), content)
    if (gate.id === 'e2e')
      Object.assign(entry, {
        executionId: 'inert-execution',
        testCount: 1,
        testInventorySha256: r10Hash,
        artifactSha256: Object.fromEntries(
          gate.artifacts.map((p) => [
            p,
            r10Sha(
              fs.readFileSync(path.join(original, 'gate-outputs', gate.id, p))
            )
          ])
        )
      })
    state.gates.push(entry)
  }
  const steps = Object.fromEntries(
    r10Gates
      .filter((g) => g.id !== 'artifacts')
      .map((g) => [
        r10Step(g.id),
        {
          outcome: 'success',
          conclusion: 'success',
          outputs: {
            seal: r10EncodeSeal(
              r10CreateSeal({ id: g.id, state, artifactDir: original, github })
            )
          }
        }
      ])
  )
  expect(
    r10CheckSeals({ state, artifactDir: original, steps, github }).failures
  ).toEqual([])
  const candidate = r10Digest(r10Sources(root))
  const expected = {
    schemaVersion: 1,
    contract: r10Version,
    contractHash: r10ContractHash,
    candidateId: candidate,
    sourceSha256: candidate,
    ownerMappingHash: r10Hash,
    runId: state.runId,
    attempt: '1',
    sha: env.GITHUB_SHA,
    startedAt: '2026-10-05T00:00:00.000Z',
    coveragePaths: [],
    coverageSources: [],
    testInventory: required,
    scopes: {}
  }
  for (const s of r10Contract.scopes)
    expected.scopes[s.id] = {
      ...expected,
      scopes: undefined,
      scope: s.id,
      derivedVariantId: candidate,
      derivedMappingHash: r10Hash,
      lockSha256: r10Hash,
      testInventoryHash: r10Digest(required),
      requiredTestIds: required.map((t) => t.id)
    }
  const legacy = {
    verdict: 'PASS',
    provenance: { mode: 'GITHUB_STEP_OUTPUT_SEALED' },
    runId: state.runId,
    candidateId: r10Hash,
    npmVersion: 'inert',
    startedAt: expected.startedAt,
    gates: [...state.gates, { id: 'artifacts', status: 'PASS' }]
  }
  r10Write(path.join(original, 'ci-bar-state.json'), state)
  r10Write(path.join(original, 'ci-bar-manifest.json'), legacy)
  r10Write(path.join(d, 'expected.json'), expected)
  r10Write(env.HISO_PG_VERSION_OUTPUT, {
    schemaVersion: 1,
    status: 'PASS',
    version: 160000,
    runId: state.runId,
    candidateId: r10Hash
  })
  env.CI_BAR_STEPS_JSON = JSON.stringify(steps)
  env.LEGACY_MANIFEST_SHA256 = r10Sha(
    fs.readFileSync(path.join(original, 'ci-bar-manifest.json'))
  )
  const cli = r10Spawn(
    process.execPath,
    [
      'scripts/hiso-import-legacy.mjs',
      original,
      path.join(d, 'expected.json'),
      out
    ],
    { cwd: root, env, encoding: 'utf8' }
  )
  expect(cli.error).toBeUndefined()
  const manifest = JSON.parse(fs.readFileSync(path.join(out, 'manifest.json')))
  return { cli, manifest, out, required }
}

describe('R11 importer preflight required native reports', () => {
  it.each(['passed', 'governed unit'])(
    'keeps complete selectors and %s policy',
    (kind) => {
      const observed = r11Import(kind)
      expect(observed.cli.status).toBe(0)
      expect(observed.manifest.status).toBe('PASS')
      expect(observed.manifest.gates.find((g) => g.id === 'unit').skipped).toBe(
        kind === 'governed unit' ? 1 : 0
      )
      for (const id of ['postgres', 'chaos']) {
        const gate = r10Contract.scopes
          .find((s) => s.id === 'transition-regression')
          .gates.find((g) => g.id === id)
        expect(() =>
          verifySnapshots({
            gate,
            entry: observed.manifest.gates.find((g) => g.id === id),
            directory: observed.out,
            manifest: observed.manifest,
            expected: {}
          })
        ).not.toThrow()
      }
    }
  )
  for (const id of ['postgres', 'chaos'])
    it.each([
      'pending',
      'skipped',
      'todo',
      'missing occurrence',
      'extra occurrence',
      'renamed'
    ])('rejects ' + id + ' %s before all PASS copies', (kind) => {
      const observed = r11Import(kind, id)
      expect(observed.cli.status).toBe(1)
      expect(observed.manifest.status).toBe('FAIL')
      expect(r10Files(observed.out).map((f) => f.path)).toEqual([
        'import-failure.log',
        'manifest.json'
      ])
      expect(fs.existsSync(path.join(observed.out, 'legacy'))).toBe(false)
      expect(fs.existsSync(path.join(observed.out, 'gate-outputs'))).toBe(false)
    })
})
