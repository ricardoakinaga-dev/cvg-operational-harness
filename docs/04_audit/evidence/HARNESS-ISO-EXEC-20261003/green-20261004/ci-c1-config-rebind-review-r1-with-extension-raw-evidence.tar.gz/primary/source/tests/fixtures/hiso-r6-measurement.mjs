import fs from 'node:fs'
import path from 'node:path'
import { createRequire } from 'node:module'
import { contract, sha } from '../../scripts/hiso-contract.mjs'
import { rules, rulesHash } from '../../scripts/hiso-variant.mjs'

// Measurement fixtures preserve the exact seven real configs of each approved
// variant. A workspace name or a physically missing file cannot select a scope.
const frozen = JSON.parse(
  fs.readFileSync(new URL('./hiso-r6-projection.json', import.meta.url), 'utf8')
)
function check(condition, label) {
  if (!condition) throw new Error(`fixture_measurement:${label}`)
}
export function projectionMode(root) {
  check(rulesHash === frozen.rulesHash, 'rules_binding')
  const matches = ['retained', 'neutral'].filter((mode) =>
    frozen.configPaths.every(
      (p) =>
        fs.existsSync(path.join(root, p)) &&
        sha(fs.readFileSync(path.join(root, p))) === frozen[mode][p].sha256
    )
  )
  check(matches.length === 1, 'seven_config_binding')
  if (matches[0] === 'neutral')
    check(
      !fs.existsSync(path.join(root, 'products')),
      'physical_product_absence'
    )
  return matches[0]
}
export function expectedCoveragePaths(root, mode = projectionMode(root)) {
  projectionMode(root)
  check(['retained', 'neutral'].includes(mode), 'scope')
  const baseline = JSON.parse(
    fs.readFileSync(path.join(root, contract.baselineInventory.path), 'utf8')
  )
  const full = [...baseline.coveragePaths, ...baseline.newCoveragePaths].sort()
  check(full.length === 281 && new Set(full).size === 281, 'full_denominator')
  const paths =
    mode === 'retained'
      ? full
      : full.filter(
          (p) => !rules.removeTrees.some((tree) => p.startsWith(tree + '/'))
        )
  check(
    paths.length === (mode === 'retained' ? 281 : 250),
    'projected_denominator'
  )
  return paths
}
export function copyProjectionConfigs(
  root,
  target,
  mode = projectionMode(root)
) {
  projectionMode(root)
  check(
    rulesHash === frozen.rulesHash && ['retained', 'neutral'].includes(mode),
    'copy_rules_binding'
  )
  for (const p of frozen.configPaths) {
    const record = frozen[mode][p]
    check(sha(record.content) === record.sha256, `frozen_config:${p}`)
    const dest = path.join(target, p)
    fs.mkdirSync(path.dirname(dest), { recursive: true })
    fs.writeFileSync(dest, record.content)
  }
  const baselinePath = path.join(target, contract.baselineInventory.path)
  fs.mkdirSync(path.dirname(baselinePath), { recursive: true })
  fs.copyFileSync(
    path.join(root, contract.baselineInventory.path),
    baselinePath
  )
  const binding = {
    mode,
    rulesHash,
    configs: Object.fromEntries(
      frozen.configPaths.map((p) => [p, frozen[mode][p].sha256])
    )
  }
  fs.writeFileSync(
    path.join(target, 'hiso-fixture-projection.json'),
    JSON.stringify(binding, null, 2) + '\n'
  )
  return binding
}
export function linkPrivateParser(root, target) {
  // The same physical private dependencies supply the parser in both variants.
  // No provider, evaluator, worker, or fixture source is executed through this link.
  const deps = path.dirname(
    path.dirname(
      createRequire(path.join(root, 'package.json')).resolve(
        'typescript/package.json'
      )
    )
  )
  fs.symlinkSync(deps, path.join(target, 'node_modules'))
}

export function nativeEvalArtifact() {
  check(
    sha(frozen.nativeEvalArtifact.content) === frozen.nativeEvalArtifact.sha256,
    'native_eval_artifact_hash'
  )
  return JSON.parse(frozen.nativeEvalArtifact.content)
}
