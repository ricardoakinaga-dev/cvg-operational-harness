import fs from 'node:fs'
import path from 'node:path'
import { createRequire } from 'node:module'
import { spawnSync } from 'node:child_process'
import {
  contract,
  digest,
  exact,
  requireThat,
  safePath,
  sha,
  sourceFiles
} from './hiso-contract.mjs'
import { ownerMapping, rules, rulesHash } from './hiso-variant.mjs'

// Declarations retain source spans and exact hashes. Parameterized runtime cases
// are collected through the public Vitest runtime API, including skipped tasks;
// declarations and collection never claim execution.
export function declarationInventory(root, inputs = sourceFiles(root)) {
  const ts = createRequire(path.join(root, 'package.json'))('typescript')
  return ownerMapping(inputs).map((file) => {
    const text = fs.readFileSync(path.join(root, file.path), 'utf8')
    const ast = ts.createSourceFile(
      file.path,
      text,
      ts.ScriptTarget.Latest,
      true
    )
    const declarations = []
    const visit = (node) => {
      if (ts.isCallExpression(node)) {
        const expr = node.expression.getText(ast)
        if (/^(it|test)(\.|$)/.test(expr)) {
          const title = node.arguments[0]
          const pos = ast.getLineAndCharacterOfPosition(node.getStart(ast))
          declarations.push({
            id: `${file.path}:${pos.line + 1}:${pos.character + 1}`,
            expression: expr,
            title: title?.getText(ast) ?? null,
            start: node.getStart(ast),
            end: node.getEnd(),
            line: pos.line + 1
          })
        }
      }
      ts.forEachChild(node, visit)
    }
    visit(ast)
    return { ...file, declarations, kind: 'SOURCE_DECLARATIONS_NOT_EXECUTED' }
  })
}

function coveragePattern(pattern) {
  let r = ''
  for (let i = 0; i < pattern.length; i++) {
    const c = pattern[i]
    if (c === '*' && pattern[i + 1] === '*') {
      i++
      if (pattern[i + 1] === '/') {
        i++
        r += '(?:.*/)?'
      } else r += '.*'
    } else if (c === '*') r += '[^/]*'
    else if (c === '?') r += '[^/]'
    else r += c.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  }
  return new RegExp(`^${r}$`)
}
export function coverageInventory(root, inputs = sourceFiles(root)) {
  const ts = createRequire(path.join(root, 'package.json'))('typescript')
  const ast = ts.createSourceFile(
    'vitest.config.mts',
    fs.readFileSync(path.join(root, 'vitest.config.mts'), 'utf8'),
    ts.ScriptTarget.Latest,
    true
  )
  let coverage
  const visit = (n) => {
    if (ts.isPropertyAssignment(n) && n.name.getText(ast) === 'coverage')
      coverage = n.initializer
    ts.forEachChild(n, visit)
  }
  visit(ast)
  requireThat(
    coverage && ts.isObjectLiteralExpression(coverage),
    'coverage_config_literal'
  )
  const arr = (key) => {
    const p = coverage.properties.find(
      (p) => ts.isPropertyAssignment(p) && p.name.getText(ast) === key
    )
    requireThat(
      p && ts.isArrayLiteralExpression(p.initializer),
      `coverage_config_${key}`
    )
    return p.initializer.elements.map((n) => {
      requireThat(ts.isStringLiteral(n), 'coverage_pattern_literal')
      return n.text
    })
  }
  const include = arr('include').map(coveragePattern),
    exclude = arr('exclude').map(coveragePattern)
  return inputs
    .filter(
      (f) =>
        include.some((p) => p.test(f.path)) &&
        !exclude.some((p) => p.test(f.path))
    )
    .map((f) => f.path)
    .sort()
}
// Exact approved without-shift-v1 projection for the frozen CI-R6 producer.
// These fingerprints bind package/lock/TS/Vitest/policies together; changing a
// producer input requires an explicit projection rebind, never path discovery.
// The full retained/transition denominator below remains the default.
const neutralProjection = {
  rulesHash: 'bacdeb66cc4cf7c034f314297188da8694e37a9495ced6513870e54786cf8bfb',
  files: {
    'package.json':
      '5d302310a51af78b41175621dca52dca06468df7f809a65a343e043b8e4790fa',
    'package-lock.json':
      '3501d3677024ae7af019ec0ea30dd1bdd91b1d3895ec7dd3db34b6e0ccb580b2',
    'tsconfig.json':
      '87265d50269862cc6f3987903e489fbf3970444034b5156647e666c69617ee99',
    'tsconfig.typecheck.json':
      '7b19bf2e21a3a2e61681eb704ecc2067ade80766c972f5e8936d0db2b42934fd',
    'vitest.config.mts':
      '74288564ef6b5bc3c69d710e699b239c9c35b0ebc0d80a866db30e4791366134',
    'config/workspace-dependency-policy.json':
      '72d138365889175cf668b7ddf7971169a17185ab223745c6b420e9b509e9a433',
    'docs/doc-link-policy.json':
      '697ebdd3d7b1ea1be2a97d2a7fcd04b2a4959bee0be103debd497c1c5a167077'
  }
}
function approvedNeutralProjection(root) {
  return (
    rulesHash === neutralProjection.rulesHash &&
    !fs.existsSync(path.join(root, 'products')) &&
    Object.entries(neutralProjection.files).every(([p, hash]) => {
      const file = path.join(root, p)
      return (
        fs.existsSync(file) &&
        fs.lstatSync(file).isFile() &&
        !fs.lstatSync(file).isSymbolicLink() &&
        sha(fs.readFileSync(file)) === hash
      )
    })
  )
}
export function approvedCoverageInventory(root, inputs = sourceFiles(root)) {
  const actual = coverageInventory(root, inputs)
  const baseline = JSON.parse(
    fs.readFileSync(path.join(root, contract.baselineInventory.path), 'utf8')
  )
  const full = [...baseline.coveragePaths, ...baseline.newCoveragePaths]
  const expected = approvedNeutralProjection(root)
    ? full.filter(
        (p) => !rules.removeTrees.some((tree) => p.startsWith(tree + '/'))
      )
    : full
  exact(actual, expected, 'approved_coverage_source_inventory')
  for (const p of expected)
    requireThat(
      fs.existsSync(path.join(root, p)) &&
        fs.lstatSync(path.join(root, p)).isFile(),
      'approved_coverage_source_inventory'
    )
  return actual
}
// The historic denominator excludes top-level imports/reexports/empty statements
// in the emitted JS. Recognize only syntax with an unambiguous isolated emit;
// namespaces, import-equals, export assignments and other syntax retain the
// original compiler oracle. A runtime declaration never depends on other files.
function obviousExecution(ts, ast) {
  // Isolated compilation adds a strict-mode statement to global scripts, even
  // when every declaration is erased. Keep that emitter behavior (and .d.ts or
  // malformed-input behavior) with the original oracle rather than guessing.
  if (
    !ts.isExternalModule(ast) ||
    ast.isDeclarationFile ||
    ast.parseDiagnostics.length > 0
  )
    return null
  let unknown = false
  for (const s of ast.statements) {
    if (
      ts.isImportDeclaration(s) ||
      ts.isExportDeclaration(s) ||
      ts.isEmptyStatement(s) ||
      ts.isInterfaceDeclaration(s) ||
      ts.isTypeAliasDeclaration(s)
    )
      continue
    if (
      ts.getModifiers(s)?.some((m) => m.kind === ts.SyntaxKind.DeclareKeyword)
    )
      continue
    if (ts.isFunctionDeclaration(s)) {
      if (s.body) return true
      continue
    }
    if (
      ts.isVariableStatement(s) ||
      ts.isClassDeclaration(s) ||
      ts.isEnumDeclaration(s) ||
      ts.isExpressionStatement(s)
    )
      return true
    unknown = true
  }
  return unknown ? null : false
}
export function coverageSourceInventory(root, inputs = sourceFiles(root)) {
  const ts = createRequire(path.join(root, 'package.json'))('typescript')
  return approvedCoverageInventory(root, inputs).map((p) => {
    // Every invocation reads and hashes current bytes, even when the caller
    // reuses an old or frozen path inventory. Nothing is memoized across calls.
    const text = fs.readFileSync(path.join(root, p), 'utf8')
    const sourceAst = ts.createSourceFile(p, text, ts.ScriptTarget.Latest, true)
    const obvious = obviousExecution(ts, sourceAst)
    if (obvious !== null)
      return { path: p, sha256: sha(text), executable: obvious }
    const emitted = ts.transpileModule(text, {
      compilerOptions: {
        target: ts.ScriptTarget.ES2022,
        module: ts.ModuleKind.ESNext
      },
      fileName: p
    }).outputText
    const ast = ts.createSourceFile(p, emitted, ts.ScriptTarget.Latest, true)
    const executable = ast.statements.some(
      (s) =>
        !ts.isExportDeclaration(s) &&
        !ts.isImportDeclaration(s) &&
        !ts.isEmptyStatement(s)
    )
    return { path: p, sha256: sha(text), executable }
  })
}
export function reconcileMapping(before, after) {
  requireThat(before.length <= after.length, 'test_removed')
  for (const old of before) {
    const current = after.find((f) => f.path === old.path)
    requireThat(
      current && current.sha256 === old.sha256,
      'test_source_changed_or_removed'
    )
  }
  return {
    baselineCount: before.length,
    currentCount: after.length,
    added: after.filter((f) => !before.some((x) => x.path === f.path)),
    mappingHash: digest(after)
  }
}
export function caseOccurrences(rows) {
  const seen = new Map()
  return rows.map((row) => {
    safePath(row.file)
    requireThat(
      typeof row.name === 'string' && row.name.length > 0,
      'case_name'
    )
    const key = digest({ file: row.file, name: row.name }),
      occurrence = (seen.get(key) ?? 0) + 1
    seen.set(key, occurrence)
    return {
      ...row,
      occurrence,
      id: digest({ file: row.file, name: row.name, occurrence })
    }
  })
}

export function collectTestInventory(root, output, env) {
  const p = path.join(output, 'vitest-discovery.json')
  const fixtures = contract.discoveryInputs.map((p) => ({
    path: p,
    status: fs.existsSync(path.join(root, p)) ? 'PRESENT' : 'MISSING',
    sha256: fs.existsSync(path.join(root, p))
      ? sha(fs.readFileSync(path.join(root, p)))
      : null
  }))
  fs.writeFileSync(
    path.join(output, 'discovery-inputs.json'),
    JSON.stringify(fixtures, null, 2) + '\n'
  )
  for (const fixture of fixtures)
    if (fixture.status === 'PRESENT')
      requireThat(
        fixture.sha256 === contract.discoveryInputHashes[fixture.path],
        `immutable_discovery_input_changed:${fixture.path}`
      )
  if (fixtures.some((f) => f.status === 'MISSING')) {
    const cause =
      'required_test_input_missing:' +
      fixtures
        .filter((f) => f.status === 'MISSING')
        .map((f) => f.path)
        .join(',')
    fs.writeFileSync(path.join(output, 'vitest-discovery.log'), cause + '\n')
    fs.writeFileSync(
      path.join(output, 'vitest-discovery-command.json'),
      JSON.stringify(
        {
          command: [
            process.execPath,
            path.join(root, 'scripts/hiso-collect-tests.mjs'),
            p
          ],
          status: 'NOT_RUN',
          exitCode: null,
          cause,
          scope: 'COLLECTION_ONLY_NOT_TEST_EXECUTION'
        },
        null,
        2
      ) + '\n'
    )
    throw new Error('hiso:' + cause)
  }
  const r = spawnSync(
    process.execPath,
    [path.join(root, 'scripts/hiso-collect-tests.mjs'), p],
    {
      cwd: root,
      env,
      encoding: 'utf8',
      timeout: 300000,
      maxBuffer: 128 * 1024 * 1024
    }
  )
  fs.writeFileSync(
    path.join(output, 'vitest-discovery.log'),
    (r.stdout ?? '') + (r.stderr ?? '') + (r.error ? String(r.error) : '')
  )
  fs.writeFileSync(
    path.join(output, 'vitest-discovery-command.json'),
    JSON.stringify(
      {
        command: [
          process.execPath,
          path.join(root, 'scripts/hiso-collect-tests.mjs'),
          p
        ],
        exitCode: r.status,
        signal: r.signal,
        error: r.error?.code ?? null,
        scope: 'COLLECTION_ONLY_NOT_TEST_EXECUTION',
        timeoutMs: 300000
      },
      null,
      2
    ) + '\n'
  )
  requireThat(
    r.status === 0,
    `test_discovery_failed:${r.error?.code ?? r.status}`
  )
  const inventory = caseOccurrences(
    JSON.parse(fs.readFileSync(p, 'utf8')).map((t) => {
      const relative = path.relative(root, t.file).split(path.sep).join('/')
      requireThat(
        !relative.startsWith('../') && !path.isAbsolute(relative),
        'test_discovery_outside_source'
      )
      return {
        file: relative,
        name: t.name,
        kind: 'COLLECTED_NOT_EXECUTED'
      }
    })
  ).sort((a, b) => a.id.localeCompare(b.id))
  requireThat(
    inventory.length > 0 &&
      new Set(inventory.map((t) => t.id)).size === inventory.length,
    'test_discovery_duplicate_or_empty'
  )
  exact(
    [...new Set(inventory.map((t) => t.file))],
    ownerMapping(sourceFiles(root))
      .filter((f) => f.path.includes('.test.'))
      .map((f) => f.path),
    'complete_unit_test_source_inventory'
  )
  return inventory
}
