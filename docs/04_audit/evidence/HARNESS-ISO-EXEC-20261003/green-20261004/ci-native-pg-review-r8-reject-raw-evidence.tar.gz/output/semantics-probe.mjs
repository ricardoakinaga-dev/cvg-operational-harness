import fs from 'node:fs';import path from 'node:path';
import {snapshotSchema,testReport,gateTestReport,verifySnapshots} from './runtimecopy/scripts/hiso-reports.mjs';
import {validateReport} from './runtimecopy/scripts/hiso-ci.mjs';
import {caseOccurrences} from './runtimecopy/scripts/hiso-inventory.mjs';
import {buildCoverageReport} from './runtimecopy/scripts/lib/coverage-gate.mjs';
import {computeMetrics} from './runtimecopy/packages/agent-evals/src/metrics.ts';
import {CORE_EVAL_DATASET} from './runtimecopy/packages/agent-evals/src/datasets/core.ts';
const out=path.resolve(import.meta.dirname,'raw'),root=process.cwd(),rows=[];let serial=0;
const result=(label,fn,expected)=>{let error;try{fn()}catch(e){error=e.message}rows.push({label,expected,actual:error?'REJECT':'ACCEPT',error,conforms:expected===(error?'REJECT':'ACCEPT')})};
const clone=structuredClone;
const critical=JSON.parse(fs.readFileSync(path.join(root,'scripts/critical-coverage-manifest.json')));
const dims=['statements','lines','functions','branches'];const metric=(total=10,covered=total)=>Object.fromEntries(dims.map(k=>[k,{total,covered,skipped:0,pct:total?Number((100*covered/total).toFixed(2)):100}]));
function summary(total=10,covered=total){const s=Object.fromEntries(critical.groups.flatMap(g=>g.paths).map(p=>[p,metric(total,covered)]));s.total=metric(total*Object.keys(s).length,covered*Object.keys(s).length);return s}
function snap(gateId,report,inventory=[],expected={}){const d=path.join(out,'semantics-snapshots',String(++serial));fs.mkdirSync(d,{recursive:true});fs.writeFileSync(path.join(d,'report.json'),JSON.stringify(report));return verifySnapshots({gate:{id:gateId,skipPolicy:'none'},entry:{outputs:[{path:'report.json'}]},directory:d,manifest:{testInventory:inventory},expected})}
const rounded=buildCoverageReport(summary(100000,94999),critical);
fs.writeFileSync(path.join(out,'critical-rounded-native-report.json'),JSON.stringify(rounded,null,2));
rows.push({label:'critical rounded producer 94999/100000',expected:'FAIL',actual:rounded.verdict,rawPercent:94.999,displayPercent:rounded.critical.groups[0].metrics.branches.pct,conforms:rounded.verdict==='FAIL'});
result('critical rounded snapshot admission',()=>snapshotSchema(rounded,'coverage-critical'),'REJECT');
result('critical rounded snapshot verifier',()=>snap('coverage-critical',rounded),'REJECT');
const integer=buildCoverageReport(summary(),critical);result('critical integral native positive',()=>snapshotSchema(integer,'coverage-critical'),'ACCEPT');
const frac=buildCoverageReport(summary(10.5),critical);result('critical fractional native counters',()=>snapshotSchema(frac,'coverage-critical'),'REJECT');
const zero=summary();zero.total=metric(0);result('critical global zero counters',()=>snapshotSchema(buildCoverageReport(zero,critical),'coverage-critical'),'REJECT');
result('critical below 95 unrounded',()=>snapshotSchema(buildCoverageReport(summary(100000,94994),critical),'coverage-critical'),'REJECT');
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json')));const collected=caseOccurrences([{file:'tests/inert.test.js',name:'case',kind:'COLLECTED_NOT_EXECUTED'},{file:'tests/inert.test.js',name:'case',kind:'COLLECTED_NOT_EXECUTED'}]);
function native(r){return {success:true,numTotalTests:r.length,numPassedTests:r.length,numFailedTests:0,numFailedTestSuites:0,testResults:[...new Set(r.map(t=>t.file))].map(file=>({name:root+'/'+file,status:'passed',assertionResults:r.filter(t=>t.file===file).map(t=>({ancestorTitles:[],title:t.name,status:'passed'}))}))}}
function admission(id,report,inventory){const d=path.join(out,'producer-reports',String(++serial));fs.mkdirSync(d,{recursive:true});fs.writeFileSync(path.join(d,'report.json'),JSON.stringify(report));return validateReport({id,artifacts:['report.json'],skipPolicy:'none'},d,{},'',inventory)}
result('unit producer collected duplicate omission',()=>admission('unit',native(collected.slice(0,1)),collected),'REJECT');
const change=clone(collected);change[0].name='replacement';result('unit producer collected identity replacement',()=>admission('unit',native(change),collected),'REJECT');
const pg=pkg.scripts['test:postgres'].split(/\s+/).filter(t=>t.endsWith('.test.ts')).map(file=>({file,name:'case'}));const chaos=fs.readdirSync(path.join(root,'packages/chaos/src/__tests__')).filter(p=>p.endsWith('.test.ts')).map(file=>({file:'packages/chaos/src/__tests__/'+file,name:'case'}));
for(const [id,selected] of [['postgres',pg],['chaos',chaos]]){const inv=caseOccurrences([...selected,{...selected[0]}]);result(id+' multiplicity positive',()=>gateTestReport(native(inv),{id,skipPolicy:'none'},inv),'ACCEPT');for(const [label,cases] of [['omission',inv.slice(0,-1)],['identity',inv.map((r,i)=>i? r:{...r,name:'replacement'})],['extra', [...inv,{...inv[0]}]]]){result(id+' producer '+label,()=>admission(id,native(cases),inv),'REJECT');result(id+' snapshot '+label,()=>snap(id,native(cases),inv),'REJECT')}}
const thresholds=JSON.parse(fs.readFileSync(path.join(root,'packages/agent-evals/src/eval-thresholds.json')));
function evalReport(failedIds=[]){const results=CORE_EVAL_DATASET.map(t=>({success:!failedIds.includes(t.id),adversarial:t.adversarial,failures:failedIds.includes(t.id)?['intent_mismatch:inert']:[],outcome:{structuredValid:true,escalation:'handoff',proposedCapabilities:[],latencyMs:1,costUsd:0}}));return {suiteId:'phase10-core-v1',agentId:'inert-pure-metrics',startedAt:'2026-10-05T00:00:00.000Z',finishedAt:'2026-10-05T00:00:01.000Z',metrics:computeMetrics(results),thresholds,verdict:'PASS',failures:failedIds.map(scenarioId=>({scenarioId,reasons:['intent_mismatch:inert']}))}}
const perfect=evalReport();const ordinary=CORE_EVAL_DATASET.find(t=>!t.adversarial),adversarial=CORE_EVAL_DATASET.find(t=>t.adversarial);
result('eval pure native perfect',()=>snapshotSchema(perfect,'evals'),'ACCEPT');result('eval pure native tolerable ordinary failure',()=>snapshotSchema(evalReport([ordinary.id]),'evals'),'ACCEPT');
for(const [label,mut] of [['fractional numerator',r=>{r.metrics.schemaFailureRate=r.metrics.hallucinationRate=0.001}],['adversarial perfect contradictions',r=>r.metrics.adversarialPassRate=0.95],['missing metric',r=>delete r.metrics.scenarios],['threshold weakened',r=>r.thresholds.taskSuccessRate=0]]){const r=clone(perfect);mut(r);result('eval '+label,()=>snapshotSchema(r,'evals'),'REJECT')}
const generic=clone(perfect);generic.suiteId='unknown-core';generic.metrics.scenarios=100;generic.metrics.taskSuccessRate=1;result('eval unknown suite 100 scenario envelope',()=>snapshotSchema(generic,'evals'),'ACCEPT');
fs.writeFileSync(path.join(out,'semantic-probes.json'),JSON.stringify({kind:'INERT_JSON_AST_CONSTANTS_PURE_METRICS_ONLY',noEvaluatorOrAgentInstantiation:true,coreNativeScenarios:CORE_EVAL_DATASET.length,adversarialNativeScenarios:CORE_EVAL_DATASET.filter(t=>t.adversarial).length,rows},null,2));console.log(JSON.stringify(rows,null,2));
