import { describe, expect, it } from 'vitest'
import { parseVitestSummary } from '../scripts/lib/certification-rules.mjs'

describe('native certification summary terminal decorations', () => {
  it.each([
    ['Tests', 'Tests 5639 passed (5639)', 5639, 0, 0, 5639],
    ['Test Files', 'Test Files 410 passed (410)', 410, 0, 0, 410],
    ['Tests', 'Tests 2 passed | 1 failed | 3 skipped (6)', 2, 1, 3, 6],
    ['Tests', '   Tests 2 passed | 1 failed', 2, 1, 0, 3],
    [
      'Tests',
      '\u001b[2m      Tests \u001b[22m\u001b[1m\u001b[32m5639 passed\u001b[39m\u001b[22m\u001b[90m (5639)\u001b[39m',
      5639,
      0,
      0,
      5639
    ],
    [
      'Test Files',
      '\u001b[2m Test Files \u001b[22m\u001b[32m410 passed\u001b[39m (410)',
      410,
      0,
      0,
      410
    ],
    [
      'Tests',
      'Tests \u001b[32m2 passed\u001b[39m | \u001b[31m1 failed\u001b[39m | \u001b[33m3 skipped\u001b[39m \u001b[90m(6)\u001b[39m',
      2,
      1,
      3,
      6
    ],
    [
      'Tests',
      '\u001b[2m Tests\u001b[22m 2 \u001b[32mpassed\u001b[39m | 1 \u001b[31mfailed\u001b[39m',
      2,
      1,
      0,
      3
    ],
    ['Tests', '\u001b]0;vitest\u0007Tests 1 failed (1)', 0, 1, 0, 1],
    ['Tests', 'Tests 0 passed (0)', 0, 0, 0, 0],
    ['Tests', 'Tests 1 skipped (1)', 0, 0, 1, 1]
  ])(
    'preserves %s counts in %j',
    (label, line, passed, failed, skipped, total) => {
      expect(parseVitestSummary(`runner output\n${line}\n`, label)).toEqual({
        passed,
        failed,
        skipped,
        total
      })
    }
  )

  it.each(['', 'test output without a summary', 'Test Files 410 passed (410)'])(
    'retains null for missing Tests summary: %j',
    (log) => {
      expect(parseVitestSummary(log, 'Tests')).toBeNull()
    }
  )

  it('keeps first-summary semantics and separate file/test denominators', () => {
    const log =
      'Test Files 2 passed (2)\n\u001b[2m Tests\u001b[22m 3 passed | 1 failed (4)\nTests 999 passed (999)\n'
    expect(parseVitestSummary(log, 'Tests')).toEqual({
      passed: 3,
      failed: 1,
      skipped: 0,
      total: 4
    })
    expect(parseVitestSummary(log, 'Test Files')).toEqual({
      passed: 2,
      failed: 0,
      skipped: 0,
      total: 2
    })
  })

  it.each([
    ['ESC/BEL', '\u001b]0;Vitest controlled title\u0007'],
    ['ESC/ST', '\u001b]0;Vitest controlled title\u001b\\'],
    ['C1/ST', '\u009d0;Vitest controlled title\u009c'],
    ['C1/BEL', '\u009d0;Vitest controlled title\u0007'],
    ['empty', '\u001b]0;\u0007'],
    ['hyperlink', '\u001b]8;;https://example.invalid/with spaces\u001b\\']
  ])('preserves the first failing OSC-decorated summary: %s', (_, osc) => {
    const first = `${osc}Tests 1 failed (1)`
    const expected = { passed: 0, failed: 1, skipped: 0, total: 1 }
    expect(parseVitestSummary(first, 'Tests')).toEqual(expected)
    expect(
      parseVitestSummary(`${first}\nTests 999 passed (999)`, 'Tests')
    ).toEqual(expected)
  })

  it.each(['\u001b]0;unterminated', '\u009d0;unterminated'])(
    'refuses an unterminated OSC instead of selecting a later summary',
    (osc) => {
      expect(
        parseVitestSummary(`${osc}\nTests 999 passed (999)`, 'Tests')
      ).toBeNull()
    }
  )

  it.each(['\u001b]0;', '\u009d0;'])(
    'bounds repeated incomplete OSC scan time for prefix %j',
    (prefix) => {
      const log = `${prefix.repeat(65536)}\nTests 999 passed (999)`
      const start = performance.now()
      expect(parseVitestSummary(log, 'Tests')).toBeNull()
      expect(performance.now() - start).toBeLessThan(1000)
    }
  )

  it('retains summaries around adjacent complete OSC strings', () => {
    const log =
      '\u001b]0;first title\u0007\u009d8;;second title\u009cTests 1 failed (1)\u001b]0;final title\u001b\\\nTests 999 passed (999)'
    expect(parseVitestSummary(log, 'Tests')).toEqual({
      passed: 0,
      failed: 1,
      skipped: 0,
      total: 1
    })
  })
})
