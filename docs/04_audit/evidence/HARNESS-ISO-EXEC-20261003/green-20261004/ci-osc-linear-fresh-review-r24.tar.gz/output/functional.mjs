import fs from 'node:fs'
import { isDeepStrictEqual } from 'node:util'
import { createHash } from 'node:crypto'
import { parseVitestSummary as parse } from './parser.mjs'
import { parseVitestSummary as original } from './original-parser.mjs'
import { deriveGateOutcome, deriveGateMetrics, GATE_EVIDENCE_MATRIX, GATE_ENVIRONMENT_EVIDENCE_MATRIX } from './gate.mjs'
if (process.versions.node.split('.')[0] !== '22') throw new Error('Node22 required')
const max = 4194304, records = [], failures = []
function check(id,input,label,expected,fn=parse) {
 if(input.length>max || Buffer.byteLength(input)>8388608 || records.length>=10000) throw new Error('Declared bound exceeded')
 let actual, error
 try { actual=fn(input,label) } catch(e) {error=String(e.stack)}
 const pass=!error && isDeepStrictEqual(actual,expected)
 const row={id,input,label,expected,actual,error,pass}
 records.push(row)
 if(!pass) failures.push(row)
}
const zero={passed:0,failed:0,skipped:0,total:0}
const failed={passed:0,failed:1,skipped:0,total:1}
const good={passed:2,failed:0,skipped:0,total:2}
const mixed={passed:2,failed:1,skipped:3,total:6}
const introductions=['\x1b]','\x9d'], terminators=['\x07','\x1b\\','\x9c']
for(const label of ['Tests','Test Files']) {
 const first=`${label} 1 failed (1)`,later=`${label} 999 passed (999)`
 for(const intro of introductions) for(const term of terminators) {
  for(const title of ['','0;title with spaces','8;;https://example.invalid/space here',`0;\n${label} 999 passed (999)\n`, '0;\x1b[32mSGR\x1b[0m','0;\x1b]nested \x9d marker','0;emoji 🧪\r\n title']) {
   const osc=intro+title+term
   check(`complete-${JSON.stringify([label,intro,term,title])}`,osc+first+'\n'+later,label,failed)
   check(`suffix-${JSON.stringify([label,intro,term,title])}`,first+osc+'\n'+later,label,failed)
   check(`inside-label-${JSON.stringify([label,intro,term,title])}`,label.slice(0,2)+osc+label.slice(2)+' 1 failed (1)\n'+later,label,failed)
   check(`adjacent-${JSON.stringify([label,intro,term,title])}`,osc+osc+first+osc,label,failed)
  }
  check('swallowed-spoof-'+JSON.stringify([label,intro,term]),intro+`0;\n${label} 999 passed (999)\n`+term+first,label,failed)
  check('closed-only-'+JSON.stringify([label,intro,term]),intro+`0;\n${label} 999 passed (999)\n`+term,label,null)
 }
 for(const intro of introductions) for(const tail of ['', '0;unfinished','0;unfinished\x1b','0;\x1b[32m','0;\n'+later, '0;'+intro.repeat(100)]) {
  for(const prefix of ['',first+'\n',`${label} 2 passed (2)\n`])check('incomplete-'+JSON.stringify([label,intro,tail,prefix]),prefix+intro+tail,label,null)
 }
 check('C1-SGR-'+label,`\x9b2m ${label}\x9b22m 2 \x9b32mpassed\x9b0m | 1 failed | 3 skipped (6)`,label,mixed)
 check('ESC-SGR-token-'+label,`${label} \x1b[32m2 passed\x1b[0m | 1 failed | 3 skipped \x1b[90m(6)\x1b[0m`,label,mixed)
 check('count-duplicates-'+label,`${label} 2 passed | 3 passed | 1 failed | 4 skipped`,label,{passed:5,failed:1,skipped:4,total:10})
 check('explicit-total-'+label,`${label} 2 passed (90)`,label,{passed:2,failed:0,skipped:0,total:90})
 check('zero-'+label,`${label} 0 passed (0)`,label,zero)
 check('skipped-only-'+label,`${label} 3 skipped (3)`,label,{passed:0,failed:0,skipped:3,total:3})
 check('malformed-first-'+label,`${label} malformed\n${later}`,label,zero)
 check('missing-'+label,'runner output\nnothing',label,null)
 check('CRLF-'+label,`runner\r\n  ${first}\r\n${later}\r\n`,label,failed)
}
let state=0x724ac311
function rand(n) {state^=state<<13;state^=state>>>17;state^=state<<5;return (state>>>0)%n}
for(let i=0;i<2500;i++) {
 const label=i%2?'Tests':'Test Files',p=rand(5000),f=rand(4),s=rand(7),total=p+f+s
 const plain=`${label} ${p} passed | ${f} failed | ${s} skipped (${total})`
 let decorated=''
 for(const c of plain) {
  if(rand(5)===0)decorated+=introductions[rand(2)]+`0; controlled 🧪 title ${i}\n${label} 999 passed (999)\n`+terminators[rand(3)]
  if(rand(7)===0)decorated+='\x1b[32m'+c+'\x1b[0m';else decorated+=c
 }
 check(`generated-complete-${i}`,decorated+`\n${label} 999 passed (999)`,label,{passed:p,failed:f,skipped:s,total})
 const intro=introductions[rand(2)]
 check(`generated-incomplete-${i}`,plain+'\n'+intro+'0;'+intro.repeat(rand(50))+`\n${label} 999 passed (999)`,label,null)
}
for(let i=0;i<1000;i++) {
 const label=i%2?'Tests':'Test Files'
 const log=['runner output',' Test Files 3 passed (3)',`${label}${i%3?' ':': '} ${rand(100)} passed | ${rand(5)} failed | ${rand(9)} skipped${i%4?'':` (${rand(300)})`}`,`${label} 999 passed (999)`].join('\n')
 check(`R19-plain-differential-${i}`,log,label,original(log,label))
}
// Concrete old-parser counterexample retained; first failure must not disappear.
const oldFailureInput='\x1b]0;Controlled title with spaces\x07Tests 1 failed (1)\nTests 999 passed (999)'
records.push({id:'R19-known-bad-counterexample',input:oldFailureInput,label:'Tests',original:original(oldFailureInput,'Tests'),source:parse(oldFailureInput,'Tests'),expectedSource:failed,pass:isDeepStrictEqual(parse(oldFailureInput,'Tests'),failed)})
// The unmodified caller functions are extracted; only Vitest branch is invoked.
const sha=b=>createHash('sha256').update(b).digest('hex')
const rawReport=Buffer.from('{"synthetic":true}')
const inventory={kind:'aud20-skip-inventory',verdict:'PASS',runId:'own-synthetic',candidateId:'own-candidate',skips:[],failures:[],reports:[{path:'certification/unit-test-report.json',sha256:sha(rawReport)}],reportCountByGate:{unit:1,postgres:1,chaos:1,e2e:1},skippedTestsByGate:{unit:0,postgres:0,chaos:0,e2e:0},totals:{skippedTests:0}}
const artifacts=new Map([['certification/unit-test-report.json',rawReport],['certification/skip-inventory.json',Buffer.from(JSON.stringify(inventory))]])
const gateRecords=[]
function gateCheck(id,log,expectedPass,{entryId='postgres',exitCode=0,metrics,artifactReader=p=>artifacts.get(p),failureIncludes}={}) {
 const entry=GATE_EVIDENCE_MATRIX[entryId]??GATE_ENVIRONMENT_EVIDENCE_MATRIX[entryId]
 const derived=deriveGateMetrics(entryId,log)
 const actual=deriveGateOutcome({gate:{id:entryId,exitCode,metrics:metrics??derived},entry,artifactReader,log:Buffer.from(log),result:{runId:'own-synthetic',candidate:{candidateId:'own-candidate'}}})
 const pass=actual.pass===expectedPass && (!failureIncludes || actual.failures.includes(failureIncludes))
 const row={id,log,entryId,exitCode,derived,actual,expectedPass,failureIncludes,pass};gateRecords.push(row);if(!pass)failures.push(row)
}
const happy='\x1b]0;title with spaces\x07\x1b[2m Test Files\x1b[0m 1 passed (1)\n\x9d0;title with spaces\x9c Tests 2 passed (2)'
gateCheck('postgres-terminal-pass',happy,true)
gateCheck('unit-catalogued-terminal-pass',happy,true,{entryId:'unit'})
gateCheck('first-test-failure-no-fallback','Test Files 1 passed (1)\n\x1b]0;title with spaces\x07Tests 1 failed (1)\nTests 999 passed (999)',false,{failureIncludes:'gate_raw_failure:postgres'})
gateCheck('first-file-failure-no-fallback','\x9d0;title with spaces\x1b\\Test Files 1 failed (1)\nTest Files 999 passed (999)\nTests 2 passed (2)',false,{failureIncludes:'gate_raw_failure:postgres'})
gateCheck('unterminated-before', '\x1b]0;unterminated\nTest Files 1 passed (1)\nTests 2 passed (2)',false,{failureIncludes:'gate_inventory_unparsable:postgres'})
gateCheck('nested-intro-completed-by-first-BEL', '\x1b]0;unterminated\n'+happy,true)
gateCheck('unterminated-after',happy+'\n\x9d0;unterminated\nTests 999 passed (999)',false,{failureIncludes:'gate_inventory_unparsable:postgres'})
gateCheck('missing-tests','Test Files 1 passed (1)',false,{failureIncludes:'gate_inventory_unparsable:postgres'})
gateCheck('missing-files','Tests 2 passed (2)',false,{failureIncludes:'gate_inventory_unparsable:postgres'})
gateCheck('zero-tests','Test Files 1 passed (1)\nTests 0 passed (0)',false,{failureIncludes:'gate_raw_failure:postgres'})
gateCheck('nonzero-exit',happy,false,{exitCode:1,failureIncludes:'gate_raw_failure:postgres'})
gateCheck('mandatory-test-skip','Test Files 1 passed (1)\nTests 2 passed | 1 skipped (3)',false,{failureIncludes:'mandatory_skip:postgres:1'})
gateCheck('mandatory-file-skip','Test Files 1 passed | 1 skipped (2)\nTests 2 passed (2)',false,{failureIncludes:'mandatory_skip:postgres:1'})
gateCheck('metrics-mismatch',happy,false,{metrics:{...deriveGateMetrics('postgres',happy),testsPassed:999},failureIncludes:'gate_metrics_mismatch:postgres:testsPassed'})
gateCheck('unit-missing-catalog',happy,false,{entryId:'unit',artifactReader:()=>undefined,failureIncludes:'gate_result_artifact_missing:unit:certification/skip-inventory.json'})
gateCheck('unit-corrupt-report',happy,false,{entryId:'unit',artifactReader:p=>p.endsWith('unit-test-report.json')?Buffer.from('corrupt'):artifacts.get(p),failureIncludes:'skip_inventory_report_hash_mismatch:certification/unit-test-report.json'})
fs.writeFileSync('functional.raw.jsonl',records.map(r=>JSON.stringify(r)).join('\n')+'\n')
fs.writeFileSync('gate.raw.json',JSON.stringify(gateRecords,null,2)+'\n')
fs.writeFileSync('functional-failures.json',JSON.stringify(failures,null,2)+'\n')
const summary={node:process.version,seed:'0x724ac311',parserChecks:records.length,gateChecks:gateRecords.length,failures:failures.length,knownBadCounterexample:records.at(-1),maxObservedCodeUnits:Math.max(...records.map(r=>r.input.length)),maxAllowedCodeUnits:max}
fs.writeFileSync('functional-summary.json',JSON.stringify(summary,null,2)+'\n');console.log(JSON.stringify(summary));if(failures.length)process.exitCode=1
