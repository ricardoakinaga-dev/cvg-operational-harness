import { stripVTControlCharacters } from 'node:util'
export const visits = { outer: 0, inner: 0 }
export function parseVitestSummary(log, label) {
  // Node's terminal stripper leaves parts of OSC titles containing spaces.
  // Scan each OSC once: an unfinished string cannot yield evidence.
  visits.outer = 0
  visits.inner = 0
  const chunks = []
  let copiedUntil = 0
  for (let index = 0; index < log.length; index++) {
    visits.outer++
    const code = log.charCodeAt(index)
    const escOsc = code === 0x1b && log.charCodeAt(index + 1) === 0x5d
    if (code !== 0x9d && !escOsc) continue
    chunks.push(log.slice(copiedUntil, index))
    index += escOsc ? 2 : 1
    let complete = false
    for (; index < log.length; index++) {
      visits.inner++
      const current = log.charCodeAt(index)
      if (current === 0x07 || current === 0x9c) {
        index++
        complete = true
        break
      }
      if (current === 0x1b && log.charCodeAt(index + 1) === 0x5c) {
        index += 2
        complete = true
        break
      }
    }
    if (!complete) return null
    copiedUntil = index
    index--
  }
  chunks.push(log.slice(copiedUntil))
  const line = stripVTControlCharacters(chunks.join(''))
    .split('\n')
    .map((entry) => entry.trim())
    .find((entry) => entry.startsWith(label))
  if (!line) return null
  const counts = { passed: 0, failed: 0, skipped: 0 }
  for (const match of line.matchAll(/(\d+)\s+(passed|failed|skipped)/g)) {
    counts[match[2]] += Number(match[1])
  }
  const totalMatch = /\((\d+)\)\s*$/.exec(line)
  return {
    ...counts,
    total: totalMatch
      ? Number(totalMatch[1])
      : counts.passed + counts.failed + counts.skipped
  }
}
