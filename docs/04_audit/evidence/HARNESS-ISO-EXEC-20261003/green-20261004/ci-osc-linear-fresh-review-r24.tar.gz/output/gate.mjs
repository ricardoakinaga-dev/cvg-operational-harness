import { createHash } from 'node:crypto'
import { parseVitestSummary } from './parser.mjs'

export function parsePlaywrightSummary(log) {
  const counts = { passed: 0, failed: 0, skipped: 0, other: 0 }
  let found = false
  for (const line of log.split('\n')) {
    const trimmed = line.replace(/\u001b\[[0-9;]*[A-Za-z]/g, '').trim()
    const match =
      /^(\d+)\s+(passed|failed|skipped|flaky|interrupted|did not run)/.exec(
        trimmed
      )
    if (!match) continue
    found = true
    const value = Number(match[1])
    if (match[2] === 'passed') counts.passed += value
    else if (match[2] === 'failed') counts.failed += value
    else if (match[2] === 'skipped') counts.skipped += value
    else counts.other += value
  }
  return found ? counts : null
}

export function parseJson(reader, relativePath, failures, gateId) {
  const content = reader(relativePath)
  if (content === undefined) {
    failures.push(`gate_result_artifact_missing:${gateId}:${relativePath}`)
    return null
  }
  try {
    return JSON.parse(content.toString('utf8'))
  } catch {
    failures.push(`gate_result_artifact_invalid:${gateId}:${relativePath}`)
    return null
  }
}

export function sha256Bytes(content) {
  return createHash('sha256').update(content).digest('hex')
}

export function deriveGateOutcome({ gate, entry, artifactReader, log, result }) {
  const failures = []
  const text = log.toString('utf8')
  switch (entry.kind) {
    case 'exit_code':
      return { pass: gate.exitCode === 0, failures }
    case 'security': {
      const pass = gate.exitCode === 0 && /found 0 vulnerabilities/i.test(text)
      if (!pass) failures.push(`security_raw_failure:${gate.id}`)
      return { pass, failures }
    }
    case 'vitest':
    case 'playwright': {
      const summary =
        entry.kind === 'vitest'
          ? {
              files: parseVitestSummary(text, 'Test Files'),
              tests: parseVitestSummary(text, 'Tests')
            }
          : { files: parsePlaywrightSummary(text), tests: null }
      if (entry.kind === 'vitest' && (!summary.files || !summary.tests)) {
        failures.push(`gate_inventory_unparsable:${gate.id}`)
        return { pass: false, failures }
      }
      if (entry.kind === 'playwright' && !summary.files) {
        failures.push(`gate_inventory_unparsable:${gate.id}`)
        return { pass: false, failures }
      }
      const passed =
        entry.kind === 'vitest' ? summary.tests.passed : summary.files.passed
      const failed =
        entry.kind === 'vitest'
          ? summary.tests.failed + summary.files.failed
          : summary.files.failed + summary.files.other
      const skipped =
        entry.kind === 'vitest'
          ? summary.tests.skipped + summary.files.skipped
          : summary.files.skipped
      const rawPass = gate.exitCode === 0 && failed === 0 && passed > 0
      if (!rawPass) failures.push(`gate_raw_failure:${gate.id}`)
      const metrics = gate.metrics ?? {}
      const derivedMetrics =
        entry.kind === 'vitest'
          ? {
              filesPassed: summary.files.passed,
              filesFailed: summary.files.failed,
              filesSkipped: summary.files.skipped,
              testsPassed: summary.tests.passed,
              testsFailed: summary.tests.failed,
              testsSkipped: summary.tests.skipped
            }
          : {
              filesPassed: summary.files.passed,
              filesFailed: summary.files.failed + summary.files.other,
              filesSkipped: summary.files.skipped
            }
      for (const [key, value] of Object.entries(derivedMetrics)) {
        if (metrics[key] !== value) {
          failures.push(`gate_metrics_mismatch:${gate.id}:${key}`)
        }
      }
      if (entry.skipPolicy === 'catalogued') {
        const inventory = parseJson(
          artifactReader,
          'certification/skip-inventory.json',
          failures,
          gate.id
        )
        if (inventory) {
          failures.push(
            ...validateSkipInventory(inventory, {
              runId: result.runId,
              candidateId: result.candidate?.candidateId
            })
          )
          const inventoryReports = new Map(
            (inventory.reports ?? []).map((report) => [report.path, report])
          )
          const rawReportPath = 'certification/unit-test-report.json'
          if (!inventoryReports.has(rawReportPath)) {
            failures.push(`skip_inventory_report_missing:${rawReportPath}`)
          }
          for (const report of inventory.reports ?? []) {
            const content = artifactReader(report.path)
            if (content === undefined) {
              failures.push(`skip_inventory_report_missing:${report.path}`)
            } else if (sha256Bytes(content) !== report.sha256) {
              failures.push(
                `skip_inventory_report_hash_mismatch:${report.path}`
              )
            }
          }
        }
      }
      if (skipped > 0) {
        if (entry.skipPolicy === 'none') {
          failures.push(`mandatory_skip:${gate.id}:${skipped}`)
        } else if (
          entry.skipPolicy !== 'catalogued' &&
          !gate.skipJustification
        ) {
          failures.push(`undeclared_skips:${gate.id}`)
        }
      }
      if (entry.kind === 'playwright') {
        try {
          const proof = parseE2eEvidenceLog({
            logContent: text,
            expectedRunId: result.runId,
            expectedCandidateId: result.candidate?.candidateId,
            expectedTestCount: summary.files.passed
          })
          const pair = validateE2eReportPair({
            jsonContent: artifactReader('certification/e2e-test-report.json'),
            xmlContent: artifactReader('playwright-results.xml'),
            expectedRunId: result.runId,
            expectedCandidateId: result.candidate?.candidateId,
            expectedTestCount: summary.files.passed
          })
          if (
            pair.executionId !== proof.executionId ||
            gate.executionId !== proof.executionId
          ) {
            throw new Error('gate log/report execution mismatch')
          }
        } catch (error) {
          failures.push(
            `e2e_report_invalid:${error instanceof Error ? error.message : String(error)}`
          )
        }
      }
      return { pass: rawPass && failures.length === 0, failures }
    }
    case 'coverage': {
      const summary = parseJson(
        artifactReader,
        'coverage/coverage-summary.json',
        failures,
        gate.id
      )
      if (!summary) return { pass: false, failures }
      const total = summary.total
      if (!total || typeof total !== 'object') {
        failures.push(`coverage_totals_missing:${gate.id}`)
        return { pass: false, failures }
      }
      const metrics = gate.metrics ?? {}
      const declared = result.metrics?.coverage ?? {}
      let rawValid = true
      for (const key of ['statements', 'branches', 'functions', 'lines']) {
        const dimension = total[key]
        const rawPct = dimension?.pct
        if (!dimension || typeof dimension !== 'object') {
          failures.push(`coverage_raw_invalid:coverage:${key}:missing`)
          rawValid = false
          continue
        }
        if (!Number.isFinite(rawPct)) {
          failures.push(`coverage_raw_invalid:coverage:${key}:not_finite`)
          rawValid = false
          continue
        }
        if (rawPct < 0 || rawPct > 100) {
          failures.push(`coverage_raw_invalid:coverage:${key}:out_of_range`)
          rawValid = false
          continue
        }
        const fromGate = metrics[key]
        if (!isFinitePercentage(fromGate)) {
          failures.push(`coverage_gate_metrics_invalid:${key}`)
        } else if (Math.abs(fromGate - rawPct) > 0.01) {
          failures.push(`coverage_metrics_mismatch:${gate.id}:${key}`)
        }
        const fromResult = declared[key]
        if (!isFinitePercentage(fromResult)) {
          failures.push(`coverage_result_metrics_invalid:${key}`)
        } else if (Math.abs(fromResult - rawPct) > 0.01) {
          failures.push(`coverage_result_metrics_mismatch:${key}`)
        }
      }
      const globalContract = evaluateGlobalCoverage(summary)
      for (const failure of globalContract.failures) {
        failures.push(`coverage_contract_failure:${failure}`)
      }

      const evidencePaths = new Set(
        (gate.evidence ?? []).map((item) => item.path)
      )
      if (evidencePaths.has('certification/critical-coverage.json')) {
        const criticalReport = parseJson(
          artifactReader,
          'certification/critical-coverage.json',
          failures,
          gate.id
        )
        const criticalManifest = parseJson(
          artifactReader,
          'scripts/critical-coverage-manifest.json',
          failures,
          gate.id
        )
        if (criticalReport && criticalManifest) {
          const computed = evaluateCriticalCoverage(summary, criticalManifest)
          if (criticalReport.verdict !== (computed.pass ? 'PASS' : 'FAIL')) {
            failures.push('critical_coverage_report_verdict_mismatch')
          }
          if (criticalReport.critical?.threshold !== computed.threshold) {
            failures.push('critical_coverage_threshold_mismatch')
          }
          for (const group of computed.groups) {
            const reported = criticalReport.critical?.groups?.find(
              (candidate) => candidate.id === group.id
            )
            if (!reported) {
              failures.push(`critical_coverage_group_missing:${group.id}`)
              continue
            }
            if (
              JSON.stringify(reported.paths) !== JSON.stringify(group.paths) ||
              JSON.stringify(reported.missing) !==
                JSON.stringify(group.missing) ||
              reported.metrics?.branches?.pct !== group.metrics.branches.pct
            ) {
              failures.push(`critical_coverage_report_mismatch:${group.id}`)
            }
          }
          failures.push(...computed.failures)
        }
      }

      if (evidencePaths.has('certification/mutation-guard.json')) {
        const mutationReport = parseJson(
          artifactReader,
          'certification/mutation-guard.json',
          failures,
          gate.id
        )
        if (mutationReport) {
          if (!Array.isArray(mutationReport.mutations)) {
            failures.push('mutation_guard_invalid:mutations')
          }
          if (
            mutationReport.verdict !== 'PASS' ||
            mutationReport.survived !== 0 ||
            mutationReport.errors !== 0 ||
            mutationReport.killed !== mutationReport.selected ||
            mutationReport.selected <= 0
          ) {
            failures.push('mutation_guard_survived_or_incomplete')
          }
          for (const mutation of mutationReport.mutations ?? []) {
            if (mutation.status !== 'KILLED') {
              failures.push(
                `mutation_guard_not_killed:${mutation.id ?? 'unknown'}`
              )
            }
          }
        }
      }

      const pass =
        gate.exitCode === 0 &&
        rawValid &&
        globalContract.pass &&
        !failures.some(
          (failure) =>
            failure.startsWith('critical_coverage_') ||
            failure.startsWith('mutation_guard_')
        )
      if (!pass) failures.push(`gate_raw_failure:${gate.id}`)
      return { pass, failures }
    }
    case 'evals': {
      const report = parseJson(
        artifactReader,
        'certification/agent-eval-report.json',
        failures,
        gate.id
      )
      if (!report) return { pass: false, failures }
      const normativeThresholds = parseJson(
        artifactReader,
        EVAL_THRESHOLD_PATH,
        failures,
        gate.id
      )
      if (!normativeThresholds) return { pass: false, failures }
      const metrics = report.metrics ?? {}
      const thresholds = report.thresholds ?? {}
      const violations = []
      let rawValid = true
      if (!Number.isInteger(metrics.scenarios) || metrics.scenarios <= 0) {
        failures.push('evals_raw_invalid:scenarios')
        rawValid = false
        violations.push('scenarios')
      }
      const rateComparisons = [
        ['taskSuccessRate', 'taskSuccessRate', 'min'],
        ['policyViolationRate', 'policyViolationRate', 'max'],
        ['unsafeActionRate', 'unsafeActionRate', 'max'],
        ['schemaFailureRate', 'schemaFailureRate', 'max'],
        ['adversarialPassRate', 'adversarialPassRate', 'min']
      ]
      for (const [metric, thresholdKey, direction] of rateComparisons) {
        const value = metrics[metric]
        if (!isFiniteRate(value)) {
          failures.push(`evals_raw_invalid:${metric}`)
          rawValid = false
          violations.push(metric)
          continue
        }
        const threshold = thresholds[thresholdKey]
        const normativeThreshold = normativeThresholds[thresholdKey]
        if (!isFiniteRate(threshold)) {
          failures.push(`evals_raw_invalid:threshold:${thresholdKey}`)
          rawValid = false
          violations.push(metric)
          continue
        }
        if (
          !isFiniteRate(normativeThreshold) ||
          Math.abs(threshold - normativeThreshold) > Number.EPSILON
        ) {
          failures.push(`evals_threshold_mismatch:${thresholdKey}`)
          rawValid = false
          violations.push(metric)
          continue
        }
        if (direction === 'min') {
          if (!(value >= threshold)) violations.push(metric)
        } else if (!(value <= threshold)) {
          violations.push(metric)
        }
      }
      if (metrics.humanEscalationAccuracy !== undefined) {
        if (!isFiniteRate(metrics.humanEscalationAccuracy)) {
          failures.push('evals_raw_invalid:humanEscalationAccuracy')
          rawValid = false
          violations.push('humanEscalationAccuracy')
        } else {
          const threshold = thresholds.escalationAccuracy
          const normativeThreshold = normativeThresholds.escalationAccuracy
          if (!isFiniteRate(threshold)) {
            failures.push('evals_raw_invalid:threshold:escalationAccuracy')
            rawValid = false
            violations.push('humanEscalationAccuracy')
          } else if (
            !isFiniteRate(normativeThreshold) ||
            Math.abs(threshold - normativeThreshold) > Number.EPSILON
          ) {
            failures.push('evals_threshold_mismatch:escalationAccuracy')
            rawValid = false
            violations.push('humanEscalationAccuracy')
          } else if (!(metrics.humanEscalationAccuracy >= threshold)) {
            violations.push('humanEscalationAccuracy')
          }
        }
      }
      const derivedVerdict = violations.length === 0 ? 'PASS' : 'FAIL'
      if (report.verdict !== derivedVerdict) {
        failures.push(
          `evals_verdict_mismatch:${report.verdict ?? 'missing'}:${derivedVerdict}`
        )
      }
      const declaredVerdict = result.metrics?.evals?.verdict
      if (declaredVerdict && declaredVerdict !== derivedVerdict) {
        failures.push(`evals_result_verdict_mismatch:${declaredVerdict}`)
      }
      return {
        pass: gate.exitCode === 0 && rawValid && derivedVerdict === 'PASS',
        failures
      }
    }
    case 'chaos': {
      const report = parseJson(
        artifactReader,
        'certification/chaos-report.json',
        failures,
        gate.id
      )
      if (!report) return { pass: false, failures }
      if (!Array.isArray(report.testResults)) {
        failures.push('chaos_raw_invalid:test_results')
        return { pass: false, failures }
      }
      const supportedStatuses = new Set(CHAOS_STATUSES)
      const scenarioStatuses = new Map()
      let malformed = false
      for (const file of report.testResults) {
        if (!Array.isArray(file?.assertionResults)) {
          failures.push('chaos_raw_invalid:assertion_results')
          malformed = true
          continue
        }
        for (const assertion of file.assertionResults) {
          const match = /CHAOS-\d{2}/.exec(assertion?.title ?? '')
          if (!match) continue
          const id = match[0]
          const status = assertion?.status
          if (!CHAOS_SCENARIOS.includes(id)) {
            failures.push(`chaos_raw_invalid:unknown_scenario:${id}`)
            malformed = true
            continue
          }
          if (!supportedStatuses.has(status)) {
            failures.push(
              `chaos_raw_invalid:unknown_status:${id}:${status ?? 'missing'}`
            )
            malformed = true
            continue
          }
          const existing = scenarioStatuses.get(id)
          if (existing) {
            existing.duplicates.push(status)
            if (status === 'failed' || existing.status === 'failed') {
              existing.status = 'failed'
            }
            failures.push(`chaos_raw_invalid:duplicate:${id}`)
            malformed = true
            continue
          }
          scenarioStatuses.set(id, { status, duplicates: [] })
        }
      }
      let executed = 0
      let passed = 0
      let failed = 0
      let notExecuted = 0
      const countScenario = (id, entry) => {
        if (entry.status === 'passed') {
          executed += 1
          passed += 1
          return
        }
        if (entry.status === 'failed') {
          executed += 1
          failed += 1
          return
        }
        notExecuted += 1
      }
      for (const id of CHAOS_REQUIRED_SCENARIOS) {
        const entry = scenarioStatuses.get(id)
        if (!entry) {
          failures.push(`chaos_raw_invalid:missing:${id}`)
          failures.push(`chaos_required_not_passed:${id}`)
          malformed = true
          continue
        }
        countScenario(id, entry)
        if (entry.status !== 'passed') {
          failures.push(`chaos_required_not_passed:${id}`)
          if (CHAOS_NON_EXECUTED_STATUSES.includes(entry.status)) {
            failures.push(
              `chaos_raw_invalid:not_executed:${id}:${entry.status}`
            )
            malformed = true
          }
        }
      }
      for (const id of CHAOS_OPTIONAL_SCENARIOS) {
        const entry = scenarioStatuses.get(id)
        if (!entry) continue
        countScenario(id, entry)
        if (entry.status === 'failed') failures.push(`chaos_failed:${id}`)
      }
      if (passed === 0) {
        failures.push('chaos_raw_invalid:zero_passed')
        malformed = true
      }
      if (
        failed > 0 &&
        !failures.some((item) => item.startsWith('chaos_failed'))
      ) {
        failures.push(`chaos_failed:${failed}`)
      }
      if (executed < CHAOS_REQUIRED_SCENARIOS.length) {
        failures.push(`chaos_below_minimum:${executed}`)
      }
      const declared = result.metrics?.chaos ?? {}
      const derived = { executed, passed, failed, notExecuted }
      for (const key of Object.keys(derived)) {
        if (declared[key] !== undefined && declared[key] !== derived[key]) {
          failures.push(`chaos_metrics_mismatch:${key}`)
        }
      }
      const pass =
        gate.exitCode === 0 &&
        !malformed &&
        failed === 0 &&
        passed >= CHAOS_REQUIRED_SCENARIOS.length &&
        executed >= CHAOS_REQUIRED_SCENARIOS.length
      return { pass, failures }
    }
    case 'load': {
      const report = parseJson(
        artifactReader,
        'certification/load-report.json',
        failures,
        gate.id
      )
      if (!report) return { pass: false, failures }
      let rawValid = true
      for (const field of ['events', 'processed', 'loss', 'duplicates']) {
        if (!isNonNegativeInteger(report[field])) {
          failures.push(`load_raw_invalid:${field}`)
          rawValid = false
        }
      }
      const pass =
        rawValid &&
        report.events > 0 &&
        report.processed === report.events &&
        report.loss === 0 &&
        report.duplicates === 0
      if (!pass) failures.push(`load_inconsistent:${gate.id}`)
      const declared = result.metrics?.load ?? {}
      if (declared.loss !== undefined && declared.loss !== report.loss) {
        failures.push('load_metrics_mismatch:loss')
      }
      if (
        declared.duplicates !== undefined &&
        declared.duplicates !== report.duplicates
      ) {
        failures.push('load_metrics_mismatch:duplicates')
      }
      return { pass: gate.exitCode === 0 && pass, failures }
    }
    case 'restore': {
      const report = parseJson(
        artifactReader,
        'certification/restore-report.json',
        failures,
        gate.id
      )
      if (!report) return { pass: false, failures }
      const digestOk = report.integrity?.digestMatches === true
      if (!digestOk) failures.push(`restore_integrity_failed:${gate.id}`)
      const numericOk =
        Number.isFinite(report.restoreMs) && report.restoreMs >= 0
      if (!numericOk) failures.push('restore_raw_invalid:restoreMs')
      const pass = digestOk && numericOk
      const declared = result.metrics?.restore ?? {}
      if (
        declared.integrity?.digestMatches !== undefined &&
        declared.integrity.digestMatches !== report.integrity?.digestMatches
      ) {
        failures.push('restore_metrics_mismatch:digestMatches')
      }
      return { pass: gate.exitCode === 0 && pass, failures }
    }
    case 'sbom': {
      const report = parseJson(
        artifactReader,
        'certification/sbom.cyclonedx.json',
        failures,
        gate.id
      )
      if (!report) return { pass: false, failures }
      const pass =
        report.bomFormat === 'CycloneDX' &&
        Array.isArray(report.components) &&
        report.components.length > 0
      if (!pass) failures.push(`sbom_invalid:${gate.id}`)
      return { pass: gate.exitCode === 0 && pass, failures }
    }
    case 'licenses': {
      const report = parseJson(
        artifactReader,
        'certification/license-report.json',
        failures,
        gate.id
      )
      if (!report) return { pass: false, failures }
      let rawValid = true
      for (const field of ['total', 'deniedCount', 'unknownCount']) {
        if (!isNonNegativeInteger(report[field])) {
          failures.push(`licenses_raw_invalid:${field}`)
          rawValid = false
        }
      }
      if (
        report.unclassifiedCount !== undefined &&
        !isNonNegativeInteger(report.unclassifiedCount)
      ) {
        failures.push('licenses_raw_invalid:unclassifiedCount')
        rawValid = false
      }
      const pass =
        rawValid &&
        report.total > 0 &&
        report.deniedCount === 0 &&
        report.unknownCount === 0 &&
        (report.unclassifiedCount ?? 0) === 0
      if (!pass) failures.push(`licenses_unresolved:${gate.id}`)
      return { pass: gate.exitCode === 0 && pass, failures }
    }
    default:
      failures.push(`unknown_gate_kind:${gate.id}`)
      return { pass: false, failures }
  }
}

export function validateSkipInventory(inventory, { runId, candidateId } = {}) {
  const failures = []
  if (!inventory || inventory.kind !== 'aud20-skip-inventory') {
    failures.push('skip_inventory_invalid')
  } else {
    if (inventory.verdict !== 'PASS') failures.push('skip_inventory_not_pass')
    if (runId && inventory.runId !== runId)
      failures.push('skip_inventory_run_mismatch')
    if (candidateId && inventory.candidateId !== candidateId)
      failures.push('skip_inventory_candidate_mismatch')
    if (!Array.isArray(inventory.skips))
      failures.push('skip_inventory_rows_missing')
    if (!Array.isArray(inventory.failures))
      failures.push('skip_inventory_failures_missing')
    if (!Array.isArray(inventory.reports))
      failures.push('skip_inventory_reports_missing')
    for (const gate of REQUIRED_REPORT_GATES) {
      if (inventory.reportCountByGate?.[gate] !== 1) {
        failures.push(`skip_inventory_report_gate_missing:${gate}`)
      }
      if (typeof inventory.skippedTestsByGate?.[gate] !== 'number') {
        failures.push(`skip_inventory_gate_count_missing:${gate}`)
      }
    }
    const ids = new Set()
    for (const row of inventory.skips ?? []) {
      for (const field of [
        'id',
        'file',
        'test',
        'reason',
        'owner',
        'dedicatedGate'
      ]) {
        if (!row[field])
          failures.push(`skip_inventory_metadata_missing:${field}`)
      }
      if (row.id && ids.has(row.id))
        failures.push(`skip_inventory_duplicate_id:${row.id}`)
      if (row.id) ids.add(row.id)
      if (!Array.isArray(row.observedGates) || row.observedGates.length === 0)
        failures.push(
          `skip_inventory_observed_gate_missing:${row.id ?? 'missing'}`
        )
    }
    if (
      inventory.totals?.skippedTests !== undefined &&
      inventory.totals.skippedTests !== (inventory.skips ?? []).length
    ) {
      failures.push('skip_inventory_total_mismatch')
    }
  }
  return [...new Set(failures)].sort()
}

export const REQUIRED_REPORT_GATES = ['unit', 'postgres', 'chaos', 'e2e']

export const GATE_EVIDENCE_MATRIX = {
  format: { log: 'certification/logs/format.log', kind: 'exit_code' },
  typecheck: { log: 'certification/logs/typecheck.log', kind: 'exit_code' },
  lint: { log: 'certification/logs/lint.log', kind: 'exit_code' },
  build: { log: 'certification/logs/build.log', kind: 'exit_code' },
  unit: {
    log: 'certification/logs/unit.log',
    kind: 'vitest',
    results: [
      'certification/unit-test-report.json',
      'certification/skip-inventory.json'
    ],
    skipPolicy: 'catalogued'
  },
  coverage: {
    log: 'certification/logs/coverage.log',
    kind: 'coverage',
    results: ['coverage/coverage-summary.json']
  },
  security: { log: 'certification/logs/security.log', kind: 'security' },
  worker_startup: {
    log: 'certification/logs/worker_startup.log',
    kind: 'exit_code'
  },
  e2e: {
    log: 'certification/logs/e2e.log',
    results: ['certification/e2e-test-report.json', 'playwright-results.xml'],
    kind: 'playwright',
    skipPolicy: 'none'
  },
  evals: {
    log: 'certification/logs/evals.log',
    kind: 'evals',
    results: ['certification/agent-eval-report.json']
  },
  chaos: {
    log: 'certification/logs/chaos.log',
    kind: 'chaos',
    results: ['certification/chaos-report.json']
  },
  load: {
    log: 'certification/logs/load.log',
    kind: 'load',
    results: ['certification/load-report.json']
  },
  restore: {
    log: 'certification/logs/restore.log',
    kind: 'restore',
    results: ['certification/restore-report.json']
  },
  sbom: {
    log: 'certification/logs/sbom.log',
    kind: 'sbom',
    results: ['certification/sbom.cyclonedx.json']
  },
  licenses: {
    log: 'certification/logs/licenses.log',
    kind: 'licenses',
    results: ['certification/license-report.json']
  }
}

export const GATE_ENVIRONMENT_EVIDENCE_MATRIX = {
  postgres: {
    log: 'certification/logs/postgres.log',
    kind: 'vitest',
    results: ['certification/postgres-test-report.json'],
    skipPolicy: 'none',
    optional: true
  }
}

export function deriveGateMetrics(entryId, logContent) {
  const entry =
    GATE_EVIDENCE_MATRIX[entryId] ?? GATE_ENVIRONMENT_EVIDENCE_MATRIX[entryId]
  if (!entry) return undefined
  if (entry.kind === 'vitest') {
    const files = parseVitestSummary(logContent, 'Test Files')
    const tests = parseVitestSummary(logContent, 'Tests')
    if (!files || !tests) return undefined
    return {
      filesPassed: files.passed,
      filesFailed: files.failed,
      filesSkipped: files.skipped,
      testsPassed: tests.passed,
      testsFailed: tests.failed,
      testsSkipped: tests.skipped
    }
  }
  if (entry.kind === 'playwright') {
    const files = parsePlaywrightSummary(logContent)
    if (!files) return undefined
    return {
      filesPassed: files.passed,
      filesFailed: files.failed + files.other,
      filesSkipped: files.skipped
    }
  }
  if (entry.kind === 'coverage') return readCoverage() ?? undefined
  return undefined
}
