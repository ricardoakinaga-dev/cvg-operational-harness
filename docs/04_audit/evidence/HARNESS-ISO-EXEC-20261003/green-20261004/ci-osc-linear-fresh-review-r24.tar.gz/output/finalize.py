import pathlib,json,hashlib,subprocess,datetime
out=pathlib.Path(__file__).resolve().parent;base=out.parent.parent
roots={'source':base/'candidate-ci-linear-r24','original':base/'candidate-final-r19'}
def sha(b):return hashlib.sha256(b).hexdigest()
inv=json.loads((out/'immutable-before.json').read_text());after={};drift=[]
for key,entries in inv.items():
 after[key]={}
 for n,prev in entries.items():
  p=roots[key]/n
  now={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} if p.is_file() else None
  after[key][n]=now
  if prev!=now:drift.append({'root':key,'path':n,'before':prev,'after':now})
(out/'immutable-after.json').write_text(json.dumps(after,indent=2)+'\n')
external=json.loads((out/'external-before.json').read_text());extAfter={}
for n,prev in external.items():
 p=pathlib.Path(n);now={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size};extAfter[n]=now
 if prev!=now:drift.append({'external':n,'before':prev,'after':now})
(out/'external-after.json').write_text(json.dumps(extAfter,indent=2)+'\n')
# Detect untracked nonignored source/config additions beyond the initial inventory.
extras={}
for key,root in roots.items():
 names=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=root).decode().split('\0')
 extras[key]=[]
 for n in names:
  parts=pathlib.PurePosixPath(n).parts
  if not n or n.endswith(('AGENTS.md','.tsbuildinfo','vite-env.d.ts')) or n.startswith(('docs/','.gauntlet/','.agent/','certification/','coverage/')) or any(x in ('node_modules','dist','build','.vite','.cache') for x in parts):continue
  if pathlib.PurePosixPath(n).name.startswith('.env') and n!='.env.example':continue
  p=root/n
  if p.is_file() and n not in inv[key]:extras[key].append({'path':n,'sha256':sha(p.read_bytes())})
assert not any(extras.values()),extras
copies=[]
for c in json.loads((out/'delta.json').read_text()):
 p=out/'copies'/c['path']; digest=sha(p.read_bytes()); assert digest==c['source']['sha256']; assert not (roots['source']/c['path']).is_symlink()
 copies.append({'path':c['path'],'sha256':digest,'bytes':p.stat().st_size})
(out/'scanner-scope.json').write_text(json.dumps({'files':copies,'fileCount':len(copies),'totalBytes':sum(x['bytes'] for x in copies),'scannerVersion':'8.28.0','argv':['dir','copies','--config',str(base/'security-final-scans-r19/tools/strict-default.toml'),'--gitleaks-ignore-path',str(base/'security-final-scans-r19/tools/empty.gitleaksignore'),'--ignore-gitleaks-allow','--redact=100','--no-banner','--no-color','--report-format','json','--report-path','gitleaks.json'],'environment':'env -i PATH=/usr/bin:/bin LANG=C.UTF-8','timeoutSeconds':45,'noBaseline':True,'ignoreFileBytes':0,'defaultRules':True,'exitStatus':int((out/'gitleaks.exit.txt').read_text()),'findings':len(json.loads((out/'gitleaks.json').read_text()))},indent=2)+'\n')
# Caller extraction is exactly the original unchanged function body.
import re
binding=json.loads((out/'sourcebindings.json').read_text())
for row in binding:
 if row['function'] in ['deriveGateOutcome','deriveGateMetrics']:
  text=(roots['original']/row['path']).read_text();start=re.search(r'^(?:export )?function '+re.escape(row['function'])+r'\(',text,re.M).start();end=text.index('\n}\n',start)+3
  row['unchangedBodyVsR19']=sha(text[start:end].encode())==row['extractedSha256'];assert row['unchangedBodyVsR19']
(out/'sourcebindings.json').write_text(json.dumps(binding,indent=2)+'\n')
status={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceFiles':len(inv['source']),'originalFiles':len(inv['original']),'externalFiles':len(external),'immutableDrift':drift,'untrackedSourceOutsideInventory':extras,'fiveCopiesMatchSourceBefore':True,'sourceUntouched':not drift,'generatedCachesExcluded':True,'rootGovernanceAndPriorReviewsRead':False}
(out/'integrity.json').write_text(json.dumps(status,indent=2)+'\n')
assert not drift,drift
functional=json.loads((out/'functional-summary.json').read_text());resource=json.loads((out/'resource-summary.json').read_text());scanner=json.loads((out/'scanner-scope.json').read_text());meta=json.loads((out/'metadata.json').read_text())
assert functional['failures']==resource['failures']==scanner['findings']==0
assert all(int((out/n).read_text())==0 for n in ['functional.exit.txt','resource.exit.txt','gitleaks.exit.txt'])
verdict={'verdict':'ACCEPT','scope':'Exactly five CI-only parser/security delta paths vs candidate-final-r19; no global or production approval','blockingFindings':[],'parserChecks':functional['parserChecks'],'gateChecks':functional['gateChecks'],'resourceParses':resource['totalParses'],'strictScannerFindings':0,'immutableDrift':0,'implementationChanges':False,'ownerForAnyFutureFixes':'Lead','limitations':['Original371 and coverage281 verified as retained metadata/immutable source, not fullsuite results','Caller extracted exactly, only Vitest branch with synthetic artifacts; no top-level nativecert executed','Finite workload <=4194304 UTF16 code units and <=8388608 UTF8 bytes; resource observation not unbounded whole-parser complexity proof','Secret scan covers five actual copied files under default Gitleaks rules, not global CodeQL/security assessment','Reviewer harness mistakes and initial raw failures retained; corrected harness only']}
(out/'verdict.json').write_text(json.dumps(verdict,indent=2)+'\n')
print(json.dumps({'verdict':verdict,'integrity':status},indent=2))
