import fs from 'node:fs'
import { performance } from 'node:perf_hooks'
import { isDeepStrictEqual } from 'node:util'
import { parseVitestSummary as parse } from './parser.mjs'
import { parseVitestSummary as measured, visits } from './instrumented-parser.mjs'
if (process.versions.node.split('.')[0] !== '22') throw new Error('Node22 required')
const MAX=4194304, suffix='\nTests 1 failed (1)', expectFailure={passed:0,failed:1,skipped:0,total:1}
const repeatTo=(s,n)=>s.repeat(Math.floor(n/s.length))+s.slice(0,n%s.length)
const shapes={
 'ESC-repeated-incomplete':n=>[repeatTo('\x1b]0;',n-suffix.length)+suffix,null],
 'C1-repeated-incomplete':n=>[repeatTo('\x9d0;',n-suffix.length)+suffix,null],
 'mixed-dense-complete':n=>{const s='\x1b]a\x07\x9db\x9c\x1b]c\x1b\\';return [s.repeat(Math.floor((n-suffix.length)/s.length))+suffix,expectFailure]},
 'long-complete-BEL':n=>['\x1b]'+ 'x'.repeat(n-suffix.length-3)+'\x07'+suffix,expectFailure],
 'long-complete-ESCST':n=>['\x9d'+ '\x1bX'.repeat(Math.floor((n-suffix.length-3)/2))+'\x1b\\'+suffix,expectFailure],
 'plain-noise':n=>['x'.repeat(n-suffix.length)+suffix,expectFailure],
 'SGR-dense':n=>['\x1b[32m\x1b[0m'.repeat(Math.floor((n-suffix.length)/9))+suffix,expectFailure],
 'CSI-incomplete-dense':n=>[repeatTo('\x1b[',n-suffix.length)+suffix,expectFailure]
}
const rows=[],failures=[]
for(const [shape,make] of Object.entries(shapes))for(const size of [65536,262144,1048576,MAX]) {
 const [input,expected]=make(size),bytes=Buffer.byteLength(input)
 if(input.length>MAX || bytes>8388608)throw new Error('Bound exceeded')
 const instrumented=measured(input,'Tests'), count={...visits}
 const times=[];let actual
 for(let k=0;k<3;k++) {const start=performance.now();actual=parse(input,'Tests');times.push(performance.now()-start)}
 const row={shape,requestedSize:size,codeUnits:input.length,utf8Bytes:bytes,expected,actual,instrumented,visits:count,totalVisits:count.outer+count.inner,timesMs:times,maxMs:Math.max(...times),pass:isDeepStrictEqual(actual,expected)&&isDeepStrictEqual(instrumented,expected)&&count.outer+count.inner<=input.length&&Math.max(...times)<1000}
 rows.push(row);console.log(JSON.stringify(row));if(!row.pass)failures.push(row)
}
fs.writeFileSync('resource.raw.json',JSON.stringify(rows,null,2)+'\n');fs.writeFileSync('resource-failures.json',JSON.stringify(failures,null,2)+'\n')
const summary={node:process.version,shapes:Object.keys(shapes).length,sizeLevels:4,samplesPerCell:3,totalParses:rows.length*4,maxCodeUnits:Math.max(...rows.map(r=>r.codeUnits)),maxUtf8Bytes:Math.max(...rows.map(r=>r.utf8Bytes)),maxParseMs:Math.max(...rows.map(r=>r.maxMs)),maxRssKb:process.resourceUsage().maxRSS,failures:failures.length,bound:'Each instrumented OSC scan visits <= n positions; partial sequences return once, no suffix rescans. Builtin stripper/count regex timing tested only within declared maximum.'}
fs.writeFileSync('resource-summary.json',JSON.stringify(summary,null,2)+'\n');console.log(JSON.stringify(summary));if(failures.length)process.exitCode=1
