import pathlib,json,hashlib,re,shutil
out=pathlib.Path(__file__).resolve().parent
base=out.parent.parent
roots={'source':base/'candidate-ci-linear-r24','original':base/'candidate-final-r19'}
authority=json.loads((out.parent/'authority.json').read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def function(text,name):
 start=re.search(r'^(?:export )?function '+re.escape(name)+r'\(',text,re.M).start()
 end=text.index('\n}\n',start)+3
 return text[start:end],start
bindings=[]
def extract(rootkey,rel,name):
 p=roots[rootkey]/rel;text=p.read_text(); body,start=function(text,name)
 bindings.append({'root':rootkey,'path':rel,'sourceSha256':sha(p.read_bytes()),'function':name,'startLine':text[:start].count('\n')+1,'endLine':text[:start+len(body)].count('\n'),'extractedSha256':sha(body.encode()),'transform':'only add export to private declarations when needed'})
 return body if body.startswith('export ') else 'export '+body
(out/'copies').mkdir(exist_ok=True)
for row in json.loads((out/'delta.json').read_text()):
 p=out/'copies'/row['path'];p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(roots['source']/row['path'],p)
parser=extract('source','scripts/lib/certification-rules.mjs','parseVitestSummary')
(out/'parser.mjs').write_text("import { stripVTControlCharacters } from 'node:util'\n"+parser)
(out/'original-parser.mjs').write_text(extract('original','scripts/lib/certification-rules.mjs','parseVitestSummary'))
parts=["import { createHash } from 'node:crypto'\nimport { parseVitestSummary } from './parser.mjs'\n"]
for name in ['parsePlaywrightSummary','parseJson','sha256Bytes','deriveGateOutcome']:
 parts.append(extract('source','scripts/lib/certification-rules.mjs',name))
parts.append(extract('source','scripts/lib/skip-governance.mjs','validateSkipInventory'))
text=(roots['source']/'scripts/lib/skip-governance.mjs').read_text();s=text.index('export const REQUIRED_REPORT_GATES');e=text.index('\n',s)+1;parts.append(text[s:e])
text=(roots['source']/'scripts/lib/certification-rules.mjs').read_text()
for name in ['GATE_EVIDENCE_MATRIX','GATE_ENVIRONMENT_EVIDENCE_MATRIX']:
 s=text.index('export const '+name);e=text.index('\n}\n',s)+3;parts.append(text[s:e])
parts.append(extract('source','scripts/phase10-certify.mjs','deriveGateMetrics'))
(out/'gate.mjs').write_text('\n'.join(parts))
inst=parser.replace('  const chunks = []','  visits.outer = 0\n  visits.inner = 0\n  const chunks = []').replace('    const code = log.charCodeAt(index)','    visits.outer++\n    const code = log.charCodeAt(index)').replace('      const current = log.charCodeAt(index)','      visits.inner++\n      const current = log.charCodeAt(index)')
(out/'instrumented-parser.mjs').write_text("import { stripVTControlCharacters } from 'node:util'\nexport const visits = { outer: 0, inner: 0 }\n"+inst)
(out/'sourcebindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
metadata={};a=json.loads((roots['original']/'scripts/hiso-baseline-inventory.json').read_text());b=json.loads((roots['source']/'scripts/hiso-baseline-inventory.json').read_text())
assert len(a['tests'])==len(b['tests'])==371 and a['tests']==b['tests']
assert a['coveragePaths']==b['coveragePaths'] and a['newCoveragePaths']==b['newCoveragePaths']
assert len(b['coveragePaths'])==275 and len(b['newCoveragePaths'])==6
assert len(set(b['coveragePaths']+b['newCoveragePaths']))==281
assert len(a['newTests'])==46 and len(b['newTests'])==47
assert sorted(set(b['newTests'])-set(a['newTests']))==['tests/certification-summary-ansi-own.test.js']
assert {k:v for k,v in a.items() if k!='newTests'}=={k:v for k,v in b.items() if k!='newTests'}
x=(roots['original']/'tests/hiso-ci-scopes.test.js').read_text();y=(roots['source']/'tests/hiso-ci-scopes.test.js').read_text()
assert y==x.replace('expect(baseline.newTests).toHaveLength(46)','expect(baseline.newTests).toHaveLength(47)')
metadata.update(original371EntriesRetained=True,coveragePathsRetained=281,newTestPaths={'original':46,'source':47},originalAssertionsRetainedExceptNewTestCount=True)
a=json.loads((roots['original']/'scripts/skip-catalog.json').read_text());b=json.loads((roots['source']/'scripts/skip-catalog.json').read_text());assert len(a['entries'])==len(b['entries'])==35
changes=[]; mismatches=[]
for old,new in zip(a['entries'],b['entries']):
 assert {k:v for k,v in old.items() if k!='sourceSha256'}=={k:v for k,v in new.items() if k!='sourceSha256'}
 actual=sha((roots['source']/new['file']).read_bytes());assert (roots['source']/new['file']).read_bytes()==(roots['original']/new['file']).read_bytes()
 if old['sourceSha256']!=new['sourceSha256']:changes.append({'id':new['id'],'file':new['file'],'old':old['sourceSha256'],'new':new['sourceSha256'],'actual':actual})
 if actual!=new['sourceSha256']:mismatches.append({'id':new['id'],'expected':new['sourceSha256'],'actual':actual})
assert len(changes)==4 and not mismatches
assert {k:v for k,v in a.items() if k!='entries'}=={k:v for k,v in b.items() if k!='entries'}
metadata.update(skipCatalogEntries=35,skipCatalogChangedHashes=changes,all35CatalogHashesMatch=True)
(out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
external={}
for key in ['scanner','strictScannerConfig','emptyIgnore']:
 p=pathlib.Path(authority[key]);external[str(p)]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
p=out.parent/'authority.json';external[str(p)]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
(out/'external-before.json').write_text(json.dumps(external,indent=2)+'\n')
bar={'required':['exactly five immutable CI paths vs R19; no app/code runtime changes','OSC ESC/C1 introductions with BEL/C1ST/ESCST terminators and SGR','first matching summary and unchanged count/skip/null semantics','any incomplete OSC fails closed anywhere; no suffix rescans','Original371 metadata/assertions and coverage281 preserved; inventory46->47 single path; catalog35 exactly4hashes repaired and bound','actual caller function behavior including skips/metrics/exit failures','strict5path Gitleaks zero; immutable inputs stable before/after'], 'maximumInputCodeUnits':4194304,'maximumInputUtf8Bytes':8388608,'maximumFunctionalCases':10000,'commandTimeoutSeconds':45,'resourceSamplesPerShapeSize':3,'resourceSingleParseLimitMs':1000,'resourceShapes':['repeated ESC incomplete','repeated C1 incomplete','dense complete mixed OSC','long complete OSC','plain noise'], 'limitations':['no full suite/nativecert/app execution','no PG/network/provider/privateenv/install/subagents','no global CodeQL or production verdict','caller exercised only Vitest branch; synthetic artifacts']}
(out/'quality-bar.json').write_text(json.dumps(bar,indent=2)+'\n')
print('Preparation PASS; metadata bound; extracted functions only; max 4Mi code units / 8Mi UTF8, 45s command limit.')
