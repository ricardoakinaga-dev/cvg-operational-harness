import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const out=import.meta.dirname, base=path.dirname(out);
const snapshot=JSON.parse(fs.readFileSync(path.join(out,'source-before-snapshot.json')));
const mismatches=[],sharedInodes=[],externalLinks=[];
for(const [r,a] of Object.entries(snapshot)) {
 const original=path.join(base,'source',r), copy=path.join(out,'runtime',r);
 const s=fs.lstatSync(original),c=fs.lstatSync(copy);
 if(a.kind==='file') {
  if(s.ino===c.ino&&s.dev===c.dev)sharedInodes.push(r);
  if(crypto.createHash('sha256').update(fs.readFileSync(copy)).digest('hex')!==a.sha256)mismatches.push(r);
 } else if(a.kind==='link') {
  const link=fs.readlinkSync(copy);
  if(link!==a.target)mismatches.push(r);
  if(!path.resolve(path.dirname(copy),link).startsWith(path.join(out,'runtime')+'/'))externalLinks.push(r);
 }
}
const report={entries:Object.keys(snapshot).length,mismatches,sharedInodes,externalLinks,physicalCopy:true,valid:!(mismatches.length||sharedInodes.length||externalLinks.length)};
fs.writeFileSync(path.join(out,'copy-integrity.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));if(!report.valid)process.exitCode=1;
