import fs from 'node:fs';
import path from 'node:path';
const file=path.join(import.meta.dirname,'write-report.mjs');
const text=fs.readFileSync(file,'utf8');
const lines=text.split('\n');
const index=lines.findIndex(line=>line.startsWith('const markdown='));
lines[index]=lines[index].replaceAll(String.fromCharCode(92,92,96),String.fromCharCode(92,96));
fs.writeFileSync(file,lines.join('\n'));
