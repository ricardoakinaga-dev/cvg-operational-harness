import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const base = path.resolve(import.meta.dirname, '..');
const source = path.join(base, 'source');
const out = import.meta.dirname;
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const expected = '378ef74dd859116e0973b413409aec61221bae55cf0086b5e95d6dff6ff50bc3';
const invRaw = fs.readFileSync(path.join(base, 'frozen-inventory.json'));
const inventory = JSON.parse(invRaw);
const stage = process.argv[2];
const records = {};
const actual = {};
function walk(dir, rel = '') {
  const stat = fs.lstatSync(dir, {bigint:true});
  records[rel || '.'] = {kind:'directory', mtimeNs:String(stat.mtimeNs), mode:String(stat.mode)};
  for (const name of fs.readdirSync(dir).sort()) {
    const r = rel ? rel+'/'+name : name;
    const p = path.join(dir,name);
    const s = fs.lstatSync(p,{bigint:true});
    if(s.isDirectory()) walk(p,r);
    else if(s.isSymbolicLink()) {
      const target = fs.readlinkSync(p);
      actual[r] = {kind:'link',target};
      records[r] = {...actual[r],mtimeNs:String(s.mtimeNs),mode:String(s.mode)};
    } else if(s.isFile()) {
      actual[r] = {bytes:Number(s.size),kind:'file',sha256:sha(fs.readFileSync(p))};
      records[r] = {...actual[r],mtimeNs:String(s.mtimeNs),mode:String(s.mode)};
    } else throw new Error('Unsupported filesystem entry: '+r);
  }
}
walk(source);
const differences = [];
for (const key of new Set([...Object.keys(inventory),...Object.keys(actual)])) {
 if(JSON.stringify(inventory[key])!==JSON.stringify(actual[key])) {
   const a=inventory[key], b=actual[key];
   if(!a||!b||Object.keys(a).some(k=>a[k]!==b[k])||Object.keys(b).some(k=>a[k]!==b[k])) differences.push({path:key,expected:a,actual:b});
 }
}
fs.writeFileSync(path.join(out,`source-${stage}-snapshot.json`), JSON.stringify(records,null,2)+'\n');
let changed=[];
if(stage==='after') {
 const before=JSON.parse(fs.readFileSync(path.join(out,'source-before-snapshot.json')));
 for(const k of new Set([...Object.keys(before),...Object.keys(records)])) if(JSON.stringify(before[k])!==JSON.stringify(records[k])) changed.push(k);
}
const report={stage,inventorySha256:sha(invRaw),expectedSha256:expected,inventoryHashValid:sha(invRaw)===expected,expectedEntries:Object.keys(inventory).length,actualEntries:Object.keys(actual).length,directories:Object.values(records).filter(x=>x.kind==='directory').length,differences,changed,valid:sha(invRaw)===expected&&differences.length===0&&changed.length===0};
fs.writeFileSync(path.join(out,`integrity-${stage}.json`),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));
if(!report.valid) process.exitCode=1;
