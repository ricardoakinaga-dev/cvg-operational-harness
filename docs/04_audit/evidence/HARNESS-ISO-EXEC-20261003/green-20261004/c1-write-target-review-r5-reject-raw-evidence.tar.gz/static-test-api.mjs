import assert from 'node:assert/strict';
import util from 'node:util';
export const tests=[], hooks=[], suites=[];
export function describe(name,fn){suites.push(name);try{fn()}finally{suites.pop()}}
export function it(name,fn){tests.push({name:[...suites,name].join(' > '),fn})}
it.each=rows=>(name,fn)=>{for(const row of rows){const args=Array.isArray(row)?row:[row];it(util.format(name,...args.slice(0,(name.match(/%s/g)||[]).length)),()=>fn(...args))}};
export function afterAll(fn){hooks.push(fn)}
export function expect(actual,label){
 const make=neg=>{
  const check=(pass,message)=>assert.ok(neg?!pass:pass,(label?label+': ':'')+message);
  return {
   get not(){return make(!neg)},
   toBe(expected){check(Object.is(actual,expected),`toBe ${util.inspect(expected)}; actual ${util.inspect(actual,{depth:1})}`)},
   toEqual(expected){check(util.isDeepStrictEqual(actual,expected),`toEqual ${util.inspect(expected)}; actual ${util.inspect(actual,{depth:1})}`)},
   toContain(expected){check(actual.includes(expected),'toContain '+util.inspect(expected))},
   toHaveLength(expected){check(actual.length===expected,`length ${expected}; actual ${actual.length}`)}
  };
 };return make(false);
}
