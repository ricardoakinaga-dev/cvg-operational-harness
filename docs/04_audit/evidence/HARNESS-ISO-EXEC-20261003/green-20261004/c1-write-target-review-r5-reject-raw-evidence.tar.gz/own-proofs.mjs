import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import childProcess from 'node:child_process';
import {registerHooks,syncBuiltinESMExports} from 'node:module';
import {pathToFileURL} from 'node:url';
import ts from './runtime/node_modules/typescript/lib/typescript.js';
import {createBoundaryLexical,assignedValues,valueBranches} from './runtime/scripts/boundary-lexical.mjs';
import {auditDynamicCodeExecution} from './runtime/scripts/boundary-code-execution.mjs';
const out=import.meta.dirname;
for(const name of ['spawn','spawnSync','exec','execSync','execFile','execFileSync','fork'])childProcess[name]=()=>{throw new Error('Forbidden descendant: '+name)};
syncBuiltinESMExports();
registerHooks({resolve(specifier,context,next){
 if(context.parentURL?.endsWith('/runtime/scripts/check-product-boundary.mjs')&&specifier==='./boundary-lexical.mjs')return {url:pathToFileURL(path.join(out,'symbolic-lexical.mjs')).href,shortCircuit:true};
 return next(specifier,context);
}});
const {auditProductBoundary}=await import('./runtime/scripts/check-product-boundary.mjs');
const cases=[
 ['simple-catch','const seed="label";function f(token="parameter"){try{}catch(token){var token=seed;observe(token)}return token}',true,false],
 ['optional-catch','const seed="label";function f(token="parameter"){try{}catch{var token=seed;observe(token)}return token}',true,true],
 ['nested-optional','const seed="label";function f(token="parameter"){try{}catch(token){try{}catch{var token=seed;observe(token)}}return token}',true,false],
 ['nested-distinct','const seed="label";function f(){try{}catch(token){try{}catch(other){var token=seed;observe(token)}}return token}',true,false],
 ['nested-matching','const seed="label";function f(){try{}catch(token){try{}catch(token){var token=seed;observe(token)}}return token}',true,false],
 ['nested-function','const seed="label";function f(){try{}catch(token){function g(){var token=seed;observe(token)}}}',true,null],
 ['arrow-boundary','const seed="label";function f(){try{}catch(token){const g=()=>{var token=seed;observe(token)}}}',true,null],
 ['method-boundary','const seed="label";function f(){try{}catch(token){class Data{method(){var token=seed;observe(token)}}}}',true,null],
 ['let-shadow','const seed="label";function f(token="parameter"){try{}catch(other){let token=seed;observe(token)}return token}',true,false],
 ['catch-destructured-parameter','const seed="label";function f(){try{}catch({token}){let alias=seed;observe(alias)}}',true,null,'alias'],
 ['directed-body-only','const seed="label";function f(token="parameter",value=()=>token){var token=seed;observe(token);return token}',true,true],
 ['parameter-copy','const seed="label";function f(token=seed,value=()=>token){var token;observe(token);return token}',true,true],
 ['static-block-same','const seed="label";function f(){try{}catch(token){class Data{static{var token=seed;observe(token)}}}}',true,null],
 ['static-block-nested-optional','const seed="label";function f(){try{}catch(token){class Data{static{try{}catch{var token=seed;observe(token)}}}}}',true,null],
 ['static-block-local-catch','const seed="label";function f(){try{}catch(token){class Data{static{try{}catch(token){var token=seed;observe(token)}}}}}',true,null],
 ['static-block-distinct','const seed="label";function f(){try{}catch(other){class Data{static{var token=seed;observe(token)}}}}',true,null],
 ['static-block-let-control','const seed="label";function f(){try{}catch(token){class Data{static{let token=seed;observe(token)}}}}',true,null],
 ['static-block-destructure-default','const seed="label";function f(){try{}catch(token){class Data{static{var {value:token=seed}={};observe(token)}}}}',true,null],
 ['static-block-array-default','const seed="label";function f(){try{}catch(token){class Data{static{var [token=seed]=[];observe(token)}}}}',true,null],
 ['catch-object-default-control','const seed="label";function f(){try{}catch(token){var {value:token=seed}={};observe(token)}}',true,null],
 ['catch-array-default-control','const seed="label";function f(){try{}catch(token){var [token=seed]=[];observe(token)}}',true,null],
 ['satisfies-alias','const seed="label";type Label=unknown;const token=seed satisfies Label;observe(token)',true,null],
 ['as-alias-control','const seed="label";const token=seed as unknown;observe(token)',true,null],
 ['nonnull-alias-control','const seed="label";const token=seed!;observe(token)',true,null],
 ['direct-alias','const seed="label";const token=seed;observe(token)',true,null],
 ['branch-alias','const seed="label";const token=flag?seed:"label";observe(token)',true,null],
 ['local-reexport','const seed="label";const token=seed;export {token as Label};observe(token)',true,null],
 ['erased-shadow-control','const seed="label";type seed={label:string};const token=seed;observe(token)',true,null],
 ['erased-query-control','const seed="label";type Label=typeof seed;const token="label";observe(token)',false,null],
 ['parameter-destructure-default','const seed="label";function f({token=seed}={}){observe(token)}',true,null]
];
const records=[];
const literal=n=>n&&ts.isStringLiteralLike(n)?n.text:undefined;
function fixtureRoot(id,text,ext){
 const root=path.join(out,'inert-fixtures',id+'-'+ext);
 for(const d of ['packages/core/src','apps','legacy','products'])fs.mkdirSync(path.join(root,d),{recursive:true});
 const write=(p,v)=>fs.writeFileSync(path.join(root,p),typeof v==='string'?v:JSON.stringify(v));
 write('package.json',{private:true,type:'module',workspaces:['packages/*']});
 write('packages/core/package.json',{name:'@neutral/core',type:'module'});
 write('tsconfig.base.json',{compilerOptions:{module:'NodeNext',moduleResolution:'NodeNext',target:'ESNext',allowJs:true}});
 write('packages/core/src/entry.'+ext,text);
 return root;
}
for(const [id,text,expectedRead,expectedReturn,readName='token'] of cases)for(const ext of (id.includes('satisfies')||id.includes('as-alias')||id.includes('nonnull')?['mts']:['mjs','mts'])){
 const source=ts.createSourceFile('neutral.'+ext,text,ts.ScriptTarget.Latest,true);
 assert.equal(source.parseDiagnostics.length,0);
 const lexical=createBoundaryLexical(ts,source),nodes=[];
 const host={getSourceFile:n=>n===source.fileName?source:undefined,getDefaultLibFileName:()=>'',writeFile:()=>{},getCurrentDirectory:()=>'',getDirectories:()=>[],fileExists:n=>n===source.fileName,readFile:()=>undefined,getCanonicalFileName:n=>n,useCaseSensitiveFileNames:()=>true,getNewLine:()=> '\n'};
 const checkerProgram=ts.createProgram([source.fileName],{noLib:true,noResolve:true,noEmit:true,allowJs:true,checkJs:true,target:ts.ScriptTarget.ESNext},host);
 const checker=checkerProgram.getTypeChecker();
 function visit(n){nodes.push(n);ts.forEachChild(n,visit)}visit(source);
 const seed=nodes.find(n=>ts.isVariableDeclaration(n)&&n.name.text==='seed').name;
 const reads=nodes.filter(n=>ts.isIdentifier(n)&&n.text===readName&&ts.isCallExpression(n.parent)&&n.parent.expression.text==='observe');
 const returned=nodes.find(n=>ts.isIdentifier(n)&&n.text===readName&&ts.isReturnStatement(n.parent));
 const labels=new Set([lexical.identity(seed)]);
 const match=n=>ts.isIdentifier(n)&&labels.has(lexical.identity(n));
 let changed=true;
 while(changed){changed=false;const bind=(k,v)=>{if(valueBranches(ts,v).some(match)&&!labels.has(k)){labels.add(k);changed=true}};
  for(const [body,param]of lexical.initialTransfers)bind(lexical.identity(body),param);
  for(const n of nodes.filter(n=>!lexical.erased(n))){if((ts.isVariableDeclaration(n)||ts.isParameter(n))&&n.initializer)assignedValues(ts,n.name,n.initializer,literal,(name,v)=>bind(lexical.writeIdentity(name),v));if(ts.isBinaryExpression(n)&&n.operatorToken.kind>=ts.SyntaxKind.FirstAssignment&&n.operatorToken.kind<=ts.SyntaxKind.LastAssignment)assignedValues(ts,n.left,n.right,literal,(name,v)=>bind(lexical.identity(name),v));}
 }
 const diagnostics=[];
 auditDynamicCodeExecution({ts,source,lexical:{...lexical,global:name=>name==='Function'?lexical.identity(seed):lexical.global(name)},runtimeNodes:nodes.filter(n=>!lexical.erased(n)),typeOnly:lexical.erased,literal,isLoader:()=>false,isBuiltinGetter:()=>false,isGlobal:()=>false,isDeclarationName:lexical.isDeclarationName,loaderDiagnostic:(n,reason)=>diagnostics.push({start:n.getStart(source),reason})});
 const cells=[];const index=k=>{if(!cells.includes(k))cells.push(k);return cells.indexOf(k)};
 const identifiers=nodes.filter(n=>ts.isIdentifier(n)&&['seed','token','alias'].includes(n.text)&&!lexical.erased(n)&&!(ts.isPropertyAssignment(n.parent)&&n.parent.name===n));
 const root=fixtureRoot(id,text,ext);
 const product=auditProductBoundary(root);
 records.push({id,ext,text,parseErrors:0,fixturesExecuted:false,expectedRead,expectedReturn,symbolicRead:reads.map(n=>labels.has(lexical.identity(n))),symbolicReturn:returned?labels.has(lexical.identity(returned)):null,dynamicRead:reads.map(n=>diagnostics.some(d=>d.start===n.getStart(source))),dynamicReturn:returned?diagnostics.some(d=>d.start===returned.getStart(source)):null,identities:identifiers.map(n=>({name:n.text,start:n.getStart(source),parent:ts.SyntaxKind[n.parent.kind],identity:index(lexical.identity(n)),writeIdentity:index(lexical.writeIdentity(n)),labeled:labels.has(lexical.identity(n)),checkerDeclarationStarts:checker.getSymbolAtLocation(n)?.declarations?.map(d=>d.getStart(source))})),parameterClosures:nodes.filter(n=>ts.isIdentifier(n)&&n.text==='token'&&ts.isArrowFunction(n.parent)).map(n=>({start:n.getStart(source),identity:index(lexical.identity(n)),labeled:labels.has(lexical.identity(n))})),transfers:lexical.initialTransfers.map(([b,p])=>({target:index(lexical.identity(b)),source:index(lexical.identity(p))})),cells:cells.map((k,i)=>({cell:i,declarations:k.declarations?.map(d=>({kind:ts.SyntaxKind[d.kind],start:d.getStart(source)})),global:k.global})),checkerDiagnostics:checkerProgram.getSemanticDiagnostics(source).map(d=>({code:d.code,start:d.start,message:ts.flattenDiagnosticMessageText(d.messageText,'\n')})),dynamicDiagnostics:diagnostics,product:{...product,abstractSeed:'require identity = neutral seed identity',fixtureRoot:path.relative(out,root),runtimeProof:false}});
}
const scalarTexts=[
 ['plain-scalar','const data={constructor:"label"};export const label=data.constructor'],
 ['as-scalar','const data={constructor:"label"};export const label=(data as {constructor:string}).constructor'],
 ['satisfies-scalar','const data={constructor:"label"};export const label=(data satisfies {constructor:string}).constructor']
 ,['as-inline-scalar-control','export const label=({constructor:"label"} as {constructor:string}).constructor']
 ,['satisfies-inline-scalar','export const label=({constructor:"label"} satisfies {constructor:string}).constructor']
];
const scalarRecords=scalarTexts.map(([id,text])=>({id,text,expectedStatus:'PASS',...auditProductBoundary(fixtureRoot(id,text,'mts')),runtimeProof:false}));
const failures=records.filter(r=>r.symbolicRead.some(x=>x!==r.expectedRead)||r.dynamicRead.some(x=>x!==r.expectedRead)||(r.expectedReturn!==null&&(r.symbolicReturn!==r.expectedReturn||r.dynamicReturn!==r.expectedReturn)));
const report={fixturesExecuted:false,descendantsStarted:0,workersStarted:0,proofMode:'AST, lexical checker, directed symbolic labels, actual dynamic analyzer with injected seed and actual product checker with abstract neutral seed',total:records.length,conforming:records.length-failures.length,mismatches:failures.map(r=>({id:r.id,ext:r.ext,symbolicRead:r.symbolicRead,dynamicRead:r.dynamicRead,productStatus:r.product.status})),records,scalarRecords};
fs.writeFileSync(path.join(out,'raw','own-proofs.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({total:report.total,conforming:report.conforming,mismatches:report.mismatches,scalars:scalarRecords.map(r=>({id:r.id,status:r.status}))}));
