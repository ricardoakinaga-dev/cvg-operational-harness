import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const out=import.meta.dirname;
const json=p=>JSON.parse(fs.readFileSync(path.join(out,p)));
const report=json('report.json');
assert.equal(report.verdict,'REJECT');assert.equal(report.validity,'VALID_STATIC_REVIEW');
assert.deepEqual(report.counts,{P1:1,P2:2});
for(const p of ['integrity-before.json','integrity-after.json','copy-integrity.json','raw/evidence-validation.json'])assert.equal(json(p).valid,true);
const before=json('source-before-snapshot.json'),after=json('source-after-snapshot.json');assert.deepEqual(before,after);
const text=fs.readFileSync(path.join(out,'report.md'),'utf8');
const links=[...text.matchAll(/\]\(([^)]+)\)/g)].map(m=>m[1]);
for(const link of links){assert.ok(!path.isAbsolute(link));assert.ok(fs.existsSync(path.join(out,link)),link);}
const validation={valid:true,report:'report.json',markdownLinksVerified:links.length,sourceSnapshotsEqual:true,manifestHashesVerified:true,verdict:'REJECT',validity:'VALID_STATIC_REVIEW',scope:'STATIC_ONLY',counts:report.counts,node:process.version};
fs.writeFileSync(path.join(out,'raw/deliverable-validation.json'),JSON.stringify(validation,null,2)+'\n');
const files=fs.readdirSync(out,{withFileTypes:true}).filter(e=>e.isFile()&&e.name!=='artifact-manifest.json').map(e=>e.name);
files.push(...fs.readdirSync(path.join(out,'raw'),{withFileTypes:true}).filter(e=>e.isFile()).map(e=>'raw/'+e.name));
const entries=files.sort().map(p=>{const b=fs.readFileSync(path.join(out,p));return {path:p,bytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex')}});
const manifest={pathBase:'output',algorithm:'SHA-256',excludes:['artifact-manifest.json (self)','runtime (complete frozen physical copy validated by copy-integrity.json)','inert-fixtures (source texts retained in raw/own-proofs.json)','home/tmp/cache (isolated operational directories)'],artifacts:entries};
fs.writeFileSync(path.join(out,'artifact-manifest.json'),JSON.stringify(manifest,null,2)+'\n');
for(const e of json('artifact-manifest.json').artifacts){const b=fs.readFileSync(path.join(out,e.path));assert.equal(b.length,e.bytes);assert.equal(crypto.createHash('sha256').update(b).digest('hex'),e.sha256);}
console.log(JSON.stringify({...validation,artifacts:entries.length}));
