import fs from 'node:fs';
import path from 'node:path';
import childProcess from 'node:child_process';
import {registerHooks,syncBuiltinESMExports} from 'node:module';
import {pathToFileURL} from 'node:url';
import {tests,hooks} from './static-test-api.mjs';
const out=import.meta.dirname;
const abstractCalls=[];
// No child, evaluator, fixture or native execution. Resolver frontier is
// explicitly abstracted to null; only the consumer's source projection runs.
childProcess.spawnSync=(executable,args,options)=>{
 const refs=JSON.parse(options.input);
 if(executable!==process.execPath||!args.includes('--experimental-import-meta-resolve')||!Array.isArray(refs)||refs.some(r=>!r.file.startsWith(out+'/tmp/')))throw new Error('Rejected unexpected descendant request');
 abstractCalls.push({mode:'ABSTRACT_NULL_FRONTIER',references:refs,descendantStarted:false});
 return {status:0,stdout:JSON.stringify(refs.map(()=>null)),stderr:''};
};
for(const name of ['spawn','exec','execSync','execFile','execFileSync','fork'])childProcess[name]=()=>{throw new Error('Forbidden descendant: '+name)};
syncBuiltinESMExports();
registerHooks({resolve(specifier,context,next){if(specifier==='vitest')return {url:pathToFileURL(path.join(out,'static-test-api.mjs')).href,shortCircuit:true};return next(specifier,context)}});
await import('./runtime/tests/product-boundary-lexical-static.test.js');
const results=[];
for(const test of tests){try{await test.fn();results.push({name:test.name,status:'PASS'});}catch(e){results.push({name:test.name,status:'FAIL',error:String(e),stack:e.stack});}}
// Preserve all suite-generated raw evidence before its cleanup hook.
function capture(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory())capture(p);else if(['new-static-results.json','r4-neutral-proofs.json'].includes(e.name))fs.copyFileSync(p,path.join(out,'raw','supplied-'+e.name));}}
capture(process.env.TMPDIR);
for(const hook of hooks)await hook();
const report={runner:'in-process compatibility API (four assert/strict matchers); unchanged supplied suite',nativeVitest:false,abstractResolver:true,fixturesExecuted:false,descendantsStarted:0,workersStarted:0,total:results.length,passed:results.filter(r=>r.status==='PASS').length,failed:results.filter(r=>r.status==='FAIL').length,results,abstractCalls};
fs.writeFileSync(path.join(out,'raw','supplied-suite.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({total:report.total,passed:report.passed,failed:report.failed,nativeVitest:false,abstractResolver:true}));
if(report.failed)process.exitCode=1;
