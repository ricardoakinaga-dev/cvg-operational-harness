import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const out=import.meta.dirname;
const supplied=JSON.parse(fs.readFileSync(path.join(out,'raw/supplied-suite.json')));
const own=JSON.parse(fs.readFileSync(path.join(out,'raw/own-proofs.json')));
assert.equal(supplied.total,212);assert.equal(supplied.failed,0);assert.equal(supplied.descendantsStarted,0);
assert.equal(own.total,57);assert.equal(own.mismatches.length,9);
const r=(id,ext='mts')=>own.records.find(r=>r.id===id&&r.ext===ext);
for(const ext of ['mjs','mts']){
 const p=r('static-block-same',ext);
 const decl=p.identities.find(n=>n.name==='token'&&n.parent==='VariableDeclaration'&&n.start>60);
 const caught=p.identities.find(n=>n.name==='token'&&n.parent==='VariableDeclaration'&&n.start<60);
 const read=p.identities.find(n=>n.parent==='CallExpression');
 assert.equal(decl.identity,read.identity);assert.equal(decl.writeIdentity,caught.identity);assert.notEqual(decl.identity,decl.writeIdentity);
 assert.deepEqual(decl.checkerDeclarationStarts,read.checkerDeclarationStarts);
 assert.deepEqual(p.symbolicRead,[false]);assert.deepEqual(p.dynamicRead,[false]);assert.equal(p.product.status,'PASS');
 assert.equal(p.dynamicDiagnostics.length,0);assert.deepEqual(p.checkerDiagnostics.map(d=>d.code),[2304]);
 for(const id of ['nested-function','method-boundary','static-block-local-catch','static-block-distinct','static-block-let-control']){
  assert.deepEqual(r(id,ext).symbolicRead,[true]);assert.deepEqual(r(id,ext).dynamicRead,[true]);assert.equal(r(id,ext).product.status,'INCOMPLETE');
 }
 const directed=r('directed-body-only',ext),copy=r('parameter-copy',ext);
 assert.equal(directed.parameterClosures[0].labeled,false);assert.equal(copy.parameterClosures[0].labeled,true);
 for(const row of [directed,copy])for(const e of row.transfers)assert.notEqual(e.target,e.source);
}
assert.deepEqual(r('satisfies-alias').symbolicRead,[false]);assert.deepEqual(r('satisfies-alias').dynamicRead,[false]);assert.equal(r('satisfies-alias').product.status,'INCOMPLETE');
for(const id of ['as-alias-control','nonnull-alias-control','direct-alias','local-reexport','erased-shadow-control'])assert.deepEqual(r(id).dynamicRead,[true]);
const scalar=id=>own.scalarRecords.find(r=>r.id===id);
assert.equal(scalar('plain-scalar').status,'PASS');assert.equal(scalar('as-inline-scalar-control').status,'PASS');
for(const id of ['as-scalar','satisfies-scalar','satisfies-inline-scalar'])assert.equal(scalar(id).status,'INCOMPLETE');
const report={valid:true,suppliedTests:212,ownBindingProofs:57,ownScalarProofs:5,provedFindings:['F1','F2','F3'],staticBlockCheckerDiagnostics:r('static-block-same').checkerDiagnostics,controlsVerified:true,fixturesExecuted:false,descendantsStarted:0};
fs.writeFileSync(path.join(out,'raw/evidence-validation.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
