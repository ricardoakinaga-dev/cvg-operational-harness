import ts from './runtime/node_modules/typescript/lib/typescript.js';
import {createBoundaryLexical as original} from './runtime/scripts/boundary-lexical.mjs';
export {assignedValues,valueBranches} from './runtime/scripts/boundary-lexical.mjs';
export function createBoundaryLexical(tsArg,source,commonJs){
 const lexical=original(tsArg,source,commonJs);
 let seed;
 function walk(n){if(ts.isVariableDeclaration(n)&&ts.isIdentifier(n.name)&&n.name.text==='seed')seed=n.name;ts.forEachChild(n,walk)}walk(source);
 return seed?{...lexical,global:name=>name==='require'?lexical.identity(seed):lexical.global(name)}:lexical;
}
