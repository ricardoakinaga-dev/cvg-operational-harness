import os,sys,stat,json,hashlib
from pathlib import Path
packet=Path('/home/ricardo/.cache/cvg-harness-green-20261004/c1-parameter-review-r3')
source=packet/'source'; output=packet/'output'
def snapshot():
 result={}
 for base,dirs,files in os.walk(source,followlinks=False):
  for path in [base]+[os.path.join(base,n) for n in dirs+files]:
   key=os.path.relpath(path,source)
   if key in result: continue
   st=os.lstat(path)
   kind='link' if stat.S_ISLNK(st.st_mode) else 'directory' if stat.S_ISDIR(st.st_mode) else 'file' if stat.S_ISREG(st.st_mode) else 'other'
   value={'kind':kind,'dev':st.st_dev,'inode':st.st_ino,'mode':st.st_mode,'nlink':st.st_nlink,'size':st.st_size,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns}
   if kind=='file':
    with open(path,'rb') as handle: value['sha256']=hashlib.file_digest(handle,'sha256').hexdigest()
   elif kind=='link': value['target']=os.readlink(path)
   result[key]=value
 return result
actual=snapshot(); before=json.load(open(output/'integrity-before.json'))
json.dump(actual,open(output/'integrity-after.json','w'),sort_keys=True,indent=2)
differences=[{'path':k,'before':before.get(k),'after':actual.get(k)} for k in sorted(set(before)|set(actual)) if before.get(k)!=actual.get(k)]
json.dump(differences,open(output/'integrity-differences.json','w'),indent=2)
frozen_bytes=(packet/'frozen-inventory.json').read_bytes(); frozen=json.loads(frozen_bytes)
normalized={}
for k,v in actual.items():
 if v['kind']=='file': normalized[k]={'bytes':v['size'],'kind':'file','sha256':v['sha256']}
 elif v['kind']=='link': normalized[k]={'kind':'link','target':v['target']}
frozen_differences=[k for k in sorted(set(frozen)|set(normalized)) if frozen.get(k)!=normalized.get(k)]
output_shared=[]; output_links=[]; source_inodes={(v['dev'],v['inode']) for v in actual.values()}
for base,dirs,files in os.walk(output,followlinks=False):
 for path in [base]+[os.path.join(base,n) for n in dirs+files]:
  st=os.lstat(path)
  if (st.st_dev,st.st_ino) in source_inodes: output_shared.append(str(path))
  if stat.S_ISLNK(st.st_mode): output_links.append(str(path))
summary={
 'source':str(source),'snapshotEntriesBefore':len(before),'snapshotEntriesAfter':len(actual),
 'regularFiles':sum(v['kind']=='file' for v in actual.values()),'links':sum(v['kind']=='link' for v in actual.values()),'directories':sum(v['kind']=='directory' for v in actual.values()),
 'frozenEntries':len(frozen),'inventorySha256':hashlib.sha256(frozen_bytes).hexdigest(),
 'expectedInventorySha256':'ec844a455df6960de4a72916bf0f2da304002d168517bffbf0c1a31d5e4f0434',
 'beforeSnapshotSha256':hashlib.sha256((output/'integrity-before.json').read_bytes()).hexdigest(),
 'afterSnapshotSha256':hashlib.sha256((output/'integrity-after.json').read_bytes()).hexdigest(),
 'fullMetadataDifferences':len(differences),'frozenContentDifferences':len(frozen_differences),'frozenDifferencePaths':frozen_differences,
 'outputSharedSourceInodes':output_shared,'outputSymlinks':output_links,
 'comparedFields':['kind','dev','inode','mode','nlink','size','mtime_ns','ctime_ns','sha256 (regular files)','target (symlinks)'],
 'sourceWalkPolicy':'lstat; os.walk(followlinks=False); hashes cover all regular files including vendor/dist/original tests/schema/roots/bar/lockfiles; includes root directory',
 'valid':not differences and not frozen_differences and not output_shared and not output_links and hashlib.sha256(frozen_bytes).hexdigest()=='ec844a455df6960de4a72916bf0f2da304002d168517bffbf0c1a31d5e4f0434'
}
json.dump(summary,open(output/'integrity-summary.json','w'),indent=2)
print(json.dumps(summary,indent=2));sys.exit(0 if summary['valid'] else 1)
