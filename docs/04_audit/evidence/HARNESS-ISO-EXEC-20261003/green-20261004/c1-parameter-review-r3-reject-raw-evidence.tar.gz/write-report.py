from pathlib import Path
import json,hashlib,datetime
p=Path('/home/ricardo/.cache/cvg-harness-green-20261004/c1-parameter-review-r3');o=p/'output';s=p/'source';r=o/'runtime'
i=json.load(open(o/'integrity-summary.json')); tests=json.load(open(o/'supplied-tests.json')); probes=json.load(open(o/'neutral-probes.json')); confirmations=json.load(open(o/'confirm-neutral.json'))
assert i['valid']
env=f'env -i PATH=/home/ricardo/.nvm/versions/node/v22.23.2/bin:/usr/bin:/bin HOME={o}/home TMPDIR={o}/tmp XDG_CACHE_HOME={o}/cache npm_config_cache={o}/cache/npm /home/ricardo/.nvm/versions/node/v22.23.2/bin/node'
before_command='''python3 - <<'PY'
import os,stat,json,hashlib
p='/home/ricardo/.cache/cvg-harness-green-20261004/c1-parameter-review-r3'; s=p+'/source'; o=p+'/output'
os.makedirs(o,exist_ok=True)
r={}; inv={}; links=[]
for base,dirs,files in os.walk(s,followlinks=False):
 for path in [base]+[os.path.join(base,n) for n in dirs+files]:
  k=os.path.relpath(path,s)
  if k in r: continue
  st=os.lstat(path); kind='link' if stat.S_ISLNK(st.st_mode) else 'directory' if stat.S_ISDIR(st.st_mode) else 'file' if stat.S_ISREG(st.st_mode) else 'other'
  v={'kind':kind,'dev':st.st_dev,'inode':st.st_ino,'mode':st.st_mode,'nlink':st.st_nlink,'size':st.st_size,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns}
  if kind=='file':
   with open(path,'rb') as f: v['sha256']=hashlib.file_digest(f,'sha256').hexdigest()
   inv[k]={'bytes':st.st_size,'kind':'file','sha256':v['sha256']}
  elif kind=='link':
   v['target']=os.readlink(path); inv[k]={'kind':'symlink','target':v['target']}; links.append((k,v['target']))
  r[k]=v
frozen=json.load(open(p+'/frozen-inventory.json'))
diffs=[{'path':k,'expected':frozen.get(k),'actual':inv.get(k)} for k in sorted(set(frozen)|set(inv)) if frozen.get(k)!=inv.get(k)]
json.dump(r,open(o+'/integrity-before.json','w'),sort_keys=True,indent=2)
json.dump(diffs,open(o+'/frozen-inventory-differences.json','w'),indent=2)
print('beforeEntries',len(r),'files',sum(x['kind']=='file' for x in r.values()),'links',len(links),'inventoryDifferences',len(diffs))
print('firstDifferences',diffs[:2]); print('links',json.dumps(links))
print('outputEntries',os.listdir(o))
PY'''
(o/'integrity-before-command.txt').write_text(before_command+'\n')
commands=[
 {'id':'first-tool-authority-freeze','cmd':f'cat {p}/authority.json {p}/freeze.json','exitCode':0},
 {'id':'second-tool-packet-constitution','cmd':f'cat {s}/docs/07_agents/AGENTS.md','exitCode':0},
 {'id':'before-full-integrity','cmd':before_command,'exitCode':0,'result':'21352 entries, 19334 files, 48 links; initial inventory comparison label mismatch only; normalized zero differences'},
 {'id':'supplied-inert-tests','cwd':str(r),'cmd':env+' node_modules/vitest/vitest.mjs run --config vitest.review.config.mjs --reporter=verbose --reporter=json --outputFile=../supplied-tests.json > ../supplied-tests.log 2>&1','exitCode':0,'outputs':['supplied-tests.log','supplied-tests.json']},
 {'id':'independent-neutral-probes','cwd':str(r),'cmd':env+' neutral-probes.mjs > ../neutral-probes.log 2>&1','exitCode':1,'expectedFailure':'Five identity/transfer checks expose source defects; not a runner failure.','outputs':['neutral-probes.log','neutral-probes.json']},
 {'id':'neutral-confirmation-initial','cwd':str(r),'cmd':env+' confirm-neutral.mjs > ../confirm-neutral.log 2>&1','exitCode':0,'outputs':['confirm-neutral.log','confirm-neutral-initial.json']},
 {'id':'neutral-confirmation-expanded','cwd':str(r),'cmd':env+' confirm-neutral.mjs > ../confirm-neutral-expanded.log 2>&1','exitCode':0,'outputs':['confirm-neutral-expanded.log','confirm-neutral.json']},
 {'id':'authorized-node-version','cwd':str(r),'cmd':env+' --version > ../node-version.txt','exitCode':0},
 {'id':'after-full-integrity','cwd':str(o),'cmd':f'python3 {o}/integrity.py > {o}/integrity-after.log','exitCode':0,'outputs':['integrity-after.log','integrity-after.json','integrity-summary.json','integrity-differences.json']}
]
commands[-1:-1] = [
 {'id':'physical-runtime-copy-and-inode-link-proof','cmd':(o/'runtime-copy-proof-command.txt').read_text(),'exitCode':0,'outputs':['runtime-isolation.json']},
 {'id':'post-execution-copy-hashes-and-own-cleanup','cmd':(o/'runtime-verify-cleanup-command.txt').read_text(),'exitCode':0,'outputs':['runtime-execution-integrity.json','cleanup.json']}
]
json.dump(commands,open(o/'commands.json','w'),indent=2)
findings=[
 {'id':'R3-STATIC-01','priority':'P1','blocking':True,'title':'Destructured body var cells remain merged with parameter cells; initialTransfers becomes a self edge','source':'scripts/boundary-lexical.mjs','lines':[73,82,90,160,164],
  'neutralProof':'function f([token="parameter"],value=()=>token){var [token]=["body"];return token}',
  'expected':'Parameter/default closure and body var/return have distinct keys and separate declarations. A one-way initial parameter value copy targets the body cell.',
  'actual':'mjs and mts: all references use cell1; declarations contain both parameter and body BindingElements; transfer target=cell1, parameter=cell1, selfEdge=true. Object and computed object body destructuring reproduce the same defect.',
  'cause':'Collected body.declarations stores the enclosing VariableDeclaration, but TypeScript symbol.declarations contains a BindingElement. Exact includes() fails the belongs test, so the environment override is skipped and the merged binder symbol survives.',
  'impact':'Identity correctness and directed initial-copy precision fail. The neutral symbolic mapping adds body-write-label to the parameter and initializer closure too. Both capability fixed points consume these same identity keys, so their separation premise fails. No native escape or real capability execution is asserted.',
  'proofArtifacts':['neutral-probes.json#array-binding-default','confirm-neutral.json#body-array-binding','confirm-neutral.json#body-object-binding','confirm-neutral.json#computed-body-binding'],
  'remediation':'Classify binding declaration ownership through the containing runtime declaration/environment, and require a distinct target/source transfer key for parameter-expression body vars, preserving actual nested/block shadow declarations.'},
 {'id':'R3-STATIC-02','priority':'P1','blocking':True,'title':'Catch bindings are collected as body var declarations and can capture references outside the catch scope','source':'scripts/boundary-lexical.mjs','lines':[73,74,85,90,165],
  'neutralProof':'function f(token="parameter"){try{}catch(token){read(token)}return token}',
  'expected':'Catch parameter/use remain a separate lexical identity. Return outside catch resolves to the function parameter. No body-var initial transfer is created when there is no body var.',
  'actual':'mjs and mts: parameter=cell1, catch binding/use=cell2, outside return=cell2. An invented cell1 -> cell2 initial transfer targets the catch binding. With an actual body var, body var and catch key merge instead.',
  'cause':'CatchClause.variableDeclaration satisfies isVariableDeclaration and its parent has no BlockScoped declaration-list flag. The body collector accepts it as a var, and identity assigns body.key to every otherwise matching body reference.',
  'impact':'Both lexical lookup and capability-transfer targets include a cell that is not a body var. Catch scope isolation fails; the outside return has incorrect declarations.',
  'proofArtifacts':['neutral-probes.json#catch-shadow','confirm-neutral.json#catch-cell','confirm-neutral.json#catch-only'],
  'remediation':'Collect only real var declarations under their declaration list, exclude catch lexical declarations, and preserve the TypeScript catch identity separately.'},
 {'id':'R3-STATIC-03','priority':'P2','blocking':True,'title':'Simple-parameter body function declaration and its body reference use different identities','source':'scripts/boundary-lexical.mjs','lines':[45,53,99,200],
  'neutralProof':'function f(token){function token(){}return token}',
  'expected':'The function declaration initializes/overwrites the shared simple-parameter runtime binding; a body reference must represent that effective body function value and its declaration. Simple parameter/var sharing must continue to work.',
  'actual':'mjs and mts: parameter=cell1 (Parameter declaration), function declaration=cell2 (FunctionDeclaration), return=cell1. BodyVsReturn=false; no transfer. The original binder body-reference-to-parameter behavior remains when expressions=false.',
  'cause':'Environment correction is gated on parameter expressions; the simple parameter case falls back to the raw checker symbols without repairing body-function precedence.',
  'impact':'Declaration/reference identity and body function precedence remain incorrect for an explicitly in-scope lexical case. The positive simple-var probe does pass.',
  'proofArtifacts':['neutral-probes.json#simple-function','confirm-neutral.json#simple-function-precedence'],
  'remediation':'Model simple-parameter shared binding and function initialization precedence consistently, including the body declaration/reference identities, without treating a body function as a parameter-value copy.'},
 {'id':'R3-STATIC-04','priority':'P2','blocking':True,'title':'Computed names inside erased parameter types create a fictitious parameter-expression environment','source':'scripts/boundary-lexical.mjs','lines':[47,48,50,52,53,92],
  'neutralProof':'function f(token:{["label"]:string}){var token;return token}',
  'expected':'The type annotation is erased. The runtime parameter list is simple; parameter and body var share one key, with no separate initial transfer.',
  'actual':'mts: parameter=cell1, body var/return=cell2; a cell1 -> cell2 transfer is created. Nested Array<{["label"]:string}> type reproduces the defect.',
  'cause':'parameterExpressions recursively scans type syntax and marks every ComputedPropertyName as an expression, without respecting runtime/value erasure.',
  'impact':'Value/type erasure and simple-parameter sharing fail even for neutral scalar input. Six neutral analyzer controls still pass, so this is specifically a lexical/transfer invariant failure.',
  'proofArtifacts':['neutral-probes.json#erased-type-computed','neutral-probes.json#erased-type-array','confirm-neutral.json#erased-computed-type'],
  'remediation':'Detect ContainsExpression in emitted parameter binding syntax and initializers, excluding all erased type/declaration syntax.'}
]
report={
 'reviewId':'C1_PARAMETER_FRESH_STATIC_REVIEW_R3','verdict':'REJECT','reviewValid':True,
 'scope':'Static lexical identities, parameter/body environments, declaration ownership, initialTransfers and both capability fixed-point consumers only',
 'source':str(s),'inventorySha256':i['inventorySha256'],'task':str(s/'docs/04_audit/evidence/HARNESS-ISO-EXEC-20261003/green-20261004/c1-parameter-environment-r3-t2.md'),
 'completedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scopeExclusions':['native/adversarial evaluator tests','execution of any fixture','provider/env inspection','PostgreSQL','Docker','network','subagents','Root edits or commits','push','deployment','production certification'],
 'authorizationAndReadBoundary':'First tool read only packet authority.json and freeze.json; second read packet source/docs/07_agents/AGENTS.md. Followed explicit packet-only, readonly static-review instruction; no skills, Root ledgers/history/prior reports or builder verdict consulted. Byte hashing for integrity covered all frozen files without semantic reading of forbidden documents.',
 'execution':{'nodeExecutable':'/home/ricardo/.nvm/versions/node/v22.23.2/bin/node','nodeVersion':(o/'node-version.txt').read_text().strip(),'physicalRuntime':str(r),'sourceNodeModulesExecution':False,'fixtureExecution':False,'environment':'env -i; HOME/TMPDIR/XDG_CACHE_HOME/npm cache entirely under output; PATH includes authorized Node 22 and standard system executables','resolverNote':'The authorized static scanner uses its fixed trusted --eval Node resolution helper; it resolves names only and never imports or evaluates fixture contents. The supplied tests and own neutral reexport audits use that helper. Identity confirmations use only TypeScript AST/checker and neutral symbolic cell labels.'},
 'suppliedTests':{'path':'tests/product-boundary-lexical-static.test.js','sha256':json.load(open(o/'runtime-isolation.json'))['selectedHashes']['tests/product-boundary-lexical-static.test.js'],'total':tests['numTotalTests'],'passed':tests['numPassedTests'],'failed':tests['numFailedTests'],'neutralSyntaxControls':61,'unknownINCOMPLETEControls':61,'identityEnvironmentChecks':10,'originalNativeSuiteRun':False,'artifacts':['supplied-tests.json','supplied-tests.log']},
 'independentProofs':{'initialTotal':len(probes),'initialPassed':sum(q['passed'] for q in probes),'initialFailed':sum(not q['passed'] for q in probes),'failedIds':[q['id'] for q in probes if not q['passed']],'neutralAnalyzerControls':6,'confirmationCases':len(confirmations['proofs']),'allConfirmationParseErrors':sum(q['parseErrors'] for q in confirmations['proofs']),'symbolicProofLimit':'Neutral labels show identity-map contamination only; no fixture/evaluator executed and no native exploit or runtime outcome inferred.','fixedPointTransferLoops':confirmations['fixedPointTransferLoops']},
 'findings':findings,'integrity':i,'runtimeIsolation':json.load(open(o/'runtime-isolation.json')),'copiedFilesAfterExecution':json.load(open(o/'runtime-execution-integrity.json')),
 'cleanup':json.load(open(o/'cleanup.json')),
 'unknownPolicy':{'suppliedUnknownControls':'61/61 require status INCOMPLETE, passed=false and the expected reason; all passed.','wholeInstalledRepositoryScanner':'NOT_RUN','wholeInstalledRepositoryAssessment':'INCOMPLETE; no PASS or release evidence inferred from this limited review.','remainingGates':'Native/adversarial and integrated product/repository gates remain outside this review.'},
 'executionNotes':['The initial inventory comparator used symlink instead of frozen kind link: 48 label-only differences. Normalization produced exact zero-content/target differences before execution and again after.','An initial post-execution comparison included reviewer-authored runtime/package.json as if copied from Source. Corrected to the actual copy scope; all 17351 copied regular files match their frozen hashes. Both diagnostic artifacts are retained.'],
 'nextAction':'Correct the four lexical/declaration defects, add inert controls for both body destructuring forms/computed binding/catch-only/simple-function/erased types, verify disjoint transfers and both fixed points, then request a new independent static review. This report grants no broader gate.'
}
json.dump(report,open(o/'report.json','w'),indent=2,ensure_ascii=False)
md=f'''# C1_PARAMETER_FRESH_STATIC_REVIEW_R3

**REJECT — valid independent review, static scope only.** Four source defects violate lexical identity, declaration ownership or initial-transfer invariants. All 132 supplied inert tests pass; that coverage does not exercise these defects. No native/adversarial or production verdict is granted.

Frozen Source: `{s}`. Inventory SHA-256: `{i['inventorySha256']}`. The task read was the explicitly authorized `c1-parameter-environment-r3-t2.md` inside this packet. No builder verdict, Root, skills, ledgers/history, prior reports or other packets were consulted.

## Findings

'''
for f in findings:
 md+=f'''### {f['id']} ({f['priority']}, blocking): {f['title']}

Source: `{f['source']}` lines {', '.join(map(str,f['lines']))}.

Neutral inert proof (parsed, never executed):

```ts
{f['neutralProof']}
```

Expected: {f['expected']}

Observed: {f['actual']}

Cause: {f['cause']}

Impact: {f['impact']}

Correction required: {f['remediation']}

Exact AST nodes, declarations, positions and cell mappings: {', '.join('`'+x+'`' for x in f['proofArtifacts'])}. The `#id` suffix identifies a JSON entry, not a URI fragment.

'''
md+='''## Both capability fixed points

AST inspection confirms the directed transfer loops occur inside `while (changed)`:

```js
// scripts/check-product-boundary.mjs:774
for (const [body, parameter] of lexical.initialTransfers)
  bind(identity(body), parameter)

// scripts/boundary-code-execution.mjs:353
for (const [body, parameter] of lexical.initialTransfers)
  record(identity(body), classify(parameter))
```

Those loops are present and directed correctly for distinct keys. They cannot repair a self edge or incorrectly owned declaration returned by the shared lexical helper. The neutral symbolic proof seeds a parameter label and then a separate body label: destructuring causes both labels to appear in the parameter/default closure cell, proving identity contamination without evaluating source text. This is a mapping proof, not a claim about native behavior or a demonstrated capability escape.

## Verification and exact evidence

- Supplied suite: **132/132 passed**, one test file, exit 0. Includes 61 neutral controls, 61 unknown controls requiring `INCOMPLETE`/`passed=false` and a reason, and 10 identity/environment checks. Unmodified test SHA-256: `cc500112e5c39584976504d4ecb21783c2eda1c396ba6ede79a7d30d4a1cf7d2`.
- Independent first probes: **27/32 passed**, five failed checks across four defect families; exit 1 intentionally records failed review assertions. Six own neutral analyzer controls pass. Exact input text, mappings and checks: [neutral-probes.json](neutral-probes.json); console output: [neutral-probes.log](neutral-probes.log).
- Expanded confirmations: **13 parse-only cases, zero parse diagnostics**, including `.mjs`/`.mts` body array/object/computed destructuring, catch with/without body var, simple function precedence and an erased computed type. [confirm-neutral.json](confirm-neutral.json) and [confirm-neutral-expanded.log](confirm-neutral-expanded.log) contain exact outputs. They are observational confirmations, not an all-green acceptance test.
- Positive invariants verified in the first probes include simple-var/rest/destructuring-without-expression sharing; direct default parameter/body-var separation and one-way copying; body function precedence with expression parameters and var/function declaration ordering; nested closures/defaults/body environments; block function/let shadows; computed parameter binding; outer initializer resolution; scalar own metadata and neutral reexports. Failed variants are reported above.
- Supplied test outputs: [supplied-tests.json](supplied-tests.json), [supplied-tests.log](supplied-tests.log). No original native code-execution suite was copied or run.

'''
md+=f'''Runtime used the approved readonly executable `/home/ricardo/.nvm/versions/node/v22.23.2/bin/node` ({report['execution']['nodeVersion']}). Dependencies and the four scanner modules/test were physically copied to `output/runtime`; all vendor symlinks were omitted. Runtime inode and link checks found zero shared Source inodes and zero runtime links. All 17,351 copied regular files retained frozen hashes after execution. `env -i` set HOME, TMPDIR and caches entirely inside output. Source/node_modules was never executed or used for cache.

The scanner's existing fixed trusted Node `--eval` helper resolves filenames only; it never imports or evaluates fixture contents. The allowed supplied tests and own neutral reexport scans can invoke that resolver. Independent identity confirmations only inspect AST/checker mappings and symbolic neutral labels. No generated fixture was imported, invoked or evaluated.

Full executable command strings and exit codes are in [commands.json](commands.json). In particular, the supplied suite ran from `{r}`:

```sh
{commands[3]['cmd']}
```

The initial before snapshot command is preserved verbatim in [integrity-before-command.txt](integrity-before-command.txt). Final integrity command:

```sh
{commands[-1]['cmd']}
```

## Source integrity and cleanup

**Complete before/after integrity: unchanged.**

```json
{json.dumps({k:i[k] for k in ['snapshotEntriesBefore','snapshotEntriesAfter','regularFiles','links','directories','frozenEntries','inventorySha256','beforeSnapshotSha256','afterSnapshotSha256','fullMetadataDifferences','frozenContentDifferences','outputSharedSourceInodes','outputSymlinks','valid']},indent=2)}
```

Comparison includes device/inode, mode, link count, size, file and directory nanosecond mtimes/ctimes, regular-file SHA-256 and symlink targets. It covers the Source root and all descendants, including original tests, schemas, roots, vendor, dist, bar and hashes. No symlink traversal. The inventory count includes 19,334 regular files and 48 links. Exact evidence: [integrity-before.json](integrity-before.json), [integrity-after.json](integrity-after.json), [integrity-summary.json](integrity-summary.json), [integrity-differences.json](integrity-differences.json), [integrity-after.log](integrity-after.log), [runtime-isolation.json](runtime-isolation.json), [runtime-execution-integrity.json](runtime-execution-integrity.json).

Two local comparator bookkeeping corrections are documented in `report.json`: the first inventory comparison used `symlink` rather than the frozen `link` label; the first runtime comparison included the reviewer's own synthetic package.json. Corrected comparisons are exact; neither correction changed Source or hid a source-content mismatch. Initial diagnostic artifacts remain available.

Cleanup removed only this review's copied dependencies, HOME, tmp and caches; [cleanup.json](cleanup.json) lists exact paths. Copied scanner/test text, neutral proof scripts/fixtures and evidence are retained. No Root/source file, original test, schema, lockfile, vendor, bar or repository ledger was changed. No provider/env inspection, PG, Docker, network, subagent, commit, push, deploy or production action occurred.

## Remaining uncertainty

61 supplied unknown controls remain `INCOMPLETE`, not PASS. The whole installed repository scanner was not run: broader installed/frontier assurance remains **INCOMPLETE**. The 132 green inert cases and six neutral controls grant no native/adversarial/integrated/release claim. Correct the four defects and obtain a new independent static review; integrated gates remain separately required.
'''
(o/'report.md').write_text(md)
artifacts={}
for path in sorted(o.rglob('*')):
 if path.is_file() and path.name!='evidence-manifest.json':
  artifacts[str(path.relative_to(o))]={'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
json.dump({'reviewId':report['reviewId'],'verdict':report['verdict'],'artifacts':artifacts},open(o/'evidence-manifest.json','w'),indent=2)
print(json.dumps({'verdict':report['verdict'],'reviewValid':report['reviewValid'],'blockingFindings':len(findings),'sourceIntegrityUnchanged':i['valid'],'reportMd':str(o/'report.md'),'reportJson':str(o/'report.json'),'evidenceArtifacts':len(artifacts)},indent=2))
