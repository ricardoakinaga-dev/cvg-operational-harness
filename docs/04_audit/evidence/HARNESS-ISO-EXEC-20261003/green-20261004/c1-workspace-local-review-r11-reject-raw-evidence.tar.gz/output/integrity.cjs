const fs=require('fs'),p=require('path'),c=require('crypto');
const base=p.resolve('source'), sealed=JSON.parse(fs.readFileSync('frozen-inventory.json'));
const sha=x=>c.createHash('sha256').update(x).digest('hex');
const entries={},meta={},issues=[];
function walk(dir,rel=''){const s=fs.lstatSync(dir,{bigint:true});meta[rel||'.']={mode:String(s.mode),mtimeNs:String(s.mtimeNs),kind:s.isDirectory()?'directory':s.isSymbolicLink()?'link':'file'};if(s.isDirectory()){for(const n of fs.readdirSync(dir).sort())walk(p.join(dir,n),rel?rel+'/'+n:n);}else if(s.isSymbolicLink()){entries[rel]={kind:'link',target:fs.readlinkSync(dir)};}else{const b=fs.readFileSync(dir);entries[rel]={bytes:b.length,kind:'file',sha256:sha(b)};}}
walk(base);
for(const [k,v] of Object.entries(sealed)){if(JSON.stringify(entries[k])!==JSON.stringify(v))issues.push({path:k,expected:v,actual:entries[k]});}
for(const k of Object.keys(entries))if(!sealed[k])issues.push({unexpected:k});
const groups={source:{},dependencies:{},dist:{}};for(const [k,v] of Object.entries(entries)){const cat=k.split('/').includes('node_modules')?'dependencies':k.split('/').includes('dist')?'dist':'source';groups[cat][k]=v;}
const result={inventoryFileSha256:sha(fs.readFileSync('frozen-inventory.json')),entries:Object.keys(entries).length,issues,groupHashes:Object.fromEntries(Object.entries(groups).map(([k,v])=>[k,sha(JSON.stringify(v))])),metadataHash:sha(JSON.stringify(meta))};
const phase=process.argv[2];fs.writeFileSync('output/integrity-'+phase+'.json',JSON.stringify(result,null,2));fs.writeFileSync('output/metadata-'+phase+'.json',JSON.stringify(meta));console.log(JSON.stringify(result,null,2));if(issues.length)process.exitCode=1;
