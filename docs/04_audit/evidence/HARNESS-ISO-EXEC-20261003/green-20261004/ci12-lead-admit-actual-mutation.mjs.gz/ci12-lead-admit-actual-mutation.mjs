import fs from 'node:fs'
import { snapshotTypes } from '../candidate/scripts/hiso-snapshot-types.mjs'
const output = new URL('./actual-mutation-type-snapshot.json',import.meta.url)
const report = JSON.parse(fs.readFileSync(new URL('../candidate/certification/mutation-guard.json', import.meta.url),'utf8'))
const receipt = snapshotTypes(report, 'mutation', output.pathname)
fs.writeFileSync(new URL('./actual-mutation-admission.json',import.meta.url), JSON.stringify({actualReport: true, selected:report.selected,killed:report.killed,survived:report.survived,timedOut:report.timedOut,errors:report.errors,receipt},null,2)+'\n')
console.log('actual native mutation admission PASS: 10 selected / 10 KILLED')
