import json
import os
from pathlib import Path
import subprocess
import sys
import time

packet = Path(__file__).resolve().parent.parent
candidate = packet / 'candidate'
output = packet / 'output'
env = {
    'PATH': str(output / 'toolchain/bin') + ':/usr/bin:/bin',
    'HOME': str(output / 'home'),
    'TMPDIR': str(output / 'tmp'),
    'TMP': str(output / 'tmp'),
    'TEMP': str(output / 'tmp'),
    'XDG_CACHE_HOME': str(output / 'cache'),
    'npm_config_cache': str(output / 'cache/npm'),
    'npm_config_offline': 'true',
    'CI': '1',
    'TZ': 'UTC',
    'LANG': 'C.UTF-8',
    'CVG_MANIFEST_RUNTIME_PROOF_DIR': str(output / sys.argv[1] / 'cases'),
}
name, *command = sys.argv[1:]
directory = output / name
directory.mkdir(exist_ok=True)
started = time.time()
with (directory / 'stdout.log').open('w') as stdout, (directory / 'stderr.log').open('w') as stderr:
    try:
        result = subprocess.run(command, cwd=candidate, env=env, stdout=stdout, stderr=stderr, timeout=600)
        code = result.returncode
    except subprocess.TimeoutExpired:
        code = 124
record = {'command': command, 'cwd': str(candidate), 'env': env, 'startedAt': started,
          'endedAt': time.time(), 'exitStatus': code, 'stdout': str(directory / 'stdout.log'),
          'stderr': str(directory / 'stderr.log'), 'evidenceKind': 'COMMAND', 'status': 'EXECUTED'}
(directory / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
print((directory / 'stdout.log').read_text()[-4500:])
print((directory / 'stderr.log').read_text()[-4500:])
sys.exit(code)
