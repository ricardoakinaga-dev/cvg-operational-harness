import { auditProductBoundary } from '../candidate/scripts/check-product-boundary.mjs'

Error.stackTraceLimit = 100
try {
  const report = auditProductBoundary(process.cwd())
  console.log(JSON.stringify(report, null, 2))
  process.exitCode = report.passed ? 0 : 1
} catch (error) {
  console.error(error.stack)
  process.exitCode = 2
}
