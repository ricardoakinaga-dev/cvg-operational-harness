import json,os
from pathlib import Path
base=Path(__file__).resolve().parent; suite=base/'discriminants';suite.mkdir(exist_ok=True); cases=[]
fields=['dependencies','devDependencies','optionalDependencies','peerDependencies']
def add(name,expected,changes=None,root_context=False,opaque=False,links=None):
 r=suite/name;r.mkdir(exist_ok=True)
 data={'package.json':{'private':True,'type':'module','workspaces':['packages/*','products/*']},'packages/core/package.json':{'name':'@synthetic/core','type':'module'},'packages/core/src/index.mts':'export const label="core";','products/consumer/package.json':{'name':'@synthetic/consumer','type':'module'},'products/consumer/src/index.mts':'export const label="consumer";','tsconfig.base.json':{'compilerOptions':{'module':'NodeNext','moduleResolution':'NodeNext','target':'ESNext','allowJs':True}}}
 for d in ['apps','legacy','packages','products']: (r/d).mkdir(exist_ok=True)
 if root_context:
  data.update({'packages/core/src/index.mts':'import "../../../auxiliary/bridge.mts";','auxiliary/bridge.mts':'export const label="bridge";'})
 else:
  data.update({'auxiliary/bridge/package.json':{'name':'@synthetic/bridge','type':'module'},'auxiliary/bridge/src/index.mts':'export const label="bridge";'})
  if not opaque:data['packages/core/src/index.mts']='import "../../../auxiliary/bridge/src/index.mts";'
 if changes:data.update(changes)
 for rel,value in data.items():
  p=r/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(value if isinstance(value,str) else json.dumps(value,indent=2)+'\n')
 for rel,target in (links or {}).items():
  p=r/rel;p.parent.mkdir(parents=True,exist_ok=True);p.unlink(missing_ok=True);os.symlink(target,p)
 cases.append({'id':name,'expected':expected,'root':str(r),'fixtureTextExecuted':False,'changes':changes or {},'links':links or {},'rootContext':root_context,'opaque':opaque})
add('reached-neutral','PASS')
for prefix,rootctx,opaque in [('reached',False,False),('opaque',False,True),('root-context',True,False)]:
 for kind,value in [('array',[]),('invalid-type',{'type':'invalid'}),('invalid-depmap',{'dependencies':[]}),('missing-local',{'dependencies':{'label':'file:missing'}}),('malformed-alias',{'dependencies':{'label':'npm:neutral@file:missing'}})]:
  add(prefix+'-'+kind,'BLOCK' if prefix=='reached' else 'PASS',{'auxiliary/bridge/dist/nested/package.json':value},rootctx,opaque)
 add(prefix+'-symlink','BLOCK' if prefix=='reached' else 'PASS',{'auxiliary/bridge/dist/nested/target.json':{'type':'module'}},rootctx,opaque,{'auxiliary/bridge/dist/nested/package.json':'target.json'})
 for fld in fields:
  add(prefix+'-nested-product-'+fld,'FAIL' if prefix=='reached' else 'PASS',{'auxiliary/bridge/dist/nested/package.json':{fld:{'@synthetic/consumer':'1.0.0'}}},rootctx,opaque)
  add(prefix+'-nested-alias-product-'+fld,'FAIL' if prefix=='reached' else 'PASS',{'auxiliary/bridge/dist/nested/package.json':{fld:{'neutral':'npm:@synthetic/consumer@1.0.0'}}},rootctx,opaque)
  add(prefix+'-nested-local-product-'+fld,'FAIL' if prefix=='reached' else 'PASS',{'auxiliary/bridge/dist/nested/package.json':{fld:{'neutral':'file:../../../../products/consumer'}}},rootctx,opaque)
for fld in fields:
 add('nearest-product-'+fld,'FAIL',{'auxiliary/bridge/package.json':{'name':'@synthetic/bridge','type':'module',fld:{'@synthetic/consumer':'1.0.0'}}})
 add('nearest-alias-product-'+fld,'FAIL',{'auxiliary/bridge/package.json':{'name':'@synthetic/bridge','type':'module',fld:{'neutral':'npm:@synthetic/consumer@1.0.0'}}})
 add('nearest-local-product-'+fld,'FAIL',{'auxiliary/bridge/package.json':{'name':'@synthetic/bridge','type':'module',fld:{'neutral':'file:../../products/consumer'}}})
for actor in ['tools','scripts','examples','config','legacy','packages','apps','products']:
 add('global-invalid-'+actor,'BLOCK',{actor+'/nested/dist/package.json':[]},opaque=True)
 add('declared-parent-invalid-'+actor,'BLOCK',{'package.json':{'private':True,'type':'module','workspaces':['packages/*','products/*',actor+'/workspaces/*']},actor+'/workspaces/archive/dist/package.json':[]},opaque=True)
for spec in ['file:../../products/%63onsumer','link:../../products/consumer','npm:@synthetic/consumer@latest']:
 add('core-dep-'+str(len(cases)),'FAIL',{'packages/core/package.json':{'name':'@synthetic/core','dependencies':{'neutral':spec}}},opaque=True)
# Local nested nonworkspace contexts must not discard a known transitive edge.
for fld in fields:
 add('nested-transitive-'+fld,'FAIL',{'auxiliary/bridge/dist/package.json':{fld:{'neutral':'file:../../../auxiliary/target'}},'auxiliary/target/package.json':{'name':'@synthetic/target',fld:{'@synthetic/consumer':'1.0.0'}},'auxiliary/target/src/index.mts':'export const label="target";'})
# Reached .json/.css still establishes nearest Node package actor.
for ext,text in [('json','{"label":"bridge"}'),('css','body {color: blue;}')]:
 add('asset-context-'+ext,'BLOCK',{'packages/core/src/index.mts':'import "../../../auxiliary/bridge/asset.'+ext+'";','auxiliary/bridge/asset.'+ext:text,'auxiliary/bridge/dist/package.json':[]})
# Reached implementation closure and runtime grammar, never evaluated.
texts=[('dynamic-import','import(label);','INCOMPLETE'),('unresolved','import "./missing.mts";','INCOMPLETE'),('builtin','import "node:fs";','PASS'),('shadow-loader','function require(label){return label};require("./missing.mts");','PASS'),('shadow-loader-plus-edge','function require(label){return label};require("./missing.mts");import "../../../products/consumer/src/index.mts";','FAIL'),('global-alias','const host=globalThis;host["require"](label);','INCOMPLETE'),('catch-shadow','try{throw "label"}catch(require){require("label");}','PASS'),('loader-destructure','const {require:load}=globalThis;load(label);','INCOMPLETE'),('unknown-format','import "../../../auxiliary/bridge/label.txt";','INCOMPLETE')]
for label,text,status in texts:
 add('lexical-'+label,status,{'packages/core/src/index.mts':text,'auxiliary/bridge/label.txt':'label'},opaque=True)
for ext in ['js','mjs','cjs']:
 for label,text in [('type','const label: string="label";'),('duplicate','const label=1; const label=2;'),('return','return "label";'),('await','await Promise.resolve("label");')]:
  expected='INCOMPLETE' if label in ['type','duplicate'] or (label=='return' and ext!='cjs') or (label=='await' and ext=='cjs') else 'PASS'
  add('grammar-'+ext+'-'+label,expected,{'packages/core/src/entry.'+ext:text},opaque=True)
for ext in ['ts','tsx','mts','cts','jsx']:
 add('grammar-neutral-'+ext,'PASS',{'packages/core/src/entry.'+ext:'const label="neutral";'},opaque=True)
 add('grammar-malformed-'+ext,'INCOMPLETE',{'packages/core/src/entry.'+ext:'const = ;'},opaque=True)
# A nested context physically governing the referenced file is a direct control.
add('referenced-dist-product','FAIL',{'packages/core/src/index.mts':'import "../../../auxiliary/bridge/dist/index.mts";','auxiliary/bridge/dist/index.mts':'export const label="nested";','auxiliary/bridge/dist/package.json':{'dependencies':{'@synthetic/consumer':'1.0.0'}}})
add('context-json-symlink','BLOCK',links={'auxiliary/bridge/package.json':'../bridge-manifest.json'},changes={'auxiliary/bridge-manifest.json':{'name':'@synthetic/bridge'}})
add('deep-invalid-local-child','BLOCK',{'auxiliary/bridge/dist/package.json':{'dependencies':{'neutral':'file:../../../auxiliary/target'}},'auxiliary/target/package.json':{'name':'@synthetic/target'},'auxiliary/target/dist/package.json':[]})
(base/'discriminants.json').write_text(json.dumps(cases,indent=2)+'\n');print('new_inert_discriminants',len(cases))
