import socket,json
results=[]
for fam in [socket.AF_INET,socket.AF_INET6,socket.AF_UNIX]:
 try: socket.socket(fam,socket.SOCK_STREAM);results.append({'family':fam,'blocked':False})
 except OSError as e:results.append({'family':fam,'blocked':e.errno==1,'errno':e.errno})
print(json.dumps({'kind':'guard-selftest-only','attempts':results,'allBlocked':all(x['blocked'] for x in results)}))
assert all(x['blocked'] for x in results)
