from pathlib import Path
import json,shutil
out=Path(__file__).resolve().parent;cases=json.loads((out/'discriminants.json').read_text()); new=[]
for holder in ['nearest','nested']:
 for field in ['dependencies','devDependencies','optionalDependencies','peerDependencies']:
  name=holder+'-nonworkspace-local-'+field;r=out/'discriminants'/name;shutil.copytree(out/'discriminants/reached-neutral',r)
  if holder=='nearest':p=r/'auxiliary/bridge/package.json';value={'name':'@synthetic/bridge','type':'module',field:{'neutral':'file:../target'}}
  else:p=r/'auxiliary/bridge/dist/package.json';value={field:{'neutral':'file:../../target'}}
  p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value)+'\n')
  p=r/'auxiliary/target/package.json';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps({'name':'@synthetic/target','type':'module'})+'\n')
  new.append({'id':name,'expected':'INCOMPLETE','root':str(r),'fixtureTextExecuted':False,'changes':{str(p.relative_to(r)):{'name':'@synthetic/target'},'holder':holder,'field':field},'links':{},'rootContext':False,'opaque':False})
(out/'discriminants-extra.json').write_text(json.dumps(new,indent=2)+'\n')
(out/'discriminants.json').write_text(json.dumps(cases+new,indent=2)+'\n')
