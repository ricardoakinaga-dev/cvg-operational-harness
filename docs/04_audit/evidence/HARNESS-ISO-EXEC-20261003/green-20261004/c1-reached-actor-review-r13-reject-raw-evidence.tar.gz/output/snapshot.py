import os,json,hashlib,stat,sys
from pathlib import Path
base=Path(__file__).resolve().parent.parent
root=base/'source'; sealed=json.loads((base/'frozen-inventory.json').read_bytes())
entries={}; metadata={}
def visit(p):
 st=p.lstat(); rel=str(p.relative_to(root)) or '.'
 metadata[rel]={'mode':st.st_mode,'size':st.st_size,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns,'dev':st.st_dev,'ino':st.st_ino,'nlink':st.st_nlink}
 if stat.S_ISLNK(st.st_mode):entries[rel]={'kind':'link','target':os.readlink(p)}
 elif stat.S_ISDIR(st.st_mode):
  for child in sorted(p.iterdir()):visit(child)
 elif stat.S_ISREG(st.st_mode):
  b=p.read_bytes(); entries[rel]={'bytes':len(b),'kind':'file','sha256':hashlib.sha256(b).hexdigest()}
 else:entries[rel]={'kind':'special'}
visit(root)
diff={k:{'sealed':sealed.get(k),'actual':entries.get(k)} for k in sorted(set(sealed)|set(entries)) if sealed.get(k)!=entries.get(k)}
name=sys.argv[1]
out={'entries':entries,'metadata':metadata,'counts':{'entries':len(entries),'files':sum(v['kind']=='file' for v in entries.values()),'links':sum(v['kind']=='link' for v in entries.values()),'directories':len(metadata)-len(entries)},'inventoryDifference':diff}
(base/'output'/f'{name}.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps({'phase':name,'counts':out['counts'],'inventoryDifferences':len(diff)}))
