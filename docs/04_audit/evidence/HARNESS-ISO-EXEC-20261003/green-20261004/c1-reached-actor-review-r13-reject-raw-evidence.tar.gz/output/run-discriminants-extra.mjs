import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
const out=path.resolve('..');const checker=path.resolve('scripts/check-product-boundary.mjs');
const cases=JSON.parse(fs.readFileSync(path.join(out,'discriminants-extra.json'),'utf8'));const rows=[];
for(const c of cases){
 const start=performance.now();const result=spawnSync(process.execPath,[checker,c.root],{encoding:'utf8',timeout:30000,maxBuffer:8*1024*1024});
 fs.writeFileSync(path.join(out,'discriminants',c.id+'.stdout'),result.stdout??'');fs.writeFileSync(path.join(out,'discriminants',c.id+'.stderr'),result.stderr??'');
 let audit;try{audit=JSON.parse(result.stdout);}catch{}
 const matches=c.expected==='BLOCK'?result.status!==0:(audit?.status===c.expected&&result.status===(c.expected==='PASS'?0:1));
 const row={...c,exitCode:result.status,signal:result.signal,error:result.error?.message,audit,matches,durationMs:performance.now()-start,stdout:'discriminants/'+c.id+'.stdout',stderr:'discriminants/'+c.id+'.stderr',argv:[process.execPath,checker,c.root]};rows.push(row);
 fs.writeFileSync(path.join(out,'discriminants-extra-results.json'),JSON.stringify(rows,null,2)+'\n');
 if(!matches)console.log(JSON.stringify({id:c.id,expected:c.expected,actual:audit?.status,exitCode:result.status}));
}
console.log(JSON.stringify({cases:rows.length,matched:rows.filter(x=>x.matches).length,mismatches:rows.filter(x=>!x.matches).length,fixturesExecuted:false}));
