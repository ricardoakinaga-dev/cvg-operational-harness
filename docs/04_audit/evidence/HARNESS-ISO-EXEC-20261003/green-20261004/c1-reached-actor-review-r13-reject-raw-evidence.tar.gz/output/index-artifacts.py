from pathlib import Path
import json,hashlib,os,stat
out=Path(__file__).resolve().parent;entries={};dirs={}
def walk(p):
 rel=str(p.relative_to(out));st=p.lstat()
 if rel=='artifacts.json':return
 if p.is_symlink():entries[rel]={'kind':'link','literalTarget':os.readlink(p)}
 elif p.is_dir():
  dirs[rel]={'mode':st.st_mode,'mtime_ns':st.st_mtime_ns}
  for child in sorted(p.iterdir()):walk(child)
 else:
  b=p.read_bytes();entries[rel]={'kind':'file','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
walk(out)
(out/'artifacts.json').write_text(json.dumps({'excludedSelf':'artifacts.json','entries':entries,'directories':dirs,'counts':{'entries':len(entries),'directories':len(dirs)}},indent=2)+'\n')
print(json.dumps({'indexedArtifacts':len(entries),'directories':len(dirs)}))
