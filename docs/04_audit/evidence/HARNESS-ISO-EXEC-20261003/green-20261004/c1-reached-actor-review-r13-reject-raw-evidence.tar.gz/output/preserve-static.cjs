const fs=require('node:fs');const path=require('node:path');const rm=fs.rmSync;
fs.rmSync=function(p,...args){if(typeof p==='string' && p.startsWith(process.env.TMPDIR+path.sep+'cvg-c1-lexical-static-')) return;return rm.call(this,p,...args)};
