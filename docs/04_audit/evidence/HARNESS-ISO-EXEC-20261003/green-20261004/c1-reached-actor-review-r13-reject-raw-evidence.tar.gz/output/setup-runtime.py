from pathlib import Path
import shutil,os,json
base=Path(__file__).resolve().parent.parent; src=base/'source'; dst=base/'output/runtime'; dst.mkdir()
auth=json.loads((base/'authority.json').read_text())
# Copy infrastructure and effective code physically. Documentary and procedural inputs stay opaque.
for item in src.iterdir():
 if item.name in {'docs','certification','AGENTS.md','README.md','tests'}:continue
 if item.is_dir():shutil.copytree(item,dst/item.name,symlinks=True)
 elif item.is_symlink():os.symlink(os.readlink(item),dst/item.name)
 else:shutil.copy2(item,dst/item.name)
(dst/'tests').mkdir();shutil.copy2(src/'tests/product-boundary-lexical-static.test.js',dst/'tests/product-boundary-lexical-static.test.js')
for name in auth['legacyMachineFixtures']:
 target=dst/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src/name,target)
# No dependency link may escape this private physical runtime.
links=[]
for p in dst.rglob('*'):
 if p.is_symlink():
  resolved=p.resolve();assert resolved.is_relative_to(dst),str(p);links.append({'path':str(p.relative_to(dst)),'literalTarget':os.readlink(p),'physicalTarget':str(resolved.relative_to(dst))})
(base/'output/runtime-links.json').write_text(json.dumps(links,indent=2)+'\n')
print(json.dumps({'runtime':str(dst),'links':len(links),'staticTestShaUnchanged':(src/'tests/product-boundary-lexical-static.test.js').read_bytes()==(dst/'tests/product-boundary-lexical-static.test.js').read_bytes()}))
