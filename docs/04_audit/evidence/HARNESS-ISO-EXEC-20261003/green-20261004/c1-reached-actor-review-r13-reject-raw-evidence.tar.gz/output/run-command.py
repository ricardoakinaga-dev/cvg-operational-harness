import os,subprocess,json,time,sys
from pathlib import Path
base=Path(__file__).resolve().parent;label=sys.argv[1];cwd=base/'runtime';cmd=sys.argv[2:]
env={'PATH':'/home/ricardo/.nvm/versions/node/v22.23.2/bin:/usr/bin:/bin','HOME':str(base),'TMPDIR':str(base/'tmp'),'LANG':'C.UTF-8','CI':'1','NODE_OPTIONS':'--require='+str(base/'preserve-static.cjs')}
full=['strace','-f','-qq','-e','trace=%network','-o',str(base/(label+'.network.trace')),str(base/'guard'),*cmd]
start=time.time()
with open(base/(label+'.stdout'),'w') as out,open(base/(label+'.stderr'),'w') as err:
 try:p=subprocess.run(full,cwd=cwd,env=env,stdout=out,stderr=err,timeout=420);rc=p.returncode
 except subprocess.TimeoutExpired:rc=124
record={'label':label,'cwd':str(cwd),'argv':full,'environment':env,'exitCode':rc,'durationSeconds':time.time()-start,'stdout':label+'.stdout','stderr':label+'.stderr','networkTrace':label+'.network.trace'}
(base/(label+'.command.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
