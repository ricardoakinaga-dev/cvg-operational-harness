import json,os,re,collections,hashlib
from pathlib import Path
out=Path(__file__).resolve().parent;packet=out.parent;source=packet/'source'
raw=json.loads((out/'discriminants-results.json').read_text())+json.loads((out/'discriminants-extra-results.json').read_text())
(out/'all-discriminants-results.json').write_text(json.dumps(raw,indent=2)+'\n')
net={}
for p in out.glob('*.network.trace'):
 rows=p.read_text().splitlines();calls=collections.Counter();external=[];ipc=0
 for line in rows:
  m=re.search(r'\b([a-z0-9_]+)\(',line)
  if not m:continue
  name=m[1];calls[name]+=1
  if name=='socketpair' and 'AF_UNIX' in line:ipc+=1;continue
  if name in {'setsockopt','getsockopt','getsockname','getpeername','shutdown'}:continue
  external.append(line)
 net[p.name]={'selftestOnly':p.name.startswith('guard-selftest'),'syscallCounts':dict(calls),'localUnixSocketpairCalls':ipc,'externalCandidateLines':external,'actualExternalSuccessCount':sum(' = -1 ' not in x for x in external),'externalAttemptCount':len(external),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
review=[v for v in net.values() if not v['selftestOnly']]
network={'nativeGuard':'seccomp-BPF, inherited by CLI children and runner threads; x86_64 only; denies sockets/connect/bind/listen/accept/send/recv and io_uring; AF_UNIX socketpair remains trusted local IPC','reviewExternalAttempts':sum(v['externalAttemptCount'] for v in review),'reviewActualExternalIO':sum(v['actualExternalSuccessCount'] for v in review),'selftestsExplicitlySeparate':True,'traces':net,'filesystemAndLocalIPC':'Local files and runner/resolver IPC necessarily perform I/O; zero actual I/O means zero external network/DNS/PG/provider I/O.'}
(out/'network-summary.json').write_text(json.dumps(network,indent=2)+'\n')
seal=json.loads((packet/'frozen-inventory.json').read_text());mirrors=[];omitted=[];differences=[]
for rel,expected in seal.items():
 p=out/'runtime'/rel
 if not p.exists() and not p.is_symlink():omitted.append(rel);continue
 if p.is_symlink():actual={'kind':'link','target':os.readlink(p)}
 else:
  b=p.read_bytes();actual={'kind':'file','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 mirrors.append(rel)
 if actual!=expected:differences.append({'path':rel,'expected':expected,'actual':actual})
mirror={'physicalRuntime':str(out/'runtime'),'mirroredEntries':len(mirrors),'omittedEntries':omitted,'differences':differences,'allMirroredEntriesExact':not differences,'testSourceUnchanged':hashlib.sha256((out/'runtime/tests/product-boundary-lexical-static.test.js').read_bytes()).hexdigest()==seal['tests/product-boundary-lexical-static.test.js']['sha256'],'documentaryFiles':'No archives/procedural documents or excluded executing test suite were copied. The seven explicitly authorized machine fixtures alone were mirrored. All dependencies, dist and code actor roots were physically copied.'}
(out/'runtime-binding.json').write_text(json.dumps(mirror,indent=2)+'\n')
# Bind review inputs by literal name to sealed inventory, including all authorized fixture bytes.
auth=json.loads((packet/'authority.json').read_text()); paths=['scripts/check-product-boundary.mjs','scripts/boundary-manifests.mjs','scripts/boundary-lexical.mjs','scripts/boundary-code-execution.mjs','scripts/tsconfig-path-grammar.mjs','package.json','package-lock.json','tsconfig.base.json','tests/product-boundary-lexical-static.test.js']+auth['legacyMachineFixtures']
(out/'review-inputs.json').write_text(json.dumps({p:seal[p] for p in paths},indent=2)+'\n')
print(json.dumps({'newCases':len(raw),'matched':sum(x['matches'] for x in raw),'mismatches':sum(not x['matches'] for x in raw),'networkExternalAttempts':network['reviewExternalAttempts'],'networkActualExternalIO':network['reviewActualExternalIO'],'mirroredEntries':len(mirrors),'runtimeDifferences':len(differences),'opaqueEntriesNotCopied':len(omitted)}))
