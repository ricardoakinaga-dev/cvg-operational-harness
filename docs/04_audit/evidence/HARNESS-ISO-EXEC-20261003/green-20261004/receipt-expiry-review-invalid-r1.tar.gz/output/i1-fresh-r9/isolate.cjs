const fs=require('node:fs'),path=require('node:path');
for(const n of ['vitest.log','test-results.json','probe-trace.jsonl'])if(fs.existsSync(path.join(__dirname,n)))fs.copyFileSync(path.join(__dirname,n),path.join(__dirname,'first-'+n));
const dep=path.join(__dirname,'node_modules'),src=path.resolve(__dirname,'../../source/node_modules');
if(!fs.lstatSync(dep).isSymbolicLink())throw Error('expected own dependency symlink');fs.unlinkSync(dep);fs.mkdirSync(dep);
for(const n of fs.readdirSync(src))if(!n.startsWith('.'))fs.symlinkSync(path.join(src,n),path.join(dep,n));
fs.mkdirSync(path.join(dep,'.vite-temp'));
const before=JSON.parse(fs.readFileSync(path.join(__dirname,'before.json'))),after=JSON.parse(fs.readFileSync(path.join(__dirname,'interim.json'))),m=new Map(before.map(x=>[x.path,x]));
const diff=after.filter(x=>JSON.stringify(x)!==JSON.stringify(m.get(x.path))).map(x=>({before:m.get(x.path),after:x}));
fs.writeFileSync(path.join(__dirname,'readonly-violation.json'),JSON.stringify({cause:'default Vite config bundler created then removed config temp through initial output/node_modules symlink; source .vite-temp mtime changed',diff,restored:false},null,2));
