const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const packet = path.resolve(__dirname, '../..');
const rows = [];
function visit(p, rel) {
  const s = fs.lstatSync(p, {bigint:true});
  const row = {path:rel, mode:s.mode.toString(), mtimeNs:s.mtimeNs.toString(), type:s.isDirectory()?'dir':s.isSymbolicLink()?'link':s.isFile()?'file':'other'};
  if(s.isFile()) {const b=fs.readFileSync(p); row.bytes=b.length; row.sha256=crypto.createHash('sha256').update(b).digest('hex');}
  if(s.isSymbolicLink()) row.target=fs.readlinkSync(p);
  rows.push(row);
  if(s.isDirectory()) for(const n of fs.readdirSync(p).sort()) visit(path.join(p,n),rel+'/'+n);
}
for(const root of ['source','original']) visit(path.join(packet,root),root);
const body=JSON.stringify(rows,null,2)+'\n';
fs.writeFileSync(path.join(__dirname,process.argv[2]+'.json'),body);
const summary={entries:rows.length,sourceEntries:rows.filter(r=>r.path.startsWith('source')).length,sha256:crypto.createHash('sha256').update(body).digest('hex')};
fs.writeFileSync(path.join(__dirname,process.argv[2]+'-summary.json'),JSON.stringify(summary,null,2)+'\n');
console.log(summary);
