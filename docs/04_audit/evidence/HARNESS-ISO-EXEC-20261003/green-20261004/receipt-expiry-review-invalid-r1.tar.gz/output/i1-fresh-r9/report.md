# I1 fresco — receipt expiry R9

Veredito: **INVALID**. A primeira execução alterou o mtime do diretório source/node_modules/.vite-temp ao carregar a configuração do Vitest através de um link de dependências criado em output. Essa violação de readonly invalida esta rodada, mesmo com resultados semânticos favoráveis. Nenhum arquivo de source/original mudou bytes ou modos; nenhuma entrada foi adicionada/removida no snapshot final. O mtime não foi restaurado ou ocultado. Evidência: readonly-violation.json e source-after-diff.json.

Packet: receipt-expiry-fresh-review-r9. Freeze declarado: cd0e22f84483820e95f763d95a9e96ee875ac062c092b74a37ed16f71e7f0306. Authority e freeze foram lidos antes de código. Os 21.191 descendentes de source/original coincidem com a contagem declarada; os snapshots adicionam os dois diretórios raiz (21.193 entradas). O digest declarado não foi reproduzido: os arquivos permitidos não especificam a serialização do freeze. Não equiparar nosso hash de snapshot ao SHA declarado.

## Resultado semântico observado

Segunda execução: 18/18 testes, incluindo os sete testes fornecidos copiados byte a byte e onze casos próprios. Mantidos timeout de 15.000 ms, 1.000 recibos e asserções originais. Os probes próprios compararam toda a projeção observável com vertical-state original e compararam o store original, incluindo igualdade de bytes do journal.

Foram exercitados 80 pares de extremos de Date/NaN, 2.500 eventos em ordem temporal mista, 60.031 comparações numéricas do predicado, matching real por eventos de outbox, rejeição causal por recepção anterior ao dispatch, saturação de 1.000 pendentes, admissão de matched além do cap, dedup após expiração, backdating após poda, rollback de admissão e poda, replay e falhas de sync tanto de poda quanto de admissão. As falhas depois do LF não publicaram projeção, sequência ou cache; a reabertura incorporou o registro completo e idempotente. Eventcounts do journal diferencial: [1,2,1,1], com quatro transações e bytes iguais nos dois stores.

Primeira execução: 12/13 passaram; o probe próprio com 2.500 eventos num único teste excedeu 15 s (27,982 s). Não foi falha semântica nem dos sete testes fornecidos. Mantive todo o fluxo contínuo e todas as asserções, dividindo-o em cinco casos sequenciais de 500 eventos, com o mesmo estado e PRNG e 15 s cada. O maior caso da segunda execução durou 10,843 s. Logs e JSON da primeira execução foram preservados com prefixo first-.

## Prova do limite conservador

Seja P o conjunto de recibos ainda não matched com receivedAt finito. O invariante necessário é B <= min(r + 86400000 para r em P), com mínimo vazio igual a Infinity. emptyVertical inicia B=Infinity. A admissão faz min(B,r+TTL); isso inclui matched e pode apenas tornar B pessimista. Matching somente adiciona chaves a deliveryMatches, removendo elementos de P e preservando o limite inferior. O único outro replacement de delivery preserva receivedAt. Não há remoção de matches que pudesse reintroduzir recibos sem atualizar B.

Se now <= B, nenhum recibo de P pode satisfazer now-r>TTL. Se now>B, a varredura mantém exatamente o predicado original para cada unmatched e reconstrói B com todos os sobreviventes finitos. Um relógio retroativo continua seguro porque nenhum passo depende de monotonicidade; uma nova recepção anterior reduz B. NaN no relógio torna ambos os predicados falsos; receivedAt NaN nunca expira pelo predicado original e não contamina B.

O domínio suportado de Date tem tempos inteiros em [-8640000000000000,8640000000000000]. r+TTL fica dentro do intervalo de inteiros exatos de IEEE-754, inclusive quando ultrapassa o máximo de Date; a soma permanece abaixo de 2^53. Perto da fronteira TTL, a diferença é exata; diferenças com eventual arredondamento em extremos opostos permanecem muito além de TTL. Portanto, sobre esse domínio, now-r>86400000 equivale a now>r+86400000. Não estendo essa equivalência a valores arbitrários de Number fora de Date.

## Validação, replay e complexidade

O diff de store adiciona somente a cópia do primitive B para a projeção temporária. A validação não publica esse objeto. O append e sync precedem publish. Após falha de batch ou sync, o estado vivo conserva seus mapas e B; após replay, emptyVertical mais os mesmos eventos reconstrói B. Não foi encontrado cache otimista persistente. Os diffs dos dois arquivos estão em store.diff e vertical-state.diff. Não há mudança textual em schema/journal/fsync nesses diffs; a igualdade de bytes/eventcounts foi observada nos casos executados.

O teste fornecido observou zero visitas de poda durante 1.001 eventos anteriores/iguais ao TTL e exatamente 1.000 na expiração. Isso demonstra eliminação da varredura de poda nessa carga. Admission/cap, clonagem de validação, reconciliação e workload misto continuam tendo custos próprios; não há alegação de O(1) para commit, estabilidade global de timing ou garantia ampla de desempenho. O limiar antigo <1300 permanece no source com bytes idênticos ao snapshot inicial e não foi executado, pois seu teste usa sockets fora da execução autorizada. Os testes antigos não foram modificados.

## Execução e integridade finitas

Node v22.23.2 com env -i; HOME/TMPDIR locais à saída, sem variáveis de provider/PG. Vitest usou workers threads, sem subagentes, instalação, commit ou rede solicitada. As guardas registraram 0 chamadas bloqueadas; guard-start identifica o processo e threads de ambas as execuções. As guardas cobrem APIs selecionadas de net/tls/dgram/http/https/dns/fetch/WebSocket/child_process. Isto é observação e bloqueio finitos em JavaScript, não enforcement de syscall nem prova exaustiva de ausência de syscalls. Não houve inspeção narrativa de documentação de dependências; snapshots só leram bytes opacos para hashing. Não foram lidos root, ledgers, env files, builder reports ou revisões externas ao packet autorizado.

before.json, interim.json e after.json registram hashes/bytes de arquivos, modos, mtimes em ns, diretórios e destinos de symlinks sem seguir links. A segunda execução usou um node_modules próprio em output com links individuais e .vite-temp próprio; interim e after são idênticos. A violação inicial permanece registrada e invalida a rodada. Os helpers foram criados em output; todos os logs de execução foram criados lá. O snapshot inicial começou depois da leitura de código e antes dos testes; não é um trace de syscalls dos comandos de leitura.

O selo finito manifest-seal.json inclui todas as entradas de output/i1-fresh-r9 exceto o próprio selo e a raiz, não segue symlinks e registra hash de cada arquivo. Não cobre árvore alvo de links nem artefatos externos; o before/after de source cobre explicitamente a árvore autorizada. Não concede release, cobertura global ou aprovação clínica. Nenhum ACCEPT é emitido por esta rodada.
