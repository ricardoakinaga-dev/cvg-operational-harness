const fs=require('node:fs'),module_=require('node:module');
const log=__dirname+'/network-trace.jsonl';
fs.appendFileSync(log,JSON.stringify({event:'guard-start',pid:process.pid,thread:require('node:worker_threads').threadId,node:process.version})+'\n');
function deny(api){return function(){fs.appendFileSync(log,JSON.stringify({event:'denied',api,pid:process.pid})+'\n');throw new Error('NETWORK0 '+api)}}
const net=require('node:net');net.connect=deny('net.connect');net.createConnection=deny('net.createConnection');net.Socket.prototype.connect=deny('Socket.connect');net.Server.prototype.listen=deny('Server.listen');
const tls=require('node:tls');tls.connect=deny('tls.connect');
const dgram=require('node:dgram');dgram.createSocket=deny('dgram.createSocket');
for(const name of ['node:http','node:https']){const m=require(name);m.request=deny(name+'.request');m.get=deny(name+'.get');}
const dns=require('node:dns');for(const k of ['lookup','resolve','resolve4','resolve6']) dns[k]=deny('dns.'+k);
globalThis.fetch=deny('fetch');globalThis.WebSocket=deny('WebSocket');
const cp=require('node:child_process');for(const k of ['spawn','spawnSync','exec','execSync','execFile','execFileSync','fork']) cp[k]=deny('child_process.'+k);
module_.syncBuiltinESMExports();
process.on('exit',code=>fs.appendFileSync(log,JSON.stringify({event:'guard-exit',pid:process.pid,code})+'\n'));
