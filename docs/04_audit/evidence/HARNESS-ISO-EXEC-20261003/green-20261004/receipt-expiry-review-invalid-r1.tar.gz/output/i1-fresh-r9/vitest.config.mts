import { defineConfig } from 'vitest/config'
export default defineConfig({
 root:import.meta.dirname,cacheDir:import.meta.dirname+'/tmp/vite-cache',envDir:import.meta.dirname,
 server:{hmr:false,ws:false},
 test:{environment:'node',testTimeout:15000,hookTimeout:15000,pool:'threads',maxWorkers:1,fileParallelism:false,
 include:['production/src/__tests__/receipt-performance-r9-own.test.ts','adversarial.test.ts'],
 reporters:['default','json'],outputFile:{json:import.meta.dirname+'/test-results.json'}}
})
