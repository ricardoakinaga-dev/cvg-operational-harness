import {it,expect} from 'vitest'
import * as fs from 'node:fs'
import {join} from 'node:path'
import {tmpdir} from 'node:os'
import {applyVertical,emptyVertical,inputDigest} from '../../source/products/shift-assistant/src/vertical-state.ts'
import {applyVertical as oldApply,emptyVertical as oldEmpty} from './original-vertical-state.ts'
import {ShiftStore} from '../../source/products/shift-assistant/src/store.ts'
import {ShiftStore as OldStore} from './original-store.ts'
import {canonical,sha256} from '../../source/products/shift-assistant/src/journal.ts'
const P='5511900000001',actor={kind:'member',memberPhone:P},TTL=86400000,E=Date.parse('2026-10-04T12:00:00Z'),MAX=8640000000000000;
const iso=(ms:number)=>Number.isNaN(ms)?'invalid-date':new Date(ms).toISOString();
function receipt(id:string,ms:number,extra:any={}) {
 const p={provider:'waha',accountRef:'i1-synthetic',providerMessageId:id,recipient:P,deliveryStatus:'delivery_confirmed',simulation:true};
 const raw=canonical(p),eventIdentity=sha256(JSON.stringify([p.provider,p.accountRef,p.providerMessageId,p.recipient,p.deliveryStatus]));
 return {v:2,type:'delivery_receipt_recorded',at:iso(ms),actor,receipt:{...p,eventIdentity,receivedAt:iso(ms),committedAt:iso(ms),raw,rawSha256:sha256(raw),rawReceiptRef:'journal:delivery:'+eventIdentity,eligibility:null,commitVerified:false,...extra}} as any;
}
function pulse(id:string,ms:number) {
 const inbox:any={key:JSON.stringify(['waha','i1-synthetic',id]),provider:'waha',session:'i1-synthetic',messageId:id,memberPhone:P,kind:'text',text:'synthetic',receivedAt:iso(ms),digest:'',state:'received',stage:'command',attempt:0};inbox.digest=inputDigest(inbox);
 return {v:2,type:'inbound_recorded',at:iso(ms),actor,inbox} as any;
}
function view(s:any) {const {nextPendingDeliveryExpiry,...rest}=s;return canonical(Object.fromEntries(Object.entries(rest).map(([k,v])=>[k,v instanceof Map?[...v]:v])))}
function bound(s:any) {let earliest=Infinity;for(const [k,d] of s.deliveries)if(!s.deliveryMatches.has(k)&&Number.isFinite(Date.parse(d.receivedAt)))earliest=Math.min(earliest,Date.parse(d.receivedAt)+TTL);expect(s.nextPendingDeliveryExpiry).toBeLessThanOrEqual(earliest);expect(Number.isNaN(s.nextPendingDeliveryExpiry)).toBe(false)}
function pair() {const a=emptyVertical(),b=oldEmpty();let n=0;return {a,b,step(e:any,id?:string){let x,y;try{applyVertical(a,e,0,false,id)}catch(err){x=(err as Error).message}try{oldApply(b,e,0,false,id)}catch(err){y=(err as Error).message}expect(x).toEqual(y);expect(view(a)).toEqual(view(b));bound(a);n++;return x},count(){return n}}}
const trace=(name:string,data:any)=>fs.appendFileSync(join(import.meta.dirname,'probe-trace.jsonl'),JSON.stringify({name,...data})+'\n');
it('I1 compares original projection at all supported Date extremes, NaN, backdated order and strict boundaries',()=>{
 let count=0;
 for(const r of [-MAX,-MAX+TTL,-TTL-1,-TTL,0,E,MAX-TTL-1,MAX-TTL,MAX-1,MAX,NaN]) {
  for(const t of [-MAX,MAX,NaN,r-1,r,r+TTL-1,r+TTL,r+TTL+1].filter(x=>Number.isNaN(x)||Math.abs(x)<=MAX)) {
   const f=pair();f.step(receipt('extreme',r));f.step(pulse('extreme-pulse',t));count++;
   expect(f.a.deliveries.size).toBe(t-r>TTL?0:1);
  }
 }
 trace('Date differential',{extremePairs:count});
});
const mixed=pair();let mixedSeed=0x197403;
it.each([0,1,2,3,4])('I1 original differential unordered stream chunk %s (continuous 2500 events, 15s each)',chunk=>{
 for(let i=chunk*500;i<(chunk+1)*500;i++){mixedSeed=(Math.imul(mixedSeed,1664525)+1013904223)>>>0;const t=E+(mixedSeed%(8*TTL))-4*TTL;mixed.step(i%4?pulse('p'+i,t):receipt('r'+i,t));}
 trace('continuous unordered differential',{chunk,events:mixed.count()});
});
it('I1 exact numeric implication for safe Date integers, including representational extremes',()=>{
 let cases=0,seed=4141;
 const rs=[-MAX,MAX,MAX-TTL,-MAX+TTL,-1,0,1];
 for(let i=0;i<12000;i++){seed=(Math.imul(seed,1664525)+1013904223)>>>0;rs.push(Math.trunc((seed/4294967295*2-1)*MAX))}
 for(const r of rs)for(const t of [r+TTL-1,r+TTL,r+TTL+1,-MAX,MAX])if(Math.abs(t)<=MAX){expect(t-r>TTL).toBe(t>r+TTL);cases++}
 trace('numeric predicate',{cases});
});
function queue(f:any,id:string,ms:number) {
 const e=pulse('queue'+id,ms);f.step(e);
 f.step({v:2,type:'processing_started',at:iso(ms),actor,key:e.inbox.key,stage:'command',attempt:1,deadline:iso(ms+1000),draftAt:iso(ms)});
 const outbox={id,purpose:'response',sourceTransitionId:'cause:'+id,recipientMemberId:P,payloadText:'synthetic',payloadSha256:sha256('synthetic'),state:'queued',attempt:0};
 f.step({v:2,type:'response_committed',at:iso(ms),actor,key:e.inbox.key,outbox},outbox.sourceTransitionId);
 const identity={provider:'waha',accountRef:'i1-synthetic',outboxId:id,sourceTransitionId:outbox.sourceTransitionId,recipient:P};
 f.step({v:2,type:'outbox_dispatch_started',at:iso(ms),actor,outboxId:id,attempt:1,identity});return identity;
}
function accepted(f:any,id:string,providerId:string,identity:any,ms:number) {f.step({v:2,type:'outbox_result',at:iso(ms),actor,outboxId:id,state:'provider_accepted',receipt:{status:201,at:iso(ms),sha256:sha256('response'),providerId,identity}})}
it('I1 matched receipts survive TTL, capacity exempts known matches, duplicate history survives expiry and causal denial',()=>{
 const f=pair(),i=queue(f,'known',E);accepted(f,'known','known-receipt',i,E);
 for(let n=0;n<1000;n++)expect(f.step(receipt('pending'+n,E))).toBeUndefined();
 expect(f.step(receipt('overflow',E))).toBe('STATE_CONFLICT');
 const known=receipt('known-receipt',E,{eligibility:undefined,commitVerified:true});delete known.receipt.eligibility;
 expect(f.step(known)).toBeUndefined();expect(f.a.deliveries.size).toBe(1001);expect(f.a.deliveryMatches.size).toBe(1);
 expect(f.step(known)).toBe('STATE_CONFLICT');
 f.step(pulse('ttl-exact',E+TTL));expect(f.a.deliveries.size).toBe(1001);
 f.step(pulse('ttl-past',E+TTL+1));expect(f.a.deliveries.size).toBe(1);expect(f.a.deliveryMatches.size).toBe(1);
 expect(f.step(receipt('pending0',E+TTL+1))).toBe('STATE_CONFLICT');
 expect(f.step(receipt('backdated',E-10000))).toBeUndefined();f.step(pulse('backdated-expire',E+TTL-9999));expect(f.a.deliveries.size).toBe(1);
 const g=pair();const identity=queue(g,'denied',E);const early=receipt('denied-receipt',E-1,{commitVerified:true});delete early.receipt.eligibility;g.step(early);accepted(g,'denied','denied-receipt',identity,E);expect(g.a.deliveryMatches.size).toBe(0);
 trace('matched/cap/dedup/causality',{events:f.count()+g.count(),matchedRetained:1});
});
function request(store:any,id:string,events:any[]) {const expected:any={};for(const e of events)for(const [entity,k]of store.references(e))(expected[entity]??={})[String(k)]=store.revision(entity,k);return {transitionId:id,expected,changes:events}}
function bytes(dir:string){const m=JSON.parse(fs.readFileSync(join(dir,'journal/manifest.json'),'utf8'));return fs.readFileSync(join(dir,m.segments.at(-1).path))}
const bad=(ms:number)=>({v:2,type:'outbox_result',at:iso(ms),actor,outboxId:'missing',state:'uncertain',error:'synthetic'});
it('I1 compares original store: failed validation copies, admission/poda rollback, eventcounts, replay and journal byte equality',()=>{
 const dirs=[fs.mkdtempSync(join(tmpdir(),'i1-new-')),fs.mkdtempSync(join(tmpdir(),'i1-old-'))];let stores:any[]=[new ShiftStore(dirs[0]),new OldStore(dirs[1])];
 try{
  const commit=(id:string,events:any[],fails=false)=>{for(const s of stores){const q=request(s,id,events);if(fails)expect(()=>s.commit(q)).toThrow('STATE_CONFLICT');else s.commit(q)}expect(stores[0].deliveries()).toEqual(stores[1].deliveries());expect(stores[0].sequence).toBe(stores[1].sequence);expect(bytes(dirs[0])).toEqual(bytes(dirs[1]));};
  commit('initial',[receipt('later',E+1000)]);const before=bytes(dirs[0]);
  commit('rollback-expiry',[pulse('pruned',E+TTL+1001),bad(E+TTL+1001)],true);expect(bytes(dirs[0])).toEqual(before);
  commit('rollback-admit',[receipt('earlier',E-1000),bad(E)],true);expect(bytes(dirs[0])).toEqual(before);
  commit('successful-batch',[receipt('earlier',E-1000),pulse('earlier-expire',E+TTL-999)]);expect(stores[0].deliveries().map((d:any)=>d.providerMessageId)).toEqual(['later']);
  for(const s of stores)s.close();stores=[new ShiftStore(dirs[0]),new OldStore(dirs[1])];expect(stores[0].storageAvailable).toBe(true);expect(stores[0].sequence).toBe(2);
  commit('future-exact',[pulse('later-exact',E+TTL+1000)]);expect(stores[0].deliveries()).toHaveLength(1);
  commit('future-past',[pulse('later-past',E+TTL+1001)]);expect(stores[0].deliveries()).toHaveLength(0);
  const lines=bytes(dirs[0]).toString().trim().split('\n').map(x=>JSON.parse(x));expect(lines.map(x=>x.changes.length)).toEqual([1,2,1,1]);trace('store differential',{transactions:lines.length,eventcounts:lines.map(x=>x.changes.length),journalSha256:sha256(bytes(dirs[0]))});
 }finally{for(const s of stores)s.close()}
});
it.each(['prune','admit'])('I1 failed fsync does not publish optimistic %s cache; complete LF replays exactly once',(kind)=>{
 const dir=fs.mkdtempSync(join(tmpdir(),'i1-sync-'));let armed=false,syncs=0;const checkpoints:string[]=[];
 let s=new ShiftStore(dir,{io:{sync(fd){syncs++;if(armed)throw Error('synthetic failure');fs.fsyncSync(fd)},checkpoint(p){checkpoints.push(p)}}});
 try{
  s.commit(request(s,'initial',[receipt('later',E+1000)]));const previous=s.sequence,live=s.deliveries(),n=syncs;checkpoints.length=0;
  const events=kind==='prune'?[pulse('fsync-expiry',E+TTL+1001)]:[receipt('fsync-earlier',E-1000)];const q=request(s,'ambiguous',events);armed=true;
  expect(()=>s.commit(q)).toThrow('STORAGE_UNAVAILABLE');expect(s.sequence).toBe(previous);expect(s.deliveries()).toEqual(live);expect(s.storageAvailable).toBe(false);expect(syncs-n).toBe(1);expect(checkpoints).toEqual(['before_journal_write','after_journal_lf']);
  s.close();s=new ShiftStore(dir);expect(s.storageAvailable).toBe(true);expect(s.sequence).toBe(previous+1);expect(s.commit(q).seq).toBe(previous+1);
  if(kind==='prune')expect(s.deliveries()).toHaveLength(0);else {expect(s.deliveries()).toHaveLength(2);s.commit(request(s,'prune-earlier',[pulse('after-replay',E+TTL-999)]));expect(s.deliveries().map(d=>d.providerMessageId)).toEqual(['later'])}
  trace('fsync failure',{kind,failedSyncCalls:1,checkpoints,replayedSequence:s.sequence});
 }finally{s.close()}
});
