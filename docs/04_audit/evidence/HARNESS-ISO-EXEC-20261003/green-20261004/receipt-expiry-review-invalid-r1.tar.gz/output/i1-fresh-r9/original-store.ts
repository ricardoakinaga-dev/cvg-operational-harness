import {
  emptyVertical,
  isV2,
  applyVertical,
  v2Affected,
  deliveryAuthority
} from "/home/ricardo/.cache/cvg-harness-green-20261004/receipt-expiry-fresh-review-r9/output/i1-fresh-r9/original-vertical-state.ts"
import type { Inbox, NoteV2, TaskV2, Outbox } from "/home/ricardo/.cache/cvg-harness-green-20261004/receipt-expiry-fresh-review-r9/source/products/shift-assistant/src/domain.ts"
import { randomUUID } from 'node:crypto'
import { lstatSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import {
  Journal,
  ShiftEventSchema,
  StoreError,
  canonical,
  sha256,
  MAX_V2_LINE,
  type JournalEvent,
  type JournalTransaction,
  type JournalIO,
  type MigrationRecord,
  type MediaDescriptor
} from "/home/ricardo/.cache/cvg-harness-green-20261004/receipt-expiry-fresh-review-r9/source/products/shift-assistant/src/journal.ts"
import {
  prepareMigration,
  replayLegacy,
  mimeForExtension,
  type MigrationOptions
} from "/home/ricardo/.cache/cvg-harness-green-20261004/receipt-expiry-fresh-review-r9/source/products/shift-assistant/src/migrate-journal.ts"
import {
  type InboundMessage,
  type KnownPatient,
  type Note,
  type ShiftEvent,
  type Task
} from "/home/ricardo/.cache/cvg-harness-green-20261004/receipt-expiry-fresh-review-r9/source/products/shift-assistant/src/domain.ts"

/**
 * State rebuilt from an append-only JSONL event log. The log is the document
 * of record (decision D4): nothing is rewritten or deleted here.
 */
export class ShiftStore {
  #vertical = emptyVertical()
  readonly #lastPresented = new Map<
    string,
    { noteId: string; revision: number }
  >()
  readonly #journal: Journal | undefined
  readonly #memoryMediaBytes = new Map<string, Uint8Array>()
  readonly #memoryMedia = new Map<string, MediaDescriptor>()
  readonly #results = new Map<string, { hash: string; result: CommitResult }>()
  readonly #revisions = new Map<string, number>()
  #migration: MigrationRecord | undefined
  #available = true
  #replaying = true
  #closed = false
  #seq = 0
  readonly #messages = new Map<string, InboundMessage>()
  readonly #processed = new Set<string>()
  readonly #notes = new Map<string, Note>()
  readonly #tasks = new Map<number, Task>()
  #paused = false
  readonly #restoreHold: boolean
  #budgetHold = false

  /** Persistent mode owns an exclusive process lock until close(). */
  constructor(dataDir?: string, options: StoreOptions = {}) {
    let restoreHold = false
    if (dataDir) {
      try {
        lstatSync(join(dataDir, 'restore-hold.json'))
        restoreHold = true
      } catch (error) {
        restoreHold = (error as NodeJS.ErrnoException).code !== 'ENOENT'
      }
    }
    if (dataDir) {
      try {
        lstatSync(join(dataDir, 'budget-hold.json'))
        this.#budgetHold = true
      } catch (error) {
        this.#budgetHold = (error as NodeJS.ErrnoException).code !== 'ENOENT'
      }
    }
    this.#restoreHold = restoreHold
    if (dataDir) {
      this.#journal = new Journal(dataDir, options.io)
      try {
        this.#journal.assertWritable()
        if (!this.#journal.manifest) {
          const migration = prepareMigration(this.#journal, options, (event) =>
            this.#applyLegacy(event)
          )
          this.#journal.initialize(
            migration?.legacy,
            migration?.record,
            migration?.recovery
          )
          this.#migration = migration?.record
        } else {
          this.#migration = this.#journal.manifest.migration
          replayLegacy(this.#journal, (event) => this.#applyLegacy(event))
        }
        this.#journal.replay((transaction) => this.#replay(transaction))
        const migration = this.#journal.manifest!.migration
        if (migration && !this.#journal.transitions.has(migration.id)) {
          const changes: JournalEvent[] = [
            {
              type: 'migration_applied',
              at: new Date().toISOString(),
              migration
            }
          ]
          this.#replay(this.#journal.append(migration.id, changes))
        }
      } catch (error) {
        this.#journal.fail(error)
        this.#available = false
      }
    }
    this.#replaying = false
  }

  get storageAvailable(): boolean {
    return (
      this.#available && !this.#closed && (this.#journal?.available ?? true)
    )
  }

  get diagnostic(): string | undefined {
    return this.#journal?.diagnostic
  }
  get operationalHold(): boolean {
    return (
      this.#restoreHold ||
      this.#budgetHold ||
      (this.#migration?.operationalHold ?? false)
    )
  }
  /** Persist once before any further effects; failure also closes storage. */
  holdBudget(at: string): void {
    if (this.#budgetHold) return
    this.#budgetHold = true
    try {
      this.#journal?.holdBudget(at)
    } catch (error) {
      this.#available = false
      throw error
    }
  }
  get effectsAllowed(): boolean {
    return this.storageAvailable && !this.operationalHold && !this.#paused
  }
  get sequence(): number {
    return this.#seq
  }
  get migration(): Readonly<MigrationRecord> | undefined {
    return this.#migration ? immutable(this.#migration) : undefined
  }

  revision(entity: RevisionEntity, id: string | number): number {
    return this.#revisions.get(entity + ':' + id) ?? 0
  }

  commit(request: CommitRequest): CommitResult {
    if (!this.storageAvailable) throw new StoreError('STORAGE_UNAVAILABLE')
    if (
      !request.transitionId ||
      !Array.isArray(request.changes) ||
      !request.changes.length
    )
      throw new StoreError('INVALID_TRANSITION')
    // Check canonical input before parsing; Zod must not silently strip undefined/unknown properties.
    canonical(request)
    const changes = request.changes.map((event) =>
      ShiftEventSchema.parse(event)
    )
    const digest = sha256(canonical(changes))
    const previous = this.#results.get(request.transitionId)
    if (previous) {
      if (previous.hash !== digest) throw new StoreError('IDEMPOTENCY_CONFLICT')
      return immutable(previous.result)
    }
    this.#checkExpected(request.expected, changes)
    this.#validate(changes, request.transitionId)
    const estimated =
      Buffer.byteLength(
        canonical({
          v: 2,
          seq: this.#seq + 1,
          transitionId: request.transitionId,
          at: changes[0]!.at,
          prevSha256: '0'.repeat(64),
          changes,
          sha256: '0'.repeat(64)
        })
      ) + 1
    if (estimated > MAX_V2_LINE)
      throw new StoreError('INVALID_TRANSITION', 'Record exceeds V2 budget')
    let transaction: JournalTransaction
    if (this.#journal)
      transaction = this.#journal.append(request.transitionId, changes)
    else {
      const body = {
        v: 2 as const,
        seq: this.#seq + 1,
        transitionId: request.transitionId,
        at: changes[0]!.at,
        prevSha256: this.#memoryHead,
        changes
      }
      transaction = { ...body, sha256: sha256(canonical(body)) }
      this.#memoryHead = transaction.sha256
    }
    this.#publish(transaction)
    return immutable({ seq: transaction.seq, sha256: transaction.sha256 })
  }
  #memoryHead = sha256('')

  /** Compatibility entry point: still uses schema, guards, one LF and fsync. */
  append(event: ShiftEvent): void {
    const expected: CommitExpected = {}
    for (const [entity, id] of this.references(event)) {
      const revisions = expected[entity] ?? {}
      revisions[String(id)] = this.revision(entity, id)
      expected[entity] = revisions
    }
    this.commit({
      transitionId: 'compat:' + randomUUID(),
      expected,
      changes: [event]
    })
  }

  /** Compatibility name is only an extension hint; destination is always generated. */
  saveMedia(name: string, bytes: Uint8Array): string {
    if (!this.storageAvailable) throw new StoreError('STORAGE_UNAVAILABLE')
    const mime = mimeForExtension(name)
    return this.saveMediaDescriptor(
      bytes,
      mime,
      JSON.stringify(['compat-media', randomUUID()])
    ).path.slice('media/'.length)
  }

  saveMediaDescriptor(
    bytes: Uint8Array,
    mime: MediaDescriptor['mime'],
    messageKey: string
  ): Readonly<MediaDescriptor> {
    if (!this.storageAvailable) throw new StoreError('STORAGE_UNAVAILABLE')
    if (this.#journal)
      return immutable(this.#journal.saveMedia(bytes, mime, messageKey))
    const map: Record<MediaDescriptor['mime'], string> = {
      'audio/ogg': 'ogg',
      'audio/mpeg': 'mp3',
      'audio/mp4': 'm4a',
      'audio/wav': 'wav',
      'image/jpeg': 'jpg',
      'image/png': 'png',
      'application/octet-stream': 'bin'
    }
    if (!map[mime] || !messageKey) throw new StoreError('INVALID_TRANSITION')
    const descriptor: MediaDescriptor = {
      messageKey,
      mime,
      bytes: bytes.length,
      sha256: sha256(bytes),
      path: 'media/' + randomUUID() + '.' + map[mime],
      stage: 'published'
    }
    this.#memoryMedia.set(descriptor.path, descriptor)
    this.#memoryMediaBytes.set(descriptor.path, new Uint8Array(bytes))
    return immutable(descriptor)
  }

  readMedia(path: string) {
    this.#verifyMedia(path)
    const d = this.#journal?.verifyMedia(path) ?? this.#memoryMedia.get(path)!
    if (d.bytes > 10485760) throw new StoreError('INVALID_TRANSITION')
    const bytes = this.#journal
      ? readFileSync(join(this.#journal.root, path))
      : this.#memoryMediaBytes.get(path)!
    if (!bytes || bytes.length !== d.bytes || sha256(bytes) !== d.sha256)
      throw new StoreError('STORAGE_UNAVAILABLE')
    return { bytes: new Uint8Array(bytes), mimetype: d.mime }
  }
  mediaInventory(): { valid: Readonly<MediaDescriptor>[]; retained: string[] } {
    return immutable(
      this.#journal?.mediaInventory() ?? {
        valid: [...this.#memoryMedia.values()],
        retained: []
      }
    )
  }

  close(): void {
    if (this.#closed) return
    this.#closed = true
    this.#journal?.close()
  }

  #checkExpected(
    expected: CommitExpected,
    changes: readonly JournalEvent[]
  ): void {
    const all = new Map<string, [RevisionEntity, string | number]>()
    for (const event of changes)
      for (const [entity, id] of this.references(event))
        all.set(entity + ':' + id, [entity, id])
    for (const [entity, revisions] of Object.entries(expected)) {
      if (!['inbox', 'notes', 'tasks', 'outbox', 'operation'].includes(entity))
        throw new StoreError('INVALID_TRANSITION')
      for (const [id, revision] of Object.entries(revisions)) {
        if (!Number.isSafeInteger(revision) || revision < 0)
          throw new StoreError('INVALID_TRANSITION')
        if (this.revision(entity as RevisionEntity, id) !== revision)
          throw new StoreError('STATE_CONFLICT')
      }
    }
    for (const [entity, id] of all.values()) {
      if (expected[entity]?.[String(id)] !== this.revision(entity, id))
        throw new StoreError('STATE_CONFLICT')
    }
  }

  #validate(changes: readonly JournalEvent[], transitionId: string): void {
    // Receipt/identity values are replaced, never mutated. Copy their indexes
    // while deep-cloning the mutable aggregates for transactional validation.
    const vertical = {
      ...structuredClone({
        inbox: this.#vertical.inbox,
        notes: this.#vertical.notes,
        tasks: this.#vertical.tasks,
        outbox: this.#vertical.outbox,
        paused: this.#vertical.paused
      }),
      deliveries: new Map(this.#vertical.deliveries),
      outboxCausality: new Map(this.#vertical.outboxCausality),
      dispatches: new Map(this.#vertical.dispatches),
      deliveryMatches: new Map(this.#vertical.deliveryMatches),
      deliveryHistory: new Map(this.#vertical.deliveryHistory)
    }
    const messages = new Map(this.#messages)
    const notes = structuredClone(this.#notes)
    const tasks = structuredClone(this.#tasks)
    const processed = new Set(this.#processed)
    for (const event of changes) {
      if (isV2(event)) {
        if (event.type === 'media_attached') this.#verifyMedia(event.path)
        if (event.type === 'inbound_recorded' && event.inbox.mediaPath)
          this.#verifyMedia(event.inbox.mediaPath)
        applyVertical(
          vertical,
          event,
          maxTaskNumber(tasks.keys()),
          this.#replaying
            ? (this.#migration?.operationalHold ?? false)
            : this.operationalHold,
          transitionId
        )
        continue
      }
      if (event.type === 'message_received') {
        if (
          event.message.mediaRef?.startsWith('base64:') ||
          event.message.mediaRef?.startsWith('data:')
        )
          throw new StoreError(
            'INVALID_TRANSITION',
            'Inline media requires envelope admission'
          )
        if (messages.has(event.message.messageId))
          throw new StoreError('STATE_CONFLICT')
        if (event.message.mediaRef?.startsWith('media/'))
          this.#verifyMedia(event.message.mediaRef)
        messages.set(event.message.messageId, event.message)
      } else if (event.type === 'message_processed') {
        if (!messages.has(event.messageId) || processed.has(event.messageId))
          throw new StoreError('STATE_CONFLICT')
        processed.add(event.messageId)
      } else if (event.type === 'note_created') {
        if (
          notes.has(event.note.id) ||
          !messages.has(event.note.messageId) ||
          messages.get(event.note.messageId)!.fromPhone !==
            event.note.authorPhone
        )
          throw new StoreError('STATE_CONFLICT')
        if (event.note.confirmed || event.note.supersededBy)
          throw new StoreError('INVALID_TRANSITION')
        if (event.note.mediaFile)
          this.#verifyMedia('media/' + event.note.mediaFile)
        notes.set(event.note.id, structuredClone(event.note))
      } else if (event.type === 'note_confirmed') {
        const note = notes.get(event.noteId)
        if (
          !note ||
          note.confirmed ||
          note.supersededBy ||
          note.unverifiedNumbers.length
        )
          throw new StoreError('STATE_CONFLICT')
        // The V1 flag is historical only; it is never V2 proof of preview/binding approval.
        note.confirmed = true
      } else if (event.type === 'note_superseded') {
        const note = notes.get(event.noteId)
        if (
          !note ||
          note.supersededBy ||
          !notes.has(event.by) ||
          event.by === event.noteId
        )
          throw new StoreError('STATE_CONFLICT')
        note.supersededBy = event.by
      } else if (event.type === 'task_created') {
        if (
          tasks.has(event.task.number) ||
          event.task.number !== maxTaskNumber(tasks.keys()) + 1 ||
          (event.task.noteId && !notes.has(event.task.noteId))
        )
          throw new StoreError('STATE_CONFLICT')
        if (
          event.task.noteId &&
          notes.get(event.task.noteId)!.authorPhone !== event.task.ownerPhone
        )
          throw new StoreError('STATE_CONFLICT')
        if (event.task.status !== 'open' || event.task.remindedCount !== 0)
          throw new StoreError('INVALID_TRANSITION')
        tasks.set(event.task.number, structuredClone(event.task))
      } else if (
        event.type === 'task_done' ||
        event.type === 'task_cancelled' ||
        event.type === 'task_snoozed' ||
        event.type === 'task_reminded'
      ) {
        const task = tasks.get(event.number)
        if (!task || task.status !== 'open')
          throw new StoreError('STATE_CONFLICT')
        if (event.type === 'task_reminded')
          throw new StoreError(
            'INVALID_TRANSITION',
            'V2 confirmation/reservation proof required'
          )
        if (event.type === 'task_done') task.status = 'done'
        if (event.type === 'task_cancelled') task.status = 'cancelled'
        if (event.type === 'task_snoozed') {
          task.dueAt = event.dueAt
          task.remindedCount = 0
        }
      } else if (event.type === 'migration_applied') {
        if (
          !this.#journal?.manifest?.migration ||
          canonical(event.migration) !==
            canonical(this.#journal.manifest.migration)
        )
          throw new StoreError('INVALID_TRANSITION')
      } else if (event.type === 'recovery_recorded') {
        if (!this.#journal) throw new StoreError('INVALID_TRANSITION')
        this.#journal.verifyRecovery(event)
      }
    }
  }

  #verifyMedia(path: string): void {
    if (this.#journal) {
      try {
        this.#journal.verifyMedia(path)
      } catch (error) {
        this.#journal.fail(error)
        throw new StoreError('STORAGE_UNAVAILABLE')
      }
    } else if (!this.#memoryMedia.has(path))
      throw new StoreError('INVALID_TRANSITION', 'Missing media')
  }

  #applyLegacy(event: ShiftEvent): void {
    this.#apply(event)
    this.#touch(event)
  }

  #replay(transaction: JournalTransaction): void {
    this.#validate(transaction.changes, transaction.transitionId)
    this.#publish(transaction)
  }

  #publish(transaction: JournalTransaction): void {
    for (const event of transaction.changes) {
      if (event.type === 'migration_applied')
        this.#migration = structuredClone(event.migration)
      else if (isV2(event)) {
        applyVertical(
          this.#vertical,
          event,
          maxTaskNumber(this.#tasks.keys()),
          this.#replaying
            ? (this.#migration?.operationalHold ?? false)
            : this.operationalHold,
          transaction.transitionId
        )
        if (event.type === 'operation_paused') this.#paused = true
        if (event.type === 'operation_resumed') this.#paused = false
        if (
          event.type === 'outbox_result' &&
          event.state === 'provider_accepted'
        ) {
          const box = this.#vertical.outbox.get(event.outboxId)
          if (box?.purpose === 'preview' && box.noteId && box.noteRevision)
            this.#lastPresented.set(box.recipientMemberId, {
              noteId: box.noteId,
              revision: box.noteRevision
            })
        }
      } else if (event.type !== 'recovery_recorded') this.#apply(event)
      this.#touch(event)
    }
    this.#seq = transaction.seq
    this.#results.set(transaction.transitionId, {
      hash: sha256(canonical(transaction.changes)),
      result: { seq: transaction.seq, sha256: transaction.sha256 }
    })
  }

  references(event: JournalEvent): [RevisionEntity, string | number][] {
    return affected(event, {
      tasks: [...this.#vertical.tasks.values()],
      outbox: [...this.#vertical.outbox.values()]
    })
  }

  #touch(event: JournalEvent): void {
    for (const [entity, id] of this.references(event)) {
      const key = entity + ':' + id
      this.#revisions.set(key, (this.#revisions.get(key) ?? 0) + 1)
    }
  }

  hasMessage(messageId: string): boolean {
    return this.#messages.has(messageId)
  }

  unprocessedMessages(): InboundMessage[] {
    return immutable(
      [...this.#messages.values()].filter(
        (message) =>
          !this.#processed.has(message.messageId) &&
          !this.#migration?.messages.some(
            (m) => m.messageId === message.messageId
          )
      )
    )
  }

  note(id: string): Note | undefined {
    const note = this.#notes.get(id)
    return note ? immutable(note) : undefined
  }

  lastActiveNote(authorPhone: string): Note | undefined {
    return immutable(
      [...this.#notes.values()]
        .filter(
          (note) => note.authorPhone === authorPhone && !note.supersededBy
        )
        .at(-1)
    )
  }

  /**
   * Patients with an ID seen in active notes, most recent first. Phase 1 has
   * no HIS access, so this is the assistant's only memory of who is who.
   */
  knownPatients(name: string): KnownPatient[] {
    return immutable(
      [...this.#vertical.notes.values()]
        .filter((n) => n.state === 'confirmed' && !n.replacementPending)
        .flatMap((n) =>
          n.bindings
            .filter(
              (b) =>
                b.name === name &&
                b.provenance !== 'unresolved' &&
                b.confirmedBy &&
                b.idLiteral
            )
            .map((b) => ({
              id: b.idLiteral!,
              name: b.name,
              ...(b.bed ? { bed: b.bed } : {}),
              lastSeen: n.createdAt
            }))
        )
    )
  }

  task(number: number): Task | TaskV2 | undefined {
    const task = this.#vertical.tasks.get(number) ?? this.#tasks.get(number)
    return task ? immutable(task) : undefined
  }

  openTasks(ownerPhone?: string): Task[] {
    return immutable(
      [...this.#vertical.tasks.values()]
        .filter(
          (t) =>
            t.status === 'open' && (!ownerPhone || t.ownerPhone === ownerPhone)
        )
        .map((t) => {
          const { patientId, ...rest } = t
          return {
            ...rest,
            ...(t.patientRef
              ? {
                  patient: this.#vertical.notes
                    .get(t.noteId)!
                    .bindings.find((b) => b.localRef === t.patientRef)!.name
                }
              : {}),
            ...(patientId ? { patientId } : {}),
            status: 'open' as const
          }
        })
    )
  }

  taskProjectionState(
    number: number
  ): 'draft' | 'legacy_review_required' | 'done' | 'cancelled' | undefined {
    const task = this.#tasks.get(number)
    if (!task) return undefined
    if (task.status !== 'open') return task.status
    return this.#migration?.heldTaskNumbers.includes(number) &&
      !this.#migration.draftTaskNumbers.includes(number)
      ? 'legacy_review_required'
      : 'draft'
  }

  nextTaskNumber(): number {
    return (
      Math.max(
        maxTaskNumber(this.#tasks.keys()),
        maxTaskNumber(this.#vertical.tasks.keys())
      ) + 1
    )
  }

  get paused(): boolean {
    return this.#paused
  }

  inbox(key: string): Inbox | undefined {
    const i = this.#vertical.inbox.get(key)
    return i ? immutable(i) : undefined
  }
  inboxes(): Inbox[] {
    return immutable([...this.#vertical.inbox.values()])
  }
  noteV2(id: string): NoteV2 | undefined {
    const n = this.#vertical.notes.get(id)
    return n ? immutable(n) : undefined
  }
  notesV2(): NoteV2[] {
    return immutable([...this.#vertical.notes.values()])
  }
  lastPresentedNote(
    memberPhone: string
  ): Readonly<{ noteId: string; revision: number }> | undefined {
    const value = this.#lastPresented.get(memberPhone)
    return value ? immutable(value) : undefined
  }
  tasksV2(): TaskV2[] {
    return immutable([...this.#vertical.tasks.values()])
  }
  #withDelivery(b: Outbox): Outbox {
    const d = [...this.#vertical.deliveries.values()].find((d) => {
      return (
        d.commitVerified &&
        this.#vertical.deliveryMatches.get(d.eventIdentity) === b.id
      )
    })
    // Never trust a delivery projection embedded in historical outbox data.
    const effect = { ...b }
    delete effect.delivery
    return d ? { ...effect, delivery: d } : effect
  }
  deliveryAuthority(d: Parameters<typeof deliveryAuthority>[1]) {
    return deliveryAuthority(this.#vertical, d)
  }
  deliveryRecorded(eventIdentity: string): boolean {
    return this.#vertical.deliveryHistory.has(eventIdentity)
  }
  deliveryCommitted(eventIdentity: string): boolean {
    return (
      this.#vertical.deliveryHistory.get(eventIdentity)?.commitVerified === true
    )
  }
  deliveries() {
    return immutable([...this.#vertical.deliveries.values()])
  }
  outboxes(): Outbox[] {
    return immutable(
      [...this.#vertical.outbox.values()].map((b) => this.#withDelivery(b))
    )
  }
  outbox(id: string): Outbox | undefined {
    const b = this.#vertical.outbox.get(id)
    return b ? immutable(this.#withDelivery(b)) : undefined
  }

  #apply(event: ShiftEvent): void {
    switch (event.type) {
      case 'message_received':
        this.#messages.set(
          event.message.messageId,
          structuredClone(event.message)
        )
        return
      case 'message_processed':
        this.#processed.add(event.messageId)
        return
      case 'note_created':
        this.#notes.set(event.note.id, structuredClone(event.note))
        return
      case 'note_confirmed': {
        const note = this.#notes.get(event.noteId)
        if (note) note.confirmed = true
        return
      }
      case 'note_superseded': {
        const note = this.#notes.get(event.noteId)
        if (note) note.supersededBy = event.by
        return
      }
      case 'task_created':
        this.#tasks.set(event.task.number, structuredClone(event.task))
        return
      case 'task_done':
        this.#updateTask(event.number, { status: 'done', doneAt: event.at })
        return
      case 'task_cancelled':
        this.#updateTask(event.number, { status: 'cancelled' })
        return
      case 'task_snoozed':
        this.#updateTask(event.number, {
          dueAt: event.dueAt,
          remindedCount: 0
        })
        return
      case 'task_reminded': {
        const task = this.#tasks.get(event.number)
        if (task) {
          task.remindedCount += 1
          task.lastRemindedAt = event.at
        }
        return
      }
      case 'paused':
        this.#paused = true
        return
      case 'resumed':
        this.#paused = false
        return
    }
  }

  #updateTask(number: number, patch: Partial<Task>): void {
    const task = this.#tasks.get(number)
    if (task) Object.assign(task, patch)
    if (task && patch.dueAt) delete task.lastRemindedAt
  }
}

export type RevisionEntity =
  | 'inbox'
  | 'notes'
  | 'tasks'
  | 'outbox'
  | 'operation'
export type CommitExpected = Partial<
  Record<RevisionEntity, Record<string, number>>
>
export interface CommitRequest {
  transitionId: string
  expected: CommitExpected
  changes: readonly ShiftEvent[]
}
export interface CommitResult {
  seq: number
  sha256: string
}
export interface StoreOptions extends MigrationOptions {
  io?: JournalIO
}

export function affected(
  event: JournalEvent,
  dependencies?: { tasks: TaskV2[]; outbox: Outbox[] }
): [RevisionEntity, string | number][] {
  if (isV2(event)) {
    const refs = v2Affected(event)
    if (dependencies) {
      const noteId =
        event.type === 'replacement_started'
          ? event.noteId
          : event.type === 'replacement_prepared'
            ? event.previousNoteId
            : undefined
      const number = 'number' in event ? event.number : undefined
      if (noteId)
        for (const t of dependencies.tasks)
          if (t.noteId === noteId) refs.push(['tasks', t.number])
      if (
        noteId ||
        event.type === 'task_completed' ||
        event.type === 'task_snoozed_v2'
      )
        for (const b of dependencies.outbox)
          if (
            (noteId && b.noteId === noteId) ||
            (number && b.taskNumber === number)
          )
            refs.push(['outbox', b.id])
      if (event.type === 'outbox_result') {
        const b = dependencies.outbox.find((b) => b.id === event.outboxId)
        if (b?.taskNumber) refs.push(['tasks', b.taskNumber])
      }
    }
    return [...new Map(refs.map((r) => [r.join(':'), r])).values()]
  }
  switch (event.type) {
    case 'message_received':
      return [['inbox', event.message.messageId]]
    case 'message_processed':
      return [['inbox', event.messageId]]
    case 'note_created':
      return [
        ['notes', event.note.id],
        ['inbox', event.note.messageId]
      ]
    case 'note_confirmed':
      return [['notes', event.noteId]]
    case 'note_superseded':
      return [
        ['notes', event.noteId],
        ['notes', event.by]
      ]
    case 'task_created':
      return [
        ['tasks', event.task.number],
        ...(event.task.noteId
          ? [['notes', event.task.noteId] as [RevisionEntity, string]]
          : [])
      ]
    case 'task_done':
    case 'task_cancelled':
    case 'task_snoozed':
    case 'task_reminded':
      return [['tasks', event.number]]
    case 'paused':
    case 'resumed':
      return [['operation', 'state']]
    case 'migration_applied':
    case 'recovery_recorded':
      return []
  }
}

function immutable<T>(value: T): T {
  const copy = structuredClone(value)
  function freeze(item: unknown): void {
    if (!item || typeof item !== 'object' || Object.isFrozen(item)) return
    for (const child of Object.values(item)) freeze(child)
    Object.freeze(item)
  }
  freeze(copy)
  return copy
}

function maxTaskNumber(numbers: Iterable<number>): number {
  let maximum = 0
  for (const number of numbers) maximum = Math.max(maximum, number)
  return maximum
}
