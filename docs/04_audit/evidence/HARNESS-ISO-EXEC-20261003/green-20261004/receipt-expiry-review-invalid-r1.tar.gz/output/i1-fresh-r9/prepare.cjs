const fs=require('node:fs'),path=require('node:path');
const packet=path.resolve(__dirname,'../..'),src=path.join(packet,'source/products/shift-assistant/src');
fs.symlinkSync(path.join(packet,'source/node_modules'),path.join(__dirname,'node_modules'));
fs.mkdirSync(path.join(__dirname,'production/src/__tests__'),{recursive:true});
for(const n of ['store.ts','journal.ts','vertical-state.ts','domain-v2.ts']) fs.symlinkSync(path.join(src,n),path.join(__dirname,'production/src',n));
const test='receipt-performance-r9-own.test.ts';
fs.copyFileSync(path.join(src,'__tests__',test),path.join(__dirname,'production/src/__tests__',test));
for(const n of ['vertical-state.ts','store.ts']) {
 const original=fs.readFileSync(path.join(packet,'original/products/shift-assistant/src',n),'utf8');
 const rewritten=original.replace(/from '(\.\/[^']+)'/g,(_,p)=>'from '+JSON.stringify(n==='store.ts'&&p==='./vertical-state.ts'?path.join(__dirname,'original-vertical-state.ts'):path.join(src,p.slice(2))));
 fs.writeFileSync(path.join(__dirname,'original-'+n),rewritten);
}
fs.writeFileSync(path.join(__dirname,'preparation.json'),JSON.stringify({productionTest:'byte-for-byte copied; relative dependency symlinks only',original:'only relative import specifiers rebased; original store uses original vertical state',node:process.version},null,2));
