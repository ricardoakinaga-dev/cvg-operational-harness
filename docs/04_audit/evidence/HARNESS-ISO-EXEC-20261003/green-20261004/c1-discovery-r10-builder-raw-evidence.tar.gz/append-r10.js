

// R10 global discovery checks use inert JSON and constant source labels only.
describe('R10 physical manifest coverage and dependency metadata', () => {
  function fixture(id, change = () => {}) {
    const root = path.join(output, 'r10-inert-metadata', id)
    const values = {
      root: { private: true, type: 'module', workspaces: ['packages/*', 'products/*'] },
      core: { name: '@synthetic/core', type: 'module' },
      consumer: { name: '@synthetic/consumer', type: 'module' }
    }
    change(values)
    const put = (rel, value) => {
      const file = path.join(root, rel)
      fs.mkdirSync(path.dirname(file), { recursive: true })
      fs.writeFileSync(file, typeof value === 'string' ? value : JSON.stringify(value))
    }
    for (const dir of ['packages/core/src', 'products/consumer/src', 'apps', 'legacy'])
      fs.mkdirSync(path.join(root, dir), { recursive: true })
    put('package.json', values.root)
    put('packages/core/package.json', values.core)
    put('products/consumer/package.json', values.consumer)
    put('packages/core/src/index.mjs', 'export const label="synthetic";')
    put('products/consumer/src/index.mjs', 'export const label="synthetic";')
    return root
  }
  const fields = ['dependencies', 'devDependencies', 'optionalDependencies', 'peerDependencies']
  const owners = ['root', 'core', 'consumer']
  const blocked = fields.flatMap(field => owners.flatMap(owner => [
    [`${owner}-${field}-invalid-npm`, v => {v[owner][field] = {'synthetic-alias': 'npm:'}}],
    [`${owner}-${field}-missing-local`, v => {v[owner][field] = {'synthetic-alias': 'file:missing-local-directory'}}]
  ]))
  blocked.push(
    ['omitted-core-invalid', v => {v.root.workspaces = ['products/*']; v.core = []}],
    ['omitted-product-invalid', v => {v.root.workspaces = ['packages/*']; v.consumer = []}],
    ['empty-discovery-invalid', v => {v.root.workspaces = []; v.consumer = []}],
    ['omitted-core-dependency', v => {v.root.workspaces = ['products/*']; v.core.dependencies = {'@synthetic/consumer': '*'}}],
    ['omitted-product-valid', v => {v.root.workspaces = ['packages/*']}],
    ['empty-discovery-valid', v => {v.root.workspaces = []}]
  )
  for (const pattern of ['packages/**/*', 'packages/*/*', 'packages/{core,other}/*', 'packages/[co]ore/*'])
    blocked.push(['unsupported-glob-' + pattern, v => {v.root.workspaces = [pattern, 'products/*']}])
  it.each(blocked)('%s cannot produce false PASS', (id, change) => {
    let result, error
    try {result = auditProductBoundary(fixture(id, change))} catch (caught) {error = caught}
    expect(error instanceof Error || result?.passed === false, id).toBe(true)
  })
  it.each(fields.flatMap(field => [
    [`root-${field}-valid-npm`, v => {v.root[field] = {'synthetic-alias': 'npm:external-neutral@1.0.0'}}],
    [`root-${field}-valid-local`, v => {v.root[field] = {'synthetic-alias': 'file:packages/core'}}],
    [`product-${field}-valid-local-core`, v => {v.consumer[field] = {'synthetic-alias': 'file:../../packages/core'}}]
  ]))('%s preserves valid metadata', (id, change) => {
    const result = auditProductBoundary(fixture(id, change))
    expect(result.status, id).toBe('PASS')
    expect(result.diagnostics, id).toEqual([])
  })
})
