import { createServer } from "node:http";
import { randomUUID, createHash } from "node:crypto";
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { composeShiftApp } from "/home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r19/products/shift-assistant/src/compose.ts";
import { loadShiftConfig } from "/home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r19/products/shift-assistant/src/config.ts";
import { startSandboxServices } from "/home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r19/products/shift-assistant/src/sandbox/services.ts";
import { loadSyntheticCorpus } from "/home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r19/products/shift-assistant/src/synthetic/corpus.ts";

// Validate every frozen case/audio hash before serving the allowlisted console.
await loadSyntheticCorpus();

// Temporary local test console; all assistant behavior comes from the existing delivery.
const root = "/home/ricardo/.cache/cvg-harness-green-20261004/local-r19";
const dataRoot = "/home/ricardo/.cache/cvg-harness-green-20261004/local/data";
const origin = "http://127.0.0.1:3501";
const secret =
  process.env.SHIFT_WEBHOOK_SECRET ?? "sandbox-local-" + randomUUID();
const members = {
  "5511900000001": "Dra Ana (fictícia)",
  "5511900000009": "Gestor (fictício)",
};
const fixturesRoot =
  "/home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r19/products/shift-assistant/src/__tests__/fixtures/reliability/cases";
const fixtures = Array.from({ length: 20 }, (_, index) => {
  const name = "case" + String(index + 1).padStart(2, "0") + ".json";
  const bytes = readFileSync(fixturesRoot + "/" + name);
  const item = JSON.parse(bytes.toString("utf8"));
  if (item.synthetic !== true)
    throw new Error("Non-synthetic fixture rejected");
  return {
    id: item.id,
    label: item.scenario,
    text: item.input.rawText,
    sha256: createHash("sha256").update(bytes).digest("hex"),
  };
}).filter((item) => typeof item.text === "string" && item.text.length > 0);
const fixedCommands = [
  "ajuda",
  "pendências",
  "feito 1",
  "adiar 1 30",
  "pausar assistente",
  "retomar assistente",
];
const allowedTexts = new Set([
  ...fixtures.map((item) => item.text),
  ...fixedCommands,
]);
const sample = fixtures[0].text;
let now = new Date();
now.setUTCHours(17, 0, 0, 0);
mkdirSync(dataRoot, { recursive: true });
const services = await startSandboxServices();
const audio = new Uint8Array([1, 2, 3, 4]);
services.media.set("exemplo.oga", audio);
services.transcripts.set(Buffer.from(audio).toString("hex"), sample);
const app = composeShiftApp(
  loadShiftConfig({
    SHIFT_PROVIDER: "waha",
    SHIFT_MEMBERS: "5511900000001=Dra Ana (fictícia);5511900000009=Gestor*",
    SHIFT_WEBHOOK_SECRET: secret,
    SHIFT_DATA_DIR: dataRoot,
    SHIFT_PORT: "3500",
    SHIFT_HOST: "127.0.0.1",
    SHIFT_TICK_SECONDS: "1",
    WAHA_URL: services.wahaUrl,
    WAHA_API_KEY: "sandbox-waha-key",
    WHISPER_URL: services.whisperUrl,
    LLM_BASE_URL: services.llmUrl,
    LLM_MODEL: "sandbox",
    LLM_LOCATION: "local",
  }),
  { clock: () => new Date(now) },
);
app.server.on("error", (error) => {
  console.error("LOCAL_OPERATION_FAILED");
  process.exit(1);
});
await app.start();
const inputs: Array<{ id: string; phone: string; label: string; at: string }> =
  [];
const messages: Array<{
  phone: string;
  label: string;
  text: string;
  reply: boolean;
}> = [];
let shown = 0;
let queue = Promise.resolve();
function state() {
  for (const m of services.sent.slice(shown))
    messages.push({
      phone: m.to,
      label: "Assistente",
      text: m.text,
      reply: true,
    });
  shown = services.sent.length;
  return {
    mode: "synthetic-only",
    inference: "NO_MODEL_DEFAULT / OPENAI_SYNTHETIC_WAITING_T4",
    model: process.env.OPENAI_MODEL ?? "gpt-6-luna",
    keyPresent: Boolean(process.env.OPENAI_API_KEY),
    fixtures,
    fixedCommands,
    now: now.toISOString(),
    members,
    inputs,
    replies: services.sent,
    messages,
    paused: app.store.paused,
    tasks: app.store.openTasks(),
    llmCalls: services.llmCalls,
    notes: app.store
      .notesV2()
      .map((note) => ({
        id: note.id,
        revision: note.revision,
        authorPhone: note.authorPhone,
        rawText: note.rawText,
        state: note.state,
        canConfirm:
          note.state === "draft" &&
          !note.replacementPending &&
          !note.issues.length &&
          !note.organized?.duvidas.length &&
          fixtures.some((fixture) => fixture.text === note.rawText) &&
          note.previewIds.length > 0 &&
          note.previewIds.every(
            (id) => app.store.outbox(id)?.state === "provider_accepted",
          ),
      })),
  };
}
function json(
  res: import("node:http").ServerResponse,
  status: number,
  value: unknown,
) {
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
    "x-content-type-options": "nosniff",
  });
  res.end(JSON.stringify(value));
}
const server = createServer((req, res) => {
  void (async () => {
    if (req.headers.host !== "127.0.0.1:3501")
      return json(res, 403, { error: "Abra http://127.0.0.1:3501" });
    if (req.method === "GET" && req.url === "/") {
      res.writeHead(200, {
        "content-type": "text/html; charset=utf-8",
        "cache-control": "no-store",
        "x-content-type-options": "nosniff",
        "content-security-policy":
          "default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
      });
      res.end(readFileSync(root + "/index.html"));
      return;
    }
    if (req.method === "GET" && req.url === "/api/state")
      return json(res, 200, state());
    if (req.method !== "POST" || req.url !== "/api/action")
      return json(res, 404, { error: "not_found" });
    if (
      req.headers.origin !== origin ||
      req.headers["content-type"] !== "application/json"
    )
      return json(res, 403, { error: "Origem inválida" });
    const chunks: Buffer[] = [];
    let size = 0;
    for await (const chunk of req) {
      size += chunk.length;
      if (size > 16384)
        return json(res, 413, { error: "Mensagem muito longa" });
      chunks.push(Buffer.from(chunk));
    }
    let input: {
      action?: string;
      text?: string;
      phone?: string;
      noteId?: string;
      revision?: number;
    };
    try {
      input = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    } catch {
      return json(res, 400, { error: "JSON inválido" });
    }
    if (!input || typeof input !== "object")
      return json(res, 400, { error: "Ação inválida" });
    if (
      Array.isArray(input) ||
      Object.keys(input).some(
        (key) =>
          !["action", "phone", "text", "noteId", "revision"].includes(key),
      )
    )
      return json(res, 400, { error: "Ação inválida" });
    const { action, phone = "5511900000001", text, noteId, revision } = input;
    if (
      text !== undefined &&
      (typeof text !== "string" || !allowedTexts.has(text))
    )
      return json(res, 400, {
        error: "Use somente os casos ou comandos sintéticos listados.",
      });
    if (
      !Object.hasOwn(members, phone) ||
      !["text", "audio", "advance", "confirm"].includes(action ?? "")
    )
      return json(res, 400, { error: "Ação inválida" });
    if (
      action === "text" &&
      (typeof text !== "string" || !allowedTexts.has(text))
    )
      return json(res, 400, {
        error: "Escreva uma mensagem de até 4000 caracteres",
      });
    if (
      action === "confirm" &&
      (typeof noteId !== "string" ||
        !/^[a-f0-9]{64}$/.test(noteId) ||
        !Number.isSafeInteger(revision) ||
        revision! < 1)
    )
      return json(res, 400, { error: "Revisão inválida" });
    const operation = queue.then(async () => {
      let selectedText = text;
      if (action === "confirm") {
        const note = app.store.noteV2(noteId!);
        const allowed = state().notes.find((item) => item.id === noteId);
        if (
          !note ||
          !allowed?.canConfirm ||
          note.authorPhone !== phone ||
          note.revision !== revision
        )
          return json(res, 409, {
            error:
              "A nota não está disponível para confirmação. Recarregue e revise.",
          });
        selectedText = `ok nota ${note.token}`;
      }
      if (action === "advance") {
        now = new Date(now.getTime() + 60 * 60 * 1000);
        await app.assistant.tick();
      } else {
        const id = randomUUID();
        const label =
          action === "audio"
            ? "🎤 Áudio de exemplo (transcrição simulada): " + sample
            : selectedText!.trim();
        const payload =
          action === "audio"
            ? {
                id,
                body: "",
                hasMedia: true,
                media: {
                  url: services.wahaUrl + "/api/files/exemplo.oga",
                  mimetype: "audio/ogg",
                },
              }
            : { id, body: selectedText!.trim() };
        state(); // Flush reminders before recording the next input.
        messages.push({ phone, label: "Você", text: label, reply: false });
        const reply = await fetch("http://127.0.0.1:3500/webhooks/waha", {
          method: "POST",
          headers: {
            "content-type": "application/json",
            "x-cvg-webhook-secret": secret,
          },
          body: JSON.stringify({
            event: "message",
            payload: { from: phone + "@c.us", fromMe: false, ...payload },
          }),
        });
        if (!reply.ok || !(await reply.json()).accepted)
          throw new Error("Webhook não aceitou a mensagem");
        inputs.push({ id, phone, label, at: now.toISOString() });
        await app.assistant.idle();
      }
      json(res, 200, state());
    });
    queue = operation.catch(() => {});
    await operation;
  })().catch((error) => {
    console.error("LOCAL_OPERATION_FAILED");
    if (!res.headersSent)
      json(res, 500, { error: "Falha no teste local; consulte run.log" });
    else res.end();
  });
});
server.on("error", (error) => {
  console.error("LOCAL_OPERATION_FAILED");
  process.exit(1);
});
await new Promise<void>((resolve) => server.listen(3501, "127.0.0.1", resolve));
writeFileSync(
  root + "/runtime.json",
  JSON.stringify(
    {
      pid: process.pid,
      console: origin,
      health: "http://127.0.0.1:3500/health",
      dataDir: dataRoot,
      startedAt: new Date().toISOString(),
      mode: "synthetic-local",
      sourceCandidate: "IMMUTABLE_PROGRAM_R19",
      sourceStatus: "IN_PROGRESS",
    },
    null,
    2,
  ),
);
console.log("Assistente de Plantão — sandbox local disponível em " + origin);
let stopping = false;
async function stop() {
  if (stopping) return;
  stopping = true;
  await new Promise<void>((resolve) => server.close(() => resolve()));
  await queue;
  await app.stop();
  await services.close();
  process.exit(0);
}
process.on("SIGTERM", () => void stop());
process.on("SIGINT", () => void stop());
