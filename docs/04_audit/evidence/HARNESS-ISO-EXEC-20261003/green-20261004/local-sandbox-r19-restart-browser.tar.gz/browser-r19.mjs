import { chromium } from '../candidate-final-r19/node_modules/playwright/index.mjs'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import { createHash } from 'node:crypto'
const base='http://127.0.0.1:3501'
const out=new URL('./output/browser-r19/',import.meta.url)
fs.mkdirSync(out,{recursive:true})
const browser=await chromium.launch({headless:true})
const page=await browser.newPage({viewport:{width:1280,height:1000}})
const errors=[]; page.on('pageerror',error=>errors.push(error.message))
const checks=[]; const record=(id)=>checks.push({id,status:'PASS'})
const state=async()=>await (await page.request.get(base+'/api/state')).json()
const post=async(body,origin=base)=>await page.request.post(base+'/api/action',{headers:{origin,'content-type':'application/json'},data:body})
try {
 await page.goto(base);await page.locator('#fixture option').first().waitFor({state:'attached'})
 let before=await state(); assert.equal(before.fixtures.length,20);assert.equal(before.keyPresent,true);assert.equal(before.model,'gpt-6-luna');assert.equal(before.llmCalls,0);record('frozen20-cases-private-key-presence-model-no-inference')
 const initialInputs=before.inputs.length
 for(const body of [{action:'text',phone:'5511900000001',text:'UNKNOWN_SYNTHETIC_SENTINEL'},{action:'text',phone:'5511999999999',text:'ajuda'},{action:'text',text:'ajuda',unexpected:true}]){const response=await post(body);assert.equal(response.status(),400)}
 assert.equal((await post({action:'text',text:'ajuda'},'https://synthetic.invalid')).status(),403)
 assert.equal((await state()).inputs.length,initialInputs);record('unknown-data-member-field-origin-no-effects')
 await page.locator('#member').selectOption('5511900000001');await page.locator('#fixture').selectOption(before.fixtures[0].text)
 await page.getByRole('button',{name:'Enviar caso',exact:true}).click()
 await page.waitForFunction(()=>document.querySelector('#status').textContent==='Concluído.')
 let current=await state();assert.equal(current.notes.length,before.notes.length+1)
 const note=current.notes.at(-1);assert.equal(note.rawText,before.fixtures[0].text);assert.equal(note.state,'draft');assert.equal(note.canConfirm,true);const inputsAfterNote=current.inputs.length;record('note-created-as-reviewable-draft')
 for(const body of [{action:'confirm',phone:'5511900000009',noteId:note.id,revision:note.revision},{action:'confirm',phone:'5511900000001',noteId:note.id,revision:note.revision+1},{action:'confirm',phone:'5511900000001',noteId:'f'.repeat(64),revision:1}]){const response=await post(body);assert.equal(response.status(),409)}
 assert.equal((await state()).inputs.length,inputsAfterNote);record('foreign-author-stale-unknown-note-no-webhook-effects')
 const taskCount=current.tasks.length
 await page.locator(`article.note[data-note-id="${note.id}"]`).getByRole('button',{name:'Confirmar esta nota',exact:true}).click()
 await page.waitForFunction((id)=>{const card=document.querySelector(`article.note[data-note-id="${id}"]`);return card?.textContent.includes('Nota confirmada.')},note.id)
 current=await state();assert.equal(current.notes.find(n=>n.id===note.id).state,'confirmed');assert.equal(current.tasks.length,taskCount);assert.equal(current.llmCalls,0);record('explicit-human-confirmation-raw-note-zero-derived-tasks-no-model')
 const inputsAfterConfirm=current.inputs.length;assert.equal((await post({action:'confirm',phone:'5511900000001',noteId:note.id,revision:note.revision})).status(),409);assert.equal((await state()).inputs.length,inputsAfterConfirm);record('repeat-confirmation-no-effects')
 await page.locator('#member').selectOption('5511900000009')
 await page.locator('#fixture').selectOption('pausar assistente');await page.getByRole('button',{name:'Enviar caso',exact:true}).click()
 await page.waitForFunction(()=>document.querySelector('#mode').textContent.includes('assistente pausado'));assert.equal((await state()).paused,true);record('manager-one-step-pause')
 await page.locator('#fixture').selectOption('retomar assistente');await page.getByRole('button',{name:'Enviar caso',exact:true}).click()
 await page.waitForFunction(()=>document.querySelector('#mode').textContent.includes('assistente ativo'));assert.equal((await state()).paused,false);record('manager-one-step-resume')
 await page.reload();await page.locator('#fixture option').first().waitFor({state:'attached'});current=await state();assert.equal(current.notes.find(n=>n.id===note.id).state,'confirmed');assert.equal(current.llmCalls,0);assert.equal(errors.length,0);record('reload-durable-note-zero-browser-errors')
 await page.screenshot({path:new URL('console.png',out).pathname,fullPage:true})
 const report={status:'PASS',checks,checkCount:checks.length,browserErrors:errors.length,model:'gpt-6-luna',keyPresenceOnly:true,keyValueRead:false,externalModelCalls:0,syntheticOnly:true,console:base,sourceHashes:Object.fromEntries(['server.mts','index.html'].map(name=>[name,createHash('sha256').update(fs.readFileSync(new URL(name,import.meta.url))).digest('hex')]))}
 fs.writeFileSync(new URL('verification.json',out),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:'PASS',checkCount:checks.length,browserErrors:errors.length,externalModelCalls:0}))
} finally {await browser.close()}
