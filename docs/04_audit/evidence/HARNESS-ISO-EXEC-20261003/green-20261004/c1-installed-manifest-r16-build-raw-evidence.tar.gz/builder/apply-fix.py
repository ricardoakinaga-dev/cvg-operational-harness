from pathlib import Path
c=Path('/home/ricardo/.cache/cvg-harness-green-20261004/c1-installed-manifest-r16-candidate')
p=c/'scripts/boundary-manifests.mjs';s=p.read_text();anchor='  function census(directory, result = new Set()) {\n';assert s.count(anchor)==1
new='''  function installedPackage(filename, name) {
    // Node supplies the declaring actor's package lookup order. No package
    // entrypoint or user expression is imported or executed for metadata.
    for (const parent of createRequire(filename).resolve.paths(name) ?? []) {
      if (!inside(root, parent)) continue
      const candidate = path.join(parent, name)
      let stat
      try { stat = fs.lstatSync(candidate) }
      catch (error) {
        if (error.code === 'ENOENT') continue
        throw error
      }
      const context = fs.realpathSync(candidate)
      if (!inside(root, context) || !fs.statSync(context).isDirectory())
        reject(candidate, 'physical_installed_directory_required')
      const manifest = path.join(context, 'package.json')
      return { context, manifest: fs.existsSync(manifest) ? manifest : undefined }
    }
    // A proven absent ordinary registry package is not a physical edge.
    // Any attempted import/loader still has its independent blocking checks.
    return undefined
  }
'''
s=s.replace(anchor,new+anchor);s=s.replace('return { read, census, localPackage, cache }','return { read, census, localPackage, installedPackage, cache }');p.write_text(s)
p=c/'scripts/check-product-boundary.mjs';s=p.read_text();anchor='''          const dependency = workspaces.get(targetName)
          if (dependency) edge(pkgFile, workspaceNode(dependency))
''';assert s.count(anchor)==1
replacement='''          const dependency = workspaces.get(targetName)
          if (dependency) edge(pkgFile, workspaceNode(dependency))
          else if (specifier.startsWith('workspace:'))
            reportDiagnostic(pkgFile, {
              file: path.relative(root, pkgFile),
              specifier: name,
              reason: 'UNVERIFIED_WORKSPACE_DEPENDENCY'
            })
          else {
            // Registry aliases are physically installed under their declared
            // key, not the registry target name. Resolve in this actor context.
            const installed = metadata.installedPackage(pkgFile, name)
            if (!installed) continue
            edge(pkgFile, installed.manifest ?? installed.context)
            const workspace = [...workspaces.values()].find(
              (item) => item.workspace === installed.context
            )
            if (workspace) edge(pkgFile, workspaceNode(workspace))
            else reportDiagnostic(pkgFile, {
              file: path.relative(root, pkgFile),
              specifier: name,
              reason: 'UNVERIFIED_INSTALLED_DEPENDENCY'
            })
            // Metadata closure can establish a known product violation even
            // while an installed implementation frontier remains unproven.
            if (installed.manifest) governActor(installed.context)
          }
'''
s=s.replace(anchor,replacement);p.write_text(s)
