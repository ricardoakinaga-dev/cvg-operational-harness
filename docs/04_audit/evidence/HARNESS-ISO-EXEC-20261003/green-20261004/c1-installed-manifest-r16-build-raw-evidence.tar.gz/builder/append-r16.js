
// R16: installed dependencies have physical identities and retain frontiers.
describe('R16 physical installed dependency metadata closure', () => {
 const fields=['dependencies','devDependencies','optionalDependencies','peerDependencies']
 function registryFixture(id,field,kind,reached=true){
  const root=path.join(output,'r16-inert',id)
  const put=(rel,v)=>{const p=path.join(root,rel);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v))}
  for(const d of ['packages/core/src','apps','legacy','products'])fs.mkdirSync(path.join(root,d),{recursive:true})
  put('package.json',{private:true,type:'module',workspaces:['packages/*','products/*']})
  put('packages/core/package.json',{name:'@synthetic/core',type:'module'})
  put('products/consumer/package.json',{name:'@synthetic/consumer',type:'module'})
  put('products/consumer/src/index.mts','export const label="product";')
  put('tsconfig.base.json',{compilerOptions:{module:'NodeNext',moduleResolution:'NodeNext',target:'ESNext',allowJs:true}})
  put('packages/core/src/index.mts',reached?'import "../../../auxiliary/bridge/src/index.mts";':'export const label="neutral";')
  put('auxiliary/bridge/package.json',{name:'@synthetic/bridge',type:'module'})
  put('auxiliary/bridge/src/index.mts','export const label="bridge";')
  const deps=kind==='workspace-missing'?{'@synthetic/missing':'workspace:*'}:kind==='alias'?{alias:'npm:external-next@1.0.0'}:{'external-next':'1.0.0'}
  put('auxiliary/bridge/dist/package.json',{[field]:deps})
  if(kind!=='workspace-missing'&&kind!=='registry-absent'){
   const key=kind==='alias'?'alias':'external-next'
   const loc='node_modules/'+key
   if(kind==='outside-link'){
    fs.mkdirSync(path.join(root,'node_modules'),{recursive:true});fs.symlinkSync('/tmp',path.join(root,loc));
   }else{
    put(loc+'/package.json',{name:'external-next',type:'module',...(kind==='neutral'||kind==='cycle'?{}:{[field]:{'@synthetic/consumer':'1.0.0'}})})
    put(loc+'/index.mjs','export const label="installed";')
    if(kind==='cycle')put(loc+'/package.json',{name:'external-next',type:'module',[field]:{bridge:'file:../../auxiliary/bridge'}})
   }
  }
  return root
 }
 it.each(fields.flatMap(f=>['direct','alias'].map(k=>[f,k])) )('%s/%s installed product metadata cannot PASS',(field,kind)=>{
  expect(auditProductBoundary(registryFixture('product-'+field+'-'+kind,field,kind)).status).toBe('FAIL')
 })
 it.each(fields)('%s absent explicit workspace remains blocking',field=>{
  const a=auditProductBoundary(registryFixture('missing-'+field,field,'workspace-missing'))
  expect(a.status).toBe('INCOMPLETE');expect(a.diagnostics.some(d=>d.reason==='UNVERIFIED_WORKSPACE_DEPENDENCY')).toBe(true)
 })
 it.each(fields)('%s installed implementation without proof remains blocking',field=>{
  const a=auditProductBoundary(registryFixture('neutral-'+field,field,'neutral'))
  expect(a.status).toBe('INCOMPLETE');expect(a.diagnostics.some(d=>d.reason==='UNVERIFIED_INSTALLED_DEPENDENCY')).toBe(true)
 })
 it.each(fields)('%s registry metadata cycles terminate and remain blocking',field=>{
  expect(auditProductBoundary(registryFixture('cycle-'+field,field,'cycle')).status).toBe('INCOMPLETE')
 })
 it.each(fields)('%s physically absent ordinary registry is not an implementation edge',field=>{
  expect(auditProductBoundary(registryFixture('absent-'+field,field,'registry-absent')).status).toBe('PASS')
 })
 it.each(fields.flatMap(f=>['direct','alias','workspace-missing','neutral'].map(k=>[f,k])))('%s/%s opaque unentered actor does not poison core',(field,kind)=>{
  expect(auditProductBoundary(registryFixture('opaque-'+field+'-'+kind,field,kind,false)).status).toBe('PASS')
 })
 it.each(fields)('%s installed symlink outside repository is refused',field=>{
  const root=registryFixture('outside-'+field,field,'outside-link');expect(()=>auditProductBoundary(root)).toThrow()
 })
})
