import fs from 'node:fs'
import path from 'node:path'
import { createRequire } from 'node:module'
import { fileURLToPath, pathToFileURL } from 'node:url'
const require = createRequire(import.meta.url)
const semver = require('semver')
export const manifestDependencyFields = [
  'dependencies',
  'devDependencies',
  'optionalDependencies',
  'peerDependencies'
]
export const packageName = (name) =>
  typeof name === 'string' &&
  /^(?:@[a-z0-9_][a-z0-9._-]*\/)?[a-z0-9_][a-z0-9._-]*$/i.test(name)
const record = (value) =>
  value !== null && typeof value === 'object' && !Array.isArray(value)
const inside = (root, file) => {
  const rel = path.relative(root, file)
  return (
    rel === '' ||
    (!rel.startsWith(`..${path.sep}`) && rel !== '..' && !path.isAbsolute(rel))
  )
}
export function createBoundaryManifestReader(root) {
  const cache = new Map()
  const censused = new Set()
  const reject = (filename, field) => {
    throw new Error(`invalid_boundary_manifest:${filename}:${field}`)
  }
  function read(filename, { rootManifest = false, requireName = false } = {}) {
    filename = path.resolve(filename)
    if (!inside(root, filename)) reject(filename, 'outside_repository')
    if (cache.has(filename)) {
      const value = cache.get(filename)
      if (requireName && !packageName(value.name)) reject(filename, 'name')
      if (rootManifest) workspaceShape(filename, value)
      return value
    }
    const stat = fs.lstatSync(filename)
    if (
      !stat.isFile() ||
      stat.isSymbolicLink() ||
      fs.realpathSync(filename) !== filename
    )
      reject(filename, 'physical_file_required')
    const value = JSON.parse(fs.readFileSync(filename, 'utf8'))
    if (!record(value)) reject(filename, 'object_required')
    if ((requireName || value.name !== undefined) && !packageName(value.name))
      reject(filename, 'name')
    if (
      value.type !== undefined &&
      !['module', 'commonjs'].includes(value.type)
    )
      reject(filename, 'type')
    if (rootManifest) workspaceShape(filename, value)
    for (const field of manifestDependencyFields) {
      if (value[field] === undefined) continue
      if (!record(value[field])) reject(filename, field)
      for (const [name, version] of Object.entries(value[field])) {
        if (!packageName(name) || typeof version !== 'string')
          reject(filename, field)
        const specifier = version.trim()
        if (specifier.startsWith('npm:')) {
          const alias = specifier.slice(4),
            separator = alias.lastIndexOf('@')
          const target = separator > 0 ? alias.slice(0, separator) : alias
          if (!packageName(target)) reject(filename, 'npm_alias')
          if (separator > 0) {
            const version = alias.slice(separator + 1)
            // Registry specs are semver ranges or npm tags, never a second URL.
            if (
              !version ||
              (!semver.validRange(version) &&
                encodeURIComponent(version) !== version)
            )
              reject(filename, 'npm_alias_version')
          }
        }
      }
    }
    // Memoize validated shape before following local edges, preserving cycles.
    // Any failed child aborts this audit; cache is private to one audit invocation.
    cache.set(filename, value)
    for (const field of manifestDependencyFields)
      for (const version of Object.values(value[field] ?? {}))
        if (/^(file|link):/.test(version.trim())) {
          const target = localPackage(filename, version)
          read(target, { requireName: true })
          census(path.dirname(target))
        }
    return value
  }
  function workspaceShape(filename, value) {
    if (
      !Array.isArray(value.workspaces) ||
      value.workspaces.some(
        (v) => typeof v !== 'string' || !v || v.trim() !== v
      ) ||
      new Set(value.workspaces).size !== value.workspaces.length
    )
      reject(filename, 'workspaces')
  }
  function localPackage(filename, version) {
    const specifier = version.trim(),
      suffix = specifier.slice(specifier.indexOf(':') + 1)
    if (!suffix || /[?#]/.test(suffix)) reject(filename, 'local_dependency')
    let target
    try {
      const url = new URL(
        'file:' + suffix,
        pathToFileURL(path.dirname(filename) + path.sep)
      )
      if (url.username || url.password || url.search || url.hash)
        reject(filename, 'local_dependency')
      target = fileURLToPath(url)
    } catch {
      reject(filename, 'local_dependency')
    }
    if (!inside(root, target) || !fs.existsSync(target))
      reject(filename, 'local_dependency')
    const resolved = fs.realpathSync(target)
    if (!inside(root, resolved) || !fs.statSync(resolved).isDirectory())
      reject(filename, 'local_dependency')
    return path.join(resolved, 'package.json')
  }
  function installedPackage(filename, name) {
    // Node supplies the declaring actor's package lookup order. No package
    // entrypoint or user expression is imported or executed for metadata.
    for (const parent of createRequire(filename).resolve.paths(name) ?? []) {
      if (!inside(root, parent)) continue
      const candidate = path.join(parent, name)
      try {
        fs.lstatSync(candidate)
      } catch (error) {
        if (error.code === 'ENOENT') continue
        throw error
      }
      const context = fs.realpathSync(candidate)
      if (!inside(root, context) || !fs.statSync(context).isDirectory())
        reject(candidate, 'physical_installed_directory_required')
      const manifest = path.join(context, 'package.json')
      return {
        context,
        manifest: fs.existsSync(manifest) ? manifest : undefined
      }
    }
    // A proven absent ordinary registry package is not a physical edge.
    // Any attempted import/loader still has its independent blocking checks.
    return undefined
  }
  function census(directory, result = new Set()) {
    if (!inside(root, directory)) reject(directory, 'outside_repository')
    if (!fs.existsSync(directory)) return result
    if (fs.realpathSync(directory) !== directory)
      reject(directory, 'physical_directory_required')
    if (censused.has(directory)) return result
    censused.add(directory)
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
      // Dependency installations and VCS are separate actors, not repo metadata.
      if (['node_modules', '.git'].includes(entry.name)) continue
      const file = path.join(directory, entry.name)
      if (entry.isSymbolicLink()) reject(file, 'physical_file_required')
      if (entry.isDirectory()) census(file, result)
      else if (entry.name === 'package.json') {
        read(file)
        result.add(file)
      }
    }
    return result
  }
  return { read, census, localPackage, installedPackage, cache }
}
