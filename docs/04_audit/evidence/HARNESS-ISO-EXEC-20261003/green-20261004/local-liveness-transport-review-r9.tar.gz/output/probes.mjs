import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createRequire, registerHooks, stripTypeScriptTypes} from 'node:module';
import net from 'node:net';
import http from 'node:http';
import https from 'node:https';
const out=path.dirname(fileURLToPath(import.meta.url)), source=path.join(out,'../source'), runtime=path.join(source,'runtime');
const loads=[];
registerHooks({resolve(specifier,context,next){const r=next(specifier,context);loads.push({specifier,parent:context.parentURL,url:r.url});if(r.url.startsWith('file:')){const p=fileURLToPath(r.url);if(!p.startsWith(runtime+'/')&&!p.startsWith(out+'/'))throw Error('outside execution boundary '+p);}return r;}});
const require=createRequire(path.join(runtime,'package.json'));
const Fastify=require('fastify');
const sec=await import(path.join(runtime,'apps/api/dist/http-security.js'));
const results=[], observations=[];
function check(id,ok,evidence){results.push({id,ok,evidence});}
function tokens(text){const re=/\/\*[\s\S]*?\*\/|\/\/[^\n]*|\s+|'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"|`(?:\\.|[^`\\])*`|[A-Za-z_$][\w$]*|\d[\w.]*|./g;return [...text.matchAll(re)].map(x=>x[0]).filter(x=>!/^\s|^\/\*|^\/\//.test(x)&&x!==';').map(x=>x.startsWith('"')?JSON.stringify(JSON.parse(x)):x.startsWith("'")?JSON.stringify(x.slice(1,-1)):x);}
const ts=fs.readFileSync(path.join(source,'apps/api/src/http-security.ts'),'utf8');
const stripped=stripTypeScriptTypes(ts).replaceAll('./response-correlation.ts','./response-correlation.js').replace(/\(HTTP_SECURITY_ALLOWED_HEADERS\s+\)/g,'HTTP_SECURITY_ALLOWED_HEADERS');
const compiled=fs.readFileSync(path.join(runtime,'apps/api/dist/http-security.js'),'utf8');
const a=tokens(stripped),b=tokens(compiled),first=a.findIndex((x,i)=>x!==b[i]);
check('source-compiled-significant-token-identity',JSON.stringify(a)===JSON.stringify(b),{sourceTokens:a.length,compiledTokens:b.length,first,around:first<0?[]:[a.slice(first-5,first+10),b.slice(first-5,first+10)],normalization:'Node22 type erasure; .ts import -> .js; remove redundant parentheses around HTTP_SECURITY_ALLOWED_HEADERS type assertion; skip comments, whitespace, semicolons; normalize quote delimiters'});
for(const f of ['apps/api/src/http-security.test.ts','apps/api/src/__tests__/http-security-edge-branches.test.ts','apps/api/src/__tests__/local-liveness-transport-own.test.ts']){const t=fs.readFileSync(path.join(source,f),'utf8');check('static-test-read:'+f,true,{bytes:Buffer.byteLength(t),executed:false});}
function security(r){return r.headers['content-security-policy']===sec.API_CONTENT_SECURITY_POLICY&&r.headers['x-content-type-options']==='nosniff'&&r.headers['x-frame-options']==='DENY'&&r.headers['referrer-policy']==='no-referrer'&&r.headers['x-permitted-cross-domain-policies']==='none';}
async function server(host,trust=[],tls=false){const app=Fastify({trustProxy:true,...(tls?{https:{key:fs.readFileSync(path.join(out,'tls-key.pem')),cert:fs.readFileSync(path.join(out,'tls-cert.pem'))}}:{})});
 app.addHook('onRequest',async req=>observations.push({method:req.method,rawUrl:req.raw.url,peer:req.raw.socket.remoteAddress,ip:req.ip,protocol:req.protocol,tls:Boolean(req.raw.socket.encrypted)}));
 sec.installHttpSecurityHooks(app,sec.normalizeHttpSecurityOptions({enforceHttps:true,allowedOrigins:['https://own.test'],trustedProxyAddresses:trust}));
 app.all('/live',async()=>({alive:true}));app.all('/health',async()=>({health:true}));app.all('/ready',async()=>({ready:true}));app.all('/other',async()=>({other:true}));
 await app.listen({host,port:0});return app;}
async function raw(app,host,target='/live',method='GET',headers={},localAddress){const port=app.server.address().port;return await new Promise((resolve,reject)=>{let buf='';const socket=net.connect({host,port,...(localAddress?{localAddress}:{})},()=>socket.write(`${method} ${target} HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n${Object.entries(headers).map(([k,v])=>`${k}: ${v}\r\n`).join('')}\r\n`));socket.setTimeout(4000,()=>socket.destroy(Error('timeout')));socket.on('data',d=>buf+=d);socket.on('error',reject);socket.on('end',()=>{const h=buf.split('\r\n\r\n')[0],lines=h.split('\r\n');resolve({status:Number(lines[0].split(' ')[1]),headers:Object.fromEntries(lines.slice(1).map(l=>{const i=l.indexOf(':');return [l.slice(0,i).toLowerCase(),l.slice(i+1).trim()]})),body:buf.slice(h.length+4)});});});}
async function probe(app,host,id,target,method,headers,status,localAddress){const r=await raw(app,host,target,method,headers,localAddress);check(id,r.status===status&&security(r)&&!r.headers['strict-transport-security'],{...r,expected:status,localAddress});return r;}
for(const host of ['127.0.0.1','::1','::ffff:127.0.0.1']){const app=await server(host);try{
 await probe(app,host,host+':exact','/live','GET',{},200);
 for(const target of ['/live?x=1','/live?','/%6cive','/l%69ve','/live/','//live','/LIVE','/health','/ready','/other','/live#x','http://localhost/live','/live%3Fx=1','/./live'])await probe(app,host,host+':path:'+target,target,'GET',{},426);
 for(const method of ['HEAD','POST','PUT','PATCH','DELETE','OPTIONS'])await probe(app,host,host+':method:'+method,'/live',method,{},426);
 await probe(app,host,host+':denied-origin','/live','GET',{origin:'https://evil.test'},403);
 const cors=await probe(app,host,host+':allowed-origin','/live','GET',{origin:'https://own.test'},200);check(host+':cors-headers',cors.headers['access-control-allow-origin']==='https://own.test'&&cors.headers.vary==='Origin'&&cors.headers['access-control-expose-headers']==='x-correlation-id',cors.headers);
 await probe(app,host,host+':spoof-forwarded-https','/other','GET',{'x-forwarded-for':'127.0.0.1','x-forwarded-proto':'https','x-forwarded-host':'localhost',forwarded:'for=127.0.0.1;proto=https'},426);
 if(host==='127.0.0.1')await probe(app,host,'real-peer-127.0.0.2-spoof','/live','GET',{'x-forwarded-for':'127.0.0.1','x-forwarded-proto':'https','x-real-ip':'127.0.0.1'},426,'127.0.0.2');
 }finally{await app.close();}}
const trusted=await server('127.0.0.1',['::ffff:7f00:1']);try{
 const r=await raw(trusted,'127.0.0.1','/other','GET',{'x-forwarded-proto':'https',origin:'https://own.test'});check('trusted-proxy-https-hsts-cors',r.status===200&&r.headers['strict-transport-security']==='max-age=31536000'&&r.headers['access-control-allow-origin']==='https://own.test'&&security(r),r);
 const p=await raw(trusted,'127.0.0.1','/other','OPTIONS',{'x-forwarded-proto':'https',origin:'https://own.test','access-control-request-method':'POST','access-control-request-headers':'content-type,x-tenant-id'});check('trusted-https-preflight',p.status===204&&p.headers['access-control-max-age']==='600'&&p.headers['strict-transport-security']==='max-age=31536000'&&security(p),p);
 const no=await raw(trusted,'127.0.0.1','/other','OPTIONS',{'x-forwarded-proto':'https',origin:'https://own.test','access-control-request-method':'DELETE'});check('trusted-https-preflight-denial',no.status===403&&no.headers['strict-transport-security']==='max-age=31536000'&&security(no),no);
}finally{await trusted.close();}
// Direct hook doubles cover absent/non-IP/nonlocal peers without connecting outside loopback.
const hooks={};sec.installHttpSecurityHooks({addHook:(n,f)=>hooks[n]=f},sec.normalizeHttpSecurityOptions({enforceHttps:true}));
for(const raw of [{url:'/live'},{url:'/live',socket:null},{url:'/live',socket:{}}]){let status=200;const reply={code(n){status=n;return this},header(){return this},send(){return this}};await hooks.onRequest({method:'GET',raw,headers:{'x-forwarded-for':'127.0.0.1','x-forwarded-proto':'https'},protocol:'https',ip:'127.0.0.1'},reply);check('absent-peer-with-spoofed-https:'+JSON.stringify(raw),status===426,{raw,status,expected:426,kind:'direct hook double'});}
for(const peer of [undefined,null,'','not-ip','localhost','0.0.0.0','::','10.2.0.7','127.0.0.2','::ffff:127.0.0.2','::1%lo','::127.0.0.1','127.000.000.001','0:0:0:0:0:0:0:1','::ffff:7f00:1','0:0:0:0:0:ffff:7f00:1']){let status=200,payload;const reply={code(n){status=n;return this},header(){return this},send(p){payload=p;return this}};await hooks.onRequest({method:'GET',raw:{url:'/live',socket:{remoteAddress:peer}},headers:{'x-forwarded-for':'127.0.0.1'},protocol:'http',ip:'127.0.0.1'},reply);const expected=['0:0:0:0:0:0:0:1','::ffff:7f00:1','0:0:0:0:0:ffff:7f00:1'].includes(peer)?200:426;check('hook-peer:'+String(peer),status===expected,{peer:peer??String(peer),status,expected,payload});}
if(fs.existsSync(path.join(out,'tls-key.pem'))){const app=await server('127.0.0.1',[],true);try{const r=await new Promise((resolve,reject)=>{https.get({hostname:'127.0.0.1',port:app.server.address().port,path:'/other',rejectUnauthorized:false,headers:{origin:'https://own.test'}},res=>{res.resume();res.on('end',()=>resolve({status:res.statusCode,headers:res.headers}))}).on('error',reject)});check('native-tls-hsts-cors',r.status===200&&r.headers['strict-transport-security']==='max-age=31536000'&&r.headers['access-control-allow-origin']==='https://own.test'&&security(r),r);}finally{await app.close();}}
fs.writeFileSync(path.join(out,'probes.json'),JSON.stringify({node:process.version,fastify:require('fastify/package.json').version,results,observations},null,2));
fs.writeFileSync(path.join(out,'module-trace.json'),JSON.stringify({kind:'Node module resolution observations, not syscall enforcement',loads},null,2));
console.log(JSON.stringify({checks:results.length,failures:results.filter(r=>!r.ok),realSocketObservations:observations.length}));
process.exitCode=results.some(r=>!r.ok)?1:0;
