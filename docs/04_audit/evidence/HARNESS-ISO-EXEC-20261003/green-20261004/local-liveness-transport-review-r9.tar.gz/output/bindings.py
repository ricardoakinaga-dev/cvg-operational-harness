import pathlib,json,hashlib,os,stat,time
p=pathlib.Path(__file__).resolve().parent.parent; out=p/'output'; src=p/'source'; cap=src/'current-captures'
def read(n): return json.loads((cap/n).read_text())
def sha(f): return hashlib.sha256(f.read_bytes()).hexdigest()
checks=[]
def check(id,ok,evidence): checks.append(dict(id=id,ok=bool(ok),evidence=evidence))
frozen=json.loads((p/'frozen-inventory.json').read_text()); before=json.loads((out/'source-before.json').read_text())
diff=[k for k,v in frozen.items() if v!={a:before.get(k,{}).get(a) for a in v}]
check('frozen-inventory-sha',sha(p/'frozen-inventory.json')=='7959db2ec64182b7e06b9d409b4b7a98b136cb701ede6f1c18777b56c922f8fc',sha(p/'frozen-inventory.json'))
check('source-before-frozen',not diff and len(frozen)==len(before),dict(count=len(before),diff=diff))
binding=read('artifact-binding.json'); unprovided=[]
for name,digest in binding['files'].items():
 target=src/name if name.startswith('runtime/') else src/'Dockerfile' if name=='context/Dockerfile' else cap/name
 if target.exists():check('artifact-hash:'+name,sha(target)==digest,dict(expected=digest,actual=sha(target)))
 else: unprovided.append(name)
q=read('qualification.json');m=read('physical-runtime-manifest.json');image=read('image-inspect.json')[0]; health=read('image-healthcheck.json');direct=read('image-healthcheck-direct-http.json')
check('image-id-bindings',binding['imageId']==m['imageId']==image['Id']==next(x['evidence']['image'] for x in q['checks'] if x['id']=='current-image-entrypoint-node22-physical'),binding['imageId'])
runtime_bad=[]
for f in m['files']:
 target=src/'runtime'/f['path']; expected=f.get('size',f.get('bytes'))
 if not target.is_file() or sha(target)!=f['sha256'] or target.stat().st_size!=expected: runtime_bad.append(f['path'])
check('physical-runtime-file-bindings',not runtime_bad,dict(count=len(m['files']),bad=runtime_bad))
link_bad=[]
for l in m['symlinks']:
 target=src/'runtime'/l['path']
 if not target.is_symlink() or os.readlink(target)!=l['link'] or target.resolve()!= (src/'runtime'/l['target']).resolve():link_bad.append(l['path'])
check('physical-runtime-link-bindings',not link_bad,dict(count=len(m['symlinks']),bad=link_bad))
res_bad=[]
for r in m['resolutions']:
 target=src/'runtime'/r['resolved']
 if not target.is_file():res_bad.append(r)
check('manifest-resolutions-exist',not res_bad,dict(count=len(m['resolutions']),bad=res_bad))
context=json.loads((src/'runtime/runtime-context.json').read_text())
check('runtime-context-binding',context==m['runtimeContext'],context)
check('entrypoint-binding',image['Config']['Cmd']==m['cmd']==['node','apps/api/dist/main.js'] and image['Config']['WorkingDir']=='/app' and image['Config']['User']==m['user']=='cvg',dict(cmd=m['cmd'],user=m['user']))
selected=read('source-before.json'); after=read('source-after.json'); sm={x['path']:x for x in selected['files']};am={x['path']:x for x in after['files']};check('capture-selected-source-before-after',sm==am,dict(count=len(sm),scope='813 selected build inputs only'))
for rel in ['Dockerfile','apps/api/src/http-security.ts','apps/api/src/http-security.test.ts','apps/api/src/__tests__/http-security-edge-branches.test.ts','apps/api/src/__tests__/local-liveness-transport-own.test.ts']:
 v=sm.get(rel); check('selected-source-binding:'+rel,v is not None and sha(src/rel)==v['sha256'],dict(capture=v,packetSha=sha(src/rel)))
projection=read('projection.json')
for x in projection['transforms']:
 check('neutral-projection:'+x['path'],sha(src/'runtime'/x['path'])==x['after'] and sm[x['path']]['sha256']==x['before'],x)
http=[json.loads(x) for x in (cap/'http.jsonl').read_text().splitlines()];db=[json.loads(x) for x in (cap/'database.jsonl').read_text().splitlines()];cmd=[json.loads(x) for x in (cap/'commands.jsonl').read_text().splitlines()]
check('22-current-groups',len(q['checks'])==22 and all(x['status']=='PASS' for x in q['checks']),[dict(id=x['id'],status=x['status'],observedAt=x['observedAt']) for x in q['checks']])
check('capture-time-window',all(q['startedAt']<=x['observedAt']<=q['finishedAt'] for x in http+db),dict(start=q['startedAt'],end=q['finishedAt'],http=len(http),sql=len(db),commands=len(cmd)))
check('healthcheck-config-binding',image['Config']['Healthcheck']==health['healthcheck']==next(x['evidence']['healthcheck'] for x in q['checks'] if x['id']=='public-image-healthcheck'),health)
check('direct-health-200',direct['status']==health['statusCode']==200 and health['exitCode']==0,direct)
hc=[x for x in cmd if len(x.get('argv',[]))>=6 and x['argv'][:3]==['docker','exec','cvg-r9-api'] and x['argv'][3:5]==['sh','-c'] and x['argv'][5]==health['healthcheck']['Test'][1]]
dc=[x for x in cmd if len(x.get('argv',[]))>=6 and x['argv'][:5]==['docker','exec','cvg-r9-api','node','-e'] and "fetch('http://127.0.0.1:3000/live')" in x['argv'][5]]
check('healthcheck-raw-command-correspondence',len(hc)==1 and hc[0]['exitCode']==0 and len(dc)==1 and dc[0]['exitCode']==0 and json.loads(dc[0]['stdout'])==direct,dict(health=hc,direct=dc))
faults=[x for x in http if x['label'].startswith('auth-fault-')];protected=[x for x in faults if '/v1/' in x['request']['url']]
check('raw-auth-fault-40-protected-503',len(protected)==40 and all(x['status']==503 for x in protected),[dict(label=x['label'],status=x['status']) for x in protected])
needed={'ready-auth-fault':503,'/health-auth-fault':200,'/live-auth-fault':200,'ready-auth-recovered':200,'admin-auth-recovered':200}
check('raw-fault-liveness-readiness',all(any(x['label']==label and x['status']==status for x in http) for label,status in needed.items()),needed)
check('raw-sql-fault-revoke-grant',any('REVOKE EXECUTE' in x['text'] and 'operator_session_get' in x['text'] for x in db) and any('GRANT EXECUTE' in x['text'] and 'operator_session_get' in x['text'] for x in db),dict(rows=[dict(observedAt=x['observedAt'],text=x['text']) for x in db if 'operator_session_get' in x['text'] and any(t in x['text'] for t in ['REVOKE EXECUTE','GRANT EXECUTE'])]))
restart=next(x['evidence'] for x in q['checks'] if x['id']=='real-restart-session-and-queue-persistence')
check('restart-data-invariants',restart['pidBefore']!=restart['pidAfter'] and restart['startedBefore']!=restart['startedAfter'] and restart['queueBefore']==restart['queueAfter'] and restart['cookieAdmin']==200 and restart['persistedReplay']==401,dict(pidBefore=restart['pidBefore'],pidAfter=restart['pidAfter'],before=restart['startedBefore'],after=restart['startedAfter'],queueSame=restart['queueBefore']==restart['queueAfter']))
stops=[x for x in cmd if x.get('argv',[])==['docker','stop','--time','15','cvg-r9-api']];starts=[x for x in cmd if x.get('argv',[])==['docker','start','cvg-r9-api']]
check('raw-restart-stop-start',bool(stops and starts) and stops[0]['exitCode']==starts[0]['exitCode']==0 and stops[0]['observedAt']<starts[0]['observedAt']<restart['startedAfter'],dict(stop=stops[0] if stops else None,start=starts[0] if starts else None))
inspects=[]
for x in cmd:
 if x.get('argv',[])==['docker','inspect','cvg-r9-api'] and x.get('exitCode')==0:
  try: inspects+=json.loads(x['stdout'])
  except (ValueError,TypeError):pass
check('restart-raw-pid-startedAt',any(x['State']['Pid']==restart['pidBefore'] and x['State']['StartedAt']==restart['startedBefore'] for x in inspects) and any(x['State']['Pid']==restart['pidAfter'] and x['State']['StartedAt']==restart['startedAfter'] for x in inspects),dict(inspectObservations=len(inspects)))
check('restart-session-snapshots',restart['sessionsBefore']==restart['sessionsAfter'],dict(sessions=len(restart['sessionsBefore'])))
check('restart-raw-http',all(any(x['label']==label and x['status']==status for x in http) for label,status in {'restart-cookie-admin':200,'restart-hmac-replay':401}.items()),dict(admin=200,replay=401))
negatives=[]
for x in cmd:
 a=x.get('argv',[])
 if len(a)==3 and a[:2]==['docker','inspect'] and a[2].startswith('cvg-r9-preflight-') and x.get('exitCode')==0:
  try:
   for o in json.loads(x['stdout']):
    if not o['State']['Running']:negatives.append(dict(name=a[2],exitCode=o['State']['ExitCode']))
  except (ValueError,KeyError,TypeError): pass
check('nine-raw-negative-preflight-exits',len({x['name'] for x in negatives})==9 and all(x['exitCode']==1 for x in negatives),negatives)
details=dict(checks=checks,unprovidedBindingArtifacts=unprovided,limitations=q['limitations'],sourceIntegrity=read('source-integrity.json'),cleanup=read('cleanup.json'),captureScope=binding['scope'],independentPgRerun=False)
(out/'bindings.json').write_text(json.dumps(details,indent=2));print(json.dumps(dict(checks=len(checks),failures=[x for x in checks if not x['ok']],unprovided=unprovided),indent=2))
