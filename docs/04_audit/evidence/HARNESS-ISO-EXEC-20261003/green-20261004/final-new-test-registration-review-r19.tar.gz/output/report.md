# I1 R19 — ACCEPT

Escopo: metadata-only. Node v22.23.2; 20 checks; 0 falhas.

Delta: 371 registros baseline preservados; cobertura 275+6 = 281; 44 caminhos anteriores preservados + somente dois testes fornecidos = 46 ordenados. CI: apenas um dígito na asserção 44 → 46. Onze pares de inputs restantes idênticos em bytes. Sete configs da fixture, rulesHash, fingerprints neutros e semver conferidos diretamente nos bytes. Pisos 90/90/90/85 preservados.

- Original 371 baseline test files not supplied: only inventory records preserved; no assertion of source byte integrity or execution.
- No test payload, producer CLI, runtime, C1, fullsuite, PG, provider, network or production execution/acceptance.
- Absolute critical threshold 95 and extra-mutant validator definitions are not supplied; only unchanged references/guard bytes proven.
- Two policy configs verified as embedded fixture content; no external docs/config paths read.
- Initial exploratory hash/snapshot used default Node24; all final checks and seals independently repeated with Node22.23.2.
- Template fallthrough checks use own structural AST stubs with extracted pure routine, not TypeScript parsing or compilation.

Negativos próprios em memória: remoção, tamper de registro, contagem menor, mudança de cobertura, substituição de caminho, contagem CI menor e conteúdo de fixture adulterado. Rotina pura: template como expressão → executável; sintaxe desconhecida → oracle/null. Inputs conferidos antes/depois por SHA, bytes, modo e mtimeNs.

Detalhes e traces finitos em report.json; snapshots antes/depois e selo em evidence-manifest.json.
