'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const acorn = require('internal/deps/acorn/acorn/dist/acorn');
if (process.versions.node.split('.')[0] !== '22') throw Error('Node22 required');
const packet = '/home/ricardo/.cache/cvg-harness-green-20261004/decimal-frontier-fresh-review-r33';
const out = path.join(packet, 'output');
const sha = x => crypto.createHash('sha256').update(x).digest('hex');
const canon = x => JSON.stringify(x);
const reads = [], checks = [];
function read(p, role) {
  const b = fs.readFileSync(p), s = fs.statSync(p);
  reads.push({path:p, role, realpath:fs.realpathSync(p), sha256:sha(b), bytes:b.length, device:s.dev, inode:s.ino, nlink:s.nlink, mode:s.mode, mtimeMs:s.mtimeMs});
  return b;
}
function json(p, role) { return JSON.parse(read(p,role)); }
function write(name, v) { fs.writeFileSync(path.join(out,name), JSON.stringify(v,null,2)+'\n'); }
function check(id, ok, detail) { checks.push({id, result:ok?'MATCH':'MISMATCH', detail}); }
const authority = json(path.join(packet,'authority.json'),'review authority');
if (authority.write !== out) throw Error('write authority mismatch');
read(__filename,'owned independent AST tooling');
read(process.execPath,'Node22 executable including Acorn');
json(path.join(out,'scope-plan.json'),'frozen review scope');
const i0 = authority.i0Readonly;
const originals = json(path.join(i0,'observations.json'),'original ordered observations');
const proposals = json(path.join(i0,'output/proposed-dispositions.json'),'I0 proposals, not accepted diagnoses');
const lines = json(path.join(i0,'output/line-bindings.json'),'I0 physical line evidence');
const evidence = json(path.join(i0,'output/evidence-nodes.json'),'I0 node evidence');
const graphs = json(path.join(i0,'output/function-caller-assignment-graphs.json'),'I0 finite caller assignment assertions');
const proofs = json(path.join(i0,'output/shared-proofs.json'),'I0 proof assertions');
const entries = json(path.join(i0,'output/entry-exports.json'),'I0 entry assertions');
const missing = json(path.join(i0,'output/missing-evidence.json'),'I0 declared unknowns');
const producerReport = json(path.join(i0,'output/report.json'),'I0 assertion scope');
const constructorSites = json(path.join(i0,'output/constructor-sites.json'),'I0 constructor site assertions');
const pmap = new Map(lines.map(x=>[x.id,x]));
const isFn = n => n && ['FunctionDeclaration','FunctionExpression','ArrowFunctionExpression'].includes(n.type);
function model(src, rel, variant) {
  const ast=acorn.parse(src,{ecmaVersion:'latest',sourceType:rel.endsWith('.mjs')?'module':'script',locations:true,ranges:true});
  const nodes=[], parent=new Map(), owner=new Map(), enclosing=new Map(), fns=[], scopes=new Map();
  const id = n => n?`${variant}:${n.type}:${n.start}:${n.end}`:null;
  const text = n => n?src.slice(n.start,n.end):null;
  function walk(n,p,fn) {
    if (!n || !n.type) return;
    parent.set(n,p);
    if (isFn(n)) { enclosing.set(n,fn||ast); fns.push(n); fn=n; }
    owner.set(n,fn||ast); nodes.push(n);
    for (const [k,v] of Object.entries(n)) {
      if (['loc','range','start','end'].includes(k)) continue;
      if (Array.isArray(v)) v.forEach(c=>walk(c,n,fn));
      else if (v && typeof v.type==='string') walk(v,n,fn);
    }
  }
  walk(ast,null,null);
  for (const s of [ast,...fns]) scopes.set(s,new Map());
  function bind(s,name,n,value) {
    if (!name) return;
    const t=scopes.get(s), b=t.get(name)||{name,scope:s,declarations:[],values:[]};
    b.declarations.push(n); if(value)b.values.push(value);t.set(name,b);
  }
  for (const f of fns) {
    for (const p of f.params) if(p.type==='Identifier') bind(f,p.name,p,null);
    if(f.id) {
      bind(f,f.id.name,f,f);
      if(f.type==='FunctionDeclaration') bind(enclosing.get(f),f.id.name,f,f);
    }
  }
  for(const n of nodes) if(n.type==='VariableDeclarator'&&n.id.type==='Identifier')bind(owner.get(n),n.id.name,n,n.init);
  function lookup(n) {
    let s=owner.get(n);
    while(s) {const b=scopes.get(s).get(n.name);if(b)return b;s=s===ast?null:enclosing.get(s);}
    return null;
  }
  for(const n of nodes)if(n.type==='AssignmentExpression'&&n.left.type==='Identifier'){
    const b=lookup(n.left);if(b)b.values.push(n.right);
  }
  const calls=nodes.filter(n=>['CallExpression','NewExpression'].includes(n.type));
  const assignments=nodes.filter(n=>['AssignmentExpression','VariableDeclarator'].includes(n.type));
  const returns=nodes.filter(n=>n.type==='ReturnStatement');
  function functionValue(n,seen=new Set()) {
    if (!n||seen.has(n))return null;seen.add(n);
    if(isFn(n))return n;
    if(n.type==='Identifier') {
      const b=lookup(n);if(!b)return null;
      const vals=b.values.map(v=>functionValue(v,new Set(seen))).filter(Boolean);
      const unique=[...new Set(vals)];return unique.length===1?unique[0]:null;
    }
    if(n.type==='CallExpression'&&isFn(n.callee)) {
      const rs=returns.filter(r=>owner.get(r)===n.callee && isFn(r.argument));
      return rs.length===1?rs[0].argument:null;
    }
    return null;
  }
  const property = n => n?.type==='MemberExpression'?n.computed?n.property.type==='Literal'?String(n.property.value):null:n.property.name:null;
  const constructors=nodes.filter(n=>property(n)==='constructor');
  const byId=new Map(nodes.map(n=>[id(n),n]));
  const starts=[0];for(let i=0;i<src.length;i++)if(src[i]==='\n')starts.push(i+1);
  function span(line) {const start=starts[line-1],end=starts[line]??src.length;return {start,end,byteStart:Buffer.byteLength(src.slice(0,start)),byteEnd:Buffer.byteLength(src.slice(0,end)),snippet:src.slice(start,end),snippetSha256:sha(src.slice(start,end))};}
  function ref(n) {return n?{id:id(n),type:n.type,start:n.start,end:n.end,loc:n.loc,byteStart:Buffer.byteLength(src.slice(0,n.start)),byteEnd:Buffer.byteLength(src.slice(0,n.end)),text:text(n),textSha256:sha(text(n))}:null;}
  function callRef(n) {const target=n.callee.type==='Identifier'?functionValue(n.callee):isFn(n.callee)?n.callee:null;return {...ref(n),callee:ref(n.callee),args:n.arguments.map(ref),caller:id(owner.get(n)),target:id(target),resolution:target?'LOCAL_SYNTACTIC_ROUTE':n.callee.type==='Identifier'&&lookup(n.callee)?'LOCAL_VALUE_IDENTITY_UNRESOLVED':'EXTERNAL_OR_MEMBER_IDENTITY_UNRESOLVED'};}
  return {src,rel,variant,ast,nodes,parent,owner,enclosing,fns,scopes,id,text,lookup,functionValue,calls,assignments,returns,property,constructors,byId,span,ref,callRef};
}
const models=[];
for(const [variant,rel] of [['umd','node_modules/decimal.js/decimal.js'],['esm','node_modules/decimal.js/decimal.mjs']]){
  const b=read(path.join(authority.sourceReadonly,rel),'physical runtime, read as data only');
  const m=model(b.toString('utf8'),rel,variant);m.hash=sha(b);models.push(m);
  write(`${variant}.independent-ast.json`,m.ast);
  write(`${variant}.independent-facts.json`,{
    file:rel,sha256:m.hash,nodeCount:m.nodes.length,
    functions:m.fns.map(f=>({node:m.ref(f),parent:m.id(m.enclosing.get(f)),params:f.params.map(m.ref),assignments:m.assignments.filter(a=>m.owner.get(a)===f).map(m.ref)})),
    calls:m.calls.map(m.callRef),constructorMembers:m.constructors.map(m.ref),
    assignments:m.assignments.map(m.ref),exports:m.nodes.filter(n=>/^Export|^Import/.test(n.type)).map(m.ref)
  });
}
const mmap=new Map(models.map(m=>[m.rel,m]));
const failures=[], accounting=[], reviewedLines=[];
const tally={}, seen=new Map(), mult=new Map();
for(const r of originals)mult.set(r.observation.file,(mult.get(r.observation.file)||0)+1);
check('ROWS_CARDINALITY', originals.length===1072&&proposals.length===1072,{original:originals.length,proposed:proposals.length});
for(let i=0;i<originals.length;i++){
  const o=originals[i],p=proposals[i];const k=o.observation.file;
  const duplicateOrdinal=seen.get(k)||0;seen.set(k,duplicateOrdinal+1);
  const cut=k.lastIndexOf(':'),file=k.slice(0,cut),line=Number(k.slice(cut+1)),m=mmap.get(file);
  const b=pmap.get(p?.lineEvidence), errors=[];
  if(!p||canon(o)!==canon(p.originalRow)||o.diagnosticIndex!==p.diagnosticIndex)errors.push('original order/identity');
  if(p.originalRowCanonicalSha256!==sha(canon(o)))errors.push('original hash');
  if(p.file!==file||p.line!==line||p.fileSha256!==m.hash)errors.push('physical binding');
  if(p.duplicateOrdinal!==duplicateOrdinal||p.duplicateCount!==mult.get(k))errors.push('duplicate accounting');
  if(p.frontierAccepted!==false||!p.missingEvidence.includes('M_ROW_TOKEN'))errors.push('token gap/suppression');
  if(!b||b.file!==file||b.line!==line||b.proposedClassification!==p.proposedClassification)errors.push('line proposal consistency');
  if(b && p.functionGraph!==b.functionGraph)errors.push('row graph link');
  for(const cid of p.exactAstCandidateIds||[]) {
    const n=m.byId.get(cid);if(!n||!(n.start<m.span(line).end&&n.end>m.span(line).start))errors.push('candidate span:'+cid);
  }
  const c=p.proposedClassification;tally[c]=(tally[c]||0)+1;
  accounting.push({position:i,originalRow:o,originalRowSha256:sha(canon(o)),file,fileSha256:m.hash,line,duplicateOrdinal,duplicateCount:mult.get(k),ordinalMeaning:'observation occurrence only; no scanner-token ordinal',proposedClassification:c,lineEvidence:p.lineEvidence,exactAstCandidateIds:p.exactAstCandidateIds,reviewErrors:errors,tokenIdentity:'UNKNOWN',scannerDiagnosticAccepted:false,suppressionGranted:false});
  failures.push(...errors.map(e=>({row:i,diagnosticIndex:o.diagnosticIndex,error:e})));
}
check('ALL_1072_ORDER_HASH_DUPLICATES_TOKEN_GAP',failures.length===0,failures);
const evidenceErrors=[];
for(const e of evidence){
  const m=mmap.get(e.file),n=m?.byId.get(e.id);
  if(!n||e.fileSha256!==m.hash||e.snippet!==m.text(n)||e.snippetSha256!==sha(m.text(n))||e.byteStart!==Buffer.byteLength(m.src.slice(0,n.start))||e.byteEnd!==Buffer.byteLength(m.src.slice(0,n.end))||canon(e.loc)!==canon(n.loc))evidenceErrors.push(e.id);
}
check('ALL_I0_NODE_SPANS_BYTES_LOC_HASH',evidenceErrors.length===0,{checked:evidence.length,errors:evidenceErrors});
const lineErrors=[], classificationErrors=[];
for(const b of lines){
  const m=mmap.get(b.file),s=m.span(b.line),errors=[];
  for(const k of ['start','end','byteStart','byteEnd','snippet','snippetSha256'])if(b[k]!==s[k])errors.push(k);
  if(b.fileSha256!==m.hash)errors.push('file hash');
  const rows=originals.filter(o=>o.observation.file===`${b.file}:${b.line}`);
  if(canon(b.diagnosticIndices)!==canon(rows.map(o=>o.diagnosticIndex))||b.multiplicity!==rows.length)errors.push('multiplicity/order');
  const beginning=m.nodes.filter(n=>n.loc.start.line===b.line), ctorCalls=beginning.filter(n=>['NewExpression','CallExpression'].includes(n.type)&&
    (['Ctor','Decimal'].includes(m.text(n.callee))||n.callee.type==='ThisExpression'||m.property(n.callee)==='constructor'));
  const transfers=beginning.filter(n=>n.type==='CallExpression'&&n.arguments.some(a=>m.text(a)==='Ctor'||m.property(a)==='constructor'));
  const ctorRefs=beginning.filter(n=>m.property(n)==='constructor');
  const owner=m.owner.get(ctorCalls[0]||transfers[0]||ctorRefs[0]||beginning.find(n=>n.type!=='Identifier'));
  const ownerName=owner?.id?.name;
  const tokens=beginning.filter(n=>['Identifier','ThisExpression'].includes(n.type)).map(m.id).sort();
  if(canon(tokens)!==canon([...b.tokenCandidates].sort()))errors.push('complete set of line identifier/this candidates');
  const relevant=beginning.filter(n=>/Expression$|Statement$|Declaration$|Declarator$/.test(n.type)&&!['ThisExpression','FunctionExpression'].includes(n.type)).map(m.id).sort();
  if(canon(relevant)!==canon([...b.exactAstNodesBeginningOnLine].sort()))errors.push('complete set of line expression/statement candidates');
  for(const d of b.identifierDefUse){
    const n=m.byId.get(d.node),p=m.parent.get(n);
    const propertyKey=p?.type==='MemberExpression'&&!p.computed&&p.property===n;
    const binding=propertyKey?null:m.lookup(n);
    if(d.binding.node&&(!binding||!binding.declarations.some(a=>m.id(a)===d.binding.node)))errors.push('lexical def/use:'+d.node);
    if(propertyKey&&d.binding.kind!=='PROPERTY_KEY_NOT_LEXICAL_BINDING')errors.push('property key treated as lexical:'+d.node);
    const expectedFunctionOwner=m.owner.get(n)===m.ast?null:m.id(m.owner.get(n));
    if(d.ownerFunction!==expectedFunctionOwner||d.parent!==m.id(p))errors.push('def/use owner/parent:'+d.node);
  }
  let independentlyExpected;
  if(ctorCalls.length)independentlyExpected=ownerName==='parseOther'?'PROPOSED_OWN_NUMERIC_CONSTRUCTOR_ROUTE':'UNRESOLVED_CONSTRUCTOR_IDENTITY_AT_INVOCATION_LINE';
  else if(transfers.length)independentlyExpected='UNRESOLVED_CONSTRUCTOR_TRANSFER_LINE';
  else if(ctorRefs.length){
    const writes=ctorRefs.filter(n=>m.parent.get(n)?.type==='AssignmentExpression'&&m.parent.get(n).left===n);
    independentlyExpected=writes.length?'PROPOSED_OWN_NUMERIC_CONSTRUCTOR_ASSIGNMENT':
      ['parseOther','parseDecimal'].includes(ownerName)?'PROPOSED_OWN_CONSTRUCTOR_DATA_REFERENCE':'PROPOSED_EXPRESSION_DATA_USE';
  } else independentlyExpected='PROPOSED_EXPRESSION_DATA_USE';
  if(independentlyExpected!==b.proposedClassification)classificationErrors.push({id:b.id,expected:independentlyExpected,actual:b.proposedClassification,owner:ownerName});
  lineErrors.push(...errors.map(error=>({id:b.id,error})));
  reviewedLines.push({id:b.id,file:b.file,fileSha256:m.hash,line:b.line,...s,multiplicity:b.multiplicity,diagnosticIndices:b.diagnosticIndices,classification:b.proposedClassification,independentlyExpected,
    constructorCalls:ctorCalls.map(m.callRef),constructorTransfers:transfers.map(m.callRef),constructorReferences:ctorRefs.map(m.ref),allBeginningNodes:beginning.map(m.ref),
    dataExpressionCandidates:beginning.filter(n=>['BinaryExpression','LogicalExpression','UnaryExpression','UpdateExpression','MemberExpression','AssignmentExpression','ConditionalExpression'].includes(n.type)).map(m.ref),
    identityLimit:'All candidates are a set at this physical line. No original scanner offset is available; no row-to-token association is asserted.',errors});
}
check('ALL_688_LINE_SPANS_HASH_ORDER',lineErrors.length===0,{checked:lines.length,errors:lineErrors});
check('INDEPENDENT_LINE_ROLE_CLASSIFICATION',classificationErrors.length===0,{checked:lines.length,errors:classificationErrors});
check('ROW_TOTALS_16_732_324',(tally.PROPOSED_EXPRESSION_DATA_USE===732)&&
  (tally.PROPOSED_OWN_CONSTRUCTOR_DATA_REFERENCE+tally.PROPOSED_OWN_NUMERIC_CONSTRUCTOR_ROUTE+tally.PROPOSED_OWN_NUMERIC_CONSTRUCTOR_ASSIGNMENT===16)&&
  (tally.UNRESOLVED_CONSTRUCTOR_IDENTITY_AT_INVOCATION_LINE+tally.UNRESOLVED_CONSTRUCTOR_TRANSFER_LINE===324),tally);
const graphErrors=[],graphCoverage=[];
for(const m of models){
  const gs=graphs.filter(g=>g.id.startsWith(m.variant+':')),calls=new Map();
  for(const g of gs)for(const c of g.outgoingCallEdges)calls.set(c.id,c);
  for(const n of m.calls){
    const c=calls.get(m.id(n));if(!c){graphErrors.push({id:m.id(n),error:'missing caller edge'});continue;}
    const expectedOwner=m.owner.get(n)===m.ast?null:m.id(m.owner.get(n));
    if(c.callerFunction!==expectedOwner||c.callee!==m.id(n.callee)||canon(c.arguments)!==canon(n.arguments.map(m.id)))graphErrors.push({id:c.id,error:'callee/argument/owner'});
    const target=n.callee.type==='Identifier'?m.functionValue(n.callee):isFn(n.callee)?n.callee:null;
    if(c.resolution==='LEXICAL_LOCAL_FUNCTION'||c.resolution==='LOCAL_IIFE')if(c.targetFunction!==m.id(target))graphErrors.push({id:c.id,error:'local callee binding',claimed:c.targetFunction,independent:m.id(target)});
    if(c.resolution==='PROTOTYPE_MEMBER_NAME_ROUTE_CONDITIONAL'&&!c.assumption)graphErrors.push({id:c.id,error:'member route asserted without condition'});
  }
  const assigned=gs.flatMap(g=>g.localAssignments).map(a=>typeof a==='string'?a:a.node||a.id);
  for(const g of gs){
    const fn=m.byId.get(g.function);
    const actualAssignments=m.assignments.filter(a=>m.owner.get(a)===fn).map(m.id);
    if(canon(g.localAssignments)!==canon(actualAssignments))graphErrors.push({id:g.id,error:'local assignments',actual:actualAssignments,claimed:g.localAssignments});
    const actualIncoming=[...calls.values()].filter(c=>c.targetFunction===g.function).map(c=>c.id);
    if(canon(g.incomingCallEdges.map(c=>c.id))!==canon(actualIncoming))graphErrors.push({id:g.id,error:'incoming calls'});
    for(const cid of g.exportedBindings){
      if(fn===m.ast){
        // Program graph carries entry anchors, not a method-function assignment relation.
        const entry=entries.find(e=>e.file===m.rel);
        if(!m.byId.has(cid)||!entry.nodes.includes(cid))graphErrors.push({id:g.id,error:'program entry anchor',anchor:cid});
        continue;
      }
      const a=m.byId.get(cid);let rhs=a?.right;
      while(rhs?.type==='AssignmentExpression')rhs=rhs.right;
      if(a?.type!=='AssignmentExpression'||(rhs!==fn&&m.functionValue(rhs)!==fn))graphErrors.push({id:g.id,error:'public assignment binding',assignment:cid});
    }
  }
  graphCoverage.push({file:m.rel,functions:m.fns.length,graphs:gs.length,calls:m.calls.length,claimedUniqueOutgoing:calls.size,assignmentCount:m.assignments.length,claimedAssignmentCount:assigned.length});
  if(calls.size!==m.calls.length)graphErrors.push({file:m.rel,error:'caller cardinality'});
}
check('FINITE_ACTUAL_CALLER_CALLEE_ARGUMENT_GRAPH',graphErrors.length===0,{coverage:graphCoverage,errors:graphErrors});
const facts=[],proofErrors=[];
for(const m of models){
  const findFn=name=>m.fns.find(f=>f.id?.name===name),Decimal=findFn('Decimal'),clone=findFn('clone'),pd=findFn('parseDecimal'),po=findFn('parseOther'),config=findFn('config'),recognition=findFn('isDecimalInstance');
  const ownWrites=m.assignments.filter(a=>a.type==='AssignmentExpression'&&m.text(a.left)==='x.constructor'&&m.owner.get(a)===Decimal);
  const ownWrite=ownWrites[0];
  const parserCalls=m.calls.filter(c=>c.callee.type==='Identifier'&&['parseOther','parseDecimal'].includes(c.callee.name));
  const parserWrites=m.assignments.filter(a=>a.type==='AssignmentExpression'&&m.property(a.left)==='constructor'&&[pd,po].includes(m.owner.get(a)));
  const parserRefs=m.nodes.filter(n=>n.type==='Identifier'&&['parseOther','parseDecimal'].includes(n.name)).map(n=>({node:m.ref(n),parent:m.ref(m.parent.get(n)),boundDeclaration:m.lookup(n)?.declarations.map(m.id)}));
  const poCalls=parserCalls.filter(c=>c.callee.name==='parseOther'),pdCalls=parserCalls.filter(c=>c.callee.name==='parseDecimal');
  const factoryReturns=m.returns.filter(r=>m.owner.get(r)===clone);
  const routeErrors=[];
  if(m.enclosing.get(Decimal)!==clone||ownWrites.length!==1||m.text(ownWrite.right)!=='Decimal')routeErrors.push('producer lexical assignment');
  if(factoryReturns.length!==1||m.text(factoryReturns[0].argument)!=='Decimal')routeErrors.push('factory return');
  if(poCalls.length!==1||m.owner.get(poCalls[0])!==Decimal||m.text(poCalls[0].arguments[0])!=='x'||poCalls[0].start<ownWrite.end)routeErrors.push('parseOther producer caller');
  if(pdCalls.length!==4||pdCalls.some(c=>![Decimal,po].includes(m.owner.get(c))||m.text(c.arguments[0])!=='x'))routeErrors.push('parseDecimal producer caller');
  if(parserWrites.length)routeErrors.push('parser constructor write');
  const knownDynamic=m.calls.filter(c=>['eval','Function','require','import'].includes(m.text(c.callee)));
  if(knownDynamic.length)routeErrors.push('syntactic evaluator/loader');
  for(const name of ['parseOther','parseDecimal']){
    const nonCallerRefs=m.nodes.filter(n=>n.type==='Identifier'&&n.name===name&&m.parent.get(n)?.type!=='FunctionDeclaration'&&!(m.parent.get(n)?.type==='CallExpression'&&m.parent.get(n).callee===n));
    if(nonCallerRefs.length)routeErrors.push('parser escaping reference:'+name);
  }
  const pkeys=m.nodes.find(n=>n.type==='VariableDeclarator'&&n.id.name==='ps'&&m.owner.get(n)===config&&n.init?.type==='ArrayExpression');
  const configKeys=pkeys.init.elements.filter((_,i)=>i%3===0).map(n=>n.value);
  const prototype=m.assignments.filter(a=>a.type==='AssignmentExpression'&&m.text(a.left)==='Decimal.prototype'&&m.owner.get(a)===clone);
  const staticThis=m.calls.filter(c=>c.type==='NewExpression'&&c.callee.type==='ThisExpression');
  const ctorOrigins=m.assignments.filter(a=>m.text(a.type==='AssignmentExpression'?a.right:a.init)?.endsWith('.constructor'));
  const transfers=m.calls.filter(c=>c.type==='CallExpression'&&c.arguments.some(a=>m.text(a)==='Ctor'));
  const cloneCalls=m.calls.filter(c=>m.text(c.callee)==='clone');
  const newSummary={};for(const c of m.calls.filter(c=>c.type==='NewExpression'))newSummary[m.text(c.callee)]=(newSummary[m.text(c.callee)]||0)+1;
  const entryNodes=m.nodes.filter(n=>(n.type==='AssignmentExpression'&&(/^(Decimal\[|Decimal\.prototype\.constructor|Decimal\.Decimal|module\.exports|globalScope\.Decimal|Decimal\.noConflict|P\.constructor|P\[Symbol)/.test(m.text(n.left))))||/^Export|^Import/.test(n.type));
  const defineCalls=m.calls.filter(c=>m.text(c.callee)==='define');
  const entryCondition=m.nodes.filter(n=>n.type==='IfStatement'&&(/define|module|globalScope|Symbol/.test(m.text(n.test))));
  const ownProof=proofs.find(p=>p.id===m.variant+':G_OWN_NUMERIC_PRODUCER'),parserProof=proofs.find(p=>p.id===m.variant+':G_OWN_PARSE_ROUTE');
  if(ownProof.producerFunction!==m.id(Decimal)||ownProof.factoryFunction!==m.id(clone)||ownProof.ownConstructorAssignment!==m.id(ownWrite)||canon(ownProof.producerReturns)!==canon(factoryReturns.map(m.id)))routeErrors.push('I0 own proof anchors');
  if(parserProof.parseOther!==m.id(po)||parserProof.parseDecimal!==m.id(pd)||canon(parserProof.incomingParseOther.map(c=>c.id))!==canon(poCalls.map(m.id))||canon(parserProof.incomingParseDecimal.map(c=>c.id))!==canon(pdCalls.map(m.id)))routeErrors.push('I0 parser proof anchors');
  proofErrors.push(...routeErrors.map(error=>({file:m.rel,error})));
  facts.push({file:m.rel,hash:m.hash,counts:{nodes:m.nodes.length,functions:m.fns.length,newExpressions:m.calls.filter(n=>n.type==='NewExpression').length,constructorMembers:m.constructors.length},
    producer:{Decimal:m.ref(Decimal),factory:m.ref(clone),ownAssignments:ownWrites.map(m.ref),prototype:prototype.map(m.ref),factoryReturns:factoryReturns.map(m.ref),cloneCalls:cloneCalls.map(m.callRef)},
    parse:{parserCalls:parserCalls.map(m.callRef),references:parserRefs,parserConstructorWrites:parserWrites.map(m.ref),primitiveStringBranch:m.nodes.filter(n=>n.type==='IfStatement'&&m.owner.get(n)===Decimal&&m.text(n.test)==="t === 'string'").map(m.ref),constructorCallsInParseOther:m.calls.filter(c=>m.owner.get(c)===po).map(m.callRef)},
    configuration:{keys:configKeys,function:m.ref(config),identityLimit:'Numeric settings and crypto values only; property access/coercion origin is not certified by this claim.'},
    unresolved:{staticNewThis:staticThis.map(m.callRef),receiverConstructorOrigins:ctorOrigins.map(m.ref),helperTransfers:transfers.map(m.callRef),tagRecognition:m.ref(recognition),inputSliceCalls:m.calls.filter(c=>m.owner.get(c)===Decimal&&m.text(c.callee)==='v.d.slice').map(m.callRef)},
    entries:{entryNodes:entryNodes.map(m.ref),defineCalls:defineCalls.map(m.callRef),conditions:entryCondition.map(n=>({test:m.ref(n.test),consequent:m.ref(n.consequent),alternate:m.ref(n.alternate)})),knownEvaluatorLoaderCalls:knownDynamic.map(m.callRef)},newExpressionCallees:newSummary,errors:routeErrors});
}
check('FINITE_OWN_PRODUCER_PARSER_CLOSURE',proofErrors.length===0,{files:2,errors:proofErrors});
const requiredUnknowns=['M_ROW_TOKEN','M_PUBLIC_RECEIVER','M_HELPER_ARGUMENT','M_AMD_DEFINE','M_HOST_ROUTING','M_INPUT_METHOD','M_HISTORICAL_LINK'];
check('REQUIRED_UNKNOWNS_PRESERVED',requiredUnknowns.every(id=>missing.some(x=>x.id===id)),requiredUnknowns);
const entryChecks=[],siteErrors=[];
for(const m of models){
  const p=entries.find(e=>e.file===m.rel);
  const importNodes=m.nodes.filter(n=>n.type==='ImportDeclaration'||n.type==='ImportExpression');
  const defs=m.calls.filter(c=>m.text(c.callee)==='define');
  let ok=true;
  if(m.variant==='umd'){
    const call=defs[0],cb=call?.arguments[0],ifn=m.nodes.find(n=>n.type==='IfStatement'&&m.text(n.test)==="typeof define == 'function' && define.amd");
    const cjs=ifn?.alternate;
    ok=defs.length===1&&isFn(cb)&&m.returns.some(r=>m.owner.get(r)===cb&&m.text(r.argument)==='Decimal')&&
      ifn?.consequent.start<call.start&&ifn.consequent.end>call.end&&cjs?.type==='IfStatement'&&
      m.text(cjs.test)==="typeof module != 'undefined' && module.exports"&&
      m.assignments.some(a=>a.type==='AssignmentExpression'&&m.text(a.left)==='module.exports'&&m.text(a.right)==='Decimal')&&
      m.assignments.some(a=>a.type==='AssignmentExpression'&&m.text(a.left)==='globalScope.Decimal'&&m.text(a.right)==='noConflict');
  }else{
    const named=m.nodes.find(n=>n.type==='ExportNamedDeclaration'),def=m.nodes.find(n=>n.type==='ExportDefaultDeclaration');
    ok=defs.length===0&&named?.declaration?.type==='VariableDeclaration'&&m.text(named.declaration.declarations[0].init)==='P.constructor = clone(DEFAULTS)'&&m.text(def?.declaration)==='Decimal';
  }
  const refsValid=[...p.nodes,...p.conditions,...p.loaderCalls].every(id=>m.byId.has(id));
  entryChecks.push({file:m.rel,structuralMatch:ok,allClaimedAnchorsExist:refsValid,imports:importNodes.length,externalDefineBinding:defs.map(c=>m.lookup(c.callee)?.declarations.map(m.id)||null),actualHostSelection:'UNKNOWN'});
  if(!ok||!refsValid||importNodes.length)siteErrors.push({file:m.rel,error:'entry structure'});
  const sites=constructorSites.filter(s=>s.file===m.rel);
  const expectedSites=[...m.calls.filter(n=>n.type==='NewExpression'),...m.constructors].map(m.id).sort();
  if(canon(sites.map(s=>s.node).sort())!==canon(expectedSites))siteErrors.push({file:m.rel,error:'complete constructor/member inventory'});
  for(const s of sites){
    const n=m.byId.get(s.node);
    if(s.fileSha256!==m.hash||s.callee&&s.callee!==m.id(n.callee))siteErrors.push({id:s.node,error:'constructor site anchor'});
    if(s.proposed==='OWN_NUMERIC_CONSTRUCTOR'){
      const own=m.text(n.callee)==='Decimal'||m.owner.get(n)?.id?.name==='parseOther';
      if(!own)siteErrors.push({id:s.node,error:'claimed own identity'});
    }
  }
}
check('PHYSICAL_EXPORT_AMD_AND_COMPLETE_CONSTRUCTOR_SITES',siteErrors.length===0,{entries:entryChecks,sites:constructorSites.length,errors:siteErrors});
const configExpected=['precision','rounding','toExpNeg','toExpPos','maxE','minE','modulo'];
check('CONFIG_NUMERIC_WHITELIST',facts.every(f=>canon(f.configuration.keys)===canon(configExpected)),facts.map(f=>({file:f.file,keys:f.configuration.keys,crypto:'strict true/false/0/1 branch, inspected source'})));
const counterexampleSources=[
  {id:'CE_PUBLIC_RECEIVER',source:'function Capability(v) { this.s = 1; this.e = 0; this.d = [1]; }\nconst foreign = { constructor: Capability };\nDecimal.prototype.abs.call(foreign);',limit:'The installed abs body uses new this.constructor(this). A supplied receiver can select a different constructor before finalise; no assertion that this scenario ran or was an actual consumer.'},
  {id:'CE_STATIC_CALLEE',source:'function Capability(v) { this.cos = function () { return 7; }; }\nDecimal.cos.call(Capability, 1);',limit:'Exported cos reaches new this(x).cos(); call supplies Capability as this. The actual callee identity stays unknown without consumer binding.'},
  {id:'CE_HELPER_TRANSFER',source:'function helper(Ctor, x) { return new Ctor(x); }\nfunction Capability(v) {}\nhelper(Capability, 1);',limit:'A closed local helper caller graph or parameter spelling Ctor does not prove the function passed is the clone-produced Decimal.'},
  {id:'CE_AMD_EXTERNAL_DEFINE',source:'function define(factory) { suppliedConsumer(factory); }\ndefine.amd = {};\nif (typeof define === "function" && define.amd) define(function () { return Decimal; });',limit:'An AMD guard and a local factory returning Decimal constrain the callback, not the supplied define implementation or selected host.'},
  {id:'CE_TAG_INPUT_SLICE',source:'const tagged = { toStringTag: "[object Decimal]", s: 1, e: 0, d: { slice: suppliedSlice } };\nnew Decimal(tagged);',limit:'isDecimalInstance permits tag-compatible inputs, then the constructor copy path calls v.d.slice(). Producer identity does not certify that supplied method.'},
  {id:'CE_MIXED_DATA_AND_CONSTRUCTOR',source:'const rm = Ctor.rounding, value = new Ctor(1);',limit:'Two Ctor identifiers on one line have distinct AST roles. Two same-line scanner observations still cannot be mapped to them from observation occurrence alone.'},
  {id:'CE_PROPERTY_NAME_ROUTE',source:'const supplied = { toString: suppliedToString };\nsupplied.toString();',limit:'Matching an installed P.toString property name permits only a conditional route; it cannot prove this concrete receiver/callee is that method.'}
];
const counterexamples=counterexampleSources.map(c=>{
  const m=model(c.source,'synthetic.js','probe');
  return {...c,method:'AST parse only; never execute/import/evaluate',sourceSha256:sha(c.source),ast:m.ast,calls:m.calls.map(m.callRef),assignments:m.assignments.map(m.ref),identifiers:m.nodes.filter(n=>n.type==='Identifier').map(m.ref)};
});
const probeMixed=counterexamples.find(c=>c.id==='CE_MIXED_DATA_AND_CONSTRUCTOR');
check('BOUNDED_AST_COUNTEREXAMPLES',counterexamples.length===7&&probeMixed.calls.some(c=>c.type==='NewExpression'),{count:counterexamples.length,executedPayloads:0,ids:counterexamples.map(c=>c.id)});
// Discriminating controls challenge actual identity/span predicates. Mutants stay in owned memory.
const controls=[];
const rowIdentity=(o,p)=>canon(o)===canon(p.originalRow)&&o.diagnosticIndex===p.diagnosticIndex&&p.originalRowCanonicalSha256===sha(canon(o));
controls.push({id:'NC_REORDER_OR_SUBSTITUTE_ROW',detected:!rowIdentity(originals[0],proposals[1])});
const duplicateRow=proposals.find(p=>p.duplicateCount>1);
const ordinalCheck=p=>p.duplicateOrdinal===accounting.find(a=>a.originalRow.diagnosticIndex===p.diagnosticIndex).duplicateOrdinal;
controls.push({id:'NC_DUPLICATE_OCCURRENCE',detected:!ordinalCheck({...duplicateRow,duplicateOrdinal:duplicateRow.duplicateOrdinal+1})});
const sample=lines[0],sm=mmap.get(sample.file),ssp=sm.span(sample.line);
controls.push({id:'NC_LINE_SHA_MUTATION',detected:({...sample,snippetSha256:'0'.repeat(64)}).snippetSha256!==ssp.snippetSha256});
const ownSample=proposals.find(p=>p.proposedClassification==='PROPOSED_OWN_NUMERIC_CONSTRUCTOR_ROUTE'),unresolvedSample=proposals.find(p=>p.proposedClassification==='UNRESOLVED_CONSTRUCTOR_IDENTITY_AT_INVOCATION_LINE');
controls.push({id:'NC_RECEIVER_PROMOTED_TO_OWN',detected:reviewedLines.find(l=>l.id===unresolvedSample.lineEvidence).independentlyExpected!==ownSample.proposedClassification});
const dataSample=proposals.find(p=>p.proposedClassification==='PROPOSED_EXPRESSION_DATA_USE');
controls.push({id:'NC_CONSTRUCTOR_INVOCATION_CLEARED_AS_DATA',detected:reviewedLines.find(l=>l.id===unresolvedSample.lineEvidence).independentlyExpected!==dataSample.proposedClassification});
controls.push({id:'NC_TOKEN_GAP_REMOVED',detected:!({...proposals[0],missingEvidence:[]}).missingEvidence.includes('M_ROW_TOKEN')});
controls.push({id:'NC_SUPPRESSION_GRANTED',detected:({...proposals[0],frontierAccepted:true}).frontierAccepted!==false});
check('NEGATIVE_CONTROLS',controls.every(c=>c.detected),controls);
write('counterexamples.json',counterexamples);
write('negative-controls.json',controls);
write('entry-and-constructor-checks.json',{entryChecks,siteErrors,constructorSiteCount:constructorSites.length});
write('row-accounting.json',accounting);
write('independent-line-checks.json',reviewedLines);
write('finite-proof-checks.json',facts);
write('raw-checks.json',{procedure:{node:process.version,acorn:acorn.version,command:process.execPath+' --expose-internals output/review.cjs',offline:true,sourceExecution:false},checks});
write('review-intermediate.json',{tally,uniqueLines:seen.size,extraDuplicates:originals.length-seen.size,models:models.map(m=>({file:m.rel,hash:m.hash,rows:originals.filter(o=>o.observation.file.startsWith(m.rel+':')).length})),entries,constructorSiteCount:constructorSites.length,producerFrontierAccepted:producerReport.frontierAccepted});
const integrity=reads.map(before=>{const b=fs.readFileSync(before.path),s=fs.statSync(before.path);const after={sha256:sha(b),bytes:b.length,device:s.dev,inode:s.ino,nlink:s.nlink,mode:s.mode,mtimeMs:s.mtimeMs};return {before,after,unchanged:Object.entries(after).every(([k,v])=>before[k]===v)};});
write('read-set-integrity.json',{startedReadWindow:'baseline immediately before each owned-script read; earlier interactive reads are not retroactively attested',inputs:integrity,allUnchanged:integrity.every(x=>x.unchanged)});
console.log(JSON.stringify({node:process.version,acorn:acorn.version,tally,rows:accounting.length,lines:reviewedLines.length,extraDuplicates:originals.length-seen.size,checks:checks.map(c=>({id:c.id,result:c.result,errors:c.detail.errors?.slice(0,8)})),integrity:integrity.every(x=>x.unchanged)},null,2));
