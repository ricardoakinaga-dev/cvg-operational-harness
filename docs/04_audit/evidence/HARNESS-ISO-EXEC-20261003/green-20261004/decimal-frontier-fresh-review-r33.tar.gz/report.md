# Decimal I0 finite line-level review

**ACCEPT — scoped to I0 line-level proposals and finite static assertions.**

The independent Node v22.23.2 / Acorn 8.16.0 offline AST review supports the proposed **16 own-constructor-related + 732 data-use + 324 unresolved** row accounting. All **1,072 ordered rows**, **688 physical file/line bindings**, and **384 extra duplicate occurrences** are retained. Each runtime variant contributes 536 rows and 344 distinct lines.

**Original scanner token identity remains UNKNOWN.** Duplicate occurrence is not token traversal order. This verdict accepts no scanner diagnostics, grants no suppression, and approves no whole closure, historical48link lineage, or release.

## Row accounting

| I0 line proposal | Rows | Distinct physical lines |
| --- | ---: | ---: |
| UNRESOLVED_CONSTRUCTOR_IDENTITY_AT_INVOCATION_LINE | 268 | 212 |
| PROPOSED_EXPRESSION_DATA_USE | 732 | 436 |
| UNRESOLVED_CONSTRUCTOR_TRANSFER_LINE | 56 | 26 |
| PROPOSED_OWN_CONSTRUCTOR_DATA_REFERENCE | 6 | 6 |
| PROPOSED_OWN_NUMERIC_CONSTRUCTOR_ROUTE | 6 | 4 |
| PROPOSED_OWN_NUMERIC_CONSTRUCTOR_ASSIGNMENT | 4 | 4 |

Every retained observation, index, occurrence, physical hash and candidate set is in [row-accounting.json](row-accounting.json); exact independent line evidence is in [independent-line-checks.json](independent-line-checks.json). All same-line candidates remain set-valued.

## Assertion and proof accuracy

The inner Decimal declared by clone is the own producer; x.constructor is assigned that lexical function before parser entry. parseOther has one call from its primitive-string branch; parseDecimal has three call sites inside Decimal and one inside parseOther. Neither parser exports/escapes its binding or writes the constructor field before reading it. The own classification describes this finite numeric route under ordinary intrinsic operations. It does not certify callback-free behavior for supplied objects.

The data proposals describe configuration, arithmetic, comparisons, indexing and formatting roles. **152 of their 436 lines also contain calls.** A data-use claim does not certify those concrete callees, clear another capability expression on a mixed line, or identify which token caused the original observation. config's finite whitelist and strict crypto values match its actual AST.

The 324 unknown rows remain unresolved: public receiver.constructor aliases, new this and helper constructor transfers have no concrete external caller binding or constructor-identity guard in this scope. All 1,718 call/new sites, 3,070 declaration/assignment nodes and 267 function/program graphs reconcile with independently parsed spans, arguments, owners, incoming edges and installed public methods. Member-name matching remains explicitly conditional.

UMD chooses AMD before CJS before global/noConflict fallback. Its AMD callback returns local Decimal; the actual define implementation and selected host remain unknown. ESM exports the clone-produced Decimal by name and default and directly accesses Symbol, whereas the UMD CJS branch guards Symbol. The two files have no syntactic eval/Function/require/import calls or import declarations. This syntactic observation does not close every capability.

[finite-proof-checks.json](finite-proof-checks.json) and [entry-and-constructor-checks.json](entry-and-constructor-checks.json) retain exact source/AST witnesses. [raw-checks.json](raw-checks.json) records all 13 substantive check groups; all final results MATCH.

## Bounded counterexamples and controls

Seven symbolic witnesses were parsed, never evaluated: foreign public receiver constructor; supplied static this/callee; foreign Ctor helper argument; external AMD define; tag-compatible object with supplied d.slice; mixed constructor/data expressions sharing one line; and a foreign toString callee matching an installed property name. They support the declared unknowns, not a universal JavaScript sandbox requirement.

[counterexamples.json](counterexamples.json) includes source, AST and spans. [negative-controls.json](negative-controls.json) detects row substitution, duplicate-occurrence mutation, line-hash mutation, receiver promotion to own, invocation clearing as data, token-gap removal and suppression granting. All seven controls detected their mutants. No Decimal or synthetic payload execution/import/require occurred.

## Preservation and integrity

- decimal.js SHA-256: `6e99821f8204c5f611b56077e3fce056a1562d22bc341a1f4af01afe7e527d83`
- decimal.mjs SHA-256: `45e6ecc0a500fee6439acdf67ee2e9322aab57e6ea0409ef52993dedbba8cf19`

[read-set-integrity.json](read-set-integrity.json) and [final-integrity.json](final-integrity.json) show stable source and substantive input bytes/metadata throughout their declared baseline windows. Current source nlink is 1 for each file. No trusted historical48link manifest was supplied; lineage remains unknown. [artifact-manifest.json](artifact-manifest.json) hashes every delivered artifact except itself. Writes were confined to this packet output.

Two reviewer schema predicates initially treated program entry anchors as function assignment bindings and program-scope null owners as function nodes. They were corrected and all checks rerun; the raw failed attempts are preserved and explained in report.json. These were reviewer-tooling errors, not proposal defects.

The required unknowns remain M_ROW_TOKEN, M_PUBLIC_RECEIVER, M_HELPER_ARGUMENT, M_AMD_DEFINE, M_HOST_ROUTING, M_INPUT_METHOD and M_HISTORICAL_LINK. No Root governance, prior critic judgments, private environment/keys, network/provider/PG/install, subagents or source mutations were used.

A later per-token decision needs original scanner token offsets/rule/traversal plus the actual relevant consumer and AMD bindings. This review completes only the authorized finite line-proposal review.
