import os,sys,json,hashlib,stat,pathlib
base=pathlib.Path(__file__).resolve().parent.parent
phase=sys.argv[1]; source=base/'source'
raw=(base/'frozen-inventory.json').read_bytes(); inv=json.loads(raw)
expected='69d7a202ec3ed0cbd7cffd9ef51ec878dca7cc3e7bafea49725d20294de7fc1e'
mtimes={}; actual={}; failures=[]
def walk(p):
 s=p.lstat(); rel=p.relative_to(source).as_posix()
 kind='link' if stat.S_ISLNK(s.st_mode) else 'dir' if stat.S_ISDIR(s.st_mode) else 'file'
 mtimes[rel]={'kind':kind,'mtime_ns':s.st_mtime_ns,'mode':stat.S_IMODE(s.st_mode),'size':s.st_size}
 if kind=='dir':
  for child in sorted(p.iterdir()): walk(child)
 elif kind=='link': actual[rel]={'kind':'link','target':os.readlink(p)}
 else:
  h=hashlib.sha256()
  with p.open('rb') as f:
   for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
  actual[rel]={'kind':'file','bytes':s.st_size,'sha256':h.hexdigest()}
walk(source)
for k in sorted(set(inv)|set(actual)):
 if inv.get(k)!=actual.get(k): failures.append({'path':k,'expected':inv.get(k),'actual':actual.get(k)})
report={'phase':phase,'inventory_sha256':hashlib.sha256(raw).hexdigest(),'inventory_digest_valid':hashlib.sha256(raw).hexdigest()==expected,'file_link_entries':len(actual),'directory_entries':sum(x['kind']=='dir' for x in mtimes.values()),'inventory_differences':failures}
if phase=='post':
 pre=json.loads((base/'output/raw/source-mtimes-pre.json').read_text())
 report['mtime_differences']=[{'path':k,'pre':pre.get(k),'post':mtimes.get(k)} for k in sorted(set(pre)|set(mtimes)) if pre.get(k)!=mtimes.get(k)]
(base/f'output/raw/source-mtimes-{phase}.json').write_text(json.dumps(mtimes,indent=2)+'\n')
(base/f'output/raw/integrity-{phase}.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
assert report['inventory_digest_valid'] and not failures
assert not report.get('mtime_differences')
