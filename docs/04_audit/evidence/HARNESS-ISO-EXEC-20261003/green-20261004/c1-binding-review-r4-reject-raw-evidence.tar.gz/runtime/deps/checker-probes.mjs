import fs from 'node:fs';import path from 'node:path';import ts from 'typescript';
import {auditProductBoundary} from './scripts/check-product-boundary.mjs';
const base=new URL('../tmp/own-neutral-checker/',import.meta.url);fs.mkdirSync(base,{recursive:true});
const cases=[
 ['scalar-string','const data={constructor:"label"};export const label=data.constructor','PASS'],
 ['scalar-alias-bigint','const token=42n;const data={constructor:token};export const label=data.constructor','PASS'],
 ['scalar-last-key','const data={constructor:1,constructor:"label"};export const label=data.constructor','PASS'],
 ['scalar-destructure','const data={constructor:"label"};const {constructor:token}=data;export {token}','PASS'],
 ['scalar-branch','const data={constructor:flag?"a":"b"};export const label=data.constructor','PASS'],
 ['scalar-write-unknown','const data={constructor:"label"};data.constructor=other;export const label=data.constructor','INCOMPLETE'],
 ['scalar-alias-unknown','const data={constructor:"label"};const alias=data;alias.constructor=other;export const label=data.constructor','INCOMPLETE'],
 ['scalar-export-unknown','export const data={constructor:"label"};export const label=data.constructor','INCOMPLETE'],
 ['scalar-getter-unknown','const data={get constructor(){return "label"}};export const label=data.constructor','INCOMPLETE'],
 ['scalar-spread-unknown','const data={...other,constructor:"label"};export const label=data.constructor','INCOMPLETE'],
 ['scalar-proto-unknown','const data={__proto__:other,constructor:"label"};export const label=data.constructor','INCOMPLETE'],
 ['neutral-renamed-import','import {label as token} from "./neutral.js";export {token as result}','PASS'],
 ['neutral-direct-reexport','export {label as token} from "./neutral.js"','PASS'],
 ['neutral-namespace-reexport','export * as token from "./neutral.js"','PASS'],
 ['neutral-type-reexport','export type {Data as token} from "./neutral.js"','PASS'],
 ['neutral-type-import','import type {Data as token} from "./neutral.js";export type Shape=token','PASS'],
 ['missing-type-unknown','import type {Data} from "./missing.js";export type Shape=Data','INCOMPLETE'],
 ['neutral-typed-computed','const label="key";export function f(token:{[label]:string}){var token;return token}','PASS'],
 ['neutral-function-precedence','export function f(token:{label:string}){var token;function token(){return "first"}function token(){return "last"}return token}','PASS'],
 ['catch-neutral-accepted','export function f(token="parameter"){try{}catch(token){var token="catch-label";read(token)}return token}','PASS']
];
const results=[];
for(const [id,text,expected] of cases){
 const root=path.join(path.fileURLToPath?path.fileURLToPath(base):decodeURIComponent(base.pathname),id);
 const write=(p,s)=>{const f=path.join(root,p);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,s)};
 for(const p of ['packages/core/src','apps','legacy','products'])fs.mkdirSync(path.join(root,p),{recursive:true});
 write('package.json',JSON.stringify({private:true,type:'module',workspaces:['packages/*']}));
 write('packages/core/package.json',JSON.stringify({name:'@synthetic/core',type:'module'}));
 write('tsconfig.base.json',JSON.stringify({compilerOptions:{module:'NodeNext',moduleResolution:'NodeNext',target:'ESNext',allowJs:true}}));
 write('packages/core/src/neutral.ts','export interface Data {label:string};export const label="neutral";');
 write('packages/core/src/entry.mts',text);
 const source=ts.createSourceFile(path.join(root,'packages/core/src/entry.mts'),text,ts.ScriptTarget.Latest,true);const audit=auditProductBoundary(root);
 results.push({id,text,fixturesExecuted:false,parseErrors:source.parseDiagnostics.length,expected,...audit,expectationMatched:source.parseDiagnostics.length===0&&audit.status===expected});
}
fs.writeFileSync(new URL('../../raw/own-checker-probes.json',import.meta.url),JSON.stringify(results,null,2)+'\n');
console.log(JSON.stringify({total:results.length,matched:results.filter(r=>r.expectationMatched).length,failures:results.filter(r=>!r.expectationMatched)},null,2));
