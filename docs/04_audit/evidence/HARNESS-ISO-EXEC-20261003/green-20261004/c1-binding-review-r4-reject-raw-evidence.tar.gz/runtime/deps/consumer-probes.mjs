import fs from 'node:fs';
import ts from 'typescript';
import {createBoundaryLexical,assignedValues,valueBranches} from './scripts/boundary-lexical.mjs';
import {auditDynamicCodeExecution} from './scripts/boundary-code-execution.mjs';
const raw=new URL('../../raw/',import.meta.url);
const texts=[
 ['catch-write-separated','const seed="label";function f(token="parameter"){try{}catch(token){var token=seed;read(token)}return token}'],
 ['catch-write-shared','const seed="label";function f(token){try{}catch(token){var token=seed;read(token)}return token}'],
 ['catch-write-no-param','const seed="label";function f(value="parameter"){try{}catch(token){var token=seed;read(token)}return token}'],
 ['catch-write-control','const seed="label";function f(token="parameter"){var token=seed;read(token);return token}'],
 ['catch-write-no-return','const seed="label";function f(token="parameter"){try{}catch(token){var token=seed;read(token)}}']
];
const out=[];
for(const [id,text] of texts)for(const ext of ['mjs','mts']){
 const source=ts.createSourceFile('/inert/'+id+'.'+ext,text,ts.ScriptTarget.Latest,true);const lexical=createBoundaryLexical(ts,source);const nodes=[];
 function visit(n){nodes.push(n);ts.forEachChild(n,visit)}visit(source);
 const seed=nodes.find(n=>ts.isVariableDeclaration(n)&&n.name.getText(source)==='seed').name;
 const key=lexical.identity(seed);const labels=new Map([[key,new Set(['SYMBOLIC_CAPABILITY'])]]);
 const literal=n=>ts.isStringLiteralLike(n??{})?n.text:undefined;
 // Exact loader binding loop shape from frozen consumer, with abstract labels.
 const match=n=>ts.isIdentifier(n)&&labels.has(lexical.identity(n));
 let changed=true;
 while(changed){changed=false;
  const bind=(name,expression)=>{if(valueBranches(ts,expression).some(match)&&!labels.has(name)){labels.set(name,new Set(['SYMBOLIC_CAPABILITY']));changed=true}};
  for(const [body,parameter] of lexical.initialTransfers)bind(lexical.identity(body),parameter);
  for(const node of nodes.filter(n=>!lexical.erased(n))){
   if((ts.isVariableDeclaration(node)||ts.isParameter(node))&&node.initializer)assignedValues(ts,node.name,node.initializer,literal,(name,value)=>bind(lexical.identity(name),value));
   if(ts.isBinaryExpression(node)&&node.operatorToken.kind>=ts.SyntaxKind.FirstAssignment&&node.operatorToken.kind<=ts.SyntaxKind.LastAssignment)assignedValues(ts,node.left,node.right,literal,(name,value)=>bind(lexical.identity(name),value));
  }
 }
 const diagnostics=[];
 // The analyzer runs on neutral AST. Remap its built-in seed to a symbolic key;
 // no evaluator identifier or payload is introduced in fixture source.
 const injected={...lexical,global:name=>name==='Function'?key:lexical.global(name)};
 auditDynamicCodeExecution({ts,source,lexical:injected,runtimeNodes:nodes.filter(n=>!lexical.erased(n)),typeOnly:lexical.erased,literal,isLoader:()=>false,isBuiltinGetter:()=>false,isGlobal:()=>false,isDeclarationName:lexical.isDeclarationName,loaderDiagnostic:(node,reason)=>diagnostics.push({start:node.getStart(source),text:node.getText(source),reason})});
 const readToken=nodes.find(n=>ts.isIdentifier(n)&&n.text==='token'&&ts.isCallExpression(n.parent));
 const returnToken=nodes.find(n=>ts.isIdentifier(n)&&n.text==='token'&&ts.isReturnStatement(n.parent));
 const varToken=nodes.find(n=>ts.isIdentifier(n)&&n.text==='token'&&((ts.isVariableDeclaration(n.parent)&&ts.isVariableDeclarationList(n.parent.parent))||ts.isBindingElement(n.parent)));
 const inCatch=id!=='catch-write-control';
 out.push({id,ext,text,parseErrors:source.parseDiagnostics.length,fixturesExecuted:false,symbolicSeed:'SYMBOLIC_CAPABILITY',actualDynamicAnalyzer:true,loaderConsumerMode:'static replay of exact binding loop, abstract membership only',writeDeclarationEqualsRead:lexical.identity(varToken)===lexical.identity(readToken),expectedReadLabel:true,actualLoaderReadLabel:labels.has(lexical.identity(readToken)),expectedReturnLabel:!inCatch,actualLoaderReturnLabel:returnToken?labels.has(lexical.identity(returnToken)):null,dynamicDiagnostics:diagnostics,dynamicReadReported:diagnostics.some(d=>d.start===readToken.getStart(source)),dynamicReturnReported:returnToken?diagnostics.some(d=>d.start===returnToken.getStart(source)):null,positions:{writeDeclaration:varToken.getStart(source),catchRead:readToken.getStart(source),bodyReturn:returnToken?.getStart(source)??null}});
}
fs.writeFileSync(new URL('own-consumer-probes.json',raw),JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out,null,2));
