import {defineConfig} from 'vitest/config';
export default defineConfig({cacheDir:'../cache/vite',test:{environment:'node',include:['tests/product-boundary-lexical-static.test.js'],setupFiles:['./retain-observations.mjs'],fileParallelism:false,maxWorkers:1}});
