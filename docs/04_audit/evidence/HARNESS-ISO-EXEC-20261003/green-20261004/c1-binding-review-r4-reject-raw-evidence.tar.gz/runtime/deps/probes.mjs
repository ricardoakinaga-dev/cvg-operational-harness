import fs from 'node:fs';
import path from 'node:path';
import ts from 'typescript';
import {createBoundaryLexical,assignedValues,valueBranches} from './scripts/boundary-lexical.mjs';
import {auditProductBoundary} from './scripts/check-product-boundary.mjs';
const raw=new URL('../../raw/',import.meta.url);
const cases=[
 ['catch-var-default','function f(token="parameter"){try{}catch(token){var token="catch-write";read(token)}return token}',[0,1,2,1,2],1],
 ['catch-var-simple','function f(token){try{}catch(token){var token="catch-write";read(token)}return token}',[0,1,0,1,0],0],
 ['catch-var-no-param','function f(value="parameter"){try{}catch(token){var token="catch-write";read(token)}return token}',[0,1,0,1],0],
 ['catch-var-plus-outside','function f(token="parameter"){try{}catch(token){var token="catch-write";read(token)}var token;return token}',[0,1,2,1,2,2],1],
 ['catch-var-reversed','function f(token="parameter"){var token;try{}catch(token){var token="catch-write";read(token)}return token}',[0,1,2,1,2,1],1],
 ['simple-pattern-function','function f({token}){function token(){}return token}',[0,0,0],0],
 ['rest-function','function f(...token){function token(){}return token}',[0,0,0],0],
 ['nested-rest-pattern','function f(...[token]){var token;return token}',[0,0,0],0],
 ['nested-rest-default','function f(...[token="parameter"]){var token;return token}',[0,1,1],1],
 ['computed-literal','function f({["label"]:token}){var token;return token}',[0,1,1],1],
 ['computed-type-only','function f(token:{["label"]:string}){var token;return token}',[0,0,0],0,'mts'],
 ['nested-body-shadow','function f(token="parameter",read=()=>token){var token;return function g(token){var token;return token}}',[0,0,1,2,2,2],1],
 ['lexical-body-only','function f(token="parameter"){let value="body";return token}',[0,0],0],
 ['catch-closure','function f(token="parameter"){var token;try{}catch(token){read(()=>token)}return token}',[0,1,2,2,1],1],
 ['var-for-of','function f(token="parameter"){for(var token of ["body"]){}return token}',[0,1,1],1],
 ['var-for-in','function f(token="parameter"){for(var token in {label:"body"}){}return token}',[0,1,1],1],
 ['function-outside-param','function f(value="parameter"){function token(){}var token;return token}',[0,0,0],0],
 ['named-expression-self','const f=function token(value=()=>token){var token;return token}',[0,0,1,1],0],
 ['outer-body-default-inner','function f(token="parameter"){var token;return function g(value=()=>token){var token;return token}}',[0,1,1,2,2],1],
 ['outer-erased-type','const token="outer";function f(value:{[token]:string}){var token;return token}',[0,1,1],0,'mts']
];
const results=[];
for(const [id,text,expected,transfers,onlyExt] of cases){
 for(const ext of onlyExt?[onlyExt]:['mjs','mts']){
  const source=ts.createSourceFile('/inert/'+id+'.'+ext,text,ts.ScriptTarget.Latest,true);
  const lexical=createBoundaryLexical(ts,source); const ids=[];
  function visit(n){if(ts.isIdentifier(n)&&n.text==='token'&&!lexical.erased(n)&&!lexical.isDeclarationName(n)||ts.isIdentifier(n)&&n.text==='token'&&!lexical.erased(n)&&['Parameter','BindingElement','VariableDeclaration','FunctionDeclaration','FunctionExpression'].includes(ts.SyntaxKind[n.parent.kind]))ids.push(n);ts.forEachChild(n,visit)}
  visit(source); const keys=ids.map(lexical.identity);const cells=[...new Set(keys)];const actual=keys.map(k=>cells.indexOf(k));
  const edges=lexical.initialTransfers.map(([target,parameter])=>({target:cells.indexOf(lexical.identity(target)),parameter:cells.indexOf(lexical.identity(parameter)),targetText:target.getText(source),targetStart:target.getStart(source),targetDeclarations:lexical.identity(target)?.declarations?.map(d=>({kind:ts.SyntaxKind[d.kind],parent:ts.SyntaxKind[d.parent.kind],start:d.getStart(source)}))}));
  const labels=new Map(cells.map(k=>[k,new Set()]));
  for(const {target,parameter} of edges){if(labels.has(cells[parameter])) labels.get(cells[parameter]).add('PARAMETER_INITIAL');for(const label of labels.get(cells[parameter])??[])labels.get(cells[target])?.add(label);labels.get(cells[target])?.add('BODY_WRITE');}
  results.push({id,ext,text,fixturesExecuted:false,parseErrors:source.parseDiagnostics.length,expected,actual,expectedTransfers:transfers,edges,identifiers:ids.map((n,i)=>({start:n.getStart(source),parent:ts.SyntaxKind[n.parent.kind],cell:actual[i]})),cells:cells.map(k=>({declarations:k.declarations?.map(d=>({kind:ts.SyntaxKind[d.kind],parent:ts.SyntaxKind[d.parent.kind],start:d.getStart(source)})),initialFunction:k.initialFunction?.getStart(source)??null})),symbolicLabels:cells.map(k=>[...labels.get(k)]),passed:source.parseDiagnostics.length===0&&JSON.stringify(actual)===JSON.stringify(expected)&&edges.length===transfers});
 }
}
fs.writeFileSync(new URL('own-binding-probes.json',raw),JSON.stringify(results,null,2)+'\n');
console.log(JSON.stringify({cases:results.length,passed:results.filter(r=>r.passed).length,failures:results.filter(r=>!r.passed).map(r=>({id:r.id,ext:r.ext,expected:r.expected,actual:r.actual,edges:r.edges}))},null,2));
