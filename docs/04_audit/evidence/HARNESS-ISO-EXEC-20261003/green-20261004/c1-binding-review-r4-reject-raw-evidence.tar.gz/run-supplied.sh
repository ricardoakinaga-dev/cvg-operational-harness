#!/bin/bash
set -u
cd /home/ricardo/.cache/cvg-harness-green-20261004/c1-binding-review-r4/output/runtime/deps
/usr/bin/env -i PATH=/home/ricardo/.nvm/versions/node/v22.23.2/bin:/usr/bin:/bin HOME="$PWD/../home" TMPDIR="$PWD/../tmp" XDG_CACHE_HOME="$PWD/../cache" npm_config_cache="$PWD/../cache/npm" /home/ricardo/.nvm/versions/node/v22.23.2/bin/node node_modules/vitest/vitest.mjs run --config review.config.mjs --reporter=verbose --reporter=json --outputFile=../../raw/supplied-vitest.json > ../../raw/supplied-vitest.log 2>&1
result=$?
printf '%s\n' "$result" > ../../raw/supplied-exit.txt
exit "$result"
