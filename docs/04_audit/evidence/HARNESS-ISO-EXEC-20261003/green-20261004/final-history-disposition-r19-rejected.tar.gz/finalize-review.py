import collections, datetime, hashlib, json, pathlib, re, subprocess, time
P=pathlib.Path(__file__).resolve().parent
AUTH=json.loads((P/'authority.json').read_text());R=pathlib.Path(AUTH['readReports'])
FROZEN='849455b09e4eadde5e27a21e0837a953f9e266c2'
ENV={'PATH':'/usr/bin:/bin','HOME':str(P),'LANG':'C.UTF-8','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_OPTIONAL_LOCKS':'0','GIT_NO_REPLACE_OBJECTS':'1','GIT_TERMINAL_PROMPT':'0'}
sha=lambda b:hashlib.sha256(b).hexdigest()
def js(n):return json.loads((P/n).read_text())
def jl(n):return [json.loads(l) for l in (P/n).read_text().splitlines()]
def write(n,v):(P/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
start=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic();calls=[]
def git(args):
    cmd=['/usr/bin/git','--git-dir=/home/ricardo/Área de trabalho/cvg-operational-harness/.git',*args]
    r=subprocess.run(cmd,cwd=P,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
    calls.append({'argv':cmd,'exitCode':r.returncode,'stdoutSha256':sha(r.stdout),'stderrSha256':sha(r.stderr),'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})
    return r
inputbytes=(R/'gitleaks-history.json').read_bytes();inputs=json.loads(inputbytes);ledger=jl('ledger.jsonl');evidence=jl('evidence.jsonl');inventory=jl('inventory.jsonl');summary=js('disposition-summary.json')
assert len(inputs)==len(ledger)==len(inventory)==6688
assert len({x['identity'] for x in ledger})==6688
assert [x['inputIndex'] for x in ledger]==list(range(6688))
assert all(x['Secret']=='REDACTED' for x in inputs)
ancestry=js('ancestry.json');cache={};values={};enddeltas=collections.Counter();startdeltas=collections.Counter()
for c in sorted({x['commit'] for x in ledger}):
    assert git(['merge-base','--is-ancestor',c,FROZEN]).returncode==0
    assert ancestry[c]['isAncestor'] and ancestry[c]['frozen']==FROZEN
for x,iv,raw in zip(ledger,inventory,inputs):
    for target,source in [('rule','RuleID'),('file','File'),('commit','Commit'),('startLine','StartLine'),('endLine','EndLine'),('startColumn','StartColumn'),('endColumn','EndColumn'),('fingerprint','Fingerprint')]:assert x[target]==raw[source]
    pair=x['commit'],x['file']
    if pair not in cache:
        r=git(['show','--no-textconv',pair[0]+':'+pair[1]]);assert r.returncode==0;cache[pair]=r.stdout
    b=cache[pair];ls=b.splitlines(keepends=True);span=b''.join(ls[x['startLine']-1:x['endLine']]);text=span.decode()
    assert x['blobSha256']==sha(b)==iv['blobSha256']
    assert x['gitBlobOid']==hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
    assert x['lineSha256']==sha(span)==iv['lineSha256']
    context=b''.join(ls[max(0,x['startLine']-5):min(len(ls),x['endLine']+4)]);assert sha(context)==x['contextSha256']
    v=text[iv['candidateStartInSpan']:iv['candidateEndInSpan']];assert sha(v.encode())==x['candidateSha256']
    pre,suf=raw['Match'].split('REDACTED',1)
    reconstructed=pre+v+suf;assert reconstructed in text
    mpos=iv['candidateStartInSpan']-len(pre);assert text[mpos:mpos+len(reconstructed)]==reconstructed
    delta=len(text[:mpos].encode())+2-x['startColumn'];startdeltas[delta]+=1
    # The report has two observed byte-column conventions. Keep original
    # scanner metadata and exact source offsets separately; do not move,
    # suppress or widen the finding span. Scanner internals were not inspected.
    assert delta in (0,1), (x['identity'],delta)
    matched=text[:mpos+len(reconstructed)];lastmatched=matched.split('\n')[-1]
    enddeltas[len(lastmatched.encode())+1-x['endColumn']]+=1
    x['lineHashes']=[{'line':i+1,'sha256':sha(ls[i])} for i in range(x['startLine']-1,x['endLine'])]
    values[x['identity']]=v

byid={x['identity']:x for x in ledger};groupkeys={};allmembers=[]
for e in evidence:
    keys=set()
    for i in e['members']:
        x=byid[i];allmembers.append(i)
        keys.add((x['rule'],x['blobSha256'],x['startLine'],x['endLine'],x['startColumn'],x['endColumn']))
        assert x['groupId']==e['groupId'] and x['evidenceId']==e['evidenceId']
        assert x['disposition']==e['disposition'] and x['reason']==e['reason']
        assert x['lineSha256']==e['lineSha256'] and x['candidateSha256']==e['candidateSha256']
    assert len(keys)==1 and next(iter(keys)) not in groupkeys;groupkeys[next(iter(keys))]=e['groupId']
assert sorted(allmembers)==sorted(byid) and len(allmembers)==6688
assert len(evidence)==summary['groups']==1956

tokens=jl('token-links.jsonl');assert len(tokens)==73 and len({t['identity'] for t in tokens})==73
for t in tokens:
    assert t['generator']['commit']==t['commit'] and t['generator']['sameCommitDigestLinks']
    assert any(n['allChecks'] for n in t['validatedNotes'])
    assert all(n['tokenSha256']==t['candidateSha256'] for n in t['validatedNotes'])
    assert byid[t['identity']]['reason']=='REVISION_IDENTIFIER_FULLY_RECOMPUTED_FROM_SAME_COMMIT_NOTE_AND_ARCHIVED_GENERATOR'
links=js('remaining-link-evidence.json');assert len(links)==5
for o in links:
    if 'offlineValidation' in o:
        c=o['offlineValidation'];assert c['pythonOpenSslSignaturesEqual'] and c['payloadRoundTripEqual'] and c['alteredPayloadRejected']
    if o['identity'] in ['F006153','F006158']:
        assert all(o[k] for k in ['exactFollowingInstanceAssignment','emptySensitiveAssignment','schemaDeclaresSeparateInstanceAndApiKey','composeRoutesInstance','composeRoutesSeparateApiKey','consumerUsesInstanceInUrl','consumerUsesSeparateKeyHeader'])
        assert byid[o['identity']]['disposition']=='PLACEHOLDER'
receipt=json.loads((R/'receipt.json').read_text());assert receipt['head']==FROZEN and receipt['findings']==6688 and receipt['exitCode']==1
assert receipt['logSha256']==sha((R/'scan.log').read_bytes())
assert '--ignore-gitleaks-allow' in receipt['command'] and '--redact=100' in receipt['command']
assert '--log-opts='+FROZEN in receipt['command']
counts=dict(collections.Counter(x['disposition'] for x in ledger));assert counts==summary['counts'];assert summary['verdict']=='REJECT' and counts['PENDING']==3
pending=[x for x in ledger if x['disposition']=='PENDING'];assert {x['identity'] for x in pending}=={'F006214','F006219','F006444'}
assert js('draft-reject-initial.json')['counts']['PENDING']==119
assert js('draft-reject-after-extraction.json')['counts']['PENDING']==78
write('draft-reject-before-final-five.json',{'source':'Observed link-tokens.py result before final five follow-up','verdict':'REJECT','identities':6688,'groups':1956,'counts':{'PLACEHOLDER':3,'HASH':6645,'SYNTHETIC':35,'PENDING':5},'credentialSuspectedIdentities':2})
write('decision-history.json',[{'stage':'initial-disposition','artifact':'draft-reject-initial.json','verdict':'REJECT','pending':119},{'stage':'exact-extraction-correction','artifact':'draft-reject-after-extraction.json','verdict':'REJECT','pending':78},{'stage':'same-commit-generator-token-linkage','artifact':'draft-reject-before-final-five.json','verdict':'REJECT','pending':5},{'stage':'bounded-final-five-linkage','artifact':'disposition-summary.json','verdict':'REJECT','pending':3}])
with (P/'ledger.jsonl').open('w') as f:
    for x in ledger:f.write(json.dumps(x,ensure_ascii=False)+'\n')
pendingout=[];linkbyid={o['identity']:o for o in links}
for x in pending:
    pendingout.append({**x,'credentialSuspected':x['identity']!='F006214','confirmedReal':False,'remainingEvidenceGap':linkbyid[x['identity']]['originDecision'],'nextEvidenceNeeded':('Independent same-commit mechanical synthetic key provenance or a stored generated fixture signature linked to this literal; do not test against a real provider.' if x['identity']!='F006214' else 'Independent structured mechanical interpretation of the exact prose match; a historical narrative verdict does not approve it.')})
write('pending.json',pendingout)
lines=['# Pending — finite historical security review','', 'All entries below remain PENDING. No real credential has been confirmed. Values are never published.','']
for x in pendingout:
    lines.extend([f"## {x['identity']}",'',f"- File: `{x['file']}`",f"- Commit: `{x['commit']}`",f"- Rule: `{x['rule']}`",f"- Lines: {x['startLine']}–{x['endLine']}; columns: {x['startColumn']}–{x['endColumn']}",f"- Blob SHA-256: `{x['blobSha256']}`",f"- Git blob OID: `{x['gitBlobOid']}`",f"- Line/span SHA-256: `{x['lineSha256']}`",f"- Candidate SHA-256: `{x['candidateSha256']}`",f"- Reason: {x['remainingEvidenceGap']}",''])
(P/'pending.md').write_text('\n'.join(lines)+'\n')

# Secret non-disclosure check on actual unresolved candidate bytes, not only report redaction.
for x in pending:
    candidate=values[x['identity']].encode()
    for p in P.iterdir():
        if p.is_file():assert candidate not in p.read_bytes(), 'Pending candidate plaintext in package artifact'
verification={'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsedSeconds':round(time.monotonic()-tick,3),'status':'PASS','scope':'artifact integrity, supplied finding identities, exact-source hashes, ancestry, exact duplicate groups and recorded mechanical linkage; not security acceptance','identities':6688,'sourcePairsRechecked':len(cache),'commitsAncestryRechecked':len(ancestry),'uniqueBlobSpanRuleGroups':len(evidence),'duplicateFingerprintOccurrencesPreserved':6688-len({x['Fingerprint'] for x in inputs}),'scannerColumnStartDeltas':dict(startdeltas),'scannerColumnEndDeltas':dict(enddeltas),'scannerColumnObservation':'Report StartColumn equals raw match 1-based byte offset or that offset plus one; anchored exact candidate bytes and original scanner metadata are both preserved. This is observed report/source mapping, not a rule waiver.','lineHashConvention':'SHA256 of original bytes including original line terminator; lineSha256 hashes entire finding span; lineHashes gives each individual line. Columns preserved exactly as scanner reported.','tokenChecks':73,'offlineCryptoChecks':2,'pendingPlaintextCheck':'PASS','scannerReceiptAndLogHash':'PASS','scannerDefaults':'Strict-default and empty-ignore setup is the supplied premise and is reflected in receipt flags; external config/executable contents were not inspected or rerun.'}
write('verification.json',verification);write('verification-provenance.json',calls)
inputmanifest={p.name:{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(R.iterdir()) if p.is_file()}
write('execution.json',{'task':'FINAL_HISTORY_DISPOSITION_R19','finalizedAt':verification['finishedAt'],'frozenHead':FROZEN,'authoritySha256':sha((P/'authority.json').read_bytes()),'supplementalAuthoritySha256':sha((P/'supplemental-authority.json').read_bytes()),'reportInputs':inputmanifest,'mainProcedure':['python3 collect.py','python3 dispose.py','python3 link-tokens.py','python3 link-final-pending.py','python3 finalize-review.py'],'gitProvenanceFiles':['git-provenance.json','link-inspection-provenance.json','token-link-provenance.json','remaining-link-provenance.json','verification-provenance.json'],'preparatoryReads':'Task authority, named report packet and generic engineering skill only; working tree, private environment, runtime/backlog/execution ledgers and prior reviews were not read. Historical tree listings were via git show exact same commit:path solely to locate authorized generators.','boundedCorrections':'Corrected repeated matches using scanner byte columns, non-suffixed cross-line capture, nullable digest maps, exact final generator archive vs earlier archive, and config env alias. Initial and intermediate REJECT dispositions preserved.','nodeAttempt':'An offline Node helper was attempted but /usr/bin/node was unavailable. No Node execution or installation occurred; Python/OpenSSL offline crypto was actually executed.','limits':['No scanner rerun or external scanner config-content inspection','No provider/network/PG/installation/current environment validation','No current-tree security or other gates','No actual historical test replay/build; only offline digest and cryptographic verification','No confirmed REAL finding; unproven signing literals stay PENDING','No production/history/rule waiver or suppression']})
report=f'''# Finite independent historical security disposition

Verdict: **REJECT**. Exactly 6,688 identities were reviewed at frozen commit `{FROZEN}`. There are **3 PENDING** identities: two signing literals with unproven synthetic origin and one prose match without independent mechanical disposition. No REAL credential has been confirmed. The complete finite list, exact commits, lines and all hashes are in [pending.md](pending.md) and [pending.json](pending.json).

| Disposition | Individual findings |
|---|---:|
| HASH | {counts['HASH']} |
| SYNTHETIC | {counts['SYNTHETIC']} |
| PLACEHOLDER / noncredential scanner match | {counts['PLACEHOLDER']} |
| PENDING | {counts['PENDING']} |
| REAL confirmed | 0 |

[ledger.jsonl](ledger.jsonl) preserves every input identity, rule, file, exact commit, lines/columns, Git blob OID, blob SHA-256, span and individual line hashes, candidate hash, ancestry and evidence link. [evidence.jsonl](evidence.jsonl) contains 1,956 distinct decisions grouped exclusively by identical blob, exact line/column span and rule. Different commits/paths retain individual identities and ancestry. There are {verification['duplicateFingerprintOccurrencesPreserved']} repeated fingerprint occurrences, all retained rather than dropped.

6,572 HASH findings are exact 64-hex values in a declared digest schema or mechanically checked artifact-path digest map (including explicit null missing entries). Names, paths and counts alone were not used. Referenced unflagged files were not read merely to recompute their hashes; this is a digest-role disposition, not proof of every recorded historical digest preimage.

The other **73 HASH findings** are revision identifiers, initially suspected opaque capabilities. Archived generators in each finding's same commit were matched by source digest to historical source/copy artifacts. Every token was exactly recomputed as note-id prefix, revision and organized-content digest prefix. The complete note ID, raw text digest and organized payload digest were independently recomputed too. The generator has no HMAC or secret-key input; the consumer also checks author identity. [token-links.jsonl](token-links.jsonl) links each individual finding to note payload hashes, generator archive/member/line hashes and script output observations; [generator-evidence.json](generator-evidence.json) records code and digest bindings. Existing exit statuses, reported successes and narrative verdicts were not acceptance authority, and historical scripts were not executed.

The final five were investigated in isolation. `F006153` and `F006158` were resolved as cross-line scanner matches: an empty API-key assignment was followed by a routing-instance assignment. Same-commit config, composition and consumer code prove the instance is placed in the URL while a separate API key is placed in a header. This decision does not rely on localhost or synthetic naming. `F006214`, `F006219` and `F006444` remain PENDING, as detailed in [remaining-link-evidence.json](remaining-link-evidence.json).

For both signing literals, exact same-commit fixture producer/consumer code and controlled identity construction were inspected. Offline Python and the existing OpenSSL library produced identical HMAC-SHA256 signatures; decoded Base64url fixture payloads round-tripped and altered payloads were rejected. There was no historical stored signature establishing synthetic origin of either literal. Cryptographic validity and fixture names do not establish that origin, so both remain PENDING. The prose match was limited to its flagged line and mechanical grammar; it cannot approve itself through a prior narrative statement.

[verification.json](verification.json) records a fresh, separate integrity pass: 6,688 input-to-ledger identities, 169 exact historical sources, 22 ancestry checks, group integrity, 73 complete revision/digest linkages, two offline cryptographic comparisons and non-disclosure of all unresolved candidate bytes. Original source line terminators are included in line hashes. Scanner columns are preserved as reported.

Initial REJECT (119 PENDING), corrected REJECT (78 PENDING), token-linked REJECT (5 PENDING) and final REJECT (3 PENDING) are preserved in [decision-history.json](decision-history.json) and its draft artifacts. No old review verdict or baseline was consulted as authority.

The review ends here with the finite gaps in `pending.json`. Scope is only this supplied strict, fully redacted historical report. Scanner receipt/log integrity and strict/no-ignore flags were checked; the outside scanner binary/config were not read or rerun. No network/provider/PG/install, subagent, descendant-commit, private environment, current working-tree or unrelated-gate work occurred. Only this disposition package was written. This rejects full disposition acceptance and grants no production, history or rule waiver. Values are absent from artifacts; only hashes, code structure and verifiable reasons are recorded.
'''
(P/'report.md').write_text(report)
manifest={'task':'FINAL_HISTORY_DISPOSITION_R19','verdict':'REJECT','frozenHead':FROZEN,'inputFindings':6688,'dispositions':counts,'pendingIds':[x['identity'] for x in pending],'credentialSuspectedIds':['F006219','F006444'],'confirmedReal':0,'scope':'individual supplied historical findings only; no production/history/rule waiver','verificationStatus':'PASS for artifact verification; security disposition remains REJECT','files':{p.name:{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(P.iterdir()) if p.is_file() and p.name!='manifest.json'}}
write('manifest.json',manifest)
assert all(sha((P/name).read_bytes())==v['sha256'] for name,v in manifest['files'].items())
print(json.dumps({'verdict':'REJECT','counts':counts,'pendingIds':[x['identity'] for x in pending],'verification':'PASS','manifestSha256':sha((P/'manifest.json').read_bytes()),'packageFiles':len(manifest['files']),'columnEndDeltas':dict(enddeltas)}))
