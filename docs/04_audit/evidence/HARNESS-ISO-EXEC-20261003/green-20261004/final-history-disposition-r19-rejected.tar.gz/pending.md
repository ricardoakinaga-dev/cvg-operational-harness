# Pending — finite historical security review

All entries below remain PENDING. No real credential has been confirmed. Values are never published.

## F006214

- File: `docs/08_runtime/archive/prod20260926_runtime_state_history.md`
- Commit: `68465197fec8873cb953da34ef6e713ccb9969cd`
- Rule: `generic-api-key`
- Lines: 3772–3772; columns: 90–123
- Blob SHA-256: `7462cf616b8f2c7aaed531747ca02724d0df2cdc173843162b7a82decf3ab787`
- Git blob OID: `7d720739336bc289d4570dfd86e3a65690063d5e`
- Line/span SHA-256: `81ec08f181bf6dc98cae7b397803dc1605ad7722ca2972a9485980e3f41d1f01`
- Candidate SHA-256: `54f8546d3c4b0d2e10ec18779f8016a5176a13da64f24c6b183eccd811b14c11`
- Reason: PENDING: narrative-only lexical match has no independent synthetic/hash/placeholder provenance; narrative declarations cannot approve themselves.

## F006219

- File: `apps/api/src/__tests__/trusted-operator-identity.test.ts`
- Commit: `c791ee478885410f3fce9910c96df638a3607e81`
- Rule: `generic-api-key`
- Lines: 342–342; columns: 12–78
- Blob SHA-256: `121e6a5363f9e5f548dd301b636a212f600bb806b614a43a07e19960a97be3a8`
- Git blob OID: `dfe7c768fb8c257fb6c0075bb3a90625e9f6c38f`
- Line/span SHA-256: `3480d58b85c51c703df46f06718bafde043c1f20b0154e816e7c5e7721c61b4b`
- Candidate SHA-256: `682b991cf3fafd483e1ac49634ab2ae68cd47e8a285701e5cc87551bb2985f81`
- Reason: PENDING: exact local fixture construction, producer/consumer references and offline HMAC validity are verified. The bounded same-commit evidence has no stored signature/output tying this candidate to independently established synthetic key generation. Mnemonics and successful signing are insufficient origin proof; this remains an unproven credential literal.

## F006444

- File: `apps/api/src/__tests__/identity-key-ring-rotation.test.ts`
- Commit: `c57c330f809e3a48947fe4aaadc538b7be151ddc`
- Rule: `generic-api-key`
- Lines: 18–18; columns: 4–53
- Blob SHA-256: `7dfba8f038b37f3cb853a7f4fb42adda77f62f04915698994537d191d40bdd09`
- Git blob OID: `159eeb63d94ba6e2d49535182ee7803d2b992a51`
- Line/span SHA-256: `ffae55fa67d854a40ec3a527043d25d53f6dd88ef31c1e92ad62c143e5896f50`
- Candidate SHA-256: `97e07e744a4f3053aa8fc64311dc33b13f88fd0a74b5439f617f70e8c5aaf625`
- Reason: PENDING: exact local fixture construction, producer/consumer references and offline HMAC validity are verified. The bounded same-commit evidence has no stored signature/output tying this candidate to independently established synthetic key generation. Mnemonics and successful signing are insufficient origin proof; this remains an unproven credential literal.

