import { createHash, createHmac, timingSafeEqual } from 'node:crypto';
let input = '';
for await (const chunk of process.stdin) input += chunk;
const { key, payload, expected } = JSON.parse(input);
const sha = value => createHash('sha256').update(value).digest('hex');
const encoded = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
const signature = createHmac('sha256', key).update(encoded, 'utf8').digest('base64url');
const good = timingSafeEqual(Buffer.from(signature), Buffer.from(expected));
const decoded = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8'));
const altered = createHmac('sha256', key).update(encoded + 'x', 'utf8').digest('base64url');
process.stdout.write(JSON.stringify({
  keySha256: sha(key), payloadSha256: sha(JSON.stringify(payload)),
  encodedPayloadSha256: sha(encoded), signatureSha256: sha(signature),
  pythonNodeSignaturesEqual: good,
  payloadRoundTripEqual: JSON.stringify(decoded) === JSON.stringify(payload),
  alteredPayloadRejected: altered !== signature
}) + '\n');
