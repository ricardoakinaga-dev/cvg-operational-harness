import collections, datetime, hashlib, io, json, pathlib, re, subprocess, zipfile
P=pathlib.Path(__file__).resolve().parent
ENV={'PATH':'/usr/bin:/bin','HOME':str(P),'LANG':'C.UTF-8','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_OPTIONAL_LOCKS':'0','GIT_NO_REPLACE_OBJECTS':'1','GIT_TERMINAL_PROMPT':'0'}
sha=lambda b:hashlib.sha256(b).hexdigest()
calls=[];cache={}
def show(c,f):
    if (c,f) not in cache:
        cmd=['/usr/bin/git','--git-dir=/home/ricardo/Área de trabalho/cvg-operational-harness/.git','show','--no-textconv',c+':'+f]
        r=subprocess.run(cmd,cwd=P,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40)
        calls.append({'argv':cmd,'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode,'stdoutSha256':sha(r.stdout),'stderrSha256':sha(r.stderr),'stdoutBytes':len(r.stdout)})
        cache[c,f]=r.stdout if r.returncode==0 else None
    return cache[c,f]
def jsonl(name):return [json.loads(l) for l in (P/name).read_text().splitlines()]
def canon(obj):return json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':'))
inventory={x['identity']:x for x in jsonl('inventory.jsonl')}
ledger=jsonl('ledger.jsonl');evidence=jsonl('evidence.jsonl')
if not (P/'draft-reject-after-extraction.json').exists():
    (P/'draft-reject-after-extraction.json').write_text((P/'disposition-summary.json').read_text())
targets=[x for x in ledger if x['reason'] in ['OPAQUE_TOKEN_CAPABILITY_ORIGIN_UNPROVEN','REVISION_IDENTIFIER_FULLY_RECOMPUTED_FROM_SAME_COMMIT_NOTE_AND_ARCHIVED_GENERATOR']]
base='docs/04_audit/evidence/HARNESS-ISO-EXEC-20261003/audit-actions/'
archive=base+'product-vertical-builder/product-source.zip'
generators={};sources=[]
for c in sorted({x['commit'] for x in targets}):
    archive=base+('product-vertical-builder/product-source.zip' if c.startswith('387aca') else 'product-first-rework/lead/product-r2-source.zip')
    b=show(c,archive)
    if b is None:continue
    z=zipfile.ZipFile(io.BytesIO(b));entry='products/shift-assistant/src/vertical-state.ts';gen=z.read(entry).decode();lines=gen.splitlines(keepends=True)
    # Verify the precise archived implementation, not a name or prior review verdict.
    formula=re.search(r'return\s+`\$\{n\.id\.slice\(0, 12\)\}([^$]*)\$\{n\.revision\}([^$]*)\$\{n\.organizedSha256\.slice\(0, 12\)\}`',gen)
    if not formula:continue
    start=gen[:formula.start()].count('\n')+1
    formulaSha=sha(formula.group().encode());formulaLineSha=sha(lines[start-1].encode())
    journal=z.read('products/shift-assistant/src/journal.ts').decode()
    assert "createHash('sha256').update(bytes).digest('hex')" in journal
    assert 'Object.keys(record)' in journal and '.sort()' in journal
    assistant=z.read('products/shift-assistant/src/assistant.ts').decode()
    assert 'const id = sha256(JSON.stringify([i.key, revision]))' in assistant
    assert 'n.authorPhone === i.memberPhone && n.token === cmd.token' in assistant
    generator={'commit':c,'archiveFile':archive,'archiveSha256':sha(b),'entry':entry,'entrySha256':sha(gen.encode()),'generatorLine':start,'generatorLineSha256':formulaLineSha,'formulaSha256':formulaSha,'formula':'note.id[0:12] + literal + decimal revision + literal + note.organizedSha256[0:12]','separatorSha256':[sha(v.encode()) for v in formula.groups()],'algorithm':'SHA256-derived revision identifier; no HMAC/key/payload bearer signature','journalEntrySha256':sha(journal.encode()),'assistantEntrySha256':sha(assistant.encode()),'authorPhoneConstraintVerified':True,'sameCommitDigestLinks':[]}
    receiptpaths=[base+('product-first-critic/canonical-pre.json' if c.startswith('387aca') else 'product-final-critic/copy-receipt.json'),base+('product-vertical-builder/source-freeze.json' if c.startswith('387aca') else 'product-first-rework/lead/product-r2-source-freeze.json')]
    for f in receiptpaths:
        rb=show(c,f)
        if rb is None:continue
        obj=json.loads(rb)
        def walk(o,path=()):
            if isinstance(o,dict):
                for k,v in o.items():
                    if k==entry and v==generator['entrySha256']:
                        generator['sameCommitDigestLinks'].append({'file':f,'blobSha256':sha(rb),'pointer':'/'+ '/'.join((*path,k)),'entryDigestEquals':True})
                    walk(v,(*path,k))
            elif isinstance(o,list):
                for i,v in enumerate(o):walk(v,(*path,str(i)))
        walk(obj)
    generators[c]=(generator,formula.groups())
    assert generator['sameCommitDigestLinks'], 'Same-commit execution-copy/source digest binding missing'
    sources.append(generator)

notes={};parsed={}
def walknotes(o,path=()):
    if isinstance(o,dict):
        if isinstance(o.get('token'),str) and all(k in o for k in ['id','revision','organizedSha256','rawTextSha256','rawText','messageKey']):yield path,o
        for k,v in o.items():yield from walknotes(v,(*path,k))
    elif isinstance(o,list):
        for i,v in enumerate(o):yield from walknotes(v,(*path,str(i)))
for x in targets:
    if not x['file'].endswith(('.json','.jsonl')):continue
    pair=x['commit'],x['file']
    if pair not in parsed:
        b=show(*pair);obj=json.loads(b) if x['file'].endswith('.json') else [json.loads(l) for l in b.splitlines() if l.strip()]
        parsed[pair]=obj
        for path,n in walknotes(obj):notes.setdefault((x['commit'],sha(n['token'].encode())),[]).append((x['file'],path,n,sha(b)))

linked=[];updates={}
for x in targets:
    g=generators.get(x['commit']);nlist=notes.get((x['commit'],x['candidateSha256']),[])
    facts={'identity':x['identity'],'commit':x['commit'],'findingFile':x['file'],'findingLines':[x['startLine'],x['endLine']],'candidateSha256':x['candidateSha256'],'generatorAvailable':g is not None,'sameCommitMatchingNoteCount':len(nlist),'validatedNotes':[],'executionOutputLinks':[]}
    if g:
        generator,sep=g
        facts['generator']=generator
        for file,path,n,blobsha in nlist:
            generated=n['id'][:12]+sep[0]+str(n['revision'])+sep[1]+n['organizedSha256'][:12]
            idcomputed=sha(json.dumps([n['messageKey'],n['revision']],ensure_ascii=False,separators=(',',':')).encode())
            orgcomputed=sha(canon(n.get('organized')).encode());rawcomputed=sha(n['rawText'].encode())
            ok=sha(generated.encode())==x['candidateSha256'] and generated==n['token'] and idcomputed==n['id'] and orgcomputed==n['organizedSha256'] and rawcomputed==n['rawTextSha256']
            nf={'sourceFile':file,'sourceBlobSha256':blobsha,'pointer':'/'+ '/'.join(path),'tokenRecomputedEquals':generated==n['token'],'tokenSha256':sha(generated.encode()),'noteIdRecomputedEquals':idcomputed==n['id'],'organizedDigestRecomputedEquals':orgcomputed==n['organizedSha256'],'rawTextDigestRecomputedEquals':rawcomputed==n['rawTextSha256'],'messageKeySha256':sha(n['messageKey'].encode()),'noteIdSha256':sha(n['id'].encode()),'organizedPayloadSha256':orgcomputed,'rawPayloadSha256':rawcomputed,'allChecks':ok}
            facts['validatedNotes'].append(nf)
        if any(n['allChecks'] for n in facts['validatedNotes']):
            updates[x['identity']]=facts
    # Execution/source/output paths are observations, not acceptance of recorded exit/verdict.
    category='product-first-critic' if '/product-first-critic/' in x['file'] else 'product-final-lead-replay' if '/product-final-lead-replay/' in x['file'] else 'product-final-critic'
    script=base+category+('/critic-adversarial-r1.ts' if category=='product-first-critic' else '/lifecycle.mts' if 'lifecycle' in x['file'] or any(z in x['file'] for z in ['pause-blocked','receipt-fsync']) else '/probe.mts')
    sb=show(x['commit'],script)
    if sb:
        txt=sb.decode();links={'sourceScript':script,'sourceScriptSha256':sha(sb),'capturesNotesV2':'notesV2()' in txt,'capturesJournal':'journal' in txt,'writesJsonOutput':'JSON.stringify' in txt,'usesInlineInputFixture':bool(re.search(r'const\s+raw\s*=',txt)),'fixtureImports':re.findall(r'from [\'\"]([^\'\"]*fixture[^\'\"]*)',txt)}
        facts['executionOutputLinks'].append(links)
    linked.append(facts)

emap={e['evidenceId']:e for e in evidence}
for x in ledger:
    if x['identity'] in updates:
        x['disposition']='HASH';x['reason']='REVISION_IDENTIFIER_FULLY_RECOMPUTED_FROM_SAME_COMMIT_NOTE_AND_ARCHIVED_GENERATOR'
for e in evidence:
    ids=e['members']
    if all(i in updates for i in ids):
        e['disposition']='HASH';e['reason']='REVISION_IDENTIFIER_FULLY_RECOMPUTED_FROM_SAME_COMMIT_NOTE_AND_ARCHIVED_GENERATOR';e['facts']['credentialSuspected']=False;e['facts']['sameCommitTokenLinkageIds']=ids;e['facts']['linkageArtifact']='token-links.jsonl';e['facts']['unkeyedRevisionIdentifier']=True
for name,rows in [('ledger.jsonl',ledger),('evidence.jsonl',evidence),('token-links.jsonl',linked)]:
    with (P/name).open('w') as f:
        for row in rows:f.write(json.dumps(row,ensure_ascii=False)+'\n')
(P/'generator-evidence.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2)+'\n')
(P/'token-link-provenance.json').write_text(json.dumps(calls,ensure_ascii=False,indent=2)+'\n')
counts=dict(collections.Counter(x['disposition'] for x in ledger));summary={'identities':len(ledger),'groups':len(evidence),'counts':counts,'reasons':dict(collections.Counter(x['reason'] for x in ledger)),'credentialSuspectedIdentities':sum(len(e['members']) for e in evidence if e['facts'].get('credentialSuspected')),'credentialSuspectedGroups':sum(bool(e['facts'].get('credentialSuspected')) for e in evidence),'sameCommitTokenTargets':len(targets),'sameCommitTokensLinked':len(updates),'verdict':'REJECT' if counts.get('PENDING') or counts.get('REAL') else 'ACCEPT'}
(P/'disposition-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
print('TOKEN_FAILURES',json.dumps([{'id':x['identity'],'generator':x['generatorAvailable'],'notes':x['sameCommitMatchingNoteCount'],'checks':[[n[k] for k in ['tokenRecomputedEquals','noteIdRecomputedEquals','organizedDigestRecomputedEquals','rawTextDigestRecomputedEquals']] for n in x['validatedNotes']]} for x in linked if x['identity'] not in updates]))
