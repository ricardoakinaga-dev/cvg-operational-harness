import datetime, hashlib, json, pathlib, re, subprocess, sys
P=pathlib.Path(__file__).resolve().parent
ENV={'PATH':'/usr/bin:/bin','HOME':str(P),'LANG':'C.UTF-8','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_OPTIONAL_LOCKS':'0','GIT_NO_REPLACE_OBJECTS':'1','GIT_TERMINAL_PROMPT':'0'}
GITDIR='/home/ricardo/Área de trabalho/cvg-operational-harness/.git'
sha=lambda b:hashlib.sha256(b).hexdigest()
calls=[]
def show(c,f):
    cmd=['/usr/bin/git','--git-dir='+GITDIR,'show','--no-textconv',c+':'+f]
    r=subprocess.run(cmd,cwd=P,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
    calls.append({'argv':cmd,'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode,'stdoutBytes':len(r.stdout),'stdoutSha256':sha(r.stdout),'stderrSha256':sha(r.stderr)})
    return r.stdout if r.returncode==0 else None
def safe(line):
    return re.sub(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|`(?:\\.|[^`\\])*`',lambda m:m.group() if m.group()[1:-1] in ['sha256','hex','utf8','base64url','base64'] else '<STRING>',line)
jobs=[('a9e516f19eaf149abda0c17916aef28255608451','products/shift-assistant/src/assistant.ts'),('a9e516f19eaf149abda0c17916aef28255608451','products/shift-assistant/src/commands.ts'),('387aca210480edd7110330b8a2a0709441787054','products/shift-assistant/src/assistant.ts'),('387aca210480edd7110330b8a2a0709441787054','products/shift-assistant/src/commands.ts'),('a9e516f19eaf149abda0c17916aef28255608451','docs/04_audit/evidence/HARNESS-ISO-EXEC-20261003/audit-actions/product-final-critic'),('a9e516f19eaf149abda0c17916aef28255608451','docs/04_audit/evidence/HARNESS-ISO-EXEC-20261003/audit-actions/product-final-lead-replay')]
observations=[]
for c,f in jobs:
    b=show(c,f)
    if b is None:print(json.dumps({'commit':c,'file':f,'missing':True}));continue
    lines=b.decode().splitlines();out={'commit':c,'file':f,'blobSha256':sha(b)}
    if f.endswith('.ts'):
        selected=set()
        for i,line in enumerate(lines):
            if re.search(r'createHmac|tokenFor|noteToken|tokenSignature|makeToken|verifyToken|\.token\s*=|function.*[Tt]oken',line):selected.update(range(max(0,i-3),min(len(lines),i+8)))
        out['mechanicalLines']=[{'line':i+1,'hashline':sha(lines[i].encode()),'skeleton':safe(lines[i])} for i in sorted(selected)]
        out['templateExpressions']=[{'line':i+1,'expressions':re.findall(r'\$\{([^}]+)\}',line)} for i,line in enumerate(lines) if i in selected and '`' in line]
    else:out['treeEntries']=lines
    observations.append(out);print(json.dumps(out,ensure_ascii=False))
(P/'link-inspection.json').write_text(json.dumps(observations,ensure_ascii=False,indent=2)+'\n')
(P/'link-inspection-provenance.json').write_text(json.dumps(calls,ensure_ascii=False,indent=2)+'\n')
