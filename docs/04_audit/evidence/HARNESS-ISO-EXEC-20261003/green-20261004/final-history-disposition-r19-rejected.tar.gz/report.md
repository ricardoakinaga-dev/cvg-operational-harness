# Finite independent historical security disposition

Verdict: **REJECT**. Exactly 6,688 identities were reviewed at frozen commit `849455b09e4eadde5e27a21e0837a953f9e266c2`. There are **3 PENDING** identities: two signing literals with unproven synthetic origin and one prose match without independent mechanical disposition. No REAL credential has been confirmed. The complete finite list, exact commits, lines and all hashes are in [pending.md](pending.md) and [pending.json](pending.json).

| Disposition | Individual findings |
|---|---:|
| HASH | 6645 |
| SYNTHETIC | 35 |
| PLACEHOLDER / noncredential scanner match | 5 |
| PENDING | 3 |
| REAL confirmed | 0 |

[ledger.jsonl](ledger.jsonl) preserves every input identity, rule, file, exact commit, lines/columns, Git blob OID, blob SHA-256, span and individual line hashes, candidate hash, ancestry and evidence link. [evidence.jsonl](evidence.jsonl) contains 1,956 distinct decisions grouped exclusively by identical blob, exact line/column span and rule. Different commits/paths retain individual identities and ancestry. There are 176 repeated fingerprint occurrences, all retained rather than dropped.

6,572 HASH findings are exact 64-hex values in a declared digest schema or mechanically checked artifact-path digest map (including explicit null missing entries). Names, paths and counts alone were not used. Referenced unflagged files were not read merely to recompute their hashes; this is a digest-role disposition, not proof of every recorded historical digest preimage.

The other **73 HASH findings** are revision identifiers, initially suspected opaque capabilities. Archived generators in each finding's same commit were matched by source digest to historical source/copy artifacts. Every token was exactly recomputed as note-id prefix, revision and organized-content digest prefix. The complete note ID, raw text digest and organized payload digest were independently recomputed too. The generator has no HMAC or secret-key input; the consumer also checks author identity. [token-links.jsonl](token-links.jsonl) links each individual finding to note payload hashes, generator archive/member/line hashes and script output observations; [generator-evidence.json](generator-evidence.json) records code and digest bindings. Existing exit statuses, reported successes and narrative verdicts were not acceptance authority, and historical scripts were not executed.

The final five were investigated in isolation. `F006153` and `F006158` were resolved as cross-line scanner matches: an empty API-key assignment was followed by a routing-instance assignment. Same-commit config, composition and consumer code prove the instance is placed in the URL while a separate API key is placed in a header. This decision does not rely on localhost or synthetic naming. `F006214`, `F006219` and `F006444` remain PENDING, as detailed in [remaining-link-evidence.json](remaining-link-evidence.json).

For both signing literals, exact same-commit fixture producer/consumer code and controlled identity construction were inspected. Offline Python and the existing OpenSSL library produced identical HMAC-SHA256 signatures; decoded Base64url fixture payloads round-tripped and altered payloads were rejected. There was no historical stored signature establishing synthetic origin of either literal. Cryptographic validity and fixture names do not establish that origin, so both remain PENDING. The prose match was limited to its flagged line and mechanical grammar; it cannot approve itself through a prior narrative statement.

[verification.json](verification.json) records a fresh, separate integrity pass: 6,688 input-to-ledger identities, 169 exact historical sources, 22 ancestry checks, group integrity, 73 complete revision/digest linkages, two offline cryptographic comparisons and non-disclosure of all unresolved candidate bytes. Original source line terminators are included in line hashes. Scanner columns are preserved as reported.

Initial REJECT (119 PENDING), corrected REJECT (78 PENDING), token-linked REJECT (5 PENDING) and final REJECT (3 PENDING) are preserved in [decision-history.json](decision-history.json) and its draft artifacts. No old review verdict or baseline was consulted as authority.

The review ends here with the finite gaps in `pending.json`. Scope is only this supplied strict, fully redacted historical report. Scanner receipt/log integrity and strict/no-ignore flags were checked; the outside scanner binary/config were not read or rerun. No network/provider/PG/install, subagent, descendant-commit, private environment, current working-tree or unrelated-gate work occurred. Only this disposition package was written. This rejects full disposition acceptance and grants no production, history or rule waiver. Values are absent from artifacts; only hashes, code structure and verifiable reasons are recorded.
