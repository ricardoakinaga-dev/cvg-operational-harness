import collections, datetime, hashlib, json, pathlib, re, subprocess

P = pathlib.Path(__file__).resolve().parent
REPORTS = pathlib.Path(json.loads((P/'authority.json').read_text())['readReports'])
FROZEN = '849455b09e4eadde5e27a21e0837a953f9e266c2'
GITDIR = '/home/ricardo/Área de trabalho/cvg-operational-harness/.git'
ENV = {'PATH':'/usr/bin:/bin','HOME':str(P),'LANG':'C.UTF-8', 'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_OPTIONAL_LOCKS':'0','GIT_NO_REPLACE_OBJECTS':'1','GIT_TERMINAL_PROMPT':'0'}
sha = lambda b: hashlib.sha256(b).hexdigest()
def write(name, obj):
    (P/name).write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n')
calls=[]
def git(args):
    cmd=['/usr/bin/git','--git-dir='+GITDIR,*args]
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    r=subprocess.run(cmd, cwd=P, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=45)
    calls.append({'argv':cmd,'startedAt':start,'exitCode':r.returncode,'stdoutBytes':len(r.stdout),'stdoutSha256':sha(r.stdout),'stderrSha256':sha(r.stderr)})
    return r
rows=json.loads((REPORTS/'gitleaks-history.json').read_text())
assert len(rows)==6688
assert all(x['Secret']=='REDACTED' for x in rows)
ancestry={}
for c in sorted({x['Commit'] for x in rows}):
    assert re.fullmatch('[a-f0-9]{40}',c)
    r=git(['merge-base','--is-ancestor',c,FROZEN])
    ancestry[c]={'frozen':FROZEN,'exitCode':r.returncode,'isAncestor':r.returncode==0}
cache={}; inventory=[]
for i,x in enumerate(rows,1):
    c,f=x['Commit'],x['File'];pair=(c,f)
    if pair not in cache:
        assert not f.startswith('/') and '..' not in pathlib.PurePosixPath(f).parts
        r=git(['show','--no-textconv',c+':'+f])
        if r.returncode: cache[pair]=None
        else:
            b=r.stdout
            cache[pair]={'bytes':b,'text':b.decode('utf-8'),'lines':b.splitlines(keepends=True),'blobSha256':sha(b),'gitBlobOid':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
    source=cache[pair]
    base={'identity':f'F{i:06d}','inputIndex':i-1,'fingerprint':x['Fingerprint'],'rule':x['RuleID'],'file':f,'commit':c,'startLine':x['StartLine'],'endLine':x['EndLine'],'startColumn':x['StartColumn'],'endColumn':x['EndColumn'],'ancestry':ancestry[c]}
    if source is None:
        inventory.append({**base,'error':'EXACT_SOURCE_UNAVAILABLE'});continue
    ls=source['lines']; lo,hi=x['StartLine']-1,x['EndLine']
    if not (0<=lo<hi<=len(ls)):
        inventory.append({**base,'error':'LINE_RANGE_INVALID'});continue
    span=b''.join(ls[lo:hi]);line=span.decode('utf-8')
    prefix,suffix=x['Match'].split('REDACTED',1)
    # Redacted scanner match anchors recover the candidate without publishing it.
    rx=re.escape(prefix)+('(?P<candidate>.*?)'+re.escape(suffix) if suffix else '(?P<candidate>[^\r\n]+)')
    matches=list(re.finditer(rx,line,re.S))
    if not matches:
        inventory.append({**base,'blobSha256':source['blobSha256'],'gitBlobOid':source['gitBlobOid'],'lineSha256':sha(span),'error':'REDACTED_MATCH_NOT_RECOVERED'});continue
    m=min(matches,key=lambda z:abs(len(line[:z.start()].encode())+2-x['StartColumn']))
    candidate_start=m.start('candidate');candidate_end=m.end('candidate')
    if not suffix:
        # EndColumn uses the final line and is offset by one in this scanner report.
        before_final=sum(len(z) for z in line.splitlines(keepends=True)[:-1])
        final_line=line[before_final:]
        boundary=before_final+len(final_line.encode()[:x['EndColumn']-1].decode())
        candidate_end=min(candidate_end,boundary)
    v=line[candidate_start:candidate_end]
    # Only predefined vocabulary indicators are emitted; unknown contents remain hashed.
    known=['test','synthetic','fake','fixture','example','placeholder','replace','change','dev','local','secret','token','key','approval','idem','operation','persist','restore','dummy','redact','hmac','signing','jwt','api','round','critic','probe','worker','replay','controlled','password','delivery','journey','postgres','smoke','continuous','qualification','never','rotation','old','new','current']
    indicators=[k for k in known if re.search(r'(?i)(?:^|[^a-z])'+k+r'(?:[^a-z]|$)',v)]
    quotes=list(re.finditer(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|`(?:\\.|[^`\\])*`',line))
    skeleton=line
    for q in reversed(quotes):
        raw=q.group(); replacement='<STRING>'
        if q.end()<=candidate_start and re.match(r'\s*:',line[q.end():]):
            # JSON member names are structural context; path-like names may be retained.
            replacement=raw
        skeleton=skeleton[:q.start()]+replacement+skeleton[q.end():]
    # Narrative and unquoted assignments are never printed as context.
    if f.endswith('.md') or f.endswith('.log') or f.endswith('.example'):
        skeleton='<NON_JSON_OR_CODE_CONTEXT_REDACTED>'
    # Hash nearby enclosing structure only: no prior narrative verdict is evidence.
    context=b''.join(ls[max(0,lo-4):min(len(ls),hi+4)])
    parents=[]
    for z in ls[max(0,lo-16):lo]:
        t=z.decode('utf-8').strip()
        pm=re.fullmatch(r'"([^"\n]+)"\s*:\s*[\[{]',t)
        if pm:parents.append(pm.group(1))
    item={**base,'blobSha256':source['blobSha256'],'gitBlobOid':source['gitBlobOid'],'lineSha256':sha(span),'contextSha256':sha(context),'candidateSha256':sha(v.encode()),'candidateLength':len(v),'candidateHex':bool(re.fullmatch('[a-fA-F0-9]+',v)),'candidateAlphabet':('hex' if re.fullmatch('[a-fA-F0-9]+',v) else 'word-hyphen' if re.fullmatch('[A-Za-z0-9_-]+',v) else 'other'),'indicators':indicators,'matchOccurrences':len(matches),'matchColumnObserved':m.start()+1,'matchByteColumnObserved':len(line[:m.start()].encode())+1,'candidateStartInSpan':candidate_start,'candidateEndInSpan':candidate_end,'safeSkeleton':skeleton.strip()[:800],'nearbyContainerKeys':parents}
    inventory.append(item)
with (P/'inventory.jsonl').open('w') as out:
    for x in inventory:out.write(json.dumps(x,ensure_ascii=False)+'\n')
write('ancestry.json',ancestry)
write('git-provenance.json',calls)
write('collection-summary.json',{'rows':len(inventory),'errors':dict(collections.Counter(x.get('error') for x in inventory if x.get('error'))),'ancestryFailures':[c for c,a in ancestry.items() if not a['isAncestor']],'sourcePairs':len(cache),'uniqueBlobs':len({x['blobSha256'] for x in inventory if 'blobSha256'in x}),'candidateShapes':dict(collections.Counter(('HEX_'+str(x['candidateLength'])) if x.get('candidateHex') else 'NONHEX_'+str(x.get('candidateLength')) for x in inventory))})
print(json.dumps(json.loads((P/'collection-summary.json').read_text())))
