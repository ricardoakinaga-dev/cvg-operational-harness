import bisect, collections, hashlib, hmac, json, pathlib, re, runpy

P=pathlib.Path(__file__).resolve().parent
C=runpy.run_path(str(P/'collect.py'))
inventory=C['inventory'];cache=C['cache'];inputrows=C['rows'];sha=C['sha'];write=C['write']
DEC=json.JSONDecoder()

def json_positions(text):
    strings=[];objects={}
    def ws(i):
        while i<len(text) and text[i].isspace():i+=1
        return i
    def node(i,path):
        i=ws(i);start=i
        if text[i]=='{':
            i=ws(i+1);obj={}
            while text[i]!='}':
                key,j=DEC.raw_decode(text,i);i=ws(j);assert text[i]==':'
                value,i=node(i+1,(*path,key));obj[key]=value;i=ws(i)
                if text[i]==',':i=ws(i+1)
                else:break
            assert text[i]=='}';objects[path]=obj;return obj,i+1
        if text[i]=='[':
            i=ws(i+1);arr=[]
            while text[i]!=']':
                value,i=node(i,(*path,len(arr)));arr.append(value);i=ws(i)
                if text[i]==',':i=ws(i+1)
                else:break
            assert text[i]==']';return arr,i+1
        value,j=DEC.raw_decode(text,i)
        if isinstance(value,str):strings.append((i,j,path,value))
        return value,j
    obj,end=node(0,());assert not text[end:].strip()
    return {'strings':strings,'objects':objects,'object':obj,'starts':[x[0] for x in strings]}

jsoncache={}
def locate(x):
    s=cache[(x['commit'],x['file'])];ls=s['lines']
    key=x['blobSha256'] if x['file'].endswith('.json') else (x['blobSha256'],x['startLine'])
    if key not in jsoncache:
        text=s['text'] if x['file'].endswith('.json') else b''.join(ls[x['startLine']-1:x['endLine']]).decode()
        jsoncache[key]=json_positions(text)
    data=jsoncache[key]
    off=len(b''.join(ls[:x['startLine']-1]).decode()) if x['file'].endswith('.json') else 0
    begin=off+x['candidateStartInSpan'];end=off+x['candidateEndInSpan']
    idx=bisect.bisect_right(data['starts'],begin)-1
    if idx<0:return None
    a,b,path,v=data['strings'][idx]
    if not a<begin<=end<b:return None
    return path,v,data['objects'].get(path[:-1],{}),data

def pointer(path):return '/'+ '/'.join(str(x).replace('~','~0').replace('/','~1') for x in path)
def extract(x):
    s=cache[(x['commit'],x['file'])]
    span=b''.join(s['lines'][x['startLine']-1:x['endLine']]).decode()
    return span[x['candidateStartInSpan']:x['candidateEndInSpan']]

grouped={}
for x in inventory:
    key=(x['rule'],x.get('blobSha256'),x['startLine'],x['endLine'],x['startColumn'],x['endColumn'])
    grouped.setdefault(key,[]).append(x)

# Fixture key candidates come ONLY from flagged literal declarations. Hash their provenance.
fixturekeys=[]
for key,rs in grouped.items():
    x=rs[0]
    if x.get('error'):continue
    v=extract(x)
    s=cache[(x['commit'],x['file'])];line=b''.join(s['lines'][x['startLine']-1:x['endLine']]).decode()
    if x['file'].endswith(('.ts','.mjs')) and re.search(r'(?i)(?:secret|password|key)\s*[:=]\s*[\'"`]',line):
        # Explicit mnemonic fixture marker, never a filename-only verdict.
        if re.search(r'(?i)(?:synthetic|sint[eé]tic[oa]|(?:^|[-_])test(?:[-_]|$))',v) or 'SYNTHETIC_' in line:
            fixturekeys.append((v,x))

evidence=[];ledger=[]
for n,(key,rs) in enumerate(grouped.items(),1):
    x=rs[0];eid=f'E{n:06d}';gid=f'G{n:06d}';status='PENDING';reason='UNRESOLVED';facts={}
    v=extract(x) if not x.get('error') else ''
    s=cache.get((x['commit'],x['file']))
    span=b''.join(s['lines'][x['startLine']-1:x['endLine']]).decode() if s else ''
    ctx=b''.join(s['lines'][max(0,x['startLine']-5):min(len(s['lines']),x['endLine']+4)]).decode() if s else ''
    # gitleaks 8.28 redacted match starts one byte before its reported StartColumn.
    facts['matchStartByteDelta']=x.get('matchByteColumnObserved',0)+1-x['startColumn']
    if x.get('error'):
        reason=x['error']
    elif not all(a['ancestry']['isAncestor'] for a in rs):reason='ANCESTRY_UNPROVEN'
    elif abs(facts['matchStartByteDelta'])>1:
        reason='MATCH_POSITION_UNPROVEN'
    else:
        info=locate(x) if x['file'].endswith(('.json','.jsonl')) else None
        if info:
            path,value,parent,data=info
            facts['jsonPointer']=pointer(path)
            facts['jsonValueEqualsCandidate']=value==v
            if x['candidateHex'] and x['candidateLength']==64 and value==v:
                explicit=any(re.search(r'(?i)(?:sha256|hash|fingerprint)',str(z)) for z in path[:-1]) or bool(re.search(r'(?i)sha256',str(path[-1])))
                digestmap=bool(parent) and all(isinstance(z,str) and bool(re.fullmatch('[a-f0-9]{64}',z)) for z in parent.values())
                nullablemap=bool(parent) and all(z is None or isinstance(z,str) and bool(re.fullmatch('[a-f0-9]{64}',z)) for z in parent.values())
                artifactkey=isinstance(path[-1],str) and ('/' in path[-1] or '.' in path[-1])
                facts.update({'candidateIs64LowerHex':bool(re.fullmatch('[a-f0-9]{64}',v)),'explicitDigestSchema':explicit,'parentHomogeneous64HexMap':digestmap,'parent64HexOrNullMap':nullablemap,'parentNullEntries':sum(z is None for z in parent.values()),'candidateMemberIsArtifactPath':artifactkey,'parentMemberCount':len(parent)})
                matches=[{'commit':c,'file':f,'blobSha256':b['blobSha256']} for (c,f),b in cache.items() if b and b['blobSha256']==v and str(path[-1])==f]
                facts['matchesAuthorizedSourceDigest']=matches
                if explicit or ((digestmap or nullablemap) and artifactkey) or matches:
                    status='HASH';reason='DIGEST_VALUE_IN_EXACT_STRUCTURAL_SCHEMA'
                    facts['limitation']='Digest role is established by exact JSON structure and byte format. Unflagged referenced files were not read; not all digest preimages were recomputed.'
            elif path[-1]=='token':
                reason='OPAQUE_TOKEN_CAPABILITY_ORIGIN_UNPROVEN'
                pieces=v.split('-')
                facts['tokenChunkLengths']=[len(z) for z in pieces]
                facts['matchesNoteIdRevision']=len(pieces)==3 and pieces[0]==str(parent.get('id',''))[:12] and pieces[1]=='r'+str(parent.get('revision'))
                facts['siblingNoteSchema']=all(z in parent for z in ['id','revision','rawTextSha256'])
                facts['credentialSuspected']=True
                # Bounded local derivation candidates; a positive result is byte proof, not a provider check.
                if facts['matchesNoteIdRevision']:
                    fields={z:parent[z] for z in ['id','revision','rawTextSha256','organizedSha256','authorPhone','messageKey'] if z in parent}
                    payloads=[]
                    for names in [('id','revision'),('id','revision','rawTextSha256'),('id','revision','authorPhone'),('id','revision','rawTextSha256','authorPhone')]:
                        if all(z in fields for z in names):
                            for sep in [':','|','-','.','/']:
                                payloads.append((str(names)+' separator='+repr(sep),sep.join(str(fields[z]) for z in names)))
                    payloads.extend([('token prefix without signature','-'.join(pieces[:2])),('JSON id/revision',json.dumps({'id':parent['id'],'revision':parent['revision']},separators=(',',':')))])
                    facts['localHmacSha256Checks']=len(payloads)*len(fixturekeys)
                    for secret,fx in fixturekeys:
                        for label,payload in payloads:
                            digest=hmac.new(secret.encode(),payload.encode(),hashlib.sha256).hexdigest()
                            if digest[:len(pieces[2])]==pieces[2]:
                                facts['localDerivation']={'algorithm':'HMAC-SHA256 truncated hex','payloadEncoding':label,'fixtureIdentity':fx['identity'],'fixtureKeySha256':fx['candidateSha256'],'payloadSha256':sha(payload.encode())}
                                status='SYNTHETIC';reason='TOKEN_RECOMPUTED_FROM_FLAGGED_SYNTHETIC_LITERAL';facts['credentialSuspected']=False
            elif value==v and re.fullmatch(r'[A-Z][A-Z0-9_]*\d{4}',v) and re.search(r'(?i)build',str(path[-1])):
                status='PLACEHOLDER';reason='BUILD_STATUS_SYMBOL_NOT_AUTHENTICATION_MATERIAL';facts['symbolUppercaseWithYearSuffix']=True
        if status=='PENDING' and x['file'].endswith(('.ts','.mjs')):
            literal=bool(re.search(r'[\'"`]'+re.escape(v)+r'[\'"`]',span))
            operation=bool(re.search(r'(?:idempotencyKey|idempotency_key|operationKey|decisionCommandKey)\s*:',span))
            literaloperation=operation or ('operationKey' in span and 'synthetic' in v.lower()) or (re.search(r'key\s*:',span) and 'idempotency' in ctx)
            mnemonic=bool(re.search(r'(?i)(?:synthetic|sint[eé]tic[oa]|(?:^|[-_])test(?:[-_]|$))',v))
            facts.update({'exactQuotedLiteral':literal,'operationIdentityField':bool(literaloperation),'explicitSyntheticMnemonic':mnemonic,'syntheticConstantDeclared':bool(re.search(r'const\s+SYNTHETIC_(?:SECRET|PASSWORD)\s*=',span)),'mechanicalContextHasTestCall':bool(re.search(r'\b(?:describe|it|test)\s*\(',ctx))})
            if literal and literaloperation:
                status='SYNTHETIC';reason='LITERAL_OPERATION_OR_IDEMPOTENCY_IDENTIFIER'
            elif literal and (mnemonic or facts['syntheticConstantDeclared']):
                status='SYNTHETIC';reason='EXPLICIT_SYNTHETIC_LITERAL_DECLARATION'
            elif re.search(r'(?i)(?:secret|password|key)\s*[:=]',span):
                reason='CREDENTIAL_LITERAL_WITHOUT_SUFFICIENT_SYNTHETIC_PROOF';facts['credentialSuspected']=True
        if status=='PENDING' and x['file'].endswith('.example'):
            # The scanner consumes a following config NAME after an empty secret assignment.
            prefix=inputrows[x['inputIndex']]['Match'].split('REDACTED',1)[0]
            following=span.splitlines()[-1]
            assignment=re.fullmatch(r'([A-Z][A-Z0-9_]*)=([^\r\n]*)',following)
            nextname=re.match(r'[A-Z][A-Z0-9_]*',v)
            facts.update({'emptySensitiveAssignmentThenNewline':bool(re.fullmatch(r'[A-Z][A-Z0-9_]*=\n',prefix)),'nextLineIsConfigAssignment':bool(assignment),'candidateIsOnlyFollowingConfigName':bool(assignment and v==assignment[1]),'nextConfigName':nextname.group() if nextname else None,'nextValueDecimal':bool(assignment and re.fullmatch('[0-9]+',assignment[2])),'nextValueLoopbackUrl':bool(assignment and re.fullmatch(r'http://(?:127\.0\.0\.1|localhost)(?::[0-9]+)?/?',assignment[2]))})
            if facts['emptySensitiveAssignmentThenNewline'] and assignment and (facts['candidateIsOnlyFollowingConfigName'] or facts['nextValueDecimal'] or facts['nextValueLoopbackUrl']):
                status='PLACEHOLDER';reason='EMPTY_SECRET_ASSIGNMENT_SCANNER_CROSSED_NEWLINE_TO_NONSECRET_CONFIG'
        if status=='PENDING' and x['file'].endswith('.md'):
            # Exact matched text is narrative: grammar observations only, no prior verdict authority.
            facts.update({'narrativeValueContainsWhitespace':bool(re.search(r'\s',v)),'narrativeValueHasNonAscii':any(ord(z)>127 for z in v),'narrativeValueContainsMarkup':bool(re.search(r'[`*]',v)),'historicalNarrativeNeverApproval':True})
            reason='NARRATIVE_MATCH_NOT_SUFFICIENT_TO_PROVE_SYNTHETIC_OR_CREDENTIAL'
        if status=='PENDING' and x['file'].endswith('.log'):
            facts['candidateIsQuotedTokenMember']=bool(re.search(r'[\'\"]token[\'\"]\s*:\s*[\'\"]'+re.escape(v),span))
            if facts['candidateIsQuotedTokenMember']:
                facts['credentialSuspected']=True;reason='OPAQUE_TOKEN_CAPABILITY_ORIGIN_UNPROVEN'
    e={'evidenceId':eid,'groupId':gid,'representative':x['identity'],'rule':x['rule'],'blobSha256':x.get('blobSha256'),'gitBlobOid':x.get('gitBlobOid'),'lineSha256':x.get('lineSha256'),'contextSha256':x.get('contextSha256'),'span':{k:x[k] for k in ['startLine','endLine','startColumn','endColumn']},'candidateSha256':x.get('candidateSha256'),'candidateLength':x.get('candidateLength'),'disposition':status,'reason':reason,'facts':facts,'members':[a['identity'] for a in rs]}
    evidence.append(e)
    for a in rs:
        ledger.append({k:a[k] for k in ['identity','inputIndex','fingerprint','rule','file','commit','startLine','endLine','startColumn','endColumn','blobSha256','gitBlobOid','lineSha256','contextSha256','candidateSha256','ancestry']}|{'groupId':gid,'evidenceId':eid,'disposition':status,'reason':reason})
ledger.sort(key=lambda x:x['inputIndex'])
for name,rows in [('ledger.jsonl',ledger),('evidence.jsonl',evidence)]:
    with (P/name).open('w') as out:
        for row in rows:out.write(json.dumps(row,ensure_ascii=False)+'\n')
counts=dict(collections.Counter(x['disposition'] for x in ledger));reasons=dict(collections.Counter(x['reason'] for x in ledger))
write('disposition-summary.json',{'identities':len(ledger),'groups':len(evidence),'counts':counts,'reasons':reasons,'credentialSuspectedIdentities':sum(len(x['members']) for x in evidence if x['facts'].get('credentialSuspected')),'credentialSuspectedGroups':sum(bool(x['facts'].get('credentialSuspected')) for x in evidence),'verdict':'REJECT' if counts.get('PENDING') or counts.get('REAL') else 'ACCEPT'})
print(json.dumps(json.loads((P/'disposition-summary.json').read_text())))
