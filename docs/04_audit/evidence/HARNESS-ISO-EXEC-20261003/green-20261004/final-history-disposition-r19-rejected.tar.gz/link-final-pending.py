import base64, collections, ctypes, datetime, hashlib, hmac, json, pathlib, re, subprocess
P=pathlib.Path(__file__).resolve().parent
ENV={'PATH':'/usr/bin:/bin','HOME':str(P),'LANG':'C.UTF-8','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_OPTIONAL_LOCKS':'0','GIT_NO_REPLACE_OBJECTS':'1','GIT_TERMINAL_PROMPT':'0'}
sha=lambda b:hashlib.sha256(b).hexdigest()
calls=[];cache={}
def show(c,f):
    if (c,f) not in cache:
        cmd=['/usr/bin/git','--git-dir=/home/ricardo/Área de trabalho/cvg-operational-harness/.git','show','--no-textconv',c+':'+f]
        r=subprocess.run(cmd,cwd=P,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
        calls.append({'argv':cmd,'exitCode':r.returncode,'stdoutSha256':sha(r.stdout),'stderrSha256':sha(r.stderr),'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})
        cache[c,f]=r.stdout if r.returncode==0 else None
    return cache[c,f]
def jsonl(n):return [json.loads(l) for l in (P/n).read_text().splitlines()]
inventory={x['identity']:x for x in jsonl('inventory.jsonl')};ledger=jsonl('ledger.jsonl');evidence=jsonl('evidence.jsonl');observations=[];updates={}
for x in ledger:
    if x['disposition']!='PENDING':continue
    iv=inventory[x['identity']];b=show(x['commit'],x['file']);ls=b.decode().splitlines(keepends=True);span=''.join(ls[x['startLine']-1:x['endLine']]);v=span[iv['candidateStartInSpan']:iv['candidateEndInSpan']]
    out={'identity':x['identity'],'commit':x['commit'],'file':x['file'],'candidateSha256':sha(v.encode()),'findingBlobSha256':sha(b),'lineSha256':x['lineSha256']}
    if x['file'].endswith('.example'):
        root='products/shift-assistant/src/' if x['file'].startswith('products/') else 'apps/worker/src/shift-assistant/'
        refs={f:show(x['commit'],root+f) for f in ['config.ts','compose.ts','whatsapp.ts']}
        config=refs['config.ts'].decode();compose=refs['compose.ts'].decode();whatsapp=refs['whatsapp.ts'].decode()
        exactassignment=bool(re.fullmatch(r'EVOLUTION_INSTANCE=[A-Za-z0-9_-]+',v))
        envbound=bool(re.search(r'const\s*\{\s*env,\s*members\s*\}\s*=\s*config',compose))
        fieldroute=envbound and bool(re.search(r'instance\s*:\s*env\.EVOLUTION_INSTANCE',compose))
        independentkey=envbound and bool(re.search(r'apiKey\s*:\s*env\.EVOLUTION_API_KEY',compose))
        urlroute='encodeURIComponent(this.#options.instance)' in whatsapp
        apikeyheader=bool(re.search(r'apikey\s*:\s*this\.#options\.apiKey',whatsapp))
        out.update({'exactFollowingInstanceAssignment':exactassignment,'emptySensitiveAssignment':span.splitlines()[0].endswith('='),'schemaDeclaresSeparateInstanceAndApiKey':'EVOLUTION_INSTANCE: z.string().optional()' in config and 'EVOLUTION_API_KEY: z.string().optional()' in config,'composeRoutesInstance':fieldroute,'composeRoutesSeparateApiKey':independentkey,'consumerUsesInstanceInUrl':urlroute,'consumerUsesSeparateKeyHeader':apikeyheader,'mechanicalSources':[{'file':root+f,'commit':x['commit'],'blobSha256':sha(data)} for f,data in refs.items()]})
        if exactassignment and out['emptySensitiveAssignment'] and out['schemaDeclaresSeparateInstanceAndApiKey'] and fieldroute and independentkey and urlroute and apikeyheader:
            updates[x['identity']]=('PLACEHOLDER','EMPTY_API_KEY_SCANNER_CONSUMED_SEPARATE_INSTANCE_ROUTING_ASSIGNMENT')
    elif x['file'].endswith('.ts'):
        genfile='apps/api/src/operator-identity.ts';gen=show(x['commit'],genfile);text=b.decode();gs=gen.decode()
        helperHmac=bool(re.search(r"createHmac\(['\"]sha256['\"], secret\)",text))
        generatorHmac=bool(re.search(r"createHmac\(['\"]sha256['\"],",gs))
        out.update({'sameCommitGenerator':{'file':genfile,'blobSha256':sha(gen)},'literalKeyInsideTestFixture':bool(re.search(r'const (?:previousSecret|PREVIOUS)\s*=',text)),'historicalFixtureHasControlledIdentity':'const IDENTITY' in text,'historicalHelperHmacSha256':helperHmac,'generatorHmacSha256':generatorHmac,'explicitTestsMnemonicInValue':bool(re.search(r'(?i)(?:^|[-_])tests(?:[-_]|$)',v)),'rotationFixtureCalls':{n:text.count(n) for n in ['createTrustedOperatorIdentityToken','createTrustedOperatorIdentityResolver','createLocalIdentityKeyRing','previousToken','PREVIOUS']}})
        # Cross-runtime offline crypto verifies actual candidate bytes, without treating validity as origin proof.
        identitymatch=re.search(r'const IDENTITY\s*(?::[^=]+)?=\s*\{(.*?)\n\}',text,re.S)
        identity={}
        if identitymatch:
            for name,value in re.findall(r'([A-Za-z]+)\s*:\s*[\'\"]([^\'\"]*)[\'\"]',identitymatch.group(1)):identity[name]=value
        payload={**identity,'iat':0,'exp':300,'jti':'finite-offline-review-fixture','kid':'finite-offline-previous-key'}
        raw=json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode();encoded=base64.urlsafe_b64encode(raw).rstrip(b'=');expected=base64.urlsafe_b64encode(hmac.new(v.encode(),encoded,hashlib.sha256).digest()).rstrip(b'=').decode()
        # Existing OpenSSL only; no installation and no key in argv/env/artifacts.
        lib=ctypes.CDLL('libcrypto.so.3');lib.EVP_sha256.restype=ctypes.c_void_p
        lib.HMAC.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.POINTER(ctypes.c_uint)]
        lib.HMAC.restype=ctypes.c_void_p
        def openssl_mac(data):
            keybuf=ctypes.create_string_buffer(v.encode());databuf=ctypes.create_string_buffer(data);obuf=ctypes.create_string_buffer(64);size=ctypes.c_uint()
            assert lib.HMAC(lib.EVP_sha256(),keybuf,len(v.encode()),databuf,len(data),obuf,ctypes.byref(size))
            return obuf.raw[:size.value]
        mac=openssl_mac(encoded);pmac=hmac.new(v.encode(),encoded,hashlib.sha256).digest()
        decoded=json.loads(base64.urlsafe_b64decode(encoded+b'='*((-len(encoded))%4)))
        out['offlineValidation']={'algorithm':'HMAC-SHA256/Base64url','independentImplementations':'Python hmac and existing OpenSSL libcrypto.so.3','keySha256':sha(v.encode()),'payloadSha256':sha(raw),'encodedPayloadSha256':sha(encoded),'signatureSha256':sha(mac),'pythonOpenSslSignaturesEqual':mac==pmac,'payloadRoundTripEqual':decoded==payload,'alteredPayloadRejected':openssl_mac(encoded+b'x')!=mac,'fixturePayloadOnly':True,'historicalStoredSignatureAvailable':False,'nodeNotRun':'/usr/bin/node unavailable; no installation performed'}
        calls.append({'procedure':'in-process Python/OpenSSL HMAC-SHA256 comparison, Base64url decode and altered-payload control','inputContentsNotPersisted':True,'executed':True,'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})
        out['identityFieldNames']=sorted(identity);out['identityPayloadSha256']=sha(json.dumps(identity,sort_keys=True,separators=(',',':')).encode())
        out['originDecision']='PENDING: exact local fixture construction, producer/consumer references and offline HMAC validity are verified. The bounded same-commit evidence has no stored signature/output tying this candidate to independently established synthetic key generation. Mnemonics and successful signing are insufficient origin proof; this remains an unproven credential literal.'
        relevant=[]
        for sourcefile,source in [(x['file'],text),(genfile,gs)]:
            source_lines=source.splitlines(keepends=True)
            selected=set()
            for i,line in enumerate(source_lines):
                if re.search(r'previousSecret|PREVIOUS\.secret|previousToken|createHmac|function sign|function signedClaims|function createTrustedOperatorIdentityToken|function createTrustedOperatorIdentityResolver',line):
                    selected.update(range(max(0,i-1),min(len(source_lines),i+4)))
            relevant.append({'file':sourcefile,'commit':x['commit'],'blobSha256':sha(source.encode()),'mechanicalLines':[{'line':i+1,'lineSha256':sha(source_lines[i].encode())} for i in sorted(selected)]})
        out['producerConsumerLineEvidence']=relevant
    else:
        out['grammarObservations']={'noAssignmentOperator':'=' not in v,'containsSlash':'/' in v,'containsDigits':bool(re.search(r'\d',v)),'candidateNoWhitespace':not bool(re.search(r'\s',v)),'priorNarrativeVerdictNotUsed':True}
        out['originDecision']='PENDING: narrative-only lexical match has no independent synthetic/hash/placeholder provenance; narrative declarations cannot approve themselves.'
    observations.append(out)
for x in ledger:
    if x['identity'] in updates:x['disposition'],x['reason']=updates[x['identity']]
for e in evidence:
    ids=e['members'];matches=[o for o in observations if o['identity'] in ids]
    if matches:e['facts']['finalLinkageArtifact']='remaining-link-evidence.json';e['facts']['finalLinkageIds']=[m['identity'] for m in matches]
    if all(i in updates for i in ids):e['disposition'],e['reason']=updates[ids[0]]
for name,rows in [('ledger.jsonl',ledger),('evidence.jsonl',evidence)]:
    with (P/name).open('w') as f:
        for row in rows:f.write(json.dumps(row,ensure_ascii=False)+'\n')
(P/'remaining-link-evidence.json').write_text(json.dumps(observations,ensure_ascii=False,indent=2)+'\n')
(P/'remaining-link-provenance.json').write_text(json.dumps(calls,ensure_ascii=False,indent=2)+'\n')
summary=json.loads((P/'disposition-summary.json').read_text());summary['counts']=dict(collections.Counter(x['disposition'] for x in ledger));summary['reasons']=dict(collections.Counter(x['reason'] for x in ledger));summary['verdict']='REJECT' if summary['counts'].get('PENDING') or summary['counts'].get('REAL') else 'ACCEPT'
(P/'disposition-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'summary':summary,'followupChecks':observations},ensure_ascii=False))
