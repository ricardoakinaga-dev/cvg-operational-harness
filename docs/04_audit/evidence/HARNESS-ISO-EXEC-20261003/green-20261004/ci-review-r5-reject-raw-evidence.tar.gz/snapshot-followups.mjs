import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
import {verifySnapshots} from './runtime/scripts/hiso-reports.mjs';
import {buildCoverageReport} from './runtime/scripts/lib/coverage-gate.mjs';
const out=path.dirname(new URL(import.meta.url).pathname),rows=[];
for(const [gateId,file] of [['coverage-critical','accepted-critical-zero.json'],['coverage-critical','accepted-critical-percent.json'],['evals','accepted-evals.json']]){
 const report=JSON.parse(fs.readFileSync(path.join(out,'own-fixtures',file))),dir=path.join(out,'snapshot-followup-fixtures',file);fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'snapshot.json'),JSON.stringify(report));let error,result;
 try{result=verifySnapshots({gate:{id:gateId,skipPolicy:'none'},entry:{outputs:[{path:'snapshot.json'}]},directory:dir,manifest:{runId:'synthetic',candidateId:'a'.repeat(64)},expected:{}});}catch(e){error=e.message;}
 let producerVerdict;
 if(gateId==='coverage-critical'){const metrics=report.global.metrics;producerVerdict=buildCoverageReport({total:metrics,'packages/synthetic.ts':metrics},{branchThreshold:95,groups:[{id:'synthetic',paths:['packages/synthetic.ts']}]}).verdict;}
 rows.push({file,gateId,snapshotAccepted:!error,error,result,producerVerdict});assert(!error);if(gateId==='coverage-critical')assert.equal(producerVerdict,'FAIL');
}
fs.writeFileSync(path.join(out,'snapshot-followups.json'),JSON.stringify(rows,null,2));console.log(JSON.stringify(rows,null,2));
