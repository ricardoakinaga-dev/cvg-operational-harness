import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
import {collectRemoteTrust} from './runtime/scripts/hiso-remote-trust.mjs';
import {contract,contractHash} from './runtime/scripts/hiso-contract.mjs';
import {verifySnapshots} from './runtime/scripts/hiso-reports.mjs';
const out=path.dirname(new URL(import.meta.url).pathname),rows=[];
let fetchCalls=0;const original=globalThis.fetch;globalThis.fetch=async()=>{fetchCalls++;throw new Error('SYNTHETIC_FETCH_MUST_NOT_BE_REACHED');};
try{for(const expected of [{schemaVersion:999},{schemaVersion:1,contract:'unknown'},null,[],{schemaVersion:1,contract:contract.contract,contractHash,candidateId:'wrong'}]){let error;const before=fetchCalls;try{await collectRemoteTrust({expected,scopes:[],producerResults:{},security:{},provenance:{},expectedFile:'unused-local-placeholder',output:path.join(out,'never-remote')});}catch(e){error=e.message;}assert(error);assert.equal(fetchCalls,before);rows.push({id:'malformed-expected-before-remote',expected,error,fetchCalls:fetchCalls-before});}}
finally{globalThis.fetch=original;}
for(const [id,report] of [['schema',{schemaVersion:999}],['type',[]],['counter',{success:true,numTotalTests:-1,testResults:[]}],['contract',{contract:'unknown'}]]){
 const dir=path.join(out,'pre-effect-fixtures',id);fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'report.json'),JSON.stringify(report));let effects=0,error;try{verifySnapshots({gate:{id:'unit',skipPolicy:'none'},entry:{outputs:[{path:'report.json'}]},directory:dir,manifest:{testInventory:[],runId:'synthetic',candidateId:'a'.repeat(64)},expected:{}});effects++;}catch(e){error=e.message;}assert(error);assert.equal(effects,0);rows.push({id:'snapshot-'+id+'-before-follow-up',error,syntheticFollowUpEffects:effects});
}
fs.writeFileSync(path.join(out,'pre-effect-checks.json'),JSON.stringify(rows,null,2));console.log(JSON.stringify(rows,null,2));
