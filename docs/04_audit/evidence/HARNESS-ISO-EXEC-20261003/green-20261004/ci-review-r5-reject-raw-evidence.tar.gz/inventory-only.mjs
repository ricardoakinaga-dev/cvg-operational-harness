import {contract} from './runtime/scripts/hiso-contract.mjs';
import {runScope} from './runtime/scripts/hiso-ci.mjs';
import fs from 'node:fs';
const scope=contract.scopes.find(s=>s.id==='consumer-contract');
// Synthetic bounded driver: invoke the actual runner only for its inventory gate.
// Original helpers/tests are unchanged; no install/build/network gate is invoked.
scope.gates=scope.gates.filter(g=>g.id==='inventory');
const result=runScope({source:new URL('./runtime/',import.meta.url).pathname,output:new URL('./inventory-run/',import.meta.url).pathname,scope:scope.id,runId:'synthetic-r5-inventory-only'});
fs.writeFileSync(new URL('./inventory-driver-result.json',import.meta.url),JSON.stringify({syntheticGateRestriction:['inventory'],status:result.status,gates:result.gates},null,2));
