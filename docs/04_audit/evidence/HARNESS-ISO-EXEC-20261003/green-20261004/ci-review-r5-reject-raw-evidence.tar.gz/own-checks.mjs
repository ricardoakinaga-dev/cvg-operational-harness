import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {spawnSync} from 'node:child_process';
import {gunzipSync} from 'node:zlib';
import {contract,contractHash,sourceFiles,digest,sha,validateContract,files} from './runtime/scripts/hiso-contract.mjs';
import {prepareVariant,projectLock,ownerMapping} from './runtime/scripts/hiso-variant.mjs';
import {snapshotSchema,testReport,coverageReport,verifySnapshots} from './runtime/scripts/hiso-reports.mjs';
import {aggregateCoverage} from './runtime/scripts/hiso-verifier.mjs';
import {approvedCoverageInventory,coverageSourceInventory,caseOccurrences} from './runtime/scripts/hiso-inventory.mjs';
import {validateE2eReportPair,parseE2eEvidenceLog} from './runtime/scripts/lib/e2e-report-binding.mjs';
const out=path.dirname(new URL(import.meta.url).pathname), runtime=path.join(out,'runtime');
const fixtureRoot=path.join(out,'own-fixtures');fs.mkdirSync(fixtureRoot,{recursive:true});
const observations=[];
const json=(p)=>JSON.parse(fs.readFileSync(p,'utf8'));
const write=(root,p,b)=>{const f=path.join(root,p);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,typeof b==='string'||Buffer.isBuffer(b)?b:JSON.stringify(b,null,2));};
const clone=structuredClone;
function check(id,expected,fn,details={}){let actual,value,error;try{value=fn();actual='ACCEPT';}catch(e){actual='REJECT';error=e.message;}const row={id,expected,actual,matched:actual===expected,...details,...(error?{error}:{}),...(value===undefined?{}:{value})};observations.push(row);console.log(JSON.stringify(row));}
const positive=()=>({success:true,numTotalTests:1,numPassedTests:1,numFailedTests:0,numPendingTests:0,numTodoTests:0,numTotalTestSuites:1,numPassedTestSuites:1,numFailedTestSuites:0,numPendingTestSuites:0,testResults:[{name:'tests/a.test.js',status:'passed',assertionResults:[{ancestorTitles:['synthetic'],title:'case',status:'passed'}]}]});
check('contract-immutable-tests-and-approved-coverage','ACCEPT',()=>{const c=validateContract(runtime),b=json(path.join(runtime,contract.baselineInventory.path));assert.equal(b.tests.length,371);assert.equal(b.newTests.length,40);return {contract:c,baseline:b.tests.length,newTests:b.newTests.length,coverage:approvedCoverageInventory(runtime).length};});
check('native-test-positive','ACCEPT',()=>testReport(positive(),['tests/a.test.js']).length);
for(const k of ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests','numTotalTestSuites','numPassedTestSuites','numFailedTestSuites','numPendingTestSuites']){
 for(const bad of [-1,'0',null,0.5])check('counter-'+k+'-'+JSON.stringify(bad),'REJECT',()=>{const r=positive();r[k]=bad;return testReport(r,['tests/a.test.js']).length;});
}
for(const [id,mut] of [
 ['empty-test-suite',r=>r.testResults[0].assertionResults=[]],
 ['missing-test-suite-array',r=>delete r.testResults],
 ['suite-status-failed',r=>r.testResults[0].status='failed'],
 ['unknown-source',r=>r.testResults[0].name='tests/unknown.test.js'],
 ['assertion-skipped',r=>r.testResults[0].assertionResults[0].status='skipped'],
 ['title-wrong-type',r=>r.testResults[0].assertionResults[0].title=3],
 ['unknown-schema',r=>r.schemaVersion=999],
 ['unknown-contract',r=>r.contract='unknown'],
 ['contradictory-passed-suites',r=>r.numPassedTestSuites=200],
 ['native-unknown-field',r=>r.unrecognizedControl='synthetic'],
 ['suite-total-inflated',r=>{r.numTotalTestSuites=200;r.numPassedTestSuites=200;}],
 ['missing-suite-counters',r=>{delete r.numTotalTestSuites;delete r.numPassedTestSuites;delete r.numPendingTestSuites;}]
])check(id,'REJECT',()=>{const r=positive();mut(r);return testReport(r,['tests/a.test.js']).length;});
// A known file list is not treated as a required membership list by testReport.
check('missing-known-suite-membership','REJECT',()=>testReport(positive(),['tests/a.test.js','tests/b.test.js']).length);
check('duplicate-file-suite-membership','REJECT',()=>{const r=positive();r.testResults.push(clone(r.testResults[0]));r.numTotalTests=2;r.numPassedTests=2;r.numTotalTestSuites=2;r.numPassedTestSuites=2;return testReport(r,['tests/a.test.js']).length;});
for(const gateId of ['postgres','chaos'])check('snapshot-'+gateId+'-partial-required-membership','REJECT',()=>{
 const dir=path.join(fixtureRoot,gateId);const p='gate-outputs/'+gateId+'/report.json';write(dir,p,positive());return verifySnapshots({gate:{id:gateId,skipPolicy:'none'},entry:{outputs:[{path:p}]},directory:dir,manifest:{runId:'synthetic',candidateId:'a'.repeat(64),testInventory:[{file:'tests/a.test.js'},{file:'tests/b.test.js'}]},expected:{}});
});
const metrics=['statements','branches','functions','lines'];
const cov=(n=1)=>Object.fromEntries(metrics.map(k=>[k,{total:n,covered:n,skipped:0,pct:n?100:100}]));
check('weighted-coverage-positive','ACCEPT',()=>aggregateCoverage([{'packages/a.ts':cov()}],['packages/a.ts'],[{path:'packages/a.ts',sha256:'a'.repeat(64),executable:true}]));
for(const metric of metrics)check('global-zero-'+metric,'REJECT',()=>{const v=cov();v[metric]=cov(0)[metric];return aggregateCoverage([{'packages/a.ts':v}],['packages/a.ts']);});
check('executable-zero-coverage','REJECT',()=>aggregateCoverage([{'packages/a.ts':cov(),'packages/b.ts':cov(0)}],['packages/a.ts','packages/b.ts'],[{path:'packages/a.ts',sha256:'a'.repeat(64),executable:true},{path:'packages/b.ts',sha256:'b'.repeat(64),executable:true}]));
check('type-only-zero-coverage','ACCEPT',()=>aggregateCoverage([{'packages/a.ts':cov(),'packages/b.ts':cov(0)}],['packages/a.ts','packages/b.ts'],[{path:'packages/a.ts',sha256:'a'.repeat(64),executable:true},{path:'packages/b.ts',sha256:'b'.repeat(64),executable:false}]).pass);
check('coverage-contradictory-total','REJECT',()=>coverageReport({total:cov(2),'packages/a.ts':cov()},['packages/a.ts']));
check('coverage-unknown-source','REJECT',()=>coverageReport({total:cov(),'packages/b.ts':cov()},['packages/a.ts']));
check('coverage-fractional-denominator','REJECT',()=>aggregateCoverage([{'packages/a.ts':cov(0.5)}],['packages/a.ts']));
const load={schemaVersion:1,kind:'phase10-load-report',events:1,processed:1,loss:0,duplicates:0,workers:1,enqueueMs:1,drainMs:1,totalMs:2,throughputPerSecond:1,latencyMs:{p50:1,p95:1,p99:1,max:1}};
check('native-load-positive','ACCEPT',()=>{snapshotSchema(load,'load');});
check('load-negative-events','REJECT',()=>{snapshotSchema({...load,events:-1},'load');});
check('load-wrong-version','REJECT',()=>{snapshotSchema({...load,schemaVersion:999},'load');});
check('load-unknown-field','REJECT',()=>{snapshotSchema({...load,unexpectedField:'synthetic'},'load');});
const critical={schemaVersion:1,kind:'aud20-coverage-report',verdict:'PASS',failures:[],global:{pass:true,failures:[],thresholds:{statements:90,branches:85,functions:90,lines:90},metrics:Object.fromEntries(metrics.map(k=>[k,{total:1,covered:1,pct:100}]))},critical:{pass:true,failures:[],threshold:95,groups:[{name:'synthetic',pass:true}]}};
check('critical-zero-denominator-and-empty-group','REJECT',()=>{const r=clone(critical);r.global.metrics=Object.fromEntries(metrics.map(k=>[k,{total:0,covered:0,pct:100}]));r.critical.groups=[{}];snapshotSchema(r,'coverage-critical');write(fixtureRoot,'accepted-critical-zero.json',r);});
check('critical-false-percentages','REJECT',()=>{const r=clone(critical);r.global.metrics=Object.fromEntries(metrics.map(k=>[k,{total:10,covered:0,pct:100}]));snapshotSchema(r,'coverage-critical');write(fixtureRoot,'accepted-critical-percent.json',r);});
check('evals-pass-with-failures','REJECT',()=>{const r={suiteId:'synthetic',agentId:'synthetic',startedAt:'2026-10-04T00:00:00Z',finishedAt:'2026-10-04T00:00:01Z',verdict:'PASS',metrics:{score:0},thresholds:{score:1},failures:[{reason:'synthetic-failure'}]};snapshotSchema(r,'evals');write(fixtureRoot,'accepted-evals.json',r);});
check('strict-inventory-malformed-mapping','REJECT',()=>{snapshotSchema({schemaVersion:1,declarations:[{}],mapping:[{}]},'inventory');});
// Hidden input checks execute only a benign module with a constant export.
const hidden=path.join(fixtureRoot,'hidden');write(hidden,'package.json',{type:'module'});
for(const rel of ['.gauntlet/helper.mjs','.gauntlet/dist/helper.mjs','.gauntlet/node_modules/helper.mjs','certification/helper.mjs','certification/extra/input.json','certification/logs/active/helper.mjs','packages/synthetic/src/dist/helper.mjs','packages/synthetic/src/.gauntlet/dist/helper.mjs']){
 const isJson=rel.endsWith('.json');write(hidden,rel,isJson?{marker:1}:'export const marker=1;\n');
 const before=digest(sourceFiles(hidden));const tracked=sourceFiles(hidden).some(f=>f.path===rel);
 if(!isJson){write(hidden,'entry.mjs',`import {marker} from './${rel}';console.log(marker);\n`);}
 const first=!isJson?spawnSync(process.execPath,[path.join(hidden,'entry.mjs')],{cwd:hidden,env:process.env,encoding:'utf8'}):null;
 const hash1=digest(sourceFiles(hidden));write(hidden,rel,isJson?{marker:2}:'export const marker=2;\n');const hash2=digest(sourceFiles(hidden));
 const second=!isJson?spawnSync(process.execPath,[path.join(hidden,'entry.mjs')],{cwd:hidden,env:process.env,encoding:'utf8'}):null;
 observations.push({id:'hidden-input-'+rel,expected:'ACCEPT',actual:tracked&&hash1!==hash2?'ACCEPT':'REJECT',matched:tracked&&hash1!==hash2,tracked,hashChanged:hash1!==hash2,first:first&&{exit:first.status,stdout:first.stdout.trim()},second:second&&{exit:second.status,stdout:second.stdout.trim()}});
}
// Exact historical machine fixtures are read and validated, without narrative reports.
const authority=json(path.join(out,'..','authority.json'));
check('exact-seven-historical-machine-fixtures','ACCEPT',()=>{const result=authority.legacyMachineFixtures.map(p=>({path:p,sha256:sha(fs.readFileSync(path.join(runtime,p)))}));assert.equal(result.length,7);return result;});
check('historical-e2e-json-xml-log-positive','ACCEPT',()=>{const prefix='docs/04_audit/evidence/PR009-20260927-r2/';const proof=json(path.join(runtime,prefix+'proof.json'));const pair=validateE2eReportPair({jsonContent:fs.readFileSync(path.join(runtime,prefix+'e2e-test-report.json')),xmlContent:fs.readFileSync(path.join(runtime,prefix+'playwright-results.xml')),expectedRunId:proof.runId,expectedCandidateId:proof.candidateId});const log=parseE2eEvidenceLog({logContent:gunzipSync(fs.readFileSync(path.join(runtime,prefix+'e2e.log.gz'))),expectedRunId:proof.runId,expectedCandidateId:proof.candidateId,expectedTestCount:pair.testCount});assert.equal(pair.executionId,log.executionId);return {tests:pair.testCount,executionId:pair.executionId};});
check('historical-e2e-malformed-counter','REJECT',()=>{const prefix='docs/04_audit/evidence/PR009-20260927-r2/';const proof=json(path.join(runtime,prefix+'proof.json')),r=json(path.join(runtime,prefix+'e2e-test-report.json'));r.stats.expected=-1;return validateE2eReportPair({jsonContent:JSON.stringify(r),xmlContent:fs.readFileSync(path.join(runtime,prefix+'playwright-results.xml')),expectedRunId:proof.runId,expectedCandidateId:proof.candidateId});});
// The actual bounded runner artifact is consumed instead of its verdict.
check('actual-runScope-inventory-emitter-schema-parity','ACCEPT',()=>{const p=path.join(out,'inventory-run/artifacts/gate-outputs/inventory/inventory.json');const r=json(p);write(fixtureRoot,'actual-inventory-shape.json',{keys:Object.keys(r),path:p,sha256:sha(fs.readFileSync(p))});snapshotSchema(r,'inventory',p);return Object.keys(r);});
// Create real consumer-free variant from the runtime copy and inspect lock projection.
for(const scope of ['harness-neutral','consumer-contract'])check('physical-neutral-'+scope,'ACCEPT',()=>{const target=path.join(out,scope),v=prepareVariant(runtime,target,scope);assert(!fs.existsSync(path.join(target,'products')));const lock=json(path.join(target,'package-lock.json')),before=json(path.join(runtime,'package-lock.json'));assert(!Object.keys(lock.packages).some(p=>p.startsWith('products/')||lock.packages[p].resolved?.startsWith('products/')));for(const [p,e]of Object.entries(lock.packages))if(p.startsWith('node_modules/')&&!e.link)assert.deepEqual(e,before.packages[p]);write(out,scope+'-variant.json',v);return {files:v.files.length,removed:v.removed.length,lockSha256:v.lockAfter,unchangedThirdParty:Object.entries(lock.packages).filter(([p,e])=>p.startsWith('node_modules/')&&!e.link).length};});
// Independent emit oracle, no execution of fixture TypeScript.
const coverageRoot=path.join(fixtureRoot,'coverage-source');write(coverageRoot,'package.json',{name:'synthetic'});
fs.cpSync(path.join(runtime,'node_modules/typescript'),path.join(fixtureRoot,'node_modules/typescript'),{recursive:true});
for(const p of ['vitest.config.mts',contract.baselineInventory.path])write(coverageRoot,p,fs.readFileSync(path.join(runtime,p)));
const coveragePaths=approvedCoverageInventory(runtime);for(const p of coveragePaths)write(coverageRoot,p,'export interface Synthetic {}\n');
const ts=createRequire(path.join(coverageRoot,'package.json'))('typescript');
const syntax=[
 'export interface I {}','export type T=string;','interface I {}','declare const a:number;','export declare const a:number;','export function overload(x:string):void;','export function fn(){return 1}',
 'namespace N {export interface I {}}','namespace N {export const n=1}','export namespace N {export const n=1}',
 'import value = require("./other");export = value;','import "./side-effect";export {};','export default 1;','export const enum E {a=1}','export class C {value=1}',
 'export {};using value=null;','export {};await using value=null;','export default interface I {}','export {type T} from "./other";','export declare namespace N {const a:number}',
 'export const value = (<number>1);','export const broken = ;', 'export abstract class C {}','export type T={value:number};',
 'export {}; declare global {interface I {}}','export {}; enum E {}'
];
const selected=coveragePaths.filter(p=>p.endsWith('.ts')).slice(0,syntax.length);selected.forEach((p,i)=>write(coverageRoot,p,syntax[i]));
const inventory=coverageSourceInventory(coverageRoot),oracleRows=[];
selected.forEach((p,i)=>{let expected,error;try{const emitted=ts.transpileModule(syntax[i],{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext},fileName:p}).outputText;const ast=ts.createSourceFile(p,emitted,ts.ScriptTarget.Latest,true);expected=ast.statements.some(s=>!ts.isExportDeclaration(s)&&!ts.isImportDeclaration(s)&&!ts.isEmptyStatement(s));}catch(e){error=e.message;}const actual=inventory.find(s=>s.path===p);oracleRows.push({path:p,syntax:syntax[i],expected,actual:actual.executable,shaMatches:actual.sha256===sha(syntax[i]),error});});
write(out,'typescript-emit-parity.json',oracleRows);
check('typescript-emit-fallback-parity','ACCEPT',()=>{assert(oracleRows.every(r=>r.expected===r.actual&&r.shaMatches));return {fixtures:oracleRows.length,sources:inventory.length};});
check('fresh-byte-cache-scope-same-size-same-mtime','ACCEPT',()=>{const p=coveragePaths[0],a='export type Value=string;'.padEnd(80),b='export const Value=1;'.padEnd(80);write(coverageRoot,p,a);fs.utimesSync(path.join(coverageRoot,p),1700000000,1700000000);const frozen=Object.freeze(sourceFiles(coverageRoot).map(Object.freeze)),first=coverageSourceInventory(coverageRoot,frozen).find(s=>s.path===p);write(coverageRoot,p,b);fs.utimesSync(path.join(coverageRoot,p),1700000000,1700000000);const next=coverageSourceInventory(coverageRoot,frozen).find(s=>s.path===p);assert.equal(first.sha256,sha(a));assert.equal(first.executable,false);assert.equal(next.sha256,sha(b));assert.equal(next.executable,true);return {first,next};});
fs.writeFileSync(path.join(out,'own-checks.json'),JSON.stringify({total:observations.length,matched:observations.filter(r=>r.matched).length,unexpected:observations.filter(r=>!r.matched),observations},null,2)+'\n');
