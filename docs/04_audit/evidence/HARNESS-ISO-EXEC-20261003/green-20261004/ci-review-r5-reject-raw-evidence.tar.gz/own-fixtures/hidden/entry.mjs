import {marker} from './packages/synthetic/src/.gauntlet/dist/helper.mjs';console.log(marker);
