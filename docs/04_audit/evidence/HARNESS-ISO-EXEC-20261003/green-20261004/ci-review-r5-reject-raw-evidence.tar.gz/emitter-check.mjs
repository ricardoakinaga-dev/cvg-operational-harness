import fs from 'node:fs';import path from 'node:path';import child from 'node:child_process';import {syncBuiltinESMExports} from 'node:module';
import {contract} from './runtime/scripts/hiso-contract.mjs';import {runScope} from './runtime/scripts/hiso-ci.mjs';import {snapshotSchema} from './runtime/scripts/hiso-reports.mjs';
const out=path.dirname(new URL(import.meta.url).pathname),source=path.join(out,'runtime'),output=path.join(out,'retained-inventory-run');
const original=child.spawnSync;let discoveryReplays=0;
const fresh=fs.readFileSync(path.join(out,'inventory-run/artifacts/vitest-discovery.json'));
// Replay this review's actual fresh COLLECTION bytes to avoid another broad collection.
// Only discovery is replaced; actual runScope inventory emitter is exercised unchanged.
child.spawnSync=(bin,args,opts)=>{if(args?.[0]===path.join(source,'scripts/hiso-collect-tests.mjs')){discoveryReplays++;fs.writeFileSync(args[1],fresh);return {status:0,signal:null,stdout:'SYNTHETIC_LOCAL_REPLAY_OF_FRESH_COLLECTION_ONLY\n',stderr:''};}return original(bin,args,opts);};syncBuiltinESMExports();
contract.scopes.find(s=>s.id==='shift-product').gates=contract.scopes.find(s=>s.id==='shift-product').gates.filter(g=>g.id==='inventory');
let m;try{m=runScope({source,output,scope:'shift-product',runId:'synthetic-r5-inventory-emitter'});}finally{child.spawnSync=original;syncBuiltinESMExports();}
const p=path.join(output,'artifacts/gate-outputs/inventory/inventory.json'),r=JSON.parse(fs.readFileSync(p));let error;try{snapshotSchema(r,'inventory',p);}catch(e){error=e.message;}
const result={driver:'Synthetic inventory-only retained scope; fresh locally collected bytes replayed to avoid expensive repeat. No install/build/remote gate.',discoveryReplays,runnerStatus:m.status,gateStatus:m.gates[0].status,snapshotPath:p,snapshotKeys:Object.keys(r),validatorError:error};fs.writeFileSync(path.join(out,'emitter-check.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));if(error!=='hiso:snapshot_types:inventory')process.exitCode=1;
