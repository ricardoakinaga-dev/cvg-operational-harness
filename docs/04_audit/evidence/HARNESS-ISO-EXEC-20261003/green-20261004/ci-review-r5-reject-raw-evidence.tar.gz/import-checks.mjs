import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {spawnSync} from 'node:child_process';
import {CI_BAR_GATES,CI_BAR_VERSION} from './runtime/scripts/ci-bar-contract.mjs';
import {createGateSeal,encodeGateSeal,gateStepId} from './runtime/scripts/ci-bar-provenance.mjs';
import {contract,contractHash,digest,sha,sourceFiles} from './runtime/scripts/hiso-contract.mjs';
import {caseOccurrences} from './runtime/scripts/hiso-inventory.mjs';
import {verifySnapshots,snapshotSchema} from './runtime/scripts/hiso-reports.mjs';
import {expectedShape} from './runtime/scripts/hiso-validation.mjs';
const out=path.dirname(new URL(import.meta.url).pathname),runtime=path.join(out,'runtime'),root=path.join(out,'import-fixture');fs.mkdirSync(root,{recursive:true});
const write=(p,v)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v));};
const candidateId=digest(sourceFiles(runtime)),runId='run-123-1',executionId='00000000-0000-4000-8000-000000000001';
const github={runId:'123',attempt:'1',sha:'a'.repeat(40),repository:'synthetic/repository',workflow:'Synthetic review only'};
const unit={success:true,numTotalTests:2,numPassedTests:2,numFailedTests:0,numPendingTests:0,numTodoTests:0,numTotalTestSuites:2,numPassedTestSuites:2,numFailedTestSuites:0,numPendingTestSuites:0,testResults:['tests/z.test.js','tests/a.test.js'].map(name=>({name:path.join(runtime,name),status:'passed',assertionResults:[{ancestorTitles:[],title:'synthetic case',status:'passed'}]}))};
const rows=caseOccurrences(unit.testResults.flatMap(f=>f.assertionResults.map(t=>({file:path.relative(runtime,f.name),name:t.title,status:t.status}))));
const expected={schemaVersion:1,contract:contract.contract,contractHash,candidateId,sourceSha256:candidateId,ownerMappingHash:'a'.repeat(64),runId,attempt:'1',testInventory:rows.map(({status,...r})=>r),scopes:{'transition-regression':{schemaVersion:1,contract:contract.contract,contractHash,scope:'transition-regression',candidateId,sourceSha256:candidateId,ownerMappingHash:'a'.repeat(64),derivedVariantId:candidateId,derivedMappingHash:'a'.repeat(64),runId,attempt:'1',testInventoryHash:digest(rows.map(({status,...r})=>r)),lockSha256:sha(fs.readFileSync(path.join(runtime,'package-lock.json')))}}};
const state={contract:CI_BAR_VERSION,runId,candidateId,nodeVersion:'22.23.2',gates:[]}, legacy={contract:CI_BAR_VERSION,candidateId,runId,npmVersion:'synthetic',startedAt:'2026-10-04T00:00:00Z',verdict:'PASS',provenance:{mode:'GITHUB_STEP_OUTPUT_SEALED'},gates:[]};
const orig=path.join(root,'original');write(path.join(orig,'runtime.txt'),'synthetic Node22 runtime\n');
for(const gate of CI_BAR_GATES){
 const log='synthetic fixture '+gate.id+'\n';const g={id:gate.id,command:gate.command,status:'PASS',exitCode:0,runId,candidateId,nodeVersion:state.nodeVersion,outputFailures:[],log:'gates/'+gate.id+'.log',logSha256:sha(log)};
 write(path.join(orig,g.log),log);g.artifactSha256={};
 for(const p of gate.artifacts??[]){let value={schemaVersion:1,syntheticFixture:true};
  if(gate.id==='unit')value=unit;
  if(gate.id==='coverage')value={total:{},[path.join(runtime,'packages/a.ts')]:{}};
  if(gate.id==='e2e'&&p.endsWith('.xml'))value=`<testsuites id="${runId}" name="candidateId=${candidateId};executionId=${executionId}" tests="1" failures="0" skipped="0" errors="0"><testsuite name="synthetic" tests="1" failures="0" skipped="0" errors="0"><testcase classname="synthetic.test.ts" name="case" /></testsuite></testsuites>`;
  if(gate.id==='e2e'&&p.endsWith('.json'))value={config:{metadata:{cvgE2e:{runId,candidateId,executionId}}},suites:[{title:'synthetic.test.ts',file:'synthetic.test.ts',specs:[{title:'case',file:'synthetic.test.ts',ok:true,tests:[{expectedStatus:'passed',status:'expected',results:[{status:'passed',retry:0,errors:[]}]}]}]}],errors:[],stats:{startTime:'2026-10-04T00:00:00Z',duration:1,expected:1,skipped:0,unexpected:0,flaky:0}};
  const f=path.join(orig,'gate-outputs',gate.id,p);write(f,value);g.artifactSha256[p]=sha(fs.readFileSync(f));
 }
 if(gate.id==='e2e')Object.assign(g,{executionId,testCount:1,testInventorySha256:'a'.repeat(64)});
 if(gate.id!=='artifacts')state.gates.push(g);legacy.gates.push(g);
}
write(path.join(orig,'ci-bar-state.json'),state);write(path.join(orig,'ci-bar-manifest.json'),legacy);
const steps=Object.fromEntries(CI_BAR_GATES.filter(g=>g.id!=='artifacts').map(g=>[gateStepId(g.id),{outcome:'success',conclusion:'success',outputs:{seal:encodeGateSeal(createGateSeal({id:g.id,state,artifactDir:orig,github}))}}]));
const ef=path.join(root,'expected.json'),pg=path.join(root,'postgres-version.json');write(ef,expected);write(pg,{schemaVersion:1,status:'PASS',runId,candidateId,version:160001});
const env={...process.env,GITHUB_RUN_ID:github.runId,GITHUB_RUN_ATTEMPT:github.attempt,GITHUB_SHA:github.sha,GITHUB_REPOSITORY:github.repository,GITHUB_WORKFLOW:github.workflow,GITHUB_WORKFLOW_REF:'synthetic/workflow',GITHUB_JOB:'synthetic',CI_BAR_STEPS_JSON:JSON.stringify(steps),LEGACY_MANIFEST_SHA256:sha(fs.readFileSync(path.join(orig,'ci-bar-manifest.json'))),HISO_PG_VERSION_OUTPUT:pg,GITHUB_OUTPUT:path.join(root,'job-outputs.txt')};
const results=[];
function run(id){const dest=path.join(root,id);const command=[process.execPath,path.join(runtime,'scripts/hiso-import-legacy.mjs'),orig,ef,dest];const r=spawnSync(command[0],command.slice(1),{cwd:runtime,env,encoding:'utf8',timeout:60000,maxBuffer:16*1024*1024});write(path.join(root,id+'.log'),r.stdout+r.stderr);const m=JSON.parse(fs.readFileSync(path.join(dest,'manifest.json')));return {command,exitCode:r.status,manifestStatus:m.status,cause:m.cause,dest,m};}
const first=run('unsorted-native-unit');
let unitError;try{const gate=first.m.gates.find(g=>g.id==='unit');verifySnapshots({gate:{id:'unit',skipPolicy:'none'},entry:gate,directory:first.dest,manifest:first.m,expected:{}});}catch(e){unitError=e.message;}
results.push({id:'legacy-native-order',command:first.command,exitCode:first.exitCode,importStatus:first.manifestStatus,downstreamUnitError:unitError,emittedInventory:first.m.executedTestInventory,rawUnitSha256:sha(fs.readFileSync(path.join(first.dest,'gate-outputs/unit/certification/unit-test-report.json')))});
let shapeError;try{expectedShape(expected);}catch(e){shapeError=e.message;}
results.push({id:'legacy-import-expected-shape',importStatus:first.manifestStatus,expectedShapeError:shapeError,syntheticIncompleteExpected:true});
write(pg,{schemaVersion:1,status:'PASS',runId,candidateId,version:'160001'});const wrongPg=run('string-pg-version');results.push({id:'legacy-import-string-pg-version',command:wrongPg.command,exitCode:wrongPg.exitCode,importStatus:wrongPg.manifestStatus,emittedVersion:JSON.parse(fs.readFileSync(path.join(wrongPg.dest,'gate-outputs/postgres-version/postgres-version.json'))).version});
// Wrong explicit expected schema is rejected before normal import work.
write(ef,{...expected,schemaVersion:999});const bad=run('bad-expected-schema');results.push({id:'legacy-import-explicit-bad-schema',command:bad.command,exitCode:bad.exitCode,importStatus:bad.manifestStatus,cause:bad.cause,legacyCopiedInFailurePath:fs.existsSync(path.join(bad.dest,'legacy/ci-bar-state.json'))});
assert.equal(first.manifestStatus,'PASS');assert.equal(unitError,'hiso:unit_execution_inventory_snapshot');assert.equal(wrongPg.manifestStatus,'PASS');assert.equal(bad.exitCode,1);
write(path.join(out,'import-checks.json'),results);console.log(JSON.stringify(results,null,2));
