import os,json,hashlib,stat,sys
from pathlib import Path
p=Path(__file__).resolve().parent.parent; src=p/'source'; out=p/'output'
rows={}
for base,ds,fs in os.walk(src,followlinks=False):
 for name in ['.']+ds+fs:
  f=Path(base) if name=='.' else Path(base)/name; rel=str(f.relative_to(src)); s=f.lstat()
  if rel in rows: continue
  r={'mode':s.st_mode,'dev':s.st_dev,'ino':s.st_ino,'mtime_ns':s.st_mtime_ns,'nlink':s.st_nlink}
  if stat.S_ISLNK(s.st_mode): r.update(kind='link',target=os.readlink(f))
  elif stat.S_ISREG(s.st_mode): r.update(kind='file',bytes=s.st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest())
  elif stat.S_ISDIR(s.st_mode): r.update(kind='directory')
  else: r.update(kind='special')
  rows[rel]=r
phase=sys.argv[1]; (out/f'integrity-{phase}.json').write_text(json.dumps(rows,sort_keys=True,indent=2))
inv=json.loads((p/'frozen-inventory.json').read_text()); bad=[]
for k,v in inv.items():
 r=rows.get(k,{})
 for prop,value in v.items():
  if r.get(prop)!=value: bad.append([k,prop,value,r.get(prop)])
extra=[k for k,v in rows.items() if v['kind']!='directory' and k not in inv]
print(json.dumps({'phase':phase,'entries':len(rows),'inventoryEntries':len(inv),'mismatch':bad,'extra':extra}))
if phase=='after':
 before=json.loads((out/'integrity-before.json').read_text()); changes=[k for k in set(before)|set(rows) if before.get(k)!=rows.get(k)]
 (out/'integrity-result.json').write_text(json.dumps({'changes':changes,'inventoryMismatch':bad,'extra':extra},indent=2)); print('before/after differences:',len(changes))
