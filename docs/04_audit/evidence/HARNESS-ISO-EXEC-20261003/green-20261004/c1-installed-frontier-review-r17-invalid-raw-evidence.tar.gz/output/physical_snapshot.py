from audit_io import *
import sys
root=OUT/'installed-capture';phase=sys.argv[1];metadata={};inventory={}
def walk(p,rel):
 s=os.lstat(p);metadata[rel]={'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'atime_ns':s.st_atime_ns,'ino':s.st_ino,'dev':s.st_dev,'nlink':s.st_nlink}
 if stat.S_ISDIR(s.st_mode):
  fd=os.open(p,os.O_RDONLY|os.O_DIRECTORY|os.O_NOATIME)
  try:
   with os.scandir(fd) as it:names=sorted(e.name for e in it)
  finally:os.close(fd)
  for name in names:walk(p/name,(rel+'/' if rel else '')+name)
 elif stat.S_ISLNK(s.st_mode):inventory[rel]={'kind':'link','target':os.readlink(p)}
 elif stat.S_ISREG(s.st_mode):inventory[rel]={'kind':'file','sha256':hashlib.sha256(read(p)).hexdigest()}
 else:raise RuntimeError(str(p))
walk(root,'')
(OUT/('installed-'+phase+'-metadata.json')).write_text(json.dumps(metadata,sort_keys=True,indent=2));(OUT/('installed-'+phase+'-inventory.json')).write_text(json.dumps(inventory,sort_keys=True,indent=2))
if phase=='after':
 before=json.loads((OUT/'installed-before-metadata.json').read_text());inv=json.loads((OUT/'installed-before-inventory.json').read_text());diff=[{'path':k,'before':before.get(k),'after':metadata.get(k)} for k in sorted(set(before)|set(metadata)) if before.get(k)!=metadata.get(k)];result={'metadataEntries':len(metadata),'directories':sum(stat.S_ISDIR(v['mode']) for v in metadata.values()),'metadataDiff':diff,'inventoryMatch':inv==inventory};(OUT/'installed-readonly-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result)[:5000])
else:print(json.dumps({'entries':len(metadata)}))
