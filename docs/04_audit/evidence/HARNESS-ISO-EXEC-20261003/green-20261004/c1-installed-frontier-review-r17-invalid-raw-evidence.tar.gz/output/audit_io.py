import os,json,hashlib,stat
from pathlib import Path
PACK=Path('/home/ricardo/.cache/cvg-harness-green-20261004/c1-installed-frontier-review-r17'); SRC=PACK/'source'; OUT=PACK/'output'
def read(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOATIME|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb') as f:return f.read()
def scan():
 metadata={}; inventory={}
 def walk(p,rel):
  s=os.lstat(p);metadata[rel]={'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'atime_ns':s.st_atime_ns,'ino':s.st_ino,'dev':s.st_dev,'nlink':s.st_nlink}
  if stat.S_ISDIR(s.st_mode):
   fd=os.open(p,os.O_RDONLY|os.O_DIRECTORY|os.O_NOATIME)
   try:
    with os.scandir(fd) as it:names=sorted(e.name for e in it)
   finally:os.close(fd)
   for name in names:walk(p/name, (rel+'/' if rel else '')+name)
  elif stat.S_ISLNK(s.st_mode):inventory[rel]={'kind':'link','target':os.readlink(p)}
  elif stat.S_ISREG(s.st_mode):inventory[rel]={'kind':'file','bytes':s.st_size,'sha256':hashlib.sha256(read(p)).hexdigest()}
  else:raise RuntimeError(str(p))
 walk(SRC,'');return metadata,inventory
if __name__=='__main__':
 import sys
 phase=sys.argv[1];meta,inv=scan();frozen=json.loads(read(PACK/'frozen-inventory.json'))
 diff=[{'path':k,'expected':frozen.get(k),'actual':inv.get(k)} for k in sorted(set(frozen)|set(inv)) if frozen.get(k)!=inv.get(k)]
 result={'inventorySha256':hashlib.sha256(read(PACK/'frozen-inventory.json')).hexdigest(),'files':sum(x['kind']=='file' for x in inv.values()),'links':sum(x['kind']=='link' for x in inv.values()),'directories':sum(stat.S_ISDIR(x['mode']) for x in meta.values()),'inventoryDiff':diff}
 (OUT/(phase+'-metadata.json')).write_text(json.dumps(meta,sort_keys=True,indent=2))
 if phase=='after':
  before=json.loads((OUT/'before-metadata.json').read_text());result['metadataDiff']=[{'path':k,'before':before.get(k),'after':meta.get(k)} for k in sorted(set(before)|set(meta)) if before.get(k)!=meta.get(k)]
 (OUT/(phase+'-verification.json')).write_text(json.dumps(result,indent=2));print(json.dumps(result))
