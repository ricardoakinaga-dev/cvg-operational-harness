from audit_io import *
import shutil
runtime=OUT/'runtime';installed=OUT/'installed-capture';installed.mkdir(exist_ok=True)
shutil.copytree(runtime/'node_modules',installed/'node_modules',symlinks=True,copy_function=os.link,dirs_exist_ok=True)
inv=json.loads(read(PACK/'frozen-inventory.json'));bindings=[]
active=['apps','packages','legacy','products','scripts','examples','config']
allowed_ext={'.js','.mjs','.cjs','.jsx','.ts','.tsx','.mts','.cts','.json','.css','.node','.wasm'}
for rel,v in inv.items():
 if rel.startswith('node_modules/'):continue
 if v['kind']!='file':continue
 parts=Path(rel).parts
 if rel not in ['package.json','tsconfig.base.json','tsconfig.json','tsconfig.runtime.json','tsconfig.typecheck.json']:
  if parts[0] not in active or 'docs' in parts or '.agent' in parts or Path(rel).suffix not in allowed_ext:continue
 target=installed/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(read(SRC/rel));bindings.append({'source':rel,'output':str(target.relative_to(OUT)),'sha256':v['sha256']})
for rel,v in inv.items():
 if v['kind']=='link' and rel.startswith('node_modules/@cvg/'):
  dest=installed/rel;dest.parent.mkdir(parents=True,exist_ok=True);os.symlink(v['target'],dest)
# Actor/source locations with no selected file remain physical directories.
meta=json.loads((OUT/'before-metadata.json').read_text())
for rel,v in meta.items():
 if rel and stat.S_ISDIR(v['mode']) and rel.split('/')[0] in active and 'docs' not in Path(rel).parts and '.agent' not in Path(rel).parts:(installed/rel).mkdir(parents=True,exist_ok=True)
(OUT/'installed-copy-bindings.json').write_text(json.dumps(bindings,indent=2));print(json.dumps({'boundActiveCodeFiles':len(bindings),'runtime':str(installed),'excluded':'documentary bytes, root env, root tests including original executable fixtures; implementation never executed'}))
