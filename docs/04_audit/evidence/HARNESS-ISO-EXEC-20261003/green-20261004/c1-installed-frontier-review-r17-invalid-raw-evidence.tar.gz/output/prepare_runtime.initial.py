from audit_io import *
import shutil
runtime=OUT/'runtime';runtime.mkdir(exist_ok=True)
inv=json.loads(read(PACK/'frozen-inventory.json'));copied=[];links=[]
selected=['scripts/check-product-boundary.mjs','scripts/boundary-manifests.mjs','scripts/boundary-lexical.mjs','scripts/boundary-code-execution.mjs','scripts/tsconfig-path-grammar.mjs','tests/product-boundary-lexical-static.test.js']
for rel,v in inv.items():
 if rel not in selected and not rel.startswith('node_modules/'):continue
 if v['kind']=='link':links.append((rel,v['target']));continue
 if rel.startswith('node_modules/') and (Path(rel).suffix.lower() in ['.md','.txt','.html','.map'] or any(x in Path(rel).parts for x in ['docs','doc','.agent','history','logs'])):continue
 dest=runtime/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(read(SRC/rel));os.chmod(dest,os.lstat(SRC/rel).st_mode&0o777)
 copied.append({'source':rel,'sha256':v['sha256'],'output':str(dest.relative_to(OUT))})
for rel,target in links:
 if rel.startswith('node_modules/@cvg/'):continue
 dest=runtime/rel;dest.parent.mkdir(parents=True,exist_ok=True)
 if not (dest.parent/target).resolve().is_relative_to(runtime):raise RuntimeError(rel)
 os.symlink(target,dest)
(runtime/'package.json').write_text('{"private":true,"type":"module"}')
(OUT/'runtime-copy-bindings.json').write_text(json.dumps(copied,indent=2))
# Keep the supplied assertions intact, but retain fixtures/raw observations after teardown.
f=runtime/'tests/product-boundary-lexical-static.test.js';text=f.read_text();text=text.replace('afterAll(() => fs.rmSync(output, { recursive: true, force: true }))','afterAll(() => fs.writeFileSync(path.join(output, "retained.json"), JSON.stringify({observations,r17Observations}, null, 2)))')
f.write_text(text)
(runtime/'vitest.config.mjs').write_text('import {defineConfig} from "vitest/config";export default defineConfig({test:{environment:"node",include:["tests/product-boundary-lexical-static.test.js"],pool:"threads",maxWorkers:1,fileParallelism:false,testTimeout:30000},cacheDir:"./.vite"});\n')
print(json.dumps({'copied':len(copied),'runtime':str(runtime),'testAdaptation':'retain teardown artifacts only; assertions untouched'}))
