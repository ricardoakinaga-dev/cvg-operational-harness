from audit_io import *
cases=[]
fields=['dependencies','devDependencies','optionalDependencies','peerDependencies']
for field in fields:
 for protocol in ['file','link','registry','alias']:
  kinds=['product','unknown','invalid','absent','same'] if protocol in ['file','link'] else ['product','missing','nested-product','jsonless-missing','nearest-fallback','nearest-shadow']
  for kind in kinds:
   ident=field+'-'+protocol+'-'+kind
   files={'package.json':{'type':'module','workspaces':['packages/*','products/*']},'packages/core/package.json':{'name':'@i/core','type':'module',field:{'next':protocol+':../neutral' if protocol in ['file','link'] else 'npm:@i/neutral@1.0.0' if protocol=='alias' else '1.0.0'}},'packages/core/src/index.mts':'export const label="inert";','packages/neutral/package.json':{'name':'@i/neutral','type':'module'},'packages/neutral/src/index.mts':'export const label="neutral";','products/consumer/package.json':{'name':'@i/consumer','type':'module'},'products/consumer/src/index.mts':'export const label="product";'}
   links=[];expected='PASS' if kind in ['absent','same'] else 'REFUSE' if kind=='invalid' else 'FAIL' if kind in ['product','nested-product','nearest-fallback'] else 'INCOMPLETE'
   if kind=='same':links=[['node_modules/next','../packages/neutral']]
   elif kind!='absent':
    pkg={'name':'published-next','type':'module'}
    if kind=='product':pkg[field]={'@i/consumer':'1.0.0'}
    if kind=='missing':pkg[field]={'build':'file:absent'}
    files['node_modules/next/package.json']=[] if kind=='invalid' else pkg
    files['node_modules/next/index.mjs']='export const label="physical-inert";'
    if kind=='nested-product':files['node_modules/next/dist/nested/package.json']={field:{'@i/consumer':'1.0.0'}}
    if kind=='jsonless-missing':
     del files['node_modules/next/package.json'];files['node_modules/next/dist/nested/package.json']={field:{'build':'file:missing'}}
    if kind.startswith('nearest-'):
     files['node_modules/next/package.json'][field]={'@i/consumer':'1.0.0'}
     files['packages/core/node_modules/next/package.json']={'name':'nearest','type':'module'}
     if kind=='nearest-shadow':files['packages/core/node_modules/next/index.mjs']='export const label="nearest";'
   cases.append({'id':ident,'field':field,'kind':kind,'protocol':protocol,'expected':expected,'nativeKey':'next','files':files,'links':links})
 for kind in ['source-jsonless-product','source-jsonless-invalid','source-jsonless-missing','source-jsonless-neutral','local-symlink-valid','local-symlink-missing','opaque-root-archive','effective-source-archive']:
  files={'package.json':{'type':'module','workspaces':['packages/*','products/*']},'packages/core/package.json':{'name':'@i/core','type':'module'},'packages/core/src/index.mts':'export const label="inert";','products/consumer/package.json':{'name':'@i/consumer','type':'module'},'products/consumer/src/index.mts':'export const label="product";'};links=[];nativeKey=None
  expected='PASS'
  if kind.startswith('source-jsonless-'):
   files['packages/core/src/index.mts']='import "../../../node_modules/next/index.mjs";';files['node_modules/next/index.mjs']='export const label="inert-source";'
   expected='FAIL' if kind.endswith('product') else 'REFUSE' if kind.endswith('invalid') else 'INCOMPLETE' if kind.endswith('missing') else 'PASS'
   if not kind.endswith('neutral'):files['node_modules/next/dist/package.json']=[] if kind.endswith('invalid') else {field:{'@i/consumer':'1.0.0'}} if kind.endswith('product') else {field:{'build':'file:absent'}}
  elif kind.startswith('local-symlink-'):
   expected='REFUSE';files['packages/core/package.json'][field]={'local':'file:../../auxiliary/link'};links=[['auxiliary/link','target']]
   files['auxiliary/target/package.json']={'name':'local'}
   if kind.endswith('missing'):files['auxiliary/target/package.json'][field]={'absent':'file:missing'}
  elif kind=='opaque-root-archive':
   files['packages/core/src/index.mts']='import "../../../anchor.mjs";';files['anchor.mjs']='export const label="root";';files['docs/archive/package.json']=[]
  elif kind=='effective-source-archive':
   expected='FAIL';files['packages/core/src/index.mts']='import "../../../docs/archive/index.mjs";';files['docs/archive/index.mjs']='export const label="inert-source";';files['docs/archive/package.json']={field:{'@i/consumer':'1.0.0'}}
  cases.append({'id':field+'-'+kind,'field':field,'kind':kind,'expected':expected,'nativeKey':nativeKey,'files':files,'links':links})
(OUT/'probes.json').write_text(json.dumps(cases,indent=2))
print({'probeCases':len(cases),'fields':fields})
