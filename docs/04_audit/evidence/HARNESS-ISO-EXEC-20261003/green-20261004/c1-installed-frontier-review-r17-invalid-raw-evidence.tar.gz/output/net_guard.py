import ctypes,os,sys,json,socket,errno
from pathlib import Path
BASE=Path(__file__).resolve().parent
lib=ctypes.CDLL('libseccomp.so.2',use_errno=True)
lib.seccomp_init.argtypes=[ctypes.c_uint32];lib.seccomp_init.restype=ctypes.c_void_p
lib.seccomp_syscall_resolve_name.argtypes=[ctypes.c_char_p];lib.seccomp_syscall_resolve_name.restype=ctypes.c_int
lib.seccomp_rule_add_array.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_int,ctypes.c_uint,ctypes.c_void_p]
lib.seccomp_load.argtypes=[ctypes.c_void_p]
class Cmp(ctypes.Structure):_fields_=[('arg',ctypes.c_uint),('op',ctypes.c_uint),('datum_a',ctypes.c_uint64),('datum_b',ctypes.c_uint64)]
ctx=lib.seccomp_init(0x7fff0000);deny=0x50000|errno.EPERM
for name in ['socket','socketpair']:
 cmp=Cmp(0,1,socket.AF_UNIX,0) # SCMP_CMP_NE
 assert lib.seccomp_rule_add_array(ctx,deny,lib.seccomp_syscall_resolve_name(name.encode()),1,ctypes.byref(cmp))==0
for name in ['io_uring_setup','io_uring_enter','io_uring_register']:
 number=lib.seccomp_syscall_resolve_name(name.encode())
 if number>=0:assert lib.seccomp_rule_add_array(ctx,deny,number,0,None)==0
assert lib.seccomp_load(ctx)==0
if sys.argv[1]=='--selftest':
 rows=[]
 for label,family,kind in [('network-ipv4',socket.AF_INET,socket.SOCK_STREAM),('network-ipv6',socket.AF_INET6,socket.SOCK_STREAM),('dns-udp',socket.AF_INET,socket.SOCK_DGRAM),('postgres-tcp',socket.AF_INET,socket.SOCK_STREAM),('provider-https',socket.AF_INET,socket.SOCK_STREAM)]:
  try:s=socket.socket(family,kind);s.close();rows.append({'case':label,'blocked':False})
  except OSError as e:rows.append({'case':label,'blocked':e.errno==errno.EPERM,'errno':e.errno})
 try:
  value=socket.getaddrinfo('guard-selftest.invalid',443);dns={'case':'actual-getaddrinfo','blocked':False,'result':str(value)}
 except socket.gaierror as e:dns={'case':'actual-getaddrinfo','blocked':True,'errno':e.errno}
 rows.append(dns)
 left,right=socket.socketpair();left.send(b'allowed-unix');payload=right.recv(100);left.close();right.close();rows.append({'case':'unix-ipc','allowed':payload==b'allowed-unix'})
 (BASE/'guard-selftests.json').write_text(json.dumps({'rows':rows,'passed':all(r.get('blocked',r.get('allowed')) for r in rows),'actualExternalCalls':0},indent=2));print(json.dumps(rows));sys.exit(0 if all(r.get('blocked',r.get('allowed')) for r in rows) else 1)
os.execv(sys.argv[1],sys.argv[1:])
