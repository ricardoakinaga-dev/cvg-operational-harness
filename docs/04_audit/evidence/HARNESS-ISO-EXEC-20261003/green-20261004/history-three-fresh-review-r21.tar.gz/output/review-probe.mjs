import { readFileSync, writeFileSync } from 'node:fs';
import { createHash, createHmac, timingSafeEqual } from 'node:crypto';
import { createRequire, stripTypeScriptTypes } from 'node:module';
import assert from 'node:assert/strict';

// Reviewer-owned inert probe: historical bytes are parsed and hashed, never imported.
// No eval, VM, subprocess, network, test runner, runtime app or historical function call.
assert.equal(process.versions.node.split('.')[0], '22');
const output = new URL('./', import.meta.url);
const packet = new URL('../../history-three-provenance-r21/', import.meta.url);
const require = createRequire(import.meta.url);
const acorn = require('internal/deps/acorn/acorn/dist/acorn');
const sha = value => createHash('sha256').update(value).digest('hex');
const read = name => readFileSync(new URL(name, output));
const save = (name, value) => writeFileSync(new URL(name, output), JSON.stringify(value, null, 2) + '\n');
const raw = JSON.parse(readFileSync(new URL('raw-observations.json', packet), 'utf8'));
assert.deepEqual(raw.map(r => r.identity), ['F006214', 'F006219', 'F006444']);
const copies = { F006214: 'git-F006214.md', F006219: 'git-F006219.ts', F006444: 'git-F006444.ts' };
const integrity = raw.map(r => {
  assert.equal(r.startLine, r.endLine);
  const bytes = readFileSync(new URL(r.sourceBlob, packet));
  const historical = read(copies[r.identity]);
  assert(bytes.equals(historical), `${r.identity}: packet != git show`);
  assert.equal(sha(bytes), r.blobSha256);
  const lines = bytes.toString('utf8').split('\n');
  const line = lines[r.startLine - 1];
  assert.equal(sha(line + '\n'), r.lineSha256, `${r.identity}: LF line hash`);
  // Finite exhaustive substring matching on this one raw line only.
  const lineBytes = Buffer.from(line);
  const matches = [];
  for (let start = 0; start < lineBytes.length; start++) {
    for (let end = start + 1; end <= lineBytes.length; end++) {
      if (sha(lineBytes.subarray(start, end)) === r.candidateSha256) matches.push({ start, end });
    }
  }
  assert.equal(matches.length, 1, `${r.identity}: candidate must occur uniquely in stated line`);
  const { start, end } = matches[0];
  assert(start >= r.startColumn - 1 && end <= r.endColumn, 'candidate inside reported wider span');
  return {
    identity: r.identity, commit: r.commit, path: r.file,
    packetBlob: r.sourceBlob, gitCopy: copies[r.identity],
    blobSha256: sha(bytes), gitCopySha256: sha(historical), bytes: bytes.length,
    line: r.startLine, lineHashConvention: 'UTF-8 complete line including LF', lineSha256: sha(line + '\n'),
    rawColumns: { start: r.startColumn, end: r.endColumn },
    candidateOffsets: { unit: 'UTF-8 byte, zero-based, end-exclusive, within stated line', start, end },
    candidateSha256: r.candidateSha256, uniqueCandidateOccurrencesInLine: matches.length,
    exactGitBytesMatch: true, hashesMatch: true,
    note: 'Raw reported columns cover a wider match; they are not asserted to be candidate-literal offsets.'
  };
});
save('integrity.json', { node: process.version, recordCount: 3, records: integrity });

function visit(node, callback, ancestors = []) {
  if (!node || typeof node !== 'object' || !node.type) return;
  callback(node, ancestors);
  for (const [key, value] of Object.entries(node)) {
    if (['loc', 'start', 'end', 'type'].includes(key)) continue;
    if (Array.isArray(value)) value.forEach(child => visit(child, callback, [...ancestors, node]));
    else if (value && typeof value === 'object' && value.type) visit(value, callback, [...ancestors, node]);
  }
}
function select(node, predicate) {
  const result = [];
  visit(node, (item, parents) => { if (predicate(item)) result.push({ node: item, parents }); });
  return result;
}
function parse(name) {
  const original = read(name).toString('utf8');
  const stripped = stripTypeScriptTypes(original, { mode: 'strip' });
  assert.equal(stripped.split('\n').length, original.split('\n').length);
  return acorn.parse(stripped, { ecmaVersion: 'latest', sourceType: 'module', locations: true });
}
const identifier = (node, name) => node?.type === 'Identifier' && node.name === name;
const propertyName = node => node?.type === 'Identifier' ? node.name : node?.value;
const property = (object, name) => object?.properties?.find(p => p.type === 'Property' && propertyName(p.key) === name)?.value;
const calls = (node, name) => select(node, n => n.type === 'CallExpression' && identifier(n.callee, name));
const mentions = (node, name) => select(node, n => identifier(n, name)).length > 0;
const span = node => ({ startLine: node.loc.start.line, endLine: node.loc.end.line });
const calleeName = node => node?.type === 'Identifier' ? node.name : node?.type === 'MemberExpression' ? `${calleeName(node.object)}.${propertyName(node.property)}` : node?.type === 'CallExpression' ? `${calleeName(node.callee)}()` : node?.type;
function binding(tree, name) {
  const result = select(tree, n => n.type === 'VariableDeclarator' && identifier(n.id, name));
  assert.equal(result.length, 1, `unambiguous binding ${name}`);
  return result[0];
}
const astResults = [];
const secrets = {};
for (const [identity, file, implFile, target, current, testName] of [
  ['F006219', 'git-F006219.ts', 'operator-identity-c791ee47.ts', 'previousSecret', 'currentSecret', 'supports bounded key rotation and rejects missing or inactive key ids'],
  ['F006444', 'git-F006444.ts', 'operator-identity-c57c330f.ts', 'PREVIOUS', 'ACTIVE', 'accepts current and previous keys inside the bounded rotation window']
]) {
  const tree = parse(file);
  const targetBinding = binding(tree, target);
  const declaration = targetBinding.parents.findLast(n => n.type === 'VariableDeclaration');
  assert.equal(declaration.kind, 'const');
  const literal = identity === 'F006219' ? targetBinding.node.init : property(targetBinding.node.init, 'secret');
  const currentBinding = binding(tree, current).node;
  const currentLiteral = identity === 'F006219' ? currentBinding.init : property(currentBinding.init, 'secret');
  assert.equal(literal.type, 'Literal');
  assert.equal(typeof literal.value, 'string');
  assert.equal(currentLiteral.type, 'Literal');
  const observation = raw.find(r => r.identity === identity);
  assert.equal(sha(literal.value), observation.candidateSha256);
  assert.equal(literal.loc.start.line, observation.startLine);
  assert(literal.value.length >= 32);
  // Exact immutable construction, not an environment/service-derived initializer.
  if (identity === 'F006444') {
    assert.equal(targetBinding.node.init.type, 'ObjectExpression');
    assert(targetBinding.node.init.properties.every(p => p.type === 'Property' && p.value.type === 'Literal'));
  }
  const exports = select(tree, n => n.type.startsWith('Export'));
  assert.equal(exports.length, 0);
  const imports = tree.body.filter(n => n.type === 'ImportDeclaration').map(n => n.source.value);
  assert.deepEqual([...imports].sort(), ['../operator-identity.ts', 'node:crypto', 'vitest'].sort());
  const forbiddenIdentifiers = select(tree, n => n.type === 'Identifier' && ['process', 'fetch', 'eval', 'Function', 'require'].includes(n.name));
  assert.equal(forbiddenIdentifiers.length, 0);
  const writes = select(tree, n => (n.type === 'AssignmentExpression' && mentions(n.left, target)) || (n.type === 'UpdateExpression' && mentions(n.argument, target)));
  assert.equal(writes.length, 0);
  const selectedTests = calls(tree, 'it').filter(c => c.node.arguments[0]?.value === testName);
  assert.equal(selectedTests.length, 1);
  const test = selectedTests[0].node;
  const callback = test.arguments[1];
  assert.equal(callback.type, 'ArrowFunctionExpression');
  if (identity === 'F006219') assert(targetBinding.parents.includes(callback));
  const ringBinding = binding(callback, 'ring').node;
  assert(identifier(ringBinding.init.callee, 'createLocalIdentityKeyRing'));
  const ringOptions = ringBinding.init.arguments[0];
  assert(mentions(property(ringOptions, 'previous'), target));
  const previousToken = binding(callback, 'previousToken').node;
  assert(identifier(previousToken.init.callee, 'createTrustedOperatorIdentityToken'));
  if (identity === 'F006219') {
    assert(identifier(property(previousToken.init.arguments[1], 'secret'), target));
    assert.equal(property(previousToken.init.arguments[1], 'keyId').value, 'previous');
  } else assert(identifier(previousToken.init.arguments[1], target));
  assert.equal(previousToken.init.arguments[2].type, 'ArrowFunctionExpression');
  assert(identifier(previousToken.init.arguments[2].body, 'NOW_MS'));
  const resolve = binding(callback, 'resolve').node;
  assert(identifier(resolve.init.callee, 'createTrustedOperatorIdentityResolver'));
  assert(identifier(property(resolve.init.arguments[0], 'keyRing'), 'ring'));
  const now = property(resolve.init.arguments[0], 'now');
  assert.equal(now.type, 'ArrowFunctionExpression');
  assert(identifier(now.body, 'NOW_MS'));
  const consumption = calls(callback, 'resolve').filter(c => identifier(property(c.node.arguments[0], 'x-cvg-operator-token'), 'previousToken'));
  assert.equal(consumption.length, 1);
  assert.equal(calls(callback, 'createConfiguredOperatorIdentityResolver').length, 0);
  const equalityAssertion = select(callback, n => n.type === 'CallExpression' && n.callee.type === 'MemberExpression' && propertyName(n.callee.property) === 'toEqual' && identifier(n.arguments[0], 'IDENTITY') && mentions(n.callee.object, 'previousToken'));
  assert.equal(equalityAssertion.length, 1);

  const impl = parse(implFile);
  const funcs = Object.fromEntries(select(impl, n => n.type === 'FunctionDeclaration').map(r => [r.node.id.name, r.node]));
  const signer = funcs.sign;
  const producer = funcs.createTrustedOperatorIdentityToken;
  const consumer = funcs.createTrustedOperatorIdentityResolver;
  const keyRing = funcs.createLocalIdentityKeyRing;
  const candidateResolver = funcs.resolveCandidateSecrets;
  assert.equal(calls(signer, 'createHmac').length, 1);
  assert.equal(calls(signer, 'createHmac')[0].node.arguments[0].value, 'sha256');
  assert.equal(calls(producer, 'sign').length, 1);
  assert(mentions(calls(producer, 'sign')[0].node.arguments[1], 'key'));
  assert.equal(calls(consumer, 'sign').length, 1);
  assert.equal(calls(consumer, 'timingSafeEqual').length, 1);
  assert.equal(calls(consumer, 'resolveCandidateSecrets').length, 1);
  assert(mentions(keyRing, 'previous') && mentions(keyRing, 'revokedKeyIds'));
  assert(mentions(candidateResolver, 'keyRing') && mentions(candidateResolver, 'keyId'));
  const reachable = ['createTrustedOperatorIdentityToken', 'createTrustedOperatorIdentityResolver', 'createLocalIdentityKeyRing', 'resolveCandidateSecrets', 'normalizeSigningKey', 'normalizeRingKey', 'assertSigningSecret', 'assertKeyId', 'assertTokenWindow', 'assertReplayCacheSize', 'isTrustedOperatorTokenId', 'pruneReplayedTokenIds', 'encodeJson', 'sign', 'decodeClaims'];
  for (const name of reachable) {
    assert(funcs[name], `${name} implementation exists`);
    assert.equal(calls(funcs[name], 'createConfiguredOperatorIdentityResolver').length, 0);
    assert.equal(select(funcs[name], n => n.type === 'Identifier' && ['process', 'fetch', 'eval', 'Function', 'require'].includes(n.name)).length, 0);
  }
  // Do not infer anything from the descriptive key text or a test-path alone.
  const auth = parse(identity === 'F006219' ? 'shared-auth-c791ee47.ts' : 'shared-auth-c57c330f.ts');
  const schema = binding(auth, 'OperatorIdentitySchema').node;
  assert.equal(calleeName(schema.init.callee), 'z.object');
  assert.equal(select(schema.init, n => n.type === 'ArrowFunctionExpression' || n.type === 'FunctionExpression').length, 0);
  secrets[identity] = { previous: literal.value, current: currentLiteral.value };
  astResults.push({
    identity, parser: `Node builtin Acorn ${acorn.version}; node:module stripTypeScriptTypes(mode=strip)`,
    fixture: file, fixtureSha256: sha(read(file)), implementation: implFile, implementationSha256: sha(read(implFile)),
    construction: { declarationKind: declaration.kind, binding: target, initializerType: targetBinding.node.init.type, literalType: literal.type, literalSha256: sha(literal.value), literalLength: literal.value.length, location: span(literal), callbackLocal: identity === 'F006219' },
    callback: span(test), imports, fixtureExports: 0, directEnvironmentOrDynamicCodeReferences: 0, targetAssignments: 0,
    linkedCalls: { ring: span(ringBinding), signer: span(previousToken), resolver: span(resolve), consumer: span(consumption[0].node), identityAssertion: span(equalityAssertion[0].node) },
    implementationFunctions: reachable.map(name => ({ name, ...span(funcs[name]), calls: [...new Set(select(funcs[name], n => n.type === 'CallExpression').map(c => calleeName(c.node.callee)))] })),
    locallyDeclaredSchema: span(schema),
    result: 'PASS',
    limits: 'Static assertions substantiate the inspected local context; they are not an exhaustive whole-program dataflow or imported-library security audit.'
  });
}
save('ast-evidence.json', { historicalCodeExecuted: false, records: astResults });

const hmac = (key, text) => createHmac('sha256', key.trim()).update(text, 'utf8').digest('base64url');
const verify = (key, text, signature) => {
  const expected = Buffer.from(hmac(key, text), 'utf8');
  const received = Buffer.from(signature, 'utf8');
  return expected.length === received.length && timingSafeEqual(expected, received);
};
// Independent standard known-answer check: HMAC-SHA256 RFC 4231 test case 1.
const known = createHmac('sha256', Buffer.alloc(20, 0x0b)).update('Hi There', 'utf8').digest('hex');
assert.equal(known, 'b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7');
const cryptoRecords = [];
for (const [identity, keys] of Object.entries(secrets)) {
  const claims = {
    operatorId: identity === 'F006219' ? 'operator.test' : 'operator.rotation',
    role: 'Supervisor',
    tenantId: identity === 'F006219' ? 'tenant_00000000-0000-4000-8000-000000000001' : 'tenant_00000000-0000-4000-8000-0000000009c1',
    ...(identity === 'F006219' ? { iss: 'cvg-operator' } : {}),
    aud: 'cvg-api', iat: 1700000000, exp: 1700000300,
    // Reviewer-generated deterministic identifier, not a historically stored token.
    jti: 'jti_00000000-0000-4000-8000-000000000021',
    kid: identity === 'F006219' ? 'previous' : 'kid_previous_2026'
  };
  const encoded = Buffer.from(JSON.stringify(claims), 'utf8').toString('base64url');
  const signature = hmac(keys.previous, encoded);
  const changed = Buffer.from(JSON.stringify({ ...claims, role: 'Admin' }), 'utf8').toString('base64url');
  const changedKid = Buffer.from(JSON.stringify({ ...claims, kid: 'reviewer.changed' }), 'utf8').toString('base64url');
  const changedSignature = `${signature[0] === 'a' ? 'b' : 'a'}${signature.slice(1)}`;
  const checks = {
    ownHmacVerifiesWithExactExtractedLiteral: verify(keys.previous, encoded, signature),
    distinctCurrentLiteralRejected: !verify(keys.current, encoded, signature),
    changedClaimsRejected: !verify(keys.previous, changed, signature),
    changedKeyIdRejected: !verify(keys.previous, changedKid, signature),
    sameLengthTamperedSignatureRejected: !verify(keys.previous, encoded, changedSignature),
    shortSignatureRejected: !verify(keys.previous, encoded, signature.slice(1))
  };
  assert(Object.values(checks).every(Boolean));
  cryptoRecords.push({ identity, keySha256: sha(keys.previous), encodedClaimsSha256: sha(encoded), ownSignatureSha256: sha(signature), checks });
}
save('crypto-evidence.json', {
  node: process.version, knownAnswer: { vector: 'RFC 4231 HMAC-SHA256 case 1', result: 'PASS' },
  records: cryptoRecords,
  interpretation: 'Own offline crypto checks on data extracted from literal AST nodes. No historical signer/resolver executed; no historical signature is claimed, required or reconstructed as stored evidence.'
});
console.log(JSON.stringify({ node: process.version, exactBlobAndHashRecords: integrity.length, astLinkedRecords: astResults.length, knownAnswer: 'PASS', offlineCryptoRecords: cryptoRecords.length, cryptoChecksPerRecord: 6, historicalExecution: false }));
