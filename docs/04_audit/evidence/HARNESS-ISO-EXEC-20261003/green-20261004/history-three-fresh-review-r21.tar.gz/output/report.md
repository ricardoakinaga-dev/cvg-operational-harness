ACCEPT — revisão independente finita de três observações históricas

O aceite se limita a F006214, F006219 e F006444 nos commits e blobs fornecidos. Não concede aprovação de produção ou cobertura global do histórico.

| Observação | Commit exato | Classificação | Resultado |
| --- | --- | --- | --- |
| F006214 | 68465197fec8873cb953da34ef6e713ccb9969cd | NATURAL_LANGUAGE_LEXICAL_MATCH | ACCEPT |
| F006219 | c791ee478885410f3fce9910c96df638a3607e81 | SYNTHETIC_LOCAL_HMAC_LITERAL | ACCEPT |
| F006444 | c57c330f809e3a48947fe4aaadc538b7be151ddc | SYNTHETIC_LOCAL_HMAC_LITERAL | ACCEPT |

**F006214** — Elemento de uma enumeração em português no campo narrativo blockers; o prefixo secrets pertence ao texto sobre roles/secrets reais.

O candidato é prosa sobre disponibilidade/observabilidade. Não há atribuição, declaração, objeto de configuração, entrada de autenticação ou uso criptográfico nesse trecho.

O hash do candidato corresponde exatamente às palavras HA/observabilidade, localizadas uma única vez na linha 3772 do blob exato. A sintaxe e as relações lexicais da enumeração distinguem texto natural de um valor de credencial; o caminho de documentação não é usado como fundamento do aceite.

Fonte: docs/08_runtime/archive/prod20260926_runtime_state_history.md, linha 3772; SHA-256 do blob 7462cf616b8f2c7aaed531747ca02724d0df2cdc173843162b7a82decf3ab787; SHA-256 do candidato 54f8546d3c4b0d2e10ec18779f8016a5176a13da64f24c6b183eccd811b14c11.

**F006219** — No callback it das linhas 341–407, const previousSecret recebe diretamente um literal string na linha 342. O AST confirma initializer Literal, sem leitura de ambiente, arquivo ou serviço para construir esse valor.

O callback injeta previousSecret no key ring como secret da chave previous (344–354) e no segundo argumento de createTrustedOperatorIdentityToken (359–363), com identidade local e NOW_MS fixo. No operator-identity.ts do mesmo commit: normalizeSigningKey preserva secret; createTrustedOperatorIdentityToken (62–86) codifica claims e chama sign(encodedClaims, key.secret); sign (464–467) usa HMAC-SHA256 local, UTF-8 e base64url. O mesmo callback cria resolve com o ring e NOW_MS (355–358), passa previousToken em x-cvg-operator-token e compara o retorno à identidade (364). O módulo seleciona a chave por kid via keysAt (283–303), recalcula HMAC e compara tamanho/timingSafeEqual (116–143). A construção local usa rotatedAt = NOW_SECONDS - 10 e janela 60. O mesmo callback constrói janela 1 e prevê rejeição da chave expirada (374–394). Não chama o helper de configuração de ambiente; o caso posterior com NODE_ENV production é outro callback e outro valor current, montado em objeto explícito. A identidade é validada por OperatorIdentitySchema, declarado como z.object com validadores de campos sem callback no auth.ts do mesmo commit (68–80). No fixture inspecionado não há export, atribuição posterior ao binding, referência process/fetch ou import de provider. Nos métodos locais relevantes não há busca de segredo de produção. A evidência vale para essa construção e seu consumo local.

A declaração const é o produtor válido do literal da fixture; não há necessidade de artefato de geração aleatória de chave. A ligação entre literal, parâmetros do assinador, chave selecionada pelo consumidor e chamada real no callback fundamenta o aceite; o nome, caminho e mnemônico não são o critério. O código histórico foi inspecionado estaticamente. Não se exige nem se afirma uma assinatura historicamente armazenada para identificar o uso mostrado pelo código.

Fonte: apps/api/src/__tests__/trusted-operator-identity.test.ts, linha 342; SHA-256 do blob 121e6a5363f9e5f548dd301b636a212f600bb806b614a43a07e19960a97be3a8; SHA-256 do candidato 682b991cf3fafd483e1ac49634ab2ae68cd47e8a285701e5cc87551bb2985f81.

**F006444** — O const PREVIOUS (16–19) é inicializado por objeto com propriedades literais keyId e secret; o literal da linha 18 corresponde ao hash candidato. É construção no escopo do módulo da fixture, não geração ou recuperação de um segredo externo.

No callback 42–65, PREVIOUS é espalhado no array previous do ring (43–47) e passado diretamente como signingKey a createTrustedOperatorIdentityToken (57–61). Identidade e relógio são constantes locais. No operator-identity.ts desse commit, normalizeSigningKey preserva secret (302–315), o produtor cria claims com kid e chama sign (60–83), e sign (424–427) aplica HMAC-SHA256 local com UTF-8/base64url. O helper de assinatura do fixture também usa node:crypto (30–38). O callback cria resolve com esse ring e NOW_MS (48–51), consome previousToken pelo header local e verifica a identidade (64). O módulo filtra por kid/chaves ativas (279–299) e recalcula a assinatura com timingSafeEqual (116–140). A janela 600 e rotatedAt = NOW_SECONDS - 100 tornam previous elegível no primeiro callback. Outros callbacks cobrem limite/expiração, revogação, kid desconhecido e assinatura feita com PREVIOUS.secret mas kid ACTIVE, com expectativa de rejeição. Isso é fluxo de autenticação local de teste, sem chamada ao helper de ambiente ou envio de token a serviço. OperatorIdentitySchema é uma declaração z.object com validadores de campos sem callback em auth.ts do mesmo commit (68–80). O AST confirma construção por literais, ausência de export e de mutação direta de PREVIOUS nesse módulo. Os imports são vitest, node:crypto e o módulo local inspecionado; o fluxo relevante usa os valores recebidos, sem lookup de segredo ou provider externo.

A inicialização const do objeto é o produtor da fixture, e seu uso é comprovado pelo caminho de assinatura/verificação dentro dos callbacks. O aceite reconhece que o literal é material HMAC funcional em teste; não o trata como inerte apenas por ser legível ou por estar num arquivo chamado test. Não é exigida geração aleatória inexistente nem assinatura previamente armazenada. As sondas novas são do revisor e não substituem a inspeção do call-context histórico.

Fonte: apps/api/src/__tests__/identity-key-ring-rotation.test.ts, linha 18; SHA-256 do blob 7dfba8f038b37f3cb853a7f4fb42adda77f62f04915698994537d191d40bdd09; SHA-256 do candidato 97e07e744a4f3053aa8fc64311dc33b13f88fd0a74b5439f617f70e8c5aaf625.

A integridade passou para os três pares packet/git show, três hashes de blob, três linhas completas com LF e três candidatos únicos por hash. Offsets exatos de candidato, em bytes UTF-8, base zero e fim exclusivo: F006214 [103,121), F006219 [28,76), F006444 [11,51). As colunas brutas maiores estão preservadas em integrity.json; não são apresentadas como posições exatas do literal.

Em Node v22.23.2, o probe próprio analisou tipos/AST sem executar código histórico. Confirmou declarações const, os valores literais por hash, imports, ausência de export/mutação direta e as ligações ring → assinador → resolver → header local → assert de identidade. A inspeção do módulo criptográfico e do schema local completa a proveniência funcional. O aviso experimental de stripTypeScriptTypes ficou registrado e não causou falha.

A sonda criptográfica própria passou o vetor conhecido RFC 4231 HMAC-SHA256 caso 1. Para cada literal extraído do AST, passou assinatura/verificação local e rejeitou chave atual distinta, alteração de claims, alteração de kid, assinatura adulterada de mesmo tamanho e assinatura curta. São 12 verificações próprias, além do vetor conhecido; nenhum resultado é apresentado como execução da suíte histórica ou assinatura historicamente armazenada.

O aceite abrange somente F006214, F006219 e F006444 nesses blobs e contextos. Os literais são chaves HMAC funcionais e públicas de teste; esta revisão não afirma impossibilidade de reutilização fora do escopo. Não há aprovação de produção, autorização global do histórico, exceção ampla de regra, supressão nova, aceitação de risco ou reescrita do histórico. Não houve execução de código histórico, app, fixture, eval ou script payload; nenhum acesso a rede/provider/PG, instalação ou leitura de commits descendentes. As escritas ficaram no output da autoridade fora do repositório. Nenhuma fonte, regra, histórico, ledger ou estado operacional do repositório foi alterado. As sondas AST não são auditoria completa do programa, dos barrels ou de dependências terceiras.

review.json contém os três registros detalhados; integrity.json, ast-evidence.json e crypto-evidence.json guardam as provas reproduzíveis. manifest.json registra os hashes das entradas e de todos os arquivos de saída, excluindo apenas o próprio manifesto e seu selo para evitar autorreferência; manifest.sha256 sela o manifesto.
