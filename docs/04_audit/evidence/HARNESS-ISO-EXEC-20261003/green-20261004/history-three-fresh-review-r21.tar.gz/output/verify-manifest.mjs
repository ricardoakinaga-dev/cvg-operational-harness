import { readFileSync, readdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';

assert.equal(process.versions.node.split('.')[0], '22');
const out = new URL('./', import.meta.url);
const sha = value => createHash('sha256').update(value).digest('hex');
const read = name => readFileSync(new URL(name, out));
const manifestBytes = read('manifest.json');
const manifest = JSON.parse(manifestBytes);
assert.equal(read('manifest.sha256').toString('utf8'), `${sha(manifestBytes)}  manifest.json\n`);
const expected = manifest.outputs.map(o => decodeURIComponent(o.path.split('/').at(-1))).sort();
const present = readdirSync(out).filter(n => !manifest.selfReferencePolicy.excludedOutputBasenames.includes(n)).sort();
assert.deepEqual(present, expected);
for (const item of [...manifest.inputs, ...manifest.outputs]) {
  const bytes = readFileSync(decodeURIComponent(item.path));
  assert.equal(bytes.length, item.bytes, item.path);
  assert.equal(sha(bytes), item.sha256, item.path);
}
for (const source of manifest.historicalGitSources) assert.equal(sha(read(source.savedAs)), source.sha256);
const review = JSON.parse(read('review.json'));
assert.equal(review.verdict, 'ACCEPT');
assert.deepEqual(review.records.map(r => r.identity), ['F006214', 'F006219', 'F006444']);
assert(review.records.every(r => r.disposition === 'ACCEPT' && r.integrity.hashesMatch));
assert.equal(manifest.exactObservationCount, 3);
assert.equal(manifest.exactCommitCount, 3);
console.log(JSON.stringify({ node: process.version, result: 'PASS', records: review.records.length, inputHashesVerified: manifest.inputs.length, outputHashesVerified: manifest.outputs.length, historicalSourcesVerified: manifest.historicalGitSources.length, sealVerified: true, manifestSha256: sha(manifestBytes) }));
