import { readFileSync, writeFileSync, readdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';

assert.equal(process.versions.node.split('.')[0], '22');
const out = new URL('./', import.meta.url);
const root = new URL('../', out);
const packet = new URL('../../history-three-provenance-r21/', out);
const read = name => readFileSync(new URL(name, out));
const json = name => JSON.parse(read(name));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const save = (name, value) => writeFileSync(new URL(name, out), JSON.stringify(value, null, 2) + '\n');
const integrity = json('integrity.json');
const ast = json('ast-evidence.json');
const crypto = json('crypto-evidence.json');
const summary = json('probe.stdout.json');
assert.equal(summary.node, 'v22.23.2');
assert.equal(summary.exactBlobAndHashRecords, 3);
assert.equal(summary.astLinkedRecords, 2);
assert.equal(summary.offlineCryptoRecords, 2);
assert.equal(summary.knownAnswer, 'PASS');
assert.equal(summary.historicalExecution, false);
assert(integrity.records.every(r => r.hashesMatch && r.exactGitBytesMatch));
assert(ast.records.every(r => r.result === 'PASS'));
assert(crypto.records.every(r => Object.values(r.checks).every(Boolean)));
const details = [
  {
    identity: 'F006214', disposition: 'ACCEPT', classification: 'NATURAL_LANGUAGE_LEXICAL_MATCH',
    provenance: {
      exactLexicalCandidate: 'HA/observabilidade',
      context: 'roles/secrets reais, HA/observabilidade de replay e limiter distribuídos',
      construction: 'Elemento de uma enumeração em português no campo narrativo blockers; o prefixo secrets pertence ao texto sobre roles/secrets reais.',
      functionalUse: 'O candidato é prosa sobre disponibilidade/observabilidade. Não há atribuição, declaração, objeto de configuração, entrada de autenticação ou uso criptográfico nesse trecho.'
    },
    reasons: [
      'O hash do candidato corresponde exatamente às palavras HA/observabilidade, localizadas uma única vez na linha 3772 do blob exato.',
      'A sintaxe e as relações lexicais da enumeração distinguem texto natural de um valor de credencial; o caminho de documentação não é usado como fundamento do aceite.'
    ],
    evidence: ['integrity.json'],
    evidenceLines: [{ file: 'git-F006214.md', startLine: 3772, endLine: 3772 }]
  },
  {
    identity: 'F006219', disposition: 'ACCEPT', classification: 'SYNTHETIC_LOCAL_HMAC_LITERAL',
    provenance: {
      construction: 'No callback it das linhas 341–407, const previousSecret recebe diretamente um literal string na linha 342. O AST confirma initializer Literal, sem leitura de ambiente, arquivo ou serviço para construir esse valor.',
      producer: 'O callback injeta previousSecret no key ring como secret da chave previous (344–354) e no segundo argumento de createTrustedOperatorIdentityToken (359–363), com identidade local e NOW_MS fixo.',
      signer: 'No operator-identity.ts do mesmo commit: normalizeSigningKey preserva secret; createTrustedOperatorIdentityToken (62–86) codifica claims e chama sign(encodedClaims, key.secret); sign (464–467) usa HMAC-SHA256 local, UTF-8 e base64url.',
      consumer: 'O mesmo callback cria resolve com o ring e NOW_MS (355–358), passa previousToken em x-cvg-operator-token e compara o retorno à identidade (364). O módulo seleciona a chave por kid via keysAt (283–303), recalcula HMAC e compara tamanho/timingSafeEqual (116–143).',
      callContext: 'A construção local usa rotatedAt = NOW_SECONDS - 10 e janela 60. O mesmo callback constrói janela 1 e prevê rejeição da chave expirada (374–394). Não chama o helper de configuração de ambiente; o caso posterior com NODE_ENV production é outro callback e outro valor current, montado em objeto explícito.',
      schemaDependency: 'A identidade é validada por OperatorIdentitySchema, declarado como z.object com validadores de campos sem callback no auth.ts do mesmo commit (68–80).',
      boundedNegativeEvidence: 'No fixture inspecionado não há export, atribuição posterior ao binding, referência process/fetch ou import de provider. Nos métodos locais relevantes não há busca de segredo de produção. A evidência vale para essa construção e seu consumo local.'
    },
    reasons: [
      'A declaração const é o produtor válido do literal da fixture; não há necessidade de artefato de geração aleatória de chave.',
      'A ligação entre literal, parâmetros do assinador, chave selecionada pelo consumidor e chamada real no callback fundamenta o aceite; o nome, caminho e mnemônico não são o critério.',
      'O código histórico foi inspecionado estaticamente. Não se exige nem se afirma uma assinatura historicamente armazenada para identificar o uso mostrado pelo código.'
    ],
    evidence: ['integrity.json', 'ast-evidence.json', 'crypto-evidence.json'],
    evidenceLines: [
      { file: 'git-F006219.ts', startLine: 341, endLine: 407 },
      { file: 'operator-identity-c791ee47.ts', startLine: 62, endLine: 232 },
      { file: 'operator-identity-c791ee47.ts', startLine: 283, endLine: 319 },
      { file: 'operator-identity-c791ee47.ts', startLine: 460, endLine: 486 },
      { file: 'shared-auth-c791ee47.ts', startLine: 68, endLine: 80 }
    ]
  },
  {
    identity: 'F006444', disposition: 'ACCEPT', classification: 'SYNTHETIC_LOCAL_HMAC_LITERAL',
    provenance: {
      construction: 'O const PREVIOUS (16–19) é inicializado por objeto com propriedades literais keyId e secret; o literal da linha 18 corresponde ao hash candidato. É construção no escopo do módulo da fixture, não geração ou recuperação de um segredo externo.',
      producer: 'No callback 42–65, PREVIOUS é espalhado no array previous do ring (43–47) e passado diretamente como signingKey a createTrustedOperatorIdentityToken (57–61). Identidade e relógio são constantes locais.',
      signer: 'No operator-identity.ts desse commit, normalizeSigningKey preserva secret (302–315), o produtor cria claims com kid e chama sign (60–83), e sign (424–427) aplica HMAC-SHA256 local com UTF-8/base64url. O helper de assinatura do fixture também usa node:crypto (30–38).',
      consumer: 'O callback cria resolve com esse ring e NOW_MS (48–51), consome previousToken pelo header local e verifica a identidade (64). O módulo filtra por kid/chaves ativas (279–299) e recalcula a assinatura com timingSafeEqual (116–140).',
      callContext: 'A janela 600 e rotatedAt = NOW_SECONDS - 100 tornam previous elegível no primeiro callback. Outros callbacks cobrem limite/expiração, revogação, kid desconhecido e assinatura feita com PREVIOUS.secret mas kid ACTIVE, com expectativa de rejeição. Isso é fluxo de autenticação local de teste, sem chamada ao helper de ambiente ou envio de token a serviço.',
      schemaDependency: 'OperatorIdentitySchema é uma declaração z.object com validadores de campos sem callback em auth.ts do mesmo commit (68–80).',
      boundedNegativeEvidence: 'O AST confirma construção por literais, ausência de export e de mutação direta de PREVIOUS nesse módulo. Os imports são vitest, node:crypto e o módulo local inspecionado; o fluxo relevante usa os valores recebidos, sem lookup de segredo ou provider externo.'
    },
    reasons: [
      'A inicialização const do objeto é o produtor da fixture, e seu uso é comprovado pelo caminho de assinatura/verificação dentro dos callbacks.',
      'O aceite reconhece que o literal é material HMAC funcional em teste; não o trata como inerte apenas por ser legível ou por estar num arquivo chamado test.',
      'Não é exigida geração aleatória inexistente nem assinatura previamente armazenada. As sondas novas são do revisor e não substituem a inspeção do call-context histórico.'
    ],
    evidence: ['integrity.json', 'ast-evidence.json', 'crypto-evidence.json'],
    evidenceLines: [
      { file: 'git-F006444.ts', startLine: 16, endLine: 65 },
      { file: 'git-F006444.ts', startLine: 81, endLine: 198 },
      { file: 'operator-identity-c57c330f.ts', startLine: 60, endLine: 228 },
      { file: 'operator-identity-c57c330f.ts', startLine: 279, endLine: 315 },
      { file: 'operator-identity-c57c330f.ts', startLine: 420, endLine: 446 },
      { file: 'shared-auth-c57c330f.ts', startLine: 68, endLine: 80 }
    ]
  }
];
const review = {
  task: 'HISTORY_THREE_FRESH_REVIEW_R21', verdict: 'ACCEPT', recordCount: 3,
  scope: 'Somente a classificação das três observações brutas nos commits/blobs exatos fornecidos.',
  basis: 'Decisão independente, baseada em bytes, sintaxe, proveniência funcional e call-context; decisões históricas não são evidência de classificação.',
  records: details.map((d, i) => ({ ...d, rule: 'generic-api-key', integrity: integrity.records[i], ...(i ? { staticEvidence: ast.records[i - 1], ownCryptoChecks: crypto.records[i - 1] } : {}) })),
  significantChecks: {
    node: process.version, exactGitBlobComparisons: 3, blobHashes: 3, completeLFLineHashes: 3, uniquelyLocatedCandidateHashes: 3,
    staticASTProducerConsumerContexts: 2, offlineCryptoKnownAnswer: 'RFC 4231 case 1 PASS', offlineCryptoCases: 2, cryptoChecksPerCase: 6,
    historicalCodeExecuted: false, fullHistoricalTestSuiteExecuted: false
  },
  integrityNotes: [
    'Os hashes de linha usam bytes UTF-8 incluindo LF final.',
    'As colunas brutas são preservadas como coordenadas do match informado; não são offsets do candidato. O candidato foi identificado uma única vez pelo hash em cada linha, e seus offsets exatos de bytes foram registrados.',
    'O stripTypeScriptTypes preservou as linhas e o Acorn produziu ASTs, sem importar, avaliar ou executar módulos históricos. O aviso experimental foi guardado em probe.stderr.txt; o probe terminou com exit 0.',
    'As assinaturas novas são artefatos próprios de crypto offline. O jti determinístico do probe não é um token histórico; randomUUID no código histórico gera jti, não a chave literal.'
  ],
  limits: [
    'O aceite abrange somente F006214, F006219 e F006444 nesses blobs e contextos.',
    'Os literais são chaves HMAC funcionais e públicas de teste; esta revisão não afirma impossibilidade de reutilização fora do escopo.',
    'Não há aprovação de produção, autorização global do histórico, exceção ampla de regra, supressão nova, aceitação de risco ou reescrita do histórico.',
    'Não houve execução de código histórico, app, fixture, eval ou script payload; nenhum acesso a rede/provider/PG, instalação ou leitura de commits descendentes.',
    'As escritas ficaram no output da autoridade fora do repositório. Nenhuma fonte, regra, histórico, ledger ou estado operacional do repositório foi alterado.',
    'As sondas AST não são auditoria completa do programa, dos barrels ou de dependências terceiras.'
  ],
  artifacts: { report: 'report.md', integrity: 'integrity.json', ast: 'ast-evidence.json', crypto: 'crypto-evidence.json', manifest: 'manifest.json', manifestSeal: 'manifest.sha256' }
};
save('review.json', review);

const report = `ACCEPT — revisão independente finita de três observações históricas\n\nO aceite se limita a F006214, F006219 e F006444 nos commits e blobs fornecidos. Não concede aprovação de produção ou cobertura global do histórico.\n\n| Observação | Commit exato | Classificação | Resultado |\n| --- | --- | --- | --- |\n${review.records.map(r => `| ${r.identity} | ${r.integrity.commit} | ${r.classification} | ACCEPT |`).join('\n')}\n\n${review.records.map(r => `**${r.identity}** — ${r.provenance.construction}\n\n${Object.entries(r.provenance).filter(([key]) => !['construction', 'exactLexicalCandidate', 'context'].includes(key)).map(([, value]) => value).join(' ')}\n\n${r.reasons.join(' ')}\n\nFonte: ${r.integrity.path}, linha ${r.integrity.line}; SHA-256 do blob ${r.integrity.blobSha256}; SHA-256 do candidato ${r.integrity.candidateSha256}.`).join('\n\n')}\n\nA integridade passou para os três pares packet/git show, três hashes de blob, três linhas completas com LF e três candidatos únicos por hash. Offsets exatos de candidato, em bytes UTF-8, base zero e fim exclusivo: F006214 [103,121), F006219 [28,76), F006444 [11,51). As colunas brutas maiores estão preservadas em integrity.json; não são apresentadas como posições exatas do literal.\n\nEm Node ${process.version}, o probe próprio analisou tipos/AST sem executar código histórico. Confirmou declarações const, os valores literais por hash, imports, ausência de export/mutação direta e as ligações ring → assinador → resolver → header local → assert de identidade. A inspeção do módulo criptográfico e do schema local completa a proveniência funcional. O aviso experimental de stripTypeScriptTypes ficou registrado e não causou falha.\n\nA sonda criptográfica própria passou o vetor conhecido RFC 4231 HMAC-SHA256 caso 1. Para cada literal extraído do AST, passou assinatura/verificação local e rejeitou chave atual distinta, alteração de claims, alteração de kid, assinatura adulterada de mesmo tamanho e assinatura curta. São 12 verificações próprias, além do vetor conhecido; nenhum resultado é apresentado como execução da suíte histórica ou assinatura historicamente armazenada.\n\n${review.limits.join(' ')}\n\nreview.json contém os três registros detalhados; integrity.json, ast-evidence.json e crypto-evidence.json guardam as provas reproduzíveis. manifest.json registra os hashes das entradas e de todos os arquivos de saída, excluindo apenas o próprio manifesto e seu selo para evitar autorreferência; manifest.sha256 sela o manifesto.\n`;
writeFileSync(new URL('report.md', out), report);

const fileEntry = (url, role) => {
  const bytes = readFileSync(url);
  return { path: url.pathname, role, bytes: bytes.length, sha256: sha(bytes) };
};
const inputs = [fileEntry(new URL('authority.json', root), 'fresh-review authority')];
for (const name of ['authority.json', 'raw-observations.json', 'F006214-prod20260926_runtime_state_history.md', 'F006219-trusted-operator-identity.test.ts', 'F006444-identity-key-ring-rotation.test.ts']) {
  inputs.push(fileEntry(new URL(name, packet), name === 'authority.json' ? 'packet procedural metadata; not adjudication evidence' : 'raw observation/provenance input'));
}
const sources = [
  ...integrity.records.map(r => ({ commit: r.commit, path: r.path, savedAs: r.gitCopy, sha256: r.gitCopySha256 })),
  ...[['c791ee478885410f3fce9910c96df638a3607e81', 'c791ee47'], ['c57c330f809e3a48947fe4aaadc538b7be151ddc', 'c57c330f']].flatMap(([commit, short]) => [
    ['apps/api/src/operator-identity.ts', `operator-identity-${short}.ts`],
    ['packages/shared/src/index.ts', `shared-index-${short}.ts`],
    ['packages/shared/src/auth.ts', `shared-auth-${short}.ts`]
  ].map(([path, savedAs]) => ({ commit, path, savedAs, sha256: sha(read(savedAs)) })))
];
assert.equal(new Set(sources.map(s => s.commit)).size, 3);
const excluded = ['manifest.json', 'manifest.sha256'];
const outputs = readdirSync(out).filter(name => !excluded.includes(name)).sort().map(name => fileEntry(new URL(name, out), 'review output'));
save('manifest.json', {
  task: review.task, verdictScope: review.scope, node: process.version,
  bootstrapAuthoritySha256: inputs[0].sha256, rawObservationsSha256: inputs.find(i => i.path.endsWith('/raw-observations.json')).sha256,
  inputs, historicalGitSources: sources, outputs,
  exactCommitCount: 3, exactObservationCount: 3,
  selfReferencePolicy: { excludedOutputBasenames: excluded, seal: 'manifest.sha256 contains SHA-256(manifest.json); payload outputs include the reviewer scripts' }
});
writeFileSync(new URL('manifest.sha256', out), `${sha(read('manifest.json'))}  manifest.json\n`);
console.log(JSON.stringify({ verdict: 'ACCEPT', records: 3, outputFilesSealed: outputs.length, manifestSha256: sha(read('manifest.json')) }));
