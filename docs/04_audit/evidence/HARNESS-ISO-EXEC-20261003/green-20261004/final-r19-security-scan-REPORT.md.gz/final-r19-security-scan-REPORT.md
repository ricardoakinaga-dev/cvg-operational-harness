# CURRENT SECURITY SCANS R19

Status da lane: **FAIL**. Disposition dos 6,578 achados: **PENDING**. Nenhum achado foi certificado como seguro ou aprovado; nenhuma aprovação de produção.

Source readonly: `/home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r19`. Snapshot privado: `/home/ricardo/.cache/cvg-harness-green-20261004/security-final-source-r19`. Identidade medida: `2e63f36ee298675cf4edbc0701ad82177a4685c0456762e13a374cd4e3d08ba9` (digest canônico nativo), **8.476/8.476** arquivos. O SHA abreviado `9cc15...` e full `5639 PASS` são contexto fornecido pelo usuário, não revalidados por histórico Git ou testes nesta lane. Os manifestos Source antes/depois coincidem; snapshot e lockfile preservados.

| Procedimento atual | Resultado | Limite |
| --- | --- | --- |
| Gitleaks 8.28.0 strict dir | 6575 achados em 185 arquivos; exit 1 | Default allrules, ignore vazio, allow comments desconsiderados, redact 100; nenhum histórico Git |
| CodeQL 2.27.0 create/analyze | 3 alertas em 2 arquivos; ambos exit 0 | JS/TS, fresh DB, threads 2/RAM 8192, installed packs only/no download |
| npm audit JSON prod+dev | 0 vulnerabilidades; retry exit 0 | 139 prod/267 dev, total 406; registry readonly, sem install/fix |
| SBOM atual | 380 componentes; exit 0 | Script atual sem alteração, executado em workspace próprio |
| Licenças atuais | 380 entradas/26 internas; denied/unknown/unclassified 0/0/0; exit 0 | Sem herdar relatório ou exceção anterior |

Os 6575 achados usam `generic-api-key`: 6536 em caminhos `docs/04_audit/evidence/**` e 39 fora deles. A distribuição é factual por caminho, sem declarar falsos positivos ou segurança. Todos os achados estão preservados com valores/redações sanitizados em `raw/gitleaks.json` e indexados em `findings.json`; contagem completa por arquivo em `triage-by-file.json`.

- `js/missing-rate-limiting`: `apps/api/src/server.ts:3194` (severity do scanner 7.5; disposition PENDING).
- `js/missing-rate-limiting`: `apps/api/src/server.ts:3292` (severity do scanner 7.5; disposition PENDING).
- `js/bad-code-sanitization`: `tests/product-boundary-code-execution.test.js:39` (severity do scanner 6.1; disposition PENDING).

CodeQL resolveu 89 queries e produziu 89 BQRS (87 regras SARIF e 2 métricas), com 910 notificações de arquivos extraídos e 842 de baseline JS esperada. O arquivo de fontes da DB contém 1020 entradas: 910 nativas e 110 auxiliares do extractor. Entre 1095 caminhos nativos com extensões de código fora da única exclusão configurada, 252 não aparecem no archive: {'nested_dependency': 96, 'declaration': 69, 'dist_directory': 87}. Esses números registram a cobertura observada; não significam análise semântica de todos os 8.476 arquivos. Nenhum caminho de `docs/04_audit/evidence/**` está no archive. Zero notificações de warning/error do extractor; diagnósticos, métricas e listas completas em `codeql-coverage.json` e `codeql-extraction-diagnostics.json`. O scanner JS/TS não cobre linguagem Python nem outros domínios.

Falhas preservadas: a primeira chamada npm terminou antes da requisição por carregar o mesmo arquivo vazio como configuração global e de usuário; a segunda usou dois arquivos vazios distintos. Não houve instalação, correção, alteração de regra/lockfile, execução de fixtures/testes/full/E2E, provider ou PostgreSQL. Sem leitura de baseline anterior: **novidade de cada achado UNKNOWN**, sem comparação histórica ou herança de disposition.

Desvio de fronteira: a leitura inicial de instruções incluiu `docs/07_agents/AGENTS.md` e `docs/08_runtime/agent_coordination.md` do root compartilhado; o output truncado incluiu narrativa histórica. Nenhuma escrita no root e nenhum julgamento anterior utilizado como evidência. Registrado em `claim.json`; as leituras seguintes ficaram no Source, ferramentas/skills e outputs próprios.

Ambiente de execução criado por allowlist, HOME/TMPDIR próprios e nenhum valor herdado de credenciais; somente npm teve requisição autorizada ao registry. Logs são recibos operacionais; SARIF preserva regras, regiões, fluxos e fingerprints, com mensagens dinâmicas/snippets redigidos. Não foi produzido trace de acesso do kernel nem revalidada identidade de commit completa. Inspeção desta lane foi do próprio executor, sem crítico independente ou descendentes.

Próxima ação: revisar as 6575 observações redigidas e os 3 alertas atuais por arquivo/linha; registrar disposition ou autorizar remediação separada. Não há mudanças de código nesta entrega. Ver `summary.json`, `sentinels.json`, `manifest.json` e `manifest.sha256` para status e integridade.
