// Dynamic evaluators and independent Node execution acquire modules outside the
// literal resolver grammar. Keep them unknown, including local alias escapes.
export function auditDynamicCodeExecution(options) {
  const {
    ts,
    source,
    runtimeNodes,
    typeOnly,
    literal,
    isLoader,
    isBuiltinGetter,
    isDeclarationName,
    loaderDiagnostic
  } = options
  const modules = new Set([
    'vm',
    'node:vm',
    'child_process',
    'node:child_process',
    'worker_threads',
    'node:worker_threads'
  ])
  const inertProperties = new Set([
    'constants',
    'isContext',
    'measureMemory',
    'isMainThread',
    'threadId',
    'parentPort',
    'workerData',
    'MessageChannel',
    'MessagePort',
    'BroadcastChannel',
    'SHARE_ENV',
    'getEnvironmentData',
    'setEnvironmentData',
    'markAsUntransferable',
    'isMarkedAsUntransferable',
    'receiveMessageOnPort'
  ])
  const reflection = new Set([
    'get',
    'construct',
    'getPrototypeOf',
    'getOwnPropertyDescriptor',
    'getOwnPropertyDescriptors'
  ])
  const capabilities = new Map([
    ['eval', 'executor'],
    ['Function', 'executor'],
    ['Object', 'reflection'],
    ['Reflect', 'reflection']
  ])
  const unwrap = (node) => {
    while (
      node &&
      (ts.isParenthesizedExpression(node) ||
        ts.isAsExpression(node) ||
        ts.isTypeAssertionExpression(node) ||
        ts.isNonNullExpression(node) ||
        ts.isAwaitExpression(node))
    )
      node = node.expression
    return node
  }
  const property = (node) =>
    ts.isPropertyAccessExpression(node)
      ? node.name.text
      : ts.isElementAccessExpression(node)
        ? literal(node.argumentExpression)
        : undefined
  const classify = (expression, depth = 0) => {
    const node = unwrap(expression)
    if (!node) return undefined
    if (depth > 128) return 'executor'
    if (ts.isIdentifier(node)) return capabilities.get(node.text)
    if (
      ts.isPropertyAccessExpression(node) ||
      ts.isElementAccessExpression(node)
    ) {
      const name = property(node),
        base = classify(node.expression, depth + 1)
      if (name === 'constructor') return 'executor'
      if (base === 'namespace')
        return inertProperties.has(name) ? undefined : 'executor'
      if (base === 'reflection' && (name === undefined || reflection.has(name)))
        return 'executor'
      if (base === 'executor' && ['bind', 'call', 'apply'].includes(name))
        return 'executor'
      if (
        name === undefined &&
        (ts.isArrowFunction(unwrap(node.expression)) ||
          ts.isFunctionExpression(unwrap(node.expression)) ||
          ts.isClassExpression(unwrap(node.expression)))
      )
        return 'executor'
    }
    if (ts.isCallExpression(node)) {
      if (
        (isLoader(node.expression) ||
          isBuiltinGetter(node.expression) ||
          node.expression.kind === ts.SyntaxKind.ImportKeyword) &&
        modules.has(literal(node.arguments[0]))
      )
        return 'namespace'
      if (classify(node.expression, depth + 1) === 'executor') return 'executor'
    }
    return undefined
  }
  const bind = (name, kind) => {
    if (!kind) return false
    const rank = { reflection: 1, namespace: 2, executor: 3 },
      old = capabilities.get(name)
    if (old && rank[old] >= rank[kind]) return false
    capabilities.set(name, kind)
    return true
  }
  for (const node of runtimeNodes) {
    if (typeOnly(node)) continue
    if (
      ts.isExportDeclaration(node) &&
      modules.has(literal(node.moduleSpecifier))
    ) {
      const names = node.exportClause
      if (
        !names ||
        !ts.isNamedExports(names) ||
        names.elements.some(
          (item) =>
            !item.isTypeOnly &&
            !inertProperties.has(item.propertyName?.text ?? item.name.text)
        )
      )
        loaderDiagnostic(node, 'UNVERIFIED_DYNAMIC_CODE_EXECUTION')
    }
    if (
      ts.isImportEqualsDeclaration(node) &&
      ts.isExternalModuleReference(node.moduleReference) &&
      modules.has(literal(node.moduleReference.expression))
    )
      bind(node.name.text, 'namespace')
    if (
      !ts.isImportDeclaration(node) ||
      !modules.has(literal(node.moduleSpecifier))
    )
      continue
    const clause = node.importClause
    if (clause?.name) bind(clause.name.text, 'namespace')
    const bindings = clause?.namedBindings
    if (bindings && ts.isNamespaceImport(bindings))
      bind(bindings.name.text, 'namespace')
    if (bindings && ts.isNamedImports(bindings))
      for (const item of bindings.elements) {
        if (item.isTypeOnly) continue
        const name = item.propertyName?.text ?? item.name.text
        bind(
          item.name.text,
          name === 'default'
            ? 'namespace'
            : inertProperties.has(name)
              ? undefined
              : 'executor'
        )
      }
  }
  const visitBinding = (pattern, expression, visit) => {
    if (ts.isIdentifier(pattern)) {
      visit(pattern.text, classify(expression))
      return
    }
    if (ts.isObjectBindingPattern(pattern))
      for (const item of pattern.elements) {
        const name = item.propertyName ?? item.name
        const key = ts.isIdentifier(name)
          ? name.text
          : literal(ts.isComputedPropertyName(name) ? name.expression : name)
        if (item.dotDotDotToken) {
          if (classify(expression)) visitBinding(item.name, expression, visit)
          continue
        }
        if (key === undefined) {
          if (classify(expression)) {
            for (const child of item.name.getChildren(source))
              if (ts.isIdentifier(child)) visit(child.text, 'executor')
            if (ts.isIdentifier(item.name)) visit(item.name.text, 'executor')
          }
          continue
        }
        const selected = ts.factory.createElementAccessExpression(
          expression,
          ts.factory.createStringLiteral(key)
        )
        visitBinding(item.name, selected, visit)
        if (item.initializer) visitBinding(item.name, item.initializer, visit)
      }
    if (ts.isArrayBindingPattern(pattern) && classify(expression))
      for (const item of pattern.elements)
        if (ts.isBindingElement(item) && ts.isIdentifier(item.name))
          visit(item.name.text, 'executor')
  }
  let changed = true
  while (changed) {
    changed = false
    const record = (name, kind) => {
      if (bind(name, kind)) changed = true
    }
    for (const node of runtimeNodes) {
      if (ts.isVariableDeclaration(node) && node.initializer)
        visitBinding(node.name, node.initializer, record)
      if (
        ts.isBinaryExpression(node) &&
        node.operatorToken.kind === ts.SyntaxKind.EqualsToken &&
        ts.isIdentifier(node.left)
      )
        record(node.left.text, classify(node.right))
    }
  }
  const reported = new Set()
  for (const node of runtimeNodes) {
    if (typeOnly(node) || isDeclarationName(node)) continue
    if (
      !(
        ts.isIdentifier(node) ||
        ts.isPropertyAccessExpression(node) ||
        ts.isElementAccessExpression(node) ||
        ts.isCallExpression(node)
      )
    )
      continue
    const kind = classify(node)
    if (!kind || kind === 'reflection') continue
    const parent = node.parent
    if (parent && ts.isPropertyAccessExpression(parent) && parent.name === node)
      continue
    let value = node
    while (
      value.parent &&
      (ts.isParenthesizedExpression(value.parent) ||
        ts.isAsExpression(value.parent) ||
        ts.isNonNullExpression(value.parent) ||
        ts.isTypeAssertionExpression(value.parent) ||
        ts.isAwaitExpression(value.parent))
    )
      value = value.parent
    const owner = value.parent
    if (
      owner &&
      ts.isVariableDeclaration(owner) &&
      owner.initializer === value &&
      !owner.parent?.parent?.modifiers?.some(
        (m) => m.kind === ts.SyntaxKind.ExportKeyword
      )
    )
      continue
    if (
      owner &&
      ts.isBinaryExpression(owner) &&
      owner.operatorToken.kind === ts.SyntaxKind.EqualsToken &&
      owner.right === value &&
      ts.isIdentifier(owner.left)
    )
      continue
    if (
      kind === 'namespace' &&
      owner &&
      (ts.isPropertyAccessExpression(owner) ||
        ts.isElementAccessExpression(owner)) &&
      owner.expression === value
    )
      continue
    const diagnostic =
      owner &&
      (ts.isCallExpression(owner) || ts.isNewExpression(owner)) &&
      owner.expression === value
        ? owner
        : node
    const key = diagnostic.getStart(source)
    if (reported.has(key)) continue
    reported.add(key)
    loaderDiagnostic(diagnostic, 'UNVERIFIED_DYNAMIC_CODE_EXECUTION')
  }
}
