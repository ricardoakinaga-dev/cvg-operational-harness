import os,json,hashlib,stat,re
from pathlib import Path
p=Path.cwd();o=p/'output';s=p/'source';rows=[]
def walk(path):
 st=path.lstat();r={'path':str(path.relative_to(s)),'mode':st.st_mode,'inode':st.st_ino,'device':st.st_dev,'size':st.st_size,'mtime_ns':st.st_mtime_ns,'nlink':st.st_nlink}
 if stat.S_ISLNK(st.st_mode):r['target']=os.readlink(path)
 elif stat.S_ISREG(st.st_mode):
  h=hashlib.sha256()
  with path.open('rb') as f:
   for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
  r['sha256']=h.hexdigest()
 rows.append(r)
 if stat.S_ISDIR(st.st_mode):
  for child in sorted(path.iterdir()):walk(child)
walk(s)
(o/'source-after.json').write_text(json.dumps(rows,indent=2)+'\n')
before=json.loads((o/'source-before.json').read_text());b={r['path']:r for r in before};a={r['path']:r for r in rows};differences=[{'path':name,'before':b.get(name),'after':a.get(name)} for name in sorted(set(a)|set(b)) if b.get(name)!=a.get(name)]
frozen=json.loads((p/'frozen-inventory.json').read_text());mismatches=[]
for name,control in frozen.items():
 actual=b.get(name)
 if control['kind']=='file':
  if not actual or actual.get('sha256')!=control['sha256'] or actual['size']!=control['bytes']:mismatches.append({'path':name,'control':control,'actual':actual})
 elif control['kind']=='link':
  if not actual or actual.get('target')!=control.get('target'):mismatches.append({'path':name,'control':control,'actual':actual})
 else:raise RuntimeError('unknown freeze record kind:'+control['kind'])
extras=[name for name,r in b.items() if ('sha256' in r or 'target' in r) and name not in frozen]
freeze=json.loads((p/'freeze.json').read_text());freeze_hash=hashlib.sha256((p/'frozen-inventory.json').read_bytes()).hexdigest()
tests=[r for r in rows if re.search(r'\.(?:test|spec)\.[cm]?[jt]sx?$',r['path']) and not r['path'].startswith('node_modules/') and 'sha256' in r]
(o/'all-test-hashes-after.json').write_text(json.dumps(tests,indent=2)+'\n')
summary={'review':'C1_PARAMETER_FRESH_STATIC_REVIEW_R2','sourceEntries':len(rows),'regularFiles':sum('sha256' in r for r in rows),'links':sum('target' in r for r in rows),'directories':sum(stat.S_ISDIR(r['mode']) for r in rows),'readonly':len(differences)==0,'differences':differences,'freezeInventorySha256':freeze_hash,'freezeInventoryHashMatches':freeze_hash==freeze['inventorySha256'],'freezeRecords':len(frozen),'freezeMismatches':mismatches,'extraSourceFilesOrLinks':extras,'freezeMatchesBefore':not mismatches and not extras,'hashControlledTestSpecFilesOutsideVendor':len(tests),'hashControlledVendorFiles':sum('sha256' in r and r['path'].startswith('node_modules/') for r in rows),'hashControlledDistFilesIncludingVendor':sum('sha256' in r and '/dist/' in r['path'] for r in rows),'beforeSha256':hashlib.sha256((o/'source-before.json').read_bytes()).hexdigest(),'afterSha256':hashlib.sha256((o/'source-after.json').read_bytes()).hexdigest(),'incident':bool(differences)}
(o/'integrity.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
