import fs from 'node:fs'
import ts from './runtime/node_modules/typescript/lib/typescript.js'
import {createBoundaryLexical} from './runtime/scripts/boundary-lexical.mjs'
const original=JSON.parse(fs.readFileSync(new URL('./symbol-proofs.json',import.meta.url),'utf8'))
const results=[]
for(const c of original.results.filter(c=>!c.passed)){
 const source=ts.createSourceFile(`/inert/${c.id}.mjs`,c.text,ts.ScriptTarget.Latest,true)
 const lexical=createBoundaryLexical(ts,source);const ids=[]
 const walk=n=>{if(ts.isIdentifier(n))ids.push(n);ts.forEachChild(n,walk)};walk(source)
 const node=tag=>{const marker=`/*${tag}*/`;return ids.find(n=>n.getStart(source)===c.text.indexOf(marker)+marker.length)}
 const checks=c.checks.map(x=>({a:x.a,b:x.b,expected:x.expected,actual:lexical.identity(node(x.a))===lexical.identity(node(x.b))})).map(x=>({...x,passed:x.actual===x.expected}))
 results.push({id:c.id,extension:'mjs',scriptKind:ts.ScriptKind[source.scriptKind],parseErrors:source.parseDiagnostics.length,fixturesExecuted:false,text:c.text,checks,passed:!source.parseDiagnostics.length&&checks.every(x=>x.passed)})
}
const result={scope:'Confirmation of the same three neutral symbol cases in plain JavaScript grammar; no fixture execution',results}
fs.writeFileSync(new URL('./javascript-symbol-confirmation.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2))
