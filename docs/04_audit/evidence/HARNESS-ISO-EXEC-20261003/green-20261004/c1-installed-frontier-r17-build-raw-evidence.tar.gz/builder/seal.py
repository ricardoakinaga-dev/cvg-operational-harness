from pathlib import Path
import os,hashlib,json,difflib,collections,datetime
b=Path('/home/ricardo/.cache/cvg-harness-green-20261004/c1-installed-unresolved-r17-builder');s=b.with_name('c1-installed-manifest-r16-candidate');c=b.with_name('c1-installed-unresolved-r17-candidate')
exclude={'.git','.gauntlet','coverage','certification','.agent','.cache','.vite','test-results','playwright-report'}
def omit(name):return name in exclude or name.startswith('.env')
def sha(v):return hashlib.sha256(v).hexdigest()
def dump(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def inv(root):
 rows=[]
 for parent,dirs,names in os.walk(root,followlinks=False):
  dirs[:]=sorted(d for d in dirs if not omit(d))
  for n in sorted(names+[d for d in dirs if (Path(parent)/d).is_symlink()]):
   if omit(n):continue
   p=Path(parent)/n;st=p.lstat();rel=p.relative_to(root).as_posix();row={'path':rel,'mode':st.st_mode,'size':st.st_size,'mtime_ns':st.st_mtime_ns}
   if p.is_symlink():
    row['link']=os.readlink(p);assert p.resolve().is_relative_to(root),(p,p.resolve())
   else:row['sha256']=sha(p.read_bytes())
   row['category']='deps' if 'node_modules' in p.relative_to(root).parts else 'dist' if 'dist' in p.relative_to(root).parts else 'source'
   rows.append(row)
 return rows
sb=json.loads((b/'source-before.json').read_text());cb=json.loads((b/'candidate-before.json').read_text());sa=inv(s);ca=inv(c)
dump(b/'source-after.json',sa);dump(b/'candidate-after.json',ca)
def delta(before,after):
 left={r['path']:r for r in before};right={r['path']:r for r in after}
 return [{'path':p,'before':left.get(p),'current':right.get(p)} for p in sorted(left.keys()|right.keys()) if left.get(p)!=right.get(p)]
sd=delta(sb,sa);cd=delta(cb,ca)
files=['scripts/check-product-boundary.mjs','scripts/boundary-manifests.mjs','tests/product-boundary-lexical-static.test.js']
assert not sd,sd[:5]
assert sorted(d['path'] for d in cd)==sorted(files),[d['path'] for d in cd]
protected={}
for name in ['source','deps','dist']:
 before=[r for r in sb if r['category']==name];after=[r for r in sa if r['category']==name]
 protected[name]={'count':len(before),'beforeSHA':sha(json.dumps(before,sort_keys=True).encode()),'currentSHA':sha(json.dumps(after,sort_keys=True).encode()),'sourceByteModeMtimeMatch':before==after}
 protected[name]['candidateChanges']=[d['path'] for d in cd if (d['before'] or d['current'])['category']==name]
dump(b/'invariance-report.json',{'protectedSource':protected,'sourceChanges':sd,'candidateChanges':cd,'excludedNames':sorted(exclude),'excludedPrefixes':['.env'],'hashInventoryScope':'Finite physical files and internal symlinks; excluded private/runtime/cache namespaces never read for hashing'})
patch=''.join(''.join(difflib.unified_diff((s/p).read_text().splitlines(keepends=True),(c/p).read_text().splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p)) for p in files)
(b/'build.patch').write_text(patch)
manifestfiles=[{'path':p,'beforeSHA':sha((s/p).read_bytes()),'currentSHA':sha((c/p).read_bytes()),'beforeBytes':(s/p).stat().st_size,'currentBytes':(c/p).stat().st_size} for p in files]
base=json.loads((b/'logs/before-native.json').read_text());final=json.loads((b/'logs/after-native.json').read_text());beforefinal=json.loads((b/'logs/before-final-r17.json').read_text())
assert base['numPassedTests']==911 and base['numFailedTests']==0
assert final['numPassedTests']==1046 and final['numFailedTests']==0 and final['numPendingTests']==0
case={}
original_count=0
for suite in final['testResults']:
 p=Path(suite['name']).relative_to(c).as_posix();prior=next(x for x in base['testResults'] if Path(x['name']).relative_to(c).as_posix()==p)
 beforecases=prior['assertionResults'];aftercases=suite['assertionResults']
 identity=lambda x:{'fullName':x['fullName'],'title':x['title'],'ancestorTitles':x['ancestorTitles']}
 assert [identity(x) for x in beforecases]==[identity(x) for x in aftercases[:len(beforecases)]]
 if p != files[2]:original_count+=len(aftercases);assert len(beforecases)==len(aftercases)
 case[p]={'beforeCases':len(beforecases),'currentCases':len(aftercases),'originalCaseIdentityMatch':True,'beforeCaseIdentitySHA':sha(json.dumps([identity(x) for x in beforecases],sort_keys=True).encode()),'currentPrefixCaseIdentitySHA':sha(json.dumps([identity(x) for x in aftercases[:len(beforecases)]],sort_keys=True).encode()),'cases':[{'index':i,**identity(x),'status':x['status'],'isAppendedR17':p==files[2] and i>=len(beforecases)} for i,x in enumerate(aftercases)]}
assert original_count==253
assert case[files[2]]['beforeCases']==658 and case[files[2]]['currentCases']==793
dump(b/'case-inventory.json',case)
installed=json.loads((b/'logs/final-installed.stdout.log').read_text());reasons=collections.Counter(d['reason'] for d in installed['diagnostics'])
rows=[d for d in installed['diagnostics'] if d['reason']=='UNRESOLVED_INSTALLED_LOCAL_DEPENDENCY']
assert len(rows)==1
r=rows[0];assert r['file']=='node_modules/eslint/package.json' and r['dependencyField']=='devDependencies'
expected='fb5acf595b68e1c19a2b61a6741c302c775fa4d360d944ce7d7b8f78ee3eee7e'
assert r['manifestSha256']==r['installedActor']['manifestSha256']==expected==sha((c/r['file']).read_bytes())
assert json.loads((c/r['file']).read_text())[r['dependencyField']][r['specifier']]==r['dependencySpecifier']=='file:packages/eslint-config-eslint'
assert not (c/r['target']).exists()
origin=r['installedActor'];assert json.loads((c/origin['declaredBy']).read_text())[origin['dependencyField']][origin['specifier']]==origin['dependencySpecifier']
unknown=sum(v for k,v in reasons.items() if k not in {'UNVERIFIED_INSTALLED_DEPENDENCY','UNRESOLVED_INSTALLED_LOCAL_DEPENDENCY','UNVERIFIED_LOCAL_DEPENDENCY','UNVERIFIED_WORKSPACE_DEPENDENCY'})
assert unknown==1610 and installed['status']=='INCOMPLETE' and not installed['passed']
assert (b/'logs/final-installed.exit').read_text().strip()=='1'
for name in ['final-typecheck','final-lint','after-native']:assert (b/('logs/'+name+'.exit')).read_text().strip()=='0'
# The existing execution analysis, loader semantics and CLI suffix remain byte exact.
anchor='  const runtimeReferences = []'
assert (s/files[0]).read_text().split(anchor,1)[1]==(c/files[0]).read_text().split(anchor,1)[1]
dump(b/'installed-diagnostics.json',{'status':installed['status'],'passed':False,'exit':1,'sourceFiles':installed['sourceFiles'],'coreFiles':installed['coreFiles'],'workspaceCount':installed['workspaceCount'],'edgeCount':installed['edgeCount'],'violations':len(installed['violations']),'diagnostics':len(installed['diagnostics']),'reasonCounts':dict(reasons),'retainedUnknownCount':unknown,'unknownIdentityLimitation':'Previous 1610 raw-row identity comparison not performed; historical narratives remain excluded. Existing analyzer/loader suffix is byte-exact; current unknown count remains 1610 and every row remains blocking.','unresolvedPhysicalRows':rows})
checks=[{'name':name,'exit':int((b/('logs/'+name+'.exit')).read_text()),'stdout':str(b/('logs/'+name+('.stdout.log' if name.startswith('final-') or name=='after-native' else '.log')))} for name in ['before-native','before-final-r17','after-native','final-typecheck','final-lint','final-installed']]
report={'task':'bounded C1 R17 installed unresolved physical metadata frontier','stage':'BUILD candidate + scoped verification; Lead owns AUDIT/acceptance/Root persistence','builderStatus':'READY_FOR_LEAD_REVIEW','releaseStatus':'NOT_ACCEPTED / installed INCOMPLETE / no global-release claim','source':str(s),'candidate':str(c),'output':str(b),'node':'v22.23.2','change':'Preserve workspace AND physical declared-key successors in declaring Node lookup order; missing-workspace uncertainty coexists with physical product FAIL. Govern/census canonical JSON-less installed contexts and connect their nested metadata while retaining unknown implementation. Separate shape validation from recursive local frontier state; registration requires a real registry declaration and exact physical Node destination. Missing file/link local references of such actors emit blocking provenance rows; strict localPackage and repository/shape/symlink/containment errors retain throws. Failed reads evict shape cache and retain failed closure state. Four fields, canonical aliases/cycles, Node search order and Root ancestry opacity preserved.','checks':checks,'beforeInstalled':{'exit':2,'classification':'FAIL_CLOSED','stderr':(b/'logs/before-installed.stderr.log').read_text()},'beforeControls':{'cases':79,'passed':beforefinal['numPassedTests'],'failed':beforefinal['numFailedTests'],'filteredOutOriginal658':658,'limitation':'Some failures concern newly exposed reader-state/provenance API assertions, not separate falsePASS cases.'},'afterTests':{'original':253,'preservedStaticPrefix':658,'appendedR17':135,'initialR17':79,'reviewerExtension':56,'total':1046,'passed':1046,'failed':0,'skipped':0},'installed':json.loads((b/'installed-diagnostics.json').read_text()),'invariance':protected,'editedFiles':manifestfiles,'evidence':{'rawNativeBefore':str(b/'logs/before-native.json'),'rawNativeAfter':str(b/'logs/after-native.json'),'rawInstalled':str(b/'logs/final-installed.stdout.log'),'assertionAST':str(b/'ast-inventory.json'),'cases':str(b/'case-inventory.json'),'invariance':str(b/'invariance-report.json')},'selfReview':{'kind':'I0 self-inspection; not independent','criteria':['Reviewed diff for any skip/vendor/field/trust exception: none added','No new fixture runtime calls in appendix AST','Existing analyzer/runtime-resolver suffix is byte-exact','All 3 edited paths bounded; original files/prefix and Source/deps/dist stable','Checked physical diagnostic field/value/path/SHA against actual installed JSON','Registry syntax and exact local-edge binding reinforced before final checks'],'remaining':'Lead fresh-context critic and Root integration are not executed by Builder'},'limitations':['Initial Root git-status/rules/mandatory runtime/log/backlog/coordination read reached prohibited ledgers/narrative outside the latest bounded request. This read-scope violation is recorded; no contents used as implementation or acceptance evidence. No further historical/reviewer narrative reads.','Installed gate remains blocking with 2957 diagnostics, including all 1610 current pre-existing-kind unknowns; no permission/trust/release granted.','Prior raw-row identity equality for the 1610 unknowns was not checked; no historical reviewer narratives inspected as evidence.','No full application suite, PG/E2E, certification, neutral/CI/remote work or independent review: those belong to Lead.','No network/PG/provider/DNS commands, dependency installs, push, subagents or lockfile edits were issued; no OS-level network-denial attestation was added to original trusted execution infrastructure.','Operational .agent and caches/private generated namespaces excluded; original native suite/Vitest/config and runtime-resolver infrastructure preserved.'], 'nextAction':'Lead verifies manifest hashes, applies build.patch only within its own bounded integration scope, and runs the separately owned fresh review; retain installed INCOMPLETE and pending R16/CI/neutral/global gates.'}
steering=json.loads((b/'steering.json').read_text())
reviewBefore=json.loads((b/'logs/before-reviewer.json').read_text());reviewAfter=json.loads((b/'logs/after-reviewer.json').read_text())
assert reviewBefore['numFailedTests']==44 and reviewBefore['numPassedTests']==12
assert reviewAfter['numPassedTests']==56 and reviewAfter['numFailedTests']==0
support={}
for finding in ['F1','F2','F3']:
 prior=[x for suite in reviewBefore['testResults'] for x in suite['assertionResults'] if x['title'].startswith(finding+' ')]
 current=[x for suite in reviewAfter['testResults'] for x in suite['assertionResults'] if x['title'].startswith(finding+' ')]
 assert all(x['status']=='failed' for x in prior) and all(x['status']=='passed' for x in current)
 support[finding]={'beforeFailed':len(prior),'afterPassed':len(current),'cases':[x['fullName'] for x in current]}
assert [support[x]['beforeFailed'] for x in ['F1','F2','F3']]==[20,4,8]
report['reviewerSteering']={'authority':steering,'reproducedConfirmedFindings':support,'additionalRegressionCases':56,'before':{'passed':12,'failed':44,'filteredOutOriginalAndInitialR17':737},'after':{'passed':56,'failed':0},'noExploratoryOuterAncestorExtension':True,'initial79ByteExact':True,'intermediateManifest':str(b/'intermediate-local-continuation/buildmanifest.json'),'intermediateInventory':str(b/'intermediate-local-continuation/artifact-index.json')}
oldFile=(b/'intermediate-local-continuation/product-boundary-lexical-static.test.js').read_bytes()
assert (c/files[2]).read_bytes().startswith(oldFile)
report['selfReview']['criteria']+=['All 32 confirmed R16 findings reproduced before correction and PASS afterward (F1 20 / F2 4 / F3 8)','Workspace+physical successor and JSON-less census include blocking missing local publication metadata','Initial79 appendix and exact 990 intermediate file/logs preserved in finite indexed archive','Four exploratory outer-ancestor cases remain excluded']
report['selfReview']['remaining']='Lead fresh-context passive diagnostic auditor/acceptance and Root integration are not performed by Builder'
report['beforeControls']['reviewerExtensionBefore']={'cases':56,'failed':44,'passed':12}
report['unknownRetention']=json.loads((b/'intermediate-to-current-retention.json').read_text())
report['evidence']['intermediateToCurrentRetention']=str(b/'intermediate-to-current-retention.json')
dump(b/'reviewer-finding-map.json',report['reviewerSteering'])
dump(b/'report.json',report)
(b/'report.md').write_text('R17 candidate ready for Lead review; installed gate remains **INCOMPLETE**, not a release acceptance.\n\nChanged only the checker, manifest helper and a byte-preserving appendix of 135 inert controls (initial 79 + 56 reviewer regressions). Original 253 and prior 658 cases remain intact; final native run: **1046 PASS, 0 FAIL, 0 SKIP**. Typecheck and lint: exit 0 in Node 22.23.2. Before new controls: 53 FAIL / 26 PASS; raw failures retained.\n\nR16 steering: all 32 confirmed findings reproduced before corrections (F1: 20, F2: 4, F3: 8). The 56-case extension had 44 FAIL / 12 PASS before and 56 PASS after; four exploratory outer-ancestor cases excluded. The initial79 appendix remains byte-exact; exact intermediate990 code/reports/logs are indexed separately.\n\nInstalled scan: before exit 2 (ESLint local dependency abort), after exit 1 / INCOMPLETE, 2,957 blocking diagnostics and 0 known product violations. The exact ESLint manifest SHA, devDependency value and missing physical path are recorded. The previous-kind 1,610 unknown count is retained; raw historical row identity was not revalidated.\n\nSource, deps and dist hashes/modes/mtimes match before/after. Candidate changed paths are exactly the three allowed paths. AST, case identity, prefix hashes and raw native logs are included.\n\nLimitation: initial Root rules/ledger/coordination reads exceeded the latest opaque read boundary. This incident is recorded, and no resulting narrative is used as implementation/acceptance evidence. Independent review, pending R16 critic, CI/neutral and Root persistence belong to Lead.\n')
manifest={'schema':'cvg-c1-r17-builder-v1','task':'C1 R17 installed unresolved metadata','source':str(s),'candidate':str(c),'output':str(b),'node':'22.23.2','files':manifestfiles,'patch':{'path':str(b/'build.patch'),'sha256':sha((b/'build.patch').read_bytes())},'report':{'path':str(b/'report.json'),'sha256':sha((b/'report.json').read_bytes())},'assertionAST':str(b/'ast-inventory.json'),'caseInventory':str(b/'case-inventory.json'),'artifactInventory':str(b/'artifact-inventory.json'),'invarianceReport':str(b/'invariance-report.json'),'status':'BUILDER_VERIFIED_SCOPED_NOT_ACCEPTED','installedStatus':'INCOMPLETE','rootPersistenceOwner':'Lead','readScopeIncident':True,'initial79ByteExact':True,'appendedCases':135,'confirmedR16Findings':['C1-F01','C1-F02','C1-F03'],'reviewerFindingMap':str(b/'reviewer-finding-map.json'),'currentUnknownRetention':str(b/'intermediate-to-current-retention.json'),'intermediateInventory':str(b/'intermediate-local-continuation/artifact-index.json')}
dump(b/'buildmanifest.json',manifest)
print(json.dumps({'sourceFiles':len(sb),'categories':{k:v['count'] for k,v in protected.items()},'changed':[x['path'] for x in cd],'tests':1046,'diagnostics':len(installed['diagnostics']),'manifest':str(b/'buildmanifest.json')}))
