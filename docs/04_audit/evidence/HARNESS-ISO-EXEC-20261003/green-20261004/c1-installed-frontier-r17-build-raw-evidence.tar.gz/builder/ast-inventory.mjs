import fs from 'node:fs'
import path from 'node:path'
import {createHash} from 'node:crypto'
import ts from '../c1-installed-unresolved-r17-candidate/node_modules/typescript/lib/typescript.js'
const output = path.dirname(new URL(import.meta.url).pathname)
const source = path.join(path.dirname(output), 'c1-installed-manifest-r16-candidate')
const candidate = path.join(path.dirname(output), 'c1-installed-unresolved-r17-candidate')
const sha = value => createHash('sha256').update(value).digest('hex')
const printer = ts.createPrinter({removeComments:true, newLine:ts.NewLineKind.LineFeed})
function inspect(label, bytes) {
  const text = bytes.toString('utf8')
  const tree = ts.createSourceFile(label, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS)
  const assertions=[], tests=[], prohibited=[]
  function visit(node) {
    if (ts.isCallExpression(node)) {
      const expression=node.expression.getText(tree)
      if (/^expect\(/.test(expression)) assertions.push(printer.printNode(ts.EmitHint.Unspecified,node,tree))
      if (expression === 'it' || /^it\.each/.test(expression)) tests.push(printer.printNode(ts.EmitHint.Unspecified,node,tree))
      if (/\b(?:eval|Function|spawnSync|spawn|execSync|execFile|runInContext|runInThisContext|import)\b/.test(expression)) prohibited.push(expression)
    }
    if (ts.isNewExpression(node) && /\b(?:Worker|Function)\b/.test(node.expression.getText(tree))) prohibited.push(node.expression.getText(tree))
    ts.forEachChild(node,visit)
  }
  visit(tree)
  return {bytes:bytes.length,sha256:sha(bytes),parseErrors:tree.parseDiagnostics.length,
    assertionExpressions:assertions.length,assertionAstSha256:sha(JSON.stringify(assertions)),
    testDeclarations:tests.length,testAstSha256:sha(JSON.stringify(tests)),prohibitedFixtureExecutionExpressions:prohibited}
}
const originalFiles=['tests/product-boundary.test.js','tests/product-boundary-code-execution.test.js']
const records=originalFiles.map(file=>{
  const before=fs.readFileSync(path.join(source,file)),after=fs.readFileSync(path.join(candidate,file))
  if (!before.equals(after)) throw Error('original_bytes_changed:'+file)
  return {file,byteExact:true,before:inspect(file,before),current:inspect(file,after)}
})
const appendedFile='tests/product-boundary-lexical-static.test.js'
const prefix=fs.readFileSync(path.join(source,appendedFile)),current=fs.readFileSync(path.join(candidate,appendedFile))
if (!prefix.equals(current.subarray(0,prefix.length))) throw Error('prefix_changed')
const append=current.subarray(prefix.length), appended=inspect('append.js',append)
if (appended.prohibitedFixtureExecutionExpressions.length || appended.parseErrors) throw Error('append_execution_or_parse_error')
const data={node:process.version,originalFiles:records,staticPrefix:{file:appendedFile,byteExact:true,...inspect(appendedFile,prefix)},appended,full:inspect(appendedFile,current)}
fs.writeFileSync(path.join(output,'ast-inventory.json'),JSON.stringify(data,null,2)+'\n')
console.log(JSON.stringify({node:process.version,prefixSha:sha(prefix),appendedAssertionCount:appended.assertionExpressions,appendSha:sha(append),forbiddenCalls:appended.prohibitedFixtureExecutionExpressions.length}))
