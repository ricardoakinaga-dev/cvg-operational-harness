R17 candidate ready for Lead review; installed gate remains **INCOMPLETE**, not a release acceptance.

Changed only the checker, manifest helper and a byte-preserving appendix of 79 inert controls. Original 253 and prior 658 cases remain intact; final native run: **990 PASS, 0 FAIL, 0 SKIP**. Typecheck and lint: exit 0 in Node 22.23.2. Before new controls: 53 FAIL / 26 PASS; raw failures retained.

Installed scan: before exit 2 (ESLint local dependency abort), after exit 1 / INCOMPLETE, 2,844 blocking diagnostics and 0 known product violations. The exact ESLint manifest SHA, devDependency value and missing physical path are recorded. The previous-kind 1,610 unknown count is retained; raw historical row identity was not revalidated.

Source, deps and dist hashes/modes/mtimes match before/after. Candidate changed paths are exactly the three allowed paths. AST, case identity, prefix hashes and raw native logs are included.

Limitation: initial Root rules/ledger/coordination reads exceeded the latest opaque read boundary. This incident is recorded, and no resulting narrative is used as implementation/acceptance evidence. Independent review, pending R16 critic, CI/neutral and Root persistence belong to Lead.
