from pathlib import Path
c=Path('/home/ricardo/.cache/cvg-harness-green-20261004/c1-installed-unresolved-r17-candidate')
p=c/'scripts/boundary-manifests.mjs'
s=p.read_text().replace("import fs from 'node:fs'", "import fs from 'node:fs'\nimport { createHash } from 'node:crypto'")
s=s.replace('  const censused = new Set()', '''  // cache contains validated shapes only; closureStates records unresolved or
  // failed frontiers separately. Neither a shape nor an incomplete closure is
  // an approval of its implementation.
  const closureStates = new Map()
  const shapeHashes = new Map()
  const installedActors = new Map()
  const unresolved = new Map()
  const censused = new Set()''')
s=s.replace('  function read(filename, { rootManifest = false, requireName = false } = {}) {','  function readShape(filename, { rootManifest = false, requireName = false } = {}) {')
s=s.replace("    const value = JSON.parse(fs.readFileSync(filename, 'utf8'))", "    const bytes = fs.readFileSync(filename)\n    const value = JSON.parse(bytes.toString('utf8'))")
a=s.index('    // Memoize validated shape before following local edges')
b=s.index('  function workspaceShape',a)
s=s[:a]+'''    cache.set(filename, value)
    shapeHashes.set(filename, createHash('sha256').update(bytes).digest('hex'))
    return value
  }
  function read(filename, options = {}) {
    filename = path.resolve(filename)
    const state = closureStates.get(filename)
    if (state?.status === 'failed') throw state.error
    const value = readShape(filename, options)
    if (state) return value // visiting cycles, complete and incomplete shapes
    closureStates.set(filename, { status: 'visiting' })
    let incomplete = false
    try {
      for (const field of manifestDependencyFields)
        for (const [name, version] of Object.entries(value[field] ?? {}))
          if (/^(file|link):/.test(version.trim())) {
            const ref = localEdge(filename, field, name, version)
            if (ref.unresolved) {
              incomplete = true
              continue
            }
            read(ref.manifest, { requireName: true })
            census(path.dirname(ref.manifest))
            if (closureStates.get(ref.manifest)?.status === 'incomplete')
              incomplete = true
          }
      closureStates.set(filename, {
        status: incomplete ? 'incomplete' : 'complete'
      })
      return value
    } catch (error) {
      cache.delete(filename)
      closureStates.set(filename, { status: 'failed', error })
      throw error
    }
  }
  function installedActor(filename) {
    // Registration comes from the actual declaring manifest and Node lookup,
    // never merely from a vendor-looking path or a requested reader option.
    return [...installedActors.values()]
      .filter(({ context }) => {
        const rel = path.relative(context, filename)
        return inside(context, filename) &&
          !rel.split(path.sep).includes('node_modules')
      })
      .sort((a, b) => b.context.length - a.context.length)[0]
  }
''' + s[b:]
s=s.replace('  function localPackage(filename, version) {','  function localDirectory(filename, version) {')
s=s.replace("    if (!inside(root, target) || !fs.existsSync(target))\n      reject(filename, 'local_dependency')", "    if (!inside(root, target)) reject(filename, 'local_dependency')\n    return target\n  }\n  function localPackage(filename, version) {\n    const target = localDirectory(filename, version)\n    if (!fs.existsSync(target)) reject(filename, 'local_dependency')")
needle='  function installedPackage(filename, name) {'
pos=s.index(needle)
s=s[:pos]+'''  function localEdge(filename, field, name, version) {
    const actor = installedActor(filename)
    if (!actor) return { manifest: localPackage(filename, version) }
    const target = localDirectory(filename, version)
    // Prove absence without swallowing permissions, malformed shape, dangling
    // links or containment errors. Existing symlink ancestors are recused even
    // if a missing descendant would otherwise make existsSync return false.
    let cursor = root
    let missing = false
    for (const part of path.relative(root, target).split(path.sep).filter(Boolean)) {
      cursor = path.join(cursor, part)
      try {
        const stat = fs.lstatSync(cursor)
        if (stat.isSymbolicLink() || !stat.isDirectory())
          reject(filename, 'local_dependency')
      } catch (error) {
        if (error.code !== 'ENOENT') throw error
        missing = true
        break
      }
    }
    const manifest = path.join(target, 'package.json')
    if (!missing) {
      try {
        fs.lstatSync(manifest)
      } catch (error) {
        if (error.code !== 'ENOENT') throw error
        missing = true
      }
    }
    if (!missing) return { manifest: localPackage(filename, version) }
    const row = {
      file: path.relative(root, filename),
      manifestSha256: shapeHashes.get(filename),
      specifier: name,
      dependencyField: field,
      dependencySpecifier: version,
      target: path.relative(root, manifest),
      reason: 'UNRESOLVED_INSTALLED_LOCAL_DEPENDENCY',
      resolution: cursor === target && fs.existsSync(target)
        ? 'MISSING_LOCAL_MANIFEST' : 'MISSING_LOCAL_DIRECTORY',
      installedActor: {
        manifest: path.relative(root, actor.manifest),
        manifestSha256: shapeHashes.get(actor.manifest),
        context: path.relative(root, actor.context),
        declaredBy: path.relative(root, actor.declaredBy),
        dependencyField: actor.field,
        specifier: actor.name,
        dependencySpecifier: actor.version
      }
    }
    const key = JSON.stringify([filename, field, name])
    unresolved.set(key, row)
    return { manifest, unresolved: row }
  }
  function installedPackage(filename, name, { field, version } = {}) {
''' + s[pos+len(needle):]
s=s.replace("      return {\n        context,\n        manifest: fs.existsSync(manifest) ? manifest : undefined\n      }",'''      // Only a real registry declaration with a physical installed destination
      // establishes this scope. Workspace/local symlink aliases retain the
      // repository's strict local-missing contract.
      const declared = readShape(filename)
      if (manifestDependencyFields.includes(field) &&
          declared[field]?.[name] === version &&
          !/^(file|link|workspace):/.test(version.trim()) &&
          path.relative(root, context).split(path.sep).includes('node_modules') &&
          !installedActors.has(context))
        installedActors.set(context, {
          context, manifest, declaredBy: filename, field, name, version
        })
      return {
        context,
        manifest: fs.existsSync(manifest) ? manifest : undefined
      }''')
s=s.replace('    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {','    try {\n    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {')
s=s.replace('    return result\n  }\n  return { read, census, localPackage, installedPackage, cache }', '''    return result
    } catch (error) {
      censused.delete(directory)
      throw error
    }
  }
  return { read, census, localPackage, localEdge, installedPackage, cache,
    closureStates, unresolved }
''')
p.write_text(s)
p=c/'scripts/check-product-boundary.mjs'; s=p.read_text()
s=s.replace('          const targetPkg = metadata.localPackage(pkgFile, version)','''          const ref = metadata.localEdge(pkgFile, field, name, version)
          if (ref.unresolved) {
            reportDiagnostic(pkgFile, ref.unresolved)
            continue
          }
          const targetPkg = ref.manifest''')
s=s.replace('const installed = metadata.installedPackage(pkgFile, name)', 'const installed = metadata.installedPackage(pkgFile, name, {\n              field, version\n            })')
p.write_text(s)
