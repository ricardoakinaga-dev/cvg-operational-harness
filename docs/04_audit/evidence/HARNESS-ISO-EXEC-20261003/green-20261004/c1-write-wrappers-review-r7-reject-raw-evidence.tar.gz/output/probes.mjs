import fs from 'node:fs'
import path from 'node:path'
import ts from './runtime/node_modules/typescript/lib/typescript.js'
import {createBoundaryLexical,assignedValues,valueBranches} from './runtime/scripts/boundary-lexical.mjs'
import {auditProductBoundary} from './runtime/scripts/check-product-boundary.mjs'
const out=path.dirname(new URL(import.meta.url).pathname)
const dir=path.join(out,'probes');fs.mkdirSync(dir,{recursive:true})
const results=[]
function parse(text,ext='mts') {
 const source=ts.createSourceFile('entry.'+ext,text,ts.ScriptTarget.Latest,true)
 const nodes=[];const visit=n=>{nodes.push(n);ts.forEachChild(n,visit)};visit(source)
 return {source,nodes,parseErrors:source.parseDiagnostics.map(d=>ts.flattenDiagnosticMessageText(d.messageText,'\n'))}
}
function native(id,text,expected,ext='mts') {
 const root=path.join(dir,id)
 const write=(file,content)=>{const f=path.join(root,file);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,content)}
 for(const d of ['packages/core/src','apps','legacy','products']) fs.mkdirSync(path.join(root,d),{recursive:true})
 write('package.json',JSON.stringify({private:true,type:'module',workspaces:['packages/*']}))
 write('packages/core/package.json',JSON.stringify({name:'@inert/core',type:'module'}))
 write('tsconfig.base.json',JSON.stringify({compilerOptions:{module:'NodeNext',moduleResolution:'NodeNext',target:'ESNext',allowJs:true}}))
 write('packages/core/src/entry.'+ext,text)
 const parsed=parse(text,ext)
 const audit=auditProductBoundary(root)
 const row={id,evidence:'native-auditProductBoundary',text,ext,parseErrors:parsed.parseErrors,expected,observed:audit.status,meetsExpected:audit.status===expected,audit,fixtureExecuted:false}
 results.push(row);return row
}
const wrappers=[['plain',s=>s],['paren',s=>`(${s})`],['as',s=>`(${s} as any)`],['satisfies',s=>`(${s} satisfies unknown)`],['non-null',s=>`(${s}!)`],['assertion',s=>`(<unknown>${s})`],['nested',s=>`(((${s} as any)!) satisfies unknown)`]]
for(const [name,wrap] of wrappers) {
 native('selection-'+name,`declare const record:{constructor:unknown};let token;({constructor:${wrap('token')}}=record);export {token}`,'INCOMPLETE')
 native('nested-selection-'+name,`declare const record:{value:{constructor:unknown}};let token;({value:{constructor:${wrap('token')}}}=record);export {token}`,'INCOMPLETE')
 native('default-selection-'+name,`declare const record:{constructor:unknown};let token;({constructor:${wrap('token')}="label"}=record);export {token}`,'INCOMPLETE')
 native('local-scalar-read-'+name,`const obj={constructor:"label"};${wrap('obj.constructor')}`,'PASS')
 native('local-scalar-property-mutation-'+name,`declare const replacement:unknown;const obj={constructor:"label"};${wrap('obj.constructor')}=replacement;obj.constructor`,'INCOMPLETE')
 native('scalar-cell-mutation-'+name,`declare const replacement:unknown;const scalar="label";${wrap('scalar')}=replacement;const obj={constructor:scalar};obj.constructor`,'INCOMPLETE')
 native('scalar-pattern-cell-mutation-'+name,`declare const replacement:unknown;const scalar="label";[${wrap('scalar')}]=[replacement];const obj={constructor:scalar};obj.constructor`,'INCOMPLETE')
 native('for-in-property-mutation-'+name,`const obj={constructor:"label"};for(${wrap('obj.constructor')} in {value:"label"}){};obj.constructor`,'INCOMPLETE')
 native('method-call-'+name,`declare const method:()=>void;const obj={constructor:"label",method};${wrap('obj.method')}();obj.constructor`,'INCOMPLETE')
 native('method-property-assignment-call-'+name,`declare const method:()=>void;const obj={constructor:"label",method:method};${wrap('obj.method')}();obj.constructor`,'INCOMPLETE')
 native('read-default-rhs-'+name,`const obj={constructor:"label"};let token;({value:token=${wrap('obj.constructor')}}={});token`,'PASS')
 native('computed-read-'+name,`const obj={constructor:"label"};let token;({[${wrap('obj.constructor')}]:token}={});token`,'PASS')
 // Neutral real helper observations. Labels only, never native capability evidence.
 for(const pattern of ['direct','object','array','default','nested-object','rest-array']) {
  const lhs=pattern==='direct'?wrap('token'):pattern==='object'?`{value:${wrap('token')}}`:pattern==='array'?`[${wrap('token')}]`:pattern==='default'?`{value:${wrap('token')}="fallback"}`:pattern==='nested-object'?`{data:{value:${wrap('token')}}}`:`[...${wrap('token')}]`
  const text=`const seed="label";let token;(${lhs}=seed);token`
  const {source,nodes,parseErrors}=parse(text);const lexical=createBoundaryLexical(ts,source)
  const assignment=nodes.find(n=>ts.isBinaryExpression(n)&&n.operatorToken.kind===ts.SyntaxKind.EqualsToken)
  const leaves=[]
  assignedValues(ts,assignment.left,assignment.right,n=>n&&ts.isStringLiteralLike(n)?n.text:undefined,(target,value)=>leaves.push({target:target.getText(source),valueKind:ts.SyntaxKind[value.kind]}))
  results.push({id:'assigned-values-'+pattern+'-'+name,evidence:'real-helper-AST-callback-only',text,parseErrors,expectedMinimumCallbacks:1,leaves,meetsExpected:leaves.length>=1,fixtureExecuted:false})
 }
}
for(const ext of ['cjs','cts','mjs','mts']) for(const name of ['require','module','exports','__filename','__dirname']) for(const mode of ['static','outer','static-pattern','outer-pattern']) {
 const declaration=mode.includes('pattern')?`var {value:${name}}={value:"label"}`:`var ${name}="label"`
 const text=mode.startsWith('static')?`class C{static{${declaration};read(${name})}}observe(${name})`:`${declaration};read(${name})`
 const {source,nodes,parseErrors}=parse(text,ext);const cjs=['cjs','cts'].includes(ext);const lexical=createBoundaryLexical(ts,source,cjs)
 const ids=nodes.filter(n=>ts.isIdentifier(n)&&n.text===name);const keys=ids.map(lexical.identity);const cells=[...new Set(keys)]
 const globalUses=keys.map(k=>k===lexical.global(name))
 const expectedGlobalUses=mode.startsWith('static')?[false,false,true]:cjs?[true,true]:[false,false]
 results.push({id:'identity-'+ext+'-'+name+'-'+mode,evidence:'real-lexical-identity',text,ext,parseErrors,actualGroups:keys.map(k=>cells.indexOf(k)),globalUses,expectedGlobalUses,meetsExpected:JSON.stringify(globalUses)===JSON.stringify(expectedGlobalUses),declarations:cells.map(k=>k.declarations?.map(d=>({kind:ts.SyntaxKind[d.kind],text:d.getText(source)}))??[]),fixtureExecuted:false})
}
native('scope-other-cell','const obj={constructor:"label"};function f(){const obj={constructor:"label"};obj.constructor="other"};obj.constructor','INCOMPLETE').interpretation='Whole-file uncertainty comes from the inner mutated constructor; this is not evidence of poisoning the outer cell. The exploratory expectation PASS was withdrawn after inspecting the diagnostic.'
native('scope-neutral-cell','const obj={constructor:"label"};function f(){let obj="label";(obj as any)="other"};obj.constructor','PASS')
native('scope-nested-write-outer','const obj={constructor:"label"};function f(){obj.constructor="other"};obj.constructor','INCOMPLETE')
native('cjs-static-scalar','class C{static{var module="label";read(module)}}','PASS','cjs')
native('cjs-static-pattern-scalar','class C{static{var {value:module}={value:"label"};read(module)}}','PASS','cjs')
native('neutral-pattern','declare const record:{value:unknown};let token;({value:(token as any)}=record);export {token}','PASS')
native('unknown-constructor-declaration','declare const record:{constructor:unknown};const {constructor:token}=record;export {token}','INCOMPLETE')
for(const [name,wrap] of wrappers) {
 native('method-parameter-'+name,`export function label(method:()=>void){const obj={constructor:"label",method:method};${wrap('obj.method')}();return obj.constructor}`,'INCOMPLETE')
 native('selection-parameter-'+name,`export function label(record:{constructor:unknown}){let token;({constructor:${wrap('token')}}=record);return token}`,'INCOMPLETE')
 native('scalar-for-pattern-'+name,`declare const replacement:unknown;const scalar="label";for([${wrap('scalar')}] of [[replacement]]){};const obj={constructor:scalar};obj.constructor`,'INCOMPLETE')
 native('object-for-pattern-'+name,`declare const replacement:unknown;const obj={constructor:"label"};for({value:${wrap('obj.constructor')}} of [{value:replacement}]){};obj.constructor`,'INCOMPLETE')
 native('delete-property-'+name,`const obj={constructor:"label"};delete ${wrap('obj.constructor')};obj.constructor`,'INCOMPLETE')
 native('update-scalar-'+name,`const scalar=1;${wrap('scalar')}++;const obj={constructor:scalar};obj.constructor`,'INCOMPLETE')
}
for(const ext of ['cjs','cts']) for(const mode of ['simple','pattern'])
 native('wrapper-module-native-'+ext+'-'+mode,mode==='simple'?'var module="label";read(module)':'var {value:module}={value:"label"};read(module)','INCOMPLETE',ext)
const summary={node:process.version,total:results.length,parseErrors:results.filter(r=>r.parseErrors.length).length,fixtureExecutions:0,counts:Object.fromEntries([...new Set(results.map(r=>r.evidence))].map(e=>[e,{total:results.filter(r=>r.evidence===e).length,mismatches:results.filter(r=>r.evidence===e&&!r.meetsExpected).length}])),mismatches:results.filter(r=>!r.meetsExpected).map(r=>r.id)}
fs.writeFileSync(path.join(out,'probes-results.json'),JSON.stringify({summary,results},null,2)+'\n')
console.log(JSON.stringify(summary,null,2))
