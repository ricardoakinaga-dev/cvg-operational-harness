import os,json,hashlib,stat,sys
from pathlib import Path
P=Path(__file__).resolve().parent.parent
S=P/'source'
O=P/'output'
def capture():
 result={}
 def visit(p):
  t=p.lstat(); k=str(p.relative_to(P)); row={'kind':'dir' if stat.S_ISDIR(t.st_mode) else 'link' if stat.S_ISLNK(t.st_mode) else 'file','inode':t.st_ino,'device':t.st_dev,'mtime_ns':t.st_mtime_ns,'mode':t.st_mode,'size':t.st_size,'nlink':t.st_nlink}
  if row['kind']=='file': row['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
  if row['kind']=='link': row['target']=os.readlink(p)
  result[k]=row
  if row['kind']=='dir':
   for q in sorted(p.iterdir()): visit(q)
 visit(S)
 for name in ['authority.json','freeze.json','frozen-inventory.json']: visit(P/name)
 return result
phase=sys.argv[1]
now=capture()
(O/('integrity-'+phase+'.json')).write_text(json.dumps(now,indent=2))
inv=json.loads((P/'frozen-inventory.json').read_text())
sha=hashlib.sha256((P/'frozen-inventory.json').read_bytes()).hexdigest()
errors=[]
for k,v in inv.items():
 a=now.get('source/'+k,{})
 if a.get('kind')!=v['kind'] or (v['kind']=='file' and (a.get('sha256')!=v['sha256'] or a.get('size')!=v['bytes'])) or (v['kind']=='link' and a.get('target')!=v['target']): errors.append(k)
actual={k[7:] for k,v in now.items() if k.startswith('source/') and v['kind']!='dir'}
errors+=sorted(actual-set(inv))
summary={'phase':phase,'freeze_sha256':sha,'freeze_valid':sha=='70659412f9a715d51e82db01e684d9576d9fc0eb6b274ab2c03d5e1a4f779059','frozen_entries':len(inv),'inventory_mismatches':errors,'full_entries':len(now),'directories':sum(v['kind']=='dir' for v in now.values()),'source_vendor_dist_included':True}
if phase=='after':
 before=json.loads((O/'integrity-before.json').read_text())
 changes=[k for k in sorted(set(now)|set(before)) if now.get(k)!=before.get(k)]
 summary.update(before_after_changes=changes,full_integrity_valid=not changes and not errors and summary['freeze_valid'])
(O/('integrity-'+phase+'-summary.json')).write_text(json.dumps(summary,indent=2))
print(json.dumps(summary))
