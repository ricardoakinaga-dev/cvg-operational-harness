# Comandos e reprodução

Todos os comandos de projeto foram executados no packet; nenhuma operação no Root da sessão.

1. Leitura inicial, nesta ordem: `authority.json`, `freeze.json`, `frozen-inventory.json`, `source/docs/07_agents/AGENTS.md` (Python stdlib para leitura; sem bibliotecas externas).
2. `python3 output/integrity.py before`
3. Inspeção textual completa dos três módulos `source/scripts/{boundary-lexical,boundary-code-execution,check-product-boundary}.mjs`, da suíte `source/tests/product-boundary-lexical-static.test.js` e da configuração `source/vitest.config.mts`, por `cat`, `sed`, `nl`; nenhum fixture importado.
4. `python3 output/copy-runtime.py` — cópia física por `copy2`; nenhum inode de arquivo compartilhado e nenhum symlink externo. `source` não é destino de cache.
5. No diretório `output/runtime`, comando nativo exato:

```sh
TMPDIR='/home/ricardo/.cache/cvg-harness-green-20261004/c1-write-wrappers-review-r7/output/tmp' TMP='/home/ricardo/.cache/cvg-harness-green-20261004/c1-write-wrappers-review-r7/output/tmp' TEMP='/home/ricardo/.cache/cvg-harness-green-20261004/c1-write-wrappers-review-r7/output/tmp' XDG_CACHE_HOME='/home/ricardo/.cache/cvg-harness-green-20261004/c1-write-wrappers-review-r7/output/cache' /home/ricardo/.nvm/versions/node/v22.23.2/bin/node node_modules/vitest/vitest.mjs run tests/product-boundary-lexical-static.test.js --pool=threads --maxWorkers=1 --no-file-parallelism --reporter=default --reporter=json --outputFile=../logs/vitest-native.json > ../logs/vitest-native.log 2>&1
```

Exit code: 0. Vitest 4.1.11, 276 testes, uma test file. O JSON conta 8 suites incluindo agrupamento; há 7 grupos `describe` concretos. Worker threads são infraestrutura do runner. Nenhuma outra suíte foi selecionada.

6. No packet:

```sh
/home/ricardo/.nvm/versions/node/v22.23.2/bin/node output/probes.mjs > output/logs/probes.log 2>&1
```

Exit code: 0 significa que o driver coletou os resultados; **não** significa que os controles concordaram. Há 34 divergências nativas. O driver foi ampliado após a primeira coleta, mantendo os casos; a expectativa exploratória de `scope-other-cell` foi corrigida de PASS para INCOMPLETE após inspeção do diagnóstico interno, registrada em `interpretation`. O controle separado `scope-neutral-cell` verifica isolamento sem a incerteza local daquele caso.

7. Comparação SHA-256 dos módulos, suíte e config copiados com o snapshot inicial: [trusted-runtime-check.json](trusted-runtime-check.json).
8. `python3 output/integrity.py after`
9. `python3 output/write-report.py` — geração dos relatórios e ledgers exclusivamente em `output`; nenhum gate instalado, build, certificação, teste code-execution, PG, Docker, rede, commit ou subagente.

Reproduzir probes não exige instalação ou configuração global: todas as dependências importadas estão em `output/runtime/node_modules`; nenhum fixture é importado, avaliado ou executado. A infraestrutura Python usa somente stdlib para copiar, inventariar e gerar documentos; não é utilizada como evidência de aceitação do projeto. O Node de execução do projeto é exclusivamente o absoluto autorizado.
