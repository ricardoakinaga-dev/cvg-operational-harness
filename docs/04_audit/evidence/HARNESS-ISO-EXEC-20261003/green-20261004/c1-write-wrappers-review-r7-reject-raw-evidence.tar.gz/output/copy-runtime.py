import shutil,json,os
from pathlib import Path
p=Path(__file__).resolve().parent.parent;s=p/'source';d=p/'output/runtime'
links=[]
for f in s.rglob('*'):
 if f.is_symlink():
  target=f.resolve();target.relative_to(s)
  links.append({'path':str(f.relative_to(s)),'target':os.readlink(f)})
shutil.copytree(s,d,symlinks=True,copy_function=shutil.copy2)
errors=[];files=0
for f in d.rglob('*'):
 if f.is_symlink(): f.resolve().relative_to(d)
 elif f.is_file():
  files+=1;a=f.stat();b=(s/f.relative_to(d)).stat()
  if a.st_ino==b.st_ino and a.st_dev==b.st_dev:errors.append(str(f))
(p/'output/runtime-copy.json').write_text(json.dumps({'physical_files':files,'internal_symlinks':links,'shared_inodes':errors,'external_symlinks':[]},indent=2))
print('Copied',files,'files;',len(links),'internal links; shared inodes',errors)
