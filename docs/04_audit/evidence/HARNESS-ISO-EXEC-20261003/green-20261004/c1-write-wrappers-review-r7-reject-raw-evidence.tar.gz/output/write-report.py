from pathlib import Path
import json,collections
O=Path(__file__).resolve().parent
p=json.loads((O/'probes-results.json').read_text())
integrity=json.loads((O/'integrity-after-summary.json').read_text())
supplied=json.loads((O/'logs/vitest-native.json').read_text())
assert integrity['full_integrity_valid']
assert supplied['numTotalTests']==276 and supplied['numPassedTests']==276 and supplied['numFailedTests']==0
rows=p['results'];native=[r for r in rows if r['evidence']=='native-auditProductBoundary']
findings=[
 {'id':'C1-R7-F1','priority':'P1','title':'TS write-target wrappers drop selected values at assignment-pattern leaves','location':{'path':'runtime/scripts/boundary-lexical.mjs','line':365},'consumers':[{'path':'runtime/scripts/boundary-code-execution.mjs','line':359},{'path':'runtime/scripts/check-product-boundary.mjs','line':793}],'nativeEvidence':True,'nativeMismatchCount':20,'nativeProbeIds':[r['id'] for r in native if not r['meetsExpected'] and 'selection' in r['id']],'reproducer':'probes/selection-as/packages/core/src/entry.mts','expected':'INCOMPLETE with UNVERIFIED_DYNAMIC_CODE_EXECUTION','actual':'PASS; passed=true; empty diagnostics and violations','control':'selection-plain, selection-paren and unknown-constructor-declaration are INCOMPLETE; neutral-pattern is PASS','mechanism':'assignedValues unwraps ParenthesizedExpression but not AsExpression, SatisfiesExpression, NonNullExpression or TypeAssertionExpression. Selected constructor values never reach the original token identity. Both consumers use this real helper, but end-to-end false PASS evidence here is from the dynamic-code consumer. No loader-native bypass is claimed.','impact':'A transparent erased wrapper changes the static gate from unknown to PASS for the same unknown constructor value. The real checker conservatively treats an unproved constructor selection as executor; no fixture executor is present or run.','helperEvidence':'30 of 42 AST callback controls omit leaves; these counts are structural helper evidence, not native capability acceptance.'},
 {'id':'C1-R7-F2','priority':'P1','title':'Wrapped method calls retain an unstable own scalar property proof','location':{'path':'runtime/scripts/boundary-code-execution.mjs','line':176},'nativeEvidence':True,'nativeMismatchCount':12,'nativeProbeIds':[r['id'] for r in native if not r['meetsExpected'] and r['id'].startswith('method')],'reproducer':'probes/method-parameter-as/packages/core/src/entry.mts','expected':'INCOMPLETE with UNVERIFIED_DYNAMIC_CODE_EXECUTION','actual':'PASS; passed=true; empty diagnostics and violations','control':'method-parameter-plain and method-property-assignment-call-plain are INCOMPLETE. All 7 property mutation controls are INCOMPLETE; scalar reads remain PASS.','mechanism':'stableInitializer checks CallExpression/NewExpression only at the property access immediate parent. Parentheses or erased TS wrappers place the call above that parent and admit the object as stable. Ordinary (obj.method)() preserves the receiver and can mutate the object.','impact':'The analyzer certifies obj.constructor as a fixed scalar across an unknown receiver method invocation. Only inert text with an unknown method parameter was parsed and audited; no mutation implementation or evaluator payload was generated or executed.'},
 {'id':'C1-R7-F3','priority':'P2','title':'Destructured outer CJS var declarations lose wrapper parameter identity','location':{'path':'runtime/scripts/boundary-lexical.mjs','line':217},'nativeEvidence':True,'nativeMismatchCount':2,'nativeProbeIds':[r['id'] for r in native if not r['meetsExpected'] and r['id'].startswith('wrapper-module-native')],'reproducer':'probes/wrapper-module-native-cjs-pattern/packages/core/src/entry.cjs','expected':'Outer CJS var leaves share lexical.global(name); conservative module control remains INCOMPLETE','actual':'BindingElement symbol is treated as a separate local cell; module pattern control is PASS in cjs and cts','control':'All 40 static-block identity cases preserve own cells; simple outer cjs/cts vars use wrapper globals; mjs/mts pattern vars use local cells.','mechanism':'wrapperVar requires every symbol declaration to be VariableDeclaration. TypeScript binds a destructured name through BindingElement, so the same outer wrapper parameter is not recognized.','impact':'Lexical identity and checker behavior depend on declaration shape. This is an identity/conservative-policy defect; the neutral scalar initializer does not itself demonstrate dangerous runtime acquisition.','lexicalEvidence':'10 mismatches in 80 real identity controls, covering five wrapper names in cjs and cts. No labels or injected checker were used.'}
]
report={'reviewId':'C1_WRITE_WRAPPERS_FRESH_REVIEW_R7','verdict':'REJECT','verdictScope':'Static lexical/value identity, erased TS write wrappers, scalar-proof stability; no installed/global/production acceptance','claim':'Task already claimed by Lead; no competing claim or repository mutation','freezeSha256':integrity['freeze_sha256'],'installedGate':{'status':'INCOMPLETE','executed':False,'passInferred':False,'basis':'User-supplied scope; this review neither measures nor grants installed acceptance'},'findings':findings,'counts':{'suppliedVitest':{'runner':'Vitest 4.1.11 native','node':'v22.23.2','testFiles':1,'total':276,'passed':276,'failed':0,'skipped':0,'exitCode':0,'auditProductBoundaryCases':167,'otherASTSymbolicSourceCases':109,'description':'All 276 executed by native runner; 167 directly call unmodified auditProductBoundary, 109 use lexical/AST/source/symbolic or injected analyzer checks'},'own':p['summary'],'ownNativeObserved':dict(collections.Counter(r['observed'] for r in native)),'ownNativeExpected':dict(collections.Counter(r['expected'] for r in native))},'integrity':integrity,'runtimeCopy':{'physicalFiles':19334,'internalLinks':48,'sharedInodes':0,'externalSymlinks':0,'trustedModulesSuiteConfigPreserved':True},'boundaries':{'writes':'output/** only','fixtureExecutions':0,'fixtureImports':0,'fixtureEvaluations':0,'newEvaluatorProcessWorkerVMPayloads':0,'trustedNativeWorkerThreads':'runner infrastructure only','codeExecutionSuiteRun':False,'stubsOrCompatibilityRunner':False,'rootOtherCandidatesHistorySkillsPriorReportsRead':False,'networkProvidersPGDockerSubagentsCommit':False,'semanticHistoryRead':False,'inventoryHashingIncludesAllFrozenFiles':True,'secretsEnvRead':False,'repairProvided':False,'notes':'Host shell/text tools and Python stdlib were used for integrity, physical copying and document generation. Project runtime and native test/probe execution used only the approved absolute Node22 and physically copied packet dependencies.'},'evidence':{'report':'report.md','commands':'commands.md','driver':'probes.mjs','probes':'probes-results.json','probesLog':'logs/probes.log','vitestJson':'logs/vitest-native.json','vitestLog':'logs/vitest-native.log','integrityDriver':'integrity.py','integrityBefore':'integrity-before.json','integrityAfter':'integrity-after.json','integritySummary':'integrity-after-summary.json','integrityLog':'logs/integrity-after.log','runtimeCopyDriver':'copy-runtime.py','runtimeCopy':'runtime-copy.json','trustedRuntimeCheck':'trusted-runtime-check.json','suppliedAbstractProofs':'tmp/r4-neutral-proofs.json'},'limitations':['No fixture execution or installed/global/production acceptance.','No claim that abstract seed-label or injected analyzer results prove native loader integration.','Own controls prove static contract mismatches, not a demonstrated runtime exploitation chain.','Read access time is not compared: hashes, file/link kind, size, mode, device/inode, nlink, mtime_ns and all source directory metadata are compared.'],'followUp':'Lead adjudicates findings and any separate repair cycle; preserve current cases and conservative contract. No correction is supplied.'}
(O/'report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
(O/'report.md').write_text('''# C1_WRITE_WRAPPERS_FRESH_REVIEW_R7 — REJECT estático escopado

**REJECT.** Dois defeitos P1 produzem falsos `PASS` no `auditProductBoundary` real; um P2 perde identidade de parâmetros do wrapper CJS. A suíte fornecida executou **276/276** testes no Vitest nativo. Isso não cobre os controles abaixo e não concede aceitação instalada/global/produção. O gate instalado permanece **INCOMPLETE**, sem execução ou inferência de PASS nesta crítica.

## Evidência e contagens

| Evidência | Total | Concordam | Divergem |
| --- | ---: | ---: | ---: |
| Suíte fornecida, Vitest 4.1.11 nativo / Node 22.23.2 | 276 | 276 | 0 |
| Probes próprios, `auditProductBoundary` real e sem injeção | 137 | 103 | 34 |
| Identidades reais de `createBoundaryLexical` / binder TS | 80 | 70 | 10 |
| Callbacks reais de `assignedValues`, evidência AST estrutural | 42 | 12 | 30 |

Todos os **259** probes próprios têm zero erros de parse; nenhum fixture foi executado/importado/avaliado. Dos 137 audits reais, 25 controles neutros esperavam PASS e passaram; 112 esperavam INCOMPLETE, dos quais 78 permaneceram INCOMPLETE e 34 retornaram PASS indevidamente. Esses 34 se dividem em 20 seleções de constructor, 12 chamadas envoltas e 2 controles de identidade/política CJS. O driver retorna 0 pela coleta concluída; as divergências constam no JSON e fundamentam REJECT.

Os 276 testes foram executados pelo runner nativo, mas apenas **167** chamam diretamente o `auditProductBoundary` sem alteração; os outros **109** são provas AST/identidade/source/simbólicas ou usam injeção de identidade no analyzer. Labels abstratos e injeção de `global` da suíte fornecida não são evidência de integração nativa do loader. Nesta revisão própria não houve injeção, stub ou harness compatível.

Evidências: [log Vitest](logs/vitest-native.log), [JSON Vitest](logs/vitest-native.json), [driver próprio](probes.mjs), [resultados completos](probes-results.json), [log de probes](logs/probes.log), [provas simbólicas fornecidas](tmp/r4-neutral-proofs.json), [comandos](commands.md).

## C1-R7-F1 — P1: wrappers TS perdem valores selecionados em folhas de assignment patterns

Local: [boundary-lexical.mjs](runtime/scripts/boundary-lexical.mjs), `assignedValues`, linha 365. Consumidores reais: [boundary-code-execution.mjs](runtime/scripts/boundary-code-execution.mjs), `visitBinding`, e [check-product-boundary.mjs](runtime/scripts/check-product-boundary.mjs), fixed point de aliases.

Reprodução mínima inerte ([arquivo](probes/selection-as/packages/core/src/entry.mts)):

```ts
declare const record:{constructor:unknown};
let token;
({constructor:(token as any)}=record);
export {token};
```

Esperado: `INCOMPLETE` / `UNVERIFIED_DYNAMIC_CODE_EXECUTION`. Observado: **PASS**, `passed=true`, diagnósticos e violações vazios. Os controles `selection-plain`, `selection-paren` e `unknown-constructor-declaration` retornam INCOMPLETE; `neutral-pattern`, selecionando a chave comum `value`, permanece PASS. O caso sem ambient declaration, [selection-parameter-as](probes/selection-parameter-as/packages/core/src/entry.mts), também reproduz o falso PASS.

`assignedValues` remove somente ParenthesizedExpression do alvo. AsExpression, SatisfiesExpression, NonNullExpression, TypeAssertionExpression e combinações encerram a recursão sem callback para `token`. O checker real perde a seleção `record["constructor"]`, que sua política classifica como capacidade incerta quando não há prova escalar. **20** audits reais reproduzem isso em patterns simples, aninhados, com defaults e em função com parâmetro desconhecido. Separadamente, **30/42** controles AST confirmam callbacks ausentes em alvos diretos, objeto, array, default, nested e rest. Esses callbacks provam a falha estrutural comum aos dois consumidores; o falso PASS nativo demonstrado aqui pertence ao consumidor dynamic-code. Não se afirma bypass nativo do loader com base em labels.

## C1-R7-F2 — P1: chamada envolta mantém prova escalar instável

Local: [boundary-code-execution.mjs](runtime/scripts/boundary-code-execution.mjs), `stableInitializer`, linhas 176–185.

Reprodução mínima inerte ([arquivo](probes/method-parameter-as/packages/core/src/entry.mts)):

```ts
export function label(method:()=>void){
  const obj={constructor:"label",method:method};
  (obj.method as any)();
  return obj.constructor;
}
```

Esperado: `INCOMPLETE` / `UNVERIFIED_DYNAMIC_CODE_EXECUTION`; observado: **PASS** e nenhum diagnóstico. `method-parameter-plain` retorna INCOMPLETE. Até o mero controle `(obj.method)()` retorna PASS. Parênteses e wrappers TS preservam o receiver da chamada: o método desconhecido pode alterar o objeto. Nenhuma implementação desse método foi gerada ou executada.

A estabilidade do objeto recusa chamadas somente quando a propriedade tem CallExpression/NewExpression como parent imediato. Os wrappers separam a propriedade desse parent; o objeto segue considerado estável e `constructor` mantém indevidamente a prova escalar. **12** audits reais reproduzem a diferença em contexto superior e em função com parâmetro. As mutações diretas, updates, delete e patterns continuam INCOMPLETE, portanto o defeito não é falta geral de detecção de writes.

## C1-R7-F3 — P2: `var` CJS destructurado perde identidade do wrapper externo

Local: [boundary-lexical.mjs](runtime/scripts/boundary-lexical.mjs), `wrapperVar`, linha 217.

Texto neutro: `var {value:module}={value:"label"};read(module)` ([cjs](probes/wrapper-module-native-cjs-pattern/packages/core/src/entry.cjs), [cts](probes/wrapper-module-native-cts-pattern/packages/core/src/entry.cts)). O binder fornece BindingElement para a declaração destructurada; `wrapperVar` exige VariableDeclaration e devolve símbolo local. Em Node CJS, o `var` externo redeclara a célula do parâmetro `module`, mesmo via pattern. O controle simples `var module="label";read(module)` é INCOMPLETE pela política conservadora existente; o pattern é PASS.

**10/80** provas reais de identidade divergem: cinco nomes (`require`, `module`, `exports`, `__filename`, `__dirname`) em cjs/cts externos destructurados. Todos os **40** casos em static block mantêm corretamente célula própria, inclusive patterns; os controles simples externos CJS e externos ESM também se comportam como esperado. Os **2** audits nativos de `module` documentam a diferença de política. O initializer neutro não demonstra aquisição perigosa em runtime: este finding é de identidade e consistência conservadora, não uma cadeia de exploração demonstrada.

## Controles e contrato preservado

Plain/parênteses/`as`/`satisfies`/non-null/assertion/nested foram comparados. Reads escalares, defaults RHS e computed keys neutras passam; assignment/compound da suíte fornecida e assignment/update/delete/for-in/for-of/patterns próprios invalidam a prova escalar. Há controles de células distintas, writes em closure externa, static blocks, wrapper externo e extensões cjs/cts/mjs/mts. O caso exploratório `scope-other-cell` não é finding: sua expectativa inicial PASS foi revista para INCOMPLETE porque o audit inclui a incerteza do objeto interno; isso está registrado no resultado. `scope-neutral-cell` fornece o controle separado de isolamento.

A suíte original code-execution não foi executada. Os três módulos reais, a suíte 276 e a config foram inspecionados e copiados sem alteração; [SHA checks](trusted-runtime-check.json). Nenhum contrato foi relaxado e nenhuma correção é fornecida.

## Freeze, integridade e limites

SHA-256 confirmado: `70659412f9a715d51e82db01e684d9576d9fc0eb6b274ab2c03d5e1a4f779059`.

**Full integrity válida**: 19.382 entries congeladas (19.334 arquivos e 48 links), 1.970 diretórios, 21.355 entries protegidas no snapshot, zero mismatches do inventário e **zero alterações antes/depois**. Cobertura recursiva integral de `source`, dependências/vendor e todos os `dist`, sem exclusão de árvores. Foram comparados SHA-256, espécie, tamanho, targets dos links, modo, dispositivo/inode, nlink e mtime em nanossegundos, incluindo diretórios. Atime de leitura não é critério de imutabilidade. As três autoridades JSON também foram comparadas. Arquivos históricos foram somente hashados no inventário, sem leitura semântica de histórico/pareceres.

Runtime: **19.334 cópias físicas**, nenhum hardlink/arquivo com inode compartilhado, 48 symlinks internos e nenhum externo. Temp/cache/resultados permanecem em output. Worker threads são somente infraestrutura Vitest. [Cópia](runtime-copy.json), [driver de cópia](copy-runtime.py), [before](integrity-before.json), [after](integrity-after.json), [resumo válido](integrity-after-summary.json), [driver de integridade](integrity.py), [log](logs/integrity-after.log).

Leitura inicial restrita às três autoridades e constituição interna. Nenhuma operação no Root, outros candidatos, skills, pareceres prévios, segredos/.env, rede/providers, PG/Docker, subagentes ou commit. Shell/text tools e Python stdlib serviram apenas à infraestrutura de leitura, hashing, cópia e documentos; toda execução do projeto usou o Node absoluto autorizado e dependências do packet copiadas fisicamente. Escrita exclusiva `output/**`; nenhum arquivo confiável modificado. A task já estava claimed pelo Lead.

A conclusão cobre exclusivamente a soundness estática definida. Os probes demonstram divergências do checker real, sem executar fixtures ou construir payloads evaluator/process/worker/VM. Não se infere aceitação instalada/global/produção. Próximo passo pertence ao Lead: adjudicar findings e conduzir eventual ciclo separado, preservando casos e contrato.

Ledgers locais: [state](state.json), [execution log](execution-log.md), [backlog](backlog.json). Versão estruturada: [report.json](report.json).
''')
state={'task':'C1_WRITE_WRAPPERS_FRESH_REVIEW_R7','status':'COMPLETED','last_completed_action':'Static independent review, supplied native 276 suite, real inert probes, full integrity and REJECT report','next_action':'Lead adjudication of C1-R7-F1/F2/F3; separate authorized repair/review cycle if pursued','verdict':'REJECT','installed_gate':'INCOMPLETE','writes':'output/**','full_integrity_valid':True}
(O/'state.json').write_text(json.dumps(state,indent=2)+'\n')
(O/'execution-log.md').write_text('''# Local execution log — C1_WRITE_WRAPPERS_FRESH_REVIEW_R7

Task claimed by Lead. Authority read before inspection. Frozen inventory SHA verified; full protected source/deps/dist/directory metadata snapshot captured before copy/run. Physical runtime copied to output. Trusted native Vitest 4.1.11 under absolute Node22 ran only product-boundary-lexical-static: 276 passed, 0 failed/skipped, exit 0. Independent inert probes: 137 unmodified audits, 80 real lexical identities, 42 real-helper AST callbacks; zero parse errors and fixture executions. Findings: P1 wrappers lose selected values; P1 wrapped calls retain unstable scalar proof; P2 destructured outer CJS var identity. Full integrity after: zero content/metadata changes; valid. Verdict REJECT static scoped; installed gate INCOMPLETE. No fix, no commit, no source ledger mutation. Evidence and exact commands are in report.md/report.json/commands.md. Next action: Lead adjudication, separate repair cycle if authorized.
''')
(O/'backlog.json').write_text(json.dumps({'scope':'local output only; no change to repository backlog','items':[{'id':f['id'],'priority':f['priority'],'status':'OPEN_FOR_LEAD_ADJUDICATION','title':f['title'],'evidence':'report.json'} for f in findings]},indent=2)+'\n')
print(json.dumps({'verdict':report['verdict'],'findings':[(f['id'],f['priority']) for f in findings],'fullIntegrityValid':integrity['full_integrity_valid'],'reports':['report.md','report.json']}))
