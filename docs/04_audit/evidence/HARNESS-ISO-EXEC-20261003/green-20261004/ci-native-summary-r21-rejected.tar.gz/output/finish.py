from pathlib import Path
import json,hashlib,stat,datetime,subprocess
OUT=Path(__file__).resolve().parent;S=Path('/home/ricardo/.cache/cvg-harness-green-20261004/candidate-ci-summary-r21');O=S.parent/'candidate-final-r19';R=OUT/'runtime'
def write(p,v): (OUT/p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def record(root,p):
 f=root/p;st=f.lstat();assert stat.S_ISREG(st.st_mode),p
 return {'path':p,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'mode':oct(stat.S_IMODE(st.st_mode)),'mtimeNs':st.st_mtime_ns,'size':st.st_size}
checks=[]
for label,root in [('source',S),('original',O)]:
 before=json.loads((OUT/f'{label}-before.json').read_text());after=[record(root,r['path']) for r in before];write(f'{label}-after.json',after);drift=[{'before':a,'after':b} for a,b in zip(before,after) if a!=b];checks.append({'root':str(root),'inputCount':len(before),'exactBytesModesMtimeSize':not drift,'drift':drift})
write('integrity.json',{'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'immutableInputs':checks,'wholeMutableGeneratedSourceCachesFrozen':False,'generatedOutputsOutsideScope':'Source certification/build/cache outputs may change during Lead native certification; neither read for verdict nor executed nor written'})
delta=json.loads((OUT/'delta.json').read_text());baseline=json.loads((OUT/'baseline-comparison.json').read_text());probes=json.loads((OUT/'probes.json').read_text());commands=json.loads((OUT/'commands.json').read_text());assert delta['exactFour'];assert all(c['exactBytesModesMtimeSize'] for c in checks);assert all(x['originalEqualsSource'] and x['sourceMatchesDeclaredHash'] for x in baseline['files']);assert probes['checks']==97 and probes['passed']==79
sourcebefore={f['path']:f for f in json.loads((OUT/'source-before.json').read_text())};originalbefore={f['path']:f for f in json.loads((OUT/'original-before.json').read_text())};contract=json.loads((R/'scripts/hiso-ci-scopes.json').read_text());declared=contract['baselineInventory']['sha256']
limits={'globalCertification':'NOT_RUN; scoped parser/delta/preparation review only','PGNetworkProvidersInstallSubagents':'NOT_RUN; no external network authorized, runtime network denied by preload','originalBaselineBinding':{'declared':declared,'originalActual':originalbefore['scripts/hiso-baseline-inventory.json']['sha256'],'sourceActual':sourcebefore['scripts/hiso-baseline-inventory.json']['sha256'],'classification':'INHERITED mismatch already present in original; unchanged contract, not a new scoped finding and not the reason for verdict'},'firstSummaryAndTotalPolicy':'Existing prefix matching, first-summary choice, duplicate count accumulation and explicit-parenthesized-total authority preserved on plain and supported SGR logs. This review does not redesign these policies.','scope':'four-path delta and directly referenced code/config/test inputs; no complete production/release/coverage execution verdict','newIndependentReviewer':'No prior review/context read; no subagents used; no candidate implementation by this reviewer','failedHarnessAttempt':'First generator accidentally re-decorated escape-sequence digits. Artifacts retained under probes-attempt1.*. Corrected generator has no SGR failures; OSC-space failures independently reproduced with six manually constructed controls.'}
write('limitations.json',limits)
finding={'id':'R21-ANSI-OSC-001','priority':'P2','severity':'correctness','confidence':'EXECUTED Node v22.23.2','path':'scripts/lib/certification-rules.mjs','line':557,'expected':'Terminal OSC decoration must not hide an otherwise present summary or change the first-summary result.','input':'\\x1b]0;Vitest controlled title\\x07Tests 1 failed (1)\\nTests 999 passed (999)','expectedResult':{'passed':0,'failed':1,'skipped':0,'total':1},'actualResult':{'passed':999,'failed':0,'skipped':0,'total':999},'isolatedSummaryActual':None,'cause':'Node 22 stripVTControlCharacters leaves the OSC payload when the title contains spaces; startsWith(label) ignores that line.','impact':'Incomplete terminal normalization; the first failed summary can disappear and a later passed summary can be selected. This is a parser demonstration, not a claim that a full certificate was issued.','originalBehavior':'The original also does not understand this OSC form. This is an unclosed ANSI normalization edge in the changed parser, not a newly introduced plain-log regression.','evidence':['osc-reproduction.json','traces/osc-reproduction.stdout.log','traces/osc-reproduction.stderr.log','probes.json'],'recommendedAction':'Handle this controlled OSC form within terminal normalization, and add isolated-failure/first-summary regression cases; preserve existing counts, totals, metadata and collector rules.'}
write('findings.json',[finding])
write('verdict.json',{'task':'CI_NATIVE_SUMMARY_FRESH_REVIEW_R21','verdict':'REJECT','scope':'Parser ANSI normalization including present/first-summary semantics; delta and isolated preparation separately PASS','reasons':[finding['id']],'checks':{'exactFourPaths':'PASS','original371FilesAndMetadata':'PASS','newTests46to47OneAddition':'PASS','coverage275plus6equals281Unchanged':'PASS','declaredInteger47Only':'PASS','ownNode22GitHEADGitignoreCollector':'PASS','generatedViteCacheUntrackedIgnored':'PASS','immutableBeforeAfter':'PASS','newTestsUncolored':'15/15 PASS','scopedTestsRealANSI':'214/214 PASS','syntheticFailedSkippedRealANSI':'expected failure exit 1; parser counts 1 passed, 1 failed, 1 skipped, total 3','independentProbes':'79/97 PASS; all 18 failures are OSC-space cases'},'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'findingCount':1,'productionReleaseApproval':False,'sourceOrOriginalMutationByReviewer':False,'nextAction':'Lead may resolve R21-ANSI-OSC-001 and submit a bounded re-review; no Source patch made here.'})
report='''# CI native summary — fresh review R21

**REJECT no escopo ANSI/presença/primeiro resumo.** O delta de quatro caminhos, a preparação isolada e os casos SGR reais foram aprovados separadamente. Uma falha concreta permanece: `scripts/lib/certification-rules.mjs:557` depende de `stripVTControlCharacters`, que em Node 22.23.2 deixa parte de um OSC cujo título contém espaços.

## Achado R21-ANSI-OSC-001 (P2, reproduzido)

Entrada controlada válida de título OSC, com BEL como terminador:

```js
'\\x1b]0;Vitest controlled title\\x07Tests 1 failed (1)\\nTests 999 passed (999)'
```

Esperado: `{ passed: 0, failed: 1, skipped: 0, total: 1 }`.
Observado: `{ passed: 999, failed: 0, skipped: 0, total: 999 }`.
Sem a segunda linha, o resumo existente retorna `null`. O terminador ST também reproduz a falha. Os controles sem cor, SGR e OSC sem espaços retornam o primeiro resumo corretamente. O normalizador deixa `;Vitest controlled title` antes do label; a busca ignora a primeira linha. O comportamento original também não reconhecia esse OSC: trata-se de uma lacuna não fechada da normalização ANSI proposta, sem regressão demonstrada para logs comuns. Não se afirma emissão de certificado incorreto.

Reprodução: `osc-reproduction.mjs`, `osc-reproduction.json` e `traces/osc-reproduction.*.log`. A execução independente encerrou em 1 ao verificar o resultado esperado. Remediação limitada: tratar esse OSC e adicionar controles de presença e primeiro resumo, mantendo as regras existentes de contagem, total e escopo.

## Evidência aprovada

- Comparados 1.011 inputs diretamente relevantes; exatamente quatro diferenças: parser, novo arquivo de 15 testes, uma inclusão em `baseline.newTests` e inteiro 46 → 47 em `tests/hiso-ci-scopes.test.js`. Diff em `delta.patch`.
- Os 371 arquivos da baseline estão idênticos ao original em bytes e correspondem aos hashes declarados; os registros originais também estão idênticos. As 46 adições anteriores permanecem, com exatamente uma nova e nenhuma remoção. Cobertura permanece 275 + 6 = 281, sem alteração de inventário/configuração.
- Node 22.23.2, dependências copiadas fisicamente, Git próprio com HEAD válido, `.gitignore` existente preservado. Cache Vite gerado presente, ignorado por `node_modules/` e ausente do índice. Função do collector e listas de exclusão idênticas ao original; um input próprio não ignorado foi incluído e um input sintético ignorado foi excluído. Não foi acrescida exclusão ao collector.
- 15/15 novos casos sem cor; 214/214 casos dos dois arquivos com ANSI real do Vitest. Um runtime sintético separado produziu log ANSI com 1 passed, 1 failed, 1 skipped (3), exit 1 esperado; o parser preservou os números.
- Probes corrigidos: 79/97 aprovados; os 18 reprovados são variações OSC com espaços. Casos comuns/SGR: falha, skip, zero, total explícito/implícito, ausência, primeiro resumo e denominadores separados preservados.
- Antes/depois: bytes, modos, mtime em nanossegundos e tamanhos exatos para os inputs imutáveis do Source e do original, incluindo os quatro caminhos, bibliotecas do projeto e configs referenciadas. Veja `integrity.json` e manifests `*-before/after.json`. Outputs de certificação/build/cache mutáveis do Lead não foram congelados.

## Limites e transparência

Revisão independente do candidato, sem contexto/julgamentos prévios, sem subagents e sem alterar Source/original. Nenhuma leitura de Root AGENTS/coordination/99/20/30 ou reviews anteriores. Instruções normativas do projeto: somente `Source/docs/07_agents/AGENTS.md`; a autorização específica do usuário prevalece quanto a ledgers e cache externos. Bootstrap genérico do engineering-framework usado apenas para revisão/evidências. Sem PG, provider, instalação ou rede externa; execução Node foi feita em inputs próprios e a rede foi bloqueada por preload.

A primeira versão do meu gerador SGR redecorava dígitos dos próprios escapes. Corrigi apenas o gerador, preservei os rastros em `probes-attempt1.*` e reproduzi a falha OSC em strings construídas manualmente. Nenhum erro desse gerador fundamenta o veredito.

O hash de baseline em `scripts/hiso-ci-scopes.json` já divergia no original e continua divergente; isso foi registrado em `limitations.json` como condição herdada, sem ampliar o delta, sem executar certificação global e sem fundamentar esta rejeição. Esta revisão não concede aprovação global de produto, produção, desempenho ou release. A crítica do OSC é finita e local ao parser; não exige congelamento de caches mutáveis.

Próxima ação: corrigir R21-ANSI-OSC-001 e repetir apenas a revisão limitada afetada. Nenhuma implementação do candidato foi feita aqui.
'''
(OUT/'report.md').write_text(report)
write('review-state.json',{'status':'COMPLETED','last_completed_action':'Independent finite review completed with REJECT R21-ANSI-OSC-001','next_action':'Lead remediation and bounded re-review','backlog':'no repository backlog write authorized; finding captured in output/findings.json','log':'output/commands.json and traces','noSourceWrites':True})
artifacts=[]
for p in sorted(OUT.rglob('*')):
 if not p.is_file() or p.is_symlink() or p.relative_to(OUT).parts[0] in ['runtime','original-runtime','synthetic-runtime','tmp','npm-cache']:continue
 if p.name=='manifest.json':continue
 st=p.stat();artifacts.append({'path':p.relative_to(OUT).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':st.st_size,'mode':oct(stat.S_IMODE(st.st_mode))})
write('manifest.json',{'task':'CI_NATIVE_SUMMARY_FRESH_REVIEW_R21','verdict':'REJECT','sourceRoot':str(S),'originalRoot':str(O),'runtimeRoot':str(R),'fourInputRecords':[sourcebefore[p] for p in delta['expectedPaths']],'ownRuntimeInputsManifest':'own-candidate-record.json','sourceBefore':'source-before.json','sourceAfter':'source-after.json','originalBefore':'original-before.json','originalAfter':'original-after.json','artifacts':artifacts,'rawRuntimeTreesExcludedFromEvidenceArtifactList':'Inputs bound separately; synthetic fixture is reproducible from synthetic-run.py and files; generated temp/cache output not part of review identity.'})
print(json.dumps({'verdict':'REJECT','finding':finding['id'],'sourceInputsUnchanged':checks[0]['inputCount'],'originalInputsUnchanged':checks[1]['inputCount'],'report':str(OUT/'report.md'),'artifactCount':len(artifacts)}))
