# CI native summary — fresh review R21

**REJECT no escopo ANSI/presença/primeiro resumo.** O delta de quatro caminhos, a preparação isolada e os casos SGR reais foram aprovados separadamente. Uma falha concreta permanece: `scripts/lib/certification-rules.mjs:557` depende de `stripVTControlCharacters`, que em Node 22.23.2 deixa parte de um OSC cujo título contém espaços.

## Achado R21-ANSI-OSC-001 (P2, reproduzido)

Entrada controlada válida de título OSC, com BEL como terminador:

```js
'\x1b]0;Vitest controlled title\x07Tests 1 failed (1)\nTests 999 passed (999)'
```

Esperado: `{ passed: 0, failed: 1, skipped: 0, total: 1 }`.
Observado: `{ passed: 999, failed: 0, skipped: 0, total: 999 }`.
Sem a segunda linha, o resumo existente retorna `null`. O terminador ST também reproduz a falha. Os controles sem cor, SGR e OSC sem espaços retornam o primeiro resumo corretamente. O normalizador deixa `;Vitest controlled title` antes do label; a busca ignora a primeira linha. O comportamento original também não reconhecia esse OSC: trata-se de uma lacuna não fechada da normalização ANSI proposta, sem regressão demonstrada para logs comuns. Não se afirma emissão de certificado incorreto.

Reprodução: `osc-reproduction.mjs`, `osc-reproduction.json` e `traces/osc-reproduction.*.log`. A execução independente encerrou em 1 ao verificar o resultado esperado. Remediação limitada: tratar esse OSC e adicionar controles de presença e primeiro resumo, mantendo as regras existentes de contagem, total e escopo.

## Evidência aprovada

- Comparados 1.011 inputs diretamente relevantes; exatamente quatro diferenças: parser, novo arquivo de 15 testes, uma inclusão em `baseline.newTests` e inteiro 46 → 47 em `tests/hiso-ci-scopes.test.js`. Diff em `delta.patch`.
- Os 371 arquivos da baseline estão idênticos ao original em bytes e correspondem aos hashes declarados; os registros originais também estão idênticos. As 46 adições anteriores permanecem, com exatamente uma nova e nenhuma remoção. Cobertura permanece 275 + 6 = 281, sem alteração de inventário/configuração.
- Node 22.23.2, dependências copiadas fisicamente, Git próprio com HEAD válido, `.gitignore` existente preservado. Cache Vite gerado presente, ignorado por `node_modules/` e ausente do índice. Função do collector e listas de exclusão idênticas ao original; um input próprio não ignorado foi incluído e um input sintético ignorado foi excluído. Não foi acrescida exclusão ao collector.
- 15/15 novos casos sem cor; 214/214 casos dos dois arquivos com ANSI real do Vitest. Um runtime sintético separado produziu log ANSI com 1 passed, 1 failed, 1 skipped (3), exit 1 esperado; o parser preservou os números.
- Probes corrigidos: 79/97 aprovados; os 18 reprovados são variações OSC com espaços. Casos comuns/SGR: falha, skip, zero, total explícito/implícito, ausência, primeiro resumo e denominadores separados preservados.
- Antes/depois: bytes, modos, mtime em nanossegundos e tamanhos exatos para os inputs imutáveis do Source e do original, incluindo os quatro caminhos, bibliotecas do projeto e configs referenciadas. Veja `integrity.json` e manifests `*-before/after.json`. Outputs de certificação/build/cache mutáveis do Lead não foram congelados.

## Limites e transparência

Revisão independente do candidato, sem contexto/julgamentos prévios, sem subagents e sem alterar Source/original. Nenhuma leitura de Root AGENTS/coordination/99/20/30 ou reviews anteriores. Instruções normativas do projeto: somente `Source/docs/07_agents/AGENTS.md`; a autorização específica do usuário prevalece quanto a ledgers e cache externos. Bootstrap genérico do engineering-framework usado apenas para revisão/evidências. Sem PG, provider, instalação ou rede externa; execução Node foi feita em inputs próprios e a rede foi bloqueada por preload.

A primeira versão do meu gerador SGR redecorava dígitos dos próprios escapes. Corrigi apenas o gerador, preservei os rastros em `probes-attempt1.*` e reproduzi a falha OSC em strings construídas manualmente. Nenhum erro desse gerador fundamenta o veredito.

O hash de baseline em `scripts/hiso-ci-scopes.json` já divergia no original e continua divergente; isso foi registrado em `limitations.json` como condição herdada, sem ampliar o delta, sem executar certificação global e sem fundamentar esta rejeição. Esta revisão não concede aprovação global de produto, produção, desempenho ou release. A crítica do OSC é finita e local ao parser; não exige congelamento de caches mutáveis.

Próxima ação: corrigir R21-ANSI-OSC-001 e repetir apenas a revisão limitada afetada. Nenhuma implementação do candidato foi feita aqui.
