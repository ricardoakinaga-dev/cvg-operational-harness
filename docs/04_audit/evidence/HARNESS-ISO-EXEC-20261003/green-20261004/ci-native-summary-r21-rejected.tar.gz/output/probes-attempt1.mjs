import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { stripVTControlCharacters } from 'node:util'
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import * as current from './runtime/scripts/lib/certification-rules.mjs'
import * as original from './original-runtime/scripts/lib/certification-rules.mjs'
const out = import.meta.dirname, runtime = path.join(out,'runtime')
const results=[]
const check=(name,fn)=>{try {const detail=fn();results.push({name,status:'PASS',detail})} catch(e) {results.push({name,status:'FAIL',error:e.stack})}}
const plain=(passed,failed,skipped,total)=>({passed,failed,skipped,total})
const fixtures=[
 ['normal-test','banner\n Tests 7 passed (7)\n','Tests',plain(7,0,0,7)],
 ['normal-file','Test Files 3 passed (3)','Test Files',plain(3,0,0,3)],
 ['mixed-status','Tests 2 passed | 1 failed | 3 skipped (6)','Tests',plain(2,1,3,6)],
 ['fail-only','Tests 2 failed (2)','Tests',plain(0,2,0,2)],
 ['skip-only','Tests 3 skipped (3)','Tests',plain(0,0,3,3)],
 ['zero','Tests 0 passed (0)','Tests',plain(0,0,0,0)],
 ['implicit-total','Tests 3 skipped | 1 failed | 2 passed','Tests',plain(2,1,3,6)],
 ['explicit-total-authority','Tests 2 passed (9)','Tests',plain(2,0,0,9)],
 ['repeated-status','Tests 2 passed | 3 passed (5)','Tests',plain(5,0,0,5)],
 ['missing','','Tests',null],
 ['missing-no-summary','runner output only','Tests',null],
 ['separate-label','Test Files 7 passed (7)','Tests',null],
 ['first-failure','Tests 1 failed (1)\nTests 900 passed (900)','Tests',plain(0,1,0,1)],
 ['first-pass','Tests 1 passed (1)\nTests 900 failed (900)','Tests',plain(1,0,0,1)],
 ['denominators','Test Files 2 passed (2)\nTests 11 passed (11)','Tests',plain(11,0,0,11)],
 ['crlf','header\r\n \tTests 12 passed (12)\r\n','Tests',plain(12,0,0,12)],
 ['empty-first-inherited','Tests\nTests 2 passed (2)','Tests',plain(0,0,0,0)]
]
for(const [name,log,label,expected] of fixtures) check(name,()=>{assert.deepEqual(current.parseVitestSummary(log,label),expected); assert.deepEqual(original.parseVitestSummary(log,label),expected);return {log,label,expected,originalParity:true}})
const decorations={
 sgr:s=>'\x1b[2m\x1b[32m'+s+'\x1b[39m\x1b[22m',
 tokenSplit:s=>s.replace(/(Tests|Test Files)/,'\x1b[2m$1\x1b[22m').replace(/(\d+)/g,'\x1b[1m$1\x1b[22m').replace(/(passed|failed|skipped)/g,'\x1b[32m$1\x1b[39m'),
 eraseCursor:s=>'\x1b[2K\x1b[1G'+s+'\x1b[K',
 oscBel:s=>'\x1b]0;Vitest controlled title\x07'+s,
 oscST:s=>'\x1b]0;Vitest controlled title\x1b\\'+s,
 csiC1:s=>'\x9b32m'+s+'\x9b0m'
}
for(const [name,log,label,expected] of fixtures.slice(0,9))for(const [d,decorate] of Object.entries(decorations))check(name+'-'+d,()=>{const decorated=decorate(log);assert.equal(stripVTControlCharacters(decorated),log);const got=current.parseVitestSummary(decorated,label);assert.deepEqual(got,expected);assert.deepEqual(got,original.parseVitestSummary(log,label));return {log:decorated,label,expected}})
check('first-colored-failure-before-pass',()=>{const log='Test Files 1 failed (1)\n\x1b[2m Tests\x1b[22m \x1b[31m1 failed\x1b[39m (1)\nTests 999 passed (999)';assert.deepEqual(current.parseVitestSummary(log,'Tests'),plain(0,1,0,1));return {log,original:original.parseVitestSummary(log,'Tests'),current:current.parseVitestSummary(log,'Tests')}})
const realRuns=[['new-test-uncolored',plain(15,0,0,15),plain(1,0,0,1)],['scoped-tests-colored',plain(214,0,0,214),plain(2,0,0,2)],['synthetic-fail-skip',plain(1,1,1,3),plain(0,1,0,1)]]
for(const [name,tests,files] of realRuns)check('real-log-'+name,()=>{const log=fs.readFileSync(path.join(out,'traces',name+'.stdout.log'),'utf8');assert.deepEqual(current.parseVitestSummary(log,'Tests'),tests);assert.deepEqual(current.parseVitestSummary(log,'Test Files'),files);const ansi=log.includes('\x1b[');if(name!=='new-test-uncolored'){assert.equal(ansi,true);assert.equal(original.parseVitestSummary(log,'Tests'),null)}else assert.equal(ansi,false);return {ansi,tests,files,originalRaw:original.parseVitestSummary(log,'Tests'),sourceRaw:current.parseVitestSummary(log,'Tests'),originalPlain:original.parseVitestSummary(stripVTControlCharacters(log),'Tests')}})
const git=(...args)=>{const p=spawnSync('git',args,{cwd:runtime,encoding:'utf8'});assert.equal(p.status,0,p.stderr);return p.stdout}
check('own-preparation-and-collector-preserves-input-scope',()=>{
 assert.match(git('rev-parse','--verify','HEAD^{commit}').trim(),/^[0-9a-f]{40}$/)
 assert.equal(git('status','--porcelain'),'')
 assert.deepEqual(current.CANDIDATE_EXCLUDED_PREFIXES,original.CANDIDATE_EXCLUDED_PREFIXES)
 assert.deepEqual(current.CANDIDATE_EXCLUDED_FILES,original.CANDIDATE_EXCLUDED_FILES)
 assert.equal(current.collectCandidateFiles.toString(),original.collectCandidateFiles.toString())
 const before=current.collectCandidateFiles(runtime);const old=original.collectCandidateFiles(runtime);assert.deepEqual(before,old)
 const marker=path.join(runtime,'r21-nonignored-probe.txt'),ignored=path.join(runtime,'.env');assert(!fs.existsSync(marker));assert(!fs.existsSync(ignored))
 try{fs.writeFileSync(marker,'SYNTHETIC NONIGNORED CANDIDATE INPUT\n');fs.writeFileSync(ignored,'SYNTHETIC IGNORED INPUT ONLY\n');const rows=current.collectCandidateFiles(runtime);assert.equal(rows.find(x=>x.path==='r21-nonignored-probe.txt')?.tracked,false);assert(!rows.some(x=>x.path==='.env'));assert(!rows.some(x=>x.path.startsWith('node_modules/')))}finally{fs.rmSync(marker,{force:true});fs.rmSync(ignored,{force:true})}
 const after=current.collectCandidateFiles(runtime);assert.deepEqual(after,before)
 const record=current.buildCandidateRecord({root:runtime,files:after});current.CandidateRecordSchema.parse(record)
 fs.writeFileSync(path.join(out,'own-candidate-record.json'),JSON.stringify(record,null,2)+'\n')
 const cache='node_modules/.vite/vitest/da39a3ee5e6b4b0d3255bfef95601890afd80709/results.json';assert(fs.existsSync(path.join(runtime,cache)));assert.equal(git('ls-files','--',cache),'');const ignore=git('check-ignore','-v','--',cache).trim();assert(ignore.includes('.gitignore'))
 assert.equal(git('status','--porcelain'),'');return {head:record.git.head,inputCount:before.length,nonignoredMarkerIncluded:true,ignoredEnvExcluded:true,collectorExact:true,cacheExists:true,cacheTracked:false,cacheIgnoredBy:ignore,wholeMutableSourceFreezeRequired:false}
})
const hash=b=>createHash('sha256').update(b).digest('hex')
check('metadata-and-original-test-integer-exact',()=>{const before=JSON.parse(fs.readFileSync(path.join(out,'original-before.json')));const lookup=new Map(before.map(x=>[x.path,x]));const text=fs.readFileSync(path.join(runtime,'tests/hiso-ci-scopes.test.js'),'utf8');assert.equal(text.split('expect(baseline.newTests).toHaveLength(47)').length,2);assert.equal(hash(text.replace('expect(baseline.newTests).toHaveLength(47)','expect(baseline.newTests).toHaveLength(46)')),lookup.get('tests/hiso-ci-scopes.test.js').sha256);const baseline=JSON.parse(fs.readFileSync(path.join(runtime,'scripts/hiso-baseline-inventory.json')));assert.equal(baseline.tests.length,371);assert.equal(baseline.newTests.length,47);assert.equal(baseline.newTests.filter(x=>x==='tests/certification-summary-ansi-own.test.js').length,1);assert.equal(baseline.coveragePaths.length,275);assert.equal(baseline.newCoveragePaths.length,6);return {changedExpectedIntegerOnly:true,originalTests:371,newTests:47,coverage:281}})
const failures=results.filter(x=>x.status!=='PASS');fs.writeFileSync(path.join(out,'probes.json'),JSON.stringify({node:process.version,checks:results.length,passed:results.length-failures.length,failures,results},null,2)+'\n');console.log(JSON.stringify({checks:results.length,passed:results.length-failures.length,failures}));if(failures.length)process.exitCode=1
