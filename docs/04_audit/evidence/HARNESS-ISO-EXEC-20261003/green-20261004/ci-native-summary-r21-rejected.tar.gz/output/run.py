from pathlib import Path
import subprocess,os,json,time
OUT=Path('/home/ricardo/.cache/cvg-harness-green-20261004/ci-native-summary-fresh-review-r21/output'); R=OUT/'runtime'; NODE=Path('/home/ricardo/.nvm/versions/node/v22.23.2/bin/node')
env={'PATH':str(NODE.parent)+':/usr/bin:/bin','HOME':os.environ['HOME'],'TMPDIR':str(OUT/'tmp'),'NODE_OPTIONS':'--import='+str(OUT/'offline-guard.mjs'),'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','npm_config_cache':str(OUT/'npm-cache'),'NPM_CONFIG_AUDIT':'false','NPM_CONFIG_FUND':'false'}
records=[]
def run(name,args,extra=None,timeout=60):
 start=time.time(); p=subprocess.run([str(NODE),*args],cwd=R,env={**env,**(extra or {})},capture_output=True,timeout=timeout)
 (OUT/'traces'/f'{name}.stdout.log').write_bytes(p.stdout); (OUT/'traces'/f'{name}.stderr.log').write_bytes(p.stderr)
 records.append({'id':name,'command':[str(NODE),*args],'cwd':str(R),'exitStatus':p.returncode,'durationSeconds':round(time.time()-start,3),'stdout':f'traces/{name}.stdout.log','stderr':f'traces/{name}.stderr.log','network':'denied by preload','nodeOptions':env['NODE_OPTIONS']})
 (OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n'); print(json.dumps(records[-1]),flush=True)
run('node-version',['--version'])
run('new-test-uncolored',['node_modules/vitest/vitest.mjs','run','tests/certification-summary-ansi-own.test.js','--no-file-parallelism','--maxWorkers=2'],{'NO_COLOR':'1','FORCE_COLOR':'0'})
run('scoped-tests-colored',['node_modules/vitest/vitest.mjs','run','tests/certification-summary-ansi-own.test.js','tests/hiso-ci-scopes.test.js','--no-file-parallelism','--maxWorkers=2'],{'FORCE_COLOR':'1'})
