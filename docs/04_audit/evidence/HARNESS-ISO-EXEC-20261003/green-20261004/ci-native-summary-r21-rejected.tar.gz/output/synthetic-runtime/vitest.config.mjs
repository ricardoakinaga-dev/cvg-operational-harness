export default { test: { environment: 'node', include: ['summary.test.js'] } }
