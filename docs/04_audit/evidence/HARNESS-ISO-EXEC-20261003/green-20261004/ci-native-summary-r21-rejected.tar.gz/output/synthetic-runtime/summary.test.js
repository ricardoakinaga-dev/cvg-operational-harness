import { it, expect } from 'vitest'
it('controlled passed case', () => expect(1).toBe(1))
it('controlled failed case', () => expect(1).toBe(2))
it.skip('controlled skipped case', () => expect(1).toBe(1))
