from pathlib import Path
import subprocess,json,os,time
out=Path(__file__).resolve().parent;node='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node';records=json.loads((out/'commands.json').read_text())
for name,script in [('independent-probes-corrected','probes.mjs'),('osc-reproduction','osc-reproduction.mjs')]:
 cmd=[node,'--import',str(out/'offline-guard.mjs'),str(out/script)];start=time.time();p=subprocess.run(cmd,cwd=out/'runtime',env={'PATH':str(Path(node).parent)+':/usr/bin:/bin','HOME':os.environ['HOME'],'TMPDIR':str(out/'tmp'),'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null'},capture_output=True,timeout=30)
 (out/f'traces/{name}.stdout.log').write_bytes(p.stdout);(out/f'traces/{name}.stderr.log').write_bytes(p.stderr);records.append({'id':name,'command':cmd,'cwd':str(out/'runtime'),'exitStatus':p.returncode,'durationSeconds':round(time.time()-start,3),'stdout':f'traces/{name}.stdout.log','stderr':f'traces/{name}.stderr.log'});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps({'id':name,'exitStatus':p.returncode}));print(p.stdout.decode()[:2200])
