import net from 'node:net'
import tls from 'node:tls'
import http from 'node:http'
import https from 'node:https'
import { syncBuiltinESMExports } from 'node:module'
const deny = () => { throw new Error('R21_REVIEW_EXTERNAL_NETWORK_FORBIDDEN') }
net.connect = deny; net.createConnection = deny; net.Socket.prototype.connect = deny
tls.connect = deny
http.request = deny; http.get = deny; https.request = deny; https.get = deny
globalThis.fetch = deny
syncBuiltinESMExports()
