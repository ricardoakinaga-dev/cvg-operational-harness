from pathlib import Path
import subprocess,os,json,time
out=Path('/home/ricardo/.cache/cvg-harness-green-20261004/ci-native-summary-fresh-review-r21/output'); node='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node'; start=time.time()
cmd=[node,str(out/'runtime/node_modules/vitest/vitest.mjs'),'run','--no-file-parallelism','--maxWorkers=2']
env={'PATH':str(Path(node).parent)+':/usr/bin:/bin','HOME':os.environ['HOME'],'TMPDIR':str(out/'tmp'),'NODE_OPTIONS':'--import='+str(out/'offline-guard.mjs'),'FORCE_COLOR':'1'}
p=subprocess.run(cmd,cwd=out/'synthetic-runtime',env=env,capture_output=True,timeout=30)
(out/'traces/synthetic-fail-skip.stdout.log').write_bytes(p.stdout); (out/'traces/synthetic-fail-skip.stderr.log').write_bytes(p.stderr)
record={'id':'synthetic-fail-skip','command':cmd,'cwd':str(out/'synthetic-runtime'),'exitStatus':p.returncode,'expectedExitStatus':1,'durationSeconds':round(time.time()-start,3),'stdout':'traces/synthetic-fail-skip.stdout.log','stderr':'traces/synthetic-fail-skip.stderr.log','network':'denied by preload','synthetic':True}
records=json.loads((out/'commands.json').read_text()); records.append(record); (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n'); print(json.dumps(record))
assert p.returncode==1
