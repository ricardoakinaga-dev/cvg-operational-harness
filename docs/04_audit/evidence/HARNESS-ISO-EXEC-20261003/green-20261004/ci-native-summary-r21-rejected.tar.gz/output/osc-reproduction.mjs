import fs from 'node:fs'
import assert from 'node:assert/strict'
import { stripVTControlCharacters } from 'node:util'
import { parseVitestSummary } from './runtime/scripts/lib/certification-rules.mjs'
const inputs={
 plain:'Tests 1 failed (1)\nTests 999 passed (999)',
 sgr:'\x1b[2mTests\x1b[22m \x1b[31m1 failed\x1b[39m (1)\nTests 999 passed (999)',
 oscNoSpaces:'\x1b]0;vitest\x07Tests 1 failed (1)\nTests 999 passed (999)',
 oscSpaces:'\x1b]0;Vitest controlled title\x07Tests 1 failed (1)\nTests 999 passed (999)',
 oscSpaceIsolated:'\x1b]0;Vitest controlled title\x07Tests 1 failed (1)',
 oscSpacesST:'\x1b]0;Vitest controlled title\x1b\\Tests 1 failed (1)\nTests 999 passed (999)'
}
const observations=Object.entries(inputs).map(([id,log])=>({id,log,stripped:stripVTControlCharacters(log),actual:parseVitestSummary(log,'Tests'),expected:{passed:0,failed:1,skipped:0,total:1}}))
fs.writeFileSync(new URL('./osc-reproduction.json',import.meta.url),JSON.stringify({node:process.version,observations},null,2)+'\n')
console.log(JSON.stringify({node:process.version,observations},null,2))
assert.deepEqual(observations.find(x=>x.id==='oscSpaces').actual,{passed:0,failed:1,skipped:0,total:1},'valid OSC title must not hide the first failed summary')
