from pathlib import Path
import os,json,hashlib,stat,shutil,subprocess,difflib
P=Path('/home/ricardo/.cache/cvg-harness-green-20261004/ci-native-summary-fresh-review-r21'); S=Path('/home/ricardo/.cache/cvg-harness-green-20261004/candidate-ci-summary-r21'); O=S.parent/'candidate-final-r19'; OUT=P/'output'; R=OUT/'runtime'
assert not R.exists(), 'own runtime must be new'
OUT.mkdir(exist_ok=True); (OUT/'traces').mkdir(exist_ok=True); (OUT/'tmp').mkdir(exist_ok=True)
paths=['scripts/lib/certification-rules.mjs','tests/certification-summary-ansi-own.test.js','scripts/hiso-baseline-inventory.json','tests/hiso-ci-scopes.test.js']
trees=['scripts','tests','apps','packages','legacy','products','config','.github']
roots=['package.json','package-lock.json','.gitignore','.gitattributes','.nvmrc','vitest.config.mts','vite.config.mts','eslint.config.js','playwright.config.ts','playwright.rem21-014.config.ts']+[p.name for p in S.glob('tsconfig*.json')]+['docs/doc-link-policy.json','docs/02_spec/0180_shared_transport_ci_security.md']
def admitted(p):
 rel=p.relative_to(S)
 return not any(x in ['node_modules','dist','.git','.vite','.vite-temp'] for x in rel.parts) and not p.name.endswith(('.tsbuildinfo','.js.map','.d.ts.map')) and not (rel.parts[0] in ['apps','packages'] and 'src' in rel.parts and p.suffix in ['.js','.map']) and not (rel.parts[0] in ['apps','packages'] and 'src' in rel.parts and p.name.endswith('.d.ts'))
inputs=sorted({p.relative_to(S).as_posix() for t in trees for p in (S/t).rglob('*') if p.is_file() and admitted(p)}|set(roots))
def record(root,p):
 f=root/p; st=f.lstat(); assert stat.S_ISREG(st.st_mode),p
 return {'path':p,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'mode':oct(stat.S_IMODE(st.st_mode)),'mtimeNs':st.st_mtime_ns,'size':st.st_size}
def write(p,v): (OUT/p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
write('source-before.json',[record(S,p) for p in inputs]); write('original-before.json',[record(O,p) for p in inputs if (O/p).is_file()])
changes=[]; diff=[]
for p in inputs:
 b=(S/p).read_bytes(); a=(O/p).read_bytes() if (O/p).is_file() else b''
 if a!=b:
  changes.append(p)
  diff.extend(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='original/'+p,tofile='source/'+p))
write('delta.json',{'expectedPaths':paths,'changedInputPaths':changes,'exactFour':set(changes)==set(paths),'comparedInputCount':len(inputs)})
(OUT/'delta.patch').write_text(''.join(diff))
b=json.loads((S/'scripts/hiso-baseline-inventory.json').read_text()); old=json.loads((O/'scripts/hiso-baseline-inventory.json').read_text()); baseline=[]
for f in b['tests']:
 a=(O/f['path']).read_bytes(); c=(S/f['path']).read_bytes()
 baseline.append({'path':f['path'],'originalEqualsSource':a==c,'sourceMatchesDeclaredHash':hashlib.sha256(c).hexdigest()==f['sha256']})
write('baseline-comparison.json',{'baselineEntries':len(baseline),'baselineIdenticalMetadata':b['tests']==old['tests'],'files':baseline,'newTestsBefore':len(old['newTests']),'newTestsAfter':len(b['newTests']),'additions':sorted(set(b['newTests'])-set(old['newTests'])),'removals':sorted(set(old['newTests'])-set(b['newTests'])),'otherBaselineFieldsEqual':{k:b[k]==v for k,v in old.items() if k!='newTests'},'coverageOriginal':len(b['coveragePaths']),'coverageAdded':len(b['newCoveragePaths']),'coverageTotal':len(set(b['coveragePaths']+b['newCoveragePaths']))})
R.mkdir()
for p in inputs:
 target=R/p; target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(S/p,target)
shutil.copytree(S/'node_modules',R/'node_modules',symlinks=True,ignore=shutil.ignore_patterns('.vite','.vite-temp','.cache'))
escaping=[]
for parent,dirs,files in os.walk(R/'node_modules',followlinks=False):
 for name in dirs+files:
  p=Path(parent)/name
  if p.is_symlink() and not p.resolve().is_relative_to(R): escaping.append(str(p.relative_to(R)))
assert not escaping, escaping
orig=OUT/'original-runtime'; (orig/'scripts').mkdir(parents=True)
shutil.copytree(O/'scripts/lib',orig/'scripts/lib'); os.symlink(R/'node_modules',orig/'node_modules',target_is_directory=True)
env={**os.environ,'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null'}
def git(*args):
 p=subprocess.run(['git',*args],cwd=R,env=env,text=True,capture_output=True); assert p.returncode==0,p.stderr; return p.stdout
logs=[git('init','-q'),git('add','--',*sorted({p.split('/')[0] for p in inputs})),git('-c','user.name=Independent Review R21','-c','user.email=review-r21@invalid.local','-c','commit.gpgsign=false','commit','-qm','Isolated scoped review input snapshot')]
write('preparation.json',{'source':str(S),'original':str(O),'runtime':str(R),'copiedInputs':len(inputs),'sourceHead':subprocess.run(['git','--no-optional-locks','rev-parse','HEAD'],cwd=S,text=True,capture_output=True).stdout.strip(),'ownHead':git('rev-parse','HEAD').strip(),'ownStatus':git('status','--porcelain'),'node':'/home/ricardo/.nvm/versions/node/v22.23.2/bin/node','dependencies':'physical independent copy, no hardlinks; workspace symlinks resolve inside runtime','sourceCacheExecution':False,'wholeMutableSourceFreezeRequired':False})
print(json.dumps({'changedPaths':changes,'inputs':len(inputs),'baselineFiles':len(baseline),'baselineExact':all(f['originalEqualsSource'] and f['sourceMatchesDeclaredHash'] for f in baseline),'ownHead':git('rev-parse','HEAD').strip()}))
