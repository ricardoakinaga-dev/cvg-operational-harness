from pathlib import Path
import shutil,json,hashlib,subprocess,os
b=Path('/home/ricardo/.cache/cvg-harness-green-20261004');root=Path('/home/ricardo/Área de trabalho/cvg-operational-harness');original=b/'candidate-final-r19';ci=b/'candidate-ci-summary-r22';staging=b/'neutral-staging-r22';target=b/'hiso-neutral-final-r22';out=b/'final-neutral-r22';assert not staging.exists() and not target.exists();staging.mkdir();out.mkdir()
manifest=json.loads((root/'docs/04_audit/evidence/HARNESS-ISO-EXEC-20261003/green-20261004/final-r19-frozen-source-manifest.json').read_text())
for record in manifest['nativeFiles']:
    rel=record['path'];src=original/rel;assert hashlib.sha256(src.read_bytes()).hexdigest()==record['sha256'],rel;dest=staging/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
paths=['scripts/lib/certification-rules.mjs','tests/certification-summary-ansi-own.test.js','scripts/hiso-baseline-inventory.json','tests/hiso-ci-scopes.test.js']
for rel in paths:shutil.copy2(ci/rel,staging/rel)
program=out/'prepare.mjs';program.write_text("import fs from 'node:fs';import {prepareVariant} from "+json.dumps((staging/'scripts/hiso-variant.mjs').as_uri())+";const proof=prepareVariant("+json.dumps(str(staging))+","+json.dumps(str(target))+",'harness-neutral');fs.writeFileSync("+json.dumps(str(out/'preparation.json'))+",JSON.stringify(proof,null,2)+'\\n');console.log(JSON.stringify({retained:proof.files.length,removed:proof.removed.length,transforms:proof.transforms.length}));\n")
env={k:v for k,v in os.environ.items() if k in ['HOME','LANG','LC_ALL','TERM']};env['PATH']='/home/ricardo/.nvm/versions/node/v22.23.2/bin:'+os.environ['PATH']
subprocess.run(['/home/ricardo/.nvm/versions/node/v22.23.2/bin/node',str(program)],env=env,check=True)
shutil.copytree(original/'node_modules',target/'node_modules',symlinks=True)
alias=target/'node_modules/@cvg/shift-assistant';assert alias.is_symlink();alias.unlink()
links=[]
for directory,dirs,names in os.walk(target/'node_modules'):
    for name in dirs+names:
        f=Path(directory)/name
        if f.is_symlink():assert f.exists() and f.resolve().is_relative_to(target),f;links.append({'path':str(f.relative_to(target)),'target':str(f.readlink())})
assert not (target/'products').exists() and not (target/'.env').exists()
with (out/'git-preparation.log').open('wb') as stream:
    for cmd in [['git','init','--initial-branch=isolated-neutral-r22'],['git','config','user.name','Codex local synthetic build'],['git','config','user.email','codex-local@example.invalid'],['git','add','--','.'],['git','commit','-m','private: freeze physically product-free R22 source']]:subprocess.run(cmd,cwd=target,env=env,check=True,stdout=stream,stderr=subprocess.STDOUT)
(out/'physical-dependencies.json').write_text(json.dumps({'physicalCopy':True,'hardlinksCreated':False,'internalLinks':links,'privateEnvAbsent':True,'productTreeAndAliasAbsent':True,'privateGitRespectsExistingIgnore':True,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=target).decode().strip()},indent=2)+'\n')
print('NEUTRAL_PHYSICAL_COPY_READY')
