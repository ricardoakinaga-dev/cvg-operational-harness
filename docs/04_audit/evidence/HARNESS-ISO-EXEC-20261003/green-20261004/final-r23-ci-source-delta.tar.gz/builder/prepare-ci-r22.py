from pathlib import Path
import shutil, json
b=Path('/home/ricardo/.cache/cvg-harness-green-20261004')
original=b/'candidate-final-r19'; previous=b/'candidate-ci-summary-r21'; target=b/'candidate-ci-summary-r22'
out=b/'ci-native-osc-r22';out.mkdir(exist_ok=False)
assert not target.exists()
shutil.copytree(original,target,symlinks=True,ignore=lambda d,n:[x for x in n if x=='.git' or x=='.env' or (x.startswith('.env.') and not x.endswith(('example','template','sample')))])
paths=['scripts/lib/certification-rules.mjs','tests/certification-summary-ansi-own.test.js','scripts/hiso-baseline-inventory.json','tests/hiso-ci-scopes.test.js']
for rel in paths:
    shutil.copy2(previous/rel,target/rel)
(out/'task.json').write_text(json.dumps({'task':'CI_NATIVE_OSC_R22','stage':'BUILD','authority':'Continuous user localfix authorization, approved SPEC0180, claim in shared coordination','finding':'R21-ANSI-OSC-001: Node22 stripVTControlCharacters leaves OSC title with spaces, hiding first failure summary','scope':paths,'original':str(original),'previous':str(previous),'target':str(target),'constraints':['No original assertions removed or weakened','baseline47/371 originals/coverage281 unchanged','No provider, key, Root runtime, push or release']},indent=2)+'\n')
config=json.loads((b/'ci-native-summary-r21/focused-r2-config.json').read_text())
config.update(cwd=str(target),output=str(out),name='ci-native-osc-r22-before')
config['command']=[x.replace(str(b/'ci-native-summary-r21/focused-r2-vitest.json'),str(out/'focused-before-vitest.json')) for x in config['command']]
(out/'before-config.json').write_text(json.dumps(config,indent=2)+'\n')
print('ISOLATED_COPY_READY')
