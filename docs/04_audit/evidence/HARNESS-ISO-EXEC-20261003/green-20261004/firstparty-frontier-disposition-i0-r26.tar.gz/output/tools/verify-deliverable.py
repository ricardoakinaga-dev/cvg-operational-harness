import json,pathlib,hashlib,datetime,os,collections
O=pathlib.Path('output');B=json.load(open(O/'baseline.json'));S=pathlib.Path(B['source']);obs=json.load(open('observations.json'));p=json.load(open(O/'proposed-dispositions.json'));raw=json.load(open(O/'raw-ast.json'));controls=json.load(open(O/'raw-ast-controls-bounded.json'));checks=[];records=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
def check(name,result,detail=None):checks.append(dict(check=name,matched=bool(result),detail=detail))
check('222-original-observations-exact-order',len(p['dispositions'])==222 and [x['observation'] for x in p['dispositions']]==obs['rows'])
check('222-raw-ast-rows',len(raw['rows'])==222 and not raw['matchIssues'])
check('unique-row-ids',len({x['id'] for x in p['dispositions']})==222)
for r in p['dispositions']:
 b=r['binding'];f=O/'source-copy'/b['file'];data=f.read_bytes();a=b['ast'];text=data[a['utf8Start']:a['utf8End']].decode();utf16=f.read_text().encode('utf-16-le')[a['start']*2:a['end']*2].decode('utf-16-le')
 check(r['id']+'-hash-offset-text',text==a['text']==utf16 and sha(text.encode())==a['textSha256'] and sha(data)==b['fileSha256'])
 check(r['id']+'-proof-or-specific-pending',bool(r['producer']['summary'] and r['caller'] and r['effect'] and r['evidenceRefs']) and ((bool(r['missingProof']) and r['gateStatus']=='INCOMPLETE') if r['proposedDisposition']=='UNRESOLVED' else (not r['missingProof'] and r['gateStatus']=='PROPOSED_ONLY')))
 check(r['id']+'-all-evidence-refs-resolve',all(x in json.load(open(O/'evidence.json'))['fragments'] for x in r['evidenceRefs']))
for initial in B['readSet']:
 path=S/initial['path'];data=path.read_bytes();current=sha(data);copied=sha((O/'source-copy'/initial['path']).read_bytes());records.append(dict(path=initial['path'],beforeSha256=initial['sha256'],afterSha256=current,copySha256=copied,bytes=len(data),beforeResolvedPath=initial['resolvedPath'],afterResolvedPath=str(path.resolve()),beforeMode=initial['mode'],afterMode=oct(path.stat().st_mode&0o777),unchanged=current==copied==initial['sha256'] and str(path.resolve())==initial['resolvedPath'] and oct(path.stat().st_mode&0o777)==initial['mode']))
check('read-set-bytes-paths-modes-preserved',all(x['unchanged'] for x in records))
inputs=[]
for initial in B['packetInputs']:
 current=sha(pathlib.Path(initial['path']).read_bytes());inputs.append(dict(**initial,afterSha256=current,unchanged=current==initial['sha256']))
check('authority-observations-specs-preserved',all(x['unchanged'] for x in inputs))
links=[]
for initial in B['internalLinks']:
 path=S/initial['path'];current=dict(path=initial['path'],link=os.readlink(path),resolved=str(path.resolve().relative_to(S)));links.append(dict(before=initial,after=current,unchanged=initial==current))
check('48-recorded-internal-links-preserved',len(links)==48 and all(x['unchanged'] for x in links))
check('parser-copy-matches-source',sha(pathlib.Path(B['parser']['path']).read_bytes())==sha((O/'tools/typescript.cjs').read_bytes())==B['parser']['sha256'])
check('node22-effective',raw['node'].startswith('v22.') and controls['node'].startswith('v22.'))
check('bounded-controls-match',len(controls['controls'])==16 and all(x['matched'] for x in controls['controls']))
check('three-source-dist-syntax-relations',len(controls['sourceDistRelations'])==3 and all(x['sameNormalizedTokens'] for x in controls['sourceDistRelations']))
cap=[r for r in p['dispositions'] if 'capability-boundary.' in r['binding']['file']];check('14-capability-reflections-retained',len(cap)==14 and all(x['category']=='DATA_ONLY_REFLECTION' for x in cap))
check('frontier-release-not-accepted',not p['frontierAccepted'] and not p['releaseGranted'] and all(x['independentReview']=='PENDING' for x in p['dispositions']))
report=json.load(open(O/'report.json'));report['otherLaneUserReported']=dict(source='User steering message in this audit; not reproduced or accepted by this lane',nativeR25=dict(units=5735,files=413,status='PASS_USER_REPORTED'),neutral=dict(units=5100,files=385,status='PASS_USER_REPORTED'),fullClosureUnknown=8882);report['deliverableVerification']=dict(artifact='deliverable-verification.json',checks=len(checks),matched=sum(x['matched'] for x in checks));json.dump(report,open(O/'report.json','w'),ensure_ascii=False,indent=2)
integrity=dict(schema='readonly-read-set-integrity-v1',generatedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceReadonly=str(S),scope='Every source/parser/input byte inspected and copied by this lane, plus the 48 recorded internal link targets. No assertion over unread whole-tree bytes.',files=records,packetInputs=inputs,links=links,parser=B['parser'],unchanged=all(x['unchanged'] for x in records+inputs+links),sourceWritesPerformed=False,writeRoot=str(O.resolve()))
json.dump(integrity,open(O/'Sourceintegrity.json','w'),ensure_ascii=False,indent=2)
json.dump(dict(method='Own artifact validation and hash/offset checks only; no candidate test/CLI/payload execution',checks=checks,matched=sum(x['matched'] for x in checks),total=len(checks),failures=[x for x in checks if not x['matched']]),open(O/'deliverable-verification.json','w'),ensure_ascii=False,indent=2)
manifest=[]
for path in sorted(O.rglob('*')):
 if path.is_file() and path.name!='artifact-manifest.json':manifest.append(dict(path=str(path.relative_to(O)),bytes=path.stat().st_size,sha256=sha(path.read_bytes())))
json.dump(dict(schema='i0-delivery-artifact-manifest-v1',artifacts=manifest),open(O/'artifact-manifest.json','w'),ensure_ascii=False,indent=2)
print(json.dumps(dict(checks=len(checks),matched=sum(x['matched'] for x in checks),failures=[x for x in checks if not x['matched']],readSetFiles=len(records),preserved=integrity['unchanged'],internalLinks=len(links),counts=p['counts']),ensure_ascii=False,indent=2))
if any(not x['matched'] for x in checks):raise SystemExit(1)
