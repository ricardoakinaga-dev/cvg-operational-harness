const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),ts=require('./typescript.cjs');
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const parse=s=>ts.createSourceFile('bounded-control.ts',s,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);
function narrowProof(text){const s=parse(text),nodes=[];function walk(n){nodes.push(n);ts.forEachChild(n,walk)}walk(s);
 const calls=nodes.filter(ts.isCallExpression),returns=nodes.filter(ts.isReturnStatement),aliases=new Set();
 for(const n of nodes)if(ts.isVariableDeclaration(n)&&ts.isIdentifier(n.name)&&n.initializer&&ts.isCallExpression(n.initializer)&&/^Object\.(getPrototypeOf|getOwnPropertyDescriptor)$/.test(n.initializer.expression.getText(s)))aliases.add(n.name.text);
 const executableAliases=new Set();for(const n of nodes)if(ts.isVariableDeclaration(n)&&n.initializer&&/\.value$/.test(n.initializer.getText(s)))executableAliases.add(n.name.getText(s));
 const dynamic=calls.some(n=>/^(?:eval|Function|require|Reflect\.get|vm\.runInNewContext)$/.test(n.expression.getText(s))||/\.constructor$|\.value$/.test(n.expression.getText(s))||aliases.has(n.expression.getText(s))||executableAliases.has(n.expression.getText(s)));
 if(dynamic)return'UNRESOLVED';
 if(calls.some(n=>n.expression.getText(s)==='unknown'))return'UNRESOLVED';
 if(returns.some(n=>n.expression&&aliases.has(n.expression.getText(s))))return'UNRESOLVED';
 if(calls.some(n=>n.expression.getText(s)==='runtime.provider'))return'UNRESOLVED';
 for(const n of calls)if(n.expression.getText(s)==='vi.spyOn'&&!['fetch','once','exit'].includes(n.arguments[1]?.text))return'UNRESOLVED';
 if(calls.some(n=>['spawn','spawnSync','promisify'].includes(n.expression.getText(s))))return'UNRESOLVED';
 if(calls.some(n=>n.expression.getText(s)==='process.getBuiltinModule'))return'UNRESOLVED';
 return'PROPOSED_I0_POSITIVE';}
const cases=[
 ['prototype-comparison','function check(value){const prototype=Object.getPrototypeOf(value);return prototype===Object.prototype||prototype===null}', 'PROPOSED_I0_POSITIVE'],
 ['descriptor-data','function stableSerialize(v){if(typeof v===\'function\')throw Error();return JSON.stringify(v)} function encode(value,key){const property=Object.getOwnPropertyDescriptor(value,key);if(!property||!(\'value\' in property))throw Error();return stableSerialize(property.value)}','PROPOSED_I0_POSITIVE'],
 ['prototype-constructor','Object.getPrototypeOf(f).constructor("return process")()','UNRESOLVED'],
 ['prototype-alias-constructor','const p=Object.getPrototypeOf(f);p.constructor("return process")()','UNRESOLVED'],
 ['prototype-return','function check(value){const p=Object.getPrototypeOf(value);return p}','UNRESOLVED'],
 ['descriptor-invocation','const p=Object.getOwnPropertyDescriptor(value,"x");p.value()','UNRESOLVED'],
 ['descriptor-callee-alias','const p=Object.getOwnPropertyDescriptor(value,"x");const run=p.value;run()','UNRESOLVED'],
 ['reflect-global-function','Reflect.get(globalThis,"Function")("return process")()','UNRESOLVED'],
 ['direct-eval','eval("import(x)")','UNRESOLVED'],
 ['vm-entry','vm.runInNewContext(text)','UNRESOLVED'],
 ['namespace-unknown-callee','unknown(process)','UNRESOLVED'],
 ['selected-fetch-spy','vi.spyOn(globalThis,"fetch").mockResolvedValue(new Response("{}"))','PROPOSED_I0_POSITIVE'],
 ['executor-spy-key','vi.spyOn(globalThis,"eval")','UNRESOLVED'],
 ['global-bootstrap-provider','runtime.provider()','UNRESOLVED'],
 ['child-launch','spawnSync(process.execPath,["-e",script])','UNRESOLVED'],
 ['builtin-getter','process.getBuiltinModule(name)','UNRESOLVED']
];
// Track descriptor-derived executable aliases for the deliberately bounded alias control.
const results=cases.map(([id,text,expected])=>{let actual=narrowProof(text);return{id,text,inputSha256:sha(text),expected,actual,matched:actual===expected,astNodes:(()=>{let k=0;function w(n){k++;ts.forEachChild(n,w)}w(parse(text));return k})()}});
const pairs=[['packages/harness/src/capability-boundary.ts','packages/harness/dist/capability-boundary.js'],['packages/shared/src/canonical.ts','packages/shared/dist/canonical.js'],['packages/platform/src/tool-invocation-boundary.ts','packages/platform/dist/tool-invocation-boundary.js']];
function tokens(text){const source=ts.createSourceFile('comparison.js',text,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS),values=[];function walk(n){if(n.kind===ts.SyntaxKind.EndOfFileToken||(n.kind>=ts.SyntaxKind.FirstJSDocNode&&n.kind<=ts.SyntaxKind.LastJSDocNode))return;const children=n.getChildren(source);if(children.length){for(const c of children)walk(c)}else values.push([n.kind,n.text===undefined?n.getText(source):n.text])}walk(source);return values;}
const relations=pairs.map(([source,dist])=>{const a=fs.readFileSync(path.join('output/source-copy',source),'utf8'),b=fs.readFileSync(path.join('output/source-copy',dist),'utf8'),emitted=ts.transpileModule(a,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,removeComments:true}}).outputText;const ea=JSON.stringify(tokens(emitted)),eb=JSON.stringify(tokens(b));return{source,dist,sourceSha256:sha(a),distSha256:sha(b),transformedSourceTokenSha256:sha(ea),distTokenSha256:sha(eb),sameNormalizedTokens:ea===eb,method:'TypeScript syntax transformation and AST leaf comparison, comments/whitespace skipped and string literals decoded; no emitted payload executed; this is not a rebuild or runtime proof'}});
const output={node:process.version,parserVersion:ts.version,scope:'16 authored AST-only controls; selected shapes, not checker execution or universal JS proof',codeExecuted:'Own AST tooling and copied TypeScript parser only',payloadsExecuted:false,controls:results,sourceDistRelations:relations};fs.writeFileSync('output/raw-ast-controls-bounded.json',JSON.stringify(output,null,2));console.log(JSON.stringify({controls:results.length,matched:results.filter(x=>x.matched).length,relations:relations.map(x=>({source:x.source,match:x.sameNormalizedTokens}))}));
