import pathlib,json,hashlib,shutil,os
packet=pathlib.Path.cwd();source=pathlib.Path(json.load(open('authority.json'))['sourceReadonly']);out=packet/'output'
obs=json.load(open('observations.json'))
paths={r['file'].rsplit(':',1)[0] if r['file'].rsplit(':',1)[-1].isdigit() else r['file'] for r in obs['rows']}
paths.update(['scripts/check-product-boundary.mjs','scripts/boundary-code-execution.mjs','scripts/boundary-lexical.mjs','packages/shared/src/lifecycle.ts','packages/platform/src/tool-invocation-boundary.ts','packages/harness/src/capability-boundary.ts','packages/shared/src/canonical.ts','apps/api/src/webhook-security.ts'])
manifest=[]
for rel in sorted(paths):
 p=source/rel; b=p.read_bytes();target=out/'source-copy'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 manifest.append(dict(path=rel,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),mode=oct(p.stat().st_mode & 0o777),resolvedPath=str(p.resolve())))
parser=source/'node_modules/typescript/lib/typescript.js';b=parser.read_bytes();(out/'tools/typescript.cjs').write_bytes(b)
inputs=[]
for p in [packet/'authority.json',packet/'observations.json',*sorted((packet/'normative').glob('0*.md'))]:
 b=p.read_bytes();inputs.append(dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b)))
links=[]
for root,dirs,files in os.walk(source/'node_modules',followlinks=False):
 for name in dirs+files:
  p=pathlib.Path(root)/name
  if p.is_symlink():
   target=p.resolve()
   if target.is_relative_to(source) and not target.is_relative_to(source/'node_modules'):links.append(dict(path=str(p.relative_to(source)),link=os.readlink(p),resolved=str(target.relative_to(source))))
json.dump(dict(source=str(source),readSet=manifest,packetInputs=inputs,parser=dict(path=str(parser),sha256=hashlib.sha256(b if False else parser.read_bytes()).hexdigest()),internalLinks=links),open(out/'baseline.json','w'),ensure_ascii=False,indent=2)
print('read files',len(manifest),'internal links',len(links),'parser bytes',parser.stat().st_size)
