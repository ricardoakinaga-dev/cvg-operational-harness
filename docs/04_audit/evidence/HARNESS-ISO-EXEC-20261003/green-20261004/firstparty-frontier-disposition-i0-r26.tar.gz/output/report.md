# Adjudicação finita I0 — R26

222 observações classificadas: **140 propostas positivas I0**, **82 UNRESOLVED**. Frontier permanece **INCOMPLETE**, revisão independente **PENDING**, sem release. Fonte R22 somente leitura; nenhum source change.

Node efetivo v22.23.2; TypeScript 6.0.3. Perfil fornecido R22exact48internalLinks: 48 links internos inspecionados. Total 8882 é o dado do packet; o CLI não foi reexecutado.

SPEC0178 verifica referências de módulos na gramática descrita; **não é sandbox de JavaScript arbitrário**. Reflexão data-only é classificação do consumo local, não prova universal de ausência de Proxy/traps/callbacks. SPEC0180 conserva escopos, fingerprints e revisão independente. As duas SPECs copiadas estão vinculadas por SHA-256 em report.json/evidence.json.

## Evidência e limites

Cada linha de proposed-dispositions.json conserva a observação original, índice, ordinal da duplicata, source/dist, SHA-256 do arquivo, texto AST/hash, offsets UTF-16 e UTF-8, callee/invocação, produtores lexicais, callers, efeito, dados, referências e prova pendente específica. A emissão original não contém offsets; o mapeamento foi reconstruído pela ordem AST e multiplicidade, conferindo 222/222 sem ambiguidade de quantidade. Não houve deduplicação.

Os bytes reais lidos foram copiados para source-copy; somente o parser TypeScript e ferramentas próprias de AST/hash foram executados. raw-ast.json preserva o AST/contexto e evidence.json preserva trechos hash-bound. Sourceintegrity.json compara antes/depois o read-set e os 48 links; não certifica bytes não lidos.

16 controles AST autorais delimitados: positivos de comparação/descritor/spy selecionado, negativos de constructor, aliases, escape, eval, VM, namespace desconhecido, callback global e processo. Todos 16 corresponderam ao esperado. Não são execução de testes do produto/checker nem prova de completude de JavaScript. Os três pares source/dist coincidiram em folhas AST após transformação sintática TS e exclusão de comentários; nenhum artefato foi reconstruído ou executado.

## Reflexões próprias e limites de capabilities

Os **14 registros de capability-boundary** são apresentados individualmente abaixo. Os guards Object.getPrototypeOf retornam booleanos; descritores têm accessors recusados e property.value segue para stableSerialize, que recusa funções e produz JSON. implementation.validateInput/execute/validateOutput são callbacks reais no mesmo módulo e **não estão aceitos por essas 14 propostas**. A reflexão não adquire/transfere loader no fluxo inspecionado; traps de Proxy não foram declaradas impossíveis.

| ID | Fonte/linha | AST [start,end) | Expressão | Resultado local |
|---|---|---|---|---|
| R26-055 | packages/harness/src/capability-boundary.ts:595 | 18005,18048 | `Object.getOwnPropertyDescriptor(value, key)` | DESCRIPTOR_JSON_DATA |
| R26-056 | packages/harness/src/capability-boundary.ts:596 | 18060,18068 | `property` | DESCRIPTOR_JSON_DATA |
| R26-057 | packages/harness/src/capability-boundary.ts:596 | 18085,18093 | `property` | DESCRIPTOR_JSON_DATA |
| R26-058 | packages/harness/src/capability-boundary.ts:600 | 18239,18253 | `property.value` | DESCRIPTOR_JSON_DATA |
| R26-059 | packages/harness/src/capability-boundary.ts:628 | 18968,18996 | `Object.getPrototypeOf(value)` | PROTOTYPE_BOOLEAN_GUARD |
| R26-060 | packages/harness/src/capability-boundary.ts:629 | 19008,19017 | `prototype` | PROTOTYPE_BOOLEAN_GUARD |
| R26-061 | packages/harness/src/capability-boundary.ts:629 | 19042,19051 | `prototype` | PROTOTYPE_BOOLEAN_GUARD |
| R26-213 | packages/harness/dist/capability-boundary.js:427 | 16206,16249 | `Object.getOwnPropertyDescriptor(value, key)` | DESCRIPTOR_JSON_DATA |
| R26-214 | packages/harness/dist/capability-boundary.js:428 | 16268,16276 | `property` | DESCRIPTOR_JSON_DATA |
| R26-215 | packages/harness/dist/capability-boundary.js:428 | 16293,16301 | `property` | DESCRIPTOR_JSON_DATA |
| R26-216 | packages/harness/dist/capability-boundary.js:431 | 16459,16473 | `property.value` | DESCRIPTOR_JSON_DATA |
| R26-217 | packages/harness/dist/capability-boundary.js:458 | 17194,17222 | `Object.getPrototypeOf(value)` | PROTOTYPE_BOOLEAN_GUARD |
| R26-218 | packages/harness/dist/capability-boundary.js:459 | 17239,17248 | `prototype` | PROTOTYPE_BOOLEAN_GUARD |
| R26-219 | packages/harness/dist/capability-boundary.js:459 | 17273,17282 | `prototype` | PROTOTYPE_BOOLEAN_GUARD |

canonical/isPlainObject tem 6 registros source/dist de comparação de protótipo; tool-invocation/isPlainRecord tem outros 6. Webhook canonicalJson tem 3. Os 29 registros de reflexão recebem proposta local data-only; não aceitam validators, implementações, getters em clones ou a autoridade das ações de domínio.

## Lifecycle, testes e executores

As seis transferências process → shutdown.install têm o callee source/dist inspecionado: install só usa once para sinais, ignora o retorno e chama shutdown. As quatro observações do mock de process estão limitadas ao mesmo lifecycle/once/exit. Não houve shutdown ou teste executado.

Os 58 spies web selecionam fetch literal. O callee instalado @vitest/spy 4.1.11 foi lido: descritor, reassign e restore usam essa mesma key; receiver é retido para restauração. Três expect.any(Function) usam Function como identidade/sample; o ramo Any correspondente só verifica typeof. Isso não aceita Function quando invocado em outro contexto nem a closure inteira de Vitest.

Nove consumidores de spawnSync leem status/error/stdout/stderr com encoding utf8 para assert/trim/JSON.parse; 31 consumidores de ChildProcess capturam data/error/close ou kill(SIGKILL). São propostas locais sem aceitar o launcher. Os 12 lançamentos/aliases executores e os 3 retornos de child continuam UNRESOLVED: planos concretos tsx, script -e, geração TLS/openssl, API/worker e seus consumidores são identificados por linha/hash/args. Native e runtime PG permanecem noutra lane.

Oito reflexões de testes devolvem membros dinâmicos de stores (uma chama Reflect.apply e outra bind(target)); não são data-only. Falta mapear keys/callers/corpos concretos de ensureControlledAgentPreset/buildServer e os stores envolvidos. Os cinco hooks do bootstrap global não têm writer/composição institucional demonstrado; o callback é realmente invocado e o cast TS não prova a origem/tipo do token. Essas pendências são específicas, não uma exigência de prova universal sobre todos os callbacks.

As 54 arestas de manifestos são metadata declarativa, porém continuam UNRESOLVED como dependências instaladas. Cada uma nomeia o specifier, seção e faixa reais e a resolução/closure instalada ainda necessária. Sem disposição ampla para vendor.

## Classificação de cada observação

Use o ID para consultar o registro integral em proposed-dispositions.json e raw-ast.json. Hash completo do arquivo e da expressão consta em cada registro. “I0+” significa somente PROPOSED_I0_POSITIVE.

| ID | Fonte original | Offset AST [start,end) | Classe / papel | Disposição |
|---|---|---|---|---|
| R26-001 | packages/shared/package.json → zod | 364,379 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-002 | packages/shared/package.json → vitest | 315,334 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-003 | packages/approval-engine/package.json → zod | 349,364 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-004 | packages/approval-engine/package.json → vitest | 397,416 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-005 | packages/channel-gateway/package.json → zod | 349,364 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-006 | packages/channel-gateway/package.json → vitest | 397,416 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-007 | packages/model-gateway/package.json → zod | 347,362 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-008 | packages/model-gateway/package.json → vitest | 395,414 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-009 | packages/observability/package.json → @opentelemetry/api | 347,377 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-010 | packages/observability/package.json → @opentelemetry/sdk-metrics | 383,422 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-011 | packages/observability/package.json → @opentelemetry/sdk-trace-base | 428,470 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-012 | packages/observability/package.json → zod | 476,491 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-013 | packages/observability/package.json → vitest | 524,543 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-014 | packages/policy-engine/package.json → zod | 347,362 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-015 | packages/policy-engine/package.json → vitest | 395,414 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-016 | packages/agent-runtime/package.json → zod | 526,541 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-017 | packages/agent-runtime/package.json → vitest | 574,593 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-018 | packages/orchestrator/package.json → vitest | 392,411 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-019 | packages/harness/package.json → vitest | 421,440 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-020 | packages/platform/package.json → zod | 342,357 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-021 | packages/rag/package.json → vitest | 394,413 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-022 | packages/platform/package.json → vitest | 415,434 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-023 | packages/persistence/package.json → pg | 552,567 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-024 | packages/persistence/package.json → zod | 573,588 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-025 | packages/persistence/package.json → vitest | 621,640 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-026 | packages/policy/package.json → vitest | 367,386 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-027 | packages/agent-core/package.json → zod | 435,450 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-028 | packages/agent-core/package.json → vitest | 483,502 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-029 | legacy/packages/secretary-journeys/package.json → fastify | 629,649 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-030 | legacy/packages/secretary-journeys/package.json → pg | 655,670 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-031 | legacy/packages/secretary-journeys/package.json → vitest | 676,695 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-032 | legacy/packages/secretary-profile/package.json → vitest | 593,612 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-033 | apps/api/package.json → fastify | 516,536 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-034 | apps/api/package.json → pg | 542,557 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-035 | apps/api/package.json → zod | 563,578 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-036 | apps/api/package.json → vitest | 611,630 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-037 | apps/web/package.json → @fontsource-variable/inter | 143,180 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-038 | apps/web/package.json → @tanstack/react-query | 186,221 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-039 | apps/web/package.json → react | 227,245 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-040 | apps/web/package.json → react-dom | 251,273 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-041 | apps/web/package.json → @testing-library/react | 306,341 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-042 | apps/web/package.json → vitest | 347,366 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-043 | apps/worker/package.json → pg | 527,542 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-044 | apps/worker/package.json → zod | 548,563 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-045 | apps/worker/package.json → vitest | 596,615 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-046 | packages/adapters/package.json → vitest | 202,221 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-047 | packages/agent-evals/package.json → zod | 213,228 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-048 | packages/agent-evals/package.json → vitest | 261,280 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-049 | packages/chaos/package.json → pg | 344,359 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-050 | packages/chaos/package.json → @types/pg | 427,449 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-051 | packages/chaos/package.json → vitest | 455,474 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-052 | packages/conversation/package.json → zod | 348,363 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-053 | packages/conversation/package.json → pg | 458,473 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-054 | packages/conversation/package.json → vitest | 479,498 | PACKAGE_METADATA / DECLARED_INSTALLED_MODULE_REFERENCE | UNRESOLVED |
| R26-055 | packages/harness/src/capability-boundary.ts:595 | 18005,18048 | DATA_ONLY_REFLECTION / DESCRIPTOR_JSON_DATA | I0+ |
| R26-056 | packages/harness/src/capability-boundary.ts:596 | 18060,18068 | DATA_ONLY_REFLECTION / DESCRIPTOR_JSON_DATA | I0+ |
| R26-057 | packages/harness/src/capability-boundary.ts:596 | 18085,18093 | DATA_ONLY_REFLECTION / DESCRIPTOR_JSON_DATA | I0+ |
| R26-058 | packages/harness/src/capability-boundary.ts:600 | 18239,18253 | DATA_ONLY_REFLECTION / DESCRIPTOR_JSON_DATA | I0+ |
| R26-059 | packages/harness/src/capability-boundary.ts:628 | 18968,18996 | DATA_ONLY_REFLECTION / PROTOTYPE_BOOLEAN_GUARD | I0+ |
| R26-060 | packages/harness/src/capability-boundary.ts:629 | 19008,19017 | DATA_ONLY_REFLECTION / PROTOTYPE_BOOLEAN_GUARD | I0+ |
| R26-061 | packages/harness/src/capability-boundary.ts:629 | 19042,19051 | DATA_ONLY_REFLECTION / PROTOTYPE_BOOLEAN_GUARD | I0+ |
| R26-062 | packages/model-gateway/src/__tests__/bounded-observer-options.test.ts:14 | 368,922 | TEST_EXECUTOR / PROCESS_LAUNCH | UNRESOLVED |
| R26-063 | packages/model-gateway/src/__tests__/bounded-observer-options.test.ts:38 | 934,946 | TEST_EXECUTOR_RESULT_METADATA / SPAWN_SYNC_DATA_CONSUMER | I0+ |
| R26-064 | packages/model-gateway/src/__tests__/bounded-observer-options.test.ts:39 | 975,988 | TEST_EXECUTOR_RESULT_METADATA / SPAWN_SYNC_DATA_CONSUMER | I0+ |
| R26-065 | packages/model-gateway/src/__tests__/bounded-observer-options.test.ts:39 | 990,1003 | TEST_EXECUTOR_RESULT_METADATA / SPAWN_SYNC_DATA_CONSUMER | I0+ |
| R26-066 | packages/model-gateway/src/__tests__/bounded-observer-options.test.ts:40 | 1042,1062 | TEST_EXECUTOR_RESULT_METADATA / SPAWN_SYNC_DATA_CONSUMER | I0+ |
| R26-067 | packages/model-gateway/src/__tests__/bounded-tls-node22.test.ts:11 | 409,417 | TEST_EXECUTOR / EXECUTOR_ALIAS_TO_PROMISIFY | UNRESOLVED |
| R26-068 | packages/model-gateway/src/__tests__/d009-budget.test.ts:171 | 5190,5488 | TEST_EXECUTOR / PROCESS_LAUNCH | UNRESOLVED |
| R26-069 | packages/model-gateway/src/__tests__/d009-budget.test.ts:186 | 5502,5515 | TEST_EXECUTOR_RESULT_METADATA / SPAWN_SYNC_DATA_CONSUMER | I0+ |
| R26-070 | packages/model-gateway/src/__tests__/d009-budget.test.ts:186 | 5517,5530 | TEST_EXECUTOR_RESULT_METADATA / SPAWN_SYNC_DATA_CONSUMER | I0+ |
| R26-071 | packages/model-gateway/src/__tests__/d009-budget.test.ts:187 | 5564,5577 | TEST_EXECUTOR_RESULT_METADATA / SPAWN_SYNC_DATA_CONSUMER | I0+ |
| R26-072 | packages/model-gateway/src/__tests__/d009-budget.test.ts:641 | 22220,22354 | TEST_EXECUTOR / PROCESS_LAUNCH | UNRESOLVED |
| R26-073 | packages/model-gateway/src/__tests__/d009-budget.test.ts:646 | 22366,22378 | TEST_EXECUTOR_RESULT_METADATA / SPAWN_SYNC_DATA_CONSUMER | I0+ |
| R26-074 | packages/model-gateway/src/__tests__/d009-budget.test.ts:646 | 22380,22392 | TEST_EXECUTOR_RESULT_METADATA / SPAWN_SYNC_DATA_CONSUMER | I0+ |
| R26-075 | packages/persistence/src/__tests__/outbox-edge.test.ts:119 | 3865,3873 | TEST_MATCHER_METADATA / FUNCTION_IDENTITY_AS_MATCHER_SAMPLE | I0+ |
| R26-076 | packages/platform/src/__tests__/controlled-preset-hardening.test.ts:106 | 3246,3285 | TEST_REFLECTION_METHOD_TRANSFER / REFLECT_GET_DYNAMIC_STORE_MEMBER | UNRESOLVED |
| R26-077 | packages/platform/src/__tests__/controlled-preset-hardening.test.ts:107 | 3308,3313 | TEST_REFLECTION_METHOD_TRANSFER / REFLECT_GET_DYNAMIC_STORE_MEMBER | UNRESOLVED |
| R26-078 | packages/platform/src/__tests__/controlled-preset-hardening.test.ts:107 | 3331,3349 | TEST_REFLECTION_METHOD_TRANSFER / REFLECT_GET_DYNAMIC_STORE_MEMBER | UNRESOLVED |
| R26-079 | packages/platform/src/__tests__/controlled-preset-hardening.test.ts:107 | 3352,3357 | TEST_REFLECTION_METHOD_TRANSFER / REFLECT_GET_DYNAMIC_STORE_MEMBER | UNRESOLVED |
| R26-080 | packages/platform/src/tool-invocation-boundary.ts:201 | 6392,6420 | DATA_ONLY_REFLECTION / PROTOTYPE_BOOLEAN_GUARD | I0+ |
| R26-081 | packages/platform/src/tool-invocation-boundary.ts:202 | 6432,6441 | DATA_ONLY_REFLECTION / PROTOTYPE_BOOLEAN_GUARD | I0+ |
| R26-082 | packages/platform/src/tool-invocation-boundary.ts:202 | 6466,6475 | DATA_ONLY_REFLECTION / PROTOTYPE_BOOLEAN_GUARD | I0+ |
| R26-083 | packages/shared/src/canonical.ts:27 | 815,843 | DATA_ONLY_REFLECTION / PROTOTYPE_BOOLEAN_GUARD | I0+ |
| R26-084 | packages/shared/src/canonical.ts:28 | 853,862 | DATA_ONLY_REFLECTION / PROTOTYPE_BOOLEAN_GUARD | I0+ |
| R26-085 | packages/shared/src/canonical.ts:28 | 887,896 | DATA_ONLY_REFLECTION / PROTOTYPE_BOOLEAN_GUARD | I0+ |
| R26-086 | apps/api/src/__tests__/approval-decision-atomicity-postgres.test.ts:366 | 12412,12451 | TEST_REFLECTION_METHOD_TRANSFER / REFLECT_GET_DYNAMIC_STORE_MEMBER | UNRESOLVED |
| R26-087 | apps/api/src/__tests__/approval-decision-atomicity.test.ts:135 | 4280,4319 | TEST_REFLECTION_METHOD_TRANSFER / REFLECT_GET_DYNAMIC_STORE_MEMBER | UNRESOLVED |
| R26-088 | apps/api/src/__tests__/approval-decision-atomicity.test.ts:141 | 4431,4470 | TEST_REFLECTION_METHOD_TRANSFER / REFLECT_GET_DYNAMIC_STORE_MEMBER | UNRESOLVED |
| R26-089 | apps/api/src/__tests__/approval-decision-atomicity.test.ts:197 | 6484,6523 | TEST_REFLECTION_METHOD_TRANSFER / REFLECT_GET_DYNAMIC_STORE_MEMBER | UNRESOLVED |
| R26-090 | apps/api/src/__tests__/identity-composition-wiring.test.ts:406 | 12618,12770 | TEST_EXECUTOR / PROCESS_LAUNCH | UNRESOLVED |
| R26-091 | apps/api/src/__tests__/identity-composition-wiring.test.ts:415 | 12795,12868 | TEST_PROCESS_LIFECYCLE / CHILD_STDIO_EVENT | I0+ |
| R26-092 | apps/api/src/__tests__/identity-composition-wiring.test.ts:418 | 12873,12946 | TEST_PROCESS_LIFECYCLE / CHILD_STDIO_EVENT | I0+ |
| R26-093 | apps/api/src/__tests__/identity-composition-wiring.test.ts:421 | 12951,12978 | TEST_PROCESS_LIFECYCLE / CHILD_EXIT_ERROR_EVENT | I0+ |
| R26-094 | apps/api/src/__tests__/identity-composition-wiring.test.ts:422 | 12983,13039 | TEST_PROCESS_LIFECYCLE / CHILD_EXIT_ERROR_EVENT | I0+ |
| R26-095 | apps/api/src/__tests__/production-bootstrap-main-own.test.ts:37 | 892,899 | TEST_PROCESS_LIFECYCLE / BIND_PROCESS_ONCE_RECEIVER | I0+ |
| R26-096 | apps/api/src/__tests__/production-bootstrap-main-own.test.ts:38 | 912,919 | TEST_PROCESS_LIFECYCLE / SPY_PROCESS_ONCE | I0+ |
| R26-097 | apps/api/src/__tests__/production-bootstrap-main-own.test.ts:41 | 1073,1080 | TEST_PROCESS_LIFECYCLE / RETURN_PROCESS_FROM_SIGNAL_MOCK | I0+ |
| R26-098 | apps/api/src/__tests__/production-bootstrap-main-own.test.ts:45 | 1143,1150 | TEST_PROCESS_LIFECYCLE / SPY_PROCESS_EXIT | I0+ |
| R26-099 | apps/api/src/main.ts:31 | 1090,1097 | PROCESS_LIFECYCLE / PROCESS_TO_SELECTED_SIGNAL_SOURCE | I0+ |
| R26-100 | apps/api/src/webhook-security.ts:507 | 15899,15927 | DATA_ONLY_REFLECTION / PROTOTYPE_BOOLEAN_GUARD | I0+ |
| R26-101 | apps/api/src/webhook-security.ts:508 | 15936,15945 | DATA_ONLY_REFLECTION / PROTOTYPE_BOOLEAN_GUARD | I0+ |
| R26-102 | apps/api/src/webhook-security.ts:508 | 15970,15979 | DATA_ONLY_REFLECTION / PROTOTYPE_BOOLEAN_GUARD | I0+ |
| R26-103 | apps/web/src/__tests__/app.test.tsx:335 | 10408,10416 | TEST_MATCHER_METADATA / FUNCTION_IDENTITY_AS_MATCHER_SAMPLE | I0+ |
| R26-104 | apps/web/src/__tests__/app.test.tsx:539 | 17642,17650 | TEST_MATCHER_METADATA / FUNCTION_IDENTITY_AS_MATCHER_SAMPLE | I0+ |
| R26-105 | apps/web/src/__tests__/app.test.tsx:50 | 1269,1279 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-106 | apps/web/src/__tests__/app.test.tsx:190 | 5781,5791 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-107 | apps/web/src/__tests__/app.test.tsx:377 | 12144,12154 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-108 | apps/web/src/__tests__/app.test.tsx:492 | 15923,15933 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-109 | apps/web/src/__tests__/app.test.tsx:562 | 18362,18372 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-110 | apps/web/src/__tests__/app.test.tsx:588 | 19455,19465 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-111 | apps/web/src/__tests__/app.test.tsx:691 | 22754,22764 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-112 | apps/web/src/__tests__/app.test.tsx:831 | 27369,27379 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-113 | apps/web/src/__tests__/app.test.tsx:926 | 30457,30467 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-114 | apps/web/src/__tests__/app.test.tsx:1005 | 33019,33029 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-115 | apps/web/src/__tests__/app.test.tsx:1133 | 37634,37644 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-116 | apps/web/src/__tests__/app.test.tsx:1320 | 43759,43769 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-117 | apps/web/src/__tests__/app.test.tsx:1365 | 45406,45416 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-118 | apps/web/src/__tests__/attendance-approval-conflict.test.tsx:29 | 676,686 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-119 | apps/web/src/__tests__/attendance-approval-conflict.test.tsx:92 | 2732,2742 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-120 | apps/web/src/__tests__/audit-checkpoint-app.test.tsx:16 | 524,534 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-121 | apps/web/src/__tests__/journeys-identity-race.test.tsx:38 | 1109,1119 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-122 | apps/web/src/__tests__/journeys-identity-race.test.tsx:76 | 2277,2287 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-123 | apps/web/src/__tests__/journeys-identity-race.test.tsx:101 | 3143,3153 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-124 | apps/web/src/__tests__/journeys-identity-race.test.tsx:151 | 4710,4720 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-125 | apps/web/src/__tests__/journeys-identity-race.test.tsx:232 | 7227,7237 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-126 | apps/web/src/__tests__/platform-panel.test.tsx:103 | 2715,2725 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-127 | apps/web/src/__tests__/platform-panel.test.tsx:225 | 6521,6531 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-128 | apps/web/src/__tests__/platform-panel.test.tsx:308 | 9102,9112 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-129 | apps/web/src/__tests__/platform-panel.test.tsx:381 | 11734,11744 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-130 | apps/web/src/__tests__/platform-panel.test.tsx:449 | 13951,13961 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-131 | apps/web/src/__tests__/platform-panel.test.tsx:511 | 15968,15978 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-132 | apps/web/src/__tests__/trusted-session-app.test.tsx:40 | 902,912 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-133 | apps/web/src/api/audit-evidence-checkpoint-client.test.ts:29 | 875,885 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-134 | apps/web/src/api/audit-evidence-checkpoint-client.test.ts:97 | 3082,3092 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-135 | apps/web/src/api/client.test.ts:52 | 1230,1240 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-136 | apps/web/src/api/release-candidate-client.test.ts:45 | 1247,1257 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-137 | apps/web/src/api/release-candidate-client.test.ts:58 | 1709,1719 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-138 | apps/web/src/api/release-candidate-client.test.ts:108 | 3772,3782 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-139 | apps/web/src/api/resilient-client.test.ts:57 | 1473,1483 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-140 | apps/web/src/api/resilient-client.test.ts:77 | 2149,2159 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-141 | apps/web/src/api/resilient-client.test.ts:104 | 3100,3110 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-142 | apps/web/src/api/resilient-client.test.ts:119 | 3618,3628 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-143 | apps/web/src/api/resilient-client.test.ts:133 | 4038,4048 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-144 | apps/web/src/api/resilient-client.test.ts:144 | 4413,4423 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-145 | apps/web/src/api/resilient-client.test.ts:157 | 4783,4793 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-146 | apps/web/src/api/resilient-client.test.ts:173 | 5224,5234 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-147 | apps/web/src/api/resilient-client.test.ts:187 | 5695,5705 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-148 | apps/web/src/auth/session.ts:77 | 2126,2136 | BOOTSTRAP_GLOBAL_CAPABILITY / GLOBAL_NAMESPACE_ALIAS | UNRESOLVED |
| R26-149 | apps/web/src/auth/session.ts:78 | 2189,2238 | BOOTSTRAP_GLOBAL_CAPABILITY / INJECTED_PROVIDER_READ | UNRESOLVED |
| R26-150 | apps/web/src/auth/session.ts:79 | 2253,2302 | BOOTSTRAP_GLOBAL_CAPABILITY / INJECTED_PROVIDER_CALL | UNRESOLVED |
| R26-151 | apps/web/src/auth/session.ts:81 | 2325,2365 | BOOTSTRAP_GLOBAL_CAPABILITY / TOKEN_GLOBAL_READ | UNRESOLVED |
| R26-152 | apps/web/src/auth/session.ts:82 | 2394,2434 | BOOTSTRAP_GLOBAL_CAPABILITY / TOKEN_GLOBAL_DELETE | UNRESOLVED |
| R26-153 | apps/web/src/features/journeys/journeys.test.tsx:28 | 825,835 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-154 | apps/web/src/features/platform/handoff-policy-control-center.test.tsx:78 | 1950,1960 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-155 | apps/web/src/features/platform/handoff-policy-control-center.test.tsx:167 | 4773,4783 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-156 | apps/web/src/features/platform/knowledge-source-catalog.test.tsx:25 | 824,834 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-157 | apps/web/src/features/platform/multi-agent-creation.test.tsx:54 | 1343,1353 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-158 | apps/web/src/features/platform/multi-agent-creation.test.tsx:228 | 7098,7108 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-159 | apps/web/src/features/platform/multi-agent-creation.test.tsx:305 | 9466,9476 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-160 | apps/web/src/features/platform/multi-agent-creation.test.tsx:411 | 12875,12885 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-161 | apps/web/src/features/platform/multi-agent-creation.test.tsx:516 | 16322,16332 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-162 | apps/web/src/features/platform/multi-agent-creation.test.tsx:626 | 19639,19649 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-163 | apps/web/src/features/platform/platform.test.tsx:33 | 748,758 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-164 | apps/web/src/features/platform/platform.test.tsx:116 | 3649,3659 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-165 | apps/web/src/features/platform/platform.test.tsx:194 | 6655,6665 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-166 | apps/web/src/features/platform/prompt-profile-control-center.test.tsx:96 | 2603,2613 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-167 | apps/web/src/features/platform/release-candidate-ledger.test.tsx:75 | 1886,1896 | TEST_REFLECTION_SELECTED_MEMBER / GLOBAL_FETCH_SPY | I0+ |
| R26-168 | apps/worker/src/__tests__/continuous-worker-entrypoint.integration.test.ts:54 | 1704,1879 | TEST_EXECUTOR / PROCESS_LAUNCH | UNRESOLVED |
| R26-169 | apps/worker/src/__tests__/continuous-worker-entrypoint.integration.test.ts:64 | 1900,1970 | TEST_PROCESS_LIFECYCLE / CHILD_STDIO_EVENT | I0+ |
| R26-170 | apps/worker/src/__tests__/continuous-worker-entrypoint.integration.test.ts:67 | 1973,2043 | TEST_PROCESS_LIFECYCLE / CHILD_STDIO_EVENT | I0+ |
| R26-171 | apps/worker/src/__tests__/continuous-worker-entrypoint.integration.test.ts:70 | 2055,2060 | TEST_EXECUTOR_HANDLE_TRANSFER / CHILD_HANDLE_RETURN | UNRESOLVED |
| R26-172 | apps/worker/src/__tests__/continuous-worker.test.ts:116 | 2955,3146 | TEST_EXECUTOR / PROCESS_LAUNCH | UNRESOLVED |
| R26-173 | apps/worker/src/__tests__/continuous-worker.test.ts:126 | 3171,3244 | TEST_PROCESS_LIFECYCLE / CHILD_STDIO_EVENT | I0+ |
| R26-174 | apps/worker/src/__tests__/continuous-worker.test.ts:129 | 3249,3322 | TEST_PROCESS_LIFECYCLE / CHILD_STDIO_EVENT | I0+ |
| R26-175 | apps/worker/src/__tests__/continuous-worker.test.ts:132 | 3360,3381 | TEST_PROCESS_LIFECYCLE / CHILD_TERMINATION | I0+ |
| R26-176 | apps/worker/src/__tests__/continuous-worker.test.ts:133 | 3395,3495 | TEST_PROCESS_LIFECYCLE / CHILD_EXIT_ERROR_EVENT | I0+ |
| R26-177 | apps/worker/src/__tests__/continuous-worker.test.ts:137 | 3500,3598 | TEST_PROCESS_LIFECYCLE / CHILD_EXIT_ERROR_EVENT | I0+ |
| R26-178 | apps/worker/src/__tests__/homolog-worker-lifecycle.test.ts:96 | 2975,3702 | TEST_EXECUTOR / PROCESS_LAUNCH | UNRESOLVED |
| R26-179 | apps/worker/src/__tests__/homolog-worker-lifecycle.test.ts:119 | 3727,3801 | TEST_PROCESS_LIFECYCLE / CHILD_STDIO_EVENT | I0+ |
| R26-180 | apps/worker/src/__tests__/homolog-worker-lifecycle.test.ts:122 | 3806,3880 | TEST_PROCESS_LIFECYCLE / CHILD_STDIO_EVENT | I0+ |
| R26-181 | apps/worker/src/__tests__/homolog-worker-lifecycle.test.ts:127 | 3979,4006 | TEST_PROCESS_LIFECYCLE / CHILD_EXIT_ERROR_EVENT | I0+ |
| R26-182 | apps/worker/src/__tests__/homolog-worker-lifecycle.test.ts:128 | 4015,4063 | TEST_PROCESS_LIFECYCLE / CHILD_EXIT_ERROR_EVENT | I0+ |
| R26-183 | apps/worker/src/__tests__/homolog-worker-lifecycle.test.ts:139 | 4395,4798 | TEST_EXECUTOR / PROCESS_LAUNCH | UNRESOLVED |
| R26-184 | apps/worker/src/__tests__/homolog-worker-lifecycle.test.ts:155 | 4823,4897 | TEST_PROCESS_LIFECYCLE / CHILD_STDIO_EVENT | I0+ |
| R26-185 | apps/worker/src/__tests__/homolog-worker-lifecycle.test.ts:158 | 4902,4976 | TEST_PROCESS_LIFECYCLE / CHILD_STDIO_EVENT | I0+ |
| R26-186 | apps/worker/src/__tests__/homolog-worker-lifecycle.test.ts:163 | 5075,5102 | TEST_PROCESS_LIFECYCLE / CHILD_EXIT_ERROR_EVENT | I0+ |
| R26-187 | apps/worker/src/__tests__/homolog-worker-lifecycle.test.ts:164 | 5111,5159 | TEST_PROCESS_LIFECYCLE / CHILD_EXIT_ERROR_EVENT | I0+ |
| R26-188 | apps/worker/src/__tests__/operational-harness-homolog.integration.test.ts:131 | 4205,4380 | TEST_EXECUTOR / PROCESS_LAUNCH | UNRESOLVED |
| R26-189 | apps/worker/src/__tests__/operational-harness-homolog.integration.test.ts:141 | 4401,4471 | TEST_PROCESS_LIFECYCLE / CHILD_STDIO_EVENT | I0+ |
| R26-190 | apps/worker/src/__tests__/operational-harness-homolog.integration.test.ts:144 | 4474,4544 | TEST_PROCESS_LIFECYCLE / CHILD_STDIO_EVENT | I0+ |
| R26-191 | apps/worker/src/__tests__/operational-harness-homolog.integration.test.ts:148 | 4611,4638 | TEST_PROCESS_LIFECYCLE / CHILD_EXIT_ERROR_EVENT | I0+ |
| R26-192 | apps/worker/src/__tests__/operational-harness-homolog.integration.test.ts:149 | 4643,4707 | TEST_PROCESS_LIFECYCLE / CHILD_EXIT_ERROR_EVENT | I0+ |
| R26-193 | apps/worker/src/__tests__/operational-harness-homolog.integration.test.ts:151 | 4724,4729 | TEST_EXECUTOR_HANDLE_TRANSFER / CHILD_HANDLE_RETURN | UNRESOLVED |
| R26-194 | apps/worker/src/__tests__/operational-harness-process-restart.integration.test.ts:132 | 3774,3949 | TEST_EXECUTOR / PROCESS_LAUNCH | UNRESOLVED |
| R26-195 | apps/worker/src/__tests__/operational-harness-process-restart.integration.test.ts:142 | 3970,4040 | TEST_PROCESS_LIFECYCLE / CHILD_STDIO_EVENT | I0+ |
| R26-196 | apps/worker/src/__tests__/operational-harness-process-restart.integration.test.ts:145 | 4043,4113 | TEST_PROCESS_LIFECYCLE / CHILD_STDIO_EVENT | I0+ |
| R26-197 | apps/worker/src/__tests__/operational-harness-process-restart.integration.test.ts:149 | 4180,4207 | TEST_PROCESS_LIFECYCLE / CHILD_EXIT_ERROR_EVENT | I0+ |
| R26-198 | apps/worker/src/__tests__/operational-harness-process-restart.integration.test.ts:150 | 4212,4276 | TEST_PROCESS_LIFECYCLE / CHILD_EXIT_ERROR_EVENT | I0+ |
| R26-199 | apps/worker/src/__tests__/operational-harness-process-restart.integration.test.ts:152 | 4293,4298 | TEST_EXECUTOR_HANDLE_TRANSFER / CHILD_HANDLE_RETURN | UNRESOLVED |
| R26-200 | apps/worker/src/__tests__/startup-error-redaction.test.ts:98 | 3478,4217 | TEST_EXECUTOR / PROCESS_LAUNCH | UNRESOLVED |
| R26-201 | apps/worker/src/__tests__/startup-error-redaction.test.ts:121 | 4242,4316 | TEST_PROCESS_LIFECYCLE / CHILD_STDIO_EVENT | I0+ |
| R26-202 | apps/worker/src/__tests__/startup-error-redaction.test.ts:124 | 4321,4395 | TEST_PROCESS_LIFECYCLE / CHILD_STDIO_EVENT | I0+ |
| R26-203 | apps/worker/src/__tests__/startup-error-redaction.test.ts:129 | 4494,4521 | TEST_PROCESS_LIFECYCLE / CHILD_EXIT_ERROR_EVENT | I0+ |
| R26-204 | apps/worker/src/__tests__/startup-error-redaction.test.ts:130 | 4530,4578 | TEST_PROCESS_LIFECYCLE / CHILD_EXIT_ERROR_EVENT | I0+ |
| R26-205 | apps/worker/src/homolog-worker.ts:275 | 9103,9110 | PROCESS_LIFECYCLE / PROCESS_TO_SELECTED_SIGNAL_SOURCE | I0+ |
| R26-206 | apps/worker/src/main.ts:185 | 5994,6001 | PROCESS_LIFECYCLE / PROCESS_TO_SELECTED_SIGNAL_SOURCE | I0+ |
| R26-207 | apps/worker/src/main.ts:267 | 8372,8379 | PROCESS_LIFECYCLE / PROCESS_TO_SELECTED_SIGNAL_SOURCE | I0+ |
| R26-208 | apps/worker/src/main.ts:385 | 12212,12219 | PROCESS_LIFECYCLE / PROCESS_TO_SELECTED_SIGNAL_SOURCE | I0+ |
| R26-209 | apps/worker/src/main.ts:490 | 15683,15690 | PROCESS_LIFECYCLE / PROCESS_TO_SELECTED_SIGNAL_SOURCE | I0+ |
| R26-210 | packages/shared/dist/canonical.js:24 | 788,816 | DATA_ONLY_REFLECTION / PROTOTYPE_BOOLEAN_GUARD | I0+ |
| R26-211 | packages/shared/dist/canonical.js:25 | 829,838 | DATA_ONLY_REFLECTION / PROTOTYPE_BOOLEAN_GUARD | I0+ |
| R26-212 | packages/shared/dist/canonical.js:25 | 863,872 | DATA_ONLY_REFLECTION / PROTOTYPE_BOOLEAN_GUARD | I0+ |
| R26-213 | packages/harness/dist/capability-boundary.js:427 | 16206,16249 | DATA_ONLY_REFLECTION / DESCRIPTOR_JSON_DATA | I0+ |
| R26-214 | packages/harness/dist/capability-boundary.js:428 | 16268,16276 | DATA_ONLY_REFLECTION / DESCRIPTOR_JSON_DATA | I0+ |
| R26-215 | packages/harness/dist/capability-boundary.js:428 | 16293,16301 | DATA_ONLY_REFLECTION / DESCRIPTOR_JSON_DATA | I0+ |
| R26-216 | packages/harness/dist/capability-boundary.js:431 | 16459,16473 | DATA_ONLY_REFLECTION / DESCRIPTOR_JSON_DATA | I0+ |
| R26-217 | packages/harness/dist/capability-boundary.js:458 | 17194,17222 | DATA_ONLY_REFLECTION / PROTOTYPE_BOOLEAN_GUARD | I0+ |
| R26-218 | packages/harness/dist/capability-boundary.js:459 | 17239,17248 | DATA_ONLY_REFLECTION / PROTOTYPE_BOOLEAN_GUARD | I0+ |
| R26-219 | packages/harness/dist/capability-boundary.js:459 | 17273,17282 | DATA_ONLY_REFLECTION / PROTOTYPE_BOOLEAN_GUARD | I0+ |
| R26-220 | packages/platform/dist/tool-invocation-boundary.js:157 | 5808,5836 | DATA_ONLY_REFLECTION / PROTOTYPE_BOOLEAN_GUARD | I0+ |
| R26-221 | packages/platform/dist/tool-invocation-boundary.js:158 | 5853,5862 | DATA_ONLY_REFLECTION / PROTOTYPE_BOOLEAN_GUARD | I0+ |
| R26-222 | packages/platform/dist/tool-invocation-boundary.js:158 | 5887,5896 | DATA_ONLY_REFLECTION / PROTOTYPE_BOOLEAN_GUARD | I0+ |

## Provas pendentes por caso

| ID | Prova concreta ainda necessária |
|---|---|
| R26-001 | Resolver zod a partir de packages/shared/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^4.3.6'} não comprova o módulo instalado nem sua closure. |
| R26-002 | Resolver vitest a partir de packages/shared/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-003 | Resolver zod a partir de packages/approval-engine/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^4.3.6'} não comprova o módulo instalado nem sua closure. |
| R26-004 | Resolver vitest a partir de packages/approval-engine/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-005 | Resolver zod a partir de packages/channel-gateway/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^4.3.6'} não comprova o módulo instalado nem sua closure. |
| R26-006 | Resolver vitest a partir de packages/channel-gateway/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-007 | Resolver zod a partir de packages/model-gateway/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^4.3.6'} não comprova o módulo instalado nem sua closure. |
| R26-008 | Resolver vitest a partir de packages/model-gateway/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-009 | Resolver @opentelemetry/api a partir de packages/observability/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^1.9.0'} não comprova o módulo instalado nem sua closure. |
| R26-010 | Resolver @opentelemetry/sdk-metrics a partir de packages/observability/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^2.11.0'} não comprova o módulo instalado nem sua closure. |
| R26-011 | Resolver @opentelemetry/sdk-trace-base a partir de packages/observability/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^2.11.0'} não comprova o módulo instalado nem sua closure. |
| R26-012 | Resolver zod a partir de packages/observability/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^4.3.6'} não comprova o módulo instalado nem sua closure. |
| R26-013 | Resolver vitest a partir de packages/observability/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-014 | Resolver zod a partir de packages/policy-engine/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^4.3.6'} não comprova o módulo instalado nem sua closure. |
| R26-015 | Resolver vitest a partir de packages/policy-engine/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-016 | Resolver zod a partir de packages/agent-runtime/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^4.3.6'} não comprova o módulo instalado nem sua closure. |
| R26-017 | Resolver vitest a partir de packages/agent-runtime/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-018 | Resolver vitest a partir de packages/orchestrator/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-019 | Resolver vitest a partir de packages/harness/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-020 | Resolver zod a partir de packages/platform/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^4.3.6'} não comprova o módulo instalado nem sua closure. |
| R26-021 | Resolver vitest a partir de packages/rag/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-022 | Resolver vitest a partir de packages/platform/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-023 | Resolver pg a partir de packages/persistence/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^8.20.0'} não comprova o módulo instalado nem sua closure. |
| R26-024 | Resolver zod a partir de packages/persistence/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^4.3.6'} não comprova o módulo instalado nem sua closure. |
| R26-025 | Resolver vitest a partir de packages/persistence/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-026 | Resolver vitest a partir de packages/policy/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-027 | Resolver zod a partir de packages/agent-core/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^4.3.6'} não comprova o módulo instalado nem sua closure. |
| R26-028 | Resolver vitest a partir de packages/agent-core/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-029 | Resolver fastify a partir de legacy/packages/secretary-journeys/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^5.12.3'} não comprova o módulo instalado nem sua closure. |
| R26-030 | Resolver pg a partir de legacy/packages/secretary-journeys/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^8.20.0'} não comprova o módulo instalado nem sua closure. |
| R26-031 | Resolver vitest a partir de legacy/packages/secretary-journeys/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-032 | Resolver vitest a partir de legacy/packages/secretary-profile/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-033 | Resolver fastify a partir de apps/api/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^5.12.5'} não comprova o módulo instalado nem sua closure. |
| R26-034 | Resolver pg a partir de apps/api/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^8.20.0'} não comprova o módulo instalado nem sua closure. |
| R26-035 | Resolver zod a partir de apps/api/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^4.3.6'} não comprova o módulo instalado nem sua closure. |
| R26-036 | Resolver vitest a partir de apps/api/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-037 | Resolver @fontsource-variable/inter a partir de apps/web/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '5.3.0'} não comprova o módulo instalado nem sua closure. |
| R26-038 | Resolver @tanstack/react-query a partir de apps/web/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^5.100.6'} não comprova o módulo instalado nem sua closure. |
| R26-039 | Resolver react a partir de apps/web/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^19.2.5'} não comprova o módulo instalado nem sua closure. |
| R26-040 | Resolver react-dom a partir de apps/web/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^19.2.5'} não comprova o módulo instalado nem sua closure. |
| R26-041 | Resolver @testing-library/react a partir de apps/web/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^16.3.2'} não comprova o módulo instalado nem sua closure. |
| R26-042 | Resolver vitest a partir de apps/web/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-043 | Resolver pg a partir de apps/worker/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^8.20.0'} não comprova o módulo instalado nem sua closure. |
| R26-044 | Resolver zod a partir de apps/worker/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^4.3.6'} não comprova o módulo instalado nem sua closure. |
| R26-045 | Resolver vitest a partir de apps/worker/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-046 | Resolver vitest a partir de packages/adapters/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-047 | Resolver zod a partir de packages/agent-evals/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^4.3.6'} não comprova o módulo instalado nem sua closure. |
| R26-048 | Resolver vitest a partir de packages/agent-evals/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-049 | Resolver pg a partir de packages/chaos/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^8.20.0'} não comprova o módulo instalado nem sua closure. |
| R26-050 | Resolver @types/pg a partir de packages/chaos/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^8.20.0'} não comprova o módulo instalado nem sua closure. |
| R26-051 | Resolver vitest a partir de packages/chaos/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-052 | Resolver zod a partir de packages/conversation/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'dependencies': '^4.3.6'} não comprova o módulo instalado nem sua closure. |
| R26-053 | Resolver pg a partir de packages/conversation/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^8.20.0'} não comprova o módulo instalado nem sua closure. |
| R26-054 | Resolver vitest a partir de packages/conversation/package.json no perfil R22 e fornecer identidade física, package/exports/runtime-versus-types e hashes de sua closure transitiva relevante. A faixa declarada {'devDependencies': '^4.1.11'} não comprova o módulo instalado nem sua closure. |
| R26-062 | Hash-bound resolução de --import tsx e closure das imports ../../index.ts e ../../circuit-breaker.ts do observer-options-child.mjs no cwd efetivo. O fixture foi lido, não executado; seu log PASS não é resultado desta auditoria. |
| R26-067 | Identidade/resolução da ferramenta openssl (native lane), entry do loader.mjs de tsx e plano AST do tls-child.mts gerado com import absoluto de ssrf-node.ts/closure. Promisify não torna executor em dado inert. |
| R26-068 | Plano hash-bound do script -e e cwd que ancora resolve(packages/model-gateway/src/index.ts), binding argv→import target (ou template literal interpolado) e entry/closure de --import tsx. O destino nominal está concreto; a closure desse executor separado não foi adjudicada. |
| R26-072 | Plano hash-bound do script -e e cwd que ancora resolve(packages/model-gateway/src/index.ts), binding argv→import target (ou template literal interpolado) e entry/closure de --import tsx. O destino nominal está concreto; a closure desse executor separado não foi adjudicada. |
| R26-076 | Enumerar os acessos de ensureControlledAgentPreset ao store deste teste e ligar cada key/método retornado ao corpo de InMemoryControlPlaneStore. O Reflect.get recebe property variável e o callable é efetivamente transferido; os corpos/keys desse caminho não foram inspecionados aqui. |
| R26-077 | Enumerar os acessos de ensureControlledAgentPreset ao store deste teste e ligar cada key/método retornado ao corpo de InMemoryControlPlaneStore. O Reflect.get recebe property variável e o callable é efetivamente transferido; os corpos/keys desse caminho não foram inspecionados aqui. |
| R26-078 | Enumerar os acessos de ensureControlledAgentPreset ao store deste teste e ligar cada key/método retornado ao corpo de InMemoryControlPlaneStore. O Reflect.get recebe property variável e o callable é efetivamente transferido; os corpos/keys desse caminho não foram inspecionados aqui. |
| R26-079 | Enumerar os acessos de ensureControlledAgentPreset ao store deste teste e ligar cada key/método retornado ao corpo de InMemoryControlPlaneStore. O Reflect.get recebe property variável e o callable é efetivamente transferido; os corpos/keys desse caminho não foram inspecionados aqui. |
| R26-086 | Fixar o conjunto de keys solicitado por buildServer no caminho approval decision com esse PostgresOperationalExecutionStore e mapear seus produtores/corpos hash-bound. Prova de runtime/PG pertence a outra lane; ela não é solicitada para I0. |
| R26-087 | Fixar keys/callers de buildServer e corpos do store de memória para os proxies de decisão/resolveApproval. O alvo concreto é conhecido, mas não foi inspecionada a closure dos métodos devolvidos por property variável; a ocorrência de Reflect.get não pode ser chamada data-only neste caso. |
| R26-088 | Fixar keys/callers de buildServer e corpos do store de memória para os proxies de decisão/resolveApproval. O alvo concreto é conhecido, mas não foi inspecionada a closure dos métodos devolvidos por property variável; a ocorrência de Reflect.get não pode ser chamada data-only neste caso. |
| R26-089 | Fixar keys/callers de buildServer e corpos do store de memória para os proxies de decisão/resolveApproval. O alvo concreto é conhecido, mas não foi inspecionada a closure dos métodos devolvidos por property variável; a ocorrência de Reflect.get não pode ser chamada data-only neste caso. |
| R26-090 | Hash-bound resolução física de node_modules/.bin/tsx e closure runtime do entry apps/api/src/main.ts para os argumentos/cwd/env desta fixture. Não basta o path literal do entry para conhecer módulos que o launcher separado adquire. |
| R26-148 | Identificar writer/composição institucional e bytes hash-bound do __CVG_OPERATOR_BOOTSTRAP_TOKEN_PROVIDER__, com closure de referências de módulo do callback efetivamente chamado. |
| R26-149 | Identificar writer/composição institucional e bytes hash-bound do __CVG_OPERATOR_BOOTSTRAP_TOKEN_PROVIDER__, com closure de referências de módulo do callback efetivamente chamado. |
| R26-150 | Identificar writer/composição institucional e bytes hash-bound do __CVG_OPERATOR_BOOTSTRAP_TOKEN_PROVIDER__, com closure de referências de módulo do callback efetivamente chamado. |
| R26-151 | Identificar writer/contrato e prova concreta de valor string/null do __CVG_OPERATOR_BOOTSTRAP_TOKEN__ no bootstrap efetivo; o tipo TypeScript não valida o valor global lido/deletado/retornado. Conservar separada a pendência do provider fallback. |
| R26-152 | Identificar writer/contrato e prova concreta de valor string/null do __CVG_OPERATOR_BOOTSTRAP_TOKEN__ no bootstrap efetivo; o tipo TypeScript não valida o valor global lido/deletado/retornado. Conservar separada a pendência do provider fallback. |
| R26-168 | Hash-bound resolução física de node_modules/.bin/tsx e closure runtime do entry apps/worker/src/main.ts para os argumentos/cwd/env desta fixture. Não basta o path literal do entry para conhecer módulos que o launcher separado adquire. |
| R26-171 | Hash-bound resolução física de node_modules/.bin/tsx e closure runtime do entry apps/worker/src/main.ts para os argumentos/cwd/env desta fixture. Não basta o path literal do entry para conhecer módulos que o launcher separado adquire. Mapear também consumers reais do child retornado e seus métodos; nenhuma exclusão ampla pelo path de teste. |
| R26-172 | Hash-bound resolução física de node_modules/.bin/tsx e closure runtime do entry apps/worker/src/main.ts para os argumentos/cwd/env desta fixture. Não basta o path literal do entry para conhecer módulos que o launcher separado adquire. |
| R26-178 | Hash-bound resolução física de node_modules/.bin/tsx e closure runtime do entry apps/worker/src/main.ts para os argumentos/cwd/env desta fixture. Não basta o path literal do entry para conhecer módulos que o launcher separado adquire. |
| R26-183 | Hash-bound resolução física de node_modules/.bin/tsx e closure runtime do entry apps/worker/src/main.ts para os argumentos/cwd/env desta fixture. Não basta o path literal do entry para conhecer módulos que o launcher separado adquire. |
| R26-188 | Hash-bound resolução física de node_modules/.bin/tsx e closure runtime do entry apps/worker/src/main.ts para os argumentos/cwd/env desta fixture. Não basta o path literal do entry para conhecer módulos que o launcher separado adquire. |
| R26-193 | Hash-bound resolução física de node_modules/.bin/tsx e closure runtime do entry apps/worker/src/main.ts para os argumentos/cwd/env desta fixture. Não basta o path literal do entry para conhecer módulos que o launcher separado adquire. Mapear também consumers reais do child retornado e seus métodos; nenhuma exclusão ampla pelo path de teste. |
| R26-194 | Hash-bound resolução física de node_modules/.bin/tsx e closure runtime do entry apps/worker/src/main.ts para os argumentos/cwd/env desta fixture. Não basta o path literal do entry para conhecer módulos que o launcher separado adquire. |
| R26-199 | Hash-bound resolução física de node_modules/.bin/tsx e closure runtime do entry apps/worker/src/main.ts para os argumentos/cwd/env desta fixture. Não basta o path literal do entry para conhecer módulos que o launcher separado adquire. Mapear também consumers reais do child retornado e seus métodos; nenhuma exclusão ampla pelo path de teste. |
| R26-200 | Hash-bound resolução física de node_modules/.bin/tsx e closure runtime do entry apps/worker/src/main.ts para os argumentos/cwd/env desta fixture. Não basta o path literal do entry para conhecer módulos que o launcher separado adquire. |

## Próxima ação

Revisão independente dos 140 positivos hash-bound e obtenção das provas específicas das 82 observações pendentes nas lanes indicadas; conservar frontier INCOMPLETE.

Nenhum RootAGENTS/ledger/coord/parecer anterior foi lido. Nenhum payload, teste, CLI completo, PG, rede/provider, segredo, install ou subagent foi executado/acessado. Escritas limitadas ao output autorizado do packet.
