#!/usr/bin/env bash
set -euo pipefail
cd '/home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r19'
exec '/home/ricardo/.nvm/versions/node/v22.23.2/bin/node' --env-file='/home/ricardo/Área de trabalho/cvg-operational-harness/.env' --import '/home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r19/node_modules/tsx/dist/loader.mjs' '/home/ricardo/.cache/cvg-harness-green-20261004/local-r19/server.mts'
