import fs from 'node:fs'
import {auditProductBoundary} from './runtime/scripts/check-product-boundary.mjs'
try {
 const result=auditProductBoundary(new URL('./runtime/',import.meta.url).pathname)
 fs.writeFileSync(new URL('./installed-gate.json',import.meta.url),JSON.stringify(result,null,2)+'\n')
 console.log(JSON.stringify({status:result.status,passed:result.passed,sourceFiles:result.sourceFiles,coreFiles:result.coreFiles,diagnostics:result.diagnostics.length,violations:result.violations.length}))
} catch(e) {
 fs.writeFileSync(new URL('./installed-gate.json',import.meta.url),JSON.stringify({error:{name:e.name,message:e.message,stack:e.stack}},null,2)+'\n')
 console.error(e.message);process.exitCode=2
}
