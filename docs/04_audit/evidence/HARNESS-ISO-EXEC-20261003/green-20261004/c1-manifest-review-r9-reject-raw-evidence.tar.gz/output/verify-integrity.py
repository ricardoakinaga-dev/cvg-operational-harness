from pathlib import Path
import os,json,hashlib,stat
out=Path(__file__).resolve().parent;packet=out.parent;root=packet/'source'
def inventory(root):
 result={}
 for dp,ds,fs in os.walk(root,followlinks=False):
  for name in sorted(ds+fs):
   f=Path(dp)/name;s=f.lstat();v={'mode':stat.S_IMODE(s.st_mode),'mtime_ns':s.st_mtime_ns,'size':s.st_size}
   if f.is_symlink():v.update(kind='symlink',target=os.readlink(f))
   elif f.is_dir():v.update(kind='directory')
   elif f.is_file():v.update(kind='file',sha256=hashlib.sha256(f.read_bytes()).hexdigest())
   else:v.update(kind='other')
   result[str(f.relative_to(root))]=v
 s=root.stat();result['.']={'kind':'directory','mtime_ns':s.st_mtime_ns,'mode':stat.S_IMODE(s.st_mode)}
 return result
before=json.loads((out/'inventory-before.json').read_text());after=inventory(root)
(out/'inventory-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
differences=[{'path':k,'before':before.get(k),'after':after.get(k)} for k in sorted(before.keys()|after.keys()) if before.get(k)!=after.get(k)]
frozen=json.loads((packet/'frozen-inventory.json').read_text());freeze=json.loads((packet/'freeze.json').read_text());frozenMismatches=[]
for k,v in frozen.items():
 for field,z in v.items():
  a=after.get(k,{}).get({'bytes':'size'}.get(field,field));a='link' if field=='kind' and a=='symlink' else a
  if a!=z:frozenMismatches.append({'path':k,'field':field,'expected':z,'observed':a})
runtimeShared=[]
for k,v in before.items():
 if v['kind']=='file':
  a=(root/k).stat();b=(out/'runtime'/k).stat()
  if a.st_dev==b.st_dev and a.st_ino==b.st_ino:runtimeShared.append(k)
def fingerprint(prefix):
 selected={k:v for k,v in after.items() if prefix(k)}
 return {'entries':len(selected),'sha256':hashlib.sha256(json.dumps(selected,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
result={'sourceUnchanged':not differences,'differences':differences,'frozenInventorySha256':hashlib.sha256((packet/'frozen-inventory.json').read_bytes()).hexdigest(),'expectedFrozenInventorySha256':freeze['inventorySha256'],'frozenMismatches':frozenMismatches,'entries':len(after),'files':sum(v['kind']=='file' for v in after.values()),'symlinks':sum(v['kind']=='symlink' for v in after.values()),'directories':sum(v['kind']=='directory' for v in after.values()),'directoryMtimesUnchanged':all(after.get(k)==v for k,v in before.items() if v['kind']=='directory'),'sharedRegularFilesWithRuntime':runtimeShared,'sourceFingerprint':fingerprint(lambda k:True),'dependenciesFingerprint':fingerprint(lambda k:k=='node_modules' or k.startswith('node_modules/')),'distFingerprint':fingerprint(lambda k:'dist' in Path(k).parts),'inventoryBeforeSha256':hashlib.sha256((out/'inventory-before.json').read_bytes()).hexdigest(),'inventoryAfterSha256':hashlib.sha256((out/'inventory-after.json').read_bytes()).hexdigest()}
(out/'source-integrity.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
assert result['sourceUnchanged'] and not frozenMismatches and not runtimeShared and result['frozenInventorySha256']==result['expectedFrozenInventorySha256']
