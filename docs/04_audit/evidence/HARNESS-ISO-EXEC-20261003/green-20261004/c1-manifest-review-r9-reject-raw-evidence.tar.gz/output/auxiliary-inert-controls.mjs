import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {resolveWorkspaceTarget,classifyManifestDeclaration,extractModuleReferences} from './runtime/scripts/workspace-dependency-audit.mjs'
import {invalidTsconfigPathPatterns,expandSingleWildcard} from './runtime/scripts/tsconfig-path-grammar.mjs'
const out=new URL('.',import.meta.url).pathname;const root=path.join(out,'auxiliary-inert-fixtures');const raw=[]
const write=(name,text)=>{const p=path.join(root,name);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,text)}
write('packages/core/src/index.mts','export const label="neutral";');write('packages/$&/src/index.mts','export const label="neutral";')
const owners=[{name:'@synthetic/core',path:'packages/core',absolutePath:path.join(root,'packages/core')},{name:'@synthetic/data',path:'packages/$&',absolutePath:path.join(root,'packages/$&')}]
function check(id,get,expected){const observed=get();raw.push({id,expected,observed,fixturesExecuted:false});assert.deepEqual(observed,expected)}
try{
 check('auxiliary-physical-dollar-wildcard',()=>{const r=resolveWorkspaceTarget(root,owners,[{pattern:'@neutral/*',targets:['packages/*/src/index.mts'],basePath:root,configPath:'tsconfig.base.json',ownerPath:null}],owners[0],path.join(root,'packages/core/src/index.mts'),'@neutral/$&');return {resolution:r.resolution,target:r.target.name,resolvedPath:r.resolvedPath}}, {resolution:'TYPESCRIPT_PATH_ALIAS',target:'@synthetic/data',resolvedPath:path.join(root,'packages/$&/src/index.mts')})
 check('auxiliary-missing-alias-remains-unknown',()=>resolveWorkspaceTarget(root,owners,[{pattern:'@neutral/*',targets:['packages/*/src/absent.mts'],basePath:root,configPath:'tsconfig.base.json',ownerPath:null}],owners[0],path.join(root,'packages/core/src/index.mts'),'@neutral/$&').resolution,'MISSING_ALIAS_TARGET')
 check('auxiliary-type-only-dev-remains-unresolved',()=>classifyManifestDeclaration('PRODUCTION','TYPE_ONLY',['devDependencies'],{}),{status:'UNRESOLVED',reason:'PUBLIC_DECLARATION_ESCAPE_NOT_PROVEN'})
 check('auxiliary-dependency-category-runtime',()=>classifyManifestDeclaration('PRODUCTION','RUNTIME',['dependencies'],{dependencyCategoryRules:{PRODUCTION_RUNTIME:['dependencies']}}),{status:'DECLARED',reason:null})
 check('auxiliary-invalid-path-map',()=>invalidTsconfigPathPatterns({'@label/**':['neutral']}),['@label/**'])
 check('auxiliary-dollar-expansion',()=>expandSingleWildcard('packages/*/src','$&'),'packages/$&/src')
} finally {fs.writeFileSync(path.join(out,'auxiliary-inert-controls.json'),JSON.stringify(raw,null,2)+'\n')}
console.log(JSON.stringify({checks:raw.length,passed:raw.length}))
