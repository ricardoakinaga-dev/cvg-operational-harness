from pathlib import Path
import subprocess,json,hashlib
out=Path(__file__).resolve().parent; runtime=out/'runtime'; node='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node'
env={'PATH':str(Path(node).parent)+':/usr/bin:/bin','HOME':str(out),'TMPDIR':str(out/'tmp')}
raw=json.loads((out/'new-controls-raw.json').read_text())+json.loads((out/'discovery-followup-raw.json').read_text())
selected=['root-dependencies-invalid-npm-alias','core-dependencies-invalid-npm-alias','product-dependencies-invalid-npm-alias','product-dependencies-missing-local-target','core-dependencies-missing-local-target','root-dependencies-missing-local-target','omitted-core-workspace-invalid-manifest','omitted-product-workspace-invalid-manifest','discovery-packages_____','valid-metadata-no-edge','alias-dependencies-npm-product','core-unknown-constructor']
records=[];folder=out/'native-cli';folder.mkdir(exist_ok=True)
for r in raw:
 if r['id'] not in selected:continue
 argv=[node,str(runtime/'scripts/check-product-boundary.mjs'),r['root']]
 result=subprocess.run(argv,cwd=runtime,env=env,capture_output=True,text=True,timeout=60)
 stdout=folder/(r['id']+'.stdout.json');stderr=folder/(r['id']+'.stderr.txt');stdout.write_text(result.stdout);stderr.write_text(result.stderr)
 try:observed=json.loads(result.stdout)
 except json.JSONDecodeError:observed=None
 records.append({'id':r['id'],'argv':argv,'cwd':str(runtime),'exitCode':result.returncode,'expected':r['expected'],'observed':observed,'stderr':result.stderr,'stdoutPath':str(stdout),'stderrPath':str(stderr),'stdoutSha256':hashlib.sha256(stdout.read_bytes()).hexdigest(),'stderrSha256':hashlib.sha256(stderr.read_bytes()).hexdigest()})
(folder/'results.json').write_text(json.dumps(records,indent=2)+'\n')
for r in records:print(r['id'],r['exitCode'],r['observed'].get('status') if r['observed'] else r['stderr'].strip())
