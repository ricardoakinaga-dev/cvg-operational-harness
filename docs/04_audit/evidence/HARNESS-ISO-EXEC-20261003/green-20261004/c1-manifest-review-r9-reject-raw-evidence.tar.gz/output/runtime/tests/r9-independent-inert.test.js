// @vitest-environment node
// Inert text/JSON/symbol evidence only; fixture source is never imported.
import fs from 'node:fs'
import path from 'node:path'
import ts from 'typescript'
import { describe, it, expect, afterAll } from 'vitest'
import { auditProductBoundary } from '../scripts/check-product-boundary.mjs'
import { createBoundaryLexical } from '../scripts/boundary-lexical.mjs'
import { invalidTsconfigPathPatterns, expandSingleWildcard } from '../scripts/tsconfig-path-grammar.mjs'
const out = path.resolve('..')
const base = path.join(out, 'new-inert-fixtures')
const observations = []
fs.mkdirSync(base, {recursive:true})
const put = (root, name, value) => {const file=path.join(root,name);fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,typeof value==='string'?value:JSON.stringify(value,null,2)+'\n')}
const cases=[]
const add=(id,change,expected='BLOCKED',reason)=>cases.push({id,change,expected,reason})
const fields=['dependencies','devDependencies','optionalDependencies','peerDependencies']
for(const scope of ['root','core','product']) for(const field of fields) for(const [shape,value] of [['array',[]],['null',null],['number',29],['string','neutral'],['bad-key',{'@': '*'}],['bad-version',{'neutral':false}]]) add(`${scope}-${field}-${shape}`,v=>v[scope][field]=value)
for(const scope of ['root','core','product']) for(const field of fields) add(`${scope}-${field}-invalid-npm-alias`,v=>v[scope][field]={'neutral':'npm:@'})
for(const scope of ['root','core','product']) for(const field of fields) add(`${scope}-${field}-missing-local-target`,v=>v[scope][field]={'neutral':'file:./absent'},'INCOMPLETE','UNVERIFIED_LOCAL_DEPENDENCY')
for(const [id,workspaces] of [['duplicate',['packages/*','packages/*']],['object',{packages:['packages/*']}],['blank',[' ']],['explicit',['packages/core']],['escape',['../outside/*']],['nul',['packages/\u0000/*']]])add(`workspaces-${id}`,v=>v.root.workspaces=workspaces)
add('duplicate-product-identity',v=>v.product.name=v.core.name)
add('invalid-unreached-product-name',v=>v.product.name='@')
add('invalid-unreached-legacy-map',v=>v.legacy.peerDependencies=[])
add('omitted-product-workspace-invalid-manifest',v=>{v.root.workspaces=['packages/*','legacy/packages/*'];v.product.dependencies=[]})
add('omitted-core-workspace-invalid-manifest',v=>{v.root.workspaces=['products/*','legacy/packages/*'];v.core.dependencies=[]})
add('empty-workspace-discovery-invalid-product',v=>{v.root.workspaces=[];v.product.name=42})
add('valid-metadata-no-edge',()=>{},'PASS')
for(const field of fields){
 add(`alias-${field}-npm-product`,v=>v.core[field]={'neutral':'npm:@synthetic/product@*'},'FAIL','CORE_DEPENDS_ON_PRODUCT')
 add(`alias-${field}-file-product`,v=>v.core[field]={'neutral':'file:../../products/product'},'FAIL','CORE_DEPENDS_ON_PRODUCT')
 add(`alias-${field}-link-product`,v=>v.core[field]={'neutral':'link:../../products/product'},'FAIL','CORE_DEPENDS_ON_PRODUCT')
 add(`alias-${field}-external-overrides-product-key`,v=>v.core[field]={'@synthetic/product':'npm:external-neutral@*'},'PASS')
 add(`alias-${field}-physical-core-overrides-product-key`,v=>v.core[field]={'@synthetic/product':'file:../core'},'PASS')
}
add('unreached-product-ast-unknown',v=>v.productText='export const label=unknownValue.constructor;','PASS')
add('reached-legacy-ast-unknown',v=>{v.core.dependencies={'@synthetic/legacy':'*'};v.legacyText='export const label=unknownValue.constructor;'},'INCOMPLETE','UNVERIFIED_DYNAMIC_CODE_EXECUTION')
add('core-unknown-constructor',v=>v.coreText='export const label=unknownValue.constructor;','INCOMPLETE','UNVERIFIED_DYNAMIC_CODE_EXECUTION')
add('core-unresolved-import',v=>v.coreText='import "./absent.mjs";export const label="neutral";','INCOMPLETE','UNRESOLVED_MODULE_REFERENCE')
add('unreached-product-unresolved-import',v=>v.productText='import "./absent.mjs";export const label="neutral";','PASS')
for(const [id,text] of [
 ['stable-scalar-wrappers','const tag="neutral";const bag=({constructor:tag} satisfies {constructor:string});export const label=(bag as {constructor:string}).constructor;'],
 ['stable-scalar-destructure','const bag={constructor:"neutral"};const {constructor:tag}=bag;export const label=tag;'],
 ['parameter-sibling-neutral','function f(handle="neutral"){var handle;return handle;}export const label="neutral";'],
 ['catch-pattern-neutral','function f(){var handle="outer";try{throw "neutral"}catch(handle){var {tag:handle}={tag:"neutral"};return handle;}return handle;}export const label="neutral";']
])add(id,v=>v.coreText=text,'PASS')
for(const [id,text] of [
 ['mutable-object-write','const bag={constructor:"neutral"};bag.constructor=unknownValue;export const label=bag.constructor;'],
 ['pattern-object-write','const bag={constructor:"neutral"};({tag:bag.constructor}={tag:unknownValue});export const label=bag.constructor;'],
 ['wrapped-pattern-object-write','const bag={constructor:"neutral"};[(bag as {constructor:unknown}).constructor]=[unknownValue];export const label=bag.constructor;'],
 ['escaped-object-alias','const bag={constructor:"neutral"};const alias=bag;export const label=bag.constructor;'],
 ['exported-object-not-stable','export const bag={constructor:"neutral"};export const label=bag.constructor;']
])add(id,v=>v.coreText=text,'INCOMPLETE','UNVERIFIED_DYNAMIC_CODE_EXECUTION')
function fixture(c){
 const root=path.join(base,c.id);const v={root:{private:true,type:'module',workspaces:['packages/*','products/*','legacy/packages/*']},core:{name:'@synthetic/core',type:'module'},product:{name:'@synthetic/product',type:'module'},legacy:{name:'@synthetic/legacy',type:'module'},coreText:'export const label="neutral";',productText:'export const label="neutral";',legacyText:'export const label="neutral";'};c.change(v)
 for(const dir of ['packages/core/src','products/product/src','legacy/packages/legacy/src','apps'])fs.mkdirSync(path.join(root,dir),{recursive:true})
 put(root,'package.json',v.root);put(root,'packages/core/package.json',v.core);put(root,'products/product/package.json',v.product);put(root,'legacy/packages/legacy/package.json',v.legacy)
 put(root,'tsconfig.base.json',{compilerOptions:{module:'NodeNext',moduleResolution:'NodeNext',target:'ESNext',allowJs:true}})
 put(root,'packages/core/src/index.mts',v.coreText);put(root,'products/product/src/index.mts',v.productText);put(root,'legacy/packages/legacy/src/index.mts',v.legacyText)
 return root
}
afterAll(()=>fs.writeFileSync(path.join(out,'new-controls-raw.json'),JSON.stringify(observations,null,2)+'\n'))
describe('R9 fresh global manifest and physical alias controls',()=>{
 for(const c of cases)it(c.id,()=>{
  const root=fixture(c);let result,error
  try{result=auditProductBoundary(root)}catch(e){error={name:e.name,message:e.message,stack:e.stack}}
  const raw={id:c.id,root,expected:c.expected,expectedReason:c.reason??null,fixturesExecuted:false,result:result??null,error:error??null};observations.push(raw);put(root,'native-observation.json',raw)
  if(c.expected==='BLOCKED')expect(Boolean(error)||result?.passed===false,c.id).toBe(true)
  else{expect(error,c.id).toBeUndefined();expect(result.status,c.id).toBe(c.expected);if(c.reason)expect([...result.diagnostics,...result.violations].some(v=>v.reason===c.reason),c.id).toBe(true)}
 })
})
function lexical(text,commonJs=false){const source=ts.createSourceFile(commonJs?'neutral.cjs':'neutral.mts',text,ts.ScriptTarget.Latest,true);const l=createBoundaryLexical(ts,source,commonJs);const ids=[];const visit=n=>{if(ts.isIdentifier(n)&&n.text==='handle')ids.push(n);ts.forEachChild(n,visit)};visit(source);expect(source.parseDiagnostics).toEqual([]);return {source,l,ids}}
describe('fresh inert lexical identity and grammar controls',()=>{
 it('separates non-simple parameter/body cells with initial transfer',()=>{const {l,ids}=lexical('function f(handle="neutral"){var handle;return handle;}');expect(l.identity(ids[0])).not.toBe(l.identity(ids[1]));expect(l.identity(ids[1])).toBe(l.identity(ids[2]));expect(l.initialTransfers).toHaveLength(1)})
 it('shares simple parameter and var cells',()=>{const {l,ids}=lexical('function f(handle){var handle;return handle;}');expect(l.identity(ids[0])).toBe(l.identity(ids[1]));expect(l.identity(ids[1])).toBe(l.identity(ids[2]))})
 it('catch initializer write targets catch cell while var declaration stays outer',()=>{const {l,ids}=lexical('function f(){var handle;try{}catch(handle){var {tag:handle}={tag:"neutral"};}return handle;}');expect(l.identity(ids[0])).toBe(l.identity(ids[2]));expect(l.writeIdentity(ids[2])).toBe(l.identity(ids[1]));expect(l.identity(ids[3])).toBe(l.identity(ids[0]))})
 it('nested block alias retains its own symbol',()=>{const {l,ids}=lexical('const handle="outer";{const handle="inner";const tag=handle;}const tag=handle;');expect(l.identity(ids[0])).not.toBe(l.identity(ids[1]));expect(l.identity(ids[1])).toBe(l.identity(ids[2]));expect(l.identity(ids[0])).toBe(l.identity(ids[3]))})
 it('CJS top-level var belongs to wrapper but static block var does not',()=>{const source=ts.createSourceFile('neutral.cjs','var require;const a=require;class X{static{var require="neutral";const b=require;}}',ts.ScriptTarget.Latest,true);const l=createBoundaryLexical(ts,source,true);const ids=[];const visit=n=>{if(ts.isIdentifier(n)&&n.text==='require')ids.push(n);ts.forEachChild(n,visit)};visit(source);expect(l.identity(ids[0])).toBe(l.global('require'));expect(l.identity(ids[1])).toBe(l.global('require'));expect(l.identity(ids[2])).not.toBe(l.global('require'));expect(l.identity(ids[2])).toBe(l.identity(ids[3]))})
 it('transparent wrappers do not erase value symbol',()=>{const {l,ids}=lexical('const handle="neutral";const tag=((handle as string) satisfies string)!;');expect(l.identity(ids[0])).toBe(l.identity(ids[1]));expect(l.erased(ids[1])).toBe(false)})
 for(const [id,paths] of [['array',[]],['null',null],['multiple-stars',{'a**':['neutral']}],['empty-target',{'a':['']}],['mixed-target',{'a':['neutral',17]}]])it('invalid-paths-'+id,()=>expect(invalidTsconfigPathPatterns(paths).length).toBeGreaterThan(0))
 it('valid wildcard expansion retains literal dollar symbols',()=>{expect(invalidTsconfigPathPatterns({'@neutral/*':['packages/*/src']})).toEqual([]);expect(expandSingleWildcard('packages/*/src','$&')).toBe('packages/$&/src')})
})
