// @vitest-environment node
import fs from 'node:fs'
import path from 'node:path'
import {it,expect,afterAll} from 'vitest'
import {auditProductBoundary} from '../scripts/check-product-boundary.mjs'
const out=path.resolve('..');const records=[]
afterAll(()=>fs.writeFileSync(path.join(out,'discovery-followup-raw.json'),JSON.stringify(records,null,2)+'\n'))
for(const pattern of ['packages/**/*','packages/*/*','packages/{core,other}/*','packages/[co]ore/*'])it('nonterminal-glob-'+pattern,()=>{
 const id='discovery-'+pattern.replace(/[^a-z]/g,'_');const root=path.join(out,'new-inert-fixtures',id)
 const put=(f,v)=>{const p=path.join(root,f);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n')}
 for(const d of ['packages/core/src','products/product/src','apps','legacy'])fs.mkdirSync(path.join(root,d),{recursive:true})
 put('package.json',{private:true,type:'module',workspaces:[pattern,'products/*']})
 put('packages/core/package.json',{name:'@synthetic/core',type:'module',dependencies:{'@synthetic/product':'*'}})
 put('products/product/package.json',{name:'@synthetic/product',type:'module'})
 put('packages/core/src/index.mts','export const label="neutral";')
 put('products/product/src/index.mts','export const label="neutral";')
 let result,error;try{result=auditProductBoundary(root)}catch(e){error={message:e.message,stack:e.stack}}
 const raw={id,pattern,root,expected:'BLOCKED_OR_FAIL_OR_INCOMPLETE',fixturesExecuted:false,result:result??null,error:error??null};records.push(raw);put('native-observation.json',raw)
 expect(Boolean(error)||result.passed===false,pattern).toBe(true)
})
