import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
import {caseOccurrences} from './work/scripts/hiso-inventory.mjs';
import {gateTestInventory,testReport,verifySnapshots} from './work/scripts/hiso-reports.mjs';
import {sourceFiles,exact} from './work/scripts/hiso-contract.mjs';
import {ownerMapping} from './work/scripts/hiso-variant.mjs';
const out=import.meta.dirname,root=path.join(out,'work'),raw=path.join(out,'raw'),d=path.join(out,'inert-fixtures/membership');fs.mkdirSync(d,{recursive:true});
const collected=JSON.parse(fs.readFileSync(path.join(raw,'collection.json')));
const inventory=caseOccurrences(collected.map(t=>({file:path.relative(root,t.file),name:t.name,kind:'COLLECTED_NOT_EXECUTED'})));
fs.writeFileSync(path.join(raw,'collected-case-inventory.json'),JSON.stringify(inventory,null,2));
let activeLabel="";const rows=[];function check(label,fn){activeLabel=label;try{rows.push({label,outcome:'ACCEPTED',result:fn()??null})}catch(e){rows.push({label,outcome:'REJECTED',error:e.message})}}
check('collection_complete_vs_owner_mapping',()=>exact([...new Set(inventory.map(t=>t.file))],ownerMapping(sourceFiles(root)).filter(f=>f.path.includes('.test.')).map(f=>f.path),'complete_unit_test_source_inventory'));
function native(required){const files=[...new Set(required.map(t=>t.file))];return {syntheticValidationOnly:true,success:true,numTotalTests:required.length,numPassedTests:required.length,numFailedTests:0,numFailedTestSuites:0,testResults:files.map(file=>({name:path.join(root,file),status:'passed',assertionResults:required.filter(t=>t.file===file).map(t=>({ancestorTitles:[],title:t.name,status:'passed'}))}))}}
function verify(id,report,more={}){const saved=path.join(raw,'membership');fs.mkdirSync(saved,{recursive:true});fs.writeFileSync(path.join(saved,activeLabel+'.json'),JSON.stringify(report,null,2));const p=id+'.json';fs.writeFileSync(path.join(d,p),JSON.stringify(report));return verifySnapshots({gate:{id,skipPolicy:'none'},entry:{outputs:[{path:p}]},directory:d,manifest:{testInventory:inventory,...more.manifest},expected:more.expected??{}})}
for(const id of ['postgres','chaos']){
 const required=gateTestInventory(id,inventory);rows.push({label:id+'_command_and_collected_manifest',command:JSON.parse(fs.readFileSync(path.join(root,'package.json'))).scripts['test:'+id],files:[...new Set(required.map(t=>t.file))],cases:required.length,rootCases:inventory.length,kind:'COLLECTED_NOT_EXECUTED'});
 const report=native([...required].reverse());check(id+'_complete_reordered_native',()=>({cases:verify(id,report).tests.length}));
 const missing=native(required.slice(1));check(id+'_producer_report_oracle_omission',()=>({cases:testReport(missing,missing.testResults.map(f=>path.relative(root,f.name)),'none').length}));check(id+'_verifier_rejects_collected_case_omission',()=>verify(id,missing));
 const missingFile=report.testResults.slice(1);const n=missingFile.reduce((a,f)=>a+f.assertionResults.length,0);check(id+'_missing_suite',()=>verify(id,{...report,testResults:missingFile,numTotalTests:n,numPassedTests:n}));
 const mutated=structuredClone(report);mutated.testResults[0].assertionResults[0].title+=' INERT_CHANGED';check(id+'_changed_identity',()=>verify(id,mutated));
}
const required=inventory.filter(t=>t.file==='tests/hiso-security.test.js');const report=native(required);const executed=testReport(report,[...new Set(required.map(t=>t.file))],'none');check('unit_canonical_reversed_manifest',()=>({cases:verify('unit',report,{manifest:{executedTestInventory:[...executed].reverse()},expected:{requiredTestIds:required.map(t=>t.id)}}).tests.length}));
const omitted=native(required.slice(1)),observed=testReport(omitted,[required[0].file]);check('unit_missing_even_when_manifest_agrees',()=>verify('unit',omitted,{manifest:{executedTestInventory:observed},expected:{requiredTestIds:required.map(t=>t.id)}}));
fs.writeFileSync(path.join(raw,'collected-membership-probes.json'),JSON.stringify(rows,null,2));console.log(JSON.stringify(rows,null,2));
