import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {sourceFiles,digest,validateContract,canonical,VERSION} from './work/scripts/hiso-contract.mjs';
import {prepareVariant,rules,rulesHash} from './work/scripts/hiso-variant.mjs';
import {approvedCoverageInventory,coverageSourceInventory,caseOccurrences} from './work/scripts/hiso-inventory.mjs';
import {snapshotSchema,verifySnapshots,testReport,gateTestInventory,envelope} from './work/scripts/hiso-reports.mjs';
import {buildCoverageReport} from './work/scripts/lib/coverage-gate.mjs';
const out=import.meta.dirname,root=path.join(out,'work'),raw=path.join(out,'raw');
const rows=[];
function observe(label,fn){try{const result=fn();rows.push({label,outcome:'ACCEPTED',result:result??null});return result}catch(e){rows.push({label,outcome:'REJECTED',error:e.message});return null}}
const H='a'.repeat(64),binding={runId:'local-r6-inert',candidateId:H};
const fixture=path.join(out,'inert-fixtures');fs.mkdirSync(fixture,{recursive:true});
function verify(id,report,inventory=[],more={}){const directory=path.join(fixture,id);fs.mkdirSync(directory,{recursive:true});const p='report.json';fs.writeFileSync(path.join(directory,p),JSON.stringify(report,null,2));return verifySnapshots({gate:{id,skipPolicy:'none'},entry:{outputs:[{path:p}]},directory,manifest:{...binding,testInventory:inventory,...more.manifest},expected:more.expected??{}})}
observe('contract_and_original371_hashes',()=>validateContract(root));
const baseline=JSON.parse(fs.readFileSync(path.join(root,'scripts/hiso-baseline-inventory.json')));
observe('protected_counts',()=>({originalTests:baseline.tests.length,newTests:baseline.newTests.length,coverageOriginal:baseline.coveragePaths.length,coverageNew:baseline.newCoveragePaths.length,coverageActual:approvedCoverageInventory(root).length}));
const frozen=JSON.parse(fs.readFileSync(path.join(root,'tests/fixtures/hiso-r6-projection.json')));
for(const mode of ['retained','neutral']){
 const scope=mode==='neutral'?'harness-neutral':'transition-regression',target=path.join(out,mode+'-projection');
 const variant=prepareVariant(root,target,scope);
 fs.writeFileSync(path.join(raw,mode+'-variant.json'),JSON.stringify(variant,null,2));
 fs.symlinkSync(path.join(root,'node_modules'),path.join(target,'node_modules'));
 observe(mode+'_seven_config_exact',()=>{assert.equal(rulesHash,frozen.rulesHash);for(const p of frozen.configPaths){const bytes=fs.readFileSync(path.join(target,p));assert.equal(digest({x:bytes.toString()}),digest({x:frozen[mode][p].content}));}return {configPaths:frozen.configPaths,productsPresent:fs.existsSync(path.join(target,'products'))}});
 observe(mode+'_coverage_denominator',()=>approvedCoverageInventory(target).length);
 if(mode==='neutral'){
  for(const p of frozen.configPaths){const f=path.join(target,p),b=fs.readFileSync(f);fs.appendFileSync(f,'\n');observe('neutral_config_drift_'+p,()=>approvedCoverageInventory(target).length);fs.writeFileSync(f,b)}
  fs.mkdirSync(path.join(target,'products/shift-assistant'),{recursive:true});fs.writeFileSync(path.join(target,'products/shift-assistant/marker.txt'),'inert');observe('neutral_products_reappear',()=>approvedCoverageInventory(target).length);fs.rmSync(path.join(target,'products'),{recursive:true});
  for(const p of frozen.configPaths)fs.writeFileSync(path.join(target,p),frozen.retained[p].content);
  observe('only_products_removed_retained_configs',()=>approvedCoverageInventory(target).length);
  for(const p of frozen.configPaths)fs.writeFileSync(path.join(target,p),frozen.neutral[p].content);
 }
}
const input=path.join(fixture,'inputs');fs.mkdirSync(input);
for(const p of ['packages/x/src/dist/leaf.mjs','packages/x/src/.gauntlet/dist/leaf.mjs','certification/custom.json','certification/logs/active/leaf.mjs','.gauntlet/dist/leaf.mjs','dist/leaf.mjs']){
 const f=path.join(input,p);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,p.endsWith('.json')?'{"marker":1}':'export const marker=1;');
 const before=sourceFiles(input);assert(before.some(x=>x.path===p));fs.appendFileSync(f,' ');assert.notEqual(digest(before),digest(sourceFiles(input)));rows.push({label:'effective_input_'+p,outcome:'INCLUDED_AND_BOUND'});
}
const pg={schemaVersion:1,status:'PASS',version:160000,...binding};
observe('numeric_pg_positive',()=>verify('postgres-version',pg));
for(const v of ['160000',160000.5]){
 const report={...pg,version:v};observe('pg_snapshot_schema_'+String(v)+'_'+typeof v,()=>snapshotSchema(report,'postgres-version'));
 // Exact producer predicate from hiso-ci.mjs:143-150, no evaluator/process/VM.
 const producerAccepts=report.status==='PASS'&&report.version>=160000&&report.version<170000&&report.runId===binding.runId&&report.candidateId===binding.candidateId;
 rows.push({label:'pg_producer_predicate_'+typeof v,version:v,producerAccepts,proof:'pure constants; exact producer comparison, not execution of PG'});
 observe('pg_verifier_'+typeof v,()=>verify('postgres-version',report));
}
for(const id of ['public-smoke','inventory','postgres-version'])observe('unknown_envelope_'+id,()=>envelope({schemaVersion:999},id));
const metrics=(n=10)=>Object.fromEntries(['statements','branches','functions','lines'].map(k=>[k,{total:n,covered:n,skipped:0,pct:n?100:null}]));
const manifest=JSON.parse(fs.readFileSync(path.join(root,'scripts/critical-coverage-manifest.json')));
const summary=Object.fromEntries(manifest.groups.flatMap(g=>g.paths).map(p=>[p,metrics()]));summary.total=metrics(10000);
const critical=buildCoverageReport(summary,manifest);observe('real_coverage_producer_projection',()=>verify('coverage-critical',critical));
for(const kind of ['omit_group','contradict_counts','zero_global','threshold','omit_file']){const r=structuredClone(critical);if(kind==='omit_group')r.critical.groups.pop();if(kind==='contradict_counts')r.critical.groups[0].metrics.branches.covered--;if(kind==='zero_global')r.global.metrics.lines=metrics(0).lines;if(kind==='threshold')r.global.thresholds.branches=0;if(kind==='omit_file')r.critical.groups[0].files.pop();observe('critical_'+kind,()=>verify('coverage-critical',r));}
const evals=JSON.parse(frozen.nativeEvalArtifact.content);observe('native_eval_artifact_only_no_evaluator',()=>verify('evals',evals));
for(const kind of ['zero_scenarios','omit_metric','threshold','contradict_failures']){const r=structuredClone(evals);if(kind==='zero_scenarios')r.metrics.scenarios=0;if(kind==='omit_metric')delete r.metrics.taskSuccessRate;if(kind==='threshold')r.thresholds.taskSuccessRate=0;if(kind==='contradict_failures')r.failures=[{scenarioId:'inert-contradiction',reasons:['intent_mismatch:synthetic']}];observe('eval_'+kind,()=>verify('evals',r));}
fs.writeFileSync(path.join(raw,'independent-probes.json'),JSON.stringify(rows,null,2));
console.log(JSON.stringify(rows,null,2));
