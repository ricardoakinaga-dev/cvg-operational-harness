import fs from 'node:fs';import path from 'node:path';import {auditProductBoundary} from './runtime/scripts/check-product-boundary.mjs';
const out=path.resolve('output'),rows=[];
const cases=[
['manifest-array',{'package.json':'[]'}],
['manifest-string',{'package.json':'"neutral"'}],
['workspaces-null',{'package.json':JSON.stringify({workspaces:null})}],
['dependency-array',{'packages/core/package.json':JSON.stringify({name:'@neutral/core',dependencies:['@neutral/consumer']})}],
['dependency-string',{'packages/core/package.json':JSON.stringify({name:'@neutral/core',dependencies:'@neutral/consumer'})}],
['unrelated-product-manifest-array',{'products/consumer/package.json':'[]'}],
['unrelated-product-name-number',{'products/consumer/package.json':JSON.stringify({name:13})}],
['valid-empty-workspaces',{'package.json':JSON.stringify({workspaces:[]})}],
['valid-unused-product',{}]
];
for(const [id,overrides]of cases){const root=path.join(out,'global-fixtures',id),files={
'package.json':JSON.stringify({private:true,type:'module',workspaces:['packages/*','products/*']}),
'packages/core/package.json':JSON.stringify({name:'@neutral/core',type:'module'}),
'packages/core/src/index.mts':'export const label="neutral";',
'products/consumer/package.json':JSON.stringify({name:'@neutral/consumer',type:'module'}),
'products/consumer/src/index.mts':'export const label="neutral";',...overrides};for(const d of ['apps','legacy'])fs.mkdirSync(path.join(root,d),{recursive:true});for(const [r,t]of Object.entries(files)){const p=path.join(root,r);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,t);}let audit,error;try{audit=auditProductBoundary(root);}catch(e){error=e.message;}const validControl=id.startsWith('valid-'),proofPassed=validControl?audit?.status==='PASS':!!error||audit?.status==='INCOMPLETE'||audit?.status==='FAIL';rows.push({id,kind:'native global input validation',fixture:path.relative(out,root),inputs:overrides,expected:validControl?'PASS':'blocked',proofPassed,...(audit?{audit}:{error})});}
const result={node:process.version,nodePath:process.execPath,fixturesExecuted:false,checkerModified:false,counts:{total:rows.length,passed:rows.filter(r=>r.proofPassed).length,failed:rows.filter(r=>!r.proofPassed).length},rows};fs.writeFileSync(path.join(out,'global-input-results.json'),JSON.stringify(result,null,2)+'\n');fs.writeFileSync(path.join(out,'global-input-raw-failures.json'),JSON.stringify(rows.filter(r=>!r.proofPassed),null,2)+'\n');console.log(JSON.stringify(result,null,2));if(result.counts.failed)process.exitCode=1;
