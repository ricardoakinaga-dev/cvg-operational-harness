# Backlog local — C1_REACHABLE_FRESH_REVIEW_R8

| ID | Prioridade | Estado | Trabalho / dependência / pronto |
| --- | --- | --- | --- |
| C1-R8-F01 | P1 | OPEN — Lead | Validar formato dos inputs globais de manifest/workspaces/name/dependency antes da closure. Reproduções: sete inputs inválidos com PASS. Fechamento: inputs inválidos bloqueiam; controles positivos/unknowns e produto isolado preservados; suíte 363 e nova crítica sob freeze. Nenhum fix aplicado. |
| C1-INSTALLED | Gate | INCOMPLETE | 1.610 diagnósticos na cópia instalada; esta crítica não concede aceite instalado/global/produção. Lead mantém gates próprios. |
| C1-R8-INTEGRATION | T1 | Lead pending | Integrar report/evidências e atualizar claim/ledgers do repositório com autorização vigente; nenhum push autorizado nesta crítica. |

[Finding](report.md) · [Falhas brutas](global-input-raw-failures.json) · [Estado local](99_runtime_state.md)
