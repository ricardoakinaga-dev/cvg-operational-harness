import fs from 'node:fs';import path from 'node:path';
const src=path.resolve('source'),dst=path.resolve('output/runtime');
fs.cpSync(src,dst,{recursive:true,dereference:false,verbatimSymlinks:true,preserveTimestamps:true});
let files=0,dirs=0,links=0;const errors=[];
function walk(p,r=''){const s=fs.lstatSync(p);if(s.isSymbolicLink()){links++;const resolved=fs.realpathSync(p);if(!resolved.startsWith(dst+'/'))errors.push('external-link:'+r);}else if(s.isDirectory()){dirs++;for(const n of fs.readdirSync(p))walk(path.join(p,n),r?r+'/'+n:n);}else{files++;const original=fs.lstatSync(path.join(src,r));if(s.ino===original.ino&&s.dev===original.dev||s.nlink!==1)errors.push('hardlink:'+r);}}
walk(dst);fs.mkdirSync('output/tmp',{recursive:true});fs.mkdirSync('output/home',{recursive:true});fs.mkdirSync('output/cache',{recursive:true});const result={files,dirs,links,physicalNoHardlinks:errors.length===0,noExternalLinks:errors.length===0,errors};fs.writeFileSync('output/runtime-copy-validity.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));if(errors.length)process.exitCode=1;
