import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const base=process.cwd(), src=path.join(base,'source'), out=path.join(base,'output');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const inventoryBytes=fs.readFileSync(path.join(base,'frozen-inventory.json'));
const inventory=JSON.parse(inventoryBytes);
const frozen='532640aca3626c71d49ba1acb872f3f6f95304884fccddc29240948878316e7e';
if(hash(inventoryBytes)!==frozen) throw Error('freeze mismatch');
function snapshot(root){const rows={};function walk(p,r){const s=fs.lstatSync(p,{bigint:true});const row={kind:s.isDirectory()?'dir':s.isSymbolicLink()?'link':s.isFile()?'file':'other',ino:String(s.ino),dev:String(s.dev),nlink:String(s.nlink),mode:String(s.mode),size:String(s.size),mtimeNs:String(s.mtimeNs),ctimeNs:String(s.ctimeNs)};if(row.kind==='file')row.sha256=hash(fs.readFileSync(p));if(row.kind==='link')row.target=fs.readlinkSync(p);rows[r]=row;if(row.kind==='dir')for(const n of fs.readdirSync(p).sort())walk(path.join(p,n),r?r+'/'+n:n);}walk(root,'');return rows;}
function verify(snap){const errors=[];const leaves=Object.keys(snap).filter(p=>snap[p].kind!=='dir');for(const [p,v]of Object.entries(inventory)){const a=snap[p];if(!a||a.kind!==v.kind||v.kind==='file'&&(a.sha256!==v.sha256||Number(a.size)!==v.bytes)||v.kind==='link'&&a.target!==v.target)errors.push(p);}for(const p of leaves)if(!inventory[p])errors.push('extra:'+p);return{valid:errors.length===0,errors,files:leaves.length,dirs:Object.values(snap).filter(v=>v.kind==='dir').length};}
const phase=process.argv[2];const snap=snapshot(src);fs.writeFileSync(path.join(out,`integrity-${phase}-full.json`),JSON.stringify(snap,null,2)+'\n');const result={phase,freeze:frozen,wholeSource:verify(snap),deps:verify(Object.fromEntries(Object.entries(snap).filter(([p])=>p.startsWith('node_modules/'))))};
// Subset validity is derived from whole inventory validation, not a subset against the whole inventory.
result.deps={valid:result.wholeSource.valid,entries:Object.keys(snap).filter(p=>p==='node_modules'||p.startsWith('node_modules/')).length};
if(phase==='before'){
fs.writeFileSync(path.join(out,'authority-inputs-before.json'),JSON.stringify(Object.fromEntries(['authority.json','freeze.json','frozen-inventory.json'].map(p=>[p,snapshot(path.join(base,p))['']])),null,2));
}else{
const before=JSON.parse(fs.readFileSync(path.join(out,'integrity-before-full.json')));const changed=[];for(const p of new Set([...Object.keys(before),...Object.keys(snap)]))if(JSON.stringify(before[p])!==JSON.stringify(snap[p]))changed.push(p);result.unchanged=changed.length===0;result.changed=changed;result.dirsValid=changed.every(p=>before[p]?.kind!=='dir'&&snap[p]?.kind!=='dir');const inputsBefore=JSON.parse(fs.readFileSync(path.join(out,'authority-inputs-before.json')));result.authorityInputsValid=['authority.json','freeze.json','frozen-inventory.json'].every(p=>JSON.stringify(inputsBefore[p])===JSON.stringify(snapshot(path.join(base,p))['']));
}
fs.writeFileSync(path.join(out,`integrity-${phase}.json`),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));if(!result.wholeSource.valid||result.unchanged===false)process.exitCode=1;
