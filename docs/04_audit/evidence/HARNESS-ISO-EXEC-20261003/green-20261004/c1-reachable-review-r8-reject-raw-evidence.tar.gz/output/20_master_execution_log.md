# Execution log local — C1_REACHABLE_FRESH_REVIEW_R8

1. Authority/freeze/inventory/constituição fornecidos lidos primeiro. Freeze SHA-256 conferido.
2. Claim local exclusivo output; snapshot integral before: 19.382 arquivos/links, 1.970 diretórios.
3. Runtime físico copiado sob output, sem hardlinks/links externos; tmp/cache locais.
4. Node22 absoluto, Vitest nativo fornecido: 363/363, exit 0. Suíte original code-execution não executada.
5. Três implementações reais inspecionadas; 222 assertions próprias iniciais passam: 180 nativas e 42 abstratas, fixtures não executadas.
6. Inputs globais: nove provas, dois controles passam, sete inputs inválidos recebem PASS indevido; exit 1, falhas brutas mantidas. C1-R8-F01 P1.
7. Scan instalado real parse-only: INCOMPLETE, 1.610 diagnósticos, zero violações, exit 1. Nenhum aceite global.
8. Normalização distingue assertion proofPassed e auditPassed; arquivo bruto intacto. ENOENT de inspeção metadata corrigido e preservado.
9. Snapshot integral after igual ao before, incluindo hashes/inodes/mtime/ctime/dirs; authority/freeze/inventory inalterados. Runtime final checker/teste idênticos; somente cache Vitest original mudou na cópia.
10. Report md/json REJECT scoped e ledgers locais entregues. Nenhum fix/commit/source write. Lead responsável pela integração.

[Comandos](commands.json) · [Relatório](report.md) · [Falhas globais](global-input-raw-failures.json)
