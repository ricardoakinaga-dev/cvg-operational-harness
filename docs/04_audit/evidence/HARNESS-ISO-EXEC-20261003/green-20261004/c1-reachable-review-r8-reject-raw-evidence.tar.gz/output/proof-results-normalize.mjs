import fs from 'node:fs';
const original=JSON.parse(fs.readFileSync('output/proof-results.json','utf8'));
// In the raw first driver, native audit.passed is distinct from assertion success.
// Keep that raw artifact intact; add an explicit proofPassed field in a derived view.
const failed=new Set(original.failures.map(r=>r.id));
const rows=original.rows.map(r=>{const {passed,...rest}=r;return {...rest,proofPassed:!failed.has(r.id),...(r.kind==='native auditProductBoundary parse-only'?{auditPassed:passed}:{})};});
fs.writeFileSync('output/proof-results-normalized.json',JSON.stringify({...original,rows},null,2)+'\n');
console.log(JSON.stringify({assertions:original.counts,normalization:'native audit.passed preserved as auditPassed; assertion result is proofPassed; raw untouched'}));
