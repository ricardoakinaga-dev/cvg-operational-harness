import os,pathlib,json,hashlib,sys
base=pathlib.Path('/home/ricardo/.cache/cvg-harness-green-20261004'); out=base/'ci-native-admission-r11-builder'
def inventory(root):
 rows={};meta={}
 for directory,dirs,files in os.walk(root,followlinks=False):
  dirs.sort();files.sort()
  for n in dirs+files:
   p=pathlib.Path(directory)/n;rel=str(p.relative_to(root)); s=p.lstat()
   if rel.startswith('node_modules/.r11-tmp') or rel.startswith('node_modules/.vite'):continue
   kind='link' if p.is_symlink() else 'directory' if p.is_dir() else 'file'
   meta[rel]={'mode':s.st_mode,'mtimeNs':s.st_mtime_ns,'size':s.st_size,'kind':kind}
   if kind=='link':rows[rel]={'kind':'link','target':os.readlink(p)}
   elif kind=='file':rows[rel]={'kind':'file','bytes':s.st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 rows=dict(sorted(rows.items()));meta=dict(sorted(meta.items()))
 groups={k:{p:v for p,v in rows.items() if ('dependencies' if p.startswith('node_modules/') else 'dist' if any(x in ('dist','dist-runtime','dist-public') for x in pathlib.Path(p).parts) or p.endswith('.tsbuildinfo') else 'source')==k} for k in ['source','dependencies','dist']}
 return {'root':str(root),'rows':rows,'metadata':meta,'groups':{k:{'count':len(v),'sha256':hashlib.sha256(json.dumps(v,sort_keys=True).encode()).hexdigest()} for k,v in groups.items()}}
phase=sys.argv[1]
for name,root in [('source',base/'ci-importer-counter-review-r10/source'),('candidate',base/'ci-native-admission-r11-candidate')]:
 data=inventory(root);(out/'proofs'/f'{name}-{phase}-complete.json').write_text(json.dumps(data,indent=2)); print(name,phase,len(data['rows']),data['groups'])
