import fs from 'node:fs';import path from 'node:path';import {createRequire,registerHooks,syncBuiltinESMExports}from'node:module';
const require=createRequire(import.meta.url),log=process.env.CRITIC_NETWORK_LOG;
const deny=(name)=>(...args)=>{if(log)fs.appendFileSync(log,JSON.stringify({name,pid:process.pid})+'\n');throw Error('CRITIC_NO_NETWORK:'+name);};
for(const [name,methods]of Object.entries({net:['connect','createConnection'],tls:['connect'],http:['request','get'],https:['request','get'],http2:['connect'],dgram:['createSocket']})){const m=require('node:'+name);for(const key of methods)m[key]=deny(name+'.'+key);}
require('node:net').Socket.prototype.connect=deny('Socket.connect');
const dns=require('node:dns');for(const k of Object.keys(dns)){if(/^(lookup|resolve|reverse)/.test(k)&&typeof dns[k]==='function')dns[k]=deny('dns.'+k);}for(const k of Object.keys(dns.promises)){if(/^(lookup|resolve|reverse)/.test(k)&&typeof dns.promises[k]==='function')dns.promises[k]=deny('dns.promises.'+k);}
require('node:net').Server.prototype.listen=deny('Server.listen');
globalThis.fetch=deny('fetch');
if(process.env.CRITIC_CHILD_LOG_DIR){const cp=require('node:child_process'),nativeSpawn=cp.spawnSync,dir=process.env.CRITIC_CHILD_LOG_DIR;fs.mkdirSync(dir,{recursive:true});let serial=0;cp.spawnSync=function(command,args,options){const startedAt=new Date().toISOString(),r=nativeSpawn.apply(this,arguments),id=process.pid+'-'+(++serial),stem=path.join(dir,id);fs.writeFileSync(stem+'.stdout.log',r.stdout??'');fs.writeFileSync(stem+'.stderr.log',r.stderr??'');fs.writeFileSync(stem+'.json',JSON.stringify({command,args,cwd:options?.cwd??process.cwd(),startedAt,finishedAt:new Date().toISOString(),status:r.status,signal:r.signal,error:r.error?.message},null,2));return r;};}
syncBuiltinESMExports();
const code=`export class Client { static criticIdentity='CI-R10-INERT-PG'; async connect() { throw new Error('CRITIC_PG_FORBIDDEN'); } async query() { throw new Error('CRITIC_PG_FORBIDDEN'); } async end() {} }; export class Pool extends Client {}; export default {Client,Pool};`;
const url='data:text/javascript,'+encodeURIComponent(code);
registerHooks({resolve(specifier,context,next){if(specifier==='pg'||specifier.startsWith('pg/'))return {url,shortCircuit:true};return next(specifier,context);}});
const pg=await import('pg');if(pg.Client.criticIdentity!=='CI-R10-INERT-PG')throw Error('pg ESM MOCK IDENTITY NOT EFFECTIVE');
if(process.env.CRITIC_GUARD_PROOF)fs.appendFileSync(process.env.CRITIC_GUARD_PROOF,JSON.stringify({pid:process.pid,node:process.versions.node,pgIdentity:pg.Client.criticIdentity,guard:'native net/tls/http/https/http2/dgram/dns/fetch',beforeProducerImport:true})+'\n');
