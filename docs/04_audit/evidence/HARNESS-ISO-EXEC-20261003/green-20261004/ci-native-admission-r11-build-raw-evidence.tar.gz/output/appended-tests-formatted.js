// R11: append-only native admission regressions; prior 182 cases stay byte exact.
const r11Summary = () => ({
  total: metrics(1000),
  ...Object.fromEntries(
    [...new Set(critical.groups.flatMap((g) => g.paths))].map((p) => [
      p,
      metrics(100),
    ]),
  ),
});
const r11Mutation = () => {
  const manifest = json("scripts/mutation-manifest.json");
  return {
    schemaVersion: 2,
    kind: "aud21-risk-mutation-guard",
    contract: manifest.contract,
    runId: "inert",
    candidateId: r10Hash,
    manifestSha256: r10Digest(manifest),
    selected: manifest.mutations.length,
    killed: manifest.mutations.length,
    survived: 0,
    timedOut: 0,
    errors: 0,
    domains: [...new Set(manifest.mutations.map((m) => m.domain))],
    mutations: manifest.mutations.map((m) => ({
      ...m,
      driver: undefined,
      testFiles: m.testFiles ?? [],
      status: "KILLED",
      exitCode: 1,
      durationMs: 1,
    })),
    verdict: "PASS",
  };
};
describe("R11 critical metrics native admission", () => {
  it.each(["statements", "lines", "functions"])(
    "accepts safe zero group %s",
    (dimension) => {
      const summary = r11Summary();
      for (const p of critical.groups[0].paths)
        summary[p][dimension] = { total: 0, covered: 0, skipped: 0, pct: null };
      const report = buildCoverageReport(summary, critical);
      expect(report.verdict).toBe("PASS");
      expect(() => snapshotSchema(report, "coverage-critical")).not.toThrow();
      expect(() => verify("coverage-critical", report)).not.toThrow();
      const forged = clone(report);
      forged.critical.groups[0].metrics[dimension].pct = 0;
      expect(() => snapshotSchema(forged, "coverage-critical")).toThrow();
    },
  );
  for (const dimension of ["statements", "lines", "functions", "branches"]) {
    it.each([-1, 0.5, 2 ** 53, "0", null])(
      "rejects malformed " + dimension + " skipped=%s",
      (value) => {
        const summary = r11Summary();
        summary[critical.groups[0].paths[0]][dimension].skipped = value;
        const report = buildCoverageReport(summary, critical);
        expect(report.verdict).toBe("FAIL");
        expect(() => snapshotSchema(report, "coverage-critical")).toThrow();
        const forged = buildCoverageReport(r11Summary(), critical);
        forged.critical.groups[0].files[0].metrics[dimension].skipped = value;
        expect(() => snapshotSchema(forged, "coverage-critical")).toThrow();
      },
    );
  }
  it.each(["omitted", "zero", "positive"])(
    "retains valid optional skipped %s",
    (kind) => {
      const summary = r11Summary();
      for (const entry of Object.values(summary))
        for (const v of Object.values(entry)) {
          if (kind === "omitted") delete v.skipped;
          else v.skipped = kind === "positive" ? 1 : 0;
        }
      const report = buildCoverageReport(summary, critical);
      expect(report.verdict).toBe("PASS");
      expect(() => snapshotSchema(report, "coverage-critical")).not.toThrow();
    },
  );
  it("rejects mathematically below integer95 with unchanged public pct=95", () => {
    const summary = r11Summary(),
      group = critical.groups.find((g) => g.id === "approval");
    const total = 9007199254700003,
      covered = 8556839291965002;
    for (const p of group.paths)
      summary[p].branches = { total: 0, covered: 0, skipped: 0, pct: null };
    summary[group.paths[0]].branches = { total, covered, skipped: 0, pct: 95 };
    expect(BigInt(covered) * 100n < BigInt(total) * 95n).toBe(true);
    const report = buildCoverageReport(summary, critical);
    expect(report.verdict).toBe("FAIL");
    expect(
      report.critical.groups.find((g) => g.id === "approval").metrics.branches
        .pct,
    ).toBe(95);
    // Forging just producer PASS fields still cannot cross independent admission.
    report.verdict = "PASS";
    report.failures = [];
    report.critical.pass = true;
    report.critical.failures = [];
    expect(() => snapshotSchema(report, "coverage-critical")).toThrow(
      "critical_coverage_raw_threshold:approval",
    );
  });
});
describe("R11 frozen mutation receipt authority", () => {
  it("admits every authoritative native source row", () =>
    expect(() => snapshotSchema(r11Mutation(), "mutation")).not.toThrow());
  it.each([
    "manifestSha256",
    "domains",
    "omission",
    "duplicate",
    "sourceSha256",
    "source",
    "domain",
    "mode",
    "from",
    "to",
    "budgetMs",
    "testFiles",
  ])("refuses receipt-only %s changes", (field) => {
    const report = r11Mutation();
    if (field === "manifestSha256") report.manifestSha256 = "0".repeat(64);
    else if (field === "domains") report.domains = ["coverage"];
    else if (field === "omission") {
      report.mutations.pop();
      report.selected--;
      report.killed--;
    } else if (field === "duplicate")
      report.mutations[1] = clone(report.mutations[0]);
    else if (field === "budgetMs") report.mutations[0][field]++;
    else if (field === "testFiles")
      report.mutations[0][field] = ["tests/inert.test.js"];
    else
      report.mutations[0][field] =
        field === "sourceSha256" ? "0".repeat(64) : "inert changed";
    expect(() => snapshotSchema(report, "mutation")).toThrow();
    expect(() => verify("mutation", report)).toThrow();
  });
  it("admits exact inventory in reordered rows/domains", () => {
    const report = r11Mutation();
    report.mutations.reverse();
    report.domains.reverse();
    expect(() => snapshotSchema(report, "mutation")).not.toThrow();
  });
});
function r11Import(kind = "passed", id = "postgres") {
  const selected = [
    row("tests/r11-inert.test.js", "same"),
    row("tests/r11-inert.test.js", "same"),
    ...[...new Set([...postgres, ...chaos])].flatMap((p) => [
      row(p, "same"),
      row(p, "same"),
    ]),
  ];
  const required = inventory(selected);
  const report = native(selected);
  if (kind === "governed unit") {
    report.testResults[0].assertionResults[0].status = "pending";
    report.numPassedTests--;
    report.numPendingTests = 1;
  }
  const d = temp(),
    original = path.join(d, "original"),
    out = path.join(d, "out");
  const env = {
    ...process.env,
    GITHUB_RUN_ID: "777",
    GITHUB_RUN_ATTEMPT: "1",
    GITHUB_SHA: "f".repeat(40),
    GITHUB_REPOSITORY: "synthetic/fixture",
    GITHUB_WORKFLOW: "Inert R10 fixture",
    CI_RUN_ID: "run-777-1",
    GITHUB_OUTPUT: path.join(d, "step-output.txt"),
    HISO_PG_VERSION_OUTPUT: path.join(d, "pg.json"),
  };
  const github = r10Runner(env);
  const state = {
    runId: "run-777-1",
    candidateId: r10Hash,
    nodeVersion: process.versions.node,
    gates: [],
  };
  fs.mkdirSync(original);
  fs.writeFileSync(path.join(original, "runtime.txt"), "inert fixture\n");
  for (const gate of r10Gates.filter((g) => g.id !== "artifacts")) {
    const log = "inert fixture; no gate execution: " + gate.id + "\n";
    const lp = "gates/" + gate.id + ".log";
    fs.mkdirSync(path.dirname(path.join(original, lp)), { recursive: true });
    fs.writeFileSync(path.join(original, lp), log);
    const entry = {
      id: gate.id,
      status: "PASS",
      exitCode: 0,
      runId: state.runId,
      candidateId: r10Hash,
      nodeVersion: state.nodeVersion,
      outputFailures: [],
      log: lp,
      logSha256: r10Sha(log),
    };
    let content = { inert: true };
    if (gate.id === "unit") content = report;
    if (["postgres", "chaos"].includes(gate.id)) {
      const selection = selected.filter((r) =>
        gate.id === "postgres"
          ? postgres.includes(r.file)
          : r.file.startsWith("packages/chaos/"),
      );
      if (gate.id === id && kind === "missing occurrence")
        selection.splice(0, 1);
      if (gate.id === id && kind === "extra occurrence")
        selection.push(clone(selection[0]));
      if (gate.id === id && kind === "renamed") selection[0].name = "changed";
      content = native(selection);
      if (gate.id === id && ["pending", "skipped", "todo"].includes(kind)) {
        content.testResults[0].assertionResults[0].status = kind;
        content.numPassedTests--;
        content.numPendingTests = kind === "todo" ? 0 : 1;
        content.numTodoTests = kind === "todo" ? 1 : 0;
      }
    }
    for (const p of gate.artifacts ?? [])
      r10Write(path.join(original, "gate-outputs", gate.id, p), content);
    if (gate.id === "e2e")
      Object.assign(entry, {
        executionId: "inert-execution",
        testCount: 1,
        testInventorySha256: r10Hash,
        artifactSha256: Object.fromEntries(
          gate.artifacts.map((p) => [
            p,
            r10Sha(
              fs.readFileSync(path.join(original, "gate-outputs", gate.id, p)),
            ),
          ]),
        ),
      });
    state.gates.push(entry);
  }
  const steps = Object.fromEntries(
    r10Gates
      .filter((g) => g.id !== "artifacts")
      .map((g) => [
        r10Step(g.id),
        {
          outcome: "success",
          conclusion: "success",
          outputs: {
            seal: r10EncodeSeal(
              r10CreateSeal({ id: g.id, state, artifactDir: original, github }),
            ),
          },
        },
      ]),
  );
  expect(
    r10CheckSeals({ state, artifactDir: original, steps, github }).failures,
  ).toEqual([]);
  const candidate = r10Digest(r10Sources(root));
  const expected = {
    schemaVersion: 1,
    contract: r10Version,
    contractHash: r10ContractHash,
    candidateId: candidate,
    sourceSha256: candidate,
    ownerMappingHash: r10Hash,
    runId: state.runId,
    attempt: "1",
    sha: env.GITHUB_SHA,
    startedAt: "2026-10-05T00:00:00.000Z",
    coveragePaths: [],
    coverageSources: [],
    testInventory: required,
    scopes: {},
  };
  for (const s of r10Contract.scopes)
    expected.scopes[s.id] = {
      ...expected,
      scopes: undefined,
      scope: s.id,
      derivedVariantId: candidate,
      derivedMappingHash: r10Hash,
      lockSha256: r10Hash,
      testInventoryHash: r10Digest(required),
      requiredTestIds: required.map((t) => t.id),
    };
  const legacy = {
    verdict: "PASS",
    provenance: { mode: "GITHUB_STEP_OUTPUT_SEALED" },
    runId: state.runId,
    candidateId: r10Hash,
    npmVersion: "inert",
    startedAt: expected.startedAt,
    gates: [...state.gates, { id: "artifacts", status: "PASS" }],
  };
  r10Write(path.join(original, "ci-bar-state.json"), state);
  r10Write(path.join(original, "ci-bar-manifest.json"), legacy);
  r10Write(path.join(d, "expected.json"), expected);
  r10Write(env.HISO_PG_VERSION_OUTPUT, {
    schemaVersion: 1,
    status: "PASS",
    version: 160000,
    runId: state.runId,
    candidateId: r10Hash,
  });
  env.CI_BAR_STEPS_JSON = JSON.stringify(steps);
  env.LEGACY_MANIFEST_SHA256 = r10Sha(
    fs.readFileSync(path.join(original, "ci-bar-manifest.json")),
  );
  const cli = r10Spawn(
    process.execPath,
    [
      "scripts/hiso-import-legacy.mjs",
      original,
      path.join(d, "expected.json"),
      out,
    ],
    { cwd: root, env, encoding: "utf8" },
  );
  expect(cli.error).toBeUndefined();
  const manifest = JSON.parse(fs.readFileSync(path.join(out, "manifest.json")));
  return { cli, manifest, out, required };
}

describe("R11 importer preflight required native reports", () => {
  it.each(["passed", "governed unit"])(
    "keeps complete selectors and %s policy",
    (kind) => {
      const observed = r11Import(kind);
      expect(observed.cli.status).toBe(0);
      expect(observed.manifest.status).toBe("PASS");
      expect(observed.manifest.gates.find((g) => g.id === "unit").skipped).toBe(
        kind === "governed unit" ? 1 : 0,
      );
      for (const id of ["postgres", "chaos"]) {
        const gate = r10Contract.scopes
          .find((s) => s.id === "transition-regression")
          .gates.find((g) => g.id === id);
        expect(() =>
          verifySnapshots({
            gate,
            entry: observed.manifest.gates.find((g) => g.id === id),
            directory: observed.out,
            manifest: observed.manifest,
            expected: {},
          }),
        ).not.toThrow();
      }
    },
  );
  for (const id of ["postgres", "chaos"])
    it.each([
      "pending",
      "skipped",
      "todo",
      "missing occurrence",
      "extra occurrence",
      "renamed",
    ])("rejects " + id + " %s before all PASS copies", (kind) => {
      const observed = r11Import(kind, id);
      expect(observed.cli.status).toBe(1);
      expect(observed.manifest.status).toBe("FAIL");
      expect(r10Files(observed.out).map((f) => f.path)).toEqual([
        "import-failure.log",
        "manifest.json",
      ]);
      expect(fs.existsSync(path.join(observed.out, "legacy"))).toBe(false);
      expect(fs.existsSync(path.join(observed.out, "gate-outputs"))).toBe(
        false,
      );
    });
});
