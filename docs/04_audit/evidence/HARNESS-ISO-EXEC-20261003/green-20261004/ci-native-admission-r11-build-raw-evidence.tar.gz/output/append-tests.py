from pathlib import Path
out=Path.cwd();p=out.parent/'ci-native-admission-r11-candidate/tests/hiso-snapshot-membership-own.test.js';s=p.read_text(); assert s== (out.parent/'ci-importer-counter-review-r10/source/tests/hiso-snapshot-membership-own.test.js').read_text()
helper=s[s.index('function r10Import(report, required) {'):s.index("describe('R10 native legacy importer shared admission'")]
helper=helper.replace('function r10Import(report, required)', "function r11Import(kind = 'passed', id = 'postgres')")
helper=helper.replace('  const d = temp(),', "  const selected = [row('tests/r11-inert.test.js', 'same'), row('tests/r11-inert.test.js', 'same'), ...[...new Set([...postgres, ...chaos])].flatMap((p) => [row(p, 'same'), row(p, 'same')])]\n  const required = inventory(selected)\n  const report = native(selected)\n  if (kind === 'governed unit') {\n    report.testResults[0].assertionResults[0].status = 'pending'\n    report.numPassedTests--\n    report.numPendingTests = 1\n  }\n  const d = temp(),",1)
helper=helper.replace('  for (const gate of r10Gates.filter', "  for (const gate of r10Gates.filter",1)
helper=helper.replace("    for (const p of gate.artifacts ?? [])", "    let content = { inert: true }\n    if (gate.id === 'unit') content = report\n    if (['postgres', 'chaos'].includes(gate.id)) {\n      const selection = selected.filter((r) => gate.id === 'postgres' ? postgres.includes(r.file) : r.file.startsWith('packages/chaos/'))\n      if (gate.id === id && kind === 'missing occurrence') selection.splice(0, 1)\n      if (gate.id === id && kind === 'extra occurrence') selection.push(clone(selection[0]))\n      if (gate.id === id && kind === 'renamed') selection[0].name = 'changed'\n      content = native(selection)\n      if (gate.id === id && ['pending', 'skipped', 'todo'].includes(kind)) {\n        content.testResults[0].assertionResults[0].status = kind\n        content.numPassedTests--\n        content.numPendingTests = kind === 'todo' ? 0 : 1\n        content.numTodoTests = kind === 'todo' ? 1 : 0\n      }\n    }\n    for (const p of gate.artifacts ?? [])",1)
helper=helper.replace("gate.id === 'unit' ? report : { inert: true }", 'content')
helper=helper.replace('r10Candidate ??= r10Digest(r10Sources(root))','r10Digest(r10Sources(root))')
append="""
// R11: append-only native admission regressions; prior 182 cases stay byte exact.
const r11Summary = () => ({total: metrics(1000), ...Object.fromEntries([...new Set(critical.groups.flatMap(g => g.paths))].map(p => [p, metrics(100)]))})
const r11Mutation = () => {
  const manifest = json('scripts/mutation-manifest.json')
  return {schemaVersion: 2, kind: 'aud21-risk-mutation-guard', contract: manifest.contract, runId: 'inert', candidateId: r10Hash, manifestSha256: r10Digest(manifest), selected: manifest.mutations.length, killed: manifest.mutations.length, survived: 0, timedOut: 0, errors: 0, domains: [...new Set(manifest.mutations.map(m => m.domain))], mutations: manifest.mutations.map(m => ({...m, driver: undefined, testFiles: m.testFiles ?? [], status: 'KILLED', exitCode: 1, durationMs: 1})), verdict: 'PASS'}
}
describe('R11 critical metrics native admission', () => {
  it.each(['statements', 'lines', 'functions'])('accepts safe zero group %s', dimension => {
    const summary = r11Summary()
    for(const p of critical.groups[0].paths) summary[p][dimension] = {total: 0, covered: 0, skipped: 0, pct: null}
    const report = buildCoverageReport(summary, critical)
    expect(report.verdict).toBe('PASS')
    expect(() => snapshotSchema(report, 'coverage-critical')).not.toThrow()
    expect(() => verify('coverage-critical', report)).not.toThrow()
    const forged = clone(report);forged.critical.groups[0].metrics[dimension].pct = 0
    expect(() => snapshotSchema(forged, 'coverage-critical')).toThrow()
  })
  for(const dimension of ['statements', 'lines', 'functions', 'branches']) {
    it.each([-1, 0.5, 2**53, '0', null])('rejects malformed '+dimension+' skipped=%s', value => {
      const summary = r11Summary();summary[critical.groups[0].paths[0]][dimension].skipped = value
      const report = buildCoverageReport(summary, critical)
      expect(report.verdict).toBe('FAIL')
      expect(() => snapshotSchema(report, 'coverage-critical')).toThrow()
      const forged = buildCoverageReport(r11Summary(), critical)
      forged.critical.groups[0].files[0].metrics[dimension].skipped = value
      expect(() => snapshotSchema(forged, 'coverage-critical')).toThrow()
    })
  }
  it.each(['omitted', 'zero', 'positive'])('retains valid optional skipped %s', kind => {
    const summary=r11Summary()
    for(const entry of Object.values(summary)) for(const v of Object.values(entry)) {
      if(kind==='omitted')delete v.skipped;else v.skipped=kind==='positive'?1:0
    }
    const report=buildCoverageReport(summary,critical)
    expect(report.verdict).toBe('PASS')
    expect(() => snapshotSchema(report,'coverage-critical')).not.toThrow()
  })
  it('rejects mathematically below integer95 with unchanged public pct=95', () => {
    const summary = r11Summary(), group = critical.groups.find(g => g.id === 'approval')
    const total=9007199254700003, covered=8556839291965002
    for(const p of group.paths)summary[p].branches={total:0,covered:0,skipped:0,pct:null}
    summary[group.paths[0]].branches={total,covered,skipped:0,pct:95}
    expect(BigInt(covered)*100n < BigInt(total)*95n).toBe(true)
    const report=buildCoverageReport(summary,critical)
    expect(report.verdict).toBe('FAIL')
    expect(report.critical.groups.find(g=>g.id==='approval').metrics.branches.pct).toBe(95)
    // Forging just producer PASS fields still cannot cross independent admission.
    report.verdict='PASS';report.failures=[];report.critical.pass=true;report.critical.failures=[]
    expect(() => snapshotSchema(report,'coverage-critical')).toThrow('critical_coverage_raw_threshold:approval')
  })
})
describe('R11 frozen mutation receipt authority', () => {
  it('admits every authoritative native source row', () => expect(() => snapshotSchema(r11Mutation(),'mutation')).not.toThrow())
  it.each(['manifestSha256', 'domains', 'omission', 'duplicate', 'sourceSha256', 'source', 'domain', 'mode', 'from', 'to', 'budgetMs', 'testFiles'])('refuses receipt-only %s changes', field => {
    const report=r11Mutation()
    if(field==='manifestSha256')report.manifestSha256='0'.repeat(64)
    else if(field==='domains')report.domains=['coverage']
    else if(field==='omission'){report.mutations.pop();report.selected--;report.killed--}
    else if(field==='duplicate')report.mutations[1]=clone(report.mutations[0])
    else if(field==='budgetMs')report.mutations[0][field]++
    else if(field==='testFiles')report.mutations[0][field]=['tests/inert.test.js']
    else report.mutations[0][field]=field==='sourceSha256'?'0'.repeat(64):'inert changed'
    expect(() => snapshotSchema(report,'mutation')).toThrow()
    expect(() => verify('mutation',report)).toThrow()
  })
  it('admits exact inventory in reordered rows/domains', () => {
    const report=r11Mutation();report.mutations.reverse();report.domains.reverse()
    expect(() => snapshotSchema(report,'mutation')).not.toThrow()
  })
})
"""
append += helper + """
describe('R11 importer preflight required native reports', () => {
  it.each(['passed', 'governed unit'])('keeps complete selectors and %s policy', kind => {
    const observed = r11Import(kind)
    expect(observed.cli.status).toBe(0)
    expect(observed.manifest.status).toBe('PASS')
    expect(observed.manifest.gates.find(g => g.id === 'unit').skipped).toBe(kind === 'governed unit' ? 1 : 0)
    for(const id of ['postgres', 'chaos']) {
      const gate=r10Contract.scopes.find(s=>s.id==='transition-regression').gates.find(g=>g.id===id)
      expect(() => verifySnapshots({gate, entry: observed.manifest.gates.find(g=>g.id===id), directory: observed.out, manifest: observed.manifest, expected:{}})).not.toThrow()
    }
  })
  for(const id of ['postgres', 'chaos']) it.each(['pending', 'skipped', 'todo', 'missing occurrence', 'extra occurrence', 'renamed'])('rejects '+id+' %s before all PASS copies', kind => {
    const observed=r11Import(kind,id)
    expect(observed.cli.status).toBe(1)
    expect(observed.manifest.status).toBe('FAIL')
    expect(r10Files(observed.out).map(f=>f.path)).toEqual(['import-failure.log','manifest.json'])
    expect(fs.existsSync(path.join(observed.out,'legacy'))).toBe(false)
    expect(fs.existsSync(path.join(observed.out,'gate-outputs'))).toBe(false)
  })
})
"""
(out/'appended-tests.js').write_text(append)
p.write_text(s+append)
print('prefix bytes',len(s.encode()),'appended bytes',len(append.encode()))
