import json,hashlib,pathlib,os,sys
base=pathlib.Path('/home/ricardo/.cache/cvg-harness-green-20261004');out=base/'ci-native-admission-r11-builder';source=base/'ci-importer-counter-review-r10/source';candidate=base/'ci-native-admission-r11-candidate'
def scan(root):
 rows={};metadata={}
 for directory,dirs,files in os.walk(root,followlinks=False):
  for name in sorted(dirs+files):
   p=pathlib.Path(directory)/name;rel=str(p.relative_to(root));s=p.lstat();kind='link' if p.is_symlink() else 'directory' if p.is_dir() else 'file';metadata[rel]={'kind':kind,'mode':s.st_mode,'size':s.st_size,'mtimeNs':s.st_mtime_ns}
   if kind=='file':rows[rel]={'kind':'file','bytes':s.st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
   elif kind=='link':rows[rel]={'kind':'link','target':os.readlink(p)}
 return {'rows':dict(sorted(rows.items())),'metadata':dict(sorted(metadata.items()))}
s=scan(source);c=scan(candidate)
freeze=json.loads((base/'ci-importer-counter-review-r10/frozen-inventory.json').read_text());freezeDiff=[p for p in sorted(set(s['rows'])|set(freeze)) if s['rows'].get(p)!=freeze.get(p)]
if freezeDiff: raise Exception(('Source freeze differences',freezeDiff))
# Recover complete before inventory from the proven immutable Source. The earlier
# operational scan accidentally omitted one supplied .vite entry; retain both.
before=json.loads((out/'proofs/source-before-complete.json').read_text());old=before['rows'];oldmeta=before['metadata'];missing=set(s['rows'])-set(old);metadataMissing=set(s['metadata'])-set(oldmeta)
if any(old.get(p)!=s['rows'].get(p) for p in old):raise Exception('Source before changed')
if any(oldmeta.get(p)!=s['metadata'].get(p) for p in oldmeta):raise Exception('Source before metadata changed')
for name,data in [('source-before-full',s),('source-after-full',s),('candidate-after-full',c)]: (out/'proofs'/f'{name}.json').write_text(json.dumps(data,indent=2))
copyBefore={'rows':s['rows'],'metadata':s['metadata']};(out/'proofs/candidate-before-full.json').write_text(json.dumps(copyBefore,indent=2))
candidateBeforeRecorded=json.loads((out/'proofs/candidate-before-complete.json').read_text())
assert all(candidateBeforeRecorded['metadata'][p]==s['metadata'][p] for p in candidateBeforeRecorded['metadata'])
# Known runtime cache additions are separate from, and never replace, full inventory.
cachePrefixes=('node_modules/.r11-tmp/', 'node_modules/.vite/')
def runtime(p):return p.startswith(cachePrefixes)
changes=[p for p in sorted(set(s['rows'])|set(c['rows'])) if s['rows'].get(p)!=c['rows'].get(p)]
write=[p for p in changes if not runtime(p)]
allowed={'scripts/lib/coverage-gate.mjs','scripts/hiso-snapshot-types.mjs','scripts/hiso-import-legacy.mjs','scripts/hiso-verifier.mjs','scripts/hiso-validation.mjs','tests/hiso-snapshot-membership-own.test.js'}
if set(write)-allowed:raise Exception(('WriteSet violation',set(write)-allowed))
orig=(source/'tests/hiso-snapshot-membership-own.test.js').read_bytes();cur=(candidate/'tests/hiso-snapshot-membership-own.test.js').read_bytes();assert cur.startswith(orig)
groups={}
for label,data in [('sourceBefore',s),('sourceAfter',s),('candidateBefore',copyBefore),('candidateAfter',c)]:
 groups[label]={}
 for group in ('source','dependencies','dist'):
  rows={p:v for p,v in data['rows'].items() if ('dependencies' if p.startswith('node_modules/') else 'dist' if any(x in ('dist','dist-public','dist-runtime') for x in pathlib.Path(p).parts) or p.endswith('.tsbuildinfo') else 'source')==group}
  groups[label][group]={'count':len(rows),'sha256':hashlib.sha256(json.dumps(rows,sort_keys=True).encode()).hexdigest()}
metadataDiff=[p for p in s['metadata'] if s['metadata'][p]!=c['metadata'].get(p)]
depVersionChanges=[p for p in changes if p.startswith('node_modules/') and not runtime(p)]
assert not depVersionChanges
proof={'freezeInventorySha256':hashlib.sha256((base/'ci-importer-counter-review-r10/frozen-inventory.json').read_bytes()).hexdigest(),'sourceFreezeDifferences':freezeDiff,'SourceCompleteCount':len(s['rows']),'candidateCompleteCount':len(c['rows']),'groups':groups,'sourceBeforeAfterContentAndMetadataUnchanged':True,'copyBytesVerifiedBefore':json.loads((out/'proofs/source-before-complete.json').read_text())['rows']==json.loads((out/'proofs/candidate-before-complete.json').read_text())['rows'],'beforeCompletenessRecovery':{'omittedSourcePaths':sorted(missing),'omittedMetadataPaths':sorted(metadataMissing),'basis':'before-recorded other rows/metadata match current immutable Source; Source matches frozen inventory'},'dependenciesVersionUnchanged':True,'distUnchanged':groups['candidateAfter']['dist']==groups['sourceBefore']['dist'],'writeSet':write,'ownRuntimeCacheChanges':[p for p in changes if runtime(p)],'originalCandidateMetadataDifferences':metadataDiff,'prefix182BYTE_EXACT':{'bytes':len(orig),'sha256':hashlib.sha256(orig).hexdigest(),'preserved':True}}
(out/'proofs/integrity-final.json').write_text(json.dumps(proof,indent=2));print(json.dumps({k:v for k,v in proof.items() if k not in ['ownRuntimeCacheChanges','originalCandidateMetadataDifferences']},indent=2))
