import pathlib, shutil, os, json, hashlib
base=pathlib.Path('/home/ricardo/.cache/cvg-harness-green-20261004')
src=base/'ci-importer-counter-review-r10/source'; dst=base/'ci-native-admission-r11-candidate'; out=base/'ci-native-admission-r11-builder'
if dst.exists(): raise Exception('candidate must be fresh')
shutil.copytree(src,dst,symlinks=True,copy_function=shutil.copy2)
links=[]
for directory, dirs, files in os.walk(dst,followlinks=False):
 for name in dirs+files:
  p=pathlib.Path(directory)/name
  if p.is_symlink():
   if not p.resolve().is_relative_to(dst): raise Exception('external link '+str(p))
   links.append(str(p.relative_to(dst)))
  elif p.is_file() and p.stat().st_nlink!=1: raise Exception('hardlink '+str(p))
(out/'proofs').mkdir(); (out/'logs').mkdir()
(out/'proofs/copy.json').write_text(json.dumps({'physical':True,'internalLinks':links,'externalLinks':0,'hardlinks':0},indent=2))
critic=base/'ci-importer-counter-review-r10/output/critic-r10'
for name in ['guard.mjs','discriminants.mjs','importer-discriminants.mjs','mutation-snapshot-discriminants.mjs','ratio-discriminants.mjs','ratio-cli.mjs']:
 text=(critic/name).read_text().replace("path.resolve('..')",'path.resolve('+json.dumps(str(out))+')').replace("path.resolve('../proofs')",'path.resolve('+json.dumps(str(out/'proofs'))+')').replace("path.resolve('../mutation-snapshot-discriminants',id)", 'path.join('+json.dumps(str(out/'mutation-snapshot-discriminants'))+',id)')
 (out/name).write_text(text)
print(json.dumps({'candidate':str(dst),'internalLinks':len(links)}))
