import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const packet=process.cwd(),out=path.join(packet,'output'),base=path.dirname(packet),local=path.join(base,'local-r19'),source=path.join(base,'candidate-final-r19'),data=path.join(base,'local/data');
assert.equal(process.version,'v22.23.2');
const sha=b=>createHash('sha256').update(b).digest('hex');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const write=(name,obj)=>fs.writeFileSync(path.join(out,name),JSON.stringify(obj,null,2)+'\n',{flag:'wx'});
const stamp=p=>{const s=fs.statSync(p,{bigint:true}),b=fs.readFileSync(p);return {sha256:sha(b),bytes:b.length,mode:Number(s.mode&0o777n).toString(8),mtimeNs:String(s.mtimeNs),physical:!fs.lstatSync(p).isSymbolicLink()};};
const inventory=(dir,rel='')=>fs.readdirSync(path.join(dir,rel),{withFileTypes:true}).flatMap(e=>{const p=path.join(rel,e.name);assert(!e.isSymbolicLink());return e.isDirectory()?inventory(dir,p):[{path:p,...stamp(path.join(dir,p))}];}).sort((a,b)=>a.path.localeCompare(b.path));
const frozen=read(path.join(packet,'freeze.json'));
const freeze=Object.entries(frozen).map(([p,e])=>{const a=stamp(p);return {path:p,expected:e,actual:a,match:a.sha256===e.sha256&&a.bytes===e.bytes&&a.mtimeNs===String(e.mtimeNs)};});
const nativePath=path.join(base,'final-private-integration-r19/native-after-full.json');
const native=read(nativePath);const nativeDiff=[];const nativeRelevant=[];
for(const row of native){assert(!path.isAbsolute(row.path)&&!row.path.split('/').includes('..')&&!/^(\.env|private\.env)$/.test(path.basename(row.path)));const a=stamp(path.join(source,row.path));if(a.sha256!==row.sha256||!a.physical)nativeDiff.push({path:row.path,expected:row.sha256,actual:a.sha256});if(row.path.startsWith('products/shift-assistant/src/')&&!row.path.includes('__tests__'))nativeRelevant.push({path:row.path,sha256:a.sha256});}
const corpusRoot=path.join(source,'products/shift-assistant/src/__tests__/fixtures/reliability');
const cmPath=path.join(corpusRoot,'corpus-manifest.json'),cm=read(cmPath), manifestTS=fs.readFileSync(path.join(source,'products/shift-assistant/src/synthetic/manifest.ts'),'utf8');
const expectedCorpus=/export const CORPUS_SHA256\s*=\s*'([a-f0-9]{64})'/.exec(manifestTS)[1];
const files=cm.files.map(e=>{const a=stamp(path.join(corpusRoot,e.path));return {path:e.path,sha256:a.sha256,bytes:a.bytes,match:a.sha256===e.sha256&&a.bytes===e.sizeBytes};});
const fixtures=cm.cases.map(e=>{const b=fs.readFileSync(path.join(corpusRoot,e.path)),j=JSON.parse(b);return {id:e.id,path:e.path,sha256:sha(b),textSha256:sha(j.input.rawText),synthetic:j.synthetic,match:sha(b)===e.sha256&&b.length===e.sizeBytes};});
const backup=inventory(path.join(local,'data-before'));
const shutdown=read(path.join(local,'output/shutdown-and-data-preservation.json'));
const preservation=backup.map(e=>{const b=fs.readFileSync(path.join(local,'data-before',e.path)),current=fs.readFileSync(path.join(data,e.path)),original=shutdown.files[e.path];return {path:e.path,backup:e,shutdownHashMatches:e.sha256===original?.sha256&&e.bytes===original?.bytes,liveBytes:current.length,originalPrefixExact:current.subarray(0,b.length).equals(b),manifestExact:e.path.endsWith('.json')?current.equals(b):null};});
const runtime=read(path.join(local,'runtime.json'));let processBinding;
try{const args=fs.readFileSync(`/proc/${runtime.pid}/cmdline`,'utf8').split('\0');processBinding={pid:runtime.pid,executable:fs.readlinkSync(`/proc/${runtime.pid}/exe`),cwd:fs.readlinkSync(`/proc/${runtime.pid}/cwd`),serverArgumentPresent:args.includes(path.join(local,'server.mts')),candidateLoaderPresent:args.includes(path.join(source,'node_modules/tsx/dist/loader.mjs')),privateEnvironmentNotRead:true};}catch(e){processBinding={error:e.code};}
write('static-integrity-before.json',{observedAt:new Date().toISOString(),node:process.version,freeze,native:{manifestPath:nativePath,manifestSha256:stamp(nativePath).sha256,count:native.length,differences:nativeDiff,relevant:nativeRelevant},corpus:{expectedCorpus,manifestSha256:stamp(cmPath).sha256,manifestHashMatches:stamp(cmPath).sha256===expectedCorpus,fixtures,files,inventory:inventory(corpusRoot).map(e=>e.path)},preservation,processBinding});
const request=async(url,opts={})=>{const r=await fetch(url,{...opts,redirect:'error',signal:AbortSignal.timeout(6000)});const t=await r.text();return {url,status:r.status,headers:Object.fromEntries(r.headers),body:t};};
const state=async()=>{const r=await request('http://127.0.0.1:3501/api/state');assert.equal(r.status,200);return JSON.parse(r.body);};
const counters=s=>({inputs:s.inputs.length,replies:s.replies.length,messages:s.messages.length,notes:s.notes.length,tasks:s.tasks.length,llmCalls:s.llmCalls,paused:s.paused,now:s.now,stateSha256:sha(JSON.stringify(s))});
const journal=()=>inventory(data);
const health=await request('http://127.0.0.1:3500/health'),html=await request('http://127.0.0.1:3501/');
const initial=await state();write('http-before.json',{observedAt:new Date().toISOString(),health,html:{...html,body:undefined,bytes:Buffer.byteLength(html.body),sha256:sha(html.body),matchesFrozen:sha(html.body)===frozen[path.join(local,'index.html')].sha256},state:initial,counters:counters(initial),journal:journal()});
assert.equal(initial.fixtures.length,20);
const fixtureBindings=fixtures.map(f=>({id:f.id,match:initial.fixtures.find(e=>e.id===f.id)?.sha256===f.sha256&&sha(initial.fixtures.find(e=>e.id===f.id)?.text??'')===f.textSha256}));
const note=initial.notes.find(n=>Number.isSafeInteger(n.revision)&&n.revision<Number.MAX_SAFE_INTEGER);assert(note,'Existing note needed for safe stale probe');
const unknownId='f'.repeat(64);assert(!initial.notes.some(n=>n.id===unknownId));
const probes=[
{id:'unknown-text',body:{action:'text',text:'FRESH_REVIEW_R19_UNKNOWN_SENTINEL'},expected:400},
{id:'unknown-phone',body:{action:'text',phone:'5511999999999',text:'ajuda'},expected:400},
{id:'unknown-field',body:{action:'text',text:'ajuda',unexpected:true},expected:400},
{id:'foreign-origin',body:{action:'text',text:'ajuda'},origin:'https://synthetic.invalid',expected:403},
{id:'stale-note',body:{action:'confirm',phone:note.authorPhone,noteId:note.id,revision:Number.MAX_SAFE_INTEGER},expected:409},
{id:'unknown-note',body:{action:'confirm',phone:note.authorPhone,noteId:unknownId,revision:1},expected:409},
{id:'foreign-author',body:{action:'confirm',phone:note.authorPhone==='5511900000001'?'5511900000009':'5511900000001',noteId:note.id,revision:note.revision},expected:409}
];
const results=[];
for(const p of probes){const b=await state(),jb=journal();const response=await request('http://127.0.0.1:3501/api/action',{method:'POST',headers:{origin:p.origin??'http://127.0.0.1:3501','content-type':'application/json'},body:JSON.stringify(p.body)});const a=await state(),ja=journal();const record={id:p.id,request:p,response,before:counters(b),after:counters(a),countersUnchanged:JSON.stringify(counters(b))===JSON.stringify(counters(a)),journalUnchanged:JSON.stringify(jb)===JSON.stringify(ja),journalBefore:jb,journalAfter:ja,statusMatches:response.status===p.expected};results.push(record);write(`negative-${p.id}.json`,record);if(!record.statusMatches||!record.countersUnchanged||!record.journalUnchanged)throw new Error('Negative invariant failed: '+p.id);}
const final=await state();write('http-after.json',{observedAt:new Date().toISOString(),health:await request('http://127.0.0.1:3500/health'),state:final,counters:counters(final),journal:journal(),fixtureBindings,negatives:results.map(r=>({id:r.id,status:r.response.status,countersUnchanged:r.countersUnchanged,journalUnchanged:r.journalUnchanged}))});
write('static-integrity-after.json',{observedAt:new Date().toISOString(),freeze:Object.entries(frozen).map(([p,e])=>({path:p,actual:stamp(p),matches:stamp(p).sha256===e.sha256})),nativeManifest:stamp(nativePath),relevantSource:nativeRelevant.map(e=>({path:e.path,matches:stamp(path.join(source,e.path)).sha256===e.sha256})),backup:inventory(path.join(local,'data-before'))});
console.log(JSON.stringify({freezeMatches:freeze.every(e=>e.match),nativeFiles:native.length,nativeDifferences:nativeDiff.length,corpusFiles:files.length,corpusMatches:files.every(e=>e.match)&&fixtures.every(e=>e.match)&&stamp(cmPath).sha256===expectedCorpus,backupMatches:preservation.every(e=>e.shutdownHashMatches&&e.originalPrefixExact),processBinding,health:JSON.parse(health.body),initial:counters(initial),final:counters(final),negatives:results.map(r=>({id:r.id,status:r.response.status,unchanged:r.countersUnchanged&&r.journalUnchanged}))}));
