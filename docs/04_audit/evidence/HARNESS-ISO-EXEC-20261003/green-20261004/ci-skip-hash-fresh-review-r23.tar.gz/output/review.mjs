import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';

const packet = '/home/ricardo/.cache/cvg-harness-green-20261004/ci-skip-hash-fresh-review-r23';
const output = path.join(packet, 'output');
const authority = JSON.parse(fs.readFileSync(path.join(packet, 'authority.json')));
const candidate = authority.sourceReadonly, original = authority.originalReadonly;
const r21 = authority.suppliedRawReportsSourceReadonly;
const relativeCatalog = 'scripts/skip-catalog.json';
const helper = path.join(candidate, 'scripts/lib/skip-governance.mjs');
const sha = b => createHash('sha256').update(b).digest('hex');
const read = p => fs.readFileSync(p);
const json = p => JSON.parse(read(p));
const put = (name, value) => fs.writeFileSync(path.join(output, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
const checks = [], controls = [], attempts = [], errors = [];
function check(name, passed, details = {}) {
  checks.push({ name, passed: Boolean(passed), ...details });
  if (!passed) errors.push(name);
}
function fingerprint(p) {
  const before = fs.statSync(p, { bigint: true });
  const bytes = read(p), after = fs.statSync(p, { bigint: true });
  if (before.mtimeNs !== after.mtimeNs || before.mode !== after.mode || before.size !== after.size) throw new Error(`unstable_input:${p}`);
  return { path: p, sha256: sha(bytes), size: Number(before.size), mode: '0o' + before.mode.toString(8), mtimeNs: String(before.mtimeNs), symlink: fs.lstatSync(p).isSymbolicLink() };
}
const hashPattern = /("sourceSha256"\s*:\s*")([a-f0-9]{64})(")/g;
const masked = b => b.toString('utf8').replace(hashPattern, '$1<SOURCE_HASH>$3');
const beforeInputs = json(path.join(output, 'raw/inputs-before.json'));
let catalog, originalCatalog, witnessRows = [], changed = [], native = [], inventory;

try {
  check('Node22', process.versions.node.startsWith('22.'), { actual: process.versions.node, execPath: process.execPath });
  if (!process.versions.node.startsWith('22.')) throw new Error('Node22 required');
  const updatedBytes = read(path.join(candidate, relativeCatalog));
  const originalBytes = read(path.join(original, relativeCatalog));
  catalog = JSON.parse(updatedBytes); originalCatalog = JSON.parse(originalBytes);
  check('catalog35entries', catalog.entries.length === 35 && originalCatalog.entries.length === 35);
  check('catalog35uniqueIDsAndPaths', new Set(catalog.entries.map(e => e.id)).size === 35 && new Set(catalog.entries.map(e => e.file)).size === 35);
  check('allOtherCatalogBytesIdentical', masked(updatedBytes) === masked(originalBytes), { method: 'Replace only each sourceSha256 64-hex value with a fixed token; compare every remaining UTF-8 byte including whitespace, key order, and entry order.' });
  const withoutHashes = c => ({ ...c, entries: c.entries.map(({ sourceSha256, ...rest }) => rest) });
  check('allOtherCatalogValuesIdentical', isDeepStrictEqual(withoutHashes(catalog), withoutHashes(originalCatalog)));
  check('exactly35HashTokens', [...updatedBytes.toString().matchAll(hashPattern)].length === 35 && [...originalBytes.toString().matchAll(hashPattern)].length === 35);
  changed = catalog.entries.flatMap((e, i) => e.sourceSha256 === originalCatalog.entries[i]?.sourceSha256 ? [] : [{ id: e.id, file: e.file, original: originalCatalog.entries[i]?.sourceSha256, updated: e.sourceSha256 }]);
  check('exactlyFourHashValuesChanged', changed.length === 4, { changed });
  let index = 0;
  const reboundOriginal = originalBytes.toString().replace(hashPattern, (_, prefix, hash, suffix) => prefix + catalog.entries[index++].sourceSha256 + suffix);
  check('originalWithOnlyHashSubstitutionExactlyEqualsCandidate', Buffer.from(reboundOriginal).equals(updatedBytes));
  for (const entry of catalog.entries) {
    const cb = read(path.join(candidate, entry.file)), ob = read(path.join(original, entry.file)), rb = read(path.join(r21, entry.file));
    witnessRows.push({ id: entry.id, file: entry.file, bytes: cb.length, catalogSha256: entry.sourceSha256, r23Sha256: sha(cb), r22Sha256: sha(ob), r21Sha256: sha(rb), r23EqualsR22Bytes: cb.equals(ob), r23EqualsR21Bytes: cb.equals(rb) });
  }
  put('raw/all35-source-witnesses.json', witnessRows);
  check('all35ActualHashesMatchUpdatedCatalog', witnessRows.length === 35 && witnessRows.every(e => e.catalogSha256 === e.r23Sha256 && e.catalogSha256 === e.r21Sha256));
  check('all35TestBytesEqualOriginalAndSuppliedR21', witnessRows.every(e => e.r23EqualsR22Bytes && e.r23EqualsR21Bytes));
  check('catalogModeUnchanged', fs.statSync(path.join(candidate, relativeCatalog)).mode === fs.statSync(path.join(original, relativeCatalog)).mode);
  check('helperBytesIdenticalR23R22R21', read(helper).equals(read(path.join(original, 'scripts/lib/skip-governance.mjs'))) && read(helper).equals(read(path.join(r21, 'scripts/lib/skip-governance.mjs'))));
  const reportNames = { unit: 'unit-test-report.json', postgres: 'postgres-test-report.json', chaos: 'chaos-report.json', e2e: 'e2e-test-report.json' };
  const reportsR21 = Object.entries(reportNames).map(([gate, file]) => ({ gate, path: 'certification/' + file }));
  const parsedReports = Object.fromEntries(reportsR21.map(r => [r.gate, json(path.join(r21, r.path))]));
  for (const report of reportsR21) {
    const value = parsedReports[report.gate];
    if (report.gate !== 'e2e') {
      const tests = value.testResults.flatMap(s => s.assertionResults ?? []);
      const counts = {};
      for (const t of tests) counts[t.status] = (counts[t.status] ?? 0) + 1;
      const passed = value.success === true && value.numTotalTests > 0 && tests.length === value.numTotalTests && tests.every(t => t.status === 'passed') && value.numPassedTests === tests.length && ['numFailedTests','numPendingTests','numTodoTests','numFailedTestSuites','numPendingTestSuites'].every(k => value[k] === 0) && value.testResults.every(s => s.status === 'passed') && value.numTotalTestSuites === value.numPassedTestSuites;
      native.push({ gate: report.gate, provenance: 'supplied R21; not executed by this R23 review', path: path.join(r21, report.path), sha256: sha(read(path.join(r21, report.path))), nativeTotals: { total: value.numTotalTests, passed: value.numPassedTests, failed: value.numFailedTests, pending: value.numPendingTests, todo: value.numTodoTests }, assertionRows: tests.length, statuses: counts, passed });
      check('suppliedR21NativeReport:' + report.gate, passed);
    } else {
      const tests = [], specs = [];
      function visit(suites) { for (const s of suites) { for (const spec of s.specs ?? []) { specs.push(spec); tests.push(...spec.tests ?? []); } visit(s.suites ?? []); } }
      visit(value.suites);
      const statuses = {};
      for (const test of tests) for (const result of test.results ?? []) statuses[result.status] = (statuses[result.status] ?? 0) + 1;
      const passed = value.errors.length === 0 && value.stats.expected > 0 && value.stats.expected === tests.length && value.stats.skipped === 0 && value.stats.unexpected === 0 && value.stats.flaky === 0 && specs.every(s => s.ok === true) && tests.every(t => t.status === 'expected' && t.expectedStatus === 'passed' && t.results.length > 0 && t.results.every(r => r.status === 'passed' && !r.error && !(r.errors?.length)));
      native.push({ gate: 'e2e', provenance: 'supplied R21; not executed by this R23 review', path: path.join(r21, report.path), sha256: sha(read(path.join(r21, report.path))), nativeStats: value.stats, testRows: tests.length, resultStatuses: statuses, passed });
      check('suppliedR21NativeReport:e2e', passed);
    }
  }
  put('raw/supplied-r21-native-verification.json', native);
  const { buildSkipInventory } = await import(pathToFileURL(helper).href);
  function attempt(id, root, explicitCatalog, reports = reportsR21) {
    const context = { id, root, helper, helperSha256: sha(read(helper)), catalogPassedExplicitly: true, catalogSha256: sha(Buffer.from(JSON.stringify(explicitCatalog))), reports, provenance: 'supplied R21 report parsing, except explicitly synthetic controls; no R23 test execution' };
    let result;
    try { result = buildSkipInventory({ root, catalog: explicitCatalog, reports }); }
    catch (e) { result = { exception: e.stack }; }
    put('raw/attempt-' + id + '.json', { context, result });
    attempts.push({ id, raw: 'raw/attempt-' + id + '.json', verdict: result.verdict ?? 'EXCEPTION', failures: result.failures ?? [result.exception] });
    console.log(JSON.stringify(attempts.at(-1)));
    return result;
  }
  inventory = attempt('001-updated-r23-catalog-supplied-r21', r21, catalog);
  check('updatedCatalogSuppliedR21InventoryPASS', inventory.verdict === 'PASS' && inventory.totals.skippedTests === 0 && inventory.totals.failures === 0 && Object.values(inventory.skippedTestsByGate).every(n => n === 0));
  const stale = attempt('002-original-r22-catalog-supplied-r21', r21, originalCatalog);
  const expectedStale = changed.map(e => 'skip_catalog_source_drift:' + e.file).sort();
  check('originalCatalogRejectsExactlyFourStaleHashes', stale.verdict === 'FAIL' && isDeepStrictEqual(stale.failures, expectedStale));
  let seq = 3;
  function rejection(label, altered, expected) {
    const result = attempt(String(seq++).padStart(3, '0') + '-' + label, r21, altered);
    const passed = result.verdict === 'FAIL' && result.failures?.some(f => f.startsWith(expected));
    controls.push({ label, layer: 'existing buildSkipInventory', passed, expectedFailure: expected });
    check('negativeControl:' + label, passed);
  }
  for (const item of changed) {
    const altered = structuredClone(catalog); altered.entries.find(e => e.id === item.id).sourceSha256 = '0'.repeat(64);
    rejection('wronghash-' + item.id, altered, 'skip_catalog_source_drift:' + item.file);
  }
  for (const [field, value, expected] of [
    ['reason', '', 'skip_catalog_metadata_missing:'], ['owner', '', 'skip_catalog_metadata_missing:'],
    ['dedicatedGate', 'invalid-gate', 'skip_catalog_unknown_gate:'], ['expiresAt', '', 'skip_catalog_expiration_missing:'],
    ['expiresAt', 'not-a-date', 'skip_catalog_expiration_invalid:'], ['expiresAt', '2000-01-01T00:00:00.000Z', 'skip_catalog_expired:'],
    ['file', 'controlled-missing-source.test.ts', 'skip_catalog_source_missing:']
  ]) {
    const altered = structuredClone(catalog); altered.entries[0][field] = value;
    rejection('invalid-' + field + '-' + seq, altered, expected);
  }
  for (const field of ['id', 'file']) {
    const altered = structuredClone(catalog); altered.entries[1][field] = altered.entries[0][field];
    rejection('duplicate-' + field, altered, 'skip_catalog_duplicate_' + field + ':');
  }
  // The immutable-metadata boundary catches even changes that remain valid metadata.
  const mutations = [
    ['id', 'CONTROL-ID'], ['file', catalog.entries[1].file], ['expectedSkippedTests', 999],
    ['reason', 'controlled altered reason'], ['owner', 'controlled owner'], ['dedicatedGate', 'unit'],
    ['required', true], ['expiresAt', '2028-12-31T23:59:59.000Z']
  ];
  for (const [field, value] of mutations) {
    const altered = structuredClone(catalog); altered.entries[0][field] = value;
    const rejected = !isDeepStrictEqual(withoutHashes(altered), withoutHashes(originalCatalog));
    put('raw/frozen-metadata-' + field + '.json', { alteredCatalog: altered, rejected, method: 'Independent equality of every metadata value against original R22' });
    controls.push({ label: 'frozen-' + field, layer: 'independent original metadata boundary', passed: rejected });
    check('negativeControl:frozen-' + field, rejected);
  }
  const whitespaceAltered = updatedBytes.toString().replace('  "schemaVersion"', '   "schemaVersion"');
  check('negativeControl:metadataWhitespace', masked(Buffer.from(whitespaceAltered)) !== masked(originalBytes));
  for (const [label, mutate] of [['schemaVersion', c => { c.schemaVersion = 2; }], ['kind', c => { c.kind = 'control'; }], ['entry-order', c => { c.entries.reverse(); }], ['entry-count', c => { c.entries.pop(); }]]) {
    const altered = structuredClone(catalog); mutate(altered);
    const rejected = !isDeepStrictEqual(withoutHashes(altered), withoutHashes(originalCatalog));
    put('raw/frozen-' + label + '.json', { alteredCatalog: altered, rejected });
    controls.push({ label: 'frozen-' + label, layer: 'independent original metadata boundary', passed: rejected });
    check('negativeControl:frozen-' + label, rejected);
  }
  // Use one small source copy and tiny invented report rows; never run that source.
  const copyRoot = path.join(output, 'controls/source-copy'); fs.mkdirSync(copyRoot, { recursive: true });
  const entry = catalog.entries.find(e => e.id === changed[0].id), copied = path.join(copyRoot, entry.file);
  fs.mkdirSync(path.dirname(copied), { recursive: true }); fs.writeFileSync(copied, read(path.join(r21, entry.file)), { flag: 'wx' });
  const oneCatalog = { ...catalog, entries: [structuredClone(entry)] };
  const copyReports = reportsR21.map(r => ({ ...r, path: path.relative(copyRoot, path.join(r21, r.path)) }));
  const copyBaseline = attempt(String(seq++).padStart(3, '0') + '-small-copy-baseline', copyRoot, oneCatalog, copyReports);
  check('smallCopyBaselinePASS', copyBaseline.verdict === 'PASS');
  fs.appendFileSync(copied, '\n// controlled integrity mutation; this source is never executed\n');
  const sourceTamper = attempt(String(seq++).padStart(3, '0') + '-copied-source-tamper', copyRoot, oneCatalog, copyReports);
  const tamperRejected = sourceTamper.verdict === 'FAIL' && sourceTamper.failures.includes('skip_catalog_source_drift:' + entry.file);
  controls.push({ label: 'copied-source-tamper', layer: 'existing buildSkipInventory', passed: tamperRejected });
  check('negativeControl:copied-source-tamper', tamperRejected);
  const reboundTamper = structuredClone(oneCatalog); reboundTamper.entries[0].sourceSha256 = sha(read(copied));
  const scopedReject = !read(copied).equals(read(path.join(original, entry.file)));
  controls.push({ label: 'source-tamper-with-rebound-hash', layer: 'independent original test-byte boundary', passed: scopedReject });
  put('raw/source-tamper-rebound-witness.json', { originalSha256: sha(read(path.join(original, entry.file))), copiedTamperedSha256: sha(read(copied)), deliberatelyReboundCatalog: reboundTamper, rejectedByOriginalByteBoundary: scopedReject });
  check('negativeControl:source-tamper-with-rebound-hash', scopedReject);
  const syntheticReports = ['unit','postgres','chaos','e2e'].map(gate => {
    const value = gate === 'e2e' ? { suites: [] } : { numPendingTests: gate === 'unit' ? 1 : 0, numTodoTests: 0, testResults: gate === 'unit' ? [{ name: entry.file, assertionResults: [{ fullName: 'controlled synthetic skipped row', status: 'skipped' }] }] : [] };
    return { gate, path: 'synthetic-control-' + gate + '.json', value, content: JSON.stringify(value) };
  });
  for (const [field, value, expected] of [['required', true, 'skip_required:'], ['expectedSkippedTests', 2, 'skip_catalog_count_mismatch:']]) {
    const altered = structuredClone(catalog); altered.entries.find(e => e.id === entry.id)[field] = value;
    const result = attempt(String(seq++).padStart(3, '0') + '-synthetic-' + field, r21, altered, syntheticReports);
    const passed = result.verdict === 'FAIL' && result.failures.some(f => f.startsWith(expected));
    controls.push({ label: 'synthetic-' + field, layer: 'existing buildSkipInventory with invented rows, not supplied execution', passed });
    check('negativeControl:synthetic-' + field, passed);
  }
} catch (e) {
  errors.push('reviewException:' + e.message); put('raw/review-exception.json', { stack: e.stack });
}
const afterInputs = beforeInputs.map(record => fingerprint(record.path));
put('raw/inputs-after.json', afterInputs);
const integrityFailures = beforeInputs.flatMap((record, i) => isDeepStrictEqual(record, afterInputs[i]) ? [] : [{ before: record, after: afterInputs[i] }]);
check('relevantInputsBytesModeMtimeUnchanged', integrityFailures.length === 0, { files: beforeInputs.length, failures: integrityFailures });
const verdict = errors.length === 0 ? 'ACCEPT' : 'REJECT';
const report = {
  task: authority.task, verdict, scope: 'limitedhashrebind: scripts/skip-catalog.json; exactly four sourceSha256 replacements only',
  generatedAt: new Date().toISOString(), execution: { node: process.versions.node, execPath: process.execPath, cwd: process.cwd(), executed: 'Own finite review script; read-only import and invocation of existing skip-governance.mjs; no tests or application source executed', suppliedReports: 'R21 unit/Postgres/chaos/E2E raw native reports; not R23 execution', applicationApproval: false, productionApproval: false, sourceWrites: false, network: false, childProcesses: false },
  roots: { candidateR23: candidate, originalR22: original, suppliedR21: r21 }, changed, witnessRows,
  suppliedR21Reports: native, inventory: { raw: 'raw/attempt-001-updated-r23-catalog-supplied-r21.json', verdict: inventory?.verdict, skippedTestsByGate: inventory?.skippedTestsByGate, totals: inventory?.totals, warning: 'The helper report.executed field denotes successful report parsing, not execution performed in this review.' },
  controls, attempts, checks, failures: errors,
  integrity: { before: 'raw/inputs-before.json', after: 'raw/inputs-after.json', files: beforeInputs.length, unchanged: integrityFailures.length === 0 },
  boundaryNotes: ['Existing helper checks source integrity and invalid metadata. Independent frozen-original equality rejects even valid-looking metadata changes; zero-skip reports alone do not exercise required/count-on-skip policies.', 'Review claims only the named catalog and 35 cataloged test sources plus relevant helper/reports; no broader repository audit or application/production approval.', 'All raw attempts, including expected failures, retained under output/raw.']
};
put('report.json', report);
const totals = native.map(r => `${r.gate}: ${r.nativeTotals?.passed ?? r.nativeStats?.expected} passed, 0 skips`).join('; ');
const md = `${verdict} — limitedhashrebind only\n\nExactly ${changed.length} sourceSha256 values changed in scripts/skip-catalog.json: ${changed.map(e => e.id).join(', ')}. All 35 actual hashes match; corresponding R23, original R22 and supplied R21 test bytes are identical. Every other catalog metadata byte/value and catalog mode are unchanged.\n\nSupplied R21 native evidence (not R23 execution): ${totals}. Existing read-only buildSkipInventory imported from R23, invoked with root R21, explicit R23 catalog and supplied R21 report paths: ${inventory?.verdict}; ${inventory?.totals?.skippedTests} skips. Its report.executed flag means parsed evidence, not a suite run by this reviewer.\n\nOriginal R22 catalog rejects exactly four stale hashes. Finite negative controls cover wrong hashes for each changed entry, invalid/duplicate metadata, frozen metadata fields and layout, copied test-source tampering, required skips and expected-count mismatch. Valid-looking metadata/source rebinding is also rejected by the independent original-boundary comparison. ${controls.filter(c => c.passed).length}/${controls.length} listed controls passed; see all checks and raw attempts in report.json and raw/.\n\n${beforeInputs.length} relevant input files preserved byte/hash, mode and nanosecond mtime across helper/control execution. No source edits, full suite, application execution, network, PostgreSQL, providers, installation, private environment access or child processes. No application or production approval.\n\nFailures: ${errors.length ? errors.join('; ') : 'none'}.\n`;
fs.writeFileSync(path.join(output, 'report.md'), md, { flag: 'wx' });
console.log(JSON.stringify({ verdict, scope: report.scope, checks: checks.length, failedChecks: errors, helperAttempts: attempts.length, controls: controls.length, preservedInputs: beforeInputs.length }));
process.exitCode = verdict === 'ACCEPT' ? 0 : 1;
