import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';

if (!process.versions.node.startsWith('22.')) throw new Error('Node22 required');
const output = '/home/ricardo/.cache/cvg-harness-green-20261004/ci-skip-hash-fresh-review-r23/output';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const get = name => JSON.parse(fs.readFileSync(path.join(output, name)));
const write = (name, value) => fs.writeFileSync(path.join(output, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
const report = get('report.json');
fs.copyFileSync(path.join(output, 'report.json'), path.join(output, 'raw/report-attempt-001.json'), fs.constants.COPYFILE_EXCL);
fs.copyFileSync(path.join(output, 'report.md'), path.join(output, 'raw/report-attempt-001.md'), fs.constants.COPYFILE_EXCL);
write('raw/review-launch-001.json', {
  command: '/home/ricardo/.nvm/versions/node/v22.23.2/bin/node output/review.mjs > output/raw/review-attempt-001.stdout.log 2> output/raw/review-attempt-001.stderr.log',
  cwd: path.dirname(output), exitCode: 0, scriptSha256: sha(fs.readFileSync(path.join(output, 'review.mjs'))),
  stderrBytes: fs.statSync(path.join(output, 'raw/review-attempt-001.stderr.log')).size
});
report.proceduralDeviations = [{
  stage: 'read-only bootstrap discovery',
  action: 'Invoked the default node --version, which returned v24.20.0, before locating installed Node22.',
  authorityConstraint: 'Node22 only',
  impact: 'Version-only invocation; no source, helper or controls executed by Node24. All substantive review/helper/control execution used /home/ricardo/.nvm/versions/node/v22.23.2/bin/node.',
  disposition: 'Disclosed procedural deviation; ACCEPT is limited to verified catalog hash rebinding and is not a claim of perfect procedural conformance.'
}];
const before = get('raw/inputs-before.json');
const after = before.map(record => {
  const stat = fs.statSync(record.path, { bigint: true });
  return { path: record.path, sha256: sha(fs.readFileSync(record.path)), size: Number(stat.size), mode: '0o' + stat.mode.toString(8), mtimeNs: String(stat.mtimeNs), symlink: fs.lstatSync(record.path).isSymbolicLink() };
});
write('raw/inputs-final.json', after);
const intact = isDeepStrictEqual(before, after);
report.checks.push({ name: 'finalRelevantInputsBytesModeMtimeUnchanged', passed: intact, files: before.length });
report.integrity.final = 'raw/inputs-final.json';
report.integrity.unchanged = report.integrity.unchanged && intact;
if (!intact) { report.verdict = 'REJECT'; report.failures.push('finalRelevantInputsBytesModeMtimeUnchanged'); }
fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(report, null, 2) + '\n');
fs.appendFileSync(path.join(output, 'report.md'), '\nProcedural deviation: bootstrap ran the default Node24 version-only query before locating Node22. All substantive review/helper/control execution used Node22. ACCEPT is limited to verified hash rebinding, not perfect procedural conformance. The final integrity recheck also preserved all 118 relevant inputs.\n');
const files = [];
function visit(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true }).sort((a,b) => a.name.localeCompare(b.name))) {
    const p = path.join(dir, entry.name);
    if (entry.isDirectory()) visit(p);
    else if (entry.isFile()) {
      const stat = fs.statSync(p, { bigint: true });
      files.push({ path: path.relative(output, p), sha256: sha(fs.readFileSync(p)), size: Number(stat.size), mode: '0o' + stat.mode.toString(8), mtimeNs: String(stat.mtimeNs) });
    } else throw new Error('Unexpected output entry: ' + p);
  }
}
visit(output);
write('manifest.json', {
  schemaVersion: 1, task: report.task, verdict: report.verdict, scope: report.scope,
  generatedAt: new Date().toISOString(), provenance: 'Own Node22 finite review; supplied native R21 reports; no R23 suite execution',
  integrity: { unchanged: intact, inputCount: before.length, before: 'raw/inputs-before.json', after: 'raw/inputs-after.json', final: 'raw/inputs-final.json' },
  proceduralDeviations: report.proceduralDeviations, inputs: before, artifacts: files,
  exclusions: ['manifest.json excludes itself; manifest.sha256 binds its final bytes', 'No application or production approval']
});
fs.writeFileSync(path.join(output, 'manifest.sha256'), sha(fs.readFileSync(path.join(output, 'manifest.json'))) + '  manifest.json\n', { flag: 'wx' });
console.log(JSON.stringify({ verdict: report.verdict, checks: report.checks.length, controls: report.controls.length, helperAttempts: report.attempts.length, preservedInputs: before.length, manifestArtifacts: files.length, proceduralDeviationDisclosed: true }));
process.exitCode = report.verdict === 'ACCEPT' && intact ? 0 : 1;
