ACCEPT — limitedhashrebind only

Exactly 4 sourceSha256 values changed in scripts/skip-catalog.json: SKIP-PG-004, SKIP-PG-008, SKIP-PG-012, SKIP-PG-014. All 35 actual hashes match; corresponding R23, original R22 and supplied R21 test bytes are identical. Every other catalog metadata byte/value and catalog mode are unchanged.

Supplied R21 native evidence (not R23 execution): unit: 5654 passed, 0 skips; postgres: 288 passed, 0 skips; chaos: 20 passed, 0 skips; e2e: 12 passed, 0 skips. Existing read-only buildSkipInventory imported from R23, invoked with root R21, explicit R23 catalog and supplied R21 report paths: PASS; 0 skips. Its report.executed flag means parsed evidence, not a suite run by this reviewer.

Original R22 catalog rejects exactly four stale hashes. Finite negative controls cover wrong hashes for each changed entry, invalid/duplicate metadata, frozen metadata fields and layout, copied test-source tampering, required skips and expected-count mismatch. Valid-looking metadata/source rebinding is also rejected by the independent original-boundary comparison. 29/29 listed controls passed; see all checks and raw attempts in report.json and raw/.

118 relevant input files preserved byte/hash, mode and nanosecond mtime across helper/control execution. No source edits, full suite, application execution, network, PostgreSQL, providers, installation, private environment access or child processes. No application or production approval.

Failures: none.

Procedural deviation: bootstrap ran the default Node24 version-only query before locating Node22. All substantive review/helper/control execution used Node22. ACCEPT is limited to verified hash rebinding, not perfect procedural conformance. The final integrity recheck also preserved all 118 relevant inputs.
