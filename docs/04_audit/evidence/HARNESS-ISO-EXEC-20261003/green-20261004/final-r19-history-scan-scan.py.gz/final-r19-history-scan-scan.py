from pathlib import Path
import json,subprocess,os,hashlib,datetime
b=Path('/home/ricardo/.cache/cvg-harness-green-20261004');p=Path(__file__).parent; a=json.loads((p/'authority.json').read_text())
cmd=[str(b/'security-tools/gitleaks-8.28.0/gitleaks'),'git',a['source'],'--log-opts='+a['head'],'--config',str(b/'security-final-scans-r19/tools/strict-default.toml'),'--gitleaks-ignore-path',str(b/'security-final-scans-r19/tools/empty.gitleaksignore'),'--ignore-gitleaks-allow','--redact=100','--no-banner','--no-color','--report-format=json','--report-path',str(p/'gitleaks-history.json')]
env={k:v for k,v in os.environ.items() if k in ['HOME','LANG','PATH']};start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (p/'scan.log').open('wb') as f:r=subprocess.run(cmd,cwd=p,env=env,stdout=f,stderr=subprocess.STDOUT)
rows=json.loads((p/'gitleaks-history.json').read_text()) if (p/'gitleaks-history.json').exists() else []
(p/'receipt.json').write_text(json.dumps({'command':cmd,'head':a['head'],'exitCode':r.returncode,'findings':len(rows),'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'disposition':'PENDING','logSha256':hashlib.sha256((p/'scan.log').read_bytes()).hexdigest()},indent=2)+'\n');print(json.dumps({'exit':r.returncode,'findings':len(rows)}))
