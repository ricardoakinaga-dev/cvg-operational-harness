
import pg from '../final-api-qualification-r19/runtime/node_modules/pg/lib/index.js';const {Pool}=pg;
import {buildServer} from '../final-api-qualification-r19/runtime/apps/api/dist/server.js';
import {InMemoryControlPlaneStore} from '../final-api-qualification-r19/runtime/packages/platform/dist/control-plane-store.js';
import {runCriticalSafetyPreflight} from '../final-api-qualification-r19/runtime/packages/platform/dist/critical-safety-preflight.js';
import {PostgresRateLimiter,createControlledRateLimitKeyRing} from '../final-api-qualification-r19/runtime/apps/api/dist/rate-limit.js';
import {PostgresOperatorSessionStore,createPostgresOperatorSessionPool} from '../final-api-qualification-r19/runtime/apps/api/dist/operator-session-postgres.js';
import {createTrustedOperatorIdentityResolver,createTrustedOperatorIdentityToken} from '../final-api-qualification-r19/runtime/apps/api/dist/operator-identity.js';
import {assertPostgresOperatorSessionBoundary} from '../final-api-qualification-r19/runtime/apps/api/dist/operator-session-preflight.js';
import {config} from './fixture-config.mjs';
const pool=new Pool({connectionString:process.env.RATE_URL,options:`-c search_path=${process.env.RATE_SCHEMA}`});
const authPool=createPostgresOperatorSessionPool(process.env.AUTH_URL);
await assertPostgresOperatorSessionBoundary(authPool,{authSchemaName:process.env.AUTH_SCHEMA,expectedSessionRole:new URL(process.env.AUTH_URL).username,productSchemaName:process.env.RATE_SCHEMA});
const sessionStore=new PostgresOperatorSessionStore(authPool,process.env.AUTH_SCHEMA);
const scope={tenantId:'tenant_00000000-0000-4000-8000-000000000211'};
const identity={operatorId:'synthetic.rate.admin',role:'Admin',...scope};const secret='synthetic-rate-proof-signing-key-20261004-only';
const platform=new InMemoryControlPlaneStore();
const agent=await platform.createAgent(scope,{slug:'synthetic-rate-proof',name:'Synthetic rate proof',description:'Synthetic'});
const version=await platform.createVersion(scope,agent.id,config,identity.operatorId);
await platform.transitionVersion(scope,version.id,'TESTING');await platform.transitionVersion(scope,version.id,'APPROVED');
const gateResults=['safety_preflight','test_lab_regression','snapshot_integrity','external_boundary'].map(key=>({key,status:'PASS',evidenceRef:'controlled://evidence/synthetic-rate-proof'}));
const candidate=await platform.createReleaseCandidate(scope,{agentId:agent.id,versionId:version.id,gateResults},'synthetic.creator');
await platform.transitionReleaseCandidate(scope,candidate.id,'VALIDATED','synthetic.approver','DRAFT');
const counters={getVersion:0,publishVersion:0,rollback:0,sessionLookup:0};
for(const name of ['getVersion','publishVersion','rollback']){const fn=platform[name].bind(platform);platform[name]=async(...args)=>{counters[name]++;return fn(...args);};}
const get=sessionStore.get.bind(sessionStore);sessionStore.get=async(...args)=>{counters.sessionLookup++;return get(...args);};
const app=buildServer({durableInbound:true,platform,identityMode:'trusted',operatorIdentityResolver:createTrustedOperatorIdentityResolver({secret}),operatorSessionStore:sessionStore,rateLimiter:new PostgresRateLimiter(pool,{keyRing:createControlledRateLimitKeyRing()}),httpSecurity:{trustedProxyAddresses:[],enforceHttps:false,allowedOrigins:['https://synthetic-rate.example']}});
const listenOrigin=await app.listen({host:'127.0.0.1',port:0});
const session=await sessionStore.create({identity,expiresAt:Date.now()+120000});
const times=[];let last;
for(let i=0;i<20;i++){const started=performance.now();last=await runCriticalSafetyPreflight({store:platform,...scope,agentId:agent.id,versionId:version.id});times.push(performance.now()-started);}
for(const k of Object.keys(counters))counters[k]=0;
process.send({ready:true,httpOrigin:listenOrigin,pid:process.pid,agentId:agent.id,versionId:version.id,candidateId:candidate.id,sessionId:session.sessionId,preflight:{caseCount:last.caseCount,externalCall:last.externalCall,passed:last.passed,timesMs:times}});
process.on('message',async msg=>{try{
 if(msg.close){await app.close();await pool.end();await authPool.end();process.send({closed:true,pid:process.pid});process.disconnect();return;}
 if(msg.reset){for(const k of Object.keys(counters))counters[k]=0;process.send({id:msg.id,reset:true});return;}
 const path=msg.operation==='rollback'?`/v1/admin/agents/${agent.id}/rollback`:`/v1/admin/agents/${agent.id}/versions/${version.id}/publish`;
 const results=[];
 for(let i=0;i<(msg.count??1);i++){
  const headers={'x-cvg-operator-token':createTrustedOperatorIdentityToken(identity,secret),'x-forwarded-for':`192.0.2.${(i%200)+1}`};
  if(msg.cookie){headers.cookie='cvg_operator_session='+msg.cookie;headers.origin='https://synthetic-rate.example';if(msg.cookieOnly)delete headers['x-cvg-operator-token'];}
  const response=await fetch(listenOrigin+path,{method:'POST',headers:{...headers,'content-type':'application/json'},body:JSON.stringify({releaseCandidateId:candidate.id,...(msg.operation==='rollback'?{versionId:version.id}:{})}),signal:AbortSignal.timeout(5000)});const body=await response.json();
  results.push({status:response.status,error:body.error?.code,retryAfter:response.headers.get('retry-after')});
 }
 process.send({id:msg.id,pid:process.pid,results,counters:{...counters}});
}catch(error){process.send({id:msg.id,error:error.message});}});
