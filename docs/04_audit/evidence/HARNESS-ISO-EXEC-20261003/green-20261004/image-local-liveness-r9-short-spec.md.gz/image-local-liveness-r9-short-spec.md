# R9 local image liveness

Real compiled R8 healthcheck fails426 because Docker GET/live has no TLS. Permit only exact GET /live from real socket loopback, including canonical mapped loopback. Never infer locality from forwarding headers, trustProxy, hostname, URL or configured addresses. Other routes, methods, nonlocal/missing peers keep HTTPS gate. Preserve CORS and security response hooks. Native socket and negative regressions plus compiled production entrypoint qualification and a new independent review required. Synthetic only; no provider/release authority.
