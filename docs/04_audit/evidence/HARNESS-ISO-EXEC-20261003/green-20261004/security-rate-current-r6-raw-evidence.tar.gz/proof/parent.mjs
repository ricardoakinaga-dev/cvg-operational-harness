
import fs from 'node:fs';import {fork} from 'node:child_process';import {Client} from 'pg';
import {runPostgresMigrations} from '../../candidate/packages/persistence/src/postgres-migrations.ts';
import {runOperatorSessionMigrations,grantOperatorSessionFunctions} from '../../candidate/packages/persistence/src/operator-session-migrations.ts';
const reportPath=process.argv[2];const adminUrl=process.env.TEST_DATABASE_URL;if(!adminUrl)throw Error('missing synthetic database');
const suffix=String(process.pid);const rateSchema='cvg_rate_proof_'+suffix,authSchema='cvg_auth_proof_'+suffix,migRole='cvg_rate_mig_'+suffix,rateRole='cvg_rate_api_'+suffix,authRole='cvg_rate_session_'+suffix;
const admin=new Client({connectionString:adminUrl});await admin.connect();let migrator;const children=[];const pending=new Map();let seq=0;const observations={node:process.version,processes:[],scenarios:[],storage:{rate:'actual PostgreSQL nonprivileged role',sessions:'actual dedicated PostgreSQL role/schema',controlPlane:'in-memory synthetic fixture, not data-layer qualification'}};
const request=(child,msg)=>new Promise((resolve,reject)=>{const id=++seq;const timer=setTimeout(()=>{pending.delete(id);reject(Error('probe IPC timeout'));},30000);pending.set(id,v=>{clearTimeout(timer);if(v.error)reject(Error(v.error));else resolve(v);});child.send({...msg,id});});
const assert=(v,msg)=>{if(!v)throw Error('probe:'+msg);};
function url(role,pw){const u=new URL(adminUrl);u.username=role;u.password=pw;return String(u);}
async function spawn(){return new Promise((resolve,reject)=>{const c=fork(new URL('./worker.mjs',import.meta.url),[],{cwd:new URL('../../candidate/',import.meta.url),execPath:process.execPath,execArgv:['--import','tsx'],env:{PATH:process.env.PATH,HOME:process.env.HOME,NODE_ENV:'production',RATE_URL:url(rateRole,'synthetic_rate_only'),RATE_SCHEMA:rateSchema,AUTH_URL:url(authRole,'synthetic_auth_only'),AUTH_SCHEMA:authSchema},stdio:['ignore','ignore','pipe','ipc']});children.push(c);let stderr='';c.stderr.on('data',d=>stderr+=d);c.on('message',m=>{if(m.ready){observations.processes.push(m);resolve(c);}else if(m.id)pending.get(m.id)?.(m);});c.on('exit',code=>{if(code&&!c.killed)reject(Error('worker exit '+code+':'+stderr.slice(0,1000)));});c.on('error',reject);});}
try{
 const db=(await admin.query('SELECT current_database() AS name')).rows[0].name;
 for(const [role,password] of [[migRole,'synthetic_mig_only'],[rateRole,'synthetic_rate_only'],[authRole,'synthetic_auth_only']])await admin.query(`CREATE ROLE ${role} LOGIN PASSWORD '${password}' NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE NOREPLICATION`);
 await admin.query(`GRANT CREATE ON DATABASE "${db}" TO ${migRole}`);
 await runPostgresMigrations(admin,{schemaName:rateSchema});
 await admin.query(`GRANT USAGE ON SCHEMA ${rateSchema} TO ${rateRole}`);await admin.query(`GRANT SELECT,INSERT,UPDATE,DELETE ON ${rateSchema}.rate_limit_buckets TO ${rateRole}`);
 migrator=new Client({connectionString:url(migRole,'synthetic_mig_only')});await migrator.connect();await runOperatorSessionMigrations(migrator,authSchema,rateSchema);await grantOperatorSessionFunctions(migrator,authSchema,authRole);
 const a=await spawn(),b=await spawn();assert(a.pid!==b.pid,'independent_processes');
 const crossCookie=await request(b,{operation:'publish',cookie:observations.processes[0].sessionId,cookieOnly:true});assert(crossCookie.results[0].status===200&&crossCookie.counters.sessionLookup===1,'durable_cross_process_cookie_authority');observations.crossProcessCookie=crossCookie;

 for(const operation of ['publish','rollback']){
  await admin.query(`TRUNCATE ${rateSchema}.rate_limit_buckets`);await request(a,{reset:true});await request(b,{reset:true});
  const first=await request(a,{operation,count:150});const second=await request(b,{operation,count:150});const denied=await request(a,{operation});const before={...denied.counters};const extra=await request(b,{operation,count:3});
  assert(first.results.every(x=>x.status!==429)&&second.results.every(x=>x.status!==429),'first300_admitted');assert(denied.results[0].status===429&&extra.results.every(x=>x.status===429),'shared_budget_enforced');assert(first.counters.getVersion>=150&&second.counters.getVersion>=150,'signed_authority_reached_handler');assert(JSON.stringify(second.counters)===JSON.stringify(extra.counters),'no_handler_after_denial');
  observations.scenarios.push({operation,firstPid:a.pid,secondPid:b.pid,firstCount:first.results.length,secondCount:second.results.length,firstStatuses:[...new Set(first.results.map(x=>x.status))],secondStatuses:[...new Set(second.results.map(x=>x.status))],denied:denied.results,extra:extra.results,countersA:before,countersB:extra.counters,untrustedForwardedFor:'300 distinct spoofed forwarding values do not rotate actual peer bucket'});
 }
 await admin.query(`TRUNCATE ${rateSchema}.rate_limit_buckets`);await request(a,{reset:true});
 await admin.query(`REVOKE SELECT,INSERT,UPDATE,DELETE ON ${rateSchema}.rate_limit_buckets FROM ${rateRole}`);
 for(const operation of ['publish','rollback']){const fault=await request(a,{operation});assert(fault.results[0].status===429,'store_fault_denies');assert(fault.counters.getVersion===0&&fault.counters.publishVersion===0&&fault.counters.rollback===0,'fault_before_effect');observations.scenarios.push({operation,storeFault:fault});}
 observations.status='PASS';
}catch(error){observations.status='FAIL';observations.error=error.message;process.exitCode=1;}
finally{
 for(const child of children){if(child.connected){child.send({close:true});await new Promise(resolve=>{if(child.exitCode!==null)return resolve();child.once('exit',resolve);setTimeout(()=>{child.kill('SIGTERM');resolve();},5000).unref();});}}
 await migrator?.end().catch(()=>{});await admin.query(`DROP SCHEMA IF EXISTS ${authSchema} CASCADE`);await admin.query(`DROP SCHEMA IF EXISTS ${rateSchema} CASCADE`);
 for(const role of [authRole,rateRole,migRole]){await admin.query(`DROP OWNED BY ${role}`).catch(()=>{});await admin.query(`DROP ROLE IF EXISTS ${role}`).catch(()=>{});}
 const remain=await admin.query('SELECT rolname FROM pg_roles WHERE rolname = ANY($1)',[[authRole,rateRole,migRole]]);observations.cleanup={remainingOwnRoles:remain.rowCount};await admin.end();fs.writeFileSync(reportPath,JSON.stringify(observations,null,2)+'\n');console.log(JSON.stringify({status:observations.status,processes:observations.processes.length,scenarios:observations.scenarios.length,error:observations.error,cleanup:observations.cleanup}));
}
