# R46 T2 — occurrence-bound descriptor local proof

Task: R46_INSTALLED_DESCRIPTOR_PROOF; Builder only, authorized by user and Lead claim.
Ownership: this directory only. Pipeline: R39 DISCOVERY/recon -> existing approved harness scope -> this short SPEC -> isolated BUILD -> fresh Critic pending.

Recon: R39 real int.common.cjs has three dynamic flags (desc assignment, reflection call, enumerable access). Global spelling and a locally stable alias do not prove incoming intrinsic stability. No existing supplied receipt proves that premise.

Rules: copy only boundary-code-execution.mjs and its lexical dependency. Keep original classification, diagnostics, traversal, loaders and 371 originals unchanged. Sidecar identities may add exact source hash/UTF16/UTF8 spans/text hashes/lexical declaration identity without changing CLI/public schemas. A bounded structural/binding proof may characterize the closed local esbuild helper, receiver, key and descriptor use slice; it cannot grant intrinsic trust. Unknown joins/branches, escapes, writes, Proxy, shadowing or shape/budget/binding failures must refuse proof. No package/name waiver, suppressed rows or trusted-profile flag. Tooling TypeScript R25 readonly is a parser, NOT physical-installed proof. No inspected payload executed.

Ready criteria: before/after real/minimal AST reproduction and R39 controls; new adversarial assertions for refs, descriptor fields/escapes, aliases, incoming defaults, sibling loaders and sinks. Positive local proofs remain UNKNOWN overall and retain diagnostics. Stable occurrence identity and parser/binder hashes captured. Node22.23.2 only. Bounded checks only; prohibited gates NOT_RUN. Source readset unchanged, diff/payload and command exit/logs/manifest provided. Deliver IMPLEMENTED instrumentation/local verifier plus explicit limitation on requested suppression; fresh Critic must independently inspect bytes. No acceptance/release.

Alternative: prerequisite proof builder without suppression, plus exact occurrence identity. Future legitimate integration needs an independently qualified execution context guaranteeing captured intrinsics and mutation freedom before this helper, or replacing reflective runtime helper with a nonreflective module wrapper under a separate source/generator task. A user-supplied boolean or package trust is insufficient.

No Root ledger writes: handoff continuity in own report/state only, per explicit ownership.
