import { analyze, real, realPath, minimal, controls, mutations, record } from './support.mjs'
const result = {
  kind: 'ORIGINAL_R25_DYNAMIC_ANALYZER_ONLY', node: process.version,
  real: analyze(real, { baseline: true, name: realPath }),
  minimal: analyze(minimal, { baseline: true }),
  controls: controls.map((item) => ({ name: item.name, expectation: item.expectation,
    ...analyze(item.text, { baseline: true }) })),
  mutations: mutations.map((item) => ({ name: item.name, ...analyze(item.text, { baseline: true }) })),
  fullInstalledCLI: 'NOT_RUN', physicalInstallationProof: false
}
record('baseline.json', result)
console.log(JSON.stringify({ real: result.real.dynamicStatus, realFlags: result.real.diagnostics.length,
  minimalFlags: result.minimal.diagnostics.length, controls: result.controls.length,
  mutations: result.mutations.length, payloadsExecuted: 0 }))
