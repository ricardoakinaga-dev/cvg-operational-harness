import assert from 'node:assert/strict'
import test from 'node:test'
import fs from 'node:fs'
import path from 'node:path'
import { analyze, real, realPath, minimal, controls, mutations, record, out, hash, ts } from './support.mjs'

const results = []
function compare(name, text, options = {}) {
  const before = analyze(text, { ...options, baseline: true })
  const after = analyze(text, options)
  assert.equal(before.parseErrors, 0, name)
  assert.equal(after.parseErrors, 0, name)
  assert.deepEqual(after.diagnostics, before.diagnostics, `${name}: original diagnostics must survive`)
  assert.deepEqual(after.loaderOccurrences, before.loaderOccurrences, `${name}: loader AST edges must survive`)
  assert.equal(after.occurrences.length, after.diagnostics.length)
  assert.equal(after.proofs[0].status, 'UNKNOWN')
  assert.equal(after.proofs[0].incomingIntrinsics, 'UNKNOWN')
  assert.equal(after.proofs[0].suppressedDiagnostics, 0)
  results.push({ name, textSha256: hash(text), before, after })
  return after
}

test('real bytes: original three diagnostics, original spans, conditional local match and UNKNOWN context', () => {
  const result = compare('real R25', real, { name: realPath })
  assert.deepEqual(result.diagnostics.map((item) => [item.startUtf16, item.endUtf16]), [[628,632],[635,662],[667,682]])
  assert.equal(result.proofs[0].localStatus, 'MATCHED_CONDITIONAL_RECIPE')
  assert.deepEqual(result.proofs[0].blockers, ['INCOMING_INTRINSIC_STABILITY_UNPROVED'])
  assert.equal(result.dynamicStatus, 'INCOMPLETE')
  assert.equal(result.loaderOccurrences.length, 2)
  assert.deepEqual(result.loaderOccurrences.map((item) => item.specifier), ['../../entity.cjs', './common.cjs'])
  assert.equal(new Set(result.occurrences.map((item) => item.occurrenceId)).size, 3)
  assert.equal(result.occurrences[0].binding.status, 'BOUND')
  assert.equal(result.occurrences[0].binding.declarations[0].kind, 'Parameter')
})
test('minimal fixture: closed lexical caller/use recipe does not grant intrinsic trust', () => {
  const result = compare('minimal R39', minimal)
  assert.equal(result.proofs[0].localStatus, 'MATCHED_CONDITIONAL_RECIPE')
  const roles = result.proofs[0].bindings.map((item) => item.role)
  for (const role of ['_copy', '_common', '_export', '_receiver', 'desc', 'from', 'key'])
    assert.ok(roles.includes(role), role)
})
test('renamed lexical cells match; no spelling-only or package waiver', () => {
  let text = minimal
  const names = ['__copyProps','__toCommonJS','__export','__getOwnPropDesc','__defProp','__getOwnPropNames','__hasOwnProp','int_common_exports','from','desc']
  for (const [index, name] of names.entries()) text = text.replace(new RegExp('\\b' + name + '\\b', 'g'), 'renamed' + index)
  const result = compare('renamed helper', text, { name: '/arbitrary/untrusted-pkg/fixture.cjs' })
  assert.equal(result.proofs[0].localStatus, 'MATCHED_CONDITIONAL_RECIPE')
  assert.equal(result.diagnostics.length, 3)
})

for (const item of controls) test('R39 control: ' + item.name, () => {
  const result = compare(item.name, item.text)
  if (item.expectation === 'negative') assert.ok(result.diagnostics.length > 0)
  if (item.expectation === 'positive') assert.equal(result.diagnostics.length, 0)
  assert.equal(result.proofs[0].localStatus, 'UNKNOWN')
})
for (const item of mutations) test('R39 mutation: ' + item.name, () => {
  const result = compare(item.name, item.text)
  assert.ok(result.diagnostics.length > 0)
  assert.equal(result.proofs[0].localStatus,
    item.name === 'separate sink beside metadata' ? 'MATCHED_CONDITIONAL_RECIPE' : 'UNKNOWN')
})

const adversarial = [
  ['value transfer', minimal.replace('return to;', 'consume(desc.value); return to;')],
  ['setter callable', minimal.replace('return to;', 'desc.set(Function); return to;')],
  ['descriptor branch Function', minimal.replace('__getOwnPropDesc(from, key)', '(condition ? __getOwnPropDesc(from, key) : Function)')],
  ['descriptor branch unknown', minimal.replace('__getOwnPropDesc(from, key)', '(condition ? __getOwnPropDesc(from, key) : external)')],
  ['computed consumer with sibling loader', minimal.replace('desc.enumerable', 'desc[require(dynamicKey)]')],
  ['intrinsic alias destructuring write', minimal + '\n({get: __getOwnPropDesc} = external);'],
  ['descriptor destructuring write', minimal.replace('return to;', '({x: desc}=external); return to;')],
  ['unknown fourth actual desc', minimal.replace('__copyProps(__defProp({}, "__esModule", {value: true}), mod)', '__copyProps(__defProp({}, "__esModule", {value: true}), mod, null, Function)')],
  ['descriptor default incoming', minimal.replace('except, desc)', 'except, desc = Function)')],
  ['receiver conditional unknown', minimal.replace('var int_common_exports = {};', 'var int_common_exports = condition ? {} : external;')],
  ['receiver spread', minimal.replace('var int_common_exports = {};', 'var int_common_exports = {...external};')],
  ['function aliases escape', minimal + '\nconst alias = __copyProps; alias({}, external);'],
  ['copy export escape', minimal + '\nmodule.exports.copy = __copyProps;'],
  ['receiver hidden mutation', minimal + '\nint_common_exports.x = Function;'],
  ['intrinsic overwrite after capture', minimal + '\nObject.getOwnPropertyDescriptor = Function;'],
  ['global Object shadow hoisted declaration', minimal + '\nvar Object = external;'],
  ['source prefix sink', 'eval("1");\n' + minimal],
  ['key branch', minimal.replace('__getOwnPropDesc(from, key)', '__getOwnPropDesc(from, condition ? key : external)')],
  ['key array non-scalar', minimal.replace('__getOwnPropDesc(from, key)', '__getOwnPropDesc(from, [key])')],
  ['key reassignment', minimal.replace('if (!__hasOwnProp.call', 'if ((key=external) && !__hasOwnProp.call')],
  ['metadata consumer mutation', minimal.replace('desc.enumerable', '(desc.enumerable = Function)')],
  ['metadata bitwise consumer', minimal.replace('!(desc =', '~(desc =')],
  ['getOwnPropertyNames intrinsic replaced', minimal.replace('Object.getOwnPropertyNames', 'Object.getOwnPropertyDescriptors')],
  ['helper unknown return', minimal.replace('return to;', 'return desc;')],
  ['extra known helper caller', minimal + '\n__copyProps({}, {});'],
  ['descriptor method-call escape', minimal.replace('desc.enumerable', 'desc.enumerable()')],
  ['recursive copy caller', minimal.replace('return to;', '__copyProps(to, from); return to;')],
  ['unknown getter target', minimal.replace('() => PgIntColumnBaseBuilder', '() => external')],
  ['duplicate alias declaration', minimal + '\nvar __getOwnPropDesc;'],
  ['receiver Proxy before snapshot', minimal.replace('var int_common_exports = {};', 'var int_common_exports = new Proxy({}, {});')]
]
for (const [name, text] of adversarial) test('adversarial: ' + name, () => {
  const result = compare(name, text)
  assert.equal(result.proofs[0].localStatus, 'UNKNOWN')
})

test('independent sibling sinks and loader identifiers remain visited', () => {
  const text = minimal + '\neval("1"); require("node:vm").runInThisContext("1"); require(dynamicPath);'
  const result = compare('sibling sinks and loader', text)
  assert.equal(result.proofs[0].localStatus, 'MATCHED_CONDITIONAL_RECIPE')
  assert.ok(result.diagnostics.some((item) => item.text === 'eval("1")'))
  assert.ok(result.diagnostics.some((item) => item.text.includes('runInThisContext')))
  assert.equal(result.loaderOccurrences.length, 2)
  assert.equal(result.loaderOccurrences[1].specifier, undefined)
  // This trace binds original loader AST nodes. Resolution/closure is NOT proved.
})
test('an unrelated shadow has its own binding and is still inspected', () => {
  const result = compare('shadowed sibling', minimal + '\nfunction shadow(__copyProps) { __copyProps({}, external); eval("1"); }')
  assert.equal(result.proofs[0].localStatus, 'MATCHED_CONDITIONAL_RECIPE')
  assert.ok(result.diagnostics.some((item) => item.text === 'eval("1")'))
})
test('incomplete traversal is UNKNOWN', () => {
  const result = compare('traversal omitted SourceFile', minimal, { omitNode: true })
  assert.equal(result.proofs[0].localStatus, 'UNKNOWN')
  assert.deepEqual(result.proofs[0].blockers, ['TRAVERSAL_INCOMPLETE'])
})
test('node budget exhaustion is UNKNOWN and original flags survive', () => {
  const result = compare('node budget', minimal + '\n' + '0;'.repeat(6001))
  assert.deepEqual(result.proofs[0].blockers, ['NODE_BUDGET_EXHAUSTED'])
})
test('malformed parse refuses metadata proof', () => {
  const result = analyze(minimal + '\nconst malformed = ;')
  assert.ok(result.parseErrors > 0)
  assert.equal(result.proofs[0].status, 'UNKNOWN')
  assert.deepEqual(result.proofs[0].blockers, ['PARSE_INCOMPLETE'])
})
test('UTF8/UTF16 occurrence identity, binding spans and deterministic repeat', () => {
  const text = '/* 😃 ç */\n' + real
  const first = compare('unicode offset', text, { name: realPath })
  const second = analyze(text, { name: realPath })
  assert.deepEqual(first.occurrences, second.occurrences)
  for (const item of first.occurrences) {
    assert.equal(item.startUtf8, Buffer.byteLength(text.slice(0, item.startUtf16)))
    assert.equal(item.endUtf8, Buffer.byteLength(text.slice(0, item.endUtf16)))
    assert.equal(item.textSha256, hash(text.slice(item.startUtf16, item.endUtf16)))
    assert.notEqual(item.startUtf8, item.startUtf16)
  }
  assert.notEqual(first.occurrences[0].occurrenceId, analyze(real, { name: realPath }).occurrences[0].occurrenceId)
})
test('no hooks: original diagnostic callback schema and count are unchanged', () => {
  const before = analyze(real, { baseline: true })
  const after = analyze(real, { evidence: false })
  assert.deepEqual(after.diagnostics, before.diagnostics)
  assert.equal(after.proofs.length, 0)
  assert.equal(after.occurrences.length, 0)
})
test('all recorded evidence remains unaccepted; persist direct before/after artifacts', () => {
  const baseline = JSON.parse(fs.readFileSync(path.join(out, 'evidence/baseline.json'), 'utf8'))
  assert.equal(baseline.real.dynamicStatus, 'INCOMPLETE')
  assert.equal(baseline.real.diagnostics.length, 3)
  assert.deepEqual(baseline.real.diagnostics, results.find((item) => item.name === 'real R25').after.diagnostics)
  record('after.json', { node: process.version, parser: ts.version, results,
    suppressedDiagnostics: 0, closureVerdict: 'INCOMPLETE_NOT_ACCEPTED',
    limitation: 'Incoming intrinsic stability has no proof. Local matching cannot suppress the three flags.' })
})
