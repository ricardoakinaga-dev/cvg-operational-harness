import fs from 'node:fs'
import path from 'node:path'
import { createHash } from 'node:crypto'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { createBoundaryLexical } from '../scripts/boundary-lexical.mjs'
import { auditDynamicCodeExecution as original } from '../baseline/boundary-code-execution.mjs'
import { auditDynamicCodeExecution as candidate } from '../scripts/boundary-code-execution.mjs'

export const out = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
export const root = '/home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r25'
export const recon = '/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/installed-closure-next-correction-r39'
if (process.execPath !== '/home/ricardo/.nvm/versions/node/v22.23.2/bin/node')
  throw new Error('Exact Node22 required')
export const ts = createRequire(path.join(root, 'scripts/check-product-boundary.mjs'))('typescript')
export const hash = (bytes) => createHash('sha256').update(bytes).digest('hex')
export const realPath = path.join(root, 'node_modules/drizzle-orm/pg-core/columns/int.common.cjs')
export const real = fs.readFileSync(realPath, 'utf8')
export const minimal = fs.readFileSync(path.join(recon, 'minimal-fixture.txt'), 'utf8')
export const controls = JSON.parse(fs.readFileSync(path.join(recon, 'controls.json'), 'utf8')).cases
export const mutations = JSON.parse(fs.readFileSync(path.join(recon, 'proposal-controls.json'), 'utf8')).results

export function analyze(text, { baseline = false, name = 'fixture.cjs', evidence = true, omitNode = false } = {}) {
  const source = ts.createSourceFile(name, text, ts.ScriptTarget.Latest, true)
  const all = [], pending = [source]
  while (pending.length) {
    const node = pending.pop(); all.push(node)
    const children = []
    ts.forEachChild(node, (child) => { children.push(child) })
    pending.push(...children.reverse())
  }
  const unavailable = []
  const lexical = createBoundaryLexical(ts, source, true, (item) => unavailable.push(item))
  const unwrap = (node) => {
    while (node && (ts.isParenthesizedExpression(node) || ts.isAsExpression(node) ||
      ts.isSatisfiesExpression(node) || ts.isNonNullExpression(node) || ts.isTypeAssertionExpression(node)))
      node = node.expression
    return node
  }
  const literal = (node) => { node = unwrap(node); return node && ts.isStringLiteralLike(node) ? node.text : undefined }
  const property = (node) => node && (ts.isPropertyAccessExpression(node) ? node.name.text
    : ts.isElementAccessExpression(node) ? literal(node.argumentExpression) : undefined)
  const global = (node, names) => {
    node = unwrap(node)
    return !!node && ts.isIdentifier(node) && names.some((name) => lexical.identity(node) === lexical.global(name))
  }
  const isLoader = (node) => global(node, ['require']) || (property(node) === 'require' && global(node.expression, ['module']))
  const diagnostics = [], occurrences = [], proofs = []
  const runtimeNodes = all.filter((node) => !lexical.erased(node))
  ;(baseline ? original : candidate)({
    ts, source, lexical, runtimeNodes: omitNode ? runtimeNodes.slice(1) : runtimeNodes,
    typeOnly: lexical.erased, literal, isLoader,
    isBuiltinGetter: (node) => property(node) === 'getBuiltinModule' && global(node.expression, ['process']),
    isGlobal: (node) => global(node, ['global', 'globalThis']),
    isDeclarationName: lexical.isDeclarationName,
    loaderDiagnostic: (node, reason) => {
      const start = node.getStart(source), end = node.getEnd()
      const position = source.getLineAndCharacterOfPosition(start)
      diagnostics.push({ reason, kind: ts.SyntaxKind[node.kind], startUtf16: start, endUtf16: end,
        line: position.line + 1, column: position.character + 1, text: node.getText(source) })
    },
    ...(evidence && !baseline ? {
      onDynamicCodeOccurrence: (item) => occurrences.push(item),
      onDescriptorMetadataProof: (item) => proofs.push(item)
    } : {})
  })
  const loaderOccurrences = all.filter((node) => ts.isCallExpression(node) && isLoader(node.expression))
    .map((node) => ({ startUtf16: node.getStart(source), endUtf16: node.getEnd(),
      text: node.getText(source), specifier: literal(node.arguments[0]), originalBinding: true }))
  return { sourceSha256: hash(text), parser: ts.version, parseErrors: source.parseDiagnostics.length,
    unavailable, diagnostics, occurrences, proofs, loaderOccurrences,
    dynamicStatus: diagnostics.length || unavailable.length ? 'INCOMPLETE' : 'NO_DYNAMIC_FLAGS',
    closureVerdict: 'NOT_EVALUATED', payloadsExecuted: 0 }
}

export function record(name, data) {
  fs.writeFileSync(path.join(out, 'evidence', name), JSON.stringify(data, null, 2) + '\n')
}
