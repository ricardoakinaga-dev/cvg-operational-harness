# Proposta curta autocontida — installed obligation graph

Status: PROPOSAL_ONLY / NO_MODEL / NO_RELEASE. Nenhuma implementação do Source, aprovação de pacote ou concessão de release. Objetivo: substituir o bloqueio instalado derivado por uma obrigação verificável, preservando UNKNOWN intrínseco e VIOLATION.

## 1. Propriedade e domínio

Provar, para roots de core definidos e um snapshot físico fechado, que sua união de dependências declaradas, metadados governados, tipos, destinos require/import e aquisições de código reconhecidas não alcança produto nem deixa uma aquisição não analisada. A prova é relativa a um contexto de execução/carga exato e a um fragmento de linguagem cujo coletor tenha soundness demonstrada. Não promete toda execução JavaScript possível, supply-chain approval, aprovação por nome/versão nem condições futuras.

snapshot/profile/gramática indisponíveis ou não demonstrados criam UNKNOWN. NO_MODEL significa nenhuma ação de modelo/provider como parte da investigação. Execução de módulos alvo é proibida para coletar a prova.

## 2. Identidade de nó e proveniência de aresta

Definir material de identidade e serialização canônica do envelope; SHA-256 dos bytes originais, sem reordenar exports/imports. Objetos do envelope podem ter chaves ordenadas; arrays semânticos e ordem das propriedades do manifesto permanecem nos bytes.

Uma chave de obrigação inclui:

- kind; snapshot digest; realpath e spelling/URL de acesso; cadeia física relevante; hash dos bytes de código ou manifesto, ou receipt explícito de ausência; pacote físico de instalação e package scope mais próximo efetivo;
- caller path/hash, declarante path/hash, campo de dependência, chave literal de instalação, spec literal e target do alias como proveniência; aliases nunca substituem lookup físico;
- modo types/require/import, formato interpretado, conditions/ordem de seleção e subpath; URL/query/fragment quando relevantes; âncora do loader; regras de symlink/case/paths;
- identidade exata do runtime, binário e versão; plataforma/arquitetura; flags, hooks e preloads; digest da configuração/build projection e dos analisadores/resolver/política.

Manter node de ator, node de manifesto, node de código, obrigação de resolução e obrigação de fechamento instalado distinguíveis. Análise de bytes pode ter cache dedicado; sua validade não se transfere entre contextos. Cada edge contém origem/destino exatos, byte offset ou campo/key, todos os hashes/proveniências, modalidade e receipt de resolução. Múltiplos declarantes/aliases preservam edges distintos mesmo para a mesma pasta. Não depender somente do primeiro registro installedActors[context].

Receipt de resolução deve mostrar a ordem de lookup relevante, candidatos existentes/ausentes, spelling/canonical identity, instalação escolhida, export/import branch e destino físico efetivo. Desvio de nearest cria um sucessor próprio; não troca um pacote pelo workspace homônimo. Nome e manifesto válido sozinhos nunca descarregam implementação.

## 3. Obrigações locais obrigatórias

| Obrigação | Evidência mínima para descarga |
| --- | --- |
| Identidade e snapshot | Bytes hashados e cadeia física/containment válidos para cada arquivo/escopo; snapshot imutável ou revalidação final com invalidação de selos. |
| Governança | Manifestos governados com shape/hash; census completo do ator incluindo manifestos nested e todos os quatro campos dependencies/dev/optional/peer; cada local/installed/workspace successor materializado. |
| Sem manifesto raiz | Prova de ausência e limites físicos/package scope real, metadados nested próprios e receipt de census. Nunca sintetizar package.json aprovado. Sem evidência completa, UNKNOWN. |
| Resolução | Para cada declaração instalada e referência de código, destinos require e import exigidos pela barra vigente; tipos/projeção de build separados. Cada item preserva seu request ID e contexto, não só posição de um batch. |
| Código | Parsing e formato; binding lexical por declaração original; união conservadora de aliases/branches; gramática de capacidades de aquisição/execução demonstrada; nenhum escape/loader/base ou execução dinâmica não modelado. |
| Fronteira | Todas as arestas enumeradas, fila drenada, nenhum erro/time budget/truncamento/limite aberto; não usar ausência de diagnóstico como receipt. |

Builtin não é allowlist por pacote: operações/capacidades precisam de semântica delimitada e vinculada ao runtime de referência. Se puderem adquirir/executar código além da gramática fechada, UNKNOWN. O Source retorna cedo para referências builtin, mas isso não constitui nesta proposta prova de completude de todas as capacidades.

Resolver deve produzir TARGET(realpath/URL/format/receipt) ou um resultado explícito NOT_FOUND / NOT_EXPORTED / UNSUPPORTED / ERROR. Nesta proposta todos os resultados não TARGET em obrigações de destinos exigidos são UNKNOWN; mudança para tratar modo indisponível como N/A exige contrato próprio verificável, ausente aqui. A ausência provada de instalação registry pode conservar a regra atual de não haver physical edge, mas exige receipt de lookup e nunca descarrega uma importação de código não resolvida.

Native, customloader não modelado, code execution desconhecido, lexical unavailable, symlink/containment recusados, foreign edge não analisável e package scope incompleto não são aprovados por checksum, nome, workspace ou lockfile.

## 4. Construção finita e selagem

1. Congelar roots não vazios, snapshot/contexto/gramática; criar obligations de core.
2. Expandir cada ator/declaração/ref fisicamente alcançado, mantendo arestas declaradas e físicas em paralelo. Agendar manifestos transitive/nested e código de todos os destinos. Preservar grafo de tipos separadamente tipado.
3. Criar nodes explícitos para null, erro, destino ausente ou formato não suportado. Nunca omitir essas fronteiras, inclusive quando o resolver respondeu um array estruturalmente válido.
4. Validar recibos locais independentemente do solver. Um erro não silencioso preserva rejeição; se traduzido para status, permanece bloqueante, nunca PROVED.
5. Selar um nó somente quando seus recibos e inventário de edges estiverem completos. DFS visiting, cache hit, closureStates.complete de metadados locais e pasta existente são estados provisórios.
6. Se a expansão não terminar em grafo finito dentro do limite, anexar UNKNOWN de fronteira/limite; não condensar apenas o prefixo como completo.
7. Condensar os SCCs do subgrafo relevante, incluindo successors de todas as modalidades. Congelar o grafo antes de emitir receipts de prova.

## 5. Semântica do solver

Para componente C, manter dois conjuntos independentes:

U(C) = UNKNOWN local de cada membro + obrigações não seladas + união de U(D) para cada saída C→D.
V(C) = VIOLATION local de cada membro + união de V(D) para cada saída C→D.

Calcular o menor ponto fixo dos conjuntos de bloqueadores, ou processar a condensação DAG dos sinks para os roots. Internamente cada membro do SCC possui os mesmos conjuntos propagados. Guardar witnesses locais e caminhos de proveniência para roots, sem apagar U quando V existir.

- V não vazio: VIOLATION, mapeado para FAIL.
- V vazio e U não vazio: UNKNOWN, mapeado para INCOMPLETE.
- V e U vazios, todos os membros/saídas selados e todos os checks locais descarregados: PROVED.

Um SCC sem saída e sem bloqueadores é PROVED apenas porque a fronteira e checks locais foram previamente demonstrados. Recorrência não prova nada por si. Node/edge inexistente, roots vazios, colisão de identidade ou qualquer inconsistência são rejeições bloqueantes. Uma implementation escalável usa SCC iterativo e DAG; a referência pequena recursiva do tableau não é um scanner de produção.

## 6. Descarga e integração proposta

Hoje check-product-boundary.mjs:287 e :538 emitem antes de qualquer certificado conjunto. Proposta: ambos registram installed-closure com destino/contexto exatos; continuam governando e expandindo o grafo. Somente após a selagem e propagação, a obrigação PROVED gera receipt de descarga. UNKNOWN/VIOLATION conserva o motivo instalado como diagnóstico derivado com dependências bloqueantes e witnesses; nunca elimina razões independentes.

Em particular, criar uma obrigação UNKNOWN por null em runtime manifestEdge antes de retirar o diagnóstico permanente. governActor/linkedManifests/discoveredSources passam a registrar estados provisórios, não aprovação. closureStates da biblioteca de manifestos mantém seu significado local; não renomeá-lo para prova global.

Receipts de SCC devem vincular membership, IDs/hashes/contextos, evidências locais, edges internos e receipts das saídas. Para evitar hash circular, calcular um digest canônico de todo o SCC e de suas saídas já condensadas, em vez de hashes de filhos internos recursivos. Receipt dos roots vincula snapshot e roots exatos. Revalidar bytes/ausências/diretórios/contexto na aceitação ou usar snapshot imutável. Consistência de hashes não substitui validação independente dos receipts locais.

## 7. Não regressão e próxima evidência

Os controles obrigatórios são leafcomplete, unknownleaf, cyclecomplete/cycleunknown e sete famílias negativas: shadowinstall, exports-mode, customloader, unresolved, native, packageJSONless e foreignedge. Os sete negativos permanecem UNKNOWN/FAIL conforme evidência, nunca PASS. Adicionar tipos/runtime em ambos os sentidos, UNKNOWN+VIOLATION, local missing transitive/nested, symlink, changed bytes, unresolved-mode null, collector unavailable e ordem de travessia. Preservar eventual conjunto histórico exato; ele não foi lido neste scout.

O tableau próprio verifica somente a álgebra, com selos assumidos. Escolha real mínima: neutral/direct do teste autorizado, linhas 200–218; coletar um snapshot físico isolado com hashes de core/bridge/entry, lookup require/import, governança e receipt de código independente. Sem essa evidência, seu verdict físico é desconhecido e não pode ser promovido com base no tableau.

Se “instalado fora de workspace” continuar seed intrínseco UNKNOWN, nenhum solver conservador pode produzir prova. Se somente os dados locais de metadados estiverem completos e a gramática de código não tiver soundness demonstrada, a prova também continua indisponível. Não produzir pseudoSOLVED.

