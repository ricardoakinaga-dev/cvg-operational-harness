# Scout R52 — obrigação de instalação e fechamento por SCC

Veredito do scout: **mecanismo de descarga proposto, prova física ainda UNKNOWN**. O Source atual não descarrega `UNVERIFIED_INSTALLED_DEPENDENCY` por completude. Um grafo de obrigações pode descarregá-la em um fragmento demonstravelmente fechado, mas SCC não fornece a prova independente que falta. Nenhum problema real foi marcado SOLVED, nenhum pacote foi aprovado e nenhum release foi concedido.

Escopo sintético isolado: NO_MODEL / no release. Claim já atribuído pelo Lead, conforme instrução do usuário. Modo Direct da skill orchestrate; zero descendentes. Escritas limitadas a este diretório. Foram lidos os três scripts autorizados e o teste autorizado para escolher um caso concreto. Não foram lidos runtime state, backlog, score, histórico, reviews, governança ou outros arquivos do Source. A instrução específica desta rodada limita a leitura e substitui o fluxo geral do Root. Os arquivos da skill foram consultados apenas por exigência do ambiente e não são evidência técnica do candidato.

## O que o código efetivamente faz

| Ponto | Evidência estática | Consequência |
| --- | --- | --- |
| check-product-boundary.mjs:273–299 | Encontra instalação pelo nome da declaração, liga manifestação/diretório, compara com workspaces e emite o motivo em 287 quando não é workspace. Depois governa o ator e agenda os dois modos. | Para um instalado fora de workspace, o motivo não depende da qualidade do fechamento. Não é uma emissão universal: existe a exceção de workspace. |
| check-product-boundary.mjs:512–542 | Para destino de manifesto resolvido, encontra o contexto físico de runtime; emite em 538 se `context !== nearest && !workspace`. Governa e visita o destino depois. | A segunda emissão é condicional à divergência de contexto, não incondicional para todo destino. Também não consulta completude. |
| check-product-boundary.mjs:482–545 | Resposta com tamanho correto e itens string/null é estruturalmente completa. Para referência de manifesto, null não produz diagnóstico por modo e cai no `continue`. | A primeira emissão mantém o caso bloqueado hoje. Retirá-la sem materializar uma obrigação para null abriria uma descarga indevida. |
| boundary-manifests.mjs:43–164 | Validação de shape e hash dos bytes; closureStates, directIncomplete e propagação para dependências file/link e metadados censados. | `complete` é do subconjunto de metadados locais; não prova JS, instalação registry, exports ou ambos os modos. |
| boundary-manifests.mjs:337–429 | installedActors registra contexto e a primeira declaração; installedPackage usa a ordem de lookup do declarante; runtimePackage identifica o pacote físico de runtime. | A instalação física não pode ser substituída por um workspace homônimo, nem a primeira declaração substituir todas as proveniências de aliases. |
| check-product-boundary.mjs:302–327, 390–444, 660–695 | Governança recursiva do ator e incorporação de destinos físicos ao inventário; parsing, verificação JS e lexical. | Existe infraestrutura útil de coleta, mas ainda não existe receipt conjunto selado de completude. |
| boundary-lexical.mjs:1–45, 179–316; check-product-boundary.mjs:1012–1069 | Binder isolado sem resolução de dependências; identidades de bindings, união de aliases e diagnóstico explícito de análise indisponível; chamada ao auditor de código dinâmico. | Receipt lexical precisa do hash do código/contexto e deve preservar UNKNOWN. O módulo de código dinâmico importado não foi autorizado para leitura; sua cobertura não foi demonstrada. |
| check-product-boundary.mjs:1547–1598 | Alcançabilidade a partir de core; produto/SHIFT resulta FAIL; outros diagnósticos resultam INCOMPLETE. | Descarga deve ocorrer somente após fechar a fronteira e calcular alcançabilidade, mantendo razões/witnesses independentes. |

Não foram executados auditor, CLI, Source, payload, parser, npm ou suites. A observação `node --version` retornou v24.20.0; esse runtime não foi usado como parser, resolver ou executor de controles. Os controles foram avaliados pelo JavaScript puro do tool, sem módulos, sistema de arquivos, subprocessos ou dados do ambiente. O artefato tableau.mjs é código próprio, compatível em sintaxe com Node22, sem execução no topo e sem I/O.

## Descarga possível e impossível

Separar duas coisas: a obrigação pendente `installed-closure(declaração, instalação física, contexto)`, que é **derivada**, e os impedimentos locais intrínsecos que justificam UNKNOWN. Descobrir uma instalação agenda a obrigação; não cria uma premissa permanente de que toda instalação é desconhecida. Ao selar as evidências locais e todos os sucessores, um SCC inteiro pode obter PROVED. Na saída, o motivo instalado permanece se a obrigação for UNKNOWN/VIOLATION; em PROVED, um receipt verificável substitui esse motivo específico. Os demais diagnósticos permanecem.

Se a regra desejada for literalmente “ser instalado fora de workspace implica UNKNOWN intrínseco”, a prova é impossível dentro dessa regra: mesmo uma folha sem arestas possui a semente UNKNOWN, e qualquer ponto fixo conservador a propaga. Remover apenas o texto do diagnóstico não resolve isso. A proposta altera sua interpretação para uma obrigação verificável; não foi implementada ou aprovada.

Há uma segunda impossibilidade prática: SCC resolve agregação, não decidibilidade de comportamento arbitrário de JavaScript. Se o coletor não prova que enumerou todos os caminhos de aquisição/execução de código de um nó, esse nó permanece UNKNOWN. Hashes e ausência de alertas não demonstram essa propriedade. Um fragmento finito com gramática de capacidades validada pode ser fechável; dynamic import não literal, loaders/hook/base desconhecidos, execução dinâmica, formato nativo, análise lexical indisponível e dependências abertas mantêm UNKNOWN. O auditor de código dinâmico e demais fontes não autorizadas impedem afirmar soundness do coletor atual nesta rodada.

## Graph, identidade e receipts

A proposta autocontida está em [short-spec.md](short-spec.md). Seu contrato exige grafo **físico**, hash dos bytes de código e de cada manifesto governado, cadeia de identidade/ausência, lookup do declarante, raiz de instalação, package scope efetivo e contexto exato de resolução/carga. Nome, versão, lockfile ou allowlist não são prova de implementação.

Preservar arestas declaradas/workspace, instalação física mais próxima e destinos efetivos de cada require/import; tipos são uma frente separada. Aresta conserva campo, spec literal, alias, declarante e hash. O mesmo destino com outro modo, condições, âncora ou loader não reutiliza automaticamente um receipt. Guardar todas as proveniências, mesmo quando a análise de bytes puder ser deduplicada. package.json ausente deve ter evidência de ausência/contexto, jamais hash inventado de manifesto. Saída do resolver null/ambígua/malformada é obrigação explícita, não aresta omitida.

Depois da expansão finita e dos selos, condensar SCCs e propagar conjuntos UNKNOWN e VIOLATION, sem apagar um pelo outro. Uma semente em qualquer membro ou saída contamina todo o SCC e seus ancestrais. PROVED exige todos os checks locais descarregados e todas as saídas PROVED. `visiting`, cache hit, shape válido, pasta existente e recursão não são provas.

## Controles próprios e limite de validade

31 controles em [controls-tableau.json](controls-tableau.json), com entradas, bytes sintéticos, hashes, contextos, arestas e SCCs. Resultado: **5 PROVED sintéticos, 22 UNKNOWN e 4 VIOLATION**. Os cinco PROVED significam exclusivamente “agregação sem bloqueadores sob receipts independentes assumidos”, não PASS do candidato físico. Os bytes neutros ilustrativos dos nós não foram analisados para derivar as arestas; o grafo e os selos são entradas explícitas do tableau. Não existe instalação desses caminhos em disco nem resolver Node por trás deles.

| Controle obrigatório | Resultado do tableau | Discriminante |
| --- | --- | --- |
| leafcomplete / unknownleaf | PROVED / UNKNOWN | Folha selada versus impedimento intrínseco. |
| cyclecomplete / cycleunknown / cycleunknown-exit | PROVED / UNKNOWN / UNKNOWN | Recorrência completa versus seed interno/saída aberta. |
| shadowinstall | UNKNOWN | Pacote hoisted completo não cobre instalação mais próxima desconhecida. |
| exports-mode | UNKNOWN | require completo não cobre import desconhecido. |
| customloader | UNKNOWN | Origem/hook não modelado impede usar resolução padrão. |
| unresolved | UNKNOWN | null materializado como obrigação. |
| native | UNKNOWN | Bytes hashados não constituem análise de implementação nativa. |
| packageJSONless | UNKNOWN | Ausência sem prova de scope/census não constitui governança. |
| foreignedge | UNKNOWN | Fora da raiz mantém o motivo atual; produto conhecido tem controle próprio VIOLATION. |

As sete famílias negativas solicitadas são shadowinstall, exports-mode, customloader, unresolved, native, packageJSONless e foreignedge: **7/7 UNKNOWN, zero PASS**. Não foi lida a identidade histórica dos “sete originais”; portanto não afirmo que controles históricos foram reexecutados ou que suas entradas foram preservadas byte a byte. A proposta exige manter todos eles bloqueantes em eventual validação real.

Os demais controles cobrem ciclos não selados, metadados nested/transitivos, violação junto com UNKNOWN, tipos/runtime em ambos os sentidos, mudanças de hash, payload ausente, symlink, contexto de formato, esquema do resolver e proveniência de alias. Casos positivos separados discriminam duas branches completas e contextos físicos distintos completos; não alteram os sete negativos. Um consumidor desconhecido inalcançável não contamina core.

Validação: resultados confrontados com um segundo algoritmo de união de bloqueadores por alcançabilidade; invariância à ordem de nós/arestas; SHA-256 conferido com vetores vazio/abc; diferenciação de contextos apesar de bytes iguais; preservação da ordem de arrays; quatro grafos malformados recusados sem PROVED. É verificação independente do **algoritmo**, feita pelo mesmo agente sobre os mesmos dados sintéticos, não review independente nem validação do coletor real.

## Próximo caso concreto que pode mudar o verdict

Escolha: o caso existente **neutral/direct** de tests/product-boundary-manifest-runtime.test.js:200–218, usando fixture('direct') definida em 19–72. É o menor caso técnico identificável nos caminhos permitidos: core declara bridge; o bridge físico tem main entry.js neutro, sem dependências transitivas. O teste hoje exige INCOMPLETE e apenas UNVERIFIED_INSTALLED_DEPENDENCY. Isso é evidência estática da expectativa escrita; não é resultado observado nesta rodada.

Próxima investigação útil, fora do escopo de execução R52: materializar esse caso como snapshot físico isolado sob ownership do Lead, coletar os bytes/hashes reais de core/bridge/entry, lookup e destinos de **ambos** os modos, formatos/scopes, census dos manifestos e receipt independente de todas as capacidades de código. Calcular o receipt do installed-closure, conservar o candidato atual e comparar seu resultado com um verificador experimental isolado. Com todas as obrigações fisicamente descarregadas, esse único INCOMPLETE derivado poderia mudar para PROVED no modelo proposto. Se import for null, aparecer metadado aberto ou faltar prova da gramática, o caso permanece UNKNOWN, sem pseudoSOLVED.

Este caso concreto é um teste já presente no Source, não um pacote de produção escolhido por nome. Não há evidência autorizada para nomear a primeira instalação real do candidato que tenha somente esse bloqueador. O Lead precisaria fornecer uma fatia física exata dessa instalação para estender o scout; não fiz scan para inventá-la.

## Artefatos e integridade

report.md; findings.json; short-spec.md; controls-tableau.json; tableau.mjs; hashmanifest.json; SHA256SUMS. O manifest inclui hashes dos quatro inputs autorizados e dos outputs anteriores a ele; exclui a si próprio para evitar hash circular. SHA256SUMS inclui hashmanifest.json e exclui a si próprio. Os hashes dos inputs são checados novamente na conclusão. Hash não é aprovação nem prova de completude.

