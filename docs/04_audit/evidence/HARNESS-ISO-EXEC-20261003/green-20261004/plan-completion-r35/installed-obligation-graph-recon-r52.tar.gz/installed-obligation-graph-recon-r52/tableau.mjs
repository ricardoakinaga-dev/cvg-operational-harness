
export function sha256(s) {
  const bytes = Array.from(unescape(encodeURIComponent(s)), c => c.charCodeAt(0));
  const bitLen = bytes.length * 8; bytes.push(128);
  while (bytes.length % 64 !== 56) bytes.push(0);
  for (let i=7;i>=0;i--) bytes.push(i>=4 ? 0 : (bitLen >>> (i*8)) & 255);
  const k=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  const h=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
  const r=(x,n)=>(x>>>n)|(x<<(32-n));
  for(let offset=0;offset<bytes.length;offset+=64) {
    const w=Array(64);
    for(let i=0;i<16;i++) w[i]=(bytes[offset+i*4]<<24)|(bytes[offset+i*4+1]<<16)|(bytes[offset+i*4+2]<<8)|bytes[offset+i*4+3];
    for(let i=16;i<64;i++) { const a=w[i-15],b=w[i-2]; w[i]=(w[i-16]+(r(a,7)^r(a,18)^(a>>>3))+w[i-7]+(r(b,17)^r(b,19)^(b>>>10)))|0; }
    let [a,b,c,d,e,f,g,hh]=h;
    for(let i=0;i<64;i++) { const t1=(hh+(r(e,6)^r(e,11)^r(e,25))+((e&f)^(~e&g))+k[i]+w[i])|0,t2=((r(a,2)^r(a,13)^r(a,22))+((a&b)^(a&c)^(b&c)))|0; hh=g;g=f;f=e;e=(d+t1)|0;d=c;c=b;b=a;a=(t1+t2)|0; }
    [a,b,c,d,e,f,g,hh].forEach((v,i)=>h[i]=(h[i]+v)|0);
  }
  return h.map(v=>(v>>>0).toString(16).padStart(8,'0')).join('');
}
export function canonical(x) {
  if(Array.isArray(x)) return '['+x.map(canonical).join(',')+']';
  if(x && typeof x==='object') return '{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+canonical(x[k])).join(',')+'}';
  return JSON.stringify(x);
}

export function evaluate(graph) {
  // Local flags are inputs from a separate collector/verifier. This tableau
  // supplies them synthetically and does not implement that verifier.
  if(!graph.roots.length) throw Error('EMPTY_ROOT_INVENTORY');
  const nodes=new Map(graph.nodes.map(n=>[n.id,n]));
  if(nodes.size!==graph.nodes.length) throw Error('DUPLICATE_NODE_ID');
  const outgoing=new Map(graph.nodes.map(n=>[n.id,[]]));
  for(const e of graph.edges) {
    if(!nodes.has(e.from)||!nodes.has(e.to)) throw Error('UNMATERIALIZED_ENDPOINT');
    outgoing.get(e.from).push(e.to);
  }
  const reachable=new Set(), queue=[...graph.roots];
  for(let i=0;i<queue.length;i++) {
    const id=queue[i]; if(!nodes.has(id)) throw Error('ROOT_MISSING');
    if(reachable.has(id)) continue; reachable.add(id); queue.push(...outgoing.get(id));
  }
  let clock=0; const index=new Map(), low=new Map(), stack=[],onStack=new Set(), components=[];
  function visit(id) {
    index.set(id,clock);low.set(id,clock++);stack.push(id);onStack.add(id);
    for(const to of outgoing.get(id)) {
      if(!reachable.has(to)) continue;
      if(!index.has(to)) { visit(to);low.set(id,Math.min(low.get(id),low.get(to))); }
      else if(onStack.has(to)) low.set(id,Math.min(low.get(id),index.get(to)));
    }
    if(low.get(id)===index.get(id)) {
      const members=[];let top;
      do { top=stack.pop();onStack.delete(top);members.push(top); } while(top!==id);
      components.push(members.sort());
    }
  }
  for(const id of [...reachable].sort()) if(!index.has(id)) visit(id);
  const owner=new Map();components.forEach((members,i)=>members.forEach(id=>owner.set(id,i)));
  const states=components.map((members,i)=>({
    members,
    outgoing:[...new Set(members.flatMap(id=>outgoing.get(id)).map(id=>owner.get(id)).filter(j=>j!==i))].sort((a,b)=>a-b),
    unknown:new Set(members.flatMap(id=>[
      ...nodes.get(id).localUnknown,
      ...(nodes.get(id).sealed?[]:['UNSEALED_FRONTIER:'+id])
    ])),
    violation:new Set(members.flatMap(id=>nodes.get(id).localViolation))
  }));
  // Least fixed point of blocker sets; PROVED is derived only after the
  // graph is finite and sealed, never granted upon DFS re-entry.
  let changed=true,rounds=0;
  while(changed) {
    changed=false;rounds++;
    for(const s of states) for(const j of s.outgoing)
      for(const kind of ['unknown','violation']) for(const reason of states[j][kind])
        if(!s[kind].has(reason)) {s[kind].add(reason);changed=true;}
  }
  const verdict=s=>s.violation.size?'VIOLATION':s.unknown.size?'UNKNOWN':'PROVED';
  const nodeStates={};
  for(const id of reachable) { const s=states[owner.get(id)]; nodeStates[id]={verdict:verdict(s),unknown:[...s.unknown].sort(),violation:[...s.violation].sort()}; }
  const rootStates=graph.roots.map(id=>nodeStates[id]);
  const unknown=[...new Set(rootStates.flatMap(s=>s.unknown))].sort(),violation=[...new Set(rootStates.flatMap(s=>s.violation))].sort();
  return {
    verdict:violation.length?'VIOLATION':unknown.length?'UNKNOWN':'PROVED',
    sourceStatusMapping:violation.length?'FAIL':unknown.length?'INCOMPLETE':'PASS',
    sourceStatusMappingIsProposalOnly:true,rootStates,nodeStates,unknown,violation,rounds,
    sccs:states.map(s=>({members:s.members,outgoing:s.outgoing,verdict:verdict(s),unknown:[...s.unknown].sort(),violation:[...s.violation].sort()})),
    reachable:[...reachable].sort()
  };
}

export function runTableau() {
  const makeNode=(label,options={})=>{
    const context={
      evidenceDomain:'IN_MEMORY_ASSUMED_NOT_PHYSICAL',
      packageDirectory:options.packageDirectory??'/synthetic-r52/node_modules/'+label,
      sourcePath:options.sourcePath??'/synthetic-r52/node_modules/'+label+'/entry.js',
      declaredBy:'/synthetic-r52/packages/core/package.json',
      dependencyField:'dependencies',installationKey:options.installationKey??label,
      aliasTarget:options.aliasTarget??label,
      mode:options.mode??'require',conditions:['node',options.mode??'require','default'],
      runtime:{version:'22.0.0',binarySha256:sha256('FICTIONAL_NODE22_BINARY'),platform:'synthetic-linux',arch:'synthetic-x64',
        flags:[],hooks:'assumed-absent',preloads:[],snapshot:'memory-r52'},
      resolutionReceipt:'SYNTHETIC_COLLECTOR_PRECONDITION',
      sourceFormat:options.sourceFormat??'commonjs',loaderAnchor:'CALLER_FILE',
      policy:'SYNTHETIC_ISOLATED_NO_MODEL_NO_RELEASE',
      analyzerSha256:sha256('TABLEAU_NOT_SOURCE_ANALYZER'),
      resolverSha256:sha256('TABLEAU_NOT_NODE_RESOLVER')
    };
    const bytes=options.bytes??'module.exports = 1;\n';
    const manifestBytes=options.manifestAbsent?null:JSON.stringify({name:options.aliasTarget??label,main:'entry.js',type:'commonjs'});
    const identity={
      context,bytesSha256:sha256(bytes),
      manifestSha256:manifestBytes===null?null:sha256(manifestBytes),
      manifestAbsence:manifestBytes===null?'ASSUMED_ABSENCE_ONLY':null,
      kind:options.kind??'CODE_OBLIGATION'
    };
    const obligations=['identity','package-scope','manifest-census','all-four-dependency-fields',
      'require-destinations','import-destinations','type-closure','parse','lexical-capabilities',
      'dynamic-code','native-format','resolution-context','snapshot-stability','outgoing-frontier'];
    return {
      id:sha256(canonical(identity)),label,identity,
      files:[{path:context.sourcePath,sha256:sha256(bytes),bytes},
        ...(manifestBytes===null?[]:[{path:context.packageDirectory+'/package.json',sha256:sha256(manifestBytes),bytes:manifestBytes}])],
      sealed:options.sealed??true,
      localUnknown:options.unknown??[],localViolation:options.violation??[],
      obligationReceipts:obligations.map(type=>({type,discharged:!(options.unknown?.length||options.violation?.length||options.sealed===false),
        evidence:'ASSUMED_SYNTHETIC_PRECONDITION_ONLY'}))
    };
  };
  const e=(a,b,kind='CODE_REFERENCE',extra={})=>({
    from:a.id,to:b.id,kind,declaredBy:a.identity.context.sourcePath,
    callerSha256:a.identity.bytesSha256,installationKey:b.identity.context.installationKey,
    aliasTarget:b.identity.context.aliasTarget,mode:b.identity.context.mode,
    contextSha256:sha256(canonical(b.identity.context)),
    receiptDomain:'IN_MEMORY_ASSUMED_NOT_PHYSICAL',...extra
  });
  const cases=[];
  function add(name,nodes,edges,roots,expected,why,seven=false) {
    const graph={nodes,edges,roots:roots.map(n=>n.id)};
    const actual=evaluate(graph);
    if(actual.verdict!==expected) throw Error('CONTROL_MISMATCH:'+name);
    if(seven&&actual.verdict==='PROVED') throw Error('NEGATIVE_FAMILY_PROVED:'+name);
    cases.push({name,expected,actual,why,sevenNegativeFamily:seven,graph,graphSha256:sha256(canonical(graph))});
  }
  {const a=makeNode('leaf');add('leafcomplete',[a],[],[a],'PROVED','All independent local witnesses are assumed discharged; not a physical proof.');}
  {const a=makeNode('unknownleaf',{unknown:['NON_LITERAL_MODULE_REFERENCE']});add('unknownleaf',[a],[],[a],'UNKNOWN','A leaf can contain an intrinsic unresolved obligation.');}
  {const a=makeNode('cycleA'),b=makeNode('cycleB');add('cyclecomplete',[a,b],[e(a,b),e(b,a)],[a],'PROVED','A sealed SCC is not blocked merely by recurrence.');}
  {const a=makeNode('cycleA'),b=makeNode('cycleB',{unknown:['UNAVAILABLE_LEXICAL_BINDING_ANALYSIS']});add('cycleunknown',[a,b],[e(a,b),e(b,a)],[a],'UNKNOWN','Unknown seed reaches every SCC member.');}
  {const a=makeNode('cycleA'),b=makeNode('cycleB'),u=makeNode('unknownExit',{unknown:['UNRESOLVED_INSTALLED_LOCAL_DEPENDENCY']});add('cycleunknown-exit',[a,b,u],[e(a,b),e(b,a),e(b,u)],[a],'UNKNOWN','An unknown SCC exit blocks the entire cycle.');}
  {const a=makeNode('cycleOpen',{sealed:false}),b=makeNode('cycleB');add('cycle-unsealed',[a,b],[e(a,b),e(b,a)],[a],'UNKNOWN','No optimistic PROVED for visiting or provisional nodes.');}
  {const a=makeNode('root'),b=makeNode('hop'),c=makeNode('leaf',{unknown:['UNRESOLVED_MODULE_REFERENCE']});add('transitive-runtime-unknown',[a,b,c],[e(a,b,'MANIFEST_DECLARATION'),e(b,c,'IMPORT_DESTINATION')],[a],'UNKNOWN','Metadata and runtime share conservative propagation.');}
  {const a=makeNode('root'),nested=makeNode('nestedMeta',{unknown:['UNRESOLVED_INSTALLED_LOCAL_DEPENDENCY']});add('nested-transitive-metadata',[a,nested],[e(a,nested,'OWNED_CENSUS_MANIFEST')],[a],'UNKNOWN','Reached actor owns nested metadata even when its entry is neutral.');}
  {const a=makeNode('root'),shadow=makeNode('bridge-shadow',{packageDirectory:'/synthetic-r52/packages/core/node_modules/bridge',unknown:['UNVERIFIED_SHADOW_PHYSICAL_CLOSURE']}),sameName=makeNode('bridge-hoisted',{aliasTarget:'bridge'});add('shadowinstall',[a,shadow,sameName],[e(a,shadow,'PHYSICAL_LOOKUP_SUCCESSOR')],[a],'UNKNOWN','A complete hoisted package cannot substitute for an unknown nearer installation.',true);}
  {const a=makeNode('root'),r=makeNode('bridge-require',{mode:'require'}),i=makeNode('bridge-import',{mode:'import',unknown:['UNVERIFIED_IMPORT_DESTINATION']});add('exports-mode',[a,r,i],[e(a,r,'REQUIRE_DESTINATION'),e(a,i,'IMPORT_DESTINATION')],[a],'UNKNOWN','Require completeness cannot cover an unverified import branch.',true);}
  {const a=makeNode('root'),b=makeNode('custom',{unknown:['UNVERIFIED_MODULE_LOADER_BASE']});add('customloader',[a,b],[e(a,b)],[a],'UNKNOWN','An unmodeled anchor/hook cannot inherit the default resolver witness.',true);}
  {const a=makeNode('root'),b=makeNode('missing',{kind:'UNRESOLVED_OBLIGATION',unknown:['UNRESOLVED_INSTALLED_RUNTIME_RESOLUTION']});add('unresolved',[a,b],[e(a,b,'NULL_MANIFEST_RUNTIME_RESULT')],[a],'UNKNOWN','A structurally valid null response is not a runtime discharge.',true);}
  {const a=makeNode('root'),b=makeNode('native',{sourceFormat:'native',unknown:['UNVERIFIED_MODULE_FORMAT']});add('native',[a,b],[e(a,b)],[a],'UNKNOWN','Hashing native bytes does not establish analyzed code behavior.',true);}
  {const a=makeNode('root'),b=makeNode('jsonless',{manifestAbsent:true,unknown:['UNVERIFIED_PACKAGE_SCOPE_CENSUS']});add('packageJSONless',[a,b],[e(a,b,'PHYSICAL_DIRECTORY_ACTOR')],[a],'UNKNOWN','No fabricated root-manifest receipt; physical scope evidence is still required.',true);}
  {const a=makeNode('root'),b=makeNode('foreign',{sourcePath:'/outside-synthetic-root/foreign.js',unknown:['MODULE_OUTSIDE_REPOSITORY']});add('foreignedge',[a,b],[e(a,b)],[a],'UNKNOWN','An outside closure remains incomplete under current diagnostic mapping.',true);}
  {const a=makeNode('root'),b=makeNode('product',{violation:['CORE_DEPENDS_ON_PRODUCT']});add('foreign-product-violation',[a,b],[e(a,b)],[a],'VIOLATION','A known forbidden product edge defeats all otherwise complete nodes.');}
  {const a=makeNode('cycleA'),b=makeNode('cycleB',{violation:['CORE_DEPENDS_ON_PRODUCT'],unknown:['UNVERIFIED_DYNAMIC_CODE_EXECUTION']});add('cycle-violation-and-unknown',[a,b],[e(a,b),e(b,a)],[a],'VIOLATION','FAIL takes precedence, while UNKNOWN reasons must remain recorded.');}
  {const a=makeNode('root'),b=makeNode('intrinsic',{unknown:['UNVERIFIED_INSTALLED_DEPENDENCY_INTRINSIC']});add('intrinsic-unproven',[a,b],[e(a,b)],[a],'UNKNOWN','If installed-ness is itself an axiom of UNKNOWN, no SCC algorithm can discharge it.');}
  {const a=makeNode('root'),b=makeNode('entry',{unknown:['UNVERIFIED_DYNAMIC_CODE_EXECUTION']});add('dynamiccode',[a,b],[e(a,b)],[a],'UNKNOWN','Removing a derived installed blocker must not remove dynamic-code evidence.');}
  {const a=makeNode('root'),r=makeNode('types',{mode:'types'}),b=makeNode('runtime',{violation:['CORE_DEPENDS_ON_PRODUCT']});add('types-neutral-runtime-product',[a,r,b],[e(a,r,'TYPE_DESTINATION'),e(a,b,'IMPORT_DESTINATION')],[a],'VIOLATION','Neutral declarations do not certify runtime bytes.');}
  {const a=makeNode('root'),t=makeNode('types',{mode:'types',violation:['CORE_DEPENDS_ON_PRODUCT']}),b=makeNode('runtime');add('types-product-runtime-neutral',[a,t,b],[e(a,t,'TYPE_DESTINATION'),e(a,b)],[a],'VIOLATION','Type closure remains an independent isolation obligation.');}
  {const a=makeNode('root'),b=makeNode('mutated',{unknown:['SNAPSHOT_HASH_MISMATCH']});add('changed-bytes',[a,b],[e(a,b)],[a],'UNKNOWN','A stale source or manifest digest invalidates its seal.');}
  {const a=makeNode('root'),b=makeNode('missingPayload',{unknown:['MISSING_RUNTIME_ENTRY']});add('missing-runtime-entry',[a,b],[e(a,b)],[a],'UNKNOWN','A physically present directory plus metadata does not prove runtime entry existence.');}
  {const a=makeNode('root'),b=makeNode('symlink',{unknown:['PHYSICAL_IDENTITY_REJECTED']});add('symlink-provenance',[a,b],[e(a,b)],[a],'UNKNOWN','A real implementation must retain rejection rather than accept canonical-path laundering.');}
  {const a=makeNode('root'),b=makeNode('modeMismatch',{mode:'import',unknown:['SOURCE_FORMAT_CONTEXT_MISMATCH']});add('mode-format-context',[a,b],[e(a,b)],[a],'UNKNOWN','A require resolution path is not evidence of its load semantics.');}
  {const a=makeNode('root'),b=makeNode('badResolver',{unknown:['RESOLVER_RESPONSE_SCHEMA_MISMATCH']});add('malformed-resolver-response',[a,b],[e(a,b)],[a],'UNKNOWN','No local or batch schema mismatch can silently discharge a destination.');}
  {const a=makeNode('root'),b=makeNode('declaration',{unknown:['ALIAS_DECLARATION_WITNESS_MISMATCH']});add('alias-provenance',[a,b],[e(a,b,'MANIFEST_DECLARATION',{installationKey:'renamed',aliasTarget:'actual'})],[a],'UNKNOWN','An alias string without the declaring bytes and selected directory is not proof.');}
  {const a=makeNode('root'),near=makeNode('bridge-near',{aliasTarget:'bridge'}),far=makeNode('bridge-far',{aliasTarget:'bridge'});add('shadow-both-complete',[a,near,far],[e(a,near,'PHYSICAL_NEAREST'),e(a,far,'DECLARED_WORKSPACE_SUPPLEMENT')],[a],'PROVED','Both exact physical contexts can close under independent synthetic receipts; difference alone is not a whitelist.');}
  {const a=makeNode('root'),r=makeNode('require',{mode:'require'}),i=makeNode('import',{mode:'import'});add('exports-both-complete',[a,r,i],[e(a,r,'REQUIRE_DESTINATION'),e(a,i,'IMPORT_DESTINATION')],[a],'PROVED','Both branches are required and independently discharged.');}
  {const a=makeNode('root'),off=makeNode('unreachable',{unknown:['UNREACHABLE_UNKNOWN']});add('unreachable-consumer',[a,off],[],[a],'PROVED','Only blockers reached from core qualify this isolation verdict.');}
  {const a=makeNode('root',{unknown:['NO_REAL_SOURCE_CODE_VERIFIER']});add('no-real-verifier',[a],[],[a],'UNKNOWN','SCC aggregation cannot supply the missing soundness of a code collector.');}
  const controlsExpected=cases.length;
  const stateCounts=cases.reduce((a,c)=>(a[c.actual.verdict]=(a[c.actual.verdict]??0)+1,a),{});
  const negatives=cases.filter(c=>c.sevenNegativeFamily);
  if(negatives.length!==7||negatives.some(c=>c.actual.verdict!=='UNKNOWN')) throw Error('SEVEN_NEGATIVE_INVARIANT');
  const sameBytesR=makeNode('exact',{mode:'require',packageDirectory:'/synthetic-r52/node_modules/exact',sourcePath:'/synthetic-r52/node_modules/exact/entry.js'});
  const sameBytesI=makeNode('exact',{mode:'import',packageDirectory:'/synthetic-r52/node_modules/exact',sourcePath:'/synthetic-r52/node_modules/exact/entry.js'});
  const alias=makeNode('exact',{installationKey:'renamed',aliasTarget:'exact'});
  if(sameBytesR.id===sameBytesI.id||alias.id===sameBytesR.id) throw Error('CONTEXT_COLLISION');
  const digestChecks={
    empty:sha256('')==='e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    abc:sha256('abc')==='ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad',
    sameBytesDifferentModes:sameBytesR.identity.bytesSha256===sameBytesI.identity.bytesSha256&&sameBytesR.id!==sameBytesI.id,
    sameTargetDifferentAlias:sameBytesR.id!==alias.id,
    canonicalObjectOrder:sha256(canonical({a:1,b:2}))===sha256(canonical({b:2,a:1})),
    arrayOrderPreserved:sha256(canonical({conditions:['node','import']}))!==sha256(canonical({conditions:['import','node']}))
  };
  if(Object.values(digestChecks).some(x=>!x)) throw Error('DIGEST_INVARIANT');
  // Independent oracle: direct reachability union, not SCC internals.
  for(const c of cases) {
    const nodes=new Map(c.graph.nodes.map(n=>[n.id,n])),seen=new Set(),todo=[...c.graph.roots];
    for(let i=0;i<todo.length;i++) if(!seen.has(todo[i])) {
      seen.add(todo[i]);todo.push(...c.graph.edges.filter(e=>e.from===todo[i]).map(e=>e.to));
    }
    const u=[...seen].flatMap(id=>[...nodes.get(id).localUnknown,...(nodes.get(id).sealed?[]:['UNSEALED_FRONTIER:'+id])]);
    const v=[...seen].flatMap(id=>nodes.get(id).localViolation);
    if((v.length?'VIOLATION':u.length?'UNKNOWN':'PROVED')!==c.actual.verdict) throw Error('REACHABILITY_ORACLE_MISMATCH:'+c.name);
    // Edge insertion / node order changes may alter SCC indices, never blockers.
    const reversed=evaluate({...c.graph,nodes:[...c.graph.nodes].reverse(),edges:[...c.graph.edges].reverse()});
    if(reversed.verdict!==c.actual.verdict||canonical(reversed.unknown)!==canonical(c.actual.unknown)||canonical(reversed.violation)!==canonical(c.actual.violation)) throw Error('ORDER_DEPENDENCE');
  }
  return {
    schema:'r52.obligation-tableau.v1',executionDomain:'PURE_TOOL_JAVASCRIPT_IN_MEMORY',
    noSourceImports:true,noPayloadExecution:true,noFilesystemFixtures:true,
    notPhysicalProof:true,sourceVerdictObserved:false,
    count:controlsExpected,counts:stateCounts,
    sevenNegativeInvariant:{count:negatives.length,allUnknown:true,
      originalHistoricalControlIdentity:'NOT_READ_NOT_ASSERTED; THESE ARE OWN FAMILY CONTROLS'},
    digestChecks,independentAlgorithmOracle:'DIRECT_REACHABILITY_UNION_ON_SAME_SYNTHETIC_INPUTS',
    independentReviewer:false,orderInvariance:true,rejectionChecks:runGuardControls(),cases
  };
}

// Explicit invocation only; importing this artifact performs no I/O.
export function renderTableauJSON() { return JSON.stringify(runTableau(), null, 2) + '\n'; }

export function runGuardControls() {
  const checks={};
  for(const [name,graph] of [
    ['emptyRoots',{nodes:[],edges:[],roots:[]}],
    ['missingEndpoint',{nodes:[{id:'r',sealed:true,localUnknown:[],localViolation:[]}],edges:[{from:'r',to:'absent'}],roots:['r']}],
    ['duplicateIdentity',{nodes:[{id:'r'},{id:'r'}],edges:[],roots:['r']}],
    ['missingRoot',{nodes:[],edges:[],roots:['absent']}]
  ]) {
    try { evaluate(graph);throw Error('EXPECTED_REJECTION:'+name); }
    catch(error) { if(error.message.startsWith('EXPECTED_REJECTION:')) throw error;
      checks[name]={result:'REJECTED_NOT_PROVED',reason:error.message}; }
  }
  return checks;
}

