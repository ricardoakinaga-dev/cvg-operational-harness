import json, os, pathlib, subprocess, sys, time
root = pathlib.Path(__file__).resolve().parents[1]
label, *cmd = sys.argv[1:]
env = dict(os.environ, TMPDIR=str(root/'tmp'), XDG_CACHE_HOME=str(root/'tool-cache'))
start = time.time()
result = subprocess.run(cmd, cwd=root/'candidate', env=env, capture_output=True)
(root/'evidence'/f'{label}.stdout').write_bytes(result.stdout)
(root/'evidence'/f'{label}.stderr').write_bytes(result.stderr)
record = dict(command=cmd,cwd=str(root/'candidate'),rawExit=result.returncode,seconds=round(time.time()-start,3),TMPDIR=env['TMPDIR'],XDG_CACHE_HOME=env['XDG_CACHE_HOME'])
(root/'evidence'/f'{label}-command.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
print(result.stdout.decode(errors='replace')[-3000:])
print(result.stderr.decode(errors='replace')[-1500:])
sys.exit(result.returncode)
