import * as fs from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { createHash } from 'node:crypto'
const [compiled, phase, volume, acceptance, mode] = process.argv.slice(2)
const { ShiftStore } = await import(pathToFileURL(join(compiled, 'store.js')).href)
const { ShiftAssistant } = await import(pathToFileURL(join(compiled, 'assistant.js')).href)
const digest = (bytes) => createHash('sha256').update(bytes).digest('hex')
const at = '2026-10-03T12:00:00.000Z', phone = '5511900000001'
let store
try { store = new ShiftStore(volume) } catch (error) {
  if (error?.message !== 'STORE_LOCKED') throw error
  console.log(JSON.stringify({sentinel:'R65_RESTART_DENIED',phase,diagnostic:'STORE_LOCKED',accepted:fs.readFileSync(acceptance,'utf8').trim().split('\n').length}))
  process.exit(0)
}
const initial = { storageAvailable:store.storageAvailable, effectsAllowed:store.effectsAllowed, diagnostic:store.diagnostic ?? null }
const accepted = () => fs.existsSync(acceptance) ? fs.readFileSync(acceptance,'utf8').trim().split('\n').filter(Boolean).length : 0
if (!store.storageAvailable) {
  store.close()
  console.log(JSON.stringify({sentinel:'R65_RESTART_DENIED',phase,...initial,accepted:accepted()}))
  process.exit(0)
}
const assistant = new ShiftAssistant({store, members:[{phone,name:'Synthetic',manager:true}], clock:()=>new Date(at),
  whatsapp:{provider:'waha',parseWebhook:()=>undefined,downloadMedia:async()=>{throw Error('NO_MEDIA')},sendText:async(recipient,text)=>{
    const receipt = {status:200,at,sha256:digest(text),providerId:'synthetic-'+(accepted()+1)}
    fs.appendFileSync(acceptance,JSON.stringify({recipient,receipt})+'\n')
    return {status:'provider_accepted',receipt}
  }},organizer:{organize:async()=>{throw Error('NO_MODEL')}},transcriber:{transcribe:async()=>{throw Error('NO_MODEL')}}})
const message={provider:'waha',messageId:'r65-synthetic-help',fromPhone:phone,kind:'text',text:'ajuda',receivedAt:at}
let boundary
if (phase === 'incident') {
  store.append({type:'paused',at,by:phone})
  store.append({type:'resumed',at,by:phone})
  const manifest=JSON.parse(fs.readFileSync(join(volume,'journal/manifest.json'),'utf8'))
  const segment=join(volume,manifest.segments.at(-1).path)
  boundary=fs.statSync(segment).size
  assistant.receive(message)
  await assistant.idle()
  if (accepted()!==1) throw Error('initial accepted receipt missing')
  const lock=join(volume,'store.lock'), lockBytes=fs.readFileSync(lock), lockInode=fs.statSync(lock).ino
  const fullSize=fs.statSync(segment).size
  fs.truncateSync(segment,mode==='zero'?0:boundary)
  const corrupt=fs.readFileSync(segment)
  const available=store.storageAvailable, effects=store.effectsAllowed, health=assistant.health()
  let rejected=false
  try { assistant.receive({...message,messageId:'r65-after-incident'}) } catch { rejected=true }
  await assistant.stop()
  store.close()
  store.close()
  const lockRetained=fs.existsSync(lock)
  console.log(JSON.stringify({sentinel:'R65_LIVE_INCIDENT',phase,mode,initial,boundary,fullSize,corruptSize:corrupt.length,corruptSha256:digest(corrupt),corruptUnchanged:fs.readFileSync(segment).equals(corrupt),storageAvailable:available,effectsAllowed:effects,health,rejected,accepted:accepted(),lockRetained,lockSha256:digest(lockBytes),lockExact:lockRetained&&fs.readFileSync(lock).equals(lockBytes)&&fs.statSync(lock).ino===lockInode}))
} else {
  assistant.receive(message)
  await assistant.idle()
  await assistant.stop()
  store.close()
  console.log(JSON.stringify({sentinel:'R65_RESTART_HEALTHY',phase,...initial,accepted:accepted(),lockReleased:!fs.existsSync(join(volume,'store.lock'))}))
}
