// @vitest-environment node
import * as fs from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { createServer, type Server } from 'node:http'
import type { AddressInfo } from 'node:net'
import { afterEach, expect, it } from 'vitest'
import { ShiftStore } from '../store.ts'
import { canonical, sha256 } from '../journal.ts'
import { ShiftAssistant } from '../assistant.ts'
import { WahaClient } from '../whatsapp.ts'
import { buildShiftServer } from '../server.ts'
import {
  backupStoppedVolume,
  restoreBackup
} from '../../scripts/backup-restore.mjs'
const AT = '2026-10-03T12:00:00.000Z',
  PHONE = '5511900000001'
const closers: Array<() => void | Promise<void>> = []
afterEach(async () => {
  for (const close of closers.splice(0).reverse()) await close()
})
function fixture(media = false) {
  const root = fs.mkdtempSync(join(tmpdir(), 'r38-retained-')),
    source = join(root, 'source')
  const store = new ShiftStore(source)
  const descriptor = media
    ? store.saveMediaDescriptor(
        Buffer.from('synthetic media'),
        'image/png',
        'm1'
      )
    : undefined
  store.commit({
    transitionId: 'input:m1',
    expected: { inbox: { m1: 0 } },
    changes: [
      {
        type: 'message_received',
        at: AT,
        message: {
          provider: 'waha',
          messageId: 'm1',
          fromPhone: PHONE,
          kind: media ? 'image' : 'text',
          text: 'ajuda',
          receivedAt: AT,
          ...(descriptor ? { mediaRef: descriptor.path } : {})
        }
      }
    ]
  })
  store.close()
  return {
    root,
    source,
    media: descriptor?.path,
    backup: join(root, 'backup'),
    target: join(root, 'target')
  }
}
function manifest(root: string) {
  return JSON.parse(
    fs.readFileSync(join(root, 'journal/manifest.json'), 'utf8')
  )
}
function active(root: string) {
  return join(root, manifest(root).segments.at(-1).path)
}
function files(root: string, relative = ''): Record<string, string> {
  const values: Record<string, string> = {}
  for (const name of fs.readdirSync(join(root, relative)).sort()) {
    const rel = relative ? relative + '/' + name : name
    if (rel === 'store.lock') continue
    if (fs.statSync(join(root, rel)).isDirectory())
      Object.assign(values, files(root, rel))
    else values[rel] = sha256(fs.readFileSync(join(root, rel)))
  }
  return values
}
function mutate(root: string, mode: string, media?: string) {
  const m = manifest(root)
  if (mode === 'revision') delete m.revision
  if (mode === 'prefix') m.segments[0].prefixSha256 = 'f'.repeat(64)
  if (mode === 'revision-file') {
    fs.unlinkSync(
      join(root, 'journal/manifests/revision-' + m.revision + '.json')
    )
    return
  }
  if (mode === 'revision' || mode === 'prefix') {
    const bytes = canonical(m) + '\n'
    fs.writeFileSync(join(root, 'journal/manifest.json'), bytes)
    fs.writeFileSync(join(root, 'journal/manifests/revision-1.json'), bytes)
  } else if (mode === 'unknown' || mode === 'reference') {
    const record = JSON.parse(fs.readFileSync(active(root), 'utf8'))
    record.changes = [
      {
        type: mode === 'unknown' ? 'unrecognized_event' : 'task_done',
        at: AT,
        ...(mode === 'reference' ? { number: 1 } : {})
      }
    ]
    const { sha256: _checksum, ...body } = record
    void _checksum
    record.sha256 = sha256(canonical(body))
    fs.writeFileSync(active(root), canonical(record) + '\n')
  } else if (mode === 'media') fs.unlinkSync(join(root, media!))
  else if (mode === 'media-sidecar')
    fs.writeFileSync(join(root, media! + '.json'), '{}')
  else if (mode === 'tail') fs.appendFileSync(active(root), '{"partial":')
}
const modes = [
  'revision',
  'prefix',
  'unknown',
  'media',
  'revision-file',
  'reference',
  'media-sidecar'
]
it.each(modes)(
  'refuses offline backup and independently forged hash-consistent restore: %s',
  (mode) => {
    const f = fixture(mode.startsWith('media'))
    backupStoppedVolume(f.source, f.backup)
    mutate(f.source, mode, f.media)
    const docs = join(f.backup, 'documents')
    mutate(docs, mode, f.media)
    const receipt = JSON.parse(
      fs.readFileSync(join(f.backup, 'manifest.json'), 'utf8')
    )
    const hashes = files(docs)
    receipt.documents = receipt.documents
      .filter((d: { path: string }) => d.path in hashes)
      .map((d: { path: string }) => ({
        path: d.path,
        bytes: fs.statSync(join(docs, d.path)).size,
        sha256: hashes[d.path]
      }))
    if (mode === 'revision') delete receipt.journal.manifestRevision
    if (mode === 'unknown' || mode === 'reference') {
      const bytes = fs.readFileSync(active(docs))
      receipt.journal.headSha256 = JSON.parse(bytes.toString()).sha256
      receipt.journal.prefixes[0] = {
        path: manifest(docs).segments[0].path,
        bytes: bytes.length,
        sha256: sha256(bytes)
      }
    }
    fs.writeFileSync(join(f.backup, 'manifest.json'), JSON.stringify(receipt))
    const before = files(f.source),
      copiedBefore = files(docs)
    const runtime = new ShiftStore(f.source)
    const runtimeAvailable = runtime.storageAvailable
    runtime.close()
    let backupAccepted = false,
      restoreAccepted = false
    try {
      backupStoppedVolume(f.source, join(f.root, 'bad-backup'))
      backupAccepted = true
    } catch {
      /* expected refusal */
    }
    try {
      restoreBackup(f.backup, f.target)
      restoreAccepted = true
    } catch {
      /* expected refusal */
    }
    console.info('R38_OFFLINE', {
      mode,
      root: f.root,
      runtimeAvailable,
      backupAccepted,
      restoreAccepted
    })
    expect(files(f.source)).toEqual(before)
    expect(files(docs)).toEqual(copiedBefore)
    expect(runtimeAvailable).toBe(false)
    expect(backupAccepted).toBe(false)
    expect(restoreAccepted).toBe(false)
    expect(fs.existsSync(f.target)).toBe(false)
  }
)
async function bind(server: Server) {
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve))
  closers.push(() => {
    server.closeAllConnections()
    return new Promise<void>((resolve) => server.close(() => resolve()))
  })
  return 'http://127.0.0.1:' + (server.address() as AddressInfo).port
}
it.each([
  'byte',
  'truncate',
  'replace',
  'manifest',
  'revision-file',
  'media',
  'media-sidecar',
  'utimes'
])(
  'denies live ingress/readiness/effects and preserves corrupted bytes: %s',
  async (mode) => {
    const f = fixture(mode.startsWith('media')),
      store = new ShiftStore(f.source)
    closers.push(() => store.close())
    let sends = 0
    const receiver = createServer((req, res) => {
      req.resume()
      if (req.url === '/api/sendText') sends++
      res.setHeader('content-type', 'application/json')
      res.end('{"id":"synthetic-accepted"}')
    })
    const client = new WahaClient({
      baseUrl: await bind(receiver),
      apiKey: 'synthetic',
      session: 'r38',
      fetch
    })
    const assistant = new ShiftAssistant({
      store,
      members: [{ phone: PHONE, name: 'Synthetic', manager: true }],
      whatsapp: client,
      organizer: {
        async organize() {
          throw new Error('NO_MODEL')
        }
      },
      transcriber: {
        async transcribe() {
          throw new Error('NO_MODEL')
        }
      }
    })
    closers.push(() => assistant.stop())
    const server = buildShiftServer({
        store,
        assistant,
        whatsapp: client,
        webhookSecret: 'r38-synthetic-secret'
      }),
      url = await bind(server)
    expect((await fetch(url + '/health/ready')).status).toBe(200)
    const segment = active(f.source),
      original = fs.readFileSync(segment),
      originalStat = fs.statSync(segment)
    if (mode === 'byte' || mode === 'utimes') {
      const fd = fs.openSync(segment, 'r+')
      fs.writeSync(fd, Buffer.from('!'), 0, 1, 0)
      fs.closeSync(fd)
    }
    if (mode === 'utimes')
      fs.utimesSync(segment, originalStat.atime, originalStat.mtime)
    if (mode.startsWith('media')) mutate(f.source, mode, f.media)
    if (mode === 'truncate') fs.truncateSync(segment, original.length - 1)
    if (mode === 'replace') {
      fs.renameSync(segment, segment + '.retained')
      fs.writeFileSync(segment, original)
    }
    if (mode === 'manifest')
      fs.appendFileSync(join(f.source, 'journal/manifest.json'), ' ')
    if (mode === 'revision-file') mutate(f.source, mode)
    const before = files(f.source)
    const response = await fetch(url + '/webhooks/waha', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-cvg-webhook-secret': 'r38-synthetic-secret'
      },
      body: JSON.stringify({
        event: 'message',
        session: 'r38',
        payload: { id: 'after-corrupt', from: PHONE + '@c.us', body: 'ajuda' }
      })
    })
    await assistant.idle()
    const ready = await fetch(url + '/health/ready')
    console.info('R38_LIVE', {
      mode,
      root: f.root,
      ingress: response.status,
      readiness: ready.status,
      sends,
      bytesPreserved: canonical(files(f.source)) === canonical(before)
    })
    expect(response.status).toBe(503)
    expect(ready.status).toBe(503)
    expect(sends).toBe(0)
    expect(store.effectsAllowed).toBe(false)
    expect(files(f.source)).toEqual(before)
  }
)
it('healthy backup/restore preserves exact bytes and reopens under hold; unrecovered tail is refused without rewriting it', () => {
  const f = fixture(true),
    before = files(f.source)
  expect(backupStoppedVolume(f.source, f.backup).status).toBe('backup_verified')
  expect(restoreBackup(f.backup, f.target).status).toBe('restored_under_hold')
  expect(files(f.source)).toEqual(before)
  const reopened = new ShiftStore(f.target)
  try {
    expect(reopened.storageAvailable).toBe(true)
    expect(reopened.effectsAllowed).toBe(false)
  } finally {
    reopened.close()
  }
  mutate(f.source, 'tail')
  const corrupt = files(f.source)
  expect(() =>
    backupStoppedVolume(f.source, join(f.root, 'tail-backup'))
  ).toThrow()
  expect(files(f.source)).toEqual(corrupt)
})

it('checks readiness before ingress and keeps failure sticky after byte restoration', async () => {
  const f = fixture(),
    store = new ShiftStore(f.source)
  closers.push(() => store.close())
  const original = fs.readFileSync(active(f.source)),
    fd = fs.openSync(active(f.source), 'r+')
  fs.writeSync(fd, Buffer.from('!'), 0, 1, 0)
  fs.closeSync(fd)
  expect(store.storageAvailable).toBe(false)
  fs.writeFileSync(active(f.source), original)
  expect(store.storageAvailable).toBe(false)
  expect(() => store.append({ type: 'paused', at: AT, by: PHONE })).toThrow(
    'STORAGE_UNAVAILABLE'
  )
  expect(fs.readFileSync(active(f.source))).toEqual(original)
})

it.each(['after_journal_lf', 'after_journal_sync'])(
  'does not bless corruption in the %s checkpoint as an owned write',
  (point) => {
    const f = fixture()
    let armed = false
    const store = new ShiftStore(f.source, {
      io: {
        checkpoint(name) {
          if (armed && name === point) {
            const fd = fs.openSync(active(f.source), 'r+')
            fs.writeSync(fd, Buffer.from('!'), 0, 1, 0)
            fs.closeSync(fd)
          }
        }
      }
    })
    closers.push(() => store.close())
    armed = true
    expect(() => store.append({ type: 'paused', at: AT, by: PHONE })).toThrow(
      'STORAGE_UNAVAILABLE'
    )
    expect(store.storageAvailable).toBe(false)
    expect(store.effectsAllowed).toBe(false)
    expect(fs.readFileSync(active(f.source))[0]).toBe(33)
  }
)

it('validates offline without lock, chmod, fsync, recovery or document modification', () => {
  const f = fixture(true)
  fs.chmodSync(active(f.source), 0o640)
  const before = files(f.source),
    stat = fs.statSync(active(f.source), { bigint: true })
  const result = ShiftStore.validateStoppedVolume(f.source)
  const after = fs.statSync(active(f.source), { bigint: true })
  expect(result.sequence).toBe(1)
  expect(files(f.source)).toEqual(before)
  expect([after.mode, after.mtimeNs, after.ctimeNs, after.ino]).toEqual([
    stat.mode,
    stat.mtimeNs,
    stat.ctimeNs,
    stat.ino
  ])
  expect(fs.existsSync(join(f.source, 'store.lock'))).toBe(false)
  mutate(f.source, 'tail')
  const damaged = files(f.source)
  expect(() => ShiftStore.validateStoppedVolume(f.source)).toThrow(
    'STORAGE_UNAVAILABLE'
  )
  expect(files(f.source)).toEqual(damaged)
  expect(fs.readdirSync(join(f.source, 'recovery'))).toEqual([])
})

// R53: additive legacy-media regression suite; the original R38 tests above are unchanged.
import { describe } from 'vitest'
import { Journal } from '../journal.ts'
import { replayLegacy } from '../migrate-journal.ts'
import type { ShiftEvent } from '../domain.ts'

{
  const AT = '2026-10-05T12:00:00.000Z'
  const PHONE = '5511900000001'
  const BYTES = Buffer.from('R53_SYNTHETIC_AUDIO_IMAGE_BYTES')
  const kinds = ['local', 'note', 'inline'] as const
  type Kind = (typeof kinds)[number]
  function seed(kind: Kind) {
    const root = fs.mkdtempSync(join(tmpdir(), 'r53-legacy-'))
    const source = join(root, 'source')
    fs.mkdirSync(join(source, 'media'), { recursive: true })
    const message = {
      provider: 'waha' as const,
      messageId: 'm1',
      fromPhone: PHONE,
      kind: kind === 'local' ? ('image' as const) : ('audio' as const),
      text: 'R53 synthetic original',
      receivedAt: AT
    }
    let local = ''
    if (kind === 'local') {
      const donor = new ShiftStore(join(root, 'donor'))
      const descriptor = donor.saveMediaDescriptor(
        BYTES,
        'image/png',
        'R53-local'
      )
      donor.close()
      local = descriptor.path
      for (const suffix of ['', '.json'])
        fs.copyFileSync(
          join(root, 'donor', local + suffix),
          join(source, local + suffix)
        )
    }
    if (kind === 'note')
      fs.writeFileSync(join(source, 'media/original.ogg'), BYTES)
    const events: ShiftEvent[] = [
      {
        type: 'message_received',
        at: AT,
        message: {
          ...message,
          ...(kind === 'local'
            ? { mediaRef: local, mimetype: 'image/png' }
            : {}),
          ...(kind === 'inline'
            ? {
                mediaRef: 'base64:' + BYTES.toString('base64'),
                mimetype: 'audio/ogg'
              }
            : {})
        }
      },
      {
        type: 'note_created',
        at: AT,
        note: {
          id: 'n1',
          messageId: 'm1',
          authorPhone: PHONE,
          createdAt: AT,
          kind: message.kind,
          rawText: message.text,
          unverifiedNumbers: [],
          confirmed: true,
          ...(kind === 'note' ? { mediaFile: 'original.ogg' } : {})
        }
      },
      // Historical processed IDs need not be known: retain existing base replay semantics.
      { type: 'message_processed', at: AT, messageId: 'historic-unknown' },
      { type: 'message_processed', at: AT, messageId: 'm1' }
    ]
    fs.writeFileSync(
      join(source, 'events.jsonl'),
      events.map((e) => JSON.stringify(e) + '\n').join('')
    )
    return { root, source, local, events }
  }
  function migrated(kind: Kind) {
    const f = seed(kind)
    const store = new ShiftStore(f.source, { legacySession: 'R53-synthetic' })
    expect(store.storageAvailable, store.diagnostic).toBe(true)
    const path =
      kind === 'local' ? f.local : store.migration!.mediaMappings[0]!.path
    const migration = store.migration!
    store.close()
    return { ...f, path, migration }
  }
  function contents(root: string, relative = ''): Record<string, string> {
    const result: Record<string, string> = {}
    for (const name of fs.readdirSync(join(root, relative)).sort()) {
      const rel = relative ? relative + '/' + name : name
      if (rel === 'store.lock') continue
      const file = join(root, rel),
        stat = fs.lstatSync(file)
      if (stat.isDirectory()) Object.assign(result, contents(root, rel))
      else
        result[rel] = stat.isSymbolicLink()
          ? 'link:' + fs.readlinkSync(file)
          : sha256(fs.readFileSync(file))
    }
    return result
  }
  const modes = [
    'absent',
    'same-size-bytes',
    'sidecar-missing',
    'sidecar-path',
    'sidecar-size',
    'sidecar-hash',
    'symlink',
    'hardlink'
  ] as const
  function corrupt(source: string, path: string, mode: (typeof modes)[number]) {
    const file = join(source, path)
    if (mode === 'absent') fs.unlinkSync(file)
    else if (mode === 'same-size-bytes')
      fs.writeFileSync(file, Buffer.alloc(BYTES.length, 88))
    else if (mode === 'sidecar-missing') fs.unlinkSync(file + '.json')
    else if (mode === 'symlink' || mode === 'hardlink') {
      const retained = join(source, 'retained-media')
      fs.renameSync(file, retained)
      if (mode === 'symlink') fs.symlinkSync(retained, file)
      else fs.linkSync(retained, file)
    } else {
      const descriptor = JSON.parse(fs.readFileSync(file + '.json', 'utf8'))
      if (mode === 'sidecar-path') descriptor.path = 'media/wrong.ogg'
      if (mode === 'sidecar-size') descriptor.bytes += 1
      if (mode === 'sidecar-hash') descriptor.sha256 = 'f'.repeat(64)
      fs.writeFileSync(file + '.json', JSON.stringify(descriptor))
    }
  }
  describe('R53 legacy primary media integrity', () => {
    it.each(kinds)(
      'preserves genuine migrated %s bytes, identity, hold and historical processed semantics',
      (kind) => {
        const f = migrated(kind)
        const before = contents(f.source)
        const identity = ShiftStore.validateStoppedVolume(f.source)
        for (let i = 0; i < 2; i++) {
          const s = new ShiftStore(f.source)
          try {
            expect(s.storageAvailable, s.diagnostic).toBe(true)
            expect(s.operationalHold).toBe(true)
            expect(s.effectsAllowed).toBe(false)
            expect(Buffer.from(s.readMedia(f.path).bytes)).toEqual(BYTES)
            expect(s.note('n1')?.confirmed).toBe(true)
            if (kind === 'note')
              expect(s.note('n1')?.mediaFile).toBe(f.path.slice(6))
            expect(s.migration).toEqual(f.migration)
          } finally {
            s.close()
          }
          expect(ShiftStore.validateStoppedVolume(f.source)).toEqual(identity)
          expect(contents(f.source)).toEqual(before)
        }
        if (kind === 'local')
          expect(
            fs.readFileSync(join(f.source, f.migration.backupPath, f.path))
          ).toEqual(BYTES)
        if (kind === 'note')
          expect(fs.readFileSync(join(f.source, 'media/original.ogg'))).toEqual(
            BYTES
          )
      }
    )
    for (const kind of kinds)
      it.each(modes)(
        'rejects ' +
          kind +
          ' %s without altering documents or adopting recovery media',
        (mode) => {
          const f = migrated(kind)
          corrupt(f.source, f.path, mode)
          const before = contents(f.source)
          expect(() => ShiftStore.validateStoppedVolume(f.source)).toThrow()
          expect(contents(f.source)).toEqual(before)
          const s = new ShiftStore(f.source)
          try {
            expect(s.storageAvailable).toBe(false)
            // Alias refusal precedes loading any migration metadata in the existing
            // constructor. Storage/effects must close even without that projection.
            if (mode !== 'symlink' && mode !== 'hardlink')
              expect(s.operationalHold).toBe(true)
            expect(s.effectsAllowed).toBe(false)
          } finally {
            s.close()
          }
          expect(contents(f.source)).toEqual(before)
          if (mode === 'absent')
            expect(fs.existsSync(join(f.source, f.path))).toBe(false)
        }
      )
    it('direct legacy replay refuses absent local primary before applying the message', () => {
      const f = migrated('local')
      fs.unlinkSync(join(f.source, f.path))
      const journal = new Journal(f.source, {}, true)
      const applied: ShiftEvent[] = []
      try {
        expect(() =>
          replayLegacy(journal, (event) => applied.push(event))
        ).toThrow()
        expect(applied).toEqual([])
      } finally {
        journal.close()
      }
    })
    it.each(kinds)(
      'validates final %s media during first migration before appending its receipt',
      (kind) => {
        const f = seed(kind)
        const s = new ShiftStore(f.source, {
          legacySession: 'R53-synthetic',
          io: {
            checkpoint(point) {
              if (point === 'after_manifest_rename') {
                const target =
                  kind === 'local'
                    ? f.local
                    : fs
                        .readdirSync(join(f.source, 'media'))
                        .find((name) => name.endsWith('.json'))!
                        .slice(0, -5)
                fs.unlinkSync(
                  join(f.source, kind === 'local' ? target : 'media/' + target)
                )
              }
            }
          }
        })
        try {
          expect(s.storageAvailable).toBe(false)
          const manifest = JSON.parse(
            fs.readFileSync(join(f.source, 'journal/manifest.json'), 'utf8')
          )
          expect(
            fs.readFileSync(join(f.source, manifest.segments[0].path), 'utf8')
          ).toBe('')
          expect(fs.readFileSync(join(f.source, 'events.jsonl'), 'utf8')).toBe(
            f.events.map((e) => JSON.stringify(e) + '\n').join('')
          )
        } finally {
          s.close()
        }
      }
    )
    it.each(kinds)(
      'observes %s legacy media for live health/effects refusal after corruption',
      (kind) => {
        const f = migrated(kind)
        const s = new ShiftStore(f.source)
        try {
          expect(s.storageAvailable).toBe(true)
          fs.writeFileSync(
            join(f.source, f.path),
            Buffer.alloc(BYTES.length, 88)
          )
          expect(s.storageAvailable).toBe(false)
          expect(s.effectsAllowed).toBe(false)
        } finally {
          s.close()
        }
      }
    )
    it.each([false, true])(
      'validates retained mapping targets after a historical note overwrite, missing=%s',
      (missing) => {
        const f = seed('note')
        // The existing V1 projection permits a later note with the same ID. Its
        // mapping remains a retained document even when the final note has no ref.
        const created = f.events.find((e) => e.type === 'note_created')!
        if (created.type !== 'note_created')
          throw new Error('fixture note required')
        const note = { ...created.note }
        delete note.mediaFile
        fs.appendFileSync(
          join(f.source, 'events.jsonl'),
          JSON.stringify({ type: 'note_created', at: AT, note }) + '\n'
        )
        const s = new ShiftStore(f.source, {
          legacySession: 'R53-synthetic',
          io: {
            checkpoint(point) {
              if (missing && point === 'after_manifest_rename') {
                const name = fs
                  .readdirSync(join(f.source, 'media'))
                  .find((n) => n.endsWith('.json'))!
                fs.unlinkSync(join(f.source, 'media', name.slice(0, -5)))
              }
            }
          }
        })
        try {
          expect(s.storageAvailable).toBe(!missing)
          expect(s.migration!.mediaMappings).toHaveLength(1)
          expect(s.note('n1')?.mediaFile).toBeUndefined()
          expect(s.operationalHold).toBe(true)
          expect(s.effectsAllowed).toBe(false)
        } finally {
          s.close()
        }
      }
    )
    it('preserves remote media references and unknown historical processed events', () => {
      const f = seed('inline')
      const message = f.events[0]!
      if (message.type !== 'message_received')
        throw new Error('fixture message required')
      message.message.mediaRef = 'https://synthetic.invalid/original-audio'
      fs.writeFileSync(
        join(f.source, 'events.jsonl'),
        f.events.map((e) => JSON.stringify(e) + '\n').join('')
      )
      const s = new ShiftStore(f.source, { legacySession: 'R53-synthetic' })
      expect(s.storageAvailable).toBe(true)
      expect(s.migration!.mediaMappings).toEqual([])
      s.close()
      expect(() => ShiftStore.validateStoppedVolume(f.source)).not.toThrow()
    })
  })
}

// R63 additive retained-original inventory regressions.
{
  function retainedFixture() {
    const root = fs.mkdtempSync(join(tmpdir(), 'r63-retained-'))
    const source = join(root, 'source')
    fs.mkdirSync(join(source, 'media'), { recursive: true })
    fs.writeFileSync(
      join(source, 'media/original.ogg'),
      Buffer.from('R63 synthetic retained bytes')
    )
    const at = '2026-10-05T00:00:00Z'
    fs.writeFileSync(
      join(source, 'events.jsonl'),
      JSON.stringify({
        type: 'note_created',
        at,
        note: {
          id: 'n1',
          messageId: 'm1',
          authorPhone: '00000000001',
          createdAt: at,
          kind: 'audio',
          rawText: 'R63 synthetic',
          unverifiedNumbers: [],
          confirmed: true,
          mediaFile: 'original.ogg'
        }
      }) + '\n'
    )
    const s = new ShiftStore(source, { legacySession: 'R63' })
    expect(s.storageAvailable, s.diagnostic).toBe(true)
    const migration = s.migration!
    s.close()
    return { root, source, migration }
  }
  for (const relative of [
    'events.jsonl',
    'media/original.ogg',
    'inventory.json'
  ])
    for (const attack of ['missing', 'tampered'])
      it(
        'R63 refuses retained ' +
          relative +
          ' ' +
          attack +
          ' before offline/runtime success',
        () => {
          const f = retainedFixture()
          const file = join(f.source, f.migration.backupPath, relative)
          if (attack === 'missing') fs.unlinkSync(file)
          else {
            const bytes = fs.readFileSync(file)
            bytes[0] = bytes[0]! ^ 1
            fs.writeFileSync(file, bytes)
          }
          const before = files(f.source)
          expect(() => ShiftStore.validateStoppedVolume(f.source)).toThrow()
          expect(files(f.source)).toEqual(before)
          const s = new ShiftStore(f.source)
          try {
            expect(s.storageAvailable).toBe(false)
            expect(s.effectsAllowed).toBe(false)
            expect(s.operationalHold).toBe(true)
          } finally {
            s.close()
          }
          expect(files(f.source)).toEqual(before)
        }
      )
  it('R63 preserves valid retained originals and offline identity across restart', () => {
    const f = retainedFixture(),
      before = files(f.source)
    const identity = ShiftStore.validateStoppedVolume(f.source)
    const s = new ShiftStore(f.source)
    try {
      expect(s.storageAvailable, s.diagnostic).toBe(true)
      expect(s.operationalHold).toBe(true)
    } finally {
      s.close()
    }
    expect(ShiftStore.validateStoppedVolume(f.source)).toEqual(identity)
    expect(files(f.source)).toEqual(before)
  })
  for (const relative of [
    'events.jsonl',
    'media/original.ogg',
    'inventory.json'
  ])
    it(
      'R63 detects live retained ' + relative + ' corruption before effects',
      () => {
        const f = retainedFixture(),
          s = new ShiftStore(f.source)
        try {
          expect(s.storageAvailable).toBe(true)
          const file = join(f.source, f.migration.backupPath, relative)
          const bytes = fs.readFileSync(file)
          bytes[0] = bytes[0]! ^ 1
          fs.writeFileSync(file, bytes)
          expect(s.storageAvailable).toBe(false)
          expect(s.effectsAllowed).toBe(false)
        } finally {
          s.close()
        }
      }
    )
}

// R65 additions: retain the existing writer fence after an observed live incident.
import { spawnSync as r65SpawnSync } from 'node:child_process'
import { fileURLToPath as r65FileURLToPath } from 'node:url'
import { buildSync as r65BuildSync } from 'esbuild'
import { Journal as R65Journal } from '../journal.ts'
let r65Compiled: { artifact: string; driver: string } | undefined
function r65Artifact() {
  if (r65Compiled) return r65Compiled
  const root = fs.mkdtempSync(join(tmpdir(), 'r65-compiled-'))
  const artifact = join(root, 'public-test-api.mjs'),
    driver = join(root, 'driver.mjs')
  r65BuildSync({
    stdin: {
      contents:
        'export {ShiftStore} from "./store.ts"; export {ShiftAssistant} from "./assistant.ts";',
      resolveDir: r65FileURLToPath(new URL('../', import.meta.url)),
      sourcefile: 'r65-public-test-api.ts',
      loader: 'ts'
    },
    bundle: true,
    platform: 'node',
    target: 'node22',
    format: 'esm',
    outfile: artifact
  })
  fs.writeFileSync(driver, r65Driver)
  return (r65Compiled = { artifact, driver })
}
function r65Child(phase: string, root: string, mode: string) {
  const { artifact, driver } = r65Artifact()
  const child = r65SpawnSync(
    process.execPath,
    [
      driver,
      artifact,
      phase,
      join(root, 'volume'),
      join(root, 'accepted.jsonl'),
      mode
    ],
    { encoding: 'utf8', timeout: 15000 }
  )
  expect(child.error, child.stderr).toBeUndefined()
  expect(child.signal, child.stderr).toBeNull()
  expect(child.status, child.stderr).toBe(0)
  return JSON.parse(child.stdout.trim()) as Record<string, unknown>
}
function r65Physical(
  root: string,
  relative = '',
  deniedRestart = false
): Record<string, string> {
  const values: Record<string, string> = {},
    path = join(root, relative)
  const stat = fs.lstatSync(path, { bigint: true })
  values[relative || '.'] = [
    stat.dev,
    stat.ino,
    stat.mode,
    stat.size,
    stat.mtimeNs,
    // Existing writer construction chmods the root before its exclusive lock
    // attempt. A denied restart may change only that directory's ctime.
    deniedRestart && relative === '' ? 'root-ctime' : stat.ctimeNs,
    stat.isFile() ? sha256(fs.readFileSync(path)) : 'directory'
  ].join(':')
  if (stat.isDirectory())
    for (const name of fs.readdirSync(path).sort())
      Object.assign(
        values,
        r65Physical(
          root,
          relative ? relative + '/' + name : name,
          deniedRestart
        )
      )
  return values
}
for (const mode of ['zero', 'prefix'])
  it(
    'R65 process restart retains an exact owned incident fence after ' +
      mode +
      ' truncation',
    () => {
      const root = fs.mkdtempSync(join(tmpdir(), 'r65-process-'))
      const live = r65Child('incident', root, mode)
      expect(live).toMatchObject({
        sentinel: 'R65_LIVE_INCIDENT',
        accepted: 1,
        storageAvailable: false,
        effectsAllowed: false,
        rejected: true,
        corruptUnchanged: true,
        lockRetained: true,
        lockExact: true,
        health: {
          ready: false,
          effectsEnabled: false,
          reasonCodes: ['storage_unavailable']
        }
      })
      expect(live.boundary).toBeGreaterThan(0)
      expect(live.fullSize).toBeGreaterThan(live.boundary as number)
      const source = join(root, 'volume'),
        segment = fs.readFileSync(active(source))
      if (mode === 'zero') expect(segment.length).toBe(0)
      else {
        expect(segment.length).toBe(live.boundary)
        const lines = segment
          .toString()
          .trim()
          .split('\n')
          .map((line) => JSON.parse(line))
        expect(lines.map((line) => line.seq)).toEqual([1, 2])
        expect(lines.map((line) => line.changes[0].type)).toEqual([
          'paused',
          'resumed'
        ])
      }
      const before = r65Physical(source, '', true)
      for (let attempt = 0; attempt < 2; attempt++) {
        expect(r65Child('restart', root, mode)).toMatchObject({
          sentinel: 'R65_RESTART_DENIED',
          diagnostic: 'STORE_LOCKED',
          accepted: 1
        })
        expect(r65Physical(source, '', true)).toEqual(before)
      }
    }
  )
for (const kind of ['manifest', 'segment'])
  it(
    'R65 live ' +
      kind +
      ' metadata failure keeps the fence and corrupt bytes across close',
    () => {
      const f = fixture(),
        store = new ShiftStore(f.source),
        lock = join(f.source, 'store.lock')
      closers.push(() => store.close())
      const owned = fs.readFileSync(lock),
        inode = fs.statSync(lock).ino
      const path =
        kind === 'manifest'
          ? join(f.source, 'journal/manifest.json')
          : active(f.source)
      fs.chmodSync(path, 0o640)
      const before = r65Physical(f.source)
      expect(store.storageAvailable).toBe(false)
      expect(store.effectsAllowed).toBe(false)
      expect(() => store.append({ type: 'paused', at: AT, by: PHONE })).toThrow(
        'STORAGE_UNAVAILABLE'
      )
      store.close()
      expect(fs.readFileSync(lock)).toEqual(owned)
      expect(fs.statSync(lock).ino).toBe(inode)
      expect(r65Physical(f.source)).toEqual(before)
      const beforeRestart = r65Physical(f.source, '', true)
      expect(() => new ShiftStore(f.source)).toThrow('STORE_LOCKED')
      expect(r65Physical(f.source, '', true)).toEqual(beforeRestart)
    }
  )
for (const foreign of [false, true])
  it(
    'R65 readonly live failure writes no fence and preserves foreign lock=' +
      foreign,
    () => {
      const f = fixture(),
        lock = join(f.source, 'store.lock')
      if (foreign)
        fs.writeFileSync(
          lock,
          canonical({ instanceId: 'foreign', pid: 1, bootId: 'synthetic' }) +
            '\n',
          { mode: 0o600 }
        )
      const reader = new R65Journal(f.source, {}, true)
      closers.push(() => reader.close())
      expect(reader.available).toBe(true)
      reader.armIntegrity()
      fs.truncateSync(active(f.source), 0)
      const before = r65Physical(f.source)
      expect(reader.available).toBe(false)
      expect(() => reader.holdBudget(AT)).toThrow('STORAGE_UNAVAILABLE')
      reader.close()
      reader.close()
      expect(r65Physical(f.source)).toEqual(before)
      expect(fs.existsSync(lock)).toBe(foreign)
      expect(fs.existsSync(join(f.source, 'budget-hold.json'))).toBe(false)
    }
  )
it('R65 writer never overwrites or unlinks a replacement foreign lock on an incident close', () => {
  const f = fixture(),
    store = new ShiftStore(f.source),
    lock = join(f.source, 'store.lock')
  closers.push(() => store.close())
  const owned = fs.readFileSync(lock),
    detached = join(f.root, 'detached-owned-lock')
  fs.renameSync(lock, detached)
  const foreign = Buffer.from(
    canonical({ instanceId: 'foreign', pid: 1, bootId: 'synthetic' }) + '\n'
  )
  fs.writeFileSync(lock, foreign, { mode: 0o600 })
  const before = r65Physical(f.source)
  expect(store.storageAvailable).toBe(false)
  store.close()
  expect(r65Physical(f.source)).toEqual(before)
  expect(fs.readFileSync(lock)).toEqual(foreign)
  expect(fs.readFileSync(detached)).toEqual(owned)
  expect(() => new ShiftStore(f.source)).toThrow('STORE_LOCKED')
})
it('R65 ordinary double close releases the lock and clean process restart deduplicates accepted sends', () => {
  const root = fs.mkdtempSync(join(tmpdir(), 'r65-clean-'))
  const first = r65Child('restart', root, 'clean')
  expect(first).toMatchObject({
    sentinel: 'R65_RESTART_HEALTHY',
    storageAvailable: true,
    effectsAllowed: true,
    accepted: 1,
    lockReleased: true
  })
  expect(r65Child('restart', root, 'clean')).toMatchObject({
    sentinel: 'R65_RESTART_HEALTHY',
    storageAvailable: true,
    effectsAllowed: true,
    accepted: 1,
    lockReleased: true
  })
  const source = join(root, 'volume'),
    store = new ShiftStore(source)
  store.close()
  store.close()
  expect(fs.existsSync(join(source, 'store.lock'))).toBe(false)
})
it('R65 successful budget hold remains durable while ordinary close releases the lock', () => {
  const f = fixture(),
    store = new ShiftStore(f.source)
  closers.push(() => store.close())
  store.holdBudget(AT)
  const hold = fs.readFileSync(join(f.source, 'budget-hold.json'))
  expect(store.storageAvailable).toBe(true)
  expect(store.effectsAllowed).toBe(false)
  store.close()
  expect(fs.existsSync(join(f.source, 'store.lock'))).toBe(false)
  const restarted = new ShiftStore(f.source)
  closers.push(() => restarted.close())
  expect(restarted.storageAvailable).toBe(true)
  expect(restarted.operationalHold).toBe(true)
  expect(restarted.effectsAllowed).toBe(false)
  restarted.close()
  expect(fs.readFileSync(join(f.source, 'budget-hold.json'))).toEqual(hold)
  expect(fs.existsSync(join(f.source, 'store.lock'))).toBe(false)
})
it('R65 existing budget marker fsync failure retains its exact owned fallback fence', () => {
  const f = fixture()
  let armed = false
  const store = new ShiftStore(f.source, {
    io: {
      sync(fd) {
        if (armed) throw Error('synthetic budget fsync failure')
        fs.fsyncSync(fd)
      }
    }
  })
  closers.push(() => store.close())
  const lock = join(f.source, 'store.lock'),
    owned = fs.readFileSync(lock)
  armed = true
  expect(() => store.holdBudget(AT)).toThrow('STORAGE_UNAVAILABLE')
  expect(store.storageAvailable).toBe(false)
  expect(store.effectsAllowed).toBe(false)
  const before = r65Physical(f.source)
  store.close()
  expect(fs.readFileSync(lock)).toEqual(owned)
  expect(r65Physical(f.source)).toEqual(before)
  expect(() => new ShiftStore(f.source)).toThrow('STORE_LOCKED')
})
it('R65 duplicate and known transition/conflict exceptions remain nonfatal and close normally', () => {
  const f = fixture(),
    store = new ShiftStore(f.source)
  closers.push(() => store.close())
  const request = {
    transitionId: 'r65-control',
    expected: { operation: { state: store.revision('operation', 'state') } },
    changes: [{ type: 'paused' as const, at: AT, by: PHONE }]
  }
  const result = store.commit(request)
  expect(store.commit(request)).toEqual(result)
  expect(() =>
    store.commit({
      ...request,
      changes: [{ type: 'resumed', at: AT, by: PHONE }]
    })
  ).toThrow('IDEMPOTENCY_CONFLICT')
  expect(() =>
    store.commit({
      ...request,
      transitionId: 'r65-stale',
      expected: { inbox: { m1: 999 } }
    })
  ).toThrow('STATE_CONFLICT')
  expect(() =>
    store.commit({ ...request, transitionId: '', changes: [] })
  ).toThrow('INVALID_TRANSITION')
  expect(store.storageAvailable).toBe(true)
  store.close()
  expect(fs.existsSync(join(f.source, 'store.lock'))).toBe(false)
  const reopened = new ShiftStore(f.source)
  closers.push(() => reopened.close())
  expect(reopened.storageAvailable).toBe(true)
  expect(reopened.commit(request)).toEqual(result)
})
const r65Driver = String.raw`import * as fs from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { createHash } from 'node:crypto'
const [compiled, phase, volume, acceptance, mode] = process.argv.slice(2)
const { ShiftStore } = await import(pathToFileURL(compiled).href)
const { ShiftAssistant } = await import(pathToFileURL(compiled).href)
const digest = (bytes) => createHash('sha256').update(bytes).digest('hex')
const at = '2026-10-03T12:00:00.000Z', phone = '5511900000001'
let store
try { store = new ShiftStore(volume) } catch (error) {
  if (error?.message !== 'STORE_LOCKED') throw error
  console.log(JSON.stringify({sentinel:'R65_RESTART_DENIED',phase,diagnostic:'STORE_LOCKED',accepted:fs.readFileSync(acceptance,'utf8').trim().split('\n').length}))
  process.exit(0)
}
const initial = { storageAvailable:store.storageAvailable, effectsAllowed:store.effectsAllowed, diagnostic:store.diagnostic ?? null }
const accepted = () => fs.existsSync(acceptance) ? fs.readFileSync(acceptance,'utf8').trim().split('\n').filter(Boolean).length : 0
if (!store.storageAvailable) {
  store.close()
  console.log(JSON.stringify({sentinel:'R65_RESTART_DENIED',phase,...initial,accepted:accepted()}))
  process.exit(0)
}
const assistant = new ShiftAssistant({store, members:[{phone,name:'Synthetic',manager:true}], clock:()=>new Date(at),
  whatsapp:{provider:'waha',parseWebhook:()=>undefined,downloadMedia:async()=>{throw Error('NO_MEDIA')},sendText:async(recipient,text)=>{
    const receipt = {status:200,at,sha256:digest(text),providerId:'synthetic-'+(accepted()+1)}
    fs.appendFileSync(acceptance,JSON.stringify({recipient,receipt})+'\n')
    return {status:'provider_accepted',receipt}
  }},organizer:{organize:async()=>{throw Error('NO_MODEL')}},transcriber:{transcribe:async()=>{throw Error('NO_MODEL')}}})
const message={provider:'waha',messageId:'r65-synthetic-help',fromPhone:phone,kind:'text',text:'ajuda',receivedAt:at}
let boundary
if (phase === 'incident') {
  store.append({type:'paused',at,by:phone})
  store.append({type:'resumed',at,by:phone})
  const manifest=JSON.parse(fs.readFileSync(join(volume,'journal/manifest.json'),'utf8'))
  const segment=join(volume,manifest.segments.at(-1).path)
  boundary=fs.statSync(segment).size
  assistant.receive(message)
  await assistant.idle()
  if (accepted()!==1) throw Error('initial accepted receipt missing')
  const lock=join(volume,'store.lock'), lockBytes=fs.readFileSync(lock), lockInode=fs.statSync(lock).ino
  const fullSize=fs.statSync(segment).size
  fs.truncateSync(segment,mode==='zero'?0:boundary)
  const corrupt=fs.readFileSync(segment)
  const available=store.storageAvailable, effects=store.effectsAllowed, health=assistant.health()
  let rejected=false
  try { assistant.receive({...message,messageId:'r65-after-incident'}) } catch { rejected=true }
  await assistant.stop()
  store.close()
  store.close()
  const lockRetained=fs.existsSync(lock)
  console.log(JSON.stringify({sentinel:'R65_LIVE_INCIDENT',phase,mode,initial,boundary,fullSize,corruptSize:corrupt.length,corruptSha256:digest(corrupt),corruptUnchanged:fs.readFileSync(segment).equals(corrupt),storageAvailable:available,effectsAllowed:effects,health,rejected,accepted:accepted(),lockRetained,lockSha256:digest(lockBytes),lockExact:lockRetained&&fs.readFileSync(lock).equals(lockBytes)&&fs.statSync(lock).ino===lockInode}))
} else {
  assistant.receive(message)
  await assistant.idle()
  await assistant.stop()
  store.close()
  console.log(JSON.stringify({sentinel:'R65_RESTART_HEALTHY',phase,...initial,accepted:accepted(),lockReleased:!fs.existsSync(join(volume,'store.lock'))}))
}
`
