# R65 task / SPEC curta BEFORE CODE

R65_DURABLE_STORAGE_INCIDENT_RESTART, bounded T2 BUILD authorized by user under existing0179. Own scope only; Lead claim registered/read. Pipeline current authorized BUILD followed by bounded self-verification, new independent critic afterward. No inherited R56 certification or R63 acceptance.

## Recon / rules
CURRENT: Journal.available fingerprints observed files; live changes call fail(), which disables storage only in memory. close() removes the owned lock unless #retainLock. A completely truncated active segment or valid transaction prefix can reopen as healthy after graceful close, forgetting already accepted receipts and allowing duplicate synthetic send. SPEC0179 recovery requires stopped-writer/operator reconciliation, retained originals and no blind retry.

Compatibility boundary: blanket lock retention for every fail() conflicts with existing recovery of writer-origin partial append, ambiguous LF/fsync and recovery checkpoint exceptions. Preserve those original assertions and known duplicate/STATE_CONFLICT/IDEMPOTENCY_CONFLICT/INVALID_TRANSITION cases. Do not change the public contract to forbid their existing reopen/replay. Minimum candidate: use existing #retainLock specifically when the live metadata/identity guard detects a corruption incident and this Journal owns its writer descriptor; readonly/no descriptor never creates or alters a lock. Existing budget fallback unchanged. No repair/lock deletion/reconciliation automation/new schema. If actual evidence requires widening public failure policy, report that boundary before implementing.

## Inputs / composition
SourceR56 technical product readonly. Verify frozen R63 source-manifest base hashes and overlay only its three paths into own copy to test current composition. Preserve byte-exact original R38/R53/R63 test prefix; append all R65 cases to same live-offline-r38-own.test.ts, no new test path (count50 unchanged). Copy only product technical code/scripts/config and minimum @cvg public build dependency closure as needed, no Source deps or caches copied. Readonly tools preferably R25, declared symlinks; native config loader and own cache/TMPDIR.

## Pronto / frozen criteria
1. BEFORE and AFTER compiled public product case in distinct Node22 processes: commit synthetic accepted delivery, external truncate to zero or a complete valid transaction boundary, live failure/effects denied, close/exit, new process. Baseline must expose restarthealthy/duplicate; correction must deny writer via retained exact same lock and keep corrupt bytes exact, with zero repeated accepted send. Prefix includes a prior committed transaction, not only partial text.
2. Append meaningful tests to same existing file: live metadata incident durable lock; zero/prefix process restart; readonly failure without own lock/no mutation (including foreign lock); ordinary double close releases owned lock and clean restart succeeds; existing budget durable marker/fallback; duplicate/conflict exceptions nonfatal and close remains normal. No original assertions edited/skipped.
3. Focus original journal migration/recovery/offline backup/live-own suites Node22, native config loader only; real synthetic filesystem/processes. Type/build/lint of delta, raw commands/exit/sentinels, source/tooling/prefix before-after hashes. Maximum two modified source files plus same existing test; no fullsuite/PG/E2E/certification.
4. Frozen payload/diff/manifest, own runtime/log/backlog and report IMPLEMENTED with exact retained-fence guarantees and limits, new critic pending. No generalized release or global closure claim.

## ExecPlan
Read/recon/claim/SPEC/readset (complete before code). Small own copy+verifiedR63 overlay. Compile baseline and reproduce subprocess restart. Implement minimum incident retention preserving original recovery; append tests. Compile after+focused suites/static gates+distinct self-review. Freeze payload, bytes and evidence, report.

## Backend decision
Invariant: an observed live integrity incident cannot silently grant a new writer after graceful close. Keep current design for nonincident recovery, reject blanket lock retention/public failure-policy change and new durable incident schema. Selected: reuse owned residual writer fence on the existing fatal live integrity path. Cost: one private state transition; residual lock requires existing operator reconciliation, never automatic TTL/PID unlocking.
