import pathlib, subprocess, json, hashlib
root = pathlib.Path(__file__).resolve().parents[1]
node = '/home/ricardo/.nvm/versions/node/v22.23.2/bin/node'
compiled = root/'candidate/products/shift-assistant/dist/public-ZDgjXK/app/dist'
def physical(path):
    out = {}
    for file in [path, *sorted(path.rglob('*'))]:
        s = file.stat()
        out[str(file.relative_to(path))] = [s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns, hashlib.sha256(file.read_bytes()).hexdigest() if file.is_file() else None]
    return out
def except_existing_root_chmod(snapshot):
    snapshot = {key:list(value) for key,value in snapshot.items()}
    snapshot['.'][5] = 'existing-root-chmod-ctime'
    return snapshot
cases = []
for mode in ['zero','prefix','clean']:
    path = root/'probes'/('after-final-'+mode)
    path.mkdir()
    phases = ['restart','restart'] if mode == 'clean' else ['incident','restart']
    for index,phase in enumerate(phases):
        label = 'after-final-'+mode+'-'+phase+('-'+str(index) if mode=='clean' else '')
        before = physical(path/'volume') if phase=='restart' and mode!='clean' else None
        command = ['python3',str(root/'probes/run-command.py'),label,node,str(root/'probes/incident-driver.mjs'),str(compiled),phase,str(path/'volume'),str(path/'accepted.jsonl'),mode]
        result = subprocess.run(command)
        if result.returncode: raise SystemExit(result.returncode)
        value = json.loads((root/'evidence'/f'{label}.stdout').read_text())
        if phase == 'incident':
            assert value['lockRetained'] and value['lockExact'] and value['corruptUnchanged']
            assert not value['storageAvailable'] and not value['effectsAllowed'] and value['accepted']==1
            if mode=='prefix':
                lines = (path/'volume'/json.loads((path/'volume/journal/manifest.json').read_text())['segments'][-1]['path']).read_text().splitlines()
                assert [json.loads(line)['seq'] for line in lines] == [1,2]
                assert [json.loads(line)['changes'][0]['type'] for line in lines] == ['paused','resumed']
        elif mode == 'clean':
            assert value['sentinel']=='R65_RESTART_HEALTHY' and value['accepted']==1 and value['storageAvailable'] and value['lockReleased']
        else:
            assert value['sentinel']=='R65_RESTART_DENIED' and value['diagnostic']=='STORE_LOCKED' and value['accepted']==1
            after = physical(path/'volume')
            assert except_existing_root_chmod(after)==except_existing_root_chmod(before)
            (root/'evidence'/('after-final-'+mode+'-physical-preservation.json')).write_text(json.dumps(dict(sentinel='R65_LOCK_AND_CORRUPT_FILES_EXACT',before=before,after=after,existingException='writer construction chmods root before EEXIST, changing directory ctime only'),indent=2)+'\n')
        cases.append(value)
hashes = {str(file.relative_to(root)):hashlib.sha256(file.read_bytes()).hexdigest() for file in [compiled/'store.js',compiled/'journal.js',compiled/'assistant.js',root/'probes/incident-driver.mjs']}
(root/'evidence/after-public-summary.json').write_text(json.dumps(dict(sentinel='R65_COMPILED_PUBLIC_CYCLES_PASS',compiled=str(compiled),cases=cases,hashes=hashes),indent=2)+'\n')
print('R65_COMPILED_PUBLIC_CYCLES_PASS')
