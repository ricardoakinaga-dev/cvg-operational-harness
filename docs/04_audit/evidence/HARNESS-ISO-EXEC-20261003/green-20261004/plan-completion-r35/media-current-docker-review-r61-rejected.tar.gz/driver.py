import subprocess,json,pathlib,time,hashlib,datetime,traceback,sys
ROOT=pathlib.Path(__file__).parent
PACKET=pathlib.Path('/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/product-dockerfile-fresh-review-r61/authority/packet.json')
P=json.loads(PACKET.read_text()); IMAGE=P['imageId']
RESULTS=[]
def run(args,check=True,timeout=40):
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    try:
        r=subprocess.run(args,capture_output=True,text=True,timeout=timeout)
        item=dict(time=start,argv=args,exitCode=r.returncode,stdout=r.stdout,stderr=r.stderr)
    except subprocess.TimeoutExpired as e:
        item=dict(time=start,argv=args,exitCode=124,stdout=str(e.stdout),stderr=str(e.stderr))
    with (ROOT/'rawcommands-results.jsonl').open('a') as f:f.write(json.dumps(item,ensure_ascii=False)+'\n')
    if check and item['exitCode']!=0: raise RuntimeError(json.dumps(item,ensure_ascii=False))
    return item
def node(name,code,check=True):return run(['docker','exec',name,'/usr/local/bin/node','--input-type=module','-e',code],check)
def result(name,ok,detail):
    entry=dict(control=name,status='PASS' if ok else 'FAIL',detail=detail);RESULTS.append(entry)
    with (ROOT/'controls.jsonl').open('a') as f:f.write(json.dumps(entry,ensure_ascii=False)+'\n')
    print(json.dumps(entry,ensure_ascii=False),flush=True)
def freshvolume(label):
    name='cvg-r61-i1-'+label
    run(['docker','volume','create',name]);return name
def create(label,vol,datadir='/data',start=True):
    name='cvg-r61-i1-'+label
    args=['docker','create','--name',name,'--network','none','--read-only','--user','10001:10001','--cap-drop','ALL','--security-opt','no-new-privileges','--pids-limit','64','--memory','512m','--cpus','1','--mount','type=volume,src='+vol+',dst=/data']
    env={'SHIFT_PROVIDER':'waha','SHIFT_MEMBERS':'5511000000001=R61 Synthetic Manager*;5511000000002=R61 Synthetic Author;5511000000003=R61 Synthetic Peer','SHIFT_WEBHOOK_SECRET':'r61-i1-synthetic-secret-000000000000','SHIFT_DATA_DIR':datadir,'SHIFT_HOST':'127.0.0.1','SHIFT_PORT':'3400','SHIFT_TICK_SECONDS':'1','WAHA_URL':'http://127.0.0.1:3500','WAHA_API_KEY':'synthetic-r61','WAHA_SESSION':'r61-i1','WHISPER_URL':'http://127.0.0.1:3502','LLM_BASE_URL':'http://127.0.0.1:3501','LLM_LOCATION':'local','LLM_MODEL':'NO_MODEL'}
    for k,v in env.items():args.extend(['--env',k+'='+v])
    args.append(IMAGE);run(args)
    if start:run(['docker','start',name]);time.sleep(.25)
    return name
def utility(label,vol):
    name='cvg-r61-i1-'+label
    run(['docker','create','--name',name,'--network','none','--read-only','--user','10001:10001','--cap-drop','ALL','--security-opt','no-new-privileges','--pids-limit','64','--memory','512m','--cpus','1','--mount','type=volume,src='+vol+',dst=/data',IMAGE,'/usr/local/bin/node','-e','process.once("SIGTERM",()=>process.exit(0));setInterval(()=>{},1000)'])
    run(['docker','start',name]);return name
MOCK="""
import http from 'node:http';
const receipts=[],requests=[];
for(const port of [3500,3501,3502])http.createServer(async(req,res)=>{
 let body='';for await(const c of req)body+=c;
 if(req.url==='/receipts'){res.setHeader('content-type','application/json');res.end(JSON.stringify({receipts,requests}));return;}
 requests.push({port,method:req.method,url:req.url,body});
 if(port===3500&&req.url==='/api/sendText'){
  receipts.push({...JSON.parse(body),id:'r61-synthetic-'+(receipts.length+1)});
  res.setHeader('content-type','application/json');res.end(JSON.stringify({id:receipts.at(-1).id}));
 }else if(port===3500&&req.url==='/media/primary.png'){
  res.setHeader('content-type','image/png');res.end(Buffer.from('89504e470d0a1a0a5236312d49312d53594e544845544943','hex'));
 }else{res.writeHead(503);res.end('{"error":"NO_MODEL"}');}
}).listen(port,'127.0.0.1');
"""
def mock(name):
    run(['docker','exec','-d',name,'/usr/local/bin/node','--input-type=module','-e',MOCK]);time.sleep(.2)
def http(name,path='/health/ready',payload=None,secret=True,port=3400):
    opts={'method':'POST' if payload is not None else 'GET','headers':{'content-type':'application/json'}}
    if secret:opts['headers']['x-cvg-webhook-secret']='r61-i1-synthetic-secret-000000000000'
    if payload is not None:opts['body']=json.dumps(payload,ensure_ascii=False)
    code="const r=await fetch("+json.dumps(f'http://127.0.0.1:{port}{path}')+","+json.dumps(opts)+");console.log(JSON.stringify({status:r.status,body:await r.json()}))"
    return json.loads(node(name,code)['stdout'])
def payload(id,text,phone='5511000000002',media=False):
    p={'event':'message','session':'r61-i1','payload':{'id':id,'from':phone+'@c.us','fromMe':False,'body':text}}
    if media:p['payload'].update(hasMedia=True,media={'mimetype':'image/png','url':'http://127.0.0.1:3500/media/primary.png'})
    return p
def send(name,id,text,phone='5511000000002',media=False):
    return http(name,'/webhooks/waha',payload(id,text,phone,media))
def receipts(name):return http(name,'/receipts',port=3500)['body']
def settle(name,seconds=.3):time.sleep(seconds);return receipts(name)
def inventory(name,root='/data'):
    return json.loads(node(name,"import fs from 'node:fs';import crypto from 'node:crypto';import path from 'node:path';const root="+json.dumps(root)+";const out=[];function walk(d){for(const n of fs.readdirSync(d).sort()){const p=path.join(d,n),s=fs.lstatSync(p);if(s.isDirectory())walk(p);else if(s.isFile())out.push({path:p.slice(root.length+1),size:s.size,mode:s.mode&511,uid:s.uid,gid:s.gid,sha256:crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')});}}walk(root);console.log(JSON.stringify(out));")['stdout'])
def stop(name):
    run(['docker','stop','--time','10',name]);run(['docker','logs',name])
def restart(name):
    stop(name);run(['docker','start',name]);time.sleep(.3)
    state=json.loads(run(['docker','inspect',name])['stdout'])[0]['State']
    if not state['Running']:return False
    mock(name);return True
def initial():
    r=run(['docker','image','inspect',IMAGE]);info=json.loads(r['stdout'])[0]
    (ROOT/'image-inspect.json').write_text(json.dumps(info,indent=2))
    result('Q2.image-config',info['Id']==IMAGE and info['Config']['User']=='10001:10001' and info['Config']['Cmd']==['/usr/local/bin/node','shift-assistant.mjs'] and not info['Config'].get('Entrypoint'),{'Id':info['Id'],'user':info['Config']['User'],'cmd':info['Config']['Cmd']})
    vol=freshvolume('public-data');name=create('public',vol);mock(name)
    (ROOT/'owned-state.json').write_text(json.dumps({'public':name,'publicVolume':vol}))
    code="""import fs from 'node:fs';import crypto from 'node:crypto';const h=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');let write;try{fs.writeFileSync('/app/r61-probe','synthetic');write='WRITABLE'}catch(e){write=e.code}console.log(JSON.stringify({node:process.version,uid:process.getuid(),gid:process.getgid(),bundle:h('/app/shift-assistant.mjs'),offline:h('/app/dist/offline-validator.mjs'),cli:h('/app/scripts/backup-restore.mjs'),rootWrite:write,pid1:fs.readFileSync('/proc/1/cmdline').toString(),status:fs.readFileSync('/proc/1/status','utf8'),runtime:JSON.parse(fs.readFileSync('/app/runtime-files.json')),absent:['/bin/sh','/bin/bash','/usr/bin/sh','/usr/bin/npm','/usr/local/bin/npm','/usr/bin/apt','/usr/bin/dpkg','/app/node_modules'].map(p=>({path:p,exists:fs.existsSync(p)})),appFiles:fs.readdirSync('/app')}))"""
    artifact=json.loads(node(name,code)['stdout']);(ROOT/'runtime-artifact.json').write_text(json.dumps(artifact,indent=2))
    result('Q1.distributed-inputs',artifact['bundle']==P['bundleSha256'] and artifact['offline']==P['offlineValidatorSha256'] and artifact['cli']==next(x['sha256'] for x in P['allowedSourceInputs'] if x['path']=='products/shift-assistant/scripts/backup-restore.mjs') and not any(x['exists'] for x in artifact['absent']),artifact)
    result('Q2.actual-runtime',artifact['node']=='v22.23.2' and artifact['uid']==artifact['gid']==10001 and artifact['pid1']=='/usr/local/bin/node\x00shift-assistant.mjs\x00',{'node':artifact['node'],'uid':artifact['uid'],'gid':artifact['gid'],'pid1':artifact['pid1']})
    inspect=json.loads(run(['docker','inspect',name])['stdout'])[0];(ROOT/'public-inspect.json').write_text(json.dumps(inspect,indent=2));h=inspect['HostConfig']
    result('Q3.isolation',h['ReadonlyRootfs'] and h['NetworkMode']=='none' and h['Memory']==536870912 and h['PidsLimit']==64 and h['NanoCpus']==1000000000 and h['CapDrop']==['ALL'] and 'no-new-privileges' in h['SecurityOpt'] and not h.get('PortBindings') and artifact['rootWrite']=='EROFS' and 'NoNewPrivs:\t1' in artifact['status'],{'hostConfig':h,'mounts':inspect['Mounts'],'rootWrite':artifact['rootWrite']})
    return name,vol
if __name__=='__main__':initial()
