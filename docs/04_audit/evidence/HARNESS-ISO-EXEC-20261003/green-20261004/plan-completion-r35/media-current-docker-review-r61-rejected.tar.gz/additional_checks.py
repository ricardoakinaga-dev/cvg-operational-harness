import driver as d,json,time,hashlib
# Correct the oracle spelling: the public contract exposes operational_hold.
old=next(json.loads(x) for x in (d.ROOT/'controls.jsonl').read_text().splitlines() if json.loads(x)['control']=='Q4.restore-hold')
z=old['detail'];ok=z['health']['status']==503 and z['healthAfter']['status']==503 and not z['health']['body']['effectsEnabled'] and not z['healthAfter']['body']['effectsEnabled'] and not z['receipts']['receipts'] and 'operational_hold' in z['health']['body']['reasonCodes']
entry={'control':'Q4.restore-hold.oracle-correction','status':'PASS' if ok else 'FAIL','supersedes':'Q4.restore-hold','detail':{'reason':'Own initial assertion expected an undocumented restore_hold label. Actual public label operational_hold is consistent with the demonstrated hold; exact recorded HTTP evidence is unchanged.','evidence':z}}
with (d.ROOT/'controls.jsonl').open('a') as f:f.write(json.dumps(entry,ensure_ascii=False)+'\n')
print(json.dumps(entry,ensure_ascii=False),flush=True)
# Scope of artifact inspection is exact runtime files, no source whole-tree scan.
v=d.freshvolume('distribution-data');u=d.utility('distribution',v)
code="""import fs from 'node:fs';import crypto from 'node:crypto';const m=JSON.parse(fs.readFileSync('/app/runtime-files.json'));const files=m.files.map(p=>({path:p,bytes:fs.statSync(p).size,sha256:crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')}));const read=p=>fs.readFileSync(p,'utf8').trim();console.log(JSON.stringify({files,directories:['/bin','/sbin','/usr/bin','/usr/sbin','/usr/local/bin','/app/scripts','/app/dist'].map(p=>({path:p,entries:fs.existsSync(p)?fs.readdirSync(p):[]})),cpu:read('/sys/fs/cgroup/cpu.max'),memory:read('/sys/fs/cgroup/memory.max'),pids:read('/sys/fs/cgroup/pids.max'),network:read('/proc/net/dev'),dataStat:{uid:fs.statSync('/data').uid,gid:fs.statSync('/data').gid,mode:fs.statSync('/data').mode&511}}));"""
artifact=json.loads(d.node(u,code)['stdout']);(d.ROOT/'exact-runtime-input-inventory.json').write_text(json.dumps(artifact,indent=2))
d.result('Q1.runtime-libraries-cli-inventory',all(x['bytes']>0 for x in artifact['files']) and next(x for x in artifact['directories'] if x['path']=='/usr/local/bin')['entries']==['node'] and next(x for x in artifact['directories'] if x['path']=='/app/dist')['entries']==['offline-validator.mjs'],artifact)
d.result('Q3.kernel-limits-network',artifact['cpu']=='100000 100000' and artifact['memory']=='536870912' and artifact['pids']=='64' and 'eth0' not in artifact['network'] and artifact['dataStat']=={'uid':10001,'gid':10001,'mode':448},artifact);d.stop(u)
# Replaying the pre-truncation identity corroborates lost durable acceptance.
n='cvg-r61-i1-journal-truncate-zero';d.run(['docker','start',n]);time.sleep(.3);d.mock(n)
reply=d.send(n,'r61-own-seed-journal-truncate-zero','R61 fonte sintética para journal-truncate-zero');receipt=d.settle(n,.4)
d.result('Q5.corruption-restart-replay',reply['body']=={'accepted':False} and len(receipt['receipts'])==0,{'webhook':reply,'receipts':receipt,'expected':'identity accepted before live truncation must not produce a second accepted send','baselineEvidence':'journal-truncate-zero-terminal-receipts.json'})
(d.ROOT/'terminal-receipts-truncation-duplicate.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2));d.stop(n)
# Independent synthetic legacy original and legacy-media controls.
for target in ['events','media']:
    label='legacy-'+target;v=d.freshvolume(label+'-data');seed=d.utility(label+'-seed',v)
    at='2026-10-05T00:00:00.000Z';note={'id':'r61-legacy-note','messageId':'r61-legacy-message','authorPhone':'5511000000002','createdAt':at,'kind':'image','rawText':'R61 legado sintético preservado.','mediaFile':'r61-legacy.png','unverifiedNumbers':[],'confirmed':False}
    event={'type':'note_created','at':at,'note':note}
    d.node(seed,"import fs from 'node:fs';fs.mkdirSync('/data/media',{mode:0o700});fs.writeFileSync('/data/media/r61-legacy.png',Buffer.from('R61-LEGACY-SYNTHETIC-MEDIA'),{mode:0o600});fs.writeFileSync('/data/events.jsonl',"+json.dumps(json.dumps(event,ensure_ascii=False)+'\n')+",{mode:0o600});console.log('own synthetic legacy seeded');")
    originals=d.inventory(seed);d.stop(seed);n=d.create(label,v);d.mock(n)
    healthy=d.http(n);admit=d.send(n,'r61-own-legacy-healthy-'+target,'ajuda');good=d.settle(n,.2)
    inv=d.inventory(n);originalsOK=all(any(x['path']==o['path'] and x['sha256']==o['sha256'] for x in inv) for o in originals)
    d.result('Q6.'+label+'.healthy',healthy['body']['reasonCodes']==['operational_hold'] and originalsOK and admit['body'].get('accepted') and not good['receipts'],{'health':healthy,'webhook':admit,'originalsPreserved':originalsOK,'inventory':inv})
    path='/data/events.jsonl' if target=='events' else '/data/media/r61-legacy.png'
    mutation=json.loads(d.node(n,"import fs from 'node:fs';import crypto from 'node:crypto';const p="+json.dumps(path)+";const s=fs.statSync(p),b=fs.readFileSync(p);b[Math.floor(b.length/2)]^=1;fs.writeFileSync(p,b);fs.utimesSync(p,s.atime,s.mtime);console.log(JSON.stringify({path:p,bytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex'),corruptBase64:b.toString('base64')}))")['stdout'])
    (d.ROOT/(label+'-mutation.json')).write_text(json.dumps(mutation,indent=2))
    denied=d.send(n,'r61-own-legacy-corrupt-'+target,'ajuda');ready=d.http(n);receipts=d.settle(n,.2)
    d.result('Q6.'+label+'.live',denied['status']==503 and 'storage_unavailable' in ready['body']['reasonCodes'] and not receipts['receipts'],{'webhook':denied,'health':ready,'receipts':receipts})
    running=d.restart(n)
    if running:
        health=d.http(n);after=d.inventory(n);d.stop(n);blocked=health['status']==503 and not health['body']['effectsEnabled']
    else:
        state=json.loads(d.run(['docker','inspect',n])['stdout'])[0]['State'];health={'state':state};reader=d.utility(label+'-reader',v);after=d.inventory(reader);d.stop(reader);blocked=state['ExitCode']==1
    preserved=any('/data/'+x['path']==path and x['sha256']==mutation['sha256'] for x in after)
    d.result('Q6.'+label+'.restart',blocked and preserved,{'health':health,'corruptBytesPreserved':preserved,'inventory':after})
