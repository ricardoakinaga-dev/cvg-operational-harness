import driver as d,json,hashlib,pathlib,datetime,os
ROOT=d.ROOT
def digest(b):return hashlib.sha256(b).hexdigest()
before=json.loads((ROOT/'fingerprints-before.json').read_text());after=[]
for item in before:
    p=pathlib.Path(d.P['source'])/item['path'];h=digest(p.read_bytes());after.append(dict(path=item['path'],sha256=h,expected=item['expected'],match=h==item['expected']))
(ROOT/'fingerprints-after.json').write_text(json.dumps(after,indent=2))
physical=[{'path':x['path'],'regular':(pathlib.Path(d.P['source'])/x['path']).is_file(),'symlink':(pathlib.Path(d.P['source'])/x['path']).is_symlink(),'physicalContained':(pathlib.Path(d.P['source'])/x['path']).resolve().is_relative_to(pathlib.Path(d.P['source']).resolve())} for x in before]
(ROOT/'physical-allowed-inputs.json').write_text(json.dumps(physical,indent=2))
d.result('Q7.fingerprints-authority',before==after and all(x['match'] for x in after) and all(x['regular'] and not x['symlink'] and x['physicalContained'] for x in physical),{'permittedTechnicalFingerprints':len(after),'sourceContextSamePath':d.P['source']==d.P['contextReadonly'],'allUnchanged':before==after,'allMatchPacket':all(x['match'] for x in after),'docsEnvAndEgressPolicyExcluded':['products/shift-assistant/README.md','products/shift-assistant/deploy/.env.example','products/shift-assistant/deploy/egress-policy.example.nft'],'sourceWrites':0,'governanceReads':0,'otherAgents':0,'providerCalls':0,'providerMock':'loopback synthetic only'})
raw=[json.loads(x) for x in (ROOT/'rawcommands-results.jsonl').read_text().splitlines()]
containers=[];volumes=[]
for x in raw:
    a=x['argv']
    if a[:2]==['docker','create'] and x['exitCode']==0:containers.append(a[a.index('--name')+1])
    if a[:3]==['docker','volume','create'] and x['exitCode']==0:volumes.append(a[3])
containers=list(dict.fromkeys(containers));volumes=list(dict.fromkeys(volumes))
assert all(x.startswith('cvg-r61-i1-') for x in containers+volumes)
isolation=[]
for name in containers:
    z=json.loads(d.run(['docker','inspect',name])['stdout'])[0];h=z['HostConfig'];c=z['Config']
    safe=z['Image']==d.IMAGE and c['User']=='10001:10001' and h['ReadonlyRootfs'] and h['NetworkMode']=='none' and not h['PortBindings'] and h['CapDrop']==['ALL'] and 'no-new-privileges' in h['SecurityOpt'] and h['PidsLimit']==64 and h['Memory']==536870912 and h['NanoCpus']==1000000000 and len(z['Mounts'])==1 and z['Mounts'][0]['Name'] in volumes and z['Mounts'][0]['Destination']=='/data'
    isolation.append({'name':name,'id':z['Id'],'image':z['Image'],'safe':safe,'wasRunning':z['State']['Running'],'command':c['Cmd'],'ownedVolume':z['Mounts'][0]['Name']})
    if z['State']['Running']:d.stop(name)
    d.run(['docker','rm',name])
for name in volumes:d.run(['docker','volume','rm',name])
absence=[]
for name in containers:absence.append({'type':'container','name':name,'absent':d.run(['docker','inspect',name],False)['exitCode']!=0})
for name in volumes:absence.append({'type':'volume','name':name,'absent':d.run(['docker','volume','inspect',name],False)['exitCode']!=0})
cleanup={'containersRemoved':containers,'volumesRemoved':volumes,'allContainerConstraints':isolation,'absence':absence,'pruneUsed':False,'foreignObjectsTouched':False}
(ROOT/'cleanup.json').write_text(json.dumps(cleanup,indent=2))
d.result('Q3.all-owned-container-constraints',all(x['safe'] for x in isolation),{'containers':len(containers),'isolation':isolation})
d.result('Q7.cleanup-own-only',all(x['absent'] for x in absence),{'containersRemoved':len(containers),'volumesRemoved':len(volumes),'allAbsent':all(x['absent'] for x in absence),'pruneUsed':False})
controls=[json.loads(x) for x in (ROOT/'controls.jsonl').read_text().splitlines()];superseded={x['supersedes'] for x in controls if 'supersedes' in x};effective=[x for x in controls if x['control'] not in superseded]
q={}
for i in range(1,8):
    group=[x for x in effective if x['control'].startswith('Q'+str(i)+'.')];q['Q'+str(i)]={'verdict':'REJECT' if any(x['status']=='FAIL' for x in group) else 'ACCEPT','controls':[{'control':x['control'],'status':x['status']} for x in group]}
controlPlan={
 'Q1':'Compare allowlisted physical COPYinputs against packet, inspect pinned Dockerfile and exact emitted image bundle/compiled validator/CLI, inspect fixed runtime-library inventory and shell/package-manager paths. Binding consistency only; no rebuild or provenance certification.',
 'Q2':'Inspect frozen image config and actual process: Node v22.23.2, UID/GID 10001, PID1 direct exec, bundle identity.',
 'Q3':'Inspect every own container against resource/network/security constraints; test EROFS, effective capabilities, kernel cgroups and loopback-only interfaces.',
 'Q4':'Exercise public HTTP for missing secret, unknown member, help, raw NO_MODEL note, primary media, foreign/wrong token, author confirmation, manager role, pause/resume and restore HOLD with mock receipts.',
 'Q5':'Healthy restart retains journal/media bytes and accepted identities; pause/HOLD survive restart. Also replay the pre-corruption identity after truncation to detect duplicate sends.',
 'Q6':'Reject second writer and live CLI backup; independently seed corruptions, restore mtime, hit webhook as first tested boundary, inspect readiness/liveness/send receipts, restart and preserve corrupted bytes. Exercise actual compiled CLI backup/restore and tamper refusal. Supplement with legacy originals/media under migration HOLD.',
 'Q7':'Use packet alone as authority, finite permitted fingerprints before/after, no source writes or governance/previous verdicts, own outputs and Docker resources only, freeze evidence and clean up without prune.'}
(ROOT/'own-Q1-Q7-controls.json').write_text(json.dumps(controlPlan,ensure_ascii=False,indent=2))
verdict={'task':d.P['task'],'reviewer':'fresh I1 Docker','localVerdict':'REJECT','imageId':d.IMAGE,'sourceCandidate':d.P['sourceCandidate'],'Q1_Q7':q,'blocker':{'id':'I1-R61-F1','severity':'HIGH','description':'Live active-segment truncation is detected in memory but restart discards the incident and trusts an empty active journal. Readiness and effects resume; replay of a previously accepted identity produces another accepted synthetic send.','controls':['Q6.journal-truncate-zero.restart','Q5.corruption-restart-replay']},'secondaryObservation':{'id':'I1-R61-O1','description':'Mutation of the retained pre-migration original media is not reported as storage corruption in live runtime or restart. Canonical migrated media remains intact and operational HOLD blocks all sends; do not infer production exposure.','control':'Q6.legacy-media.live'},'oracleCorrections':[{'control':'Q4.restore-hold','supersededBy':'Q4.restore-hold.oracle-correction','reason':'Own initial label assertion was incorrect; correct public label operational_hold, effects stayed blocked.'}],'qualificationLimits':d.P['qualificationLimits'],'leadCertification':'SEPARATE_NOT_GRANTED','buildProvenance':'Packet-bound consistency verified; independent rebuild/build attestation not performed','completedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(ROOT/'verdict.json').write_text(json.dumps(verdict,ensure_ascii=False,indent=2))
active=[x for x in effective if x['status']=='FAIL']
table='\n'.join('| '+k+' | '+v['verdict']+' |' for k,v in q.items())
report=f'''# R61 — crítico I1 Docker novo

Veredito local: **REJECT**, imagem `{d.IMAGE}`.

A falha bloqueadora I1-R61-F1 é perda de autoridade durável depois de truncar o segmento ativo: a detecção durante a execução bloqueia o webhook com 503 e desabilita efeitos; após parada/restart o processo retorna readiness 200, `effectsEnabled: true`, aceita outro webhook e envia resposta ao mock. O replay da identidade originalmente aceita também retorna `accepted: true` e gera outro envio da mesma prévia/token. A sequência está nos comandos e respostas integrais, não depende de revisão anterior.

| Controle | Veredito local |
| --- | --- |
{table}

## Evidência bloqueadora

1. Volume/container próprios `cvg-r61-i1-journal-truncate-zero-data` / `cvg-r61-i1-journal-truncate-zero`, sempre imagem frozen, network none, root readonly, UID10001, caps ALL dropped, no-new-privileges, pids64, memory512m, cpu1, sem portas publicadas.
2. `r61-own-seed-journal-truncate-zero` entra pelo webhook real e a prévia é aceita pelo mock sintético.
3. O controle trunca o segmento ativo para 0 bytes e restaura mtime. Arquivo antes e depois: `journal-truncate-zero-mutation.json`, com hashes e bytes base64. A primeira chamada pública testada após a alteração retorna 503; nenhum envio adicional ocorre enquanto o processo está vivo.
4. Após restart: readiness200, efeitos habilitados, novo webhook aceito e novo envio. `journal-truncate-zero-terminal-receipts.json` registra os receipts anteriores e posteriores. O runtime acrescenta novos registros ao arquivo truncado: bytes incidentes não ficam isolados/preservados como documento fechado.
5. Um novo restart e replay de `r61-own-seed-journal-truncate-zero` aceita novamente e gera a mesma prévia/token: `terminal-receipts-truncation-duplicate.json` e controle `Q5.corruption-restart-replay`.

A leitura técnica permite inferir a causa: `Journal.fail()` marca disponibilidade/diagnóstico em memória; a proteção de integridade observa metadata em memória. O manifest inicial do segmento ativo permite prefixo vazio, e não há nessas provas uma marca durável de incidente que impeça o novo processo de aceitar a truncação para vazio como histórico válido. A correção deve ser construída/certificada separadamente pelo lead, incluindo truncação em fronteiras completas de transação.

## Resultados e limites

Q1–Q3 passaram na consistência packet/context/imagem: {len(after)} fingerprints permitidos antes/depois coincidem com a autoridade, Dockerfile contém base digest fixa, Node22.23.2 real, hash do bundle/validator/CLI exato. Foram inspecionados somente os arquivos de runtime expressamente enumerados e diretórios de executáveis/CLI, sem exportar/duplicar o Node de 124836408 bytes. O pin do Dockerfile e a ligação por hashes não constituem atestado independente de proveniência de build; não foi feito rebuild/npm/install.

Q4 passou: segredo/membro, ajuda, fonte bruta NO_MODEL, mídia primária sintética, autor/token, role gestor, pausa/retomada, HOLD do restore e resistência a retomada pelo gestor. As portas3501/3502 dos sentinelas locais não receberam requests. A mídia usa bytes sintéticos com MIME de imagem; não foi verificada interpretação visual nem áudio/Whisper. O contrato público chama o HOLD de `operational_hold`; a primeira asserção própria esperava incorretamente `restore_hold`. O registro bruto do erro foi preservado e corrigido por avaliação explícita da mesma evidência, sem atribuí-lo ao produto.

Q5 passou em restart saudável: journal/media originais idênticos, replay de texto/mídia rejeitado, zero novos envios; pausa e restore HOLD persistem. Q5 rejeita o caso de replay depois da perda por truncação.

Q6: todos os 9 casos de journal/manifest/mídia primária foram barrados ao vivo. Depois do restart, 8 foram barrados por503 ou saída1 antes de abrir o servidor; o caso de truncação do journal para vazio falhou. Segunda escrita foi rejeitada com STORE_LOCKED. A CLI distribuída na imagem, importando o validator compilado, executou backup e restore de5 documentos com hashes iguais, HOLD criado, originais intactos; recusou backup com writer vivo e restore adulterado antes de criar destino.

Controle adicional de legado: os originais foram preservados na migração e ficaram sob HOLD; alterar `events.jsonl` foi detectado ao vivo/restart. Alterar o arquivo de mídia original pré-migração não apareceu como storage_unavailable, embora o arquivo canônico migrado permanecesse intacto e HOLD impedisse envio. Isso é observação de cobertura, com efeito limitado pela migração/HOLD; não constitui demonstração de egress nem atendimento real. O critério de restart desse controle adicional prova bloqueio por HOLD, não detecção da alteração do original.

Q7: autoridade única packet, nenhuma leitura de Root/governança/histórico/builder/pareceres prévios/privateenv, nenhuma mutação de source/context/repositório, nenhuma suite/PG/npm/install/descendant/hostfirewall/push. Os scripts são originais desta revisão e ficam exclusivamente em writeOnly. Os fingerprints cobrem somente a lista técnica permitida, excluídos README do produto, env example e exemplo de política de egress. O hash aprovado de spec vem apenas do packet, que não fornece um caminho de spec autorizado para ler.

## Artefatos e cleanup

`rawcommands-results.jsonl` preserva argv, stdout, stderr, timestamps e exit codes de cada operação Docker do driver; `controls.jsonl` mantém resultados brutos e correção de oracle; `verdict.json` e `frozen-manifest.json` são a saída consolidada. A exploração inicial do packet e dos arquivos técnicos ocorreu pela sessão terminal antes do driver; os fingerprints iniciais e binding de autoridade são seus receipts persistentes, sem alegar que esse JSONL captura tais leituras iniciais.

Foram removidos somente os {len(containers)} containers e {len(volumes)} volumes criados por este driver. `cleanup.json` registra IDs, configurações e ausência posterior de cada objeto. Nenhum prune ou objeto estrangeiro. Terminal receipts, hashes e bytes das mutações permanecem em writeOnly; árvores grandes de runtime não foram copiadas.

Host egress matrix **NOT_QUALIFIED**; real alert receipt **NOT_RUN**; clinical human/Whisper **NOT_RUN**; produção **NO_GO**. O lead certifica o candidato separadamente; esta revisão concede apenas o veredito local REJECT.
'''
(ROOT/'report.md').write_text(report)
(ROOT/'authority-packet-frozen.json').write_bytes(d.PACKET.read_bytes())
files=[]
for f in sorted(ROOT.rglob('*')):
    if f.is_file() and f.name not in ['frozen-manifest.json','frozen-manifest.sha256']:
        files.append({'path':str(f.relative_to(ROOT)),'bytes':f.stat().st_size,'sha256':digest(f.read_bytes())})
manifest={'version':1,'task':d.P['task'],'reviewer':'fresh I1 Docker','localVerdict':'REJECT','packetSha256':digest(d.PACKET.read_bytes()),'sourceCandidate':d.P['sourceCandidate'],'imageId':d.IMAGE,'bundleSha256':d.P['bundleSha256'],'offlineValidatorSha256':d.P['offlineValidatorSha256'],'approvedSpecSha256FromAuthorityOnly':d.P['approvedSpecSha256'],'contextReadonly':d.P['contextReadonly'],'sourceFingerprintsUnchanged':before==after,'qualificationLimits':d.P['qualificationLimits'],'cleanupComplete':all(x['absent'] for x in absence),'artifacts':files,'totalArtifactBytes':sum(x['bytes'] for x in files),'frozenAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
mf=ROOT/'frozen-manifest.json';mf.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');mh=digest(mf.read_bytes());(ROOT/'frozen-manifest.sha256').write_text(mh+'  frozen-manifest.json\n')
for f in ROOT.rglob('*'):
    if f.is_file():f.chmod(0o444)
print(json.dumps({'localVerdict':'REJECT','Q1_Q7':{k:v['verdict'] for k,v in q.items()},'failures':[x['control'] for x in active],'frozenManifestSha256':mh,'artifactBytes':manifest['totalArtifactBytes'],'containersRemoved':len(containers),'volumesRemoved':len(volumes)},indent=2),flush=True)
