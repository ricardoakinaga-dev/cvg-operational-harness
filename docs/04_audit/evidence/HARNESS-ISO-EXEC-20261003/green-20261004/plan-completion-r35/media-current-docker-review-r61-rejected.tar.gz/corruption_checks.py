import driver as d,json,time,sys
public='cvg-r61-i1-public';vol='cvg-r61-i1-public-data'
if len(sys.argv)==1:
    before=d.inventory(public);second=d.create('secondwriter',vol);time.sleep(.3)
    state=json.loads(d.run(['docker','inspect',second])['stdout'])[0]['State'];logs=d.run(['docker','logs',second]);after=d.inventory(public)
    d.result('Q6.second-writer',not state['Running'] and state['ExitCode']==1 and 'shift.start.failed' in logs['stderr']+logs['stdout'] and before==after and d.http(public)['status']==200,{'state':state,'logs':logs,'documentsUnchanged':before==after})
    backup=d.run(['docker','exec',public,'/usr/local/bin/node','/app/scripts/backup-restore.mjs','backup','/data','/tmp/r61-backup'],False)
    d.result('Q6.backup-live-writer-refused',backup['exitCode']==1 and d.inventory(public)==after,backup)
cases=[('journal-samesize','journal','same'),('journal-truncate-zero','journal','truncate'),('journal-replacement','journal','replace'),('manifest-reference','manifest','reference'),('manifest-history-reference','history','same'),('primary-media-samesize','media','same'),('primary-media-truncate','media','truncate'),('primary-media-replacement','media','replace'),('primary-sidecar-reference','sidecar','reference')]
for label,target,attack in cases:
    if len(sys.argv)>1 and label=='journal-samesize':continue
    vol=d.freshvolume(label+'-data');n=d.create(label,vol);d.mock(n)
    health=d.http(n);w=d.send(n,'r61-own-seed-'+label,'R61 fonte sintética para '+label,media=target in ['media','sidecar'])
    good=d.settle(n,.4);inv=d.inventory(n)
    d.result('Q6.'+label+'.healthy',health['status']==200 and w['body'].get('accepted') and len(good['receipts'])==1,{'health':health,'webhook':w,'receipts':good})
    select={'journal':"'/data/'+m.segments.at(-1).path",'manifest':"'/data/journal/manifest.json'",'history':"'/data/journal/manifests/revision-'+m.revision+'.json'",'media':"'/data/media/'+fs.readdirSync('/data/media').find(x=>!x.endsWith('.json'))",'sidecar':"'/data/media/'+fs.readdirSync('/data/media').find(x=>x.endsWith('.json'))"}[target]
    action={'same':"const b=Buffer.from(original);b[Math.floor(b.length/2)]^=1;fs.writeFileSync(p,b);",'truncate':"fs.truncateSync(p,0);",'replace':"const b=Buffer.from(original);b[Math.floor(b.length/2)]^=1;fs.writeFileSync(p+'.r61',b,{mode:0o600});fs.renameSync(p+'.r61',p);",'reference':"const x=JSON.parse(original);if(x.segments)x.segments[0].path='journal/segment-00000000-0000-0000-0000-000000000000.jsonl';else x.path='media/r61-missing.png';fs.writeFileSync(p,JSON.stringify(x)+'\\n');"}[attack]
    code="import fs from 'node:fs';import crypto from 'node:crypto';const m=JSON.parse(fs.readFileSync('/data/journal/manifest.json'));const p="+select+";const original=fs.readFileSync(p),s=fs.statSync(p);"+action+";fs.utimesSync(p,s.atime,s.mtime);const now=fs.readFileSync(p);console.log(JSON.stringify({path:p,originalSha256:crypto.createHash('sha256').update(original).digest('hex'),corruptSha256:crypto.createHash('sha256').update(now).digest('hex'),originalBytes:original.length,corruptBytes:now.length,originalBase64:original.toString('base64'),corruptBase64:now.toString('base64')}));"
    mutation=json.loads(d.node(n,code)['stdout']);(d.ROOT/(label+'-mutation.json')).write_text(json.dumps(mutation,indent=2))
    # First boundary after corruption is an authorized public webhook.
    denied=d.send(n,'r61-own-after-'+label,'ajuda');ready=d.http(n);live=d.http(n,'/health/live');noEffects=d.settle(n,.2)
    now=d.inventory(n);changed=next(x for x in now if '/data/'+x['path']==mutation['path'])
    liveOK=denied['status']==503 and ready['status']==503 and not ready['body']['effectsEnabled'] and live['status']==200 and noEffects['receipts']==good['receipts'] and changed['sha256']==mutation['corruptSha256']
    d.result('Q6.'+label+'.live',liveOK,{'webhook':denied,'readiness':ready,'liveness':live,'receiptsUnchanged':noEffects['receipts']==good['receipts'],'corruptFile':changed})
    running=d.restart(n)
    if running:
        ready2=d.http(n);denied2=d.send(n,'r61-own-restart-'+label,'ajuda');noEffects2=d.settle(n,.2);inv2=d.inventory(n)
    else:
        state=json.loads(d.run(['docker','inspect',n])['stdout'])[0]['State'];d.run(['docker','logs',n])
        ready2={'status':'PROCESS_EXIT','body':{'effectsEnabled':False},'state':state};denied2={'status':'PROCESS_EXIT'};noEffects2={'receipts':[],'requests':[]}
        reader=d.utility(label+'-reader',vol);inv2=d.inventory(reader);d.stop(reader)
    preserved=any('/data/'+x['path']==mutation['path'] and x['sha256']==mutation['corruptSha256'] for x in inv2)
    restartOK=ready2['status'] in [503,'PROCESS_EXIT'] and not ready2['body']['effectsEnabled'] and denied2['status'] in [503,'PROCESS_EXIT'] and len(noEffects2['receipts'])==0 and preserved
    d.result('Q6.'+label+'.restart',restartOK,{'readiness':ready2,'webhook':denied2,'receipts':noEffects2,'corruptBytesPreserved':preserved,'inventory':inv2})
    (d.ROOT/(label+'-terminal-receipts.json')).write_text(json.dumps({'before':good,'afterLive':noEffects,'afterRestart':noEffects2},ensure_ascii=False,indent=2))
    d.stop(n)
