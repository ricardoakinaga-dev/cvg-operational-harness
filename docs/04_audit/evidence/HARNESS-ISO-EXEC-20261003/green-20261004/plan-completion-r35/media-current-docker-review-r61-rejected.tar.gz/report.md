# R61 — crítico I1 Docker novo

Veredito local: **REJECT**, imagem `sha256:3b9e3d37595cfba6c7e89a04efcf35d64cc5165b2b4e335fd5c4e5feddb555ba`.

A falha bloqueadora I1-R61-F1 é perda de autoridade durável depois de truncar o segmento ativo: a detecção durante a execução bloqueia o webhook com 503 e desabilita efeitos; após parada/restart o processo retorna readiness 200, `effectsEnabled: true`, aceita outro webhook e envia resposta ao mock. O replay da identidade originalmente aceita também retorna `accepted: true` e gera outro envio da mesma prévia/token. A sequência está nos comandos e respostas integrais, não depende de revisão anterior.

| Controle | Veredito local |
| --- | --- |
| Q1 | ACCEPT |
| Q2 | ACCEPT |
| Q3 | ACCEPT |
| Q4 | ACCEPT |
| Q5 | REJECT |
| Q6 | REJECT |
| Q7 | ACCEPT |

## Evidência bloqueadora

1. Volume/container próprios `cvg-r61-i1-journal-truncate-zero-data` / `cvg-r61-i1-journal-truncate-zero`, sempre imagem frozen, network none, root readonly, UID10001, caps ALL dropped, no-new-privileges, pids64, memory512m, cpu1, sem portas publicadas.
2. `r61-own-seed-journal-truncate-zero` entra pelo webhook real e a prévia é aceita pelo mock sintético.
3. O controle trunca o segmento ativo para 0 bytes e restaura mtime. Arquivo antes e depois: `journal-truncate-zero-mutation.json`, com hashes e bytes base64. A primeira chamada pública testada após a alteração retorna 503; nenhum envio adicional ocorre enquanto o processo está vivo.
4. Após restart: readiness200, efeitos habilitados, novo webhook aceito e novo envio. `journal-truncate-zero-terminal-receipts.json` registra os receipts anteriores e posteriores. O runtime acrescenta novos registros ao arquivo truncado: bytes incidentes não ficam isolados/preservados como documento fechado.
5. Um novo restart e replay de `r61-own-seed-journal-truncate-zero` aceita novamente e gera a mesma prévia/token: `terminal-receipts-truncation-duplicate.json` e controle `Q5.corruption-restart-replay`.

A leitura técnica permite inferir a causa: `Journal.fail()` marca disponibilidade/diagnóstico em memória; a proteção de integridade observa metadata em memória. O manifest inicial do segmento ativo permite prefixo vazio, e não há nessas provas uma marca durável de incidente que impeça o novo processo de aceitar a truncação para vazio como histórico válido. A correção deve ser construída/certificada separadamente pelo lead, incluindo truncação em fronteiras completas de transação.

## Resultados e limites

Q1–Q3 passaram na consistência packet/context/imagem: 826 fingerprints permitidos antes/depois coincidem com a autoridade, Dockerfile contém base digest fixa, Node22.23.2 real, hash do bundle/validator/CLI exato. Foram inspecionados somente os arquivos de runtime expressamente enumerados e diretórios de executáveis/CLI, sem exportar/duplicar o Node de 124836408 bytes. O pin do Dockerfile e a ligação por hashes não constituem atestado independente de proveniência de build; não foi feito rebuild/npm/install.

Q4 passou: segredo/membro, ajuda, fonte bruta NO_MODEL, mídia primária sintética, autor/token, role gestor, pausa/retomada, HOLD do restore e resistência a retomada pelo gestor. As portas3501/3502 dos sentinelas locais não receberam requests. A mídia usa bytes sintéticos com MIME de imagem; não foi verificada interpretação visual nem áudio/Whisper. O contrato público chama o HOLD de `operational_hold`; a primeira asserção própria esperava incorretamente `restore_hold`. O registro bruto do erro foi preservado e corrigido por avaliação explícita da mesma evidência, sem atribuí-lo ao produto.

Q5 passou em restart saudável: journal/media originais idênticos, replay de texto/mídia rejeitado, zero novos envios; pausa e restore HOLD persistem. Q5 rejeita o caso de replay depois da perda por truncação.

Q6: todos os 9 casos de journal/manifest/mídia primária foram barrados ao vivo. Depois do restart, 8 foram barrados por503 ou saída1 antes de abrir o servidor; o caso de truncação do journal para vazio falhou. Segunda escrita foi rejeitada com STORE_LOCKED. A CLI distribuída na imagem, importando o validator compilado, executou backup e restore de5 documentos com hashes iguais, HOLD criado, originais intactos; recusou backup com writer vivo e restore adulterado antes de criar destino.

Controle adicional de legado: os originais foram preservados na migração e ficaram sob HOLD; alterar `events.jsonl` foi detectado ao vivo/restart. Alterar o arquivo de mídia original pré-migração não apareceu como storage_unavailable, embora o arquivo canônico migrado permanecesse intacto e HOLD impedisse envio. Isso é observação de cobertura, com efeito limitado pela migração/HOLD; não constitui demonstração de egress nem atendimento real. O critério de restart desse controle adicional prova bloqueio por HOLD, não detecção da alteração do original.

Q7: autoridade única packet, nenhuma leitura de Root/governança/histórico/builder/pareceres prévios/privateenv, nenhuma mutação de source/context/repositório, nenhuma suite/PG/npm/install/descendant/hostfirewall/push. Os scripts são originais desta revisão e ficam exclusivamente em writeOnly. Os fingerprints cobrem somente a lista técnica permitida, excluídos README do produto, env example e exemplo de política de egress. O hash aprovado de spec vem apenas do packet, que não fornece um caminho de spec autorizado para ler.

## Artefatos e cleanup

`rawcommands-results.jsonl` preserva argv, stdout, stderr, timestamps e exit codes de cada operação Docker do driver; `controls.jsonl` mantém resultados brutos e correção de oracle; `verdict.json` e `frozen-manifest.json` são a saída consolidada. A exploração inicial do packet e dos arquivos técnicos ocorreu pela sessão terminal antes do driver; os fingerprints iniciais e binding de autoridade são seus receipts persistentes, sem alegar que esse JSONL captura tais leituras iniciais.

Foram removidos somente os 24 containers e 13 volumes criados por este driver. `cleanup.json` registra IDs, configurações e ausência posterior de cada objeto. Nenhum prune ou objeto estrangeiro. Terminal receipts, hashes e bytes das mutações permanecem em writeOnly; árvores grandes de runtime não foram copiadas.

Host egress matrix **NOT_QUALIFIED**; real alert receipt **NOT_RUN**; clinical human/Whisper **NOT_RUN**; produção **NO_GO**. O lead certifica o candidato separadamente; esta revisão concede apenas o veredito local REJECT.
