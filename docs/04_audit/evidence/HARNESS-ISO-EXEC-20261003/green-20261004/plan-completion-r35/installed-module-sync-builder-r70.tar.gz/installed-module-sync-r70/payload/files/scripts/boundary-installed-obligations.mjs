// @ts-check
import fs from 'node:fs'
import path from 'node:path'
import { createHash } from 'node:crypto'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

/** @param {Buffer|string} bytes */
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex')
const binarySha256 = hash(fs.readFileSync(process.execPath))
const policySha256 = hash(fs.readFileSync(new URL(import.meta.url)))
const fields = [
  'dependencies',
  'devDependencies',
  'optionalDependencies',
  'peerDependencies'
]
/** @param {string} root @param {string} file */
const inside = (root, file) => {
  const rel = path.relative(root, file)
  return (
    rel === '' ||
    (!rel.startsWith(`..${path.sep}`) && rel !== '..' && !path.isAbsolute(rel))
  )
}

/**
 * Positive certificate for a closed, non-acquiring fragment. It is deliberately
 * not a blacklist of dangerous calls: every complete statement must match.
 * Literal RHS has no lookup/coercion/call/getter. Const names have no uses.
 * CJS module.exports is the fresh standard wrapper's own data property, only
 * under default Node loading and an unshadowed wrapper binding. ESM exports
 * introduce scalar bindings. Primitive throw terminates without construction.
 * Imports, all calls/new, functions, loops, aliases and property reads refuse.
 * @param {typeof import('typescript')} ts
 * @param {string} file
 * @param {Buffer} bytes
 * @param {string} format
 */
function closedCode(ts, file, bytes, format) {
  const source = ts.createSourceFile(
    file,
    bytes.toString('utf8'),
    ts.ScriptTarget.Latest,
    true
  )
  // TypeScript exposes parseDiagnostics at runtime, outside its public d.ts.
  const parseDiagnostics =
    /** @type {import('typescript').SourceFile & {parseDiagnostics: readonly import('typescript').Diagnostic[]}} */ (
      source
    ).parseDiagnostics
  if (
    parseDiagnostics.length ||
    source.referencedFiles.length ||
    source.typeReferenceDirectives.length
  )
    return { complete: false, reason: 'PARSER_OR_DIRECTIVE' }
  /** @param {import('typescript').Expression|undefined} node */
  const scalar = (node) =>
    Boolean(
      node &&
      (ts.isStringLiteral(node) ||
        ts.isNumericLiteral(node) ||
        ts.isBigIntLiteral(node) ||
        ts.isNoSubstitutionTemplateLiteral(node) ||
        [
          ts.SyntaxKind.TrueKeyword,
          ts.SyntaxKind.FalseKeyword,
          ts.SyntaxKind.NullKeyword
        ].includes(node.kind))
    )
  const bindings = new Set()
  const syntax = []
  for (const statement of source.statements) {
    let accepted = ts.isEmptyStatement(statement)
    if (ts.isThrowStatement(statement)) accepted = scalar(statement.expression)
    if (ts.isExpressionStatement(statement)) {
      const expression = statement.expression
      accepted = scalar(expression)
      if (
        ts.isBinaryExpression(expression) &&
        expression.operatorToken.kind === ts.SyntaxKind.EqualsToken
      ) {
        const left = expression.left
        accepted =
          format === 'commonjs' &&
          ts.isPropertyAccessExpression(left) &&
          ts.isIdentifier(left.expression) &&
          left.expression.text === 'module' &&
          left.name.text === 'exports' &&
          scalar(expression.right)
      }
    }
    if (ts.isVariableStatement(statement)) {
      const modifiers = statement.modifiers ?? []
      accepted =
        Boolean(statement.declarationList.flags & ts.NodeFlags.Const) &&
        modifiers.every((item) => item.kind === ts.SyntaxKind.ExportKeyword) &&
        (modifiers.length === 0 ||
          format === 'module' ||
          format === 'source-ts')
      for (const declaration of statement.declarationList.declarations) {
        if (
          !ts.isIdentifier(declaration.name) ||
          declaration.type ||
          declaration.exclamationToken ||
          !scalar(declaration.initializer) ||
          ['module', 'exports', 'require'].includes(declaration.name.text) ||
          bindings.has(declaration.name.text)
        ) {
          accepted = false
        } else bindings.add(declaration.name.text)
      }
    }
    if (ts.isExportAssignment(statement))
      accepted =
        format === 'module' &&
        !statement.isExportEquals &&
        scalar(statement.expression)
    if (!accepted)
      return {
        complete: false,
        reason: ts.SyntaxKind[statement.kind],
        offset: statement.getStart(source)
      }
    syntax.push({
      kind: ts.SyntaxKind[statement.kind],
      start: statement.getStart(source),
      end: statement.end
    })
  }
  return { complete: true, grammar: 'closed-scalar-statements-v1', syntax }
}

/** @typedef {{id:string, edges:Set<string>, unknown:Set<string>, violation:Set<string>, evidence:object[], expanded:boolean, sealed:boolean}} ObligationNode */
/**
 * Internal checker integration, never accepts caller-supplied proof/seal flags.
 * Only the original emitted installed diagnostics are eligible for discharge.
 * @param {{root:string, ts:typeof import('typescript'), graph:Map<string,Set<string>>,
 * metadata:{cache:Map<string,any>, shapeHashes:Map<string,string>, censusInventories:Map<string,string[][]>},
 * diagnostics:any[], diagnosticSources:WeakMap<object,string>,
 * obligations:{file:string, context:string, diagnostic:any}[],
 * declarations:{file:string,field:string,name:string,version:string,context:string|null}[],
 * resolutions:any[], sourceSnapshots:Map<string,string>}} input
 */
export function proveInstalledObligations(input) {
  const {
    root,
    ts,
    graph,
    metadata,
    diagnostics,
    diagnosticSources,
    obligations,
    declarations,
    resolutions,
    sourceSnapshots
  } = input
  const runtime = {
    version: process.version,
    execPath: process.execPath,
    binarySha256,
    platform: process.platform,
    arch: process.arch,
    execArgv: [...process.execArgv],
    ambientNodeOptionsPresent: Boolean(process.env.NODE_OPTIONS),
    ambientNodePathPresent: Boolean(process.env.NODE_PATH),
    standaloneCheckerEntry:
      process.argv[1] ===
      fileURLToPath(new URL('./check-product-boundary.mjs', import.meta.url))
  }
  if (obligations.length === 0)
    return {
      discharged: new Set(),
      report: { obligations: [], runtime, policySha256 }
    }
  /** @type {Map<string,ObligationNode>} */
  const nodes = new Map()
  /** @type {string[]} */
  const pending = []
  /** @param {string} id */
  const node = (id) => {
    if (!nodes.has(id)) {
      nodes.set(id, {
        id,
        edges: new Set(),
        unknown: new Set(),
        violation: new Set(),
        evidence: [],
        expanded: false,
        sealed: false
      })
      pending.push(id)
    }
    return /** @type {ObligationNode} */ (nodes.get(id))
  }
  /** @param {string} from @param {string} to */
  const edge = (from, to) => {
    node(from).edges.add(to)
    node(to)
  }
  /** @param {string} id @param {string} reason */
  const initialUnknown = (id, reason) => node(id).unknown.add(reason)
  const derived = new Set(obligations.map((item) => item.diagnostic))
  const roots = obligations.map((item, index) => {
    const id = `installed:${index}:${JSON.stringify([item.file, item.context, item.diagnostic.specifier, item.diagnostic.mode ?? null])}`
    edge(id, item.file)
    edge(
      id,
      fs.existsSync(path.join(item.context, 'package.json'))
        ? path.join(item.context, 'package.json')
        : item.context
    )
    node(id).evidence.push({
      context: item.context,
      diagnostic: item.diagnostic,
      kind: 'installed-closure'
    })
    return id
  })
  // Runtime policy is read from the actual process, never a user trust flag.
  const hooks = process.execArgv.some((arg) =>
    /^(--(?:experimental-)?loader|--import|--require|-r(?:=|$)|--preserve-symlinks|--experimental-default-type|--experimental-transform-types|--(?:no-)?experimental-require-module(?:=|$))/.test(
      arg
    )
  )
  if (
    !process.version.startsWith('v22.') ||
    hooks ||
    runtime.ambientNodeOptionsPresent ||
    runtime.ambientNodePathPresent ||
    !runtime.standaloneCheckerEntry
  )
    for (const id of roots) initialUnknown(id, 'UNSUPPORTED_RUNTIME_CONTEXT')
  for (const diagnostic of diagnostics) {
    if (derived.has(diagnostic)) continue
    const origin = diagnosticSources.get(diagnostic)
    if (origin) initialUnknown(origin, diagnostic.reason)
    else for (const id of roots) initialUnknown(id, diagnostic.reason)
    if (diagnostic.reason === 'CONSUMER_ENV_IN_CORE')
      for (const id of origin ? [origin] : roots)
        node(id).violation.add(diagnostic.reason)
  }
  // Each declaration has its own identity, including all aliases and fields.
  // Node targets are modal nodes; null is explicitly materialized, never omitted.
  for (const declaration of declarations) {
    const id = `declaration:${JSON.stringify([declaration.file, metadata.shapeHashes.get(declaration.file), declaration.field, declaration.name, declaration.version, declaration.context])}`
    edge(declaration.file, id)
    node(id).evidence.push({
      kind: 'declaration',
      ...declaration,
      manifestSha256: metadata.shapeHashes.get(declaration.file)
    })
    if (!declaration.context) {
      initialUnknown(id, 'MISSING_PHYSICAL_DECLARATION')
      continue
    }
    edge(
      id,
      fs.existsSync(path.join(declaration.context, 'package.json'))
        ? path.join(declaration.context, 'package.json')
        : declaration.context
    )
    const lookup = []
    let selected = false
    for (const directory of createRequire(declaration.file).resolve.paths(
      declaration.name
    ) ?? []) {
      if (!inside(root, directory)) continue
      const candidate = path.join(directory, declaration.name)
      try {
        const stat = fs.lstatSync(candidate)
        const physical = fs.realpathSync(candidate)
        lookup.push({
          candidate,
          physical,
          kind: stat.isSymbolicLink()
            ? 'symlink'
            : stat.isDirectory()
              ? 'directory'
              : 'other'
        })
        if (
          stat.isSymbolicLink() ||
          !stat.isDirectory() ||
          physical !== candidate ||
          physical !== declaration.context
        )
          initialUnknown(id, 'UNVERIFIED_LOOKUP_IDENTITY')
        selected = physical === declaration.context
        break
      } catch (error) {
        if (
          !(error instanceof Error) ||
          /** @type {NodeJS.ErrnoException} */ (error).code !== 'ENOENT'
        )
          initialUnknown(id, 'LOOKUP_ERROR')
        lookup.push({ candidate, absent: true })
      }
    }
    node(id).evidence.push({ kind: 'lookup', lookup })
    if (!selected) initialUnknown(id, 'LOOKUP_NOT_SELECTED')
    for (const mode of ['require', 'import']) {
      const modeId = `${id}:mode:${mode}`
      edge(id, modeId)
      const receipts = resolutions.filter(
        (item) =>
          item.file === declaration.file &&
          item.specifier === declaration.name &&
          item.mode === mode &&
          item.manifestEdge?.field === declaration.field &&
          item.manifestEdge?.version === declaration.version &&
          item.manifestEdge?.nearest === declaration.context
      )
      if (
        receipts.length !== 1 ||
        !receipts[0]?.complete ||
        !receipts[0]?.target
      ) {
        initialUnknown(modeId, 'NULL_OR_MISSING_MODE_TARGET')
        node(modeId).evidence.push({
          kind: 'resolution',
          mode,
          result: 'UNKNOWN',
          receipts
        })
      } else {
        const receipt = receipts[0]
        edge(modeId, receipt.target)
        node(modeId).evidence.push({
          kind: 'resolution',
          mode,
          result: 'TARGET',
          ...receipt
        })
      }
    }
  }
  // Original code/type references remain edges too. This grammar refuses all
  // acquisition syntax, so even a correctly resolved code import is UNKNOWN.
  for (const receipt of resolutions) {
    if (receipt.manifestEdge) continue
    const id = `reference:${JSON.stringify([receipt.file, sourceSnapshots.get(receipt.file), receipt.location, receipt.specifier, receipt.mode])}`
    edge(receipt.file, id)
    node(id).evidence.push({ kind: 'code-resolution', ...receipt })
    if (!receipt.complete || !receipt.target)
      initialUnknown(id, 'NULL_CODE_MODE_TARGET')
    else edge(id, receipt.target)
  }
  // Positive physical receipts are obtained from bytes and census snapshots,
  // not from a clean diagnostics array or metadata.closureStates.complete.
  /** @param {string} file */
  const validatePath = (file) => {
    if (!inside(root, file)) return false
    let cursor = root
    for (const component of path
      .relative(root, file)
      .split(path.sep)
      .filter(Boolean)) {
      cursor = path.join(cursor, component)
      if (fs.lstatSync(cursor).isSymbolicLink()) return false
    }
    return fs.realpathSync(file) === file
  }
  for (let index = 0; index < pending.length; index++) {
    const id = pending[index],
      current = node(id)
    if (index >= 20000) {
      initialUnknown(id, 'FINITE_FRONTIER_LIMIT')
      continue
    }
    for (const target of graph.get(id) ?? []) edge(id, target)
    if (inside(root, id)) {
      try {
        if (!validatePath(id)) initialUnknown(id, 'PHYSICAL_IDENTITY_UNKNOWN')
        if (inside(path.join(root, 'products'), id))
          current.violation.add('CORE_DEPENDS_ON_PRODUCT')
        const stat = fs.lstatSync(id)
        if (!stat.isFile()) {
          initialUnknown(id, 'PACKAGE_JSONLESS_OR_NONFILE')
          current.evidence.push({
            kind: 'nonfile',
            path: id,
            rootManifestAbsent: !fs.existsSync(path.join(id, 'package.json'))
          })
        } else {
          const bytes = fs.readFileSync(id),
            sha256 = hash(bytes)
          if (path.basename(id) === 'package.json') {
            if (metadata.shapeHashes.get(id) !== sha256)
              initialUnknown(id, 'MANIFEST_SNAPSHOT_UNKNOWN_OR_CHANGED')
            const pkg = metadata.cache.get(id)
            if (!pkg) initialUnknown(id, 'UNGOVERNED_MANIFEST')
            else {
              // Resolver currently records physical paths, not query/fragment
              // URL identities. Refuse that context rather than collapsing it.
              if (/[?#]/.test(JSON.stringify([pkg.main, pkg.exports])))
                initialUnknown(id, 'UNSUPPORTED_ENTRY_URL_CONTEXT')
              for (const field of fields)
                for (const [name, version] of Object.entries(pkg[field] ?? {}))
                  if (
                    !declarations.some(
                      (item) =>
                        item.file === id &&
                        item.field === field &&
                        item.name === name &&
                        item.version === version
                    )
                  )
                    initialUnknown(id, 'MISSING_DECLARATION_FRONTIER')
            }
            current.evidence.push({ kind: 'manifest', path: id, sha256 })
          } else {
            if (sourceSnapshots.get(id) !== sha256)
              initialUnknown(id, 'SOURCE_SNAPSHOT_UNKNOWN_OR_CHANGED')
            let scope = path.dirname(id)
            while (
              inside(root, scope) &&
              !fs.existsSync(path.join(scope, 'package.json')) &&
              scope !== root
            )
              scope = path.dirname(scope)
            const scopeManifest = path.join(scope, 'package.json')
            edge(id, scopeManifest)
            const ext = path.extname(id)
            const format =
              ext === '.cjs'
                ? 'commonjs'
                : ext === '.mjs'
                  ? 'module'
                  : ext === '.js'
                    ? (metadata.cache.get(scopeManifest)?.type ?? 'commonjs')
                    : ext === '.ts' && !/\.d\.ts$/.test(id)
                      ? 'source-ts'
                      : 'unsupported'
            const certificate =
              format === 'unsupported'
                ? { complete: false, reason: 'FORMAT' }
                : closedCode(ts, id, bytes, format)
            if (!certificate.complete)
              initialUnknown(
                id,
                `UNSUPPORTED_CODE_GRAMMAR:${certificate.reason}`
              )
            current.evidence.push({
              kind: 'code',
              path: id,
              sha256,
              scopeManifest,
              scopeSha256: metadata.shapeHashes.get(scopeManifest),
              format,
              certificate
            })
          }
        }
      } catch (error) {
        const errno =
          error instanceof Error
            ? /** @type {NodeJS.ErrnoException} */ (error)
            : undefined
        initialUnknown(id, `PHYSICAL_RECEIPT_ERROR:${errno?.code ?? 'UNKNOWN'}`)
      }
    } else if (!/^(installed:|declaration:|reference:)/.test(id))
      initialUnknown(id, 'FOREIGN_OR_UNMATERIALIZED_ENDPOINT')
    current.expanded = true
  }
  // Final identity/census/absence revalidation happens after expansion, before
  // any seal. Repeated cached expansion never creates a seal of its own.
  for (const [directory, expected] of metadata.censusInventories) {
    try {
      const actual = fs
        .readdirSync(directory, { withFileTypes: true })
        .map((entry) => [
          entry.name,
          entry.isDirectory() ? 'directory' : entry.isFile() ? 'file' : 'other'
        ])
        .sort((a, b) => a[0].localeCompare(b[0]))
      if (JSON.stringify(actual) !== JSON.stringify(expected))
        for (const current of nodes.values())
          if (inside(directory, current.id))
            current.unknown.add('CENSUS_CHANGED')
    } catch {
      for (const id of roots) initialUnknown(id, 'CENSUS_REVALIDATION_ERROR')
    }
  }
  for (const current of nodes.values()) {
    for (const evidence of /** @type {any[]} */ (current.evidence)) {
      try {
        if (
          evidence.sha256 &&
          (!validatePath(evidence.path) ||
            hash(fs.readFileSync(evidence.path)) !== evidence.sha256)
        )
          current.unknown.add('BYTES_CHANGED_BEFORE_SEAL')
        for (const lookup of evidence.lookup ?? []) {
          if (lookup.absent) {
            try {
              fs.lstatSync(lookup.candidate)
              current.unknown.add('LOOKUP_ABSENCE_CHANGED')
            } catch (error) {
              if (
                !(error instanceof Error) ||
                /** @type {NodeJS.ErrnoException} */ (error).code !== 'ENOENT'
              )
                current.unknown.add('LOOKUP_REVALIDATION_ERROR')
            }
          } else if (
            !validatePath(lookup.candidate) ||
            fs.realpathSync(lookup.candidate) !== lookup.physical
          )
            current.unknown.add('LOOKUP_CHANGED')
        }
      } catch {
        current.unknown.add('SNAPSHOT_REVALIDATION_ERROR')
      }
    }
    if (!current.expanded) current.unknown.add('UNEXPANDED_FRONTIER')
  }
  // Iterative Kosaraju: no recursive DFS stack or visiting-as-proof shortcut.
  const reverse = new Map([...nodes.keys()].map((id) => [id, new Set()]))
  for (const current of nodes.values())
    for (const target of current.edges) reverse.get(target)?.add(current.id)
  const seen = new Set()
  /** @type {string[]} */
  const order = []
  for (const start of nodes.keys()) {
    if (seen.has(start)) continue
    /** @type {[string,boolean][]} */
    const stack = [[start, false]]
    while (stack.length) {
      const [id, exit] = /** @type {[string,boolean]} */ (stack.pop())
      if (exit) {
        order.push(id)
        continue
      }
      if (seen.has(id)) continue
      seen.add(id)
      stack.push([id, true])
      for (const target of node(id).edges)
        if (!seen.has(target)) stack.push([target, false])
    }
  }
  /** @type {Map<string,number>} */
  const componentOf = new Map()
  /** @type {{members:string[],outgoing:Set<number>,incoming:Set<number>,unknown:Set<string>,violation:Set<string>,settled:boolean}[]} */
  const components = []
  for (const start of order.reverse()) {
    if (componentOf.has(start)) continue
    const members = [],
      stack = [start],
      index = components.length
    componentOf.set(start, index)
    while (stack.length) {
      const id = /** @type {string} */ (stack.pop())
      members.push(id)
      for (const target of reverse.get(id) ?? [])
        if (!componentOf.has(target)) {
          componentOf.set(target, index)
          stack.push(target)
        }
    }
    components.push({
      members,
      outgoing: new Set(),
      incoming: new Set(),
      unknown: new Set(),
      violation: new Set(),
      settled: false
    })
  }
  for (const [id, current] of nodes) {
    const componentIndex = /** @type {number} */ (componentOf.get(id))
    const component = components[componentIndex]
    for (const reason of current.unknown)
      component.unknown.add(`${id}:${reason}`)
    for (const reason of current.violation)
      component.violation.add(`${id}:${reason}`)
    for (const target of current.edges) {
      const successor = /** @type {number} */ (componentOf.get(target))
      if (successor !== componentIndex) {
        component.outgoing.add(successor)
        components[successor].incoming.add(componentIndex)
      }
    }
  }
  const remaining = components.map((component) => component.outgoing.size)
  const ready = remaining.flatMap((count, index) =>
    count === 0 ? [index] : []
  )
  for (let cursor = 0; cursor < ready.length; cursor++) {
    const index = ready[cursor],
      component = components[index]
    component.settled = true
    // A single seal transition, only on complete local and successor receipts.
    if (!component.unknown.size && !component.violation.size)
      for (const id of component.members) node(id).sealed = true
    for (const parentIndex of component.incoming) {
      const parent = components[parentIndex]
      for (const reason of component.unknown) parent.unknown.add(reason)
      for (const reason of component.violation) parent.violation.add(reason)
      if (--remaining[parentIndex] === 0) ready.push(parentIndex)
    }
  }
  const discharged = new Set()
  const outcomes = roots.map((id, index) => {
    const component = components[/** @type {number} */ (componentOf.get(id))]
    const status = component.violation.size
      ? 'VIOLATION'
      : component.unknown.size || !component.settled || !node(id).sealed
        ? 'UNKNOWN'
        : 'PROVED'
    if (status === 'PROVED') discharged.add(obligations[index].diagnostic)
    return {
      id,
      status,
      unknown: [...component.unknown].sort(),
      violations: [...component.violation].sort(),
      sealed: node(id).sealed
    }
  })
  const inventory = [...nodes.values()].map((current) => ({
    ...current,
    edges: [...current.edges].sort(),
    unknown: [...current.unknown].sort(),
    violation: [...current.violation].sort()
  }))
  const snapshotSha256 = hash(JSON.stringify(inventory))
  return {
    discharged,
    report: {
      runtime,
      policySha256,
      snapshotSha256,
      pending: [...nodes.values()]
        .filter((current) => !current.expanded)
        .map((current) => current.id),
      nodeCount: nodes.size,
      dischargedCount: discharged.size,
      obligations: outcomes,
      components: components.map((component) => ({
        members: component.members.sort(),
        outgoing: [...component.outgoing],
        settled: component.settled
      })),
      nodes: inventory
    }
  }
}
