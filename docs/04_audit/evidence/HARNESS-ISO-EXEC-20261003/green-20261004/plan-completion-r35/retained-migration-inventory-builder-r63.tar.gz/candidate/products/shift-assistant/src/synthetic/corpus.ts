import { createHash } from 'node:crypto'
import { lstat, readFile, readdir } from 'node:fs/promises'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { z } from 'zod'
import { ModelGatewayError } from '@cvg/model-gateway'
import { OrganizedSchema, type Organized } from '../domain.ts'
import { CORPUS_FILES, CORPUS_SHA256, SYNTHETIC_FIXTURES } from './manifest.ts'

export const DEFAULT_CORPUS_DIRECTORY = fileURLToPath(
  new URL('../__tests__/fixtures/reliability/', import.meta.url)
)
export function sha256(bytes: string | Uint8Array): string {
  return createHash('sha256').update(bytes).digest('hex')
}
export function deny(message: string): never {
  throw new ModelGatewayError('policy_denied', message)
}
export const FixtureBindingSchema = z.strictObject({
  fixtureId: z.string(),
  corpusSha256: z.literal(CORPUS_SHA256),
  textSha256: z.string().regex(/^[a-f0-9]{64}$/)
})
export type FixtureBinding = z.infer<typeof FixtureBindingSchema>
export function fixtureBinding(fixtureId: string): Readonly<FixtureBinding> {
  const entry = SYNTHETIC_FIXTURES.find((e) => e.id === fixtureId)
  if (!entry) deny('Unknown synthetic fixture identity')
  return Object.freeze({
    fixtureId,
    corpusSha256: CORPUS_SHA256,
    textSha256: entry.textSha256
  })
}
export function assertBinding(value: unknown): FixtureBinding {
  const parsed = FixtureBindingSchema.safeParse(value)
  if (!parsed.success) deny('Invalid synthetic fixture binding')
  const expected = fixtureBinding(parsed.data.fixtureId)
  if (parsed.data.textSha256 !== expected.textSha256)
    deny('Fixture text hash mismatch')
  return parsed.data
}

async function fileNames(root: string, relative = ''): Promise<string[]> {
  const directory = join(root, relative)
  const stat = await lstat(directory)
  if (!stat.isDirectory() || stat.isSymbolicLink())
    deny('Corpus directory must be physical')
  const names: string[] = []
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const path = relative ? `${relative}/${entry.name}` : entry.name
    if (entry.isDirectory()) names.push(...(await fileNames(root, path)))
    else if (entry.isFile()) names.push(path)
    else deny('Corpus contains a non-regular file')
  }
  return names.sort()
}

/** Every original file is checked, including unselected cases and audio. */
export async function loadSyntheticCorpus(
  directory = DEFAULT_CORPUS_DIRECTORY
) {
  try {
    const names = await fileNames(directory)
    const expectedNames = [
      'corpus-manifest.json',
      ...CORPUS_FILES.map((e) => e.path)
    ].sort()
    if (JSON.stringify(names) !== JSON.stringify(expectedNames))
      deny('Corpus file inventory mismatch')
    const manifestBytes = await readFile(
      join(directory, 'corpus-manifest.json')
    )
    if (sha256(manifestBytes) !== CORPUS_SHA256)
      deny('Original corpus manifest hash mismatch')
    const manifest = JSON.parse(manifestBytes.toString('utf8'))
    if (
      manifest.cases.length !== 20 ||
      manifest.files.length !== CORPUS_FILES.length
    )
      deny('Original corpus identity mismatch')
    const texts = new Map<string, string>()
    const references = new Map<string, Organized>()
    for (const entry of CORPUS_FILES) {
      const bytes = await readFile(join(directory, entry.path))
      if (
        bytes.byteLength !== entry.sizeBytes ||
        sha256(bytes) !== entry.sha256
      )
        deny('Original corpus file hash mismatch')
      const fixture = SYNTHETIC_FIXTURES.find((e) => e.path === entry.path)
      if (fixture) {
        const original = manifest.cases.find(
          (e: { id: string }) => e.id === fixture.id
        )
        if (
          !original ||
          original.path !== fixture.path ||
          original.sha256 !== fixture.fileSha256
        )
          deny('Original case manifest binding mismatch')
        const data = JSON.parse(bytes.toString('utf8'))
        if (
          data.id !== fixture.id ||
          data.clockInstant !== fixture.clockInstant ||
          typeof data.input?.rawText !== 'string' ||
          sha256(data.input.rawText) !== fixture.textSha256
        )
          deny('Fixture identity or text hash mismatch')
        texts.set(fixture.id, data.input.rawText)
        if (
          data.expectations !== 'PROPOSED_SPEC0179_AWAITING_HUMAN_REVIEW' ||
          (data.expectedOutput && data.expectedOutput.sourceApproval !== false)
        )
          deny('Unexpected corpus qualification state')
        if (data.expectedOutput?.organizedV1)
          references.set(
            fixture.id,
            OrganizedSchema.parse(data.expectedOutput.organizedV1)
          )
      }
    }
    if (texts.size !== 20) deny('Incomplete synthetic corpus')
    return Object.freeze({
      get(binding: unknown) {
        const valid = assertBinding(binding)
        const entry = SYNTHETIC_FIXTURES.find((e) => e.id === valid.fixtureId)!
        return Object.freeze({
          ...valid,
          rawText: texts.get(entry.id)!,
          clockInstant: entry.clockInstant,
          proposedReference: references.has(entry.id)
            ? structuredClone(references.get(entry.id)!)
            : null,
          humanQualification: 'NOT_RUN' as const
        })
      }
    })
  } catch (error) {
    if (error instanceof ModelGatewayError) throw error
    deny('Synthetic corpus unavailable or malformed')
  }
}
