import { z } from 'zod'
import type { ShiftStore, CommitExpected } from './store.ts'
import type { WhatsAppClient } from './whatsapp.ts'
import type { ShiftAssistant } from './assistant.ts'
import { canonical, sha256 } from './journal.ts'
import type { DeliveryReceipt } from './domain-v2.ts'
const Callback = z.strictObject({
  provider: z.enum(['waha', 'evolution']),
  accountRef: z.string().min(1).max(512),
  providerMessageId: z.string().min(1).max(256),
  recipient: z.string().min(1).max(256),
  deliveryStatus: z.literal('delivery_confirmed'),
  simulation: z.literal(true)
})
/** Raw bytes must independently prove the exact simulator projection. */
export function rawReceiptMatchesCallback(d: DeliveryReceipt): boolean {
  let payload: unknown
  try {
    payload = JSON.parse(d.raw)
  } catch {
    return false
  }
  const parsed = Callback.safeParse(payload)
  if (!parsed.success) return false
  const p = parsed.data
  return (
    p.provider === d.provider &&
    p.accountRef === d.accountRef &&
    p.providerMessageId === d.providerMessageId &&
    p.recipient === d.recipient &&
    p.deliveryStatus === d.deliveryStatus &&
    p.simulation === d.simulation
  )
}
/** Explicit local simulator contract. WAHA/Evolution real receipts remain NOT_QUALIFIED. */
export function recordSimulatedDelivery(
  payload: unknown,
  store: ShiftStore,
  client: WhatsAppClient,
  assistant: ShiftAssistant,
  clock: () => string
): boolean {
  const parsed = Callback.safeParse(payload)
  if (!parsed.success) throw new Error('INVALID_DELIVERY')
  const p = parsed.data
  if (
    p.provider !== client.provider ||
    p.accountRef !== client.session ||
    !assistant.member(p.recipient)
  )
    throw new Error('INVALID_DELIVERY')
  const authority = store.deliveryAuthority(p)
  if (authority.status === 'rejected') throw new Error('INVALID_DELIVERY')
  const eventIdentity = sha256(
    JSON.stringify([
      p.provider,
      p.accountRef,
      p.providerMessageId,
      p.recipient,
      p.deliveryStatus
    ])
  )
  const recorded = store.deliveryRecorded(eventIdentity)
  if (store.deliveryCommitted(eventIdentity)) return false
  const now = clock()
  if (Date.parse(now) < Date.parse(authority.eligibility.startedAt))
    throw new Error('INVALID_DELIVERY')
  const raw = canonical(payload)
  const change = {
    v: 2 as const,
    type: 'delivery_receipt_recorded' as const,
    at: now,
    actor: { kind: 'member' as const, memberPhone: p.recipient },
    receipt: {
      ...p,
      eventIdentity,
      receivedAt: now,
      committedAt: now,
      rawReceiptRef: 'journal:delivery:' + eventIdentity,
      rawSha256: sha256(raw),
      raw,
      commitVerified: false,
      eligibility: authority.eligibility
    }
  }
  const expected: CommitExpected = {}
  for (const [entity, id] of store.references(change)) {
    const map = expected[entity] ?? {}
    map[String(id)] = store.revision(entity, id)
    expected[entity] = map
  }
  if (!recorded)
    store.commit({
      transitionId: 'delivery:' + eventIdentity,
      expected,
      changes: [change]
    })
  // The first commit has completed fsync. This conservative timestamp measures
  // actual durable receipt arrival; the follow-up is a new event, never a rewrite.
  const committedAt = clock()
  const final = {
    v: 2 as const,
    type: 'delivery_receipt_committed' as const,
    at: committedAt,
    actor: change.actor,
    eventIdentity,
    committedAt
  }
  const finalExpected: CommitExpected = {}
  for (const [entity, id] of store.references(final)) {
    const map = finalExpected[entity] ?? {}
    map[String(id)] = store.revision(entity, id)
    finalExpected[entity] = map
  }
  store.commit({
    transitionId: 'delivery-committed:' + eventIdentity,
    expected: finalExpected,
    changes: [final]
  })
  return !recorded
}
