import { toGatewayError } from '@cvg/model-gateway'
import {
  createSyntheticOpenAIRun,
  type SyntheticRunOptions,
  type SyntheticCallEvidence
} from './adapter.ts'
import { authorizeSyntheticPacket } from './packet.ts'
import { loadSyntheticCorpus, type FixtureBinding } from './corpus.ts'
import { validateOrganization } from '../source-evidence.ts'
import type { OrganizedV2 } from '../domain.ts'
import { compareProposedReference } from './reference.ts'

/** No CLI bootstrap or implicit execution. Operator must explicitly invoke it. */
export async function runSyntheticOpenAIPacket(options: {
  packetBytes: string
  humanExecutionReceipt: unknown
  apiKey: string
  corpusDirectory?: string
  signal?: AbortSignal
}) {
  const packet = await authorizeSyntheticPacket(
    options.packetBytes,
    options.humanExecutionReceipt
  )
  const run = await createSyntheticOpenAIRun({ ...options, mode: 'external' })
  return collect(
    run,
    packet.fixtureBindings,
    options.corpusDirectory,
    options.signal
  )
}

/** Local BUILD runner: both HTTP transport and DNS are explicitly mocked. */
export async function runSyntheticOpenAIMock(
  options: Omit<Extract<SyntheticRunOptions, { mode: 'mock' }>, 'mode'> & {
    signal?: AbortSignal
  }
) {
  const run = await createSyntheticOpenAIRun({ ...options, mode: 'mock' })
  return collect(
    run,
    options.fixtureBindings,
    options.corpusDirectory,
    options.signal
  )
}

async function collect(
  run: Awaited<ReturnType<typeof createSyntheticOpenAIRun>>,
  bindings: readonly FixtureBinding[],
  corpusDirectory?: string,
  signal?: AbortSignal
) {
  const corpus = await loadSyntheticCorpus(corpusDirectory)
  const qualifications = new Map<
    string,
    Pick<
      SyntheticCallEvidence,
      'qualification' | 'blockingCount' | 'warningCount' | 'status' | 'code'
    > & { referenceMismatchCount?: number; humanQualification?: 'NOT_RUN' }
  >()
  // Collection evidence is the persistent qualification envelope. Adapter
  // evidence alone describes schema/transport and must not imply source PASS.
  const evidence = () =>
    run
      .evidence()
      .map((e) => Object.freeze({ ...e, ...qualifications.get(e.fixtureId) }))
  const results: Array<{
    binding: FixtureBinding
    organized: OrganizedV2
    sourceValidation: ReturnType<typeof validateOrganization>
  }> = []
  for (const binding of bindings) {
    const fixed = corpus.get(binding)
    let organized: OrganizedV2
    try {
      organized = await run.organizeFixture(binding, signal)
    } catch (error) {
      qualifications.set(binding.fixtureId, {
        status: 'failed',
        qualification: 'FAILED',
        code: toGatewayError(error).code
      })
      return {
        status: 'failed' as const,
        qualification: 'FAILED' as const,
        code: toGatewayError(error).code,
        results,
        evidence: evidence()
      }
    }
    const sourceValidation = validateOrganization(
      fixed.rawText,
      organized,
      [],
      fixed.clockInstant
    )
    const blockingCount = sourceValidation.issues.length
    const warningCount = organized.duvidas.length
    const reference = compareProposedReference(
      organized,
      fixed.proposedReference
    )
    if (blockingCount || warningCount || reference.mismatchCount) {
      const code = blockingCount
        ? 'source_invalid'
        : warningCount
          ? 'source_review_required'
          : 'reference_mismatch'
      qualifications.set(binding.fixtureId, {
        status: 'source_blocked',
        code,
        qualification: 'FAILED',
        blockingCount,
        warningCount,
        referenceMismatchCount: reference.mismatchCount,
        humanQualification: 'NOT_RUN'
      })
      // A V2 schema match never accepts blocking source errors or unresolved
      // questions. Diagnostics stay in memory, outside accepted results.
      return {
        status: 'source_blocked' as const,
        qualification: 'FAILED' as const,
        code,
        results,
        blocked: { binding, sourceValidation },
        evidence: evidence()
      }
    }
    qualifications.set(binding.fixtureId, {
      status: 'validated_v2',
      qualification: 'PASS',
      blockingCount,
      warningCount,
      referenceMismatchCount: 0,
      humanQualification: 'NOT_RUN'
    })
    results.push({ binding, organized, sourceValidation })
  }
  // Persist qualification + evidence only; results/blocked contain diagnostics.
  return {
    status: 'completed' as const,
    qualification: 'PASS' as const,
    results,
    evidence: evidence()
  }
}
