import type { Organized, OrganizedV2 } from '../domain.ts'

// A comparison against the frozen, proposed synthetic reference detects
// omissions. It is an experimental oracle, never a human/clinical approval.
export function compareProposedReference(
  output: OrganizedV2,
  expected: Organized | null
) {
  if (!expected)
    return Object.freeze({
      status: 'UNAVAILABLE' as const,
      mismatchCount: 1,
      mismatchCodes: ['reference_unavailable'],
      humanQualification: 'NOT_RUN' as const
    })
  const mismatches: string[] = []
  if (output.pacientes.length !== expected.pacientes.length)
    mismatches.push('patient_count')
  if (output.pendencias.length !== expected.pendencias.length)
    mismatches.push('task_count')
  const fields = [
    'nome',
    'id',
    'leito',
    'especie',
    'tutor',
    'motivo',
    'evolucao',
    'exames_pedidos',
    'condutas'
  ] as const
  expected.pacientes.forEach((patient, index) => {
    const actual = output.pacientes[index]
    if (!actual) return
    for (const field of fields)
      if (JSON.stringify(actual[field]) !== JSON.stringify(patient[field]))
        mismatches.push(`patient_${index}_${field}`)
  })
  expected.pendencias.forEach((task, index) => {
    const actual = output.pendencias[index]
    if (!actual) return
    if (actual.descricao !== task.descricao)
      mismatches.push(`task_${index}_description`)
    const patient = output.pacientes.find(
      (p) => p.localRef === actual.pacienteRef
    )
    if ((patient?.nome ?? null) !== (task.paciente ?? null))
      mismatches.push(`task_${index}_patient`)
    if (
      actual.quando !== task.quando &&
      !(
        actual.quando &&
        task.quando &&
        Date.parse(actual.quando) === Date.parse(task.quando)
      )
    )
      mismatches.push(`task_${index}_time`)
  })
  return Object.freeze({
    status: mismatches.length ? ('MISMATCH' as const) : ('MATCH' as const),
    mismatchCount: mismatches.length,
    mismatchCodes: mismatches,
    humanQualification: 'NOT_RUN' as const
  })
}
