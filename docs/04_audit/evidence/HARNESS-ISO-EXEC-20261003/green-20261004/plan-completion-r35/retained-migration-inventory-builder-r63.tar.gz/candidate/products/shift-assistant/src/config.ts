import { z } from 'zod'
import { parseMembers, type Member } from './domain.ts'

const EnvSchema = z
  .object({
    SHIFT_PROVIDER: z.enum(['waha', 'evolution']),
    SHIFT_MEMBERS: z.string().min(1),
    SHIFT_WEBHOOK_SECRET: z.string().min(24),
    SHIFT_DATA_DIR: z.string().min(1),
    SHIFT_PORT: z.coerce.number().int().min(0).max(65535).default(3400),
    SHIFT_HOST: z.string().default('0.0.0.0'),
    SHIFT_TICK_SECONDS: z.coerce.number().int().min(1).max(5).default(1),
    SHIFT_SEND_TIMEOUT_MS: z.coerce
      .number()
      .int()
      .min(1000)
      .max(10000)
      .default(10000),
    SHIFT_MEDIA_TIMEOUT_MS: z.coerce
      .number()
      .int()
      .min(1000)
      .max(15000)
      .default(15000),
    SHIFT_WHISPER_TIMEOUT_MS: z.coerce
      .number()
      .int()
      .min(1000)
      .max(120000)
      .default(120000),
    SHIFT_MODEL_TIMEOUT_MS: z.coerce
      .number()
      .int()
      .min(1000)
      .max(60000)
      .default(60000),
    SHIFT_JOB_TIMEOUT_MS: z.coerce
      .number()
      .int()
      .min(1000)
      .max(210000)
      .default(210000),
    SHIFT_SHUTDOWN_TIMEOUT_MS: z.coerce
      .number()
      .int()
      .min(1000)
      .max(10000)
      .default(10000),
    SHIFT_MAX_MEDIA_BYTES: z.coerce
      .number()
      .int()
      .min(1024)
      .max(10485760)
      .default(10485760),
    SHIFT_MAX_PENDING_MESSAGES: z.coerce
      .number()
      .int()
      .min(1)
      .max(1000)
      .default(1000),
    SHIFT_HEALTH_STALE_MS: z.coerce
      .number()
      .int()
      .min(5000)
      .max(30000)
      .default(30000),
    SHIFT_DELIVERY_SIMULATION_SECRET: z.string().min(24).optional(),
    WAHA_URL: z.url().optional(),
    WAHA_API_KEY: z.string().optional(),
    WAHA_SESSION: z.string().default('default'),
    EVOLUTION_URL: z.url().optional(),
    EVOLUTION_API_KEY: z.string().optional(),
    EVOLUTION_INSTANCE: z.string().optional(),
    WHISPER_URL: z.url(),
    WHISPER_MODEL: z.string().default('whisper-1'),
    LLM_BASE_URL: z.url(),
    LLM_API_KEY: z.string().optional(),
    /** `local` only for a model on loopback (demo, self-hosted); default external HTTPS. */
    LLM_LOCATION: z.enum(['external', 'local']).default('external'),
    LLM_MODEL: z.string().min(1)
  })
  .superRefine((env, ctx) => {
    if (
      env.SHIFT_DELIVERY_SIMULATION_SECRET &&
      !['127.0.0.1', '::1', 'localhost'].includes(env.SHIFT_HOST)
    ) {
      ctx.addIssue({
        code: 'custom',
        path: ['SHIFT_DELIVERY_SIMULATION_SECRET'],
        message: 'simulation requires loopback'
      })
    }
    for (const field of [
      'WAHA_URL',
      'EVOLUTION_URL',
      'WHISPER_URL',
      'LLM_BASE_URL'
    ] as const) {
      const value = env[field]
      if (!value) continue
      let u: URL
      try {
        u = new URL(value)
      } catch {
        ctx.addIssue({
          code: 'custom',
          path: [field],
          message: 'invalid origin'
        })
        continue
      }
      if (!['http:', 'https:'].includes(u.protocol) || u.username || u.password)
        ctx.addIssue({
          code: 'custom',
          path: [field],
          message: 'invalid origin'
        })
      if (
        field === 'LLM_BASE_URL' &&
        ((env.LLM_LOCATION === 'external' && u.protocol !== 'https:') ||
          (env.LLM_LOCATION === 'local' &&
            !['127.0.0.1', '[::1]', 'localhost'].includes(u.hostname)))
      )
        ctx.addIssue({
          code: 'custom',
          path: [field],
          message: 'invalid model origin'
        })
      if (
        field === 'WHISPER_URL' &&
        !(
          /^(127\.|10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.)/.test(
            u.hostname
          ) ||
          ['localhost', '[::1]', 'whisper', 'whisper.local'].includes(
            u.hostname
          )
        )
      )
        ctx.addIssue({
          code: 'custom',
          path: [field],
          message: 'Whisper must be local'
        })
    }
    if (env.LLM_LOCATION === 'external' && !env.LLM_API_KEY) {
      ctx.addIssue({ code: 'custom', message: 'LLM_API_KEY is required' })
    }
    if (env.SHIFT_PROVIDER === 'waha' && (!env.WAHA_URL || !env.WAHA_API_KEY)) {
      ctx.addIssue({
        code: 'custom',
        message: 'WAHA_URL and WAHA_API_KEY are required'
      })
    }
    if (
      env.SHIFT_PROVIDER === 'evolution' &&
      (!env.EVOLUTION_URL || !env.EVOLUTION_API_KEY || !env.EVOLUTION_INSTANCE)
    ) {
      ctx.addIssue({
        code: 'custom',
        message:
          'EVOLUTION_URL, EVOLUTION_API_KEY and EVOLUTION_INSTANCE are required'
      })
    }
  })

export type ShiftEnv = z.infer<typeof EnvSchema>

export interface ShiftConfig {
  env: ShiftEnv
  members: Member[]
}

/** Fails closed on any missing or malformed setting; values are never logged. */
export function loadShiftConfig(
  source: Record<string, string | undefined>
): ShiftConfig {
  const parsed = EnvSchema.safeParse(source)
  if (!parsed.success) {
    const fields = parsed.error.issues.map(
      (issue) => issue.path.join('.') || issue.message
    )
    throw new Error(
      `Invalid shift assistant configuration: ${fields.join(', ')}`
    )
  }
  const members = parseMembers(parsed.data.SHIFT_MEMBERS)
  if (members.length === 0) throw new Error('SHIFT_MEMBERS has no members')
  return { env: parsed.data, members }
}

/** Host-only configuration. No environment/webhook flag can approve model use. */
export interface ApprovedModelHostConfig {
  tenantId: string
  costDirectory: string
  authority: 'owner-approved' | 'synthetic-fixture'
  prompt: {
    promptId: 'shift-note'
    version: '1'
    content: string
    sha256: string
    owner: string
    approvedBy: string
    status: 'approved'
    effectiveFrom: string
    effectiveUntil?: string
    classification: 'CLINICAL'
  }
  pricing: {
    inputPer1kUsd: number
    outputPer1kUsd: number
    approvalRef: string
  }
  inputTokenUpperBound: {
    tokens: number
    /** Must cover system/messages AND protocol/tokenizer overhead, never chars/token. */
    evidenceRef: string
    coversProtocol: true
  }
  requestLimitUsd: number
  dailyLimitUsd: number
  restore?: { reconciledHead?: { sequence: number; hash: string } }
}

const HostModelSchema = z
  .object({
    tenantId: z.string().regex(/^tenant_[0-9a-f-]{36}$/),
    costDirectory: z.string().min(1),
    authority: z.enum(['owner-approved', 'synthetic-fixture']),
    prompt: z
      .object({
        promptId: z.literal('shift-note'),
        version: z.literal('1'),
        content: z.string().min(1),
        sha256: z.string().regex(/^[0-9a-f]{64}$/),
        owner: z.string().min(1),
        approvedBy: z.string().min(1),
        status: z.literal('approved'),
        effectiveFrom: z.iso.datetime(),
        effectiveUntil: z.iso.datetime().optional(),
        classification: z.literal('CLINICAL')
      })
      .strict(),
    pricing: z
      .object({
        inputPer1kUsd: z.number().finite().nonnegative(),
        outputPer1kUsd: z.number().finite().nonnegative(),
        approvalRef: z.string().min(1)
      })
      .strict(),
    inputTokenUpperBound: z
      .object({
        tokens: z.number().int().positive().max(1_000_000),
        evidenceRef: z.string().min(1),
        coversProtocol: z.literal(true)
      })
      .strict(),
    requestLimitUsd: z.number().finite().nonnegative().max(1000),
    dailyLimitUsd: z.number().finite().nonnegative(),
    restore: z
      .object({
        reconciledHead: z
          .object({
            sequence: z.number().int().nonnegative(),
            hash: z.string().regex(/^[0-9a-f]{64}$/)
          })
          .strict()
          .optional()
      })
      .strict()
      .optional()
  })
  .strict()

export function validateModelHostConfig(config: ApprovedModelHostConfig): {
  estimatedCostUsd: number
} {
  const parsed = HostModelSchema.safeParse(config)
  if (!parsed.success)
    throw new Error('Invalid approved model host configuration')
  const c = parsed.data
  const estimatedMicro = Math.ceil(
    ((c.inputTokenUpperBound.tokens * c.pricing.inputPer1kUsd) / 1000 +
      (1500 * c.pricing.outputPer1kUsd) / 1000) *
      1_000_000
  )
  if (
    !Number.isSafeInteger(estimatedMicro) ||
    estimatedMicro > Math.floor(c.requestLimitUsd * 1_000_000) ||
    estimatedMicro > Math.floor(c.dailyLimitUsd * 1_000_000) ||
    !Number.isSafeInteger(Math.floor(c.dailyLimitUsd * 1_000_000))
  )
    throw new Error('Model cost ceiling is invalid or insufficient')
  return { estimatedCostUsd: estimatedMicro / 1_000_000 }
}
