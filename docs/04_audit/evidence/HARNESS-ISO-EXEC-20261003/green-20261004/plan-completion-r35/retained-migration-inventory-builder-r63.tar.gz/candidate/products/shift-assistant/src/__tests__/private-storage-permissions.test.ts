// @vitest-environment node
import * as fs from 'node:fs'
import { spawnSync } from 'node:child_process'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { afterEach, expect, it } from 'vitest'
import { ShiftStore } from '../store.ts'

const roots: string[] = []
afterEach(() => {
  for (const root of roots.splice(0))
    fs.rmSync(root, { recursive: true, force: true })
})
it.each([0o002, 0o022, 0o077])(
  'new volume and recovery directories stay 0700 under umask %s in a real Node22 child',
  (mask) => {
    const root = fs.mkdtempSync(join(tmpdir(), 'shift-private-dir-'))
    roots.push(root)
    const source = fileURLToPath(new URL('../store.ts', import.meta.url))
    const program = `
import * as fs from 'node:fs';import {join} from 'node:path';
import {ShiftStore} from ${JSON.stringify(source)};
process.umask(${mask});const dir=process.argv[1];const first=new ShiftStore(dir);
first.append({type:'paused',at:'2026-10-03T12:00:00Z',by:'5511900000009'});first.close();
const manifest=JSON.parse(fs.readFileSync(join(dir,'journal/manifest.json'),'utf8'));
const active=join(dir,manifest.segments.at(-1).path);const original=fs.readFileSync(active);
fs.appendFileSync(active,'incomplete');const second=new ShiftStore(dir);
const available=second.storageAvailable;second.close();
const directories={};function walk(relative=''){for(const name of fs.readdirSync(join(dir,relative))){const p=relative?relative+'/'+name:name;const stat=fs.lstatSync(join(dir,p));if(stat.isDirectory()){directories[p]=stat.mode&511;walk(p)}}}walk();
console.log(JSON.stringify({available,rootMode:fs.statSync(dir).mode&511,directories,originalPreserved:fs.readFileSync(active).equals(Buffer.concat([original,Buffer.from('incomplete')]))}));
`
    const result = spawnSync(
      process.execPath,
      [
        '--import',
        join(process.cwd(), 'node_modules/tsx/dist/loader.mjs'),
        '--input-type=module',
        '-e',
        program,
        join(root, 'volume')
      ],
      { encoding: 'utf8', timeout: 10000 }
    )
    expect(result.status, result.stderr).toBe(0)
    const proof = JSON.parse(result.stdout)
    expect(proof.available).toBe(true)
    expect(proof.originalPreserved).toBe(true)
    expect(proof.rootMode).toBe(0o700)
    expect(
      Object.keys(proof.directories).some((name) =>
        name.startsWith('recovery/')
      )
    ).toBe(true)
    expect(
      Object.values(proof.directories).every((mode) => mode === 0o700)
    ).toBe(true)
  }
)

it('narrows owned existing directories before replay without modifying document bytes', () => {
  const root = fs.mkdtempSync(join(tmpdir(), 'shift-private-existing-'))
  roots.push(root)
  const directory = join(root, 'volume')
  const first = new ShiftStore(directory)
  first.append({
    type: 'paused',
    at: '2026-10-03T12:00:00Z',
    by: '5511900000009'
  })
  first.close()
  const manifest = fs.readFileSync(join(directory, 'journal/manifest.json'))
  for (const relative of [
    '',
    'journal',
    'media',
    'recovery',
    'journal/manifests'
  ])
    fs.chmodSync(join(directory, relative), 0o775)
  const second = new ShiftStore(directory)
  try {
    expect(second.storageAvailable).toBe(true)
    for (const relative of [
      '',
      'journal',
      'media',
      'recovery',
      'journal/manifests'
    ])
      expect(fs.statSync(join(directory, relative)).mode & 0o777).toBe(0o700)
    expect(fs.readFileSync(join(directory, 'journal/manifest.json'))).toEqual(
      manifest
    )
  } finally {
    second.close()
  }
})

it('rejects a symlink ancestor before creating a volume through it', () => {
  const root = fs.mkdtempSync(join(tmpdir(), 'shift-private-symlink-'))
  roots.push(root)
  fs.mkdirSync(join(root, 'actual'))
  fs.symlinkSync(join(root, 'actual'), join(root, 'indirect'))
  expect(() => new ShiftStore(join(root, 'indirect/volume'))).toThrow(
    'STORAGE_UNAVAILABLE'
  )
  expect(fs.existsSync(join(root, 'actual/volume'))).toBe(false)
})
