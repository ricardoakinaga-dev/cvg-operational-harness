import type { ShiftStore } from './store.ts'

/** Compose budget readiness into the existing server's /health/ready response. */
export function withModelBudgetHealth<
  T extends { ready: boolean; effectsEnabled: boolean; reasonCodes: string[] }
>(health: T, budget: { ready: boolean; reasonCodes: string[] }): T {
  return {
    ...health,
    ready: health.ready && budget.ready,
    effectsEnabled: health.effectsEnabled && budget.ready,
    reasonCodes: [...new Set([...health.reasonCodes, ...budget.reasonCodes])]
  }
}
/** Conservative local receipt deadline; provider acceptance alone is insufficient. */
export function deliveryReasonCodes(store: ShiftStore, now: number): string[] {
  const overdue = store.outboxes().some((b) => {
    if (b.purpose !== 'reminder' || b.state === 'cancelled') return false
    const t = store.tasksV2().find((t) => t.number === b.taskNumber)
    if (!t || t.status !== 'open' || t.generation !== b.taskGeneration)
      return false
    const deadline =
      b.slot === 1
        ? Date.parse(t.dueAt) + 60000
        : Date.parse(b.receipt?.at ?? '') + 60000
    return (
      now > deadline &&
      (!b.delivery || Date.parse(b.delivery.committedAt) > deadline)
    )
  })
  return overdue ? ['delivery_overdue'] : []
}
/** Reason transitions drive local counters and redacted alerts; an external monitor is still required. */
export class HealthSignals {
  readonly counts = new Map<string, number>()
  #active = new Set<string>()
  observe(
    reasons: readonly string[],
    alert: (code: string) => void
  ): Record<string, number> {
    for (const code of reasons)
      if (!this.#active.has(code)) {
        this.counts.set(code, (this.counts.get(code) ?? 0) + 1)
        alert(code)
      }
    this.#active = new Set(reasons)
    return Object.fromEntries(this.counts)
  }
}
