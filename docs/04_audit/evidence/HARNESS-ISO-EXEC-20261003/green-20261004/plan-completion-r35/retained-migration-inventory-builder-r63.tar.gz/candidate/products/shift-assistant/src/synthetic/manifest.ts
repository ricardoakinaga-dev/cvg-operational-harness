/* Frozen from the existing reliability corpus, never from incoming messages. */
export const AMENDMENT_SHA256 =
  'a497960b5c4b22ff540dc4a6bfc5bf17399f2739e6d48c91402a4a8b3bd2b4f7'
export const CORPUS_SHA256 =
  'ac8e3de6e2e972cc65af2d8b841b6c8e4d2386e8933bd8e8fb54a88847f217a2'
export const SYNTHETIC_FIXTURES = Object.freeze(
  [
    {
      id: 'SYN-REL-01',
      path: 'cases/case01.json',
      fileSha256:
        '039077daf2b32d3fffc5c683784cb73d7a8e240c4bd5bd553175b5636af10603',
      textSha256:
        '328e3edaa4dcb696c1a81393fff4fa722a1ac4ae426676ad7164f286f95630b7',
      clockInstant: '2026-10-03T17:00:00Z'
    },
    {
      id: 'SYN-REL-02',
      path: 'cases/case02.json',
      fileSha256:
        '8271228ac6731558e0ab2828aabe045f145808ae70a473bcccbf4e8d5b921b73',
      textSha256:
        '51bbf7e4c12c05a2805c4e7190b2015bac67b3d8c5de7bf3315595403b7bff67',
      clockInstant: '2026-10-03T17:00:00Z'
    },
    {
      id: 'SYN-REL-03',
      path: 'cases/case03.json',
      fileSha256:
        '916955b8823c0c1779578bdc4d84c5eb44548ee911de557de6ec55874825b573',
      textSha256:
        'af4a57eedaf9eeb8a51631269105cf3e9c176bff7c7dc42a25d95030048d601c',
      clockInstant: '2026-10-03T17:00:00Z'
    },
    {
      id: 'SYN-REL-04',
      path: 'cases/case04.json',
      fileSha256:
        '4bf9aff131cf8d3ebb9edd825ad70cd95199a7cdb70b8b5e46c3d5f865656edd',
      textSha256:
        '1b505fc8b87feaea79dff990921b7e62ea388784cb35405c0e9c02bb35eb3f06',
      clockInstant: '2026-10-03T17:00:00Z'
    },
    {
      id: 'SYN-REL-05',
      path: 'cases/case05.json',
      fileSha256:
        'ab438621bde055d908427d7863bcfd71a635015de3eb2f14803cfb938eeec377',
      textSha256:
        'dad72ac376e7befb0c01d46b1a38d40972862912bd827d4c492850b9980cd0c9',
      clockInstant: '2026-10-03T17:00:00Z'
    },
    {
      id: 'SYN-REL-06',
      path: 'cases/case06.json',
      fileSha256:
        '59091adc64b436f140de8709e93be960cb9c83a9d93cf54f9ace838c53a3086f',
      textSha256:
        '2535e41b4926feeb8ad55ddaccf4ddda5171941694380ac69016043019e57174',
      clockInstant: '2026-10-03T17:00:00Z'
    },
    {
      id: 'SYN-REL-07',
      path: 'cases/case07.json',
      fileSha256:
        'e496a6c555e84b996836d0c46996266783061a4a0bb0447c916e7e0474813e65',
      textSha256:
        '8b3af95ae0369a0c70666da3e57ad428420725ec81d1b33e44959b7510f1265b',
      clockInstant: '2026-10-03T17:00:00Z'
    },
    {
      id: 'SYN-REL-08',
      path: 'cases/case08.json',
      fileSha256:
        'c0e1bc1c848aa116eb3055015f5ab85491aa6a199c2bd5317426dd92c51cf05c',
      textSha256:
        '5232769c773612f2da3bfa17dd8f1e8e69d59f471114ab23dabab4027abc2442',
      clockInstant: '2026-10-03T17:00:00Z'
    },
    {
      id: 'SYN-REL-09',
      path: 'cases/case09.json',
      fileSha256:
        '3410e21530d33ed5f220afa68f97105a7a0d6a39db78dd41e97bed3567b8e901',
      textSha256:
        'a1724038abe16b0468c233eba778d4188a00680814bcc61d432f1e171441e51b',
      clockInstant: '2026-10-03T17:00:00Z'
    },
    {
      id: 'SYN-REL-10',
      path: 'cases/case10.json',
      fileSha256:
        '5693eb38cd685756d20713a3e083aa719b09c3327cf5bd6a1c4588de871bd03f',
      textSha256:
        '9f21c76c2f08429ad3637187cf2e9acea1ea6391f6843e8604cb503f2c11e883',
      clockInstant: '2026-10-03T17:00:00Z'
    },
    {
      id: 'SYN-REL-11',
      path: 'cases/case11.json',
      fileSha256:
        '3796a88aa1e1c937370e819dceaa1a1e2fcd8faa264196a68c575bb3785c7d32',
      textSha256:
        'e10c473e72f5758844fe4afda1738f9d8d8a15fc36ff691b5529836f26d03f13',
      clockInstant: '2026-10-03T17:00:00Z'
    },
    {
      id: 'SYN-REL-12',
      path: 'cases/case12.json',
      fileSha256:
        '3bb9a8be00ca11c0657427b680a7bb45b232fbef9cdf2dddda1bb626546fe97d',
      textSha256:
        'eab3ce1435fac483b402962f9e10ffcc1925466e23eaac5703bbe47dfbcd220f',
      clockInstant: '2026-10-03T17:00:00Z'
    },
    {
      id: 'SYN-REL-13',
      path: 'cases/case13.json',
      fileSha256:
        '7af65df1c978e2121630125f7ff2c999af26706642bf60f4cb4c8db4078140b9',
      textSha256:
        '85dff1105c6dbce942d8a084b925423bb1745a8d3b4fcd7becca86301045d95d',
      clockInstant: '2026-10-03T17:00:00Z'
    },
    {
      id: 'SYN-REL-14',
      path: 'cases/case14.json',
      fileSha256:
        'e4a81a7b3ef41ea25f2667c2dab8aa5a69430f2f16b5d55cc340e8b624a6a29a',
      textSha256:
        'bfef3a4d8083890becef6e91fc9b8410f56e5f40f9c107fe284332a98121c21d',
      clockInstant: '2026-10-03T17:00:00Z'
    },
    {
      id: 'SYN-REL-15',
      path: 'cases/case15.json',
      fileSha256:
        'f46c30e8324e1b4cdbdef97f58ee0821e074995cac93b45e55773def83452b01',
      textSha256:
        '272591eb55fd3331190939efa93841f2589415ac970f1acba195a527a449281d',
      clockInstant: '2026-10-03T17:00:00Z'
    },
    {
      id: 'SYN-REL-16',
      path: 'cases/case16.json',
      fileSha256:
        '0a6838e0a42d04f83eb3ef4b15f88bbb1165ac328bc3743e1f58f06fb1cf7353',
      textSha256:
        '5e24dd00f4ca1fb8b437de3d2d498a6b122debf5de55ed1ae76801290eeeb7dc',
      clockInstant: '2026-10-03T17:00:00Z'
    },
    {
      id: 'SYN-REL-17',
      path: 'cases/case17.json',
      fileSha256:
        '2436d641ab8be4012e296a0de8a68d9329b60ce01915cc3c83849cb4345fbc7b',
      textSha256:
        '53795bf880fce298340aeea09b950e4e53a1dce8f5e1b4a342eed2bf59623fb1',
      clockInstant: '2026-10-03T17:00:00Z'
    },
    {
      id: 'SYN-REL-18',
      path: 'cases/case18.json',
      fileSha256:
        '333cdf790cbe1c1b1a96b19fcd2a846fea798aac874b221e5346189a8a46f80b',
      textSha256:
        '5b4cdca1d23b30ec3bb65a7608e836ba4c51179257212f3ef95c23d707ad808a',
      clockInstant: '2026-10-03T17:00:00Z'
    },
    {
      id: 'SYN-REL-19',
      path: 'cases/case19.json',
      fileSha256:
        '765675c57b43c9ae1ab7d876472e4418b07eb211be78275d46716642df05e998',
      textSha256:
        '891eaabb8b88325ffecae21714960e1f2284cc41d37ea4120c0be33520cfee52',
      clockInstant: '2026-10-03T17:00:00Z'
    },
    {
      id: 'SYN-REL-20',
      path: 'cases/case20.json',
      fileSha256:
        '569c3437c751910814db7afb4410a0e619c7caddfc6d1ae6769603c0487b105f',
      textSha256:
        'd3897667f134d4026c0d5097a729fdfa58dca07df3fc9a9157e992f53a06b0e0',
      clockInstant: '2026-10-03T17:00:00Z'
    }
  ].map((entry) => Object.freeze(entry))
)
export const CORPUS_FILES = Object.freeze(
  [
    {
      path: 'audio/audio01.txt',
      sha256:
        '5708866592f4bf1058731c3a072e36dad670845425e011a4407882dfbc9d23de',
      sizeBytes: 379
    },
    {
      path: 'audio/audio01.wav',
      sha256:
        '6cdc4dd70b53e3b75f400f5f2696fae9db7ea620da519fb8b3dc59c7dfe5a2b7',
      sizeBytes: 976930
    },
    {
      path: 'audio/audio02.txt',
      sha256:
        '0e46cec1e7592e58ff8898321a4e6ef70d476e4b8950ff498437cfa945e5a168',
      sizeBytes: 375
    },
    {
      path: 'audio/audio02.wav',
      sha256:
        'b5b532f64a602de18b04462462ca3755502d25120a4a5ca822fe5d80fe6afe0a',
      sizeBytes: 882138
    },
    {
      path: 'audio/audio03.txt',
      sha256:
        '2b848a32e67f797826bff392a79df5863e5bdbc2800ccfe68ae3d5882e81ddbc',
      sizeBytes: 405
    },
    {
      path: 'audio/audio03.wav',
      sha256:
        '0ea930505838a11e02be54b368a8abadcaac16ed2d6cbe61b7af91bb5696aefc',
      sizeBytes: 1090964
    },
    {
      path: 'audio/audio04.txt',
      sha256:
        '64cf41e6d1aa92b288ab8c0b13692e44ab54f28d46075ad35a4945cf0325d3bd',
      sizeBytes: 379
    },
    {
      path: 'audio/audio04.wav',
      sha256:
        '515e24a4ecd5701e904ca1bc2e7a4add14297a8a1f72b9f8fdc63d8e7a717d98',
      sizeBytes: 934786
    },
    {
      path: 'audio/audio05.txt',
      sha256:
        'ec64792c78aaad0b8a22980ff6d0067571b344b7982da915fc3bd4f9d6498b24',
      sizeBytes: 374
    },
    {
      path: 'audio/audio05.wav',
      sha256:
        '8d39c6dc7ca6c775581605a3f6d502b6be5fc0aa8006f5e61b6711825ce5201a',
      sizeBytes: 882074
    },
    {
      path: 'audio/audio06.txt',
      sha256:
        'c6170d6025d8a8183b0a83a78934a2b00699aa5e49b2a0f7a7f4fd4cb0a92701',
      sizeBytes: 356
    },
    {
      path: 'audio/audio06.wav',
      sha256:
        'eed2e685c90f9184a0c3f1b2e367e38d7e3fecbe0a0f03e5f5813326d9d5edb5',
      sizeBytes: 989636
    },
    {
      path: 'audio/audio07.txt',
      sha256:
        'f9e9db0062a78649531e118ac08b751eac09c577d0920b831a9c6d411fdadb66',
      sizeBytes: 368
    },
    {
      path: 'audio/audio07.wav',
      sha256:
        '00c8e481aa22ba24da58d2d7ea210c2561a2c62a58ce9d87d64a891f7acf142e',
      sizeBytes: 936750
    },
    {
      path: 'audio/audio08.txt',
      sha256:
        '05484ddaad96270e450f2f6796d3cb8e7525f1f856f9ed4e5ac4d905331d0f6a',
      sizeBytes: 364
    },
    {
      path: 'audio/audio08.wav',
      sha256:
        'b97287abcf233e0ec33a662c7109e64cd3139ab0258167996db8958fddc80f94',
      sizeBytes: 831364
    },
    {
      path: 'audio/audio09.txt',
      sha256:
        '1e69061ec0c9820ee6fa6a66af46f569bdf565497040612fa67f6cb6d89a3aed',
      sizeBytes: 373
    },
    {
      path: 'audio/audio09.wav',
      sha256:
        '83604a224b9066b7003f2b6dcff86a14363f910ccadd9d7f8f2bc8fab0f9414a',
      sizeBytes: 984900
    },
    {
      path: 'audio/audio10.txt',
      sha256:
        '743ef402c193217286348a7533305a96bfef72dda225e1097e88bcd15362d337',
      sizeBytes: 386
    },
    {
      path: 'audio/audio10.wav',
      sha256:
        'fa81b536f8a6655b243a819fe626c7cc3c3f65252ac040f79911913ae8638a37',
      sizeBytes: 944654
    },
    {
      path: 'audio-manifest.json',
      sha256:
        '71cceaee3a18c14dab2d6d99d0b36ddca84ce7674e3f7ca4f4e6d87e285b40f6',
      sizeBytes: 51651
    },
    {
      path: 'cases/case01.json',
      sha256:
        '039077daf2b32d3fffc5c683784cb73d7a8e240c4bd5bd553175b5636af10603',
      sizeBytes: 4640
    },
    {
      path: 'cases/case02.json',
      sha256:
        '8271228ac6731558e0ab2828aabe045f145808ae70a473bcccbf4e8d5b921b73',
      sizeBytes: 4368
    },
    {
      path: 'cases/case03.json',
      sha256:
        '916955b8823c0c1779578bdc4d84c5eb44548ee911de557de6ec55874825b573',
      sizeBytes: 4131
    },
    {
      path: 'cases/case04.json',
      sha256:
        '4bf9aff131cf8d3ebb9edd825ad70cd95199a7cdb70b8b5e46c3d5f865656edd',
      sizeBytes: 5388
    },
    {
      path: 'cases/case05.json',
      sha256:
        'ab438621bde055d908427d7863bcfd71a635015de3eb2f14803cfb938eeec377',
      sizeBytes: 4832
    },
    {
      path: 'cases/case06.json',
      sha256:
        '59091adc64b436f140de8709e93be960cb9c83a9d93cf54f9ace838c53a3086f',
      sizeBytes: 11093
    },
    {
      path: 'cases/case07.json',
      sha256:
        'e496a6c555e84b996836d0c46996266783061a4a0bb0447c916e7e0474813e65',
      sizeBytes: 9359
    },
    {
      path: 'cases/case08.json',
      sha256:
        'c0e1bc1c848aa116eb3055015f5ab85491aa6a199c2bd5317426dd92c51cf05c',
      sizeBytes: 7372
    },
    {
      path: 'cases/case09.json',
      sha256:
        '3410e21530d33ed5f220afa68f97105a7a0d6a39db78dd41e97bed3567b8e901',
      sizeBytes: 6474
    },
    {
      path: 'cases/case10.json',
      sha256:
        '5693eb38cd685756d20713a3e083aa719b09c3327cf5bd6a1c4588de871bd03f',
      sizeBytes: 5364
    },
    {
      path: 'cases/case11.json',
      sha256:
        '3796a88aa1e1c937370e819dceaa1a1e2fcd8faa264196a68c575bb3785c7d32',
      sizeBytes: 4596
    },
    {
      path: 'cases/case12.json',
      sha256:
        '3bb9a8be00ca11c0657427b680a7bb45b232fbef9cdf2dddda1bb626546fe97d',
      sizeBytes: 5215
    },
    {
      path: 'cases/case13.json',
      sha256:
        '7af65df1c978e2121630125f7ff2c999af26706642bf60f4cb4c8db4078140b9',
      sizeBytes: 7704
    },
    {
      path: 'cases/case14.json',
      sha256:
        'e4a81a7b3ef41ea25f2667c2dab8aa5a69430f2f16b5d55cc340e8b624a6a29a',
      sizeBytes: 7552
    },
    {
      path: 'cases/case15.json',
      sha256:
        'f46c30e8324e1b4cdbdef97f58ee0821e074995cac93b45e55773def83452b01',
      sizeBytes: 7553
    },
    {
      path: 'cases/case16.json',
      sha256:
        '0a6838e0a42d04f83eb3ef4b15f88bbb1165ac328bc3743e1f58f06fb1cf7353',
      sizeBytes: 3014
    },
    {
      path: 'cases/case17.json',
      sha256:
        '2436d641ab8be4012e296a0de8a68d9329b60ce01915cc3c83849cb4345fbc7b',
      sizeBytes: 6717
    },
    {
      path: 'cases/case18.json',
      sha256:
        '333cdf790cbe1c1b1a96b19fcd2a846fea798aac874b221e5346189a8a46f80b',
      sizeBytes: 12863
    },
    {
      path: 'cases/case19.json',
      sha256:
        '765675c57b43c9ae1ab7d876472e4418b07eb211be78275d46716642df05e998',
      sizeBytes: 3820
    },
    {
      path: 'cases/case20.json',
      sha256:
        '569c3437c751910814db7afb4410a0e619c7caddfc6d1ae6769603c0487b105f',
      sizeBytes: 9062
    },
    {
      path: 'cases-index.md',
      sha256:
        '2c5a8a1648ddd50cd4c84c0868b8904c4c1172d9fcaf0262f2934ccc87f48991',
      sizeBytes: 6788
    },
    {
      path: 'numeral-equivalence-cases.json',
      sha256:
        '28665a695886b10675fc3b27c43e7bd1e3a6f9e42f727f0ce3b121ad1c78571b',
      sizeBytes: 162616
    },
    {
      path: 'quote-evidence-cases.json',
      sha256:
        '4b6ad2a5ab95162251fe870e1c0444a41a8749d243a1a01496cd3716604f9d22',
      sizeBytes: 34641
    }
  ].map((entry) => Object.freeze(entry))
)
