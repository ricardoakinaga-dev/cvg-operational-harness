import { boundedRequest, strictJson, mediaMime } from './transport-limits.ts'
import type { FetchLike } from './egress.ts'
import type { MediaFile } from './whatsapp.ts'

export interface Transcriber {
  transcribe(audio: MediaFile, signal?: AbortSignal): Promise<string>
}

export interface WhisperOptions {
  /** Local Whisper server exposing the OpenAI-compatible transcription API. */
  baseUrl: string
  model: string
  language: string
  fetch: FetchLike
  timeoutMs?: number
}

const EXTENSIONS: Record<string, string> = {
  'audio/ogg': 'ogg',
  'audio/mpeg': 'mp3',
  'audio/mp4': 'm4a',
  'audio/wav': 'wav',
  'audio/webm': 'webm'
}

/** Whisper running locally (faster-whisper-server, whisper.cpp, LocalAI...). */
export class WhisperTranscriber implements Transcriber {
  readonly #options: WhisperOptions

  constructor(options: WhisperOptions) {
    this.#options = { ...options, baseUrl: options.baseUrl.replace(/\/+$/, '') }
  }

  async transcribe(audio: MediaFile, signal?: AbortSignal): Promise<string> {
    const mimetype = mediaMime(audio.mimetype)
    if (
      !mimetype.startsWith('audio/') ||
      audio.bytes.length > 10485760 ||
      signal?.aborted
    )
      throw new Error('MEDIA_INVALID')
    const form = new FormData()
    form.append(
      'file',
      new Blob([new Uint8Array(audio.bytes)], { type: mimetype }),
      `audio.${EXTENSIONS[mimetype] ?? 'ogg'}`
    )
    form.append('model', this.#options.model)
    form.append('language', this.#options.language)
    form.append('response_format', 'json')
    const { bytes } = await boundedRequest(
      this.#options.fetch,
      `${this.#options.baseUrl}/v1/audio/transcriptions`,
      { method: 'POST', body: form },
      this.#options.timeoutMs ?? 120000,
      262144,
      signal
    )
    const body = strictJson(bytes) as { text?: unknown }
    if (!body || typeof body.text !== 'string' || body.text.length > 16384)
      throw new Error('WHISPER_SCHEMA_INVALID')
    return body.text.trim()
  }
}
