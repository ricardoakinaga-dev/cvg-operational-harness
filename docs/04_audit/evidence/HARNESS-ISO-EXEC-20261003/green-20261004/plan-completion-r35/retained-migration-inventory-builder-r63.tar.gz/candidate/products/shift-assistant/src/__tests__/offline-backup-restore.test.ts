// @vitest-environment node
import * as fs from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import {
  backupStoppedVolume,
  restoreBackup
} from '../../scripts/backup-restore.mjs'
import { ShiftStore } from '../store.ts'
import { sha256 } from '../journal.ts'

const volumes: string[] = []
afterEach(() => {
  for (const directory of volumes.splice(0))
    fs.rmSync(directory, { recursive: true, force: true })
})
function fixture() {
  const root = fs.mkdtempSync(join(tmpdir(), 'shift-backup-'))
  volumes.push(root)
  const source = join(root, 'source')
  const store = new ShiftStore(source)
  store.commit({
    transitionId: 'input:synthetic-1',
    expected: { inbox: { 'synthetic-1': 0 } },
    changes: [
      {
        type: 'message_received',
        at: '2026-10-03T12:00:00.000Z',
        message: {
          provider: 'waha',
          messageId: 'synthetic-1',
          fromPhone: '5511900000001',
          kind: 'text',
          text: 'ajuda',
          receivedAt: '2026-10-03T12:00:00.000Z'
        }
      }
    ]
  })
  store.close()
  fs.writeFileSync(
    join(source, 'media/orphan.bin'),
    Buffer.from([0, 1, 2, 255])
  )
  return {
    root,
    source,
    backup: join(root, 'backup'),
    restored: join(root, 'restored')
  }
}
function documents(root: string, relative = ''): Record<string, string> {
  const result: Record<string, string> = {}
  for (const name of fs.readdirSync(join(root, relative)).sort()) {
    const rel = relative ? relative + '/' + name : name
    if (rel === 'store.lock') continue
    const file = join(root, rel)
    if (fs.statSync(file).isDirectory())
      Object.assign(result, documents(root, rel))
    else result[rel] = sha256(fs.readFileSync(file))
  }
  return result
}
function rewriteManifest(
  backup: string,
  update: (manifest: {
    journal: { sequence: number }
    documents: { path: string; bytes: number; sha256: string }[]
  }) => void
) {
  const file = join(backup, 'manifest.json')
  const manifest = JSON.parse(fs.readFileSync(file, 'utf8'))
  update(manifest)
  fs.writeFileSync(file, JSON.stringify(manifest))
}
describe('offline backup and restoration preserve documents and fail closed', () => {
  it('copies every original byte, orphan, manifest and journal identity into a private new volume', () => {
    const f = fixture()
    const before = documents(f.source)
    const receipt = backupStoppedVolume(f.source, f.backup)
    expect(receipt.status).toBe('backup_verified')
    expect(receipt.originalsPreserved).toBe(true)
    expect(documents(f.source)).toEqual(before)
    expect(documents(join(f.backup, 'documents'))).toEqual(before)
    const manifest = JSON.parse(
      fs.readFileSync(join(f.backup, 'manifest.json'), 'utf8')
    )
    expect(manifest.journal.sequence).toBe(1)
    expect(manifest.journal.journalId).toMatch(/^[a-f0-9-]{36}$/)
    expect(manifest.journal.headSha256).toMatch(/^[a-f0-9]{64}$/)
    const restored = restoreBackup(f.backup, f.restored)
    expect(restored.effectsEnabled).toBe(false)
    const after = documents(f.restored)
    delete after['restore-hold.json']
    expect(after).toEqual(before)
    expect(fs.statSync(f.restored).mode & 0o777).toBe(0o700)
    expect(
      fs.statSync(join(f.restored, 'restore-hold.json')).mode & 0o777
    ).toBe(0o600)
    expect(fs.existsSync(join(f.source, 'store.lock'))).toBe(false)
    expect(fs.existsSync(join(f.restored, 'store.lock'))).toBe(false)
  })
  it('reopens the exact projection under operational hold with effects denied', () => {
    const f = fixture()
    const original = new ShiftStore(f.source)
    const projection = {
      sequence: original.sequence,
      messages: original.unprocessedMessages(),
      notes: original.notesV2(),
      tasks: original.tasksV2(),
      inbox: original.inboxes(),
      outbox: original.outboxes(),
      paused: original.paused
    }
    original.close()
    backupStoppedVolume(f.source, f.backup)
    restoreBackup(f.backup, f.restored)
    const restored = new ShiftStore(f.restored)
    try {
      expect({
        sequence: restored.sequence,
        messages: restored.unprocessedMessages(),
        notes: restored.notesV2(),
        tasks: restored.tasksV2(),
        inbox: restored.inboxes(),
        outbox: restored.outboxes(),
        paused: restored.paused
      }).toEqual(projection)
      expect(restored.operationalHold).toBe(true)
      expect(restored.effectsAllowed).toBe(false)
    } finally {
      restored.close()
    }
  })
  it.each(['active', 'residual'] as const)(
    'refuses %s writer locks and preserves their exact identity',
    (kind) => {
      const f = fixture()
      const writer = kind === 'active' ? new ShiftStore(f.source) : undefined
      if (!writer)
        fs.writeFileSync(
          join(f.source, 'store.lock'),
          'synthetic-residual-lock'
        )
      const before = fs.readFileSync(join(f.source, 'store.lock'))
      try {
        expect(() => backupStoppedVolume(f.source, f.backup)).toThrow()
        expect(fs.readFileSync(join(f.source, 'store.lock'))).toEqual(before)
        expect(fs.existsSync(f.backup)).toBe(false)
      } finally {
        writer?.close()
      }
    }
  )
  it.each(['tampered', 'missing', 'extra', 'symlink'] as const)(
    'rejects %s copied documents before creating the destination',
    (kind) => {
      const f = fixture()
      backupStoppedVolume(f.source, f.backup)
      const file = join(f.backup, 'documents/media/orphan.bin')
      if (kind === 'tampered') fs.appendFileSync(file, 'changed')
      if (kind === 'missing') fs.unlinkSync(file)
      if (kind === 'extra')
        fs.writeFileSync(join(f.backup, 'documents/unlisted'), 'extra')
      if (kind === 'symlink') {
        fs.unlinkSync(file)
        fs.symlinkSync(join(f.source, 'media/orphan.bin'), file)
      }
      expect(() => restoreBackup(f.backup, f.restored)).toThrow()
      expect(fs.existsSync(f.restored)).toBe(false)
    }
  )
  it.each([
    '../outside',
    '/absolute',
    'a\\b',
    'a/../b',
    '.env',
    'key.pem',
    'store.lock'
  ])('refuses unsafe manifest path %s', (name) => {
    const f = fixture()
    backupStoppedVolume(f.source, f.backup)
    rewriteManifest(f.backup, (manifest) => {
      manifest.documents[0]!.path = name
    })
    expect(() => restoreBackup(f.backup, f.restored)).toThrow()
    expect(fs.existsSync(f.restored)).toBe(false)
  })
  it.each(['duplicate', 'missingHash', 'journalIdentity'] as const)(
    'refuses %s manifest declarations',
    (kind) => {
      const f = fixture()
      backupStoppedVolume(f.source, f.backup)
      rewriteManifest(f.backup, (manifest) => {
        if (kind === 'duplicate')
          manifest.documents.push(manifest.documents[0]!)
        if (kind === 'missingHash') manifest.documents[0]!.sha256 = ''
        if (kind === 'journalIdentity') manifest.journal.sequence += 1
      })
      expect(() => restoreBackup(f.backup, f.restored)).toThrow()
      expect(fs.existsSync(f.restored)).toBe(false)
    }
  )
  it('refuses a nonempty destination without overwriting its documents', () => {
    const f = fixture()
    backupStoppedVolume(f.source, f.backup)
    fs.mkdirSync(f.restored)
    fs.writeFileSync(join(f.restored, 'existing'), 'keep')
    expect(() => restoreBackup(f.backup, f.restored)).toThrow(
      'DESTINATION_MUST_BE_EMPTY'
    )
    expect(fs.readFileSync(join(f.restored, 'existing'), 'utf8')).toBe('keep')
  })
  it('refuses backup through symlink parents and configuration-secret filenames', () => {
    const f = fixture()
    const indirect = join(f.root, 'indirect')
    fs.symlinkSync(f.root, indirect)
    expect(() =>
      backupStoppedVolume(f.source, join(indirect, 'escape'))
    ).toThrow('PHYSICAL_DIRECTORY_REQUIRED')
    expect(fs.existsSync(join(f.root, 'escape'))).toBe(false)
    fs.writeFileSync(join(f.source, '.env'), 'synthetic-only')
    expect(() => backupStoppedVolume(f.source, f.backup)).toThrow(
      'CONFIGURATION_SECRET_NOT_A_DOCUMENT'
    )
    expect(fs.existsSync(f.backup)).toBe(false)
    expect(fs.existsSync(join(f.source, 'store.lock'))).toBe(false)
  })
})
