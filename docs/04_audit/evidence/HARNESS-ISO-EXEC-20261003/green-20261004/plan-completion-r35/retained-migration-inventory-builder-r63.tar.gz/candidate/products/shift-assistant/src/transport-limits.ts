import type { FetchLike } from './egress.ts'
export class TransportError extends Error {
  constructor(readonly code: string) {
    super(code)
  }
}
export function deadlineSignal(ms: number, external?: AbortSignal) {
  const controller = new AbortController()
  const abort = () => controller.abort(external?.reason ?? 'cancelled')
  external?.addEventListener('abort', abort, { once: true })
  if (external?.aborted) abort()
  const timer = setTimeout(() => controller.abort('deadline'), ms)
  return {
    signal: controller.signal,
    close() {
      clearTimeout(timer)
      external?.removeEventListener('abort', abort)
    }
  }
}
export function interruptible<T>(
  work: Promise<T>,
  signal: AbortSignal
): Promise<T> {
  return new Promise((resolve, reject) => {
    const abort = () => {
      signal.removeEventListener('abort', abort)
      reject(new TransportError('TRANSPORT_TIMEOUT'))
    }
    if (signal.aborted) {
      work.catch(() => {})
      abort()
      return
    }
    signal.addEventListener('abort', abort, { once: true })
    work.then(
      (v) => {
        signal.removeEventListener('abort', abort)
        resolve(v)
      },
      (e) => {
        signal.removeEventListener('abort', abort)
        reject(e)
      }
    )
  })
}
export async function boundedBody(
  response: Response,
  limit: number,
  signal: AbortSignal
): Promise<Buffer> {
  const encoding = response.headers.get('content-encoding')
  const reader = response.body?.getReader()
  try {
    if (encoding && encoding !== 'identity')
      throw new TransportError('MEDIA_INVALID')
    if (Number(response.headers.get('content-length')) > limit)
      throw new TransportError('RESPONSE_TOO_LARGE')
    const chunks: Uint8Array[] = []
    let size = 0
    if (reader)
      while (true) {
        const { done, value } = await interruptible(reader.read(), signal)
        if (done) break
        size += value.byteLength
        if (size > limit) throw new TransportError('RESPONSE_TOO_LARGE')
        chunks.push(value)
      }
    return Buffer.concat(chunks, size)
  } finally {
    if (reader) {
      void reader.cancel().catch(() => {})
      reader.releaseLock()
    }
  }
}
export async function boundedRequest(
  fetchImpl: FetchLike,
  url: string,
  init: RequestInit,
  ms: number,
  limit: number,
  external?: AbortSignal
) {
  const d = deadlineSignal(ms, external)
  try {
    if (d.signal.aborted) throw new TransportError('TRANSPORT_TIMEOUT')
    const response = await interruptible(
      fetchImpl(url, { ...init, signal: d.signal, redirect: 'manual' }),
      d.signal
    )
    if (!response.ok) {
      void response.body?.cancel().catch(() => {})
      throw new TransportError('TRANSPORT_HTTP_ERROR')
    }
    return { response, bytes: await boundedBody(response, limit, d.signal) }
  } finally {
    d.close()
  }
}
export function strictJson(bytes: Uint8Array): unknown {
  return JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes))
}
const MIMES = new Set([
  'audio/ogg',
  'audio/mpeg',
  'audio/mp4',
  'audio/wav',
  'image/jpeg',
  'image/png'
])
export function mediaMime(value: string | undefined): string {
  const mime = value?.split(';')[0]?.trim().toLowerCase()
  if (!mime || !MIMES.has(mime)) throw new TransportError('MEDIA_INVALID')
  return mime
}
export function decodeBase64(value: string, max: number): Buffer {
  if (value.length > Math.ceil(max / 3) * 4)
    throw new TransportError('MEDIA_TOO_LARGE')
  if (
    !value.length ||
    value.length % 4 ||
    !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(
      value
    )
  )
    throw new TransportError('MEDIA_INVALID')
  const decoded = Buffer.from(value, 'base64')
  if (decoded.length > max) throw new TransportError('MEDIA_TOO_LARGE')
  if (decoded.toString('base64') !== value)
    throw new TransportError('MEDIA_INVALID')
  return decoded
}
