import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

// No apply mode: only owned Docker preparation/cleanup and read-only nft proof.
const SELF = fileURLToPath(import.meta.url)
const TEMPLATE = path.resolve(
  path.dirname(SELF),
  '../deploy/egress-policy.example.nft'
)
const OWNER = 'HARNESS_ISO_GREEN_20261004_PISO007_INFRA'
const LABEL = 'cvg.piso007.owner'
const NODE = '/usr/local/bin/node'
const sha = (value) => createHash('sha256').update(value).digest('hex')
const hashFile = (file) => sha(fs.readFileSync(file))
const now = () => new Date().toISOString()
const jsonFile = (file, value) =>
  fs.writeFileSync(file, JSON.stringify(value, null, 2) + '\n', { mode: 0o600 })
const quote = (text) => "'" + text.replaceAll("'", "'\\''") + "'"

export const RECEIVER = String.raw`
const http = require('node:http'), dgram = require('node:dgram');
const state = {http:0, dnsUdp:0, dnsTcp:0};
const net = require('node:net');
http.createServer((req,res)=>{
  if(req.url === '/stats') return res.end(JSON.stringify(state));
  state.http++; res.end('synthetic-piso007');
}).listen(8080,'0.0.0.0');
const udp=dgram.createSocket('udp4'); udp.on('message',()=>state.dnsUdp++); udp.bind(53,'0.0.0.0');
net.createServer(s=>{state.dnsTcp++;s.end();}).listen(53,'0.0.0.0');
`
export const STATS = String.raw`
const http=require('node:http');
const req=http.get('http://127.0.0.1:8080/stats',r=>{let s='';r.on('data',b=>s+=b);r.on('end',()=>console.log(s));});
req.setTimeout(1500,()=>req.destroy(new Error('stats timeout')));
req.on('error',e=>{console.error(e.message);process.exitCode=1;});
`
export const NATIVE_PROBE = String.raw`
const [kind,host,portText]=process.argv.slice(1), port=Number(portText);
const startedAt=new Date().toISOString();
let done=false, timer;
const finish=(result)=>{if(done)return;done=true;clearTimeout(timer);console.log(JSON.stringify({kind,host,port,startedAt,finishedAt:new Date().toISOString(),...result}));};
if(kind==='http') {
  const http=require('node:http');let body='';
  const req=http.get({host,port,path:'/proof',agent:false},r=>{r.on('data',b=>body+=b);r.on('end',()=>finish({connected:true,status:r.statusCode,body}));});
  timer=setTimeout(()=>{req.destroy();finish({connected:false,timeout:true});},1500);
  req.on('error',e=>finish({connected:false,error:e.code||e.message}));
} else if(kind==='tcp' || kind==='ipv6') {
  const s=require('node:net').createConnection({host,port,family:kind==='ipv6'?6:4});
  timer=setTimeout(()=>{s.destroy();finish({connected:false,timeout:true});},1500);
  s.on('connect',()=>{s.destroy();finish({connected:true});});s.on('error',e=>finish({connected:false,error:e.code||e.message}));
} else if(kind==='udp') {
  const s=require('node:dgram').createSocket('udp4');
  const query=Buffer.from('017901000001000000000000076578616d706c6507696e76616c69640000010001','hex');
  timer=setTimeout(()=>{s.close();finish({connected:false,sent:true,timeout:true});},1500);
  s.on('message',()=>{s.close();finish({connected:true});});
  s.on('error',e=>{s.close();finish({connected:false,error:e.code||e.message});});
  s.send(query,port,host,e=>{if(e){s.close();finish({connected:false,error:e.code||e.message});}});
} else {throw new Error('unknown probe kind');}
`
const IDENTITY = String.raw`
const fs=require('node:fs'),os=require('node:os');
const disabled={};for(const i of fs.readdirSync('/proc/sys/net/ipv6/conf')) disabled[i]=fs.readFileSync('/proc/sys/net/ipv6/conf/'+i+'/disable_ipv6','utf8').trim();
console.log(JSON.stringify({node:process.version,uid:process.getuid(),gid:process.getgid(),interfaces:os.networkInterfaces(),ipv6Disabled:disabled,resolv:fs.readFileSync('/etc/resolv.conf','utf8')}));
`

function command(bin, args, timeout = 12000) {
  const result = spawnSync(bin, args, {
    encoding: 'utf8',
    timeout,
    maxBuffer: 8 * 1024 * 1024
  })
  if (result.error || result.status !== 0) {
    throw new Error(
      `${bin} ${args.slice(0, 5).join(' ')}: exit=${result.status}; ${result.error?.code || result.stderr.trim()}`
    )
  }
  return result.stdout.trim()
}
const docker = (...args) => command('docker', args)
const inspect = (kind, id) => JSON.parse(docker(kind, 'inspect', id))[0]
function observation(bin, args) {
  try {
    return { observedAt: now(), exit: 0, output: command(bin, args) }
  } catch (e) {
    return { observedAt: now(), exit: 1, error: e.message }
  }
}
function hostFacts() {
  const sysctls = {}
  for (const file of [
    '/proc/sys/net/ipv4/ip_forward',
    '/proc/sys/net/ipv6/conf/all/disable_ipv6',
    '/proc/sys/net/bridge/bridge-nf-call-iptables',
    '/proc/sys/net/bridge/bridge-nf-call-ip6tables'
  ]) {
    try {
      sysctls[file] = fs.readFileSync(file, 'utf8').trim()
    } catch (e) {
      sysctls[file] = e.code
    }
  }
  return {
    observedAt: now(),
    node: process.version,
    uid: process.getuid(),
    sysctls,
    dockerVersion: observation('docker', [
      'version',
      '--format',
      '{{.Server.Version}}'
    ]),
    nftVersion: observation('nft', ['--version']),
    nftRead: observation('nft', ['-j', 'list', 'tables']),
    iptablesVersion: observation('iptables', ['--version']),
    routes: observation('ip', ['-j', 'route', 'show'])
  }
}
function validateName(name) {
  assert.match(name, /^cvg-piso007-20261004-[a-f0-9]{8}$/)
}
function validateSubnet(subnet) {
  assert.match(subnet, /^10\.(?:\d{1,3}\.){2}\d{1,3}\/28$/)
  const bytes = subnet.split('/')[0].split('.').map(Number)
  assert(
    bytes.every((n) => n >= 0 && n <= 255) && bytes[3] % 16 === 0,
    'aligned private /28 required'
  )
  return bytes.reduce((n, b) => (n * 256 + b) >>> 0, 0)
}
function ipAt(subnet, offset) {
  const parts = subnet.split('/')[0].split('.')
  parts[3] = String(Number(parts[3]) + offset)
  return parts.join('.')
}
function overlaps(a, b) {
  const [ip, prefixText] = b.split('/'),
    prefix = Number(prefixText)
  if (ip.includes(':')) return false
  const num = ip
    .split('.')
    .reduce((n, byte) => (n * 256 + Number(byte)) >>> 0, 0)
  const mask = prefix === 0 ? 0 : (0xffffffff << (32 - prefix)) >>> 0
  return (
    (a & mask) >>> 0 === (num & mask) >>> 0 ||
    (prefix > 28 && a >>> 4 === num >>> 4)
  )
}
function checkSubnets(source, target) {
  const a = validateSubnet(source),
    b = validateSubnet(target)
  assert.notEqual(a, b)
  const ids = docker('network', 'ls', '-q').split('\n').filter(Boolean)
  for (const id of ids)
    for (const cfg of inspect('network', id).IPAM.Config || []) {
      assert(
        !overlaps(a, cfg.Subnet) && !overlaps(b, cfg.Subnet),
        `subnet overlaps existing Docker network ${id}`
      )
    }
  for (const route of JSON.parse(command('ip', ['-j', 'route', 'show'])))
    if (route.dst !== 'default' && route.dst.includes('/')) {
      assert(
        !overlaps(a, route.dst) && !overlaps(b, route.dst),
        `subnet overlaps host route ${route.dst}`
      )
    }
}

const match = (selector, value) => ['match', selector, value]
const count = (name) => ['counter', name]
function expectedRules(p) {
  const s = p.source.ip,
    b = p.source.bridge,
    r = p.receivers
  return {
    forward: [
      [
        match('meta:iifname', b),
        match('payload:ip:saddr', s),
        ['jump', 'owned_v4']
      ],
      [
        match('meta:iifname', b),
        match('meta:nfproto', 'ipv6'),
        count('ipv6'),
        ['drop']
      ],
      [match('meta:iifname', b), count('wrong_source'), ['drop']],
      [
        match('meta:oifname', b),
        match('payload:ip:daddr', s),
        match('payload:ip:saddr', r.allowed.ip),
        match('ct:state', ['established', 'related']),
        count('reply'),
        ['accept']
      ]
    ],
    input: [[match('meta:iifname', b), count('host_input'), ['drop']]],
    owned_v4: [
      [
        match('payload:ip:daddr', r.allowed.ip),
        match('payload:tcp:dport', 8080),
        count('allow_v4'),
        ['accept']
      ],
      [match('payload:udp:dport', 53), count('dns_udp'), ['drop']],
      [match('payload:tcp:dport', 53), count('dns_tcp'), ['drop']],
      [
        match('payload:ip:daddr', '169.254.169.254'),
        count('metadata'),
        ['drop']
      ],
      [
        match('payload:ip:daddr', r.prohibited.ip),
        count('prohibited'),
        ['drop']
      ],
      [match('payload:ip:daddr', r.model.ip), count('model'), ['drop']],
      [
        match('payload:ip:daddr', r.private.ip),
        count('private_unlisted'),
        ['drop']
      ],
      [count('default_v4'), ['drop']]
    ]
  }
}
const namespaceRules = {
  output: [
    [
      match('meta:oifname', 'lo'),
      match('payload:udp:dport', 53),
      count('embedded_dns_udp'),
      ['drop']
    ],
    [
      match('meta:oifname', 'lo'),
      match('payload:tcp:dport', 53),
      count('embedded_dns_tcp'),
      ['drop']
    ]
  ]
}
function expression(e) {
  assert.equal(Object.keys(e).length, 1, 'ambiguous nft expression')
  if (e.match) {
    const m = e.match,
      left = m.left
    assert(['==', 'in'].includes(m.op), 'unexpected match operator')
    let selector
    if (left.meta) selector = 'meta:' + left.meta.key
    else if (left.payload)
      selector = 'payload:' + left.payload.protocol + ':' + left.payload.field
    else if (left.ct) selector = 'ct:' + left.ct.key
    else throw new Error('unexpected nft selector')
    const right = m.right?.set ? [...m.right.set].sort() : m.right
    return match(selector, right)
  }
  if ('counter' in e) {
    const name = typeof e.counter === 'string' ? e.counter : e.counter?.name
    assert.equal(typeof name, 'string', 'named counters required')
    return count(name)
  }
  if ('jump' in e) return ['jump', e.jump.target]
  if ('accept' in e) return ['accept']
  if ('drop' in e) return ['drop']
  throw new Error('unexpected nft expression')
}
export function assertPolicy(data, p, namespace = false) {
  const table = namespace ? p.namespaceTable : p.table
  const items = data.nftables.filter((o) => !o.metainfo)
  assert(
    items.every((o) => ['table', 'chain', 'rule', 'counter'].some((k) => o[k])),
    'unknown nft object'
  )
  assert.equal(items.filter((o) => o.table).length, 1)
  for (const item of items) {
    const value = item.table || item.chain || item.rule || item.counter
    assert.equal(value.family, 'inet')
    assert.equal(value.table || value.name, table)
  }
  const expected = namespace ? namespaceRules : expectedRules(p)
  const chains = items.filter((o) => o.chain).map((o) => o.chain)
  assert.equal(chains.length, Object.keys(expected).length)
  for (const chain of chains) {
    assert(Object.hasOwn(expected, chain.name))
    if (chain.name !== 'owned_v4') {
      assert.equal(chain.type, 'filter')
      assert.equal(chain.hook, chain.name)
      assert.equal(chain.prio, namespace ? -200 : -10)
      assert.equal(chain.policy, 'accept')
    } else assert(!chain.hook && !chain.type && !chain.policy)
  }
  for (const [chain, rules] of Object.entries(expected)) {
    assert.deepEqual(
      items
        .filter((o) => o.rule?.chain === chain)
        .map((o) => o.rule.expr.map(expression)),
      rules,
      'effective rule mismatch: ' + chain
    )
  }
  const counters = Object.fromEntries(
    items
      .filter((o) => o.counter)
      .map((o) => [o.counter.name, o.counter.packets])
  )
  const names = [
    ...new Set(
      Object.values(expected)
        .flat(2)
        .filter((e) => e[0] === 'counter')
        .map((e) => e[1])
    )
  ].sort()
  assert.deepEqual(Object.keys(counters).sort(), names)
  assert(
    Object.values(counters).every((n) => Number.isSafeInteger(n) && n >= 0),
    'missing/noninteger counters'
  )
  return counters
}
export function assertDockerPriority(data, p) {
  const chains = data.nftables
    .filter((o) => o.chain?.hook === 'forward')
    .map((o) => o.chain)
  const other = chains.filter(
    (c) => c.table !== p.table && ['ip', 'ip6', 'inet'].includes(c.family)
  )
  assert(
    other.length &&
      other.every((c) => Number.isInteger(c.prio) && c.prio > -10),
    'unqualified FORWARD ordering'
  )
  assert(
    data.nftables.some((o) =>
      /docker/i.test(o.chain?.name || o.table?.name || '')
    ),
    'Docker rules absent from observed nft ruleset'
  )
  return other.map(({ family, table, name, prio }) => ({
    family,
    table,
    name,
    prio
  }))
}
export function attempts(p) {
  return [
    {
      id: 'permitted',
      kind: 'http',
      host: p.receivers.allowed.ip,
      port: 8080,
      counter: 'allow_v4',
      positive: true
    },
    {
      id: 'prohibited',
      kind: 'http',
      host: p.receivers.prohibited.ip,
      port: 8080,
      counter: 'prohibited'
    },
    {
      id: 'model_NO_MODEL',
      kind: 'http',
      host: p.receivers.model.ip,
      port: 8080,
      counter: 'model'
    },
    {
      id: 'private_unlisted',
      kind: 'http',
      host: p.receivers.private.ip,
      port: 8080,
      counter: 'private_unlisted'
    },
    {
      id: 'default_deny_port',
      kind: 'tcp',
      host: p.receivers.allowed.ip,
      port: 8081,
      counter: 'default_v4'
    },
    {
      id: 'dns_udp',
      kind: 'udp',
      host: p.receivers.dns.ip,
      port: 53,
      counter: 'dns_udp'
    },
    {
      id: 'dns_tcp',
      kind: 'tcp',
      host: p.receivers.dns.ip,
      port: 53,
      counter: 'dns_tcp'
    },
    {
      id: 'metadata',
      kind: 'tcp',
      host: '169.254.169.254',
      port: 80,
      counter: 'metadata'
    },
    {
      id: 'embedded_dns_udp',
      kind: 'udp',
      host: '127.0.0.11',
      port: 53,
      counter: 'embedded_dns_udp',
      namespace: true
    },
    {
      id: 'embedded_dns_tcp',
      kind: 'tcp',
      host: '127.0.0.11',
      port: 53,
      counter: 'embedded_dns_tcp',
      namespace: true
    },
    {
      id: 'ipv6_disabled',
      kind: 'ipv6',
      host: 'fd00:179::3',
      port: 8080,
      disabledIPv6: true
    }
  ]
}
export function assertAttempt(
  spec,
  result,
  before,
  after,
  receiverBefore,
  receiverAfter
) {
  assert.equal(result.host, spec.host)
  assert.equal(result.port, spec.port)
  assert.equal(result.kind, spec.kind)
  assert(result.startedAt && result.finishedAt)
  if (spec.positive) {
    assert.equal(result.connected, true)
    assert.equal(result.status, 200)
    assert.equal(result.body, 'synthetic-piso007')
  } else assert.equal(result.connected, false)
  if (spec.disabledIPv6)
    assert(
      ['ENETUNREACH', 'EAFNOSUPPORT', 'EADDRNOTAVAIL'].includes(result.error),
      'IPv6 disable must be demonstrated, not inferred from a timeout'
    )
  else
    assert(
      after[spec.counter] > before[spec.counter],
      'missing qualified counter delta: ' + spec.id
    )
  for (const name of Object.keys(receiverBefore)) {
    const expected = structuredClone(receiverBefore[name])
    if (name === 'allowed' && spec.positive) expected.http++
    assert.deepEqual(
      receiverAfter[name],
      expected,
      'unexpected receiver requests: ' + name
    )
  }
}

function ownResource(resource, p, kind) {
  const x = inspect(kind, resource.id)
  assert.equal(x.Id, resource.id)
  const labels = kind === 'network' ? x.Labels : x.Config.Labels
  assert.equal(labels?.[LABEL], OWNER)
  assert.equal(labels?.['cvg.piso007.run'], p.name)
  assert.equal(kind === 'network' ? x.Name : x.Name.slice(1), resource.name)
  return x
}
function verifyResources(p) {
  validateName(p.name)
  const source = ownResource(p.source, p, 'network'),
    target = ownResource(p.target, p, 'network')
  assert.equal(source.Driver, 'bridge')
  assert.equal(target.Driver, 'bridge')
  assert.equal(source.EnableIPv6, false)
  assert.equal(target.EnableIPv6, false)
  assert.equal(source.Internal, false)
  assert.equal(
    source.Options['com.docker.network.bridge.name'],
    p.source.bridge
  )
  assert.equal(
    target.Options['com.docker.network.bridge.name'],
    p.target.bridge
  )
  assert.equal(
    target.Options['com.docker.network.bridge.gateway_mode_ipv4'],
    'routed'
  )
  assert.deepEqual(source.IPAM.Config, p.source.ipam)
  assert.deepEqual(target.IPAM.Config, p.target.ipam)
  for (const network of [source, target]) {
    const allowed = new Set(
      network.Id === source.Id
        ? [p.probe.id]
        : Object.values(p.receivers).map((r) => r.id)
    )
    assert.deepEqual(
      Object.keys(network.Containers || {}).sort(),
      [...allowed].sort(),
      'foreign or missing network endpoint'
    )
  }
  for (const r of [p.probe, ...Object.values(p.receivers)]) {
    const x = ownResource(r, p, 'container')
    assert.equal(x.Image, p.image.id)
    assert.equal(x.Config.User, '10001:10001')
    assert.equal(x.State.Running, true)
    assert.equal(
      sha(JSON.stringify({ config: x.Config, hostConfig: x.HostConfig })),
      r.configDigest,
      'container configuration drift'
    )
    const net = r === p.probe ? p.source : p.target
    assert.deepEqual(Object.keys(x.NetworkSettings.Networks), [net.name])
    assert.equal(x.NetworkSettings.Networks[net.name].NetworkID, net.id)
    assert.equal(x.NetworkSettings.Networks[net.name].IPAddress, r.ip)
    assert.equal(x.NetworkSettings.Networks[net.name].GlobalIPv6Address, '')
    if (r === p.probe)
      assert.equal(
        x.State.Pid,
        p.probe.pid,
        'probe namespace/PID changed: rebuild packet'
      )
  }
  const image = inspect('image', p.image.id)
  assert.equal(
    sha(JSON.stringify(image.Config)),
    p.image.configDigest,
    'image configuration drift'
  )
  return ipv6Identity(p)
}
function ipv6Identity(p) {
  const identity = JSON.parse(docker('exec', p.probe.id, NODE, '-e', IDENTITY))
  assert.match(identity.node, /^v22\./)
  assert.equal(identity.uid, 10001)
  assert.equal(identity.gid, 10001)
  assert(
    Object.values(identity.ipv6Disabled).every((v) => v === '1'),
    'IPv6 not disabled on every namespace interface'
  )
  assert(
    !Object.values(identity.interfaces)
      .flat()
      .some((a) => a.family === 'IPv6')
  )
  assert.equal(
    identity.resolv,
    `nameserver ${p.receivers.dns.ip}\noptions attempts:1 timeout:1\n`
  )
  return identity
}
function loadPacket(file, approvedHash) {
  const full = path.resolve(file),
    p = JSON.parse(fs.readFileSync(full, 'utf8'))
  assert.match(
    approvedHash || '',
    /^[a-f0-9]{64}$/,
    'explicit reviewed packet SHA256 required'
  )
  assert.equal(hashFile(full), approvedHash, 'reviewed packet drift')
  assert.equal(p.schema, 1)
  assert.equal(p.owner, OWNER)
  assert.equal(path.dirname(full), p.out)
  validateName(p.name)
  assert.equal(hashFile(SELF), p.inputs.runner)
  assert.equal(hashFile(TEMPLATE), p.inputs.template)
  for (const [name, digest] of Object.entries(p.files)) {
    assert.equal(path.basename(name), name)
    assert.equal(
      hashFile(path.join(p.out, name)),
      digest,
      'packet file drift: ' + name
    )
  }
  assert.deepEqual(p.plannedAttempts, attempts(p), 'attempt manifest drift')
  assert.deepEqual(p.expectedRules, expectedRules(p))
  assert.deepEqual(p.expectedNamespaceRules, namespaceRules)
  return p
}
function counters(p, namespace = false) {
  const args = [
    '-j',
    'list',
    'table',
    'inet',
    namespace ? p.namespaceTable : p.table
  ]
  const raw = namespace
    ? command('nsenter', [
        '--target',
        String(p.probe.pid),
        '--net',
        'nft',
        ...args
      ])
    : command('nft', args)
  const data = JSON.parse(raw)
  return {
    counts: assertPolicy(data, p, namespace),
    digest: sha(raw),
    data,
    observedAt: now()
  }
}
function applyCheck(p) {
  const identity = verifyResources(p)
  const ruleset = JSON.parse(command('nft', ['-j', 'list', 'ruleset']))
  assert(
    !ruleset.nftables.some(
      (o) => o.table?.family === 'inet' && o.table.name === p.table
    ),
    'owned host table already exists: application refused'
  )
  const forwardOrdering = assertDockerPriority(ruleset, p)
  const namespace = JSON.parse(
    command('nsenter', [
      '--target',
      String(p.probe.pid),
      '--net',
      'nft',
      '-j',
      'list',
      'tables'
    ])
  )
  assert(
    !namespace.nftables.some(
      (o) => o.table?.family === 'inet' && o.table.name === p.namespaceTable
    ),
    'owned namespace table already exists: application refused'
  )
  return {
    status: 'APPLY_INPUTS_MATCH_TABLES_ABSENT_NOT_AUTHORITY',
    identity,
    forwardOrdering,
    packetHash: hashFile(path.join(p.out, 'packet.json'))
  }
}
function receiverCounts(p) {
  return Object.fromEntries(
    Object.entries(p.receivers).map(([name, r]) => [
      name,
      JSON.parse(docker('exec', r.id, NODE, '-e', STATS))
    ])
  )
}
function containerHelperValidation(p) {
  // Validate the exact probe source inside the selected image, on namespace loopback.
  // This never contacts a receiver and cannot qualify forwarded egress.
  const code = `
    const assert=require('node:assert/strict'),http=require('node:http'),cp=require('node:child_process');
    let count=0;
    const server=http.createServer((req,res)=>{count++;res.end('synthetic-piso007');});
    server.listen(0,'127.0.0.1',()=>{
      const child=cp.spawn(process.execPath,['-e',${JSON.stringify(NATIVE_PROBE)},'http','127.0.0.1',String(server.address().port)],{stdio:['ignore','pipe','pipe']});
      let output='',error='';child.stdout.on('data',b=>output+=b);child.stderr.on('data',b=>error+=b);
      const timer=setTimeout(()=>{child.kill('SIGKILL');server.close();process.exitCode=1;},5000);
      child.on('exit',exit=>{clearTimeout(timer);server.close();try{
        assert.equal(exit,0,error);const result=JSON.parse(output);
        assert.equal(result.connected,true);assert.equal(result.body,'synthetic-piso007');assert.equal(count,1);
        console.log(JSON.stringify({status:'SOURCE_HELPER_VALIDATED',node:process.version,uid:process.getuid(),count,result,infrastructureQualification:'NOT_RUN'}));
      }catch(e){console.error(e.message);process.exitCode=1;}});
    });
  `
  return JSON.parse(docker('exec', p.probe.id, NODE, '-e', code))
}
function namespacePolicy(table) {
  return `table inet ${table} {\n counter embedded_dns_udp { }\n counter embedded_dns_tcp { }\n chain output {\n type filter hook output priority -200; policy accept;\n oifname "lo" udp dport 53 counter name embedded_dns_udp drop\n oifname "lo" tcp dport 53 counter name embedded_dns_tcp drop\n }\n}\n`
}

function prepare(opts) {
  assert.match(
    opts.image || '',
    /^cvg-shift-assistant:green-20261004-[a-z0-9-]+$/,
    'explicit own local candidate image required'
  )
  validateName(opts.resource || '')
  const out = path.resolve(opts.out || '')
  assert(
    opts.out && !fs.existsSync(out),
    'fresh explicit output directory required'
  )
  checkSubnets(opts['source-subnet'], opts['receiver-subnet'])
  const image = inspect('image', opts.image)
  assert.equal(image.Config.User, '10001:10001')
  assert(
    !(image.Config.Env || []).some((v) =>
      /^(?:OPENAI_API_KEY|SHIFT_WEBHOOK_SECRET|WAHA_API_KEY|EVOLUTION_API_KEY)=/.test(
        v
      )
    )
  )
  const token = opts.resource.slice(-8)
  fs.mkdirSync(out, { recursive: true, mode: 0o700 })
  const p = {
    schema: 1,
    owner: OWNER,
    name: opts.resource,
    out,
    preparedAt: now(),
    status: 'PREPARED_NOT_QUALIFIED',
    table: 'cvg_piso007_' + token,
    namespaceTable: 'cvg_piso007_dns_' + token,
    inputs: { runner: hashFile(SELF), template: hashFile(TEMPLATE) },
    image: {
      selector: opts.image,
      id: image.Id,
      repoDigests: image.RepoDigests,
      configDigest: sha(JSON.stringify(image.Config))
    },
    source: {
      name: opts.resource + '-source',
      bridge: 'cvgs' + token,
      subnet: opts['source-subnet'],
      ip: ipAt(opts['source-subnet'], 2)
    },
    target: {
      name: opts.resource + '-receivers',
      bridge: 'cvgr' + token,
      subnet: opts['receiver-subnet']
    },
    probe: { name: opts.resource + '-probe' },
    receivers: {},
    files: {}
  }
  jsonFile(path.join(out, 'host-facts.json'), hostFacts())
  const labels = [
    '--label',
    LABEL + '=' + OWNER,
    '--label',
    'cvg.piso007.run=' + p.name
  ]
  try {
    for (const net of [p.source, p.target]) {
      const args = [
        'network',
        'create',
        ...labels,
        '--driver',
        'bridge',
        '--subnet',
        net.subnet,
        '--opt',
        'com.docker.network.bridge.name=' + net.bridge
      ]
      if (net === p.target)
        args.push('--opt', 'com.docker.network.bridge.gateway_mode_ipv4=routed')
      args.push(net.name)
      net.id = docker(...args)
      net.ipam = inspect('network', net.id).IPAM.Config
    }
    let offset = 2
    for (const name of ['allowed', 'prohibited', 'model', 'private', 'dns'])
      p.receivers[name] = {
        name: p.name + '-' + name,
        ip: ipAt(p.target.subnet, offset++)
      }
    fs.writeFileSync(
      path.join(out, 'resolv.conf'),
      `nameserver ${p.receivers.dns.ip}\noptions attempts:1 timeout:1\n`,
      { mode: 0o644 }
    )
    p.probe.ip = p.source.ip
    for (const r of [...Object.values(p.receivers), p.probe]) {
      const probe = r === p.probe
      const args = [
        'create',
        '--name',
        r.name,
        ...labels,
        '--pull',
        'never',
        '--user',
        '10001:10001',
        '--read-only',
        '--cap-drop',
        'ALL',
        '--security-opt',
        'no-new-privileges:true',
        '--memory',
        '128m',
        '--pids-limit',
        '32',
        '--cpus',
        '0.25',
        '--tmpfs',
        '/tmp:rw,noexec,nosuid,nodev,size=16m',
        '--sysctl',
        'net.ipv6.conf.all.disable_ipv6=1',
        '--sysctl',
        'net.ipv6.conf.default.disable_ipv6=1',
        '--network',
        probe ? p.source.name : p.target.name,
        '--ip',
        r.ip,
        '--no-healthcheck',
        '--entrypoint',
        NODE
      ]
      if (probe)
        args.push(
          '--mount',
          `type=bind,src=${path.join(out, 'resolv.conf')},dst=/etc/resolv.conf,readonly`
        )
      else
        args.push(
          '--publish',
          '0.0.0.0::8080/tcp',
          '--publish',
          '0.0.0.0::53/tcp',
          '--publish',
          '0.0.0.0::53/udp'
        )
      args.push(p.image.id, '-e', probe ? 'setInterval(()=>{},1000)' : RECEIVER)
      r.id = docker(...args)
      docker('start', r.id)
      const x = inspect('container', r.id)
      r.configDigest = sha(
        JSON.stringify({ config: x.Config, hostConfig: x.HostConfig })
      )
      if (probe) p.probe.pid = x.State.Pid
    }
    // Startup checks use loopback stats only, which never increments request counts.
    let ready = false
    for (let attempt = 0; attempt < 10; attempt++) {
      try {
        receiverCounts(p)
        ready = true
        break
      } catch (e) {
        if (attempt === 9) throw e
        Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 100)
      }
    }
    assert(ready)
    p.identity = verifyResources(p)
    jsonFile(
      path.join(out, 'helper-validation.json'),
      containerHelperValidation(p)
    )
    const replacements = {
      TABLE: p.table,
      BRIDGE: p.source.bridge,
      SOURCE: p.source.ip,
      ALLOWED: p.receivers.allowed.ip,
      PROHIBITED: p.receivers.prohibited.ip,
      MODEL: p.receivers.model.ip,
      PRIVATE: p.receivers.private.ip
    }
    let policy = fs.readFileSync(TEMPLATE, 'utf8')
    for (const [key, value] of Object.entries(replacements))
      policy = policy.replaceAll('@' + key + '@', value)
    assert(!/@[A-Z]+@/.test(policy))
    fs.writeFileSync(path.join(out, 'host-forward.nft'), policy, {
      mode: 0o600
    })
    fs.writeFileSync(
      path.join(out, 'namespace-dns.nft'),
      namespacePolicy(p.namespaceTable),
      { mode: 0o600 }
    )
    fs.writeFileSync(
      path.join(out, 'rollback-host.nft'),
      `delete table inet ${p.table}\n`,
      { mode: 0o600 }
    )
    fs.writeFileSync(
      path.join(out, 'rollback-namespace.nft'),
      `delete table inet ${p.namespaceTable}\n`,
      { mode: 0o600 }
    )
    const check = `${quote(process.execPath)} ${quote(SELF)} apply-check --packet ${quote(path.join(out, 'packet.json'))} --packet-sha256 "$1"`
    fs.writeFileSync(
      path.join(out, 'apply-planned-only.sh'),
      `#!/bin/sh\n# DO NOT EXECUTE BEFORE FINAL T4 AUTHORITY. No authority is granted by this file.\nset -eu\n${check}\nnft --check --file ${quote(path.join(out, 'host-forward.nft'))}\nnsenter --target ${p.probe.pid} --net nft --check --file ${quote(path.join(out, 'namespace-dns.nft'))}\n# Fresh table names: no replacement/flush of any preexisting policy.\nnft --file ${quote(path.join(out, 'host-forward.nft'))}\nnsenter --target ${p.probe.pid} --net nft --file ${quote(path.join(out, 'namespace-dns.nft'))}\n# A partial apply is NOT qualified; leave source idle or stop it for recovery.\n`,
      { mode: 0o600 }
    )
    for (const name of [
      'host-facts.json',
      'helper-validation.json',
      'resolv.conf',
      'host-forward.nft',
      'namespace-dns.nft',
      'rollback-host.nft',
      'rollback-namespace.nft',
      'apply-planned-only.sh'
    ])
      p.files[name] = hashFile(path.join(out, name))
    p.expectedRules = expectedRules(p)
    p.expectedNamespaceRules = namespaceRules
    p.plannedAttempts = attempts(p)
    p.modelRelay = {
      status: 'PROPOSED_ONLY_NOT_ENABLED',
      proposedListener: { ip: p.receivers.model.ip, port: 8443 },
      upstreamFixedEndpoint: 'PENDING_SEPARATE_D2_T4',
      fixedDestinationRequired: true,
      arbitraryConnectForbidden: true,
      clinical: 'NO_MODEL'
    }
    jsonFile(path.join(out, 'packet.json'), p)
    const packetHash = hashFile(path.join(out, 'packet.json'))
    fs.writeFileSync(
      path.join(out, 'packet.sha256'),
      packetHash + '  packet.json\n',
      { mode: 0o600 }
    )
    jsonFile(path.join(out, 'preparation.json'), {
      status: p.status,
      exit: 0,
      packetHash,
      finishedAt: now(),
      receiverCounts: receiverCounts(p),
      qualification: 'NOT_RUN',
      appliedFirewall: false
    })
    return {
      status: p.status,
      packet: path.join(out, 'packet.json'),
      packetHash
    }
  } catch (e) {
    jsonFile(path.join(out, 'preparation-failure.json'), {
      status: 'FAIL',
      error: e.message,
      partialResources: p,
      finishedAt: now()
    })
    // Preserve exact IDs for own-only cleanup; no name-based cleanup or foreign mutations.
    for (const r of [p.probe, ...Object.values(p.receivers)].filter(
      (r) => r.id
    )) {
      ownResource(r, p, 'container')
      docker('rm', '--force', '--volumes', r.id)
    }
    for (const r of [p.source, p.target].filter((r) => r.id)) {
      ownResource(r, p, 'network')
      docker('network', 'rm', r.id)
    }
    throw e
  }
}
function qualify(p, reportPath) {
  const report = {
    status: 'NOT_RUN',
    startedAt: now(),
    packetHash: hashFile(path.join(p.out, 'packet.json')),
    inputs: p.inputs,
    image: p.image,
    source: p.source,
    target: p.target,
    attempts: p.plannedAttempts.map((a) => ({ ...a, status: 'NOT_RUN' })),
    limits: [
      'synthetic infrastructure only; no provider, relay TLS or production qualification'
    ]
  }
  let attempted = false
  try {
    report.identity = verifyResources(p)
    const initialHost = counters(p),
      initialNamespace = counters(p, true)
    report.initialHostPolicy = initialHost
    report.initialNamespacePolicy = initialNamespace
    const ruleset = JSON.parse(command('nft', ['-j', 'list', 'ruleset']))
    report.rulesetDigest = sha(JSON.stringify(ruleset))
    report.forwardOrdering = assertDockerPriority(ruleset, p)
    const initialReceivers = receiverCounts(p)
    assert(
      Object.values(initialReceivers).every(
        (r) => r.http === 0 && r.dnsTcp === 0 && r.dnsUdp === 0
      ),
      'nonzero receiver baseline: prepare fresh resources'
    )
    report.initialReceiverCounts = initialReceivers
    for (let i = 0; i < p.plannedAttempts.length; i++) {
      verifyResources(p)
      const spec = p.plannedAttempts[i],
        before = counters(p, Boolean(spec.namespace)),
        receiversBefore = receiverCounts(p)
      attempted = true
      report.attempts[i] = {
        ...spec,
        status: 'FAIL',
        initiatedAt: now(),
        before,
        receiversBefore
      }
      const result = JSON.parse(
        docker(
          'exec',
          p.probe.id,
          NODE,
          '-e',
          NATIVE_PROBE,
          spec.kind,
          spec.host,
          String(spec.port)
        )
      )
      const after = counters(p, Boolean(spec.namespace)),
        receiversAfter = receiverCounts(p)
      report.attempts[i] = {
        ...spec,
        status: 'FAIL',
        result,
        before,
        after,
        receiversBefore,
        receiversAfter
      }
      assertAttempt(
        spec,
        result,
        before.counts,
        after.counts,
        receiversBefore,
        receiversAfter
      )
      report.attempts[i].status = 'PASS'
    }
    report.finalIdentity = verifyResources(p)
    report.finalHostPolicy = counters(p)
    report.finalNamespacePolicy = counters(p, true)
    report.finalReceiverCounts = receiverCounts(p)
    assert.equal(report.finalReceiverCounts.allowed.http, 1)
    report.status = 'PASS'
    report.exit = 0
  } catch (e) {
    report.status = attempted ? 'FAIL' : 'NOT_RUN'
    report.exit = attempted ? 1 : 2
    report.error = e.message
  }
  report.finishedAt = now()
  jsonFile(reportPath, report)
  return {
    status: report.status,
    exit: report.exit,
    report: reportPath,
    error: report.error
  }
}
function cleanup(p) {
  // Stop the originating namespace before removing any fixture. Never remove nft tables here.
  for (const r of [p.probe, ...Object.values(p.receivers)])
    ownResource(r, p, 'container')
  for (const r of [p.source, p.target]) {
    const x = ownResource(r, p, 'network'),
      expected = new Set(
        r === p.source
          ? [p.probe.id]
          : Object.values(p.receivers).map((c) => c.id)
      )
    assert(
      Object.keys(x.Containers || {}).every((id) => expected.has(id)),
      'foreign network endpoint: cleanup refused'
    )
  }
  for (const r of [p.probe, ...Object.values(p.receivers)])
    docker('rm', '--force', '--volumes', r.id)
  for (const r of [p.source, p.target]) docker('network', 'rm', r.id)
  const result = {
    status: 'OWN_RESOURCES_REMOVED',
    finishedAt: now(),
    hostFirewallChanged: false,
    namespaceFirewallRemovedWithContainer: true,
    hostTableRequiresApprovedNarrowRollback: p.table
  }
  jsonFile(path.join(p.out, 'cleanup.json'), result)
  return result
}
function cli() {
  assert.match(process.version, /^v22\./, 'Node22 required')
  const [mode, ...args] = process.argv.slice(2),
    opts = {}
  assert(
    ['prepare', 'plan-check', 'apply-check', 'qualify', 'cleanup'].includes(
      mode
    ),
    'Usage: prepare --image <own-local-image> --resource cvg-piso007-20261004-<8hex> --source-subnet <private/28> --receiver-subnet <private/28> --out <fresh-dir>; plan-check|qualify|cleanup --packet <packet.json> --packet-sha256 <reviewed-hash> [--report <new-report.json>]'
  )
  assert.equal(args.length % 2, 0)
  for (let i = 0; i < args.length; i += 2) {
    assert.match(args[i], /^--[a-z0-9-]+$/)
    assert(!Object.hasOwn(opts, args[i].slice(2)))
    opts[args[i].slice(2)] = args[i + 1]
  }
  const allowed =
    mode === 'prepare'
      ? ['image', 'resource', 'source-subnet', 'receiver-subnet', 'out']
      : mode === 'qualify'
        ? ['packet', 'packet-sha256', 'report']
        : ['packet', 'packet-sha256']
  assert(
    Object.keys(opts).every((k) => allowed.includes(k)),
    'unexpected option'
  )
  let result
  if (mode === 'prepare') result = prepare(opts)
  else {
    assert(opts.packet, 'explicit own packet required')
    const p = loadPacket(opts.packet, opts['packet-sha256'])
    if (mode === 'plan-check') {
      const identity = verifyResources(p)
      result = {
        status: 'PLAN_INPUTS_MATCH_NOT_QUALIFIED',
        identity,
        packetHash: hashFile(opts.packet)
      }
    } else if (mode === 'apply-check') result = applyCheck(p)
    else if (mode === 'cleanup') result = cleanup(p)
    else {
      assert(
        opts.report && !fs.existsSync(opts.report),
        'fresh explicit report required'
      )
      result = qualify(p, opts.report)
      process.exitCode = result.exit
    }
  }
  process.stdout.write(JSON.stringify(result) + '\n')
}
if (process.argv[1] && path.resolve(process.argv[1]) === SELF) {
  try {
    cli()
  } catch (e) {
    process.stderr.write(
      JSON.stringify({ status: 'FAIL', error: e.message, observedAt: now() }) +
        '\n'
    )
    process.exitCode = 1
  }
}
