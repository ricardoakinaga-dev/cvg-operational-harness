// @vitest-environment node
import { createServer } from 'node:http'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import type { AddressInfo } from 'node:net'
import { afterEach, expect, it, vi } from 'vitest'
import { composeShiftApp, type ShiftApp } from '../compose.ts'
import { loadShiftConfig } from '../config.ts'

const PHONE = '5511900000001',
  MANAGER = '5511900000009'
const SECRET = 'late-receipt-synthetic-secret'
const cleanup: Array<() => void | Promise<void>> = []
afterEach(async () => {
  vi.restoreAllMocks()
  for (const close of cleanup.splice(0).reverse()) await close()
})
async function fixture(unproven = false) {
  const directory = mkdtempSync(join(tmpdir(), 'ops-r5-'))
  cleanup.push(() => rmSync(directory, { recursive: true, force: true }))
  let requests = 0
  const receiver = createServer(async (request, response) => {
    for await (const chunk of request) void chunk
    requests++
    response.writeHead(201, { 'content-type': 'application/json' })
    response.flushHeaders() // Actual accepted HTTP exchange, unknown final id.
  })
  await new Promise<void>((resolve) => receiver.listen(0, '127.0.0.1', resolve))
  cleanup.push(async () => {
    receiver.closeAllConnections()
    await new Promise<void>((resolve) => receiver.close(() => resolve()))
  })
  const base = `http://127.0.0.1:${(receiver.address() as AddressInfo).port}`
  const open = async (account = 'account-A') => {
    const app = composeShiftApp(
      loadShiftConfig({
        SHIFT_PROVIDER: 'waha',
        SHIFT_MEMBERS: `${PHONE}=Ficticio;${MANAGER}=Gestor*`,
        SHIFT_WEBHOOK_SECRET: SECRET,
        SHIFT_DELIVERY_SIMULATION_SECRET: SECRET,
        SHIFT_DATA_DIR: directory,
        SHIFT_PORT: '0',
        SHIFT_HOST: '127.0.0.1',
        SHIFT_SEND_TIMEOUT_MS: '1000',
        WAHA_URL: base,
        WAHA_API_KEY: 'synthetic',
        WAHA_SESSION: account,
        WHISPER_URL: 'http://127.0.0.1:2',
        LLM_BASE_URL: 'http://127.0.0.1:3',
        LLM_MODEL: 'synthetic',
        LLM_LOCATION: 'local'
      }),
      { fetchImpl: (url, init) => fetch(url, init) }
    )
    cleanup.push(() => app.stop())
    return { app, url: `http://127.0.0.1:${await app.start()}` }
  }
  const initial = await open()
  if (unproven) {
    const commit = initial.app.store.commit.bind(initial.app.store)
    vi.spyOn(initial.app.store, 'commit').mockImplementation((request) => {
      const copy = structuredClone(request)
      for (const event of copy.changes)
        if (
          'v' in event &&
          event.v === 2 &&
          event.type === 'outbox_dispatch_started'
        )
          event.identity = null
      return commit(copy)
    })
  }
  initial.app.assistant.receive({
    provider: 'waha',
    messageId: 'late-source',
    fromPhone: PHONE,
    kind: 'text',
    text: 'ajuda',
    receivedAt: new Date().toISOString()
  })
  await initial.app.assistant.idle()
  expect(requests).toBe(1)
  expect(initial.app.store.outboxes()[0]?.state).toBe('uncertain')
  return { ...initial, open, requests: () => requests }
}
async function callback(url: string, overrides: Record<string, string> = {}) {
  const response = await fetch(url + '/callbacks/delivery-simulation', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-cvg-webhook-secret': SECRET
    },
    body: JSON.stringify({
      provider: 'waha',
      accountRef: 'account-A',
      providerMessageId: 'late-id',
      recipient: PHONE,
      deliveryStatus: 'delivery_confirmed',
      simulation: true,
      ...overrides
    })
  })
  await response.arrayBuffer()
  return response.status
}
function pendingOnly(app: ShiftApp) {
  expect(app.store.outboxes()[0]?.state).toBe('uncertain')
  expect(app.store.outboxes()[0]?.delivery).toBeUndefined()
  expect(app.store.deliveries()).toHaveLength(1)
  expect(app.store.deliveries()[0]?.commitVerified).toBe(true)
}
it('durably stages a late authenticated callback after real socket timeout without confirming, retrying or rewriting the uncertain effect, including restart', async () => {
  const f = await fixture()
  expect(await callback(f.url)).toBe(200)
  pendingOnly(f.app)
  const sequence = f.app.store.sequence
  expect(await callback(f.url)).toBe(200)
  expect(f.app.store.sequence).toBe(sequence)
  await f.app.stop()
  const reopened = await f.open()
  pendingOnly(reopened.app)
  expect(reopened.app.store.sequence).toBe(sequence)
  expect(await callback(reopened.url)).toBe(200)
  expect(reopened.app.store.sequence).toBe(sequence)
  expect(f.requests()).toBe(1)
})
it('denies wrong account, provider, recipient and a newly configured account for an old uncertain send with no journal effect', async () => {
  const f = await fixture()
  for (const overrides of [
    { accountRef: 'account-B' },
    { provider: 'evolution' },
    { recipient: MANAGER }
  ]) {
    const sequence = f.app.store.sequence
    expect(await callback(f.url, overrides)).toBe(400)
    expect(f.app.store.sequence).toBe(sequence)
  }
  await f.app.stop()
  const reopened = await f.open('account-B')
  const sequence = reopened.app.store.sequence
  expect(await callback(reopened.url, { accountRef: 'account-B' })).toBe(400)
  expect(reopened.app.store.sequence).toBe(sequence)
  expect(f.requests()).toBe(1)
})
it('denies an explicitly unproven uncertain send rather than assigning the current transport', async () => {
  const f = await fixture(true)
  const sequence = f.app.store.sequence
  expect(await callback(f.url)).toBe(400)
  expect(f.app.store.sequence).toBe(sequence)
  expect(f.app.store.deliveries()).toHaveLength(0)
})
