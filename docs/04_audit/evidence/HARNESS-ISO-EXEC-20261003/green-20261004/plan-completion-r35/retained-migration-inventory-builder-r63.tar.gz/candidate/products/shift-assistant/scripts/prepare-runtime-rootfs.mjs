import fs from 'node:fs'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { rootCertificates } from 'node:tls'

// Build-time only. Copies exactly Node's ELF dependencies and CA roots into
// a new scratch filesystem; no shell, package manager or host executables.
const root = process.argv[2]
if (!root || !path.isAbsolute(root) || fs.existsSync(root))
  throw new Error('New absolute runtime directory required')
fs.mkdirSync(root, { mode: 0o755 })
const copied = new Set()
function copy(source) {
  if (!path.isAbsolute(source))
    throw new Error('Absolute runtime input required')
  const destination = path.join(root, source)
  fs.mkdirSync(path.dirname(destination), { recursive: true })
  // Dereference ELF dependency symlinks so the scratch path is self-contained.
  fs.copyFileSync(source, destination)
  fs.chmodSync(destination, fs.statSync(source).mode & 0o777)
  copied.add(source)
}
const binary = fs.realpathSync(process.execPath)
const ldd = spawnSync('ldd', [binary], { encoding: 'utf8' })
if (ldd.status !== 0) throw new Error('Node ELF dependencies unavailable')
for (const line of ldd.stdout.split('\n')) {
  if (line.includes('not found')) throw new Error('Missing Node ELF dependency')
  const match = line.match(/(?:=>\s*)?(\/[^\s]+)\s+\(/)
  if (match) copy(match[1])
}
const node = '/usr/local/bin/node'
fs.mkdirSync(path.join(root, '/usr/local/bin'), { recursive: true })
fs.copyFileSync(binary, path.join(root, node))
fs.chmodSync(path.join(root, node), 0o755)
copied.add(node)
const caPath = '/etc/ssl/certs/ca-certificates.crt'
fs.mkdirSync(path.dirname(path.join(root, caPath)), { recursive: true })
if (!rootCertificates.length)
  throw new Error('Pinned Node CA roots unavailable')
fs.writeFileSync(path.join(root, caPath), rootCertificates.join('\n') + '\n')
copied.add(caPath)
for (const name of ['app', 'data', 'tmp', 'etc'])
  fs.mkdirSync(path.join(root, name), {
    recursive: true,
    mode: name === 'data' ? 0o700 : 0o755
  })
fs.chownSync(path.join(root, 'data'), 10001, 10001)
fs.chmodSync(path.join(root, 'tmp'), 0o1777)
fs.writeFileSync(
  path.join(root, 'etc/passwd'),
  'cvg:x:10001:10001:CVG:/app:/nonexistent\n'
)
fs.writeFileSync(path.join(root, 'etc/group'), 'cvg:x:10001:\n')
fs.writeFileSync(path.join(root, 'etc/nsswitch.conf'), 'hosts: files dns\n')
fs.writeFileSync(
  path.join(root, 'app/runtime-files.json'),
  JSON.stringify(
    {
      node: process.version,
      files: [...copied].sort(),
      owner: '10001:10001',
      shell: false
    },
    null,
    2
  ) + '\n'
)
