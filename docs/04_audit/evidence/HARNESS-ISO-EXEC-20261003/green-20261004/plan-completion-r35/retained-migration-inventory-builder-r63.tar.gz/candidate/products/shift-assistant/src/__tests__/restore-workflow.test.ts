// @vitest-environment node
import * as fs from 'node:fs'
import { createServer, type Server } from 'node:http'
import type { AddressInfo } from 'node:net'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, expect, it } from 'vitest'
import { ShiftStore } from '../store.ts'
import { ShiftAssistant } from '../assistant.ts'
import { WahaClient } from '../whatsapp.ts'
import { buildShiftServer } from '../server.ts'
import { RAW, staticOrganizer } from './vertical-test-fixture.ts'
import {
  backupStoppedVolume,
  restoreBackup
} from '../../scripts/backup-restore.mjs'
import type { JournalManifest } from '../journal.ts'

const ANA = '5511900000001',
  BRUNO = '5511900000002',
  MANAGER = '5511900000009'
const SECRET = 'synthetic-backup-webhook-secret'
const cleanup: (() => Promise<void> | void)[] = []
afterEach(async () => {
  for (const close of cleanup.splice(0).reverse()) await close()
})
async function bind(server: Server) {
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve))
  cleanup.push(async () => {
    server.closeAllConnections()
    await new Promise<void>((resolve) => server.close(() => resolve()))
  })
  return `http://127.0.0.1:${(server.address() as AddressInfo).port}`
}
function projection(store: ShiftStore) {
  return {
    sequence: store.sequence,
    messages: store.unprocessedMessages(),
    notes: store.notesV2(),
    tasks: store.tasksV2(),
    inbox: store.inboxes(),
    outbox: store.outboxes(),
    paused: store.paused,
    anaLastPresented: store.lastPresentedNote(ANA),
    brunoLastPresented: store.lastPresentedNote(BRUNO),
    known: store.knownPatients('Rex'),
    media: store.mediaInventory()
  }
}
it('restores real webhook drafts, confirmations, correction, done/snooze, uncertain dispatch, pause, recovery and orphan bytes without resend', async () => {
  const root = fs.mkdtempSync(join(tmpdir(), 'shift-restore-flow-'))
  cleanup.push(() => fs.rmSync(root, { recursive: true, force: true }))
  const source = join(root, 'source'),
    restoredDirectory = join(root, 'restored')
  let clock = new Date('2026-10-03T18:00:00Z'),
    mode = 'accepted'
  const requests: string[] = []
  const receiver = createServer((request, response) => {
    void (async () => {
      let data = ''
      for await (const chunk of request) data += String(chunk)
      requests.push(data)
      if (mode === 'disconnect') {
        request.socket.destroy()
        return
      }
      response.writeHead(201, { 'content-type': 'application/json' })
      response.end(JSON.stringify({ id: 'synthetic-' + requests.length }))
    })()
  })
  const baseUrl = await bind(receiver)
  async function open(directory: string) {
    const store = new ShiftStore(directory)
    cleanup.push(() => store.close())
    const whatsapp = new WahaClient({
      baseUrl,
      session: 'fixture',
      apiKey: 'synthetic',
      fetch: async (url, init) => fetch(url, init),
      sendTimeoutMs: 50
    })
    const assistant = new ShiftAssistant({
      store,
      whatsapp,
      members: [
        { phone: ANA, name: 'Ana', manager: false },
        { phone: BRUNO, name: 'Bruno', manager: false },
        { phone: MANAGER, name: 'Manager', manager: true }
      ],
      organizer: staticOrganizer,
      transcriber: {
        async transcribe() {
          return RAW
        }
      },
      clock: () => clock
    })
    cleanup.push(() => assistant.stop())
    const server = buildShiftServer({
      assistant,
      store,
      whatsapp,
      webhookSecret: SECRET,
      clock: () => clock
    })
    const url = await bind(server)
    async function say(id: string, text: string, phone = ANA) {
      const response = await fetch(url + '/webhooks/waha', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'x-cvg-webhook-secret': SECRET
        },
        body: JSON.stringify({
          event: 'message',
          session: 'fixture',
          payload: { id, from: phone + '@c.us', body: text }
        })
      })
      expect(response.status).toBe(200)
      await assistant.idle()
    }
    async function confirm(id: string, phone = ANA) {
      const note = store
        .notesV2()
        .filter((n) => n.authorPhone === phone)
        .at(-1)
      expect(note).toBeDefined()
      await say(
        id,
        'ok nota ' +
          store
            .notesV2()
            .filter((n) => n.authorPhone === phone)
            .at(-1)!.token,
        phone
      )
    }
    return {
      store,
      assistant,
      say,
      confirm,
      close: async () => {
        await assistant.stop()
        store.close()
      }
    }
  }
  const first = await open(source)
  await first.say('note-1', RAW)
  await first.confirm('confirm-1')
  await first.say('done-1', 'feito 1')
  await first.say('note-2', RAW)
  await first.confirm('confirm-2')
  await first.say('snooze-2', 'adiar 2 30')
  const snoozed = first.store.tasksV2().find((t) => t.number === 2)!
  expect(snoozed.generation).toBeGreaterThan(1)
  expect(snoozed.dueAt).toBe('2026-10-03T19:30:00.000Z')
  const old = first.store.notesV2().at(-1)!
  await first.say('correction', 'corrigir nota ' + old.token + ': ' + RAW)
  await first.confirm('confirm-correction')
  await first.say('draft-bruno', RAW, BRUNO)
  expect(first.store.notesV2().some((n) => n.state === 'superseded')).toBe(true)
  expect(first.store.notesV2().some((n) => n.state === 'draft')).toBe(true)
  clock = new Date('2026-10-03T19:01:00Z')
  mode = 'disconnect'
  await first.assistant.tick()
  await first.assistant.idle()
  const uncertain = first.store
    .outboxes()
    .filter((b) => b.purpose === 'reminder' && b.state === 'uncertain')
  expect(uncertain.length).toBeGreaterThan(0)
  mode = 'accepted'
  await first.say('pause', 'pausar assistente', MANAGER)
  expect(first.store.paused).toBe(true)
  first.store.saveMedia('synthetic-media.bin', new Uint8Array([0, 1, 2, 255]))
  fs.writeFileSync(join(source, 'media/orphan.bin'), 'synthetic-orphan')
  await first.close()
  const manifest: JournalManifest = JSON.parse(
    fs.readFileSync(join(source, 'journal/manifest.json'), 'utf8')
  )
  const active = join(source, manifest.segments.at(-1)!.path)
  const prefix = fs.readFileSync(active)
  fs.appendFileSync(active, '{"incomplete":')
  const recovered = new ShiftStore(source)
  expect(recovered.storageAvailable).toBe(true)
  const expected = projection(recovered)
  expect(fs.readFileSync(active)).toEqual(
    Buffer.concat([prefix, Buffer.from('{"incomplete":')])
  )
  recovered.close()
  backupStoppedVolume(source, join(root, 'backup'))
  restoreBackup(join(root, 'backup'), restoredDirectory)
  const restored = await open(restoredDirectory)
  expect(projection(restored.store)).toEqual(expected)
  expect(restored.store.operationalHold).toBe(true)
  expect(restored.store.effectsAllowed).toBe(false)
  const requestsUnderHold = requests.length
  await restored.assistant.tick()
  expect(requests).toHaveLength(requestsUnderHold)
  await restored.close()
  // Explicit reconciliation of this disposable synthetic copy only; the
  // runtime never deletes or releases a hold automatically.
  fs.unlinkSync(join(restoredDirectory, 'restore-hold.json'))
  const released = await open(restoredDirectory)
  await released.say('resume-after-reconcile', 'retomar assistente', MANAGER)
  expect(released.store.operationalHold).toBe(false)
  expect(
    released.store
      .outboxes()
      .filter((b) => uncertain.some((u) => u.id === b.id))
  ).toEqual(uncertain)
  await released.confirm('confirm-bruno-restored', BRUNO)
  const beforeTick = requests.length
  await released.assistant.tick()
  await released.assistant.idle()
  expect(requests.length).toBeGreaterThan(beforeTick)
  expect(
    released.store
      .outboxes()
      .filter((b) => uncertain.some((u) => u.id === b.id))
  ).toEqual(uncertain)
  expect(
    fs.readFileSync(join(restoredDirectory, 'media/orphan.bin'), 'utf8')
  ).toBe('synthetic-orphan')
}, 15000)
