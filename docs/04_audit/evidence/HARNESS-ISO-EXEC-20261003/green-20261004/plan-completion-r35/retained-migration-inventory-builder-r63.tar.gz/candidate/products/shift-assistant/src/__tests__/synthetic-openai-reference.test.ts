// @vitest-environment node
import { describe, expect, it, vi } from 'vitest'
import { fixtureBinding, loadSyntheticCorpus } from '../synthetic/corpus.ts'
import { compareProposedReference } from '../synthetic/reference.ts'
import { runSyntheticOpenAIMock } from '../synthetic/runner.ts'
import type { OrganizedV2 } from '../domain.ts'
const empty: OrganizedV2 = {
  schemaVersion: 2,
  pacientes: [],
  pendencias: [],
  duvidas: [],
  evidence: []
}
describe('synthetic reference completeness and qualification', () => {
  it('does not qualify an empty schema-valid response for a populated fixture', async () => {
    const transport = vi.fn(
      async () =>
        new Response(
          JSON.stringify({
            choices: [
              {
                message: { content: JSON.stringify(empty) },
                finish_reason: 'stop'
              }
            ],
            usage: { prompt_tokens: 1, completion_tokens: 1 }
          }),
          { status: 200 }
        )
    )
    const result = await runSyntheticOpenAIMock({
      model: 'gpt-6-luna',
      fixtureBindings: [fixtureBinding('SYN-REL-01')],
      transport,
      dnsLookup: async () => ['93.184.216.34']
    })
    expect(transport).toHaveBeenCalledTimes(1)
    expect(result).toMatchObject({
      status: 'source_blocked',
      qualification: 'FAILED',
      code: 'reference_mismatch',
      results: []
    })
    expect(result.evidence[0]).toMatchObject({
      status: 'source_blocked',
      humanQualification: 'NOT_RUN',
      referenceMismatchCount: 1
    })
  })
  it('compares literal identity and values without granting human qualification', async () => {
    const fixed = (await loadSyntheticCorpus()).get(
      fixtureBinding('SYN-REL-01')
    )
    const output: OrganizedV2 = {
      ...empty,
      pacientes: fixed.proposedReference!.pacientes.map((patient, i) => ({
        ...patient,
        localRef: 'p' + (i + 1)
      }))
    }
    expect(
      compareProposedReference(output, fixed.proposedReference)
    ).toMatchObject({
      status: 'MATCH',
      humanQualification: 'NOT_RUN',
      mismatchCount: 0
    })
    output.pacientes[0]!.id = '99999'
    expect(
      compareProposedReference(output, fixed.proposedReference)
    ).toMatchObject({
      status: 'MISMATCH',
      humanQualification: 'NOT_RUN',
      mismatchCodes: ['patient_0_id']
    })
  })
  it('detects omitted source fields and tasks in the proposed reference', async () => {
    const fixed = (await loadSyntheticCorpus()).get(
      fixtureBinding('SYN-REL-17')
    )
    const output: OrganizedV2 = {
      ...empty,
      pacientes: fixed.proposedReference!.pacientes.map((patient, i) => ({
        ...patient,
        motivo: 'unsourced',
        localRef: 'p' + (i + 1)
      }))
    }
    expect(
      compareProposedReference(output, fixed.proposedReference)
    ).toMatchObject({
      status: 'MISMATCH',
      humanQualification: 'NOT_RUN',
      mismatchCount: 2
    })
  })
})
