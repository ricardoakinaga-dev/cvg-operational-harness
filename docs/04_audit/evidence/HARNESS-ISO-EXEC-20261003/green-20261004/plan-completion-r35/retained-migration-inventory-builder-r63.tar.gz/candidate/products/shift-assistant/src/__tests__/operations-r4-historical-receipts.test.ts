// @vitest-environment node
import { mkdtempSync, readFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, expect, it, vi } from 'vitest'
import { composeShiftApp, type ShiftApp } from '../compose.ts'
import { loadShiftConfig } from '../config.ts'
import {
  ShiftStore,
  type CommitRequest,
  type CommitExpected
} from '../store.ts'
import { canonical, sha256 } from '../journal.ts'
import { EffectIdentitySchema, type V2Event } from '../domain-v2.ts'
import { recordSimulatedDelivery } from '../delivery-receipts.ts'
import { RAW, staticOrganizer } from './vertical-test-fixture.ts'

const PHONE = '5511900000001'
const cleanup: Array<() => void | Promise<void>> = []
let now = new Date('2026-10-04T12:00:00Z')
afterEach(async () => {
  vi.restoreAllMocks()
  for (const close of cleanup.splice(0).reverse()) await close()
  now = new Date('2026-10-04T12:00:00Z')
})
function directory() {
  const d = mkdtempSync(join(tmpdir(), 'ops-r4-'))
  cleanup.push(() => rmSync(d, { recursive: true, force: true }))
  return d
}
function app(
  d: string,
  account = 'account-A',
  provider = 'waha',
  id = 'sent-id',
  organized = false
) {
  const config = loadShiftConfig({
    SHIFT_PROVIDER: provider,
    SHIFT_MEMBERS: `${PHONE}=Ficticio;5511900000009=Gestor*`,
    SHIFT_WEBHOOK_SECRET: 'r4-input-synthetic-secret',
    SHIFT_DELIVERY_SIMULATION_SECRET: 'r4-delivery-synthetic-secret',
    SHIFT_DATA_DIR: d,
    SHIFT_HOST: '127.0.0.1',
    SHIFT_PORT: '0',
    WAHA_URL: 'http://127.0.0.1:1',
    WAHA_API_KEY: 'synthetic',
    WAHA_SESSION: account,
    EVOLUTION_URL: 'http://127.0.0.1:1',
    EVOLUTION_API_KEY: 'synthetic',
    EVOLUTION_INSTANCE: account,
    WHISPER_URL: 'http://127.0.0.1:2',
    LLM_BASE_URL: 'http://127.0.0.1:3',
    LLM_MODEL: 'synthetic',
    LLM_LOCATION: 'local'
  })
  const a = composeShiftApp(config, {
    clock: () => now,
    ...(organized ? { organizer: staticOrganizer } : {}),
    fetchImpl: async () => new Response(JSON.stringify({ id }), { status: 201 })
  })
  cleanup.push(() => a.stop())
  return a
}
async function say(a: ShiftApp, id: string) {
  a.assistant.receive({
    provider: a.whatsapp.provider,
    messageId: id,
    fromPhone: PHONE,
    kind: 'text',
    text: 'ajuda',
    receivedAt: now.toISOString()
  })
  await a.assistant.idle()
}
function payload(account = 'account-A', provider = 'waha', id = 'sent-id') {
  return {
    provider,
    accountRef: account,
    providerMessageId: id,
    recipient: PHONE,
    deliveryStatus: 'delivery_confirmed',
    simulation: true
  }
}
function record(a: ShiftApp, p: unknown = payload()) {
  return recordSimulatedDelivery(p, a.store, a.whatsapp, a.assistant, () =>
    now.toISOString()
  )
}
function journal(d: string) {
  const manifest = JSON.parse(
    readFileSync(join(d, 'journal/manifest.json'), 'utf8')
  ) as { segments: Array<{ path: string }> }
  return join(d, manifest.segments.at(-1)!.path)
}
// Generates legacy-shaped synthetic records through the real journal API.
// Only this test's events are changed, before append; no persisted bytes rewritten.
function legacy(a: ShiftApp, unproven: boolean | string = false) {
  const commit = a.store.commit.bind(a.store)
  return vi.spyOn(a.store, 'commit').mockImplementation((r) => {
    const old = structuredClone(r)
    for (const e of old.changes) {
      if (!('v' in e) || e.v !== 2) continue
      if (e.type === 'outbox_dispatch_started') delete e.identity
      if (e.type === 'outbox_result' && e.receipt) delete e.receipt.identity
      if (unproven && 'outbox' in e && e.outbox)
        e.outbox.sourceTransitionId =
          typeof unproven === 'string' ? unproven : 'unrelated-transition'
      if (unproven && 'outboxes' in e)
        for (const b of e.outboxes)
          b.sourceTransitionId =
            typeof unproven === 'string' ? unproven : 'unrelated-transition'
    }
    return commit(old)
  })
}
function commitEvent(store: ShiftStore, e: V2Event, transitionId: string) {
  const expected: CommitExpected = {}
  for (const [entity, key] of store.references(e)) {
    const map = expected[entity] ?? {}
    map[String(key)] = store.revision(entity, key)
    expected[entity] = map
  }
  return store.commit({ transitionId, expected, changes: [e] })
}
function historicalCallback(a: ShiftApp, account: string, id: string) {
  const p = payload(account, 'waha', id),
    raw = canonical(p)
  const eventIdentity = sha256(
    JSON.stringify([
      p.provider,
      p.accountRef,
      p.providerMessageId,
      p.recipient,
      p.deliveryStatus
    ])
  )
  const actor = { kind: 'member' as const, memberPhone: PHONE }
  commitEvent(
    a.store,
    {
      v: 2,
      type: 'delivery_receipt_recorded',
      at: now.toISOString(),
      actor,
      receipt: {
        ...p,
        provider: 'waha',
        deliveryStatus: 'delivery_confirmed',
        simulation: true,
        eventIdentity,
        raw,
        rawSha256: sha256(raw),
        rawReceiptRef: 'journal:delivery:' + eventIdentity,
        receivedAt: now.toISOString(),
        committedAt: now.toISOString(),
        commitVerified: false
      }
    },
    'old-receipt:' + eventIdentity
  )
  commitEvent(
    a.store,
    {
      v: 2,
      type: 'delivery_receipt_committed',
      at: now.toISOString(),
      actor,
      eventIdentity,
      committedAt: now.toISOString()
    },
    'old-commit:' + eventIdentity
  )
}

it.each(['waha', 'evolution'])(
  'persists exact %s send identity, replays delivery and keeps duplicate delta zero',
  async (provider) => {
    const d = directory()
    let a = app(d, 'account-A', provider)
    await say(a, 'original')
    const b = a.store.outboxes()[0]!
    expect(b.receipt?.identity).toEqual({
      provider,
      accountRef: 'account-A',
      outboxId: b.id,
      sourceTransitionId: b.sourceTransitionId,
      recipient: PHONE
    })
    const before = a.store.sequence
    expect(record(a, payload('account-A', provider))).toBe(true)
    expect(a.store.sequence).toBe(before + 2)
    expect(record(a, payload('account-A', provider))).toBe(false)
    expect(a.store.sequence).toBe(before + 2)
    const prefix = readFileSync(journal(d))
    await a.stop()
    a = app(d, 'account-A', provider)
    expect(a.store.storageAvailable).toBe(true)
    expect(a.store.outboxes()[0]?.delivery?.commitVerified).toBe(true)
    expect(readFileSync(journal(d))).toEqual(prefix)
  }
)

it.each([
  ['account-B', 'waha'],
  ['account-A', 'evolution']
])(
  'rejects switched %s/%s without changing volume and retains old tuple positive after reopen',
  async (account, provider) => {
    const d = directory()
    let a = app(d)
    await say(a, 'original')
    await a.stop()
    const prefix = readFileSync(journal(d))
    a = app(d, account, provider)
    const seq = a.store.sequence
    expect(() => record(a, payload(account, provider))).toThrow(
      'INVALID_DELIVERY'
    )
    expect(a.store.sequence).toBe(seq)
    expect(a.store.outboxes()[0]?.delivery).toBeUndefined()
    expect(readFileSync(journal(d))).toEqual(prefix)
    await a.stop()
    a = app(d)
    expect(record(a)).toBe(true)
    expect(a.store.outboxes()[0]?.delivery?.accountRef).toBe('account-A')
  }
)

it('current client and any compatible inbox cannot change historical authority', async () => {
  const d = directory()
  let a = app(d)
  await say(a, 'source-A')
  await a.stop()
  a = app(d, 'account-B', 'waha', 'other-id')
  await say(a, 'unrelated-B')
  expect(a.store.inboxes().some((i) => i.session === 'account-B')).toBe(true)
  const seq = a.store.sequence
  expect(() => record(a, payload('account-B'))).toThrow('INVALID_DELIVERY')
  expect(a.store.sequence).toBe(seq)
  expect(a.store.outboxes()[0]?.delivery).toBeUndefined()
  expect(record(a, payload('account-B', 'waha', 'other-id'))).toBe(true)
})

it.each([
  ['account-B', 'waha'],
  ['account-A', 'evolution']
])(
  'permits same provider id in separate exact tuples %s/%s; no cross projection',
  async (account, provider) => {
    const d = directory()
    let a = app(d)
    await say(a, 'send-A')
    expect(record(a)).toBe(true)
    await a.stop()
    a = app(d, account, provider)
    await say(a, 'send-B')
    expect(record(a, payload(account, provider))).toBe(true)
    const boxes = a.store.outboxes()
    expect(boxes).toHaveLength(2)
    expect(boxes[0]?.delivery).toMatchObject({
      provider: 'waha',
      accountRef: 'account-A'
    })
    expect(boxes[1]?.delivery).toMatchObject({ provider, accountRef: account })
    await a.stop()
    a = app(d, account, provider)
    expect(a.store.outboxes().every((b) => b.delivery?.commitVerified)).toBe(
      true
    )
  }
)

it('derives legacy identity only from exact sourceTransitionId and causal input, preserving bytes', async () => {
  const d = directory()
  let a = app(d)
  const spy = legacy(a)
  await say(a, 'legacy')
  spy.mockRestore()
  expect(a.store.outboxes()[0]?.receipt?.identity).toBeUndefined()
  expect(
    a.store.deliveryAuthority({ ...payload(), provider: 'waha' })
  ).toMatchObject({
    status: 'matched'
  })
  await a.stop()
  const prefix = readFileSync(journal(d))
  a = app(d, 'account-B')
  expect(() => record(a, payload('account-B'))).toThrow('INVALID_DELIVERY')
  expect(readFileSync(journal(d))).toEqual(prefix)
  await a.stop()
  a = app(d)
  expect(record(a)).toBe(true)
  expect(a.store.outboxes()[0]?.delivery?.commitVerified).toBe(true)
  expect(readFileSync(journal(d)).subarray(0, prefix.length)).toEqual(prefix)
})

it('legacy crosscausal source reference requires reconciliation even with compatible inboxes', async () => {
  const d = directory()
  let a = app(d)
  const spy = legacy(a, true)
  await say(a, 'legacy-unproven')
  spy.mockRestore()
  expect(a.store.inboxes()[0]?.session).toBe('account-A')
  const seq = a.store.sequence
  expect(() => record(a)).toThrow('INVALID_DELIVERY')
  expect(a.store.sequence).toBe(seq)
  expect(a.store.outboxes()[0]?.delivery).toBeUndefined()
  await a.stop()
  const prefix = readFileSync(journal(d))
  a = app(d)
  expect(a.store.storageAvailable).toBe(true)
  expect(() => record(a)).toThrow('INVALID_DELIVERY')
  expect(a.store.sequence).toBe(seq)
  expect(readFileSync(journal(d))).toEqual(prefix)
})

it('sessionless dev mock acceptance is explicitly unproven and cannot inherit an inbox session', async () => {
  const a = app(directory())
  vi.spyOn(a.whatsapp, 'session', 'get').mockReturnValue(undefined)
  await say(a, 'devmock')
  expect(a.store.outboxes()[0]?.state).toBe('provider_accepted')
  expect(a.store.outboxes()[0]?.receipt?.identity).toBeNull()
  expect(
    a.store.deliveryAuthority({ ...payload(), provider: 'waha' }).status
  ).toBe('rejected')
  expect(a.store.outboxes()[0]?.delivery).toBeUndefined()
})

it.each([
  'outboxId',
  'sourceTransitionId',
  'recipient',
  'accountRef',
  'provider'
])(
  'malformed or inconsistent %s in durable acceptance cannot authorize delivery',
  async (field) => {
    const a = app(directory())
    const commit = a.store.commit.bind(a.store)
    let challenged = false
    vi.spyOn(a.store, 'commit').mockImplementation((r: CommitRequest) => {
      const old = structuredClone(r)
      for (const e of old.changes)
        if (
          'v' in e &&
          e.v === 2 &&
          e.type === 'outbox_result' &&
          e.receipt?.identity
        ) {
          challenged = true
          if (field === 'provider') e.receipt.identity.provider = 'evolution'
          else
            e.receipt.identity[
              field as
                | 'outboxId'
                | 'sourceTransitionId'
                | 'recipient'
                | 'accountRef'
            ] = 'wrong'
          const seq = a.store.sequence
          expect(() => commit(old)).toThrow()
          expect(a.store.sequence).toBe(seq)
        }
      return commit(r)
    })
    await say(a, 'malformed')
    expect(challenged).toBe(true)
    expect(record(a)).toBe(true)
  }
)

it.each([
  { accountRef: '' },
  { provider: 'unknown' },
  { recipient: PHONE + '@c.us' },
  { providerMessageId: '' },
  { simulation: false },
  { extra: true }
])('rejects malformed callback %j without journal mutation', async (bad) => {
  const a = app(directory())
  await say(a, 'malformed-callback')
  const seq = a.store.sequence
  expect(() => record(a, { ...payload(), ...bad })).toThrow('INVALID_DELIVERY')
  expect(a.store.sequence).toBe(seq)
  expect(record(a)).toBe(true)
})

it('historical wrong-account receipts neither project nor escape unmatched TTL through unrelated inbox', async () => {
  const d = directory()
  let a = app(d)
  await say(a, 'source-A')
  historicalCallback(a, 'account-B', 'sent-id')
  expect(a.store.outboxes()[0]?.delivery).toBeUndefined()
  expect(record(a)).toBe(true)
  await a.stop()
  a = app(d, 'account-B', 'waha', 'fresh-id')
  await say(a, 'unrelated-B')
  expect(a.store.outboxes()[0]?.delivery?.accountRef).toBe('account-A')
  now = new Date(+now + 86400001)
  expect(record(a, payload('account-B', 'waha', 'fresh-id'))).toBe(true)
  expect(a.store.deliveries()).toHaveLength(2)
  expect(
    a.store
      .deliveries()
      .some(
        (d) => d.providerMessageId === 'sent-id' && d.accountRef === 'account-B'
      )
  ).toBe(false)
  expect(a.store.outboxes()[0]?.delivery?.accountRef).toBe('account-A')
})

it('receipt-before-acceptance binds only the captured dispatch tuple and remains correct after restart', async () => {
  const d = directory()
  let a = app(d)
  const send = a.whatsapp.sendText.bind(a.whatsapp)
  vi.spyOn(a.whatsapp, 'sendText').mockImplementation(async (...args) => {
    expect(a.store.outboxes()[0]?.state).toBe('dispatching')
    expect(record(a)).toBe(true)
    expect(a.store.outboxes()[0]?.delivery).toBeUndefined()
    expect(() => record(a, payload('account-B'))).toThrow('INVALID_DELIVERY')
    return send(...args)
  })
  await say(a, 'early')
  expect(a.store.outboxes()[0]?.delivery?.commitVerified).toBe(true)
  await a.stop()
  a = app(d)
  expect(a.store.outboxes()[0]?.delivery?.commitVerified).toBe(true)
})

it('legacy reference to another real creating transaction is not causal proof', async () => {
  const d = directory()
  let a = app(d, 'account-A', 'waha', 'unrelated-id')
  await say(a, 'unrelated')
  const wrongSource = a.store.outboxes()[0]!.sourceTransitionId
  await a.stop()
  a = app(d)
  const spy = legacy(a, wrongSource)
  await say(a, 'crosscausal')
  spy.mockRestore()
  expect(a.store.outboxes()[1]?.sourceTransitionId).toBe(wrongSource)
  expect(() => record(a)).toThrow('INVALID_DELIVERY')
  expect(a.store.outboxes()[1]?.delivery).toBeUndefined()
})

it('legacy reminder follows creating transition through task and note to exact source inbox', async () => {
  now = new Date('2026-10-03T18:00:00Z')
  const d = directory()
  let a = app(d, 'account-A', 'waha', 'preview', true)
  const spy = legacy(a)
  a.assistant.receive({
    provider: 'waha',
    messageId: 'note',
    fromPhone: PHONE,
    kind: 'text',
    text: RAW,
    receivedAt: now.toISOString()
  })
  await a.assistant.idle()
  const note = a.store.notesV2()[0]!
  expect(note.state).toBe('draft')
  expect(note.issues).toEqual([])
  const send = vi.spyOn(a.whatsapp, 'sendText').mockResolvedValue({
    status: 'provider_accepted',
    receipt: {
      status: 201,
      at: now.toISOString(),
      sha256: sha256('synthetic'),
      providerId: 'confirmation'
    }
  })
  a.assistant.receive({
    provider: 'waha',
    messageId: 'confirm',
    fromPhone: PHONE,
    kind: 'text',
    text: 'ok nota ' + note.token,
    receivedAt: now.toISOString()
  })
  await a.assistant.idle()
  expect(a.store.notesV2()[0]?.state).toBe('confirmed')
  send.mockResolvedValue({
    status: 'provider_accepted',
    receipt: {
      status: 201,
      at: now.toISOString(),
      sha256: sha256('synthetic'),
      providerId: 'reminder'
    }
  })
  now = new Date('2026-10-05T12:00:00Z')
  await a.assistant.tick()
  await a.assistant.idle()
  spy.mockRestore()
  const reminder = a.store.outboxes().find((b) => b.purpose === 'reminder')!
  expect(reminder.state).toBe('provider_accepted')
  expect(reminder.receipt?.identity).toBeUndefined()
  expect(record(a, payload('account-A', 'waha', 'reminder'))).toBe(true)
  expect(a.store.outbox(reminder.id)?.delivery?.commitVerified).toBe(true)
  await a.stop()
  a = app(d)
  expect(a.store.outbox(reminder.id)?.delivery?.accountRef).toBe('account-A')
})

it('acceptance captures dispatch identity before a mutable mock changes its current account', async () => {
  const a = app(directory())
  const send = a.whatsapp.sendText.bind(a.whatsapp)
  let current = 'account-A'
  vi.spyOn(a.whatsapp, 'session', 'get').mockImplementation(() => current)
  vi.spyOn(a.whatsapp, 'sendText').mockImplementation(async (...args) => {
    current = 'account-B'
    return send(...args)
  })
  await say(a, 'capture')
  expect(a.store.outboxes()[0]?.receipt?.identity?.accountRef).toBe('account-A')
  expect(() => record(a, payload('account-B'))).toThrow('INVALID_DELIVERY')
  current = 'account-A'
  expect(record(a)).toBe(true)
})

it('strict optional metadata accepts legacy absence but rejects partial and extra identity fields', () => {
  expect(
    EffectIdentitySchema.safeParse({
      provider: 'waha',
      accountRef: 'account-A'
    }).success
  ).toBe(false)
  expect(
    EffectIdentitySchema.safeParse({
      provider: 'waha',
      accountRef: 'account-A',
      outboxId: 'b',
      sourceTransitionId: 's',
      recipient: PHONE,
      extra: 1
    }).success
  ).toBe(false)
})
