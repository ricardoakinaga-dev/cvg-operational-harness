// @vitest-environment node
import { spawnSync } from 'node:child_process'
import { createServer, type Server } from 'node:http'
import type { AddressInfo } from 'node:net'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, expect, it } from 'vitest'
import { composeShiftApp } from '../compose.ts'
import { loadShiftConfig } from '../config.ts'
import { ShiftStore } from '../store.ts'
import { RAW, RESPONSE } from './vertical-test-fixture.ts'
const ANA = '5511900000001',
  MANAGER = '5511900000009',
  SECRET = 'synthetic-webhook-secret-12345',
  DELIVERY = 'synthetic-delivery-secret-12345'
const cleanup: (() => Promise<void> | void)[] = []
afterEach(async () => {
  for (const close of cleanup.reverse()) await close()
  cleanup.length = 0
})
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))
async function until(predicate: () => boolean, ms = 5000) {
  const start = performance.now()
  while (!predicate()) {
    if (performance.now() - start > ms) throw new Error('predicate_timeout')
    await sleep(10)
  }
}
async function bind(server: Server) {
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', r))
  return `http://127.0.0.1:${(server.address() as AddressInfo).port}`
}
async function fixture(count = 1, elapsedClock = false) {
  let now = new Date(
      elapsedClock ? '2026-10-03T18:59:58Z' : '2026-10-03T18:00:00Z'
    ),
    appUrl = '',
    hang = false,
    early = false,
    noDelivery = false,
    blockOrganizer = false,
    organizerStarted = false
  let anchor = Date.now()
  const clock = () => new Date(+now + (elapsedClock ? Date.now() - anchor : 0))
  const sends: { id: string; text: string; at: number }[] = [],
    callbackCommits: number[] = []
  const receiver = createServer((req, res) => {
    void (async () => {
      let body = ''
      for await (const chunk of req) body += String(chunk)
      const p = JSON.parse(body),
        id = 'synthetic-' + (sends.length + 1)
      sends.push({ id, text: p.text, at: performance.now() })
      if (hang && p.text.startsWith('⏰')) {
        res.writeHead(201, { 'content-type': 'application/json' })
        res.flushHeaders()
        return
      }
      const deliver = async () => {
        const r = await fetch(appUrl + '/callbacks/delivery-simulation', {
          method: 'POST',
          headers: {
            'content-type': 'application/json',
            'x-cvg-webhook-secret': DELIVERY
          },
          body: JSON.stringify({
            provider: 'waha',
            accountRef: 'fixture',
            providerMessageId: id,
            recipient: ANA,
            deliveryStatus: 'delivery_confirmed',
            simulation: true
          })
        })
        if (r.status === 200) callbackCommits.push(performance.now())
      }
      if (early && p.text.startsWith('⏰')) await deliver()
      await sleep(20)
      res.writeHead(201, { 'content-type': 'application/json' })
      res.end(JSON.stringify({ id }))
      if (!early && !noDelivery && p.text.startsWith('⏰')) {
        await sleep(30)
        await deliver()
      }
    })().catch(() => {})
  })
  const provider = await bind(receiver)
  cleanup.push(() => {
    receiver.closeAllConnections()
    return new Promise<void>((r) => receiver.close(() => r()))
  })
  const dir = mkdtempSync(join(tmpdir(), 'operations-reminder-'))
  const config = loadShiftConfig({
    SHIFT_PROVIDER: 'waha',
    SHIFT_MEMBERS: `${ANA}=Ana;${MANAGER}=Manager*`,
    SHIFT_WEBHOOK_SECRET: SECRET,
    SHIFT_DELIVERY_SIMULATION_SECRET: DELIVERY,
    SHIFT_DATA_DIR: dir,
    SHIFT_HOST: '127.0.0.1',
    SHIFT_PORT: '0',
    SHIFT_TICK_SECONDS: '5',
    WAHA_URL: provider,
    WAHA_API_KEY: 'synthetic',
    WAHA_SESSION: 'fixture',
    WHISPER_URL: provider,
    LLM_BASE_URL: provider,
    LLM_LOCATION: 'local',
    LLM_MODEL: 'synthetic'
  })
  const response = structuredClone(RESPONSE)
  response.pendencias = Array.from({ length: count }, (_, i) => ({
    ...RESPONSE.pendencias[0]!,
    localRef: `t${i + 1}`
  }))
  response.evidence = response.evidence.filter(
    (e) => !e.path.startsWith('pendencias.')
  )
  for (let i = 1; i <= count; i++)
    for (const field of ['descricao', 'quando'])
      response.evidence.push({
        ...RESPONSE.evidence.find((e) => e.path === `pendencias.t1.${field}`)!,
        path: `pendencias.t${i}.${field}`
      })
  let app = composeShiftApp(config, {
    clock,
    organizer: {
      async organize(_text, _at, signal) {
        if (blockOrganizer) {
          organizerStarted = true
          await new Promise<void>((_resolve, reject) => {
            signal?.addEventListener(
              'abort',
              () => reject(new Error('cancelled')),
              { once: true }
            )
          })
        }
        return response
      }
    }
  })
  appUrl = `http://127.0.0.1:${await app.start()}`
  cleanup.push(() => app.stop())
  const post = (id: string, text: string, phone = ANA) =>
    fetch(appUrl + '/webhooks/waha', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-cvg-webhook-secret': SECRET
      },
      body: JSON.stringify({
        event: 'message',
        session: 'fixture',
        payload: { id, from: phone + '@c.us', body: text }
      })
    })
  const say = async (id: string, text: string, phone = ANA) => {
    const r = await post(id, text, phone)
    expect(r.status).toBe(200)
    await app.assistant.idle()
  }
  const confirm = async () => {
    await say('note', RAW)
    expect(app.store.openTasks()).toHaveLength(0)
    expect(app.store.notesV2()[0]?.issues).toEqual([])
    await say('confirm', 'ok nota ' + app.store.notesV2()[0]!.token)
    expect(app.store.openTasks()).toHaveLength(count)
  }
  const callback = (patch: Record<string, unknown> = {}, secret = DELIVERY) =>
    fetch(appUrl + '/callbacks/delivery-simulation', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-cvg-webhook-secret': secret
      },
      body: JSON.stringify({
        provider: 'waha',
        accountRef: 'fixture',
        providerMessageId: sends.filter((s) => s.text.startsWith('⏰'))[0]?.id,
        recipient: ANA,
        deliveryStatus: 'delivery_confirmed',
        simulation: true,
        ...patch
      })
    })
  return {
    get app() {
      return app
    },
    dir,
    sends,
    confirm,
    restart: async () => {
      await app.stop()
      app = composeShiftApp(config, {
        clock,
        organizer: {
          async organize(_text, _at, signal) {
            if (blockOrganizer) {
              organizerStarted = true
              await new Promise<void>((_resolve, reject) => {
                signal?.addEventListener(
                  'abort',
                  () => reject(new Error('cancelled')),
                  { once: true }
                )
              })
            }
            return response
          }
        }
      })
      appUrl = `http://127.0.0.1:${await app.start()}`
    },
    post,
    say,
    callback,
    callbackCommits,
    until,
    block: () => {
      blockOrganizer = true
    },
    organizerStarted: () => organizerStarted,
    advance: (ms: number) => {
      now = new Date(+now + ms)
    },
    due: () => {
      now = new Date('2026-10-03T19:00:00Z')
      anchor = Date.now()
    },
    hang: () => {
      hang = true
    },
    early: () => {
      early = true
    },
    noDelivery: () => {
      noDelivery = true
    }
  }
}
it('two concurrent ticks reserve once while real HTTP body hangs; pause commits <=1s and second effect never starts', async () => {
  const f = await fixture(2)
  await f.confirm()
  f.due()
  f.hang()
  const counts = await Promise.all([
    f.app.assistant.tick(),
    f.app.assistant.tick()
  ])
  expect(counts).toEqual([2, 0])
  await f.until(() => f.sends.some((s) => s.text.startsWith('⏰')))
  const start = performance.now()
  expect((await f.post('pause', 'pausar assistente', MANAGER)).status).toBe(200)
  expect(performance.now() - start).toBeLessThan(1000)
  await f.app.assistant.idle()
  expect(f.app.store.paused).toBe(true)
  expect(f.sends.filter((s) => s.text.startsWith('⏰'))).toHaveLength(1)
  expect(
    f.app.store
      .outboxes()
      .filter((b) => b.purpose === 'reminder')
      .map((b) => b.state)
  ).toEqual(['uncertain', 'queued'])
  expect(f.sends.at(-1)?.text).toBe('Assistente pausado.')
  expect(f.app.assistant.health().reasonCodes).toContain('outbox_review')
})
it('four accepted slots at >=30m stop; backwards clock and restart preserve slots; snooze opens new generation; done stops', async () => {
  const f = await fixture()
  await f.confirm()
  f.due()
  for (let slot = 1; slot <= 4; slot++) {
    expect(await f.app.assistant.tick()).toBe(1)
    await f.app.assistant.idle()
    expect(f.app.store.tasksV2()[0]?.remindedCount).toBe(slot)
    expect(await f.app.assistant.tick()).toBe(0)
    f.advance(1800000)
  }
  expect(await f.app.assistant.tick()).toBe(0)
  f.advance(-7200000)
  expect(await f.app.assistant.tick()).toBe(0)
  await f.say('snooze', 'adiar 1 30')
  expect(f.app.store.tasksV2()[0]?.generation).toBe(2)
  f.advance(1800000)
  expect(await f.app.assistant.tick()).toBe(1)
  await f.app.assistant.idle()
  await f.say('done', 'feito 1')
  expect(await f.app.assistant.tick()).toBe(0)
  await f.app.stop()
  const reopened = new ShiftStore(f.dir)
  cleanup.push(() => reopened.close())
  expect(reopened.tasksV2()[0]).toMatchObject({
    status: 'done',
    generation: 2,
    remindedCount: 1
  })
  expect(
    reopened.outboxes().filter((b) => b.purpose === 'reminder')
  ).toHaveLength(5)
})
it('AP011-LATENCY explicit simulation: batch20 confirmed through webhook, max5s timer independent of suspended organizer, authenticated receipts <=60s persist on restart', async () => {
  const f = await fixture(20, true)
  await f.confirm()
  await f.restart()
  expect(f.app.store.openTasks()).toHaveLength(20)
  expect(await f.app.assistant.tick()).toBe(0)
  f.block()
  expect((await f.post('model-busy', RAW)).status).toBe(200)
  await f.until(f.organizerStarted)
  f.due()
  const start = performance.now()
  await f.until(
    () =>
      f.app.store
        .outboxes()
        .filter((b) => b.purpose === 'reminder' && b.delivery).length === 20 &&
      f.callbackCommits.length === 20,
    60000
  )
  expect(performance.now() - start).toBeLessThan(60000)
  expect(f.sends.filter((s) => s.text.startsWith('⏰'))).toHaveLength(20)
  expect(f.callbackCommits).toHaveLength(20)
  const dueAt = Date.parse(f.app.store.tasksV2()[0]!.dueAt)
  const durableDeltas = f.app.store
    .outboxes()
    .filter((b) => b.purpose === 'reminder')
    .map((b) => Date.parse(b.delivery!.committedAt) - dueAt)
  expect(Math.max(...durableDeltas)).toBeGreaterThan(0)
  expect(Math.max(...durableDeltas)).toBeLessThan(60000)
  expect(Math.max(...f.callbackCommits) - start).toBeLessThan(60000)
  console.log(
    'AP011_SIMULATION_BATCH20',
    JSON.stringify({
      tasks: 20,
      tickSeconds: 5,
      positiveResponseDelayMs: 20,
      callbackDelayMs: 30,
      observedMaxCommitMs: Math.max(...f.callbackCommits) - start,
      durableMaxCommitMs: Math.max(...durableDeltas),
      providerQualification: 'NOT_QUALIFIED'
    })
  )
  expect(
    f.app.store
      .outboxes()
      .filter((b) => b.purpose === 'reminder')
      .every((b) => b.state === 'provider_accepted' && b.delivery?.simulation)
  ).toBe(true)
  await f.app.stop()
  const reopened = new ShiftStore(f.dir)
  cleanup.push(() => reopened.close())
  expect(reopened.outboxes().filter((b) => b.delivery)).toHaveLength(20)
  reopened.close()
  const child = spawnSync(
    process.execPath,
    [
      '--import',
      'tsx',
      '--input-type=module',
      '-e',
      `import {ShiftStore} from './products/shift-assistant/src/store.ts'; const s=new ShiftStore(process.argv[1]); console.log(JSON.stringify({node:process.version,deliveries:s.outboxes().filter(b=>b.delivery).length,tasks:s.openTasks().length}));s.close()`,
      f.dir
    ],
    {
      cwd: process.cwd(),
      encoding: 'utf8',
      timeout: 10000,
      env: { PATH: process.env.PATH, TMPDIR: process.env.TMPDIR }
    }
  )
  expect(child.status).toBe(0)
  expect(JSON.parse(child.stdout)).toMatchObject({
    node: process.version,
    deliveries: 20,
    tasks: 20
  })
}, 65000)
it('separate callback: early receipt, duplicate idempotency, auth/account/recipient/id negatives never confirm other message', async () => {
  const f = await fixture()
  await f.confirm()
  f.early()
  f.due()
  expect(await f.app.assistant.tick()).toBe(1)
  await f.app.assistant.idle()
  expect(
    f.app.store.outboxes().find((b) => b.purpose === 'reminder')?.delivery
  ).toBeDefined()
  const seq = f.app.store.sequence
  expect((await f.callback()).status).toBe(200)
  expect(f.app.store.sequence).toBe(seq)
  expect((await f.callback({}, 'invalid')).status).toBe(401)
  for (const patch of [
    { accountRef: 'other' },
    { recipient: MANAGER },
    { providerMessageId: 'unknown' },
    { deliveryStatus: 'server_ack' },
    { simulation: false }
  ])
    expect((await f.callback(patch)).status).toBe(400)
  expect(f.app.store.sequence).toBe(seq)
})
it('HTTP accepted without delivery fails AP011; overdue cannot become retroactive healthy after120s', async () => {
  const f = await fixture()
  await f.confirm()
  f.noDelivery()
  f.due()
  expect(await f.app.assistant.tick()).toBe(1)
  await f.app.assistant.idle()
  expect(
    f.app.store.outboxes().find((b) => b.purpose === 'reminder')?.delivery
  ).toBeUndefined()
  f.advance(120000)
  expect(f.app.assistant.health().reasonCodes).toContain('delivery_overdue')
  expect((await f.callback()).status).toBe(200)
  expect(f.app.assistant.health().reasonCodes).toContain('delivery_overdue')
})

it('AP011-LATENCY explicit single simulation after empty round uses max5s scheduler and separate persisted callback', async () => {
  const f = await fixture(1, true)
  await f.confirm()
  expect(await f.app.assistant.tick()).toBe(0)
  f.due()
  const start = performance.now()
  await f.until(
    () =>
      !!f.app.store.outboxes().find((b) => b.purpose === 'reminder')?.delivery,
    60000
  )
  const reminder = f.app.store.outboxes().find((b) => b.purpose === 'reminder')!
  const durableDelta =
    Date.parse(reminder.delivery!.committedAt) -
    Date.parse(f.app.store.tasksV2()[0]!.dueAt)
  expect(durableDelta).toBeGreaterThan(0)
  expect(durableDelta).toBeLessThan(60000)
  const elapsed = performance.now() - start
  expect(elapsed).toBeLessThan(60000)
  console.log(
    'AP011_SIMULATION_SINGLE',
    JSON.stringify({
      tasks: 1,
      tickSeconds: 5,
      observedCommitMs: elapsed,
      durableCommitMs: durableDelta,
      providerQualification: 'NOT_QUALIFIED'
    })
  )
}, 65000)
it('uncertain reminder consumes slot and blocks next window after explicit resume and process-store restart, with effectsAllowed true', async () => {
  const f = await fixture()
  await f.confirm()
  f.due()
  f.hang()
  expect(await f.app.assistant.tick()).toBe(1)
  await f.until(() => f.sends.some((s) => s.text.startsWith('⏰')))
  await f.say('pause-uncertain', 'pausar assistente', MANAGER)
  expect(
    f.app.store.outboxes().find((b) => b.purpose === 'reminder')?.state
  ).toBe('uncertain')
  await f.say('resume-uncertain', 'retomar assistente', MANAGER)
  expect(f.app.store.effectsAllowed).toBe(true)
  f.advance(3600000)
  expect(await f.app.assistant.tick()).toBe(0)
  await f.restart()
  expect(f.app.store.effectsAllowed).toBe(true)
  expect(await f.app.assistant.tick()).toBe(0)
  expect(
    f.app.store.outboxes().filter((b) => b.purpose === 'reminder')
  ).toHaveLength(1)
  expect(f.app.store.tasksV2()[0]?.remindedCount).toBe(0)
  expect(f.sends.filter((s) => s.text.startsWith('⏰'))).toHaveLength(1)
})
