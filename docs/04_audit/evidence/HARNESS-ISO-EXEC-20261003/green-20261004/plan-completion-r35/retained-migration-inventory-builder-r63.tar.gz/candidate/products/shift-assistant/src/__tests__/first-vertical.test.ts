// @vitest-environment node
import * as fs from 'node:fs'
import { createServer, type Server } from 'node:http'
import type { AddressInfo } from 'node:net'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { spawn, spawnSync } from 'node:child_process'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { ShiftStore, type CommitExpected } from '../store.ts'
import { ShiftAssistant } from '../assistant.ts'
import {
  WahaClient,
  EvolutionClient,
  type WhatsAppClient,
  type SendResult
} from '../whatsapp.ts'
import { buildShiftServer } from '../server.ts'
import { ModelOrganizer, type Organizer } from '../organizer.ts'
import { canonical, sha256, type JournalIO } from '../journal.ts'
import { type V2Event, type OrganizedV2 } from '../domain.ts'
import { RAW, RESPONSE, staticOrganizer } from './vertical-test-fixture.ts'
import { validateOrganization } from '../source-evidence.ts'
import { inputDigest } from '../vertical-state.ts'
import { composeShiftApp } from '../compose.ts'
import { loadShiftConfig } from '../config.ts'
const ANA = '5511900000001',
  BRUNO = '5511900000002',
  MANAGER = '5511900000009'
const members = [
  { phone: ANA, name: 'Ana', manager: false },
  { phone: BRUNO, name: 'Bruno', manager: false },
  { phone: MANAGER, name: 'Manager', manager: true }
]
const SECRET = 'synthetic-webhook-secret-12345'
const closers: (() => Promise<void> | void)[] = []
afterEach(async () => {
  for (const close of closers.reverse()) await close()
  closers.length = 0
})
function volume() {
  return fs.mkdtempSync(join(tmpdir(), 'product-vertical-'))
}
function bind(s: Server) {
  return new Promise<string>((resolve) =>
    s.listen(0, '127.0.0.1', () =>
      resolve(`http://127.0.0.1:${(s.address() as AddressInfo).port}`)
    )
  )
}
function closeServer(s: Server) {
  s.closeAllConnections()
  return new Promise<void>((r) => s.close(() => r()))
}
async function setup(
  o: {
    provider?: 'waha' | 'evolution'
    dir?: string
    organizer?: Organizer
    io?: JournalIO
    transport?: () => Promise<SendResult | void>
    modelTimeoutMs?: number
  } = {}
) {
  const dir = o.dir ?? volume()
  let now = new Date('2026-10-03T18:00:00Z')
  let mode = 'accepted'
  const sent: { path: string; body: Record<string, unknown> }[] = []
  const receiver = createServer((req, res) => {
    void (async () => {
      let data = ''
      for await (const chunk of req) data += String(chunk)
      sent.push({ path: req.url!, body: JSON.parse(data) })
      if (mode === 'disconnect') {
        req.socket.destroy()
        return
      }
      if (mode === '5xx') {
        res.writeHead(503)
        res.end('{}')
        return
      }
      if (mode === 'hang') return
      res.writeHead(201, { 'content-type': 'application/json' })
      res.end(
        JSON.stringify(
          o.provider === 'evolution'
            ? { key: { id: 'synthetic-' + sent.length } }
            : { id: 'synthetic-' + sent.length }
        )
      )
    })()
  })
  const base = await bind(receiver)
  closers.push(() => closeServer(receiver))
  const client: WhatsAppClient =
    o.provider === 'evolution'
      ? new EvolutionClient({
          baseUrl: base,
          instance: 'fixture',
          apiKey: 'synthetic',
          fetch: async (u, i) => fetch(u, i),
          sendTimeoutMs: 50
        })
      : new WahaClient({
          baseUrl: base,
          session: 'fixture',
          apiKey: 'synthetic',
          fetch: async (u, i) => fetch(u, i),
          sendTimeoutMs: 50
        })
  if (o.transport) client.sendText = o.transport
  const store = new ShiftStore(dir, o.io ? { io: o.io } : {})
  closers.push(() => store.close())
  const assistant = new ShiftAssistant({
    store,
    members,
    whatsapp: client,
    organizer: o.organizer ?? staticOrganizer,
    transcriber: {
      async transcribe() {
        return RAW
      }
    },
    clock: () => now,
    ...(o.modelTimeoutMs ? { modelTimeoutMs: o.modelTimeoutMs } : {})
  })
  closers.push(() => assistant.stop())
  const server = buildShiftServer({
    assistant,
    store,
    whatsapp: client,
    webhookSecret: SECRET,
    clock: () => now
  })
  const url = await bind(server)
  closers.push(() => closeServer(server))
  const body = (id: string, text: string, phone = ANA) =>
    o.provider === 'evolution'
      ? {
          event: 'messages.upsert',
          instance: 'fixture',
          data: {
            key: { id, remoteJid: phone + '@s.whatsapp.net' },
            message: { conversation: text }
          }
        }
      : {
          event: 'message',
          session: 'fixture',
          payload: { id, from: phone + '@c.us', body: text }
        }
  const post = async (id: string, text: string, phone = ANA) =>
    fetch(url + '/webhooks/' + (o.provider ?? 'waha'), {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-cvg-webhook-secret': SECRET
      },
      body: JSON.stringify(body(id, text, phone))
    })
  const say = async (id: string, text: string, phone = ANA) => {
    const r = await post(id, text, phone)
    await assistant.idle()
    return r
  }
  return {
    dir,
    store,
    assistant,
    server,
    client,
    url,
    post,
    say,
    sent,
    body,
    mode: (m: string) => {
      mode = m
    },
    advance: (ms: number) => {
      now = new Date(+now + ms)
    },
    token: () => store.notesV2().at(-1)!.token
  }
}
function commit(store: ShiftStore, id: string, e: V2Event) {
  const expected: CommitExpected = {}
  for (const [entity, key] of store.references(e)) {
    expected[entity] ??= {}
    expected[entity]![String(key)] = store.revision(entity, key)
  }
  return store.commit({ transitionId: id, expected, changes: [e] })
}
describe('first observable text product vertical', () => {
  it.each(['waha', 'evolution'] as const)(
    '%s real HTTP: durable admission, queued preview, exact confirmation, task and durable receipt',
    async (provider) => {
      const e = await setup({ provider })
      expect((await e.say('n1', RAW)).status).toBe(200)
      const n = e.store.notesV2()[0]!
      expect(n.issues).toEqual([])
      expect(n.rawText).toBe(RAW)
      expect(e.store.openTasks()).toEqual([])
      expect(e.store.tasksV2()[0]!.status).toBe('draft')
      expect(e.sent[0]!.body.text).toContain('RASCUNHO')
      expect(e.sent[0]!.body.text).toContain('ok nota ' + n.token)
      expect(e.store.outboxes()[0]!.state).toBe('provider_accepted')
      expect(e.store.outboxes()[0]!.receipt?.providerId).toBe('synthetic-1')
      await e.say('ok1', 'ok nota ' + n.token)
      expect(e.store.openTasks(ANA)).toHaveLength(1)
      expect(e.store.noteV2(n.id)?.state).toBe('confirmed')
      expect(e.store.noteV2(n.id)?.bindings[0]?.confirmedBy).toBe(ANA)
      expect(e.store.outboxes().at(-1)?.purpose).toBe('response')
      expect(e.store.outboxes().at(-1)?.state).toBe('provider_accepted')
      expect(e.store.outboxes().some((b) => 'delivery_confirmed' in b)).toBe(
        false
      )
      const history = fs.readdirSync(join(e.dir, 'journal'))
      expect(history.length).toBeGreaterThan(1)
    }
  )
  it('rejects another author generic ok and stale token, deduplicates admission and confirmation', async () => {
    const e = await setup()
    await e.say('n1', RAW)
    const token = e.token()
    await e.say('bare', 'ok', BRUNO)
    await e.say('other', 'ok nota ' + token, BRUNO)
    expect(e.store.openTasks()).toHaveLength(0)
    const duplicate = await e.say('n1', RAW)
    expect(await duplicate.json()).toEqual({ accepted: false })
    expect(e.store.notesV2()).toHaveLength(1)
    const conflict = await e.say('n1', RAW + ' changed')
    expect(conflict.status).toBe(409)
    await e.say('valid', 'ok nota ' + token)
    await e.say('again', 'ok nota ' + token)
    expect(e.store.openTasks()).toHaveLength(1)
    expect(e.store.nextTaskNumber()).toBe(2)
    const response = e.store.outboxes().at(-1)
    expect(response?.payloadText).toContain('já confirmada')
  })
  it('keeps V1/raw JSON/extra flags as durable review sources with zero derived tasks and refuses confirmation', async () => {
    for (const output of [
      '{invalid}',
      { pacientes: [], pendencias: [], duvidas: [] },
      { ...RESPONSE, confirmed: true },
      {
        ...RESPONSE,
        evidence: RESPONSE.evidence.map((p) => ({ ...p, start: 0, end: 1 }))
      }
    ]) {
      const e = await setup({
        organizer: {
          async organize() {
            return output
          }
        }
      })
      await e.say('n', RAW)
      expect(e.store.tasksV2()).toHaveLength(0)
      expect(e.store.inboxes()[0]?.text).toBe(RAW)
      expect(e.store.inboxes()[0]?.state).toBe('review_required')
      expect(e.store.inboxes()[0]?.error).toBe('schema_invalid')
      expect(e.store.notesV2()).toEqual([])
      expect(e.store.outboxes()[0]?.payloadText).toContain(RAW)
      await e.say('c', 'ok')
      expect(e.store.notesV2()).toEqual([])
      expect(e.store.outboxes().at(-1)?.payloadText).toContain(
        'CONFIRMATION_NOT_ELIGIBLE'
      )
      expect(e.store.openTasks()).toEqual([])
    }
  })
  it('default ModelOrganizer policy_denied has zero external/local provider calls and raw-document confirmation', async () => {
    const execute = vi.fn()
    for (const location of ['external', 'local']) {
      const denied = new ModelOrganizer(
        { id: 'fixture', location, execute } as never,
        'm'
      )
      await expect(denied.organize(RAW, new Date())).rejects.toMatchObject({
        code: 'policy_denied'
      })
      expect(execute).not.toHaveBeenCalled()
    }
    const e = await setup({ organizer: new ModelOrganizer() })
    await e.say('n', RAW)
    expect(e.store.notesV2()[0]!.warnings).toContain('policy_denied')
    expect(e.store.openTasks()).toEqual([])
    await e.say('c', 'ok nota ' + e.token())
    expect(e.store.notesV2()[0]!.state).toBe('confirmed')
    expect(execute).not.toHaveBeenCalled()
  })
  it('close/restart keeps original, confirmed task/binding/receipts and same tuple dedup', async () => {
    const e = await setup()
    await e.say('n', RAW)
    await e.say('c', 'ok nota ' + e.token())
    const before = canonical([
      e.store.notesV2(),
      e.store.tasksV2(),
      e.store.outboxes()
    ])
    await e.assistant.stop()
    await closeServer(e.server)
    e.store.close()
    const restarted = await setup({ dir: e.dir })
    restarted.assistant.recoverPending()
    await restarted.assistant.idle()
    expect(
      canonical([
        restarted.store.notesV2(),
        restarted.store.tasksV2(),
        restarted.store.outboxes()
      ])
    ).toBe(before)
    expect((await restarted.say('n', RAW)).status).toBe(200)
    expect(restarted.sent).toHaveLength(0)
  })
  it('correction suspends before organizing; transient failure leaves pending replacement, done stays terminal', async () => {
    let failing = false
    const e = await setup({
      organizer: {
        async organize() {
          if (failing) throw new Error('synthetic')
          return RESPONSE
        }
      }
    })
    await e.say('n', RAW)
    await e.say('c', 'ok nota ' + e.token())
    const old = e.store.notesV2()[0]!,
      token = old.token
    failing = true
    await e.say('correction', 'corrigir nota ' + token + ': ' + RAW)
    expect(e.store.noteV2(old.id)?.replacementPending).toBe(true)
    expect(e.store.tasksV2()[0]?.status).toBe('suspended')
    expect(e.store.inboxes().at(-1)?.state).toBe('retry_wait')
    await e.say('stale', 'ok nota ' + token)
    expect(e.store.openTasks()).toEqual([])
    failing = false
    e.advance(30000)
    e.assistant.resumePending()
    await e.assistant.idle()
    expect(e.store.noteV2(old.id)?.state).toBe('superseded')
    expect(e.store.tasksV2()[0]?.status).toBe('cancelled')
    expect(e.store.tasksV2()[1]?.status).toBe('draft')
    await e.say('new', 'ok nota ' + e.token())
    expect(e.store.openTasks()[0]?.number).toBe(2)
    await e.say('done', 'feito 2')
    await e.say('correction2', 'corrigir nota ' + e.token() + ': ' + RAW)
    expect(e.store.tasksV2()[1]?.status).toBe('done')
    expect(e.store.tasksV2()[2]?.number).toBe(3)
  })
  it('commit confirmation fsync failure publishes none; restart atomically recovers tasks, binding and queued receipt', async () => {
    let armed = false,
      syncCalls = 0
    const e = await setup({
      io: {
        sync(fd) {
          if (armed && ++syncCalls === 3)
            throw new Error('synthetic confirmation sync failure')
          fs.fsyncSync(fd)
        }
      }
    })
    await e.say('n', RAW)
    const n = e.store.notesV2()[0]!
    armed = true
    const admitted = await e.post('confirm-crash', 'ok nota ' + n.token)
    expect(admitted.status).toBe(200)
    await e.assistant.idle()
    expect(syncCalls).toBe(3)
    expect(e.store.noteV2(n.id)?.state).toBe('draft')
    expect(e.store.tasksV2()[0]?.status).toBe('draft')
    expect(e.store.outboxes()).toHaveLength(1)
    expect(e.store.storageAvailable).toBe(false)
    expect((await fetch(e.url + '/health/ready')).status).toBe(503)
    e.store.close()
    armed = false
    const reopened = new ShiftStore(e.dir)
    closers.push(() => reopened.close())
    expect(reopened.storageAvailable).toBe(true)
    expect(reopened.tasksV2()[0]?.status).toBe('open')
    expect(reopened.notesV2()[0]?.bindings[0]?.confirmedBy).toBe(ANA)
    expect(reopened.outboxes().at(-1)?.state).toBe('queued')
    expect(reopened.inboxes().at(-1)?.state).toBe('processed')
  })
  it('processing retry budgets persist across restart and exhausted organizer stores raw source', async () => {
    const fail = {
      async organize() {
        throw new Error('synthetic')
      }
    }
    const e = await setup({ organizer: fail })
    await e.say('n', RAW)
    expect(e.store.inboxes()[0]?.attempt).toBe(1)
    expect(e.store.inboxes()[0]?.state).toBe('retry_wait')
    for (const delay of [30000, 120000, 600000, 1800000]) {
      e.advance(delay)
      e.assistant.resumePending()
      await e.assistant.idle()
    }
    expect(e.store.inboxes()[0]?.attempt).toBe(5)
    expect(e.store.inboxes()[0]?.state).toBe('review_required')
    expect(e.store.inboxes()[0]?.error).toBe('organizer_failed')
    expect(e.store.inboxes()[0]?.text).toBe(RAW)
    expect(e.store.notesV2()).toEqual([])
    expect(e.store.outboxes()[0]?.payloadText).toContain(RAW)
    expect(e.store.tasksV2()).toEqual([])
    await e.say('help', 'ajuda')
    expect(e.store.inboxes().at(-1)?.state).toBe('processed')
  })
  it('five total definitely-not-accepted attempts persist backoff and do not loop', async () => {
    let calls = 0
    const e = await setup({
      transport: async () => {
        calls++
        return {
          status: 'definitely_not_accepted',
          code: 'qualified_fixture_rejection'
        }
      }
    })
    await e.say('n', RAW)
    expect(calls).toBe(1)
    for (const delay of [30000, 120000, 600000, 1800000]) {
      e.advance(delay)
      e.assistant.resumePending()
      await e.assistant.idle()
    }
    expect(calls).toBe(5)
    expect(e.store.outboxes()[0]?.state).toBe('review_required')
    expect(e.store.outboxes()[0]?.attempt).toBe(5)
    e.advance(99999999)
    e.assistant.resumePending()
    await e.assistant.idle()
    expect(calls).toBe(5)
  })
  it.each(['disconnect', '5xx', 'hang'])(
    'post-start %s is uncertain, no retry and confirmation blocked',
    async (mode) => {
      const e = await setup()
      e.mode(mode)
      await e.say('n', RAW)
      expect(e.store.outboxes()[0]?.state).toBe('uncertain')
      e.mode('accepted')
      e.advance(999999)
      e.assistant.resumePending()
      await e.assistant.idle()
      expect(e.sent).toHaveLength(1)
      await e.say('c', 'ok nota ' + e.token())
      expect(e.store.openTasks()).toEqual([])
    }
  )
  it('restart processing and dispatching stages recovers processing once and marks dispatch uncertain', async () => {
    const e = await setup()
    await e.say('n', RAW)
    const b = e.store.outboxes()[0]!
    const actor = { kind: 'member' as const, memberPhone: ANA }
    const at = '2026-10-03T18:00:30Z'
    // Use another admitted message with no runner while paused then simulate stage abandoned at process stop.
    await e.assistant.stop()
    e.store.close()
    const store = new ShiftStore(e.dir)
    closers.push(() => store.close())
    const n = store.notesV2()[0]!
    expect(n.previewIds[0]).toBe(b.id)
    // Existing receipts remain immutable; a new queued response can legitimately be dispatching at crash.
    const e2 = await setup({
      dir: volume(),
      transport: async () => ({
        status: 'definitely_not_accepted',
        code: 'qualified'
      })
    })
    await e2.say('n', RAW)
    e2.advance(30000)
    const pending = e2.store.outboxes()[0]!
    commit(e2.store, 'manual-dispatch', {
      v: 2,
      type: 'outbox_dispatch_started',
      at,
      actor,
      outboxId: pending.id,
      attempt: 2
    })
    e2.store.close()
    const r = await setup({ dir: e2.dir })
    r.assistant.recoverPending()
    await r.assistant.idle()
    expect(r.store.outboxes()[0]?.state).toBe('uncertain')
    expect(r.sent).toHaveLength(0)
  })
  it('pause control proceeds independently of pending organizer and sends, without new content effect', async () => {
    let resolve: (v: unknown) => void = () => {}
    const organizer = {
      organize: (_t: string, _d: Date, signal?: AbortSignal) =>
        new Promise<unknown>((r) => {
          resolve = r
          signal?.addEventListener('abort', () => r(RESPONSE), { once: true })
        })
    }
    const e = await setup({ organizer })
    await e.post('n', RAW)
    await new Promise((r) => setTimeout(r, 10))
    const start = performance.now()
    const paused = await e.post('p', 'pausar assistente', MANAGER)
    expect(paused.status).toBe(200)
    expect(performance.now() - start).toBeLessThan(1000)
    expect(e.store.paused).toBe(true)
    resolve(RESPONSE)
    await e.assistant.idle()
    expect(e.store.notesV2()).toHaveLength(0)
    expect(e.store.inboxes()[0]?.state).toBe('received')
    expect(e.sent.every((s) => String(s.body.text).includes('pausado'))).toBe(
      true
    )
  })
  it('recipient revocation is checked at dispatch, queued preview cannot start', async () => {
    const mutable = [...members]
    const e = await setup({
      transport: async () => ({
        status: 'definitely_not_accepted',
        code: 'qualified'
      })
    })
    await e.say('n', RAW)
    mutable.splice(0, 1) // Replace assistant using a live current registry without granting rights from history.
    const next = new ShiftAssistant({
      store: e.store,
      members: mutable,
      whatsapp: e.client,
      organizer: staticOrganizer,
      transcriber: {
        async transcribe() {
          return ''
        }
      },
      clock: () => new Date('2026-10-04T00:00:00Z')
    })
    await e.assistant.stop()
    closers.push(() => next.stop())
    next.resumePending()
    await next.idle()
    expect(e.store.outboxes()[0]?.state).toBe('cancelled')
  })
  it('stop releases its own store lock and default composed text makes zero LLM requests', async () => {
    const dir = volume()
    const e = await setup()
    const config = loadShiftConfig({
      SHIFT_PROVIDER: 'waha',
      SHIFT_MEMBERS: ANA + '=Ana;' + MANAGER + '=Manager*',
      SHIFT_WEBHOOK_SECRET: SECRET,
      SHIFT_DATA_DIR: dir,
      SHIFT_PORT: '0',
      SHIFT_HOST: '127.0.0.1',
      WAHA_URL: 'http://127.0.0.1:1',
      WAHA_API_KEY: 'synthetic',
      WHISPER_URL: 'http://127.0.0.1:2',
      LLM_BASE_URL: 'http://127.0.0.1:3',
      LLM_LOCATION: 'local',
      LLM_MODEL: 'synthetic'
    })
    const app = composeShiftApp(config)
    const port = await app.start()
    expect(port).not.toBe(3400)
    await app.stop()
    await app.stop()
    const r = new ShiftStore(dir)
    closers.push(() => r.close())
    expect(r.storageAvailable).toBe(true)
    expect(e.store.storageAvailable).toBe(true)
  })
})
describe('durable failures and recovery boundaries', () => {
  it('stable transport timestamp excluded; provider/session/message tuple stays distinct and defaults reject foreign sessions', async () => {
    const e = await setup()
    await e.say('id', RAW)
    e.advance(99999)
    expect(await (await e.say('id', RAW)).json()).toEqual({ accepted: false })
    expect(e.store.notesV2()).toHaveLength(1)
    expect(
      e.client.parseWebhook(
        { ...e.body('id', 'x'), session: 'other' },
        new Date().toISOString()
      )
    ).toBeUndefined()
    const other = new ShiftAssistant({
      store: e.store,
      members,
      whatsapp: e.client,
      session: 'other',
      organizer: staticOrganizer,
      transcriber: {
        async transcribe() {
          return ''
        }
      }
    })
    closers.push(() => other.stop())
    other.receive({
      provider: 'waha',
      messageId: 'id',
      fromPhone: ANA,
      kind: 'text',
      text: RAW,
      receivedAt: new Date().toISOString()
    })
    await other.idle()
    expect(e.store.inboxes()).toHaveLength(2)
    expect(e.store.notesV2()).toHaveLength(2)
  })
  it('processing stage crash recovers after close/reopen, preserving attempt and elaboration time', async () => {
    const e = await setup()
    await e.say('pause', 'pausar assistente', MANAGER)
    await e.say('pending', RAW)
    const i = e.store.inboxes().at(-1)!
    // Simulate abandoned stage using the same typed admission, guards and on-disk transaction.
    const actor = { kind: 'member' as const, memberPhone: MANAGER }
    const at = '2026-10-03T18:00:00Z'
    const control = e.store.inboxes()[0]!
    expect(control.state).toBe('processed')
    // Resume control and stop scheduling before admitting through a new durable paused-independent lane.
    await e.assistant.stop()
    e.store.close()
    const store = new ShiftStore(e.dir)
    closers.push(() => store.close())
    const resumeKey = JSON.stringify(['waha', 'fixture', 'manual-resume'])
    const resume = {
      key: resumeKey,
      digest: '0'.repeat(64),
      provider: 'waha' as const,
      session: 'fixture',
      messageId: 'manual-resume',
      memberPhone: MANAGER,
      kind: 'text' as const,
      text: 'retomar assistente',
      receivedAt: at,
      state: 'received' as const,
      stage: 'command' as const,
      attempt: 0
    }
    resume.digest = inputDigest(resume)
    commit(store, 'resume-inbound', {
      v: 2,
      type: 'inbound_recorded',
      at,
      actor,
      inbox: resume
    })
    const box = {
      id: 'resume-fixture',
      purpose: 'control' as const,
      sourceTransitionId: 'resume-fixture',
      recipientMemberId: MANAGER,
      payloadText: 'retomado',
      payloadSha256: sha256('retomado'),
      state: 'queued' as const,
      attempt: 0
    }
    commit(store, 'resume-control', {
      v: 2,
      type: 'operation_resumed',
      at,
      actor,
      key: resumeKey,
      outbox: box
    })
    commit(store, 'abandoned-stage', {
      v: 2,
      type: 'processing_started',
      at,
      actor: { kind: 'member', memberPhone: ANA },
      key: i.key,
      stage: 'organize',
      attempt: 1,
      deadline: '2026-10-03T18:03:30Z',
      draftAt: at
    })
    store.close()
    const r = await setup({ dir: e.dir })
    r.assistant.recoverPending()
    await r.assistant.idle()
    expect(r.store.inbox(i.key)?.attempt).toBe(2)
    expect(r.store.inbox(i.key)?.state).toBe('processed')
    expect(r.store.notesV2()[0]?.createdAt).toBe(at)
    expect(r.store.notesV2()[0]?.rawText).toBe(RAW)
  })
  it('restart preserves inbox and outbox backoff budgets, no attempt before due', async () => {
    let calls = 0
    const organizer = {
      async organize() {
        calls++
        throw new Error('transient')
      }
    }
    const e = await setup({ organizer })
    await e.say('n', RAW)
    expect(calls).toBe(1)
    const before = e.store.inboxes()[0]!
    await e.assistant.stop()
    e.store.close()
    const r = await setup({ dir: e.dir, organizer })
    r.assistant.recoverPending()
    await r.assistant.idle()
    expect(calls).toBe(1)
    expect(r.store.inboxes()[0]?.nextAttemptAt).toBe(before.nextAttemptAt)
    r.advance(30000)
    r.assistant.resumePending()
    await r.assistant.idle()
    expect(calls).toBe(2)
    expect(r.store.inboxes()[0]?.attempt).toBe(2)
    let sends = 0
    const reject = async () => {
      sends++
      return {
        status: 'definitely_not_accepted' as const,
        code: 'qualified_fixture'
      }
    }
    const out = await setup({ transport: reject })
    await out.say('n', RAW)
    await out.assistant.stop()
    out.store.close()
    const next = await setup({ dir: out.dir, transport: reject })
    next.assistant.recoverPending()
    await next.assistant.idle()
    expect(sends).toBe(1)
    next.advance(30000)
    next.assistant.resumePending()
    await next.assistant.idle()
    expect(sends).toBe(2)
    expect(next.store.outboxes()[0]?.attempt).toBe(2)
  })
  it('receipt persistence failure blocks effects; reopen recovers acceptance without another HTTP request', async () => {
    let armed = false
    const e = await setup({
      io: {
        sync(fd) {
          if (armed) throw new Error('synthetic receipt sync')
          fs.fsyncSync(fd)
        }
      },
      transport: async () => {
        armed = true
        return {
          status: 'provider_accepted',
          receipt: {
            status: 201,
            at: new Date().toISOString(),
            sha256: sha256('{}'),
            providerId: 'synthetic-receipt'
          }
        }
      }
    })
    await e.say('n', RAW)
    expect(e.store.storageAvailable).toBe(false)
    expect(e.store.outboxes()[0]?.state).toBe('dispatching')
    expect(e.store.openTasks()).toEqual([])
    await e.assistant.stop()
    e.store.close()
    const r = await setup({ dir: e.dir })
    r.assistant.recoverPending()
    await r.assistant.idle()
    expect(r.store.outboxes()[0]?.state).toBe('provider_accepted')
    expect(r.sent).toHaveLength(0)
    await r.say('help', 'ajuda')
    expect(r.store.inboxes().at(-1)?.state).toBe('processed')
  })
  it('deadline releases ignored organizer promises, persists retry; stop interrupts text job and preserves source', async () => {
    const e = await setup({
      organizer: { organize: async () => new Promise(() => {}) },
      modelTimeoutMs: 20
    })
    await e.say('n', RAW)
    expect(e.store.inboxes()[0]?.state).toBe('retry_wait')
    expect(e.store.inboxes()[0]?.error).toBe('organizer_deadline')
    expect(e.store.notesV2()).toEqual([])
    const r = await setup({
      organizer: { organize: async () => new Promise(() => {}) }
    })
    await r.post('n', RAW)
    await new Promise((resolve) => setTimeout(resolve, 5))
    const start = performance.now()
    await r.assistant.stop()
    expect(performance.now() - start).toBeLessThan(1000)
    expect(r.store.inboxes()[0]?.state).toBe('received')
    expect(r.store.inboxes()[0]?.attempt).toBe(0)
    expect(r.store.notesV2()).toEqual([])
  })
  it('pause against blocked real HTTP prevents next content send; bounded stop preserves uncertain state', async () => {
    const e = await setup()
    e.mode('hang')
    await e.post('n', RAW)
    await new Promise((resolve) => setTimeout(resolve, 10))
    await e.post('next', RAW)
    const start = performance.now()
    const pause = await e.post('pause', 'pausar assistente', MANAGER)
    expect(pause.status).toBe(200)
    expect(performance.now() - start).toBeLessThan(1000)
    await e.assistant.idle()
    expect(e.store.paused).toBe(true)
    expect(
      e.sent.filter((s) => String(s.body.text).includes('RASCUNHO'))
    ).toHaveLength(1)
    expect(e.store.outboxes()[0]?.state).toBe('uncertain')
    await e.assistant.stop()
    expect(
      e.store.inboxes().find((i) => i.messageId === 'next')?.state
    ).toMatch(/received|processed/)
  })
  it('default real composition denies clinical webhook before fake model endpoint or budget/provider work', async () => {
    let modelRequests = 0
    const model = createServer((_req, res) => {
      modelRequests++
      res.end('{}')
    })
    const modelUrl = await bind(model)
    closers.push(() => closeServer(model))
    const e = await setup()
    const recipient = createServer((req, res) => {
      req.resume()
      res.end('{}')
    })
    const waUrl = await bind(recipient)
    closers.push(() => closeServer(recipient))
    const config = loadShiftConfig({
      SHIFT_PROVIDER: 'waha',
      SHIFT_MEMBERS: ANA + '=Ana;' + MANAGER + '=Manager*',
      SHIFT_WEBHOOK_SECRET: SECRET,
      SHIFT_DATA_DIR: volume(),
      SHIFT_PORT: '0',
      SHIFT_HOST: '127.0.0.1',
      WAHA_URL: waUrl,
      WAHA_API_KEY: 'synthetic',
      WHISPER_URL: 'http://127.0.0.1:1',
      LLM_BASE_URL: modelUrl,
      LLM_LOCATION: 'local',
      LLM_MODEL: 'synthetic'
    })
    const app = composeShiftApp(config)
    closers.push(() => app.stop())
    const port = await app.start()
    const post = await fetch(`http://127.0.0.1:${port}/webhooks/waha`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-cvg-webhook-secret': SECRET
      },
      body: JSON.stringify({
        event: 'message',
        payload: { id: 'clinical-default', from: ANA + '@c.us', body: RAW }
      })
    })
    expect(post.status).toBe(200)
    await app.assistant.idle()
    expect(modelRequests).toBe(0)
    expect(app.store.notesV2()[0]?.warnings).toContain('policy_denied')
    expect(app.store.tasksV2()).toEqual([])
    expect(e.store.inboxes()).toEqual([])
  })
  it.each(['before_journal_write', 'after_journal_lf', 'after_journal_sync'])(
    'real SIGKILL %s around confirmation yields whole activation or none in a new recovery volume',
    async (point) => {
      const e = await setup()
      await e.say('n', RAW)
      const n = e.store.notesV2()[0]!
      await e.assistant.stop()
      e.store.close()
      const module = new URL('../store.ts', import.meta.url).href
      const code = `import {ShiftStore} from ${JSON.stringify(module)};import {canonical,sha256} from ${JSON.stringify(new URL('../journal.ts', import.meta.url).href)};import {inputDigest} from ${JSON.stringify(new URL('../vertical-state.ts', import.meta.url).href)};let armed=false;const store=new ShiftStore(${JSON.stringify(e.dir)},{io:{checkpoint(p){if(armed&&p===${JSON.stringify(point)})process.kill(process.pid,'SIGKILL')}}});const actor={kind:'member',memberPhone:${JSON.stringify(ANA)}};const key=JSON.stringify(['waha','fixture','kill-confirm']);const at='2026-10-03T18:00:00Z';const i={key,digest:'0'.repeat(64),provider:'waha',session:'fixture',messageId:'kill-confirm',memberPhone:actor.memberPhone,kind:'text',text:'ok nota '+${JSON.stringify(n.token)},receivedAt:at,state:'received',stage:'command',attempt:0};i.digest=inputDigest(i);function commit(id,event){const expected={};for(const [entity,id]of store.references(event)){expected[entity]??={};expected[entity][id]=store.revision(entity,id)}store.commit({transitionId:id,expected,changes:[event]})}commit('kill-admit',{v:2,type:'inbound_recorded',at,actor,inbox:i});commit('kill-start',{v:2,type:'processing_started',at,actor,key,stage:'command',attempt:1,deadline:'2026-10-03T18:03:30Z',draftAt:at});const n=store.notesV2()[0];const text='confirmed';const box={id:'kill-response',purpose:'response',sourceTransitionId:'kill-response',recipientMemberId:actor.memberPhone,payloadText:text,payloadSha256:sha256(text),state:'queued',attempt:0};armed=true;commit('kill-confirm',{v:2,type:'confirmation_committed',at,actor,key,noteId:n.id,revision:n.revision,hash:n.organizedSha256,token:n.token,tasks:n.tasks.map(t=>({...t,status:'open'})),bindings:n.bindings.map(b=>({...b,confirmedBy:actor.memberPhone,confirmedAt:at})),outbox:box});`
      const child = spawnSync(
        process.execPath,
        ['--import', 'tsx', '--input-type=module', '-e', code],
        { encoding: 'utf8', timeout: 15000 }
      )
      expect(child.signal, child.stderr).toBe('SIGKILL')
      expect(() => new ShiftStore(e.dir)).toThrow('STORE_LOCKED')
      const recovered = volume()
      fs.cpSync(e.dir, recovered, { recursive: true })
      fs.writeFileSync(
        join(recovered, 'operator-recovery.json'),
        JSON.stringify({
          operator: 'synthetic',
          signal: child.signal,
          childExited: true,
          sourceVolume: e.dir,
          decision: 'recover_owned_copy_after_child_exit'
        })
      )
      fs.unlinkSync(join(recovered, 'store.lock'))
      const r = new ShiftStore(recovered)
      closers.push(() => r.close())
      expect(r.storageAvailable).toBe(true)
      const full = point !== 'before_journal_write'
      expect(r.notesV2()[0]?.state).toBe(full ? 'confirmed' : 'draft')
      expect(r.tasksV2()[0]?.status).toBe(full ? 'open' : 'draft')
      expect(r.outboxes().some((b) => b.id === 'kill-response')).toBe(full)
      expect(Boolean(r.notesV2()[0]?.bindings[0]?.confirmedBy)).toBe(full)
      expect(fs.existsSync(join(e.dir, 'store.lock'))).toBe(true)
    }
  )
})
describe('R2 public identity omission regression', () => {
  it.each(['waha', 'evolution'] as const)(
    '%s HTTP confirmation and reopen reject explicit source ID omitted or contradicted by prepared output',
    async (provider) => {
      let output = structuredClone(RESPONSE)
      const http: {
        messageId: string
        text: string
        status: number
        response: unknown
      }[] = []
      const e = await setup({
        provider,
        organizer: {
          async organize() {
            return structuredClone(output)
          }
        }
      })
      await e.say('history', RAW)
      await e.say('confirm-history', 'ok nota ' + e.token())
      expect(e.store.knownPatients('Rex').map((p) => p.id)).toEqual(['20202'])
      for (const sourceId of ['99999', '20202']) {
        for (const mode of ['null', 'omitted', 'present', 'contradictory']) {
          const id = sourceId + '-' + mode
          const raw = RAW.replaceAll('20202', sourceId)
          output = structuredClone(RESPONSE)
          output.pacientes[0]!.id =
            mode === 'null' ? null : mode === 'present' ? sourceId : '88888'
          if (mode === 'omitted') delete output.pacientes[0]!.id
          output.evidence[0]!.quote = 'Paciente Rex, ID ' + sourceId
          output.evidence = output.evidence.filter(
            (v) => v.path !== 'pacientes.p1.id'
          )
          if (mode === 'present' || mode === 'contradictory')
            output.evidence.push({
              path: 'pacientes.p1.id',
              patientRef: 'p1',
              quote: 'ID ' + output.pacientes[0]!.id
            })
          // The exact critic repro retains the old task ID despite omitting p.id.
          output.pendencias[0]!.pacienteId =
            mode === 'present' ? sourceId : '20202'
          const admission = await e.say(id, raw)
          expect(admission.status).toBe(200)
          http.push({
            messageId: id,
            text: raw,
            status: admission.status,
            response: await admission.json()
          })
          const n = e.store.notesV2().at(-1)!
          expect(n.rawText).toBe(raw)
          const confirmationText = 'ok nota ' + n.token
          const confirmation = await e.say('confirm-' + id, confirmationText)
          expect(confirmation.status).toBe(200)
          http.push({
            messageId: 'confirm-' + id,
            text: confirmationText,
            status: confirmation.status,
            response: await confirmation.json()
          })
          if (mode === 'present') {
            expect(n.issues).toEqual([])
            expect(
              e.store
                .openTasks()
                .filter((t) => t.noteId === n.id)
                .map((t) => t.patientId)
            ).toEqual([sourceId])
          } else {
            expect(
              n.issues.some(
                (v) => v.path === 'pacientes.p1.id' && v.severity === 'blocking'
              )
            ).toBe(true)
            expect(
              n.bindings.every(
                (b) => b.provenance === 'unresolved' && !b.idLiteral
              )
            ).toBe(true)
            expect(e.store.tasksV2().filter((t) => t.noteId === n.id)).toEqual(
              []
            )
            expect(e.store.noteV2(n.id)?.state).toBe('draft')
          }
        }
      }
      const before = canonical([
        e.store.notesV2(),
        e.store.tasksV2(),
        e.store.knownPatients('Rex')
      ])
      await e.assistant.stop()
      e.store.close()
      const reopened = new ShiftStore(e.dir)
      closers.push(() => reopened.close())
      expect(
        canonical([
          reopened.notesV2(),
          reopened.tasksV2(),
          reopened.knownPatients('Rex')
        ])
      ).toBe(before)
      const blocked = reopened.notesV2().filter((n) => n.issues.length)
      expect(blocked).toHaveLength(6)
      for (const n of blocked) {
        expect(n.bindings.every((b) => !b.confirmedBy && !b.idLiteral)).toBe(
          true
        )
        expect(reopened.tasksV2().filter((t) => t.noteId === n.id)).toEqual([])
      }
      fs.writeFileSync(
        join(e.dir, 'r2-identity-http-proof.json'),
        JSON.stringify(
          {
            provider,
            synthetic: true,
            http,
            sent: e.sent,
            notes: reopened.notesV2(),
            tasks: reopened.tasksV2(),
            memory: reopened.knownPatients('Rex'),
            reopenedMatches: true
          },
          null,
          2
        )
      )
    }
  )
})

describe('R2-P3 real organizer processing SIGKILL', () => {
  it.each([2, 5])(
    'SIGKILL in organizer attempt %i reopens same journal/stage/source with five-attempt budget',
    async (killAttempt) => {
      const dir = volume()
      const code = `
      import fs from 'node:fs';
      import {ShiftStore} from ${JSON.stringify(new URL('../store.ts', import.meta.url).href)};
      import {ShiftAssistant} from ${JSON.stringify(new URL('../assistant.ts', import.meta.url).href)};
      import {WahaClient} from ${JSON.stringify(new URL('../whatsapp.ts', import.meta.url).href)};
      import {buildShiftServer} from ${JSON.stringify(new URL('../server.ts', import.meta.url).href)};
      let now=new Date('2026-10-03T18:00:00Z');
      const store=new ShiftStore(${JSON.stringify(dir)});
      const whatsapp=new WahaClient({baseUrl:'http://127.0.0.1:1',session:'fixture',apiKey:'synthetic',fetch:async()=>{throw new Error('no send before draft')}});
      const assistant=new ShiftAssistant({store,members:${JSON.stringify(members)},whatsapp,clock:()=>now,
        transcriber:{async transcribe(){throw new Error('text only')}},
        organizer:{async organize(text){
          const inbox=store.inboxes()[0];
          if(inbox.attempt===${killAttempt}){
            fs.writeFileSync(${JSON.stringify(join(dir, 'kill-stage.json'))},JSON.stringify({pid:process.pid,text,inbox,notes:store.notesV2(),tasks:store.tasksV2(),outboxes:store.outboxes()}));
            process.kill(process.pid,'SIGKILL');
            await new Promise(()=>{});
          }
          throw new Error('synthetic transient');
        }}});
      const server=buildShiftServer({assistant,store,whatsapp,webhookSecret:${JSON.stringify(SECRET)},clock:()=>now});
      server.listen(0,'127.0.0.1',()=>process.send({port:server.address().port}));
      process.on('message',async()=>{
        await assistant.idle();
        for(const delay of [30000,120000,600000,1800000]){
          now=new Date(+now+delay);assistant.resumePending();await assistant.idle();
        }
        process.exit(3);
      });
    `
      const child = spawn(
        process.execPath,
        ['--import', 'tsx', '--input-type=module', '-e', code],
        { cwd: process.cwd(), stdio: ['ignore', 'pipe', 'pipe', 'ipc'] }
      )
      let stderr = ''
      child.stderr!.on('data', (chunk) => {
        stderr += chunk
      })
      const exit = new Promise<{
        code: number | null
        signal: NodeJS.Signals | null
      }>((resolve, reject) => {
        child.once('error', reject)
        child.once('exit', (code, signal) => resolve({ code, signal }))
      })
      const watchdog = setTimeout(() => child.kill('SIGTERM'), 10000)
      try {
        const port = await new Promise<number>((resolve, reject) => {
          child.once('message', (m) => resolve((m as { port: number }).port))
          child.once('exit', () =>
            reject(new Error('child exited before HTTP ready: ' + stderr))
          )
        })
        expect([3400, 3401]).not.toContain(port)
        const r = await fetch('http://127.0.0.1:' + port + '/webhooks/waha', {
          method: 'POST',
          headers: {
            'content-type': 'application/json',
            'x-cvg-webhook-secret': SECRET
          },
          body: JSON.stringify({
            event: 'message',
            session: 'fixture',
            payload: { id: 'kill-organizer', from: ANA + '@c.us', body: RAW }
          })
        })
        expect(r.status).toBe(200)
        expect(await r.json()).toEqual({ accepted: true })
        child.send('drive-retries')
        const result = await exit
        expect(result, stderr).toEqual({ code: null, signal: 'SIGKILL' })
        const checkpoint = JSON.parse(
          fs.readFileSync(join(dir, 'kill-stage.json'), 'utf8')
        )
        expect(checkpoint.pid).toBe(child.pid)
        expect(checkpoint.text).toBe(RAW)
        expect(checkpoint.inbox).toMatchObject({
          state: 'processing',
          stage: 'organize',
          attempt: killAttempt,
          draftAt: '2026-10-03T18:00:00.000Z'
        })
        expect(checkpoint.notes).toEqual([])
        expect(checkpoint.tasks).toEqual([])
        expect(checkpoint.outboxes).toEqual([])
        expect(() => new ShiftStore(dir)).toThrow('STORE_LOCKED')
        // Synthetic operator recovery only after the owned child has demonstrably exited.
        const manifest = JSON.parse(
          fs.readFileSync(join(dir, 'journal/manifest.json'), 'utf8')
        )
        const journalBefore = manifest.segments.map((s: { path: string }) =>
          sha256(fs.readFileSync(join(dir, s.path)))
        )
        fs.writeFileSync(
          join(dir, 'operator-lock-recovery.json'),
          JSON.stringify({
            childPid: child.pid,
            ...result,
            childExited: true,
            decision: 'release_owned_synthetic_lock'
          })
        )
        fs.unlinkSync(join(dir, 'store.lock'))
        let calls = 0
        const e = await setup({
          dir,
          organizer: {
            async organize(text) {
              calls++
              expect(text).toBe(RAW)
              return structuredClone(RESPONSE)
            }
          }
        })
        expect(
          manifest.segments.map((s: { path: string }) =>
            sha256(fs.readFileSync(join(dir, s.path)))
          )
        ).toEqual(journalBefore)
        expect(e.store.inboxes()[0]).toEqual(checkpoint.inbox)
        e.assistant.recoverPending()
        await e.assistant.idle()
        expect(e.store.inboxes()[0]).toMatchObject({
          key: checkpoint.inbox.key,
          stage: 'organize',
          attempt: killAttempt < 5 ? killAttempt + 1 : 5,
          draftAt: checkpoint.inbox.draftAt,
          text: RAW,
          state: killAttempt < 5 ? 'processed' : 'review_required'
        })
        expect(calls).toBe(killAttempt < 5 ? 1 : 0)
        if (killAttempt < 5) {
          const n = e.store.notesV2()[0]!
          expect(e.store.notesV2()).toHaveLength(1)
          expect(n.id).toBe(sha256(JSON.stringify([checkpoint.inbox.key, 1])))
          expect(n.messageKey).toBe(checkpoint.inbox.key)
          expect(n.createdAt).toBe(checkpoint.inbox.draftAt)
          expect(n.rawText).toBe(RAW)
          expect(e.store.openTasks()).toEqual([])
          await e.say('confirm-recovered', 'ok nota ' + n.token)
          expect(e.store.openTasks()).toHaveLength(1)
          expect(e.store.openTasks()[0]?.patientId).toBe('20202')
        } else {
          expect(e.store.notesV2()).toEqual([])
          expect(e.store.tasksV2()).toEqual([])
        }
        e.advance(99999999)
        e.assistant.resumePending()
        await e.assistant.idle()
        expect(calls).toBe(killAttempt < 5 ? 1 : 0)
        await e.say('help-after-kill', 'ajuda')
        expect(e.store.inboxes().at(-1)?.state).toBe('processed')
        const expected = canonical([
          e.store.notesV2(),
          e.store.tasksV2(),
          e.store.inboxes()
        ])
        await e.assistant.stop()
        e.store.close()
        const reopened = new ShiftStore(dir)
        closers.push(() => reopened.close())
        expect(
          canonical([
            reopened.notesV2(),
            reopened.tasksV2(),
            reopened.inboxes()
          ])
        ).toBe(expected)
      } finally {
        clearTimeout(watchdog)
        if (child.exitCode === null && child.signalCode === null)
          child.kill('SIGKILL')
        await exit
      }
    }
  )
})

describe('bounded text preview parts', () => {
  it('persists ordered UTF8-safe parts and requires acceptance of every part for raw confirmation', async () => {
    const raw = '漢'.repeat(16000)
    const e = await setup({ organizer: new ModelOrganizer() })
    await e.say('n', raw)
    const n = e.store.notesV2()[0]!
    expect(n.previewIds).toHaveLength(2)
    expect(e.sent).toHaveLength(2)
    const texts = e.sent.map((s) => String(s.body.text))
    expect(texts.every((t) => Buffer.byteLength(t) <= 32768)).toBe(true)
    expect(texts.join('')).toContain(raw)
    expect(texts.join('')).toContain(n.token)
    expect(
      e.store.outboxes().every((b) => b.state === 'provider_accepted')
    ).toBe(true)
    await e.say('c', 'ok nota ' + n.token)
    expect(e.store.notesV2()[0]?.state).toBe('confirmed')
    expect(e.store.tasksV2()).toEqual([])
  })
  it('uncertain first part prevents subsequent parts, including after close/reopen', async () => {
    const e = await setup({ organizer: new ModelOrganizer() })
    e.mode('disconnect')
    await e.say('n', '漢'.repeat(16000))
    expect(e.sent).toHaveLength(1)
    expect(e.store.outboxes().map((b) => b.state)).toEqual([
      'uncertain',
      'queued'
    ])
    const token = e.token()
    await e.assistant.stop()
    e.store.close()
    const r = await setup({ dir: e.dir })
    r.assistant.recoverPending()
    await r.assistant.idle()
    expect(r.sent).toHaveLength(0)
    await r.say('c', 'ok nota ' + token)
    expect(r.store.notesV2()[0]?.state).toBe('draft')
    expect(r.store.openTasks()).toEqual([])
  })
})
describe('source identity/fidelity through product caller', () => {
  it('binds second homonym by literal ID and source block even when model array order reverses', async () => {
    const raw = RAW + '\nPaciente Rex, ID 10101, leito 7. Evolução: dormindo.'
    const response: OrganizedV2 = {
      ...structuredClone(RESPONSE),
      pacientes: [
        {
          localRef: 'p2',
          nome: 'Rex',
          id: '10101',
          leito: '7',
          evolucao: 'dormindo',
          exames_pedidos: [],
          condutas: []
        },
        RESPONSE.pacientes[0]!
      ],
      evidence: [
        ...RESPONSE.evidence,
        {
          path: 'pacientes.p2.nome',
          patientRef: 'p2',
          quote: 'Paciente Rex, ID 10101'
        },
        { path: 'pacientes.p2.id', patientRef: 'p2', quote: 'ID 10101' },
        { path: 'pacientes.p2.leito', patientRef: 'p2', quote: 'leito 7' },
        {
          path: 'pacientes.p2.evolucao',
          patientRef: 'p2',
          quote: 'Evolução: dormindo'
        }
      ]
    }
    const e = await setup({
      organizer: {
        async organize() {
          return response
        }
      }
    })
    await e.say('n', raw)
    expect(e.store.notesV2()[0]?.issues).toEqual([])
    await e.say('c', 'ok nota ' + e.token())
    expect(e.store.openTasks()[0]?.patientId).toBe('20202')
  })
  it.each([
    'invented',
    'swapped',
    'unit',
    'ref',
    'missingQuote',
    'duplicateQuote'
  ])(
    'blocks %s without derivative tasks or trusted binding activation',
    async (kind) => {
      const r = structuredClone(RESPONSE)
      let raw = RAW
      if (kind === 'invented') r.pacientes[0]!.id = '99999'
      if (kind === 'swapped') r.pacientes[0]!.evolucao = 'dose 2 mg'
      if (kind === 'unit') {
        raw = RAW.replace('alerta', 'dose 1 mg')
        r.pacientes[0]!.evolucao = 'dose 1 g'
        r.evidence[3]!.quote = 'Evolução: dose 1 mg'
      }
      if (kind === 'ref') r.pendencias[0]!.pacienteRef = 'p2'
      if (kind === 'missingQuote')
        r.evidence = r.evidence.filter((e) => !e.path.endsWith('descricao'))
      if (kind === 'duplicateQuote')
        raw = RAW.replace(
          'Evolução: alerta.',
          'Evolução: alerta. Evolução: alerta.'
        )
      const e = await setup({
        organizer: {
          async organize() {
            return r
          }
        }
      })
      await e.say('n', raw)
      expect(e.store.notesV2()[0]!.issues.length).toBeGreaterThan(0)
      expect(e.store.tasksV2()).toEqual([])
      await e.say('c', 'ok nota ' + e.token())
      expect(e.store.notesV2()[0]?.state).toBe('draft')
      expect(e.store.knownPatients('Rex')).toEqual([])
    }
  )
  it('rejects dose/field swaps even when all numbers exist elsewhere in the document', async () => {
    const raw =
      'Paciente Alfa, ID 111. Condutas: dose 1 mg. Evolução: glicemia 92 mg/dL.\nPaciente Beta, ID 222. Condutas: dose 2 mg.'
    const response: OrganizedV2 = {
      schemaVersion: 2,
      pacientes: [
        {
          localRef: 'p1',
          nome: 'Alfa',
          id: '111',
          condutas: ['dose 2 mg'],
          exames_pedidos: []
        }
      ],
      pendencias: [],
      duvidas: [],
      evidence: [
        {
          path: 'pacientes.p1.nome',
          patientRef: 'p1',
          quote: 'Paciente Alfa, ID 111'
        },
        { path: 'pacientes.p1.id', patientRef: 'p1', quote: 'ID 111' },
        {
          path: 'pacientes.p1.condutas.0',
          patientRef: 'p1',
          quote: 'Condutas: dose 1 mg'
        }
      ]
    }
    const e = await setup({
      organizer: {
        async organize() {
          return response
        }
      }
    })
    await e.say('n', raw)
    expect(
      e.store.notesV2()[0]?.issues.some((i) => i.code === 'UNSOURCED_VALUE')
    ).toBe(true)
    await e.say('c', 'ok nota ' + e.token())
    expect(e.store.knownPatients('Alfa')).toEqual([])
    response.pacientes[0]!.condutas = ['glicemia 92 mg/dL']
    response.evidence[2]!.quote =
      'Condutas: dose 1 mg. Evolução: glicemia 92 mg/dL'
    const field = validateOrganization(raw, response)
    expect(field.issues.some((i) => i.path === 'pacientes.p1.condutas.0')).toBe(
      true
    )
  })
  it('confirmed memory is unavailable before exact author confirmation and persists literal IDs after reopen', async () => {
    const e = await setup()
    await e.say('n', RAW)
    expect(e.store.knownPatients('Rex')).toEqual([])
    await e.say('c', 'ok nota ' + e.token())
    expect(e.store.knownPatients('Rex')[0]?.id).toBe('20202')
    await e.assistant.stop()
    e.store.close()
    const r = new ShiftStore(e.dir)
    closers.push(() => r.close())
    expect(r.knownPatients('Rex')[0]?.id).toBe('20202')
  })
  it('general explicit source admits general task, arbitrary patient text cannot become a general task', async () => {
    const raw = 'Pendência geral: conferir quadro às 16:00.'
    const response: OrganizedV2 = {
      schemaVersion: 2,
      pacientes: [],
      pendencias: [
        {
          localRef: 't1',
          descricao: 'conferir quadro',
          pacienteRef: null,
          pacienteId: null,
          quando: '2026-10-03T16:00:00-03:00'
        }
      ],
      duvidas: [],
      evidence: [
        { path: 'pendencias.t1.descricao', patientRef: null, quote: raw },
        { path: 'pendencias.t1.quando', patientRef: null, quote: raw }
      ]
    }
    const e = await setup({
      organizer: {
        async organize() {
          return response
        }
      }
    })
    await e.say('n', raw)
    expect(e.store.notesV2()[0]?.issues).toEqual([])
    await e.say('c', 'ok nota ' + e.token())
    expect(e.store.tasksV2()[0]?.patientRef).toBeNull()
    expect(e.store.tasksV2()[0]?.status).toBe('open')
    const invalid = await setup({
      organizer: {
        async organize() {
          return response
        }
      }
    })
    await invalid.say('n', 'Paciente Rex, ID 20202. ' + raw)
    expect(invalid.store.tasksV2()).toEqual([])
  })
  it('unknown token and draft task mutations fail; invented date does not inherit a quoted clock', async () => {
    const e = await setup()
    await e.say('n', RAW)
    await e.say('unknown', 'ok nota not-a-token')
    await e.say('done', 'feito 1')
    await e.say('snooze', 'adiar 1 30')
    expect(e.store.tasksV2()[0]?.status).toBe('draft')
    expect(e.store.tasksV2()[0]?.generation).toBe(1)
    const response = structuredClone(RESPONSE)
    response.pendencias[0]!.quando = '2026-10-04T16:00:00-03:00'
    const date = await setup({
      organizer: {
        async organize() {
          return response
        }
      }
    })
    await date.say('n', RAW)
    expect(
      date.store
        .notesV2()[0]
        ?.issues.some((i) => i.path === 'pendencias.t1.quando')
    ).toBe(true)
    expect(date.store.tasksV2()).toEqual([])
  })
  it('validates local numeric equivalence without changing source literal or merging ID', () => {
    const raw = RAW.replace('ID 20202', 'ficha cento e um').replace(
      'alerta',
      'Volume anotado dois mililitros'
    )
    const o = structuredClone(RESPONSE)
    o.pacientes[0]!.id = '101'
    o.pacientes[0]!.evolucao = 'Volume anotado 2 mililitros'
    o.pendencias[0]!.pacienteId = '101'
    o.evidence[0]!.quote = 'Paciente Rex, ficha cento e um'
    o.evidence[1]!.quote = 'ficha cento e um'
    o.evidence[3]!.quote = 'Evolução: Volume anotado dois mililitros'
    const validation = validateOrganization(raw, o)
    expect(validation.issues).toEqual([])
    expect(validation.bindings[0]?.idLiteral).toBe('cento e um')
    expect(validation.evidence[3]?.quote).toContain('dois mililitros')
    expect(raw).toContain('dois mililitros')
  })
})

describe('approved shorthand and failed replacement recovery', () => {
  it.each(['ok', 'confirmo', 'confirmado'])(
    'accepts %s for the only eligible author preview and preserves activation on reopen',
    async (command) => {
      const e = await setup()
      await e.say('note', RAW)
      const note = e.store.notesV2()[0]!
      expect(e.store.lastPresentedNote(ANA)).toEqual({
        noteId: note.id,
        revision: note.revision
      })
      await e.say('confirmation', command)
      expect(e.store.openTasks()).toHaveLength(1)
      expect(e.store.noteV2(note.id)?.state).toBe('confirmed')
      expect(e.store.outboxes().at(-1)?.sourceTransitionId).toBe(
        'confirm:' +
          note.id +
          ':' +
          note.revision +
          ':' +
          sha256(JSON.stringify(['waha', 'fixture', 'confirmation']))
      )
      await e.assistant.stop()
      e.store.close()
      const reopened = new ShiftStore(e.dir)
      try {
        expect(reopened.openTasks()).toHaveLength(1)
        expect(reopened.lastPresentedNote(ANA)).toEqual({
          noteId: note.id,
          revision: note.revision
        })
      } finally {
        reopened.close()
      }
    }
  )
  it('requires a token for multiple eligible drafts without exposing another author notes', async () => {
    const e = await setup()
    await e.say('first', RAW)
    await e.say('second', RAW)
    await e.say('ambiguous', 'ok')
    expect(e.store.openTasks()).toHaveLength(0)
    expect(e.store.outboxes().at(-1)?.payloadText).toContain(
      'CONFIRMATION_NOT_ELIGIBLE'
    )
    await e.say('explicit', 'ok nota ' + e.token())
    expect(e.store.openTasks()).toHaveLength(1)
  })
  it('does not shorthand-confirm an earlier draft while an earlier received note is waiting for retry', async () => {
    let failing = false
    const e = await setup({
      organizer: {
        async organize() {
          if (failing) throw new Error('synthetic transient')
          return RESPONSE
        }
      }
    })
    await e.say('good', RAW)
    failing = true
    await e.say('pending', RAW)
    expect(e.store.inboxes().at(-1)?.state).toBe('retry_wait')
    await e.say('unsafe-short', 'ok')
    expect(e.store.openTasks()).toHaveLength(0)
    expect(e.store.outboxes().at(-1)?.payloadText).toContain(
      'CONFIRMATION_NOT_ELIGIBLE'
    )
  })
  it('does not shorthand-confirm an older eligible draft after an ineligible newer preview was presented', async () => {
    let output: unknown = RESPONSE
    const e = await setup({
      organizer: {
        async organize() {
          return structuredClone(output)
        }
      }
    })
    await e.say('good', RAW)
    const old = e.token()
    output = { ...RESPONSE, duvidas: ['Identidade ambígua'] }
    await e.say('blocked', RAW)
    expect(e.store.notesV2()[1]!.organized?.duvidas).toHaveLength(1)
    await e.say('unsafe-short', 'ok')
    expect(e.store.openTasks()).toHaveLength(0)
    await e.say('safe-explicit', 'ok nota ' + old)
    expect(e.store.openTasks()).toHaveLength(1)
  })
  it.each([
    'schema_invalid',
    'policy_denied',
    'invalid_request',
    'response_too_large'
  ])(
    'permanent correction %s retains the pending original and suspended task, not a prepared replacement',
    async (code) => {
      let failure = false
      const e = await setup({
        organizer: {
          async organize() {
            if (failure) throw Object.assign(new Error('synthetic'), { code })
            return RESPONSE
          }
        }
      })
      await e.say('initial', RAW)
      const old = e.store.notesV2()[0]!
      await e.say('confirm', 'ok nota ' + old.token)
      failure = true
      await e.say('replacement', 'corrigir nota ' + old.token + ': ' + RAW)
      expect(e.store.noteV2(old.id)?.state).toBe('confirmed')
      expect(e.store.noteV2(old.id)?.replacementPending).toBe(true)
      expect(e.store.tasksV2()[0]?.status).toBe('suspended')
      expect(e.store.notesV2()).toHaveLength(1)
      expect(e.store.inboxes().at(-1)?.state).toBe('review_required')
      expect(e.store.inboxes().at(-1)?.replacementText).toBe(RAW)
      expect(e.store.outboxes().at(-1)?.payloadText).toContain(
        'Correção pendente de revisão'
      )
      await e.assistant.stop()
      e.store.close()
      const reopened = new ShiftStore(e.dir)
      try {
        expect(reopened.noteV2(old.id)?.replacementPending).toBe(true)
        expect(reopened.tasksV2()[0]?.status).toBe('suspended')
      } finally {
        reopened.close()
      }
      const retry = await setup({ dir: e.dir })
      await retry.say(
        'replacement-new',
        'corrigir nota ' + old.token + ': ' + RAW
      )
      expect(retry.store.noteV2(old.id)?.state).toBe('superseded')
      expect(retry.store.tasksV2()[0]?.status).toBe('cancelled')
      expect(retry.store.tasksV2()[1]?.status).toBe('draft')
      await retry.say('confirm-new', 'ok nota ' + retry.token())
      expect(retry.store.openTasks()).toHaveLength(1)
      expect(retry.store.openTasks()[0]?.number).toBe(2)
    }
  )
  it('invalid prepared correction JSON leaves the original pending and suspended rather than superseding it', async () => {
    let invalid = false
    const e = await setup({
      organizer: {
        async organize() {
          return invalid ? '{invalid}' : RESPONSE
        }
      }
    })
    await e.say('initial', RAW)
    const old = e.store.notesV2()[0]!
    await e.say('confirm', 'ok nota ' + old.token)
    invalid = true
    await e.say('replacement', 'corrigir nota ' + old.token + ': ' + RAW)
    expect(e.store.noteV2(old.id)?.replacementPending).toBe(true)
    expect(e.store.tasksV2()[0]?.status).toBe('suspended')
    expect(e.store.inboxes().at(-1)?.error).toBe('schema_invalid')
    expect(e.store.notesV2()).toHaveLength(1)
  })
})
