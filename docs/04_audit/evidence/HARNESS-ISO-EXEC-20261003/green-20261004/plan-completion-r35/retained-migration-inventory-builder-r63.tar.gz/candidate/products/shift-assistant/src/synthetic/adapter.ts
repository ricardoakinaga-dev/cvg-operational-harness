import {
  ModelGatewayError,
  ModelInputSchema,
  OpenAICompatibleProvider,
  toGatewayError,
  type FetchLike,
  type OpenAICompatibleProviderOptions
} from '@cvg/model-gateway'
import type { OrganizedV2 } from '../domain.ts'
import { parseOrganizerResponse, type Organizer } from '../organizer.ts'
import {
  assertBinding,
  deny,
  loadSyntheticCorpus,
  sha256,
  type FixtureBinding
} from './corpus.ts'
import {
  authorizeSyntheticPacket,
  MAX_SYNTHETIC_CALLS,
  MAX_SYNTHETIC_OUTPUT_TOKENS,
  MAX_SYNTHETIC_REQUEST_BYTES,
  SYNTHETIC_BASE_URL,
  SyntheticModelSchema,
  SYNTHETIC_PROMPT,
  SYNTHETIC_PROMPT_SHA256,
  SYNTHETIC_TIMEOUT_MS,
  syntheticBundleSha256
} from './packet.ts'

type MockOptions = {
  mode: 'mock'
  model: string
  fixtureBindings: readonly FixtureBinding[]
  transport: FetchLike
  dnsLookup: NonNullable<OpenAICompatibleProviderOptions['dnsLookup']>
  /** Short timeouts for mocked timeout tests only. */
  timeoutMs?: number
  corpusDirectory?: string
}
type ExternalOptions = {
  mode: 'external'
  packetBytes: string
  humanExecutionReceipt: unknown
  /** Explicit in-memory credential supplied by an operator; never reads env. */
  apiKey: string
  corpusDirectory?: string
}
export type SyntheticRunOptions = MockOptions | ExternalOptions
export interface SyntheticCallEvidence {
  fixtureId: string
  inputSha256: string
  outputSha256?: string
  status: 'validated_v2' | 'source_blocked' | 'failed'
  code?: string
  httpStatus?: number
  inputTokens?: number
  outputTokens?: number
  qualification?: 'PASS' | 'FAILED'
  blockingCount?: number
  warningCount?: number
}

/**
 * Reviewed synthetic test exception. No gateway classification downgrade,
 * production organizer wiring, free-text entry point, action or persistence.
 * Creating a run is read-only; only an explicit organize invocation calls HTTP.
 */
export async function createSyntheticOpenAIRun(options: SyntheticRunOptions) {
  if (options.mode !== 'mock' && options.mode !== 'external')
    deny('Explicit synthetic mode required')
  const packet =
    options.mode === 'external'
      ? await authorizeSyntheticPacket(
          options.packetBytes,
          options.humanExecutionReceipt
        )
      : undefined
  if (
    options.mode === 'external' &&
    (typeof options.apiKey !== 'string' ||
      !options.apiKey.trim() ||
      /[\r\n]/.test(options.apiKey))
  )
    throw new ModelGatewayError(
      'provider_auth_failed',
      'Configured credential required'
    )
  if (
    options.mode === 'mock' &&
    (typeof options.transport !== 'function' ||
      typeof options.dnsLookup !== 'function')
  )
    deny('Mock transport and mock DNS required')
  const timeoutMs =
    options.mode === 'mock'
      ? (options.timeoutMs ?? SYNTHETIC_TIMEOUT_MS)
      : SYNTHETIC_TIMEOUT_MS
  if (
    !Number.isInteger(timeoutMs) ||
    timeoutMs < 1 ||
    timeoutMs > SYNTHETIC_TIMEOUT_MS
  )
    deny('Invalid synthetic timeout')
  const bindings = (
    packet?.fixtureBindings ?? (options as MockOptions).fixtureBindings
  ).map(assertBinding)
  if (
    bindings.length < 1 ||
    bindings.length > MAX_SYNTHETIC_CALLS ||
    new Set(bindings.map((b) => b.fixtureId)).size !== bindings.length
  )
    deny('Synthetic run requires 1..20 distinct fixed fixtures')
  const model = SyntheticModelSchema.parse(
    packet?.model ?? (options as MockOptions).model
  )
  const corpusDirectory = options.corpusDirectory
  const initialCorpus = await loadSyntheticCorpus(corpusDirectory)
  for (const binding of bindings) initialCorpus.get(binding)
  const selected = new Set(bindings.map((b) => b.fixtureId))
  const used = new Set<string>()
  const evidence: SyntheticCallEvidence[] = []
  // Snapshot authority and credential: later mutation of caller options cannot change them.
  const provider = new OpenAICompatibleProvider({
    id: 'shift-synthetic-openai-test',
    location: 'external',
    baseUrl: SYNTHETIC_BASE_URL,
    model,
    apiKey:
      options.mode === 'external' ? options.apiKey : 'synthetic-mock-only',
    requiresApiKey: true,
    ...(options.mode === 'mock'
      ? { fetchImpl: options.transport, dnsLookup: options.dnsLookup }
      : {})
  })

  function organizerFor(value: unknown): Organizer {
    const binding = Object.freeze(assertBinding(value))
    if (!selected.has(binding.fixtureId))
      deny('Fixture absent from this execution packet')
    return Object.freeze({
      async organize(
        text: string,
        now: Date,
        signal?: AbortSignal
      ): Promise<OrganizedV2> {
        if (signal?.aborted)
          throw new ModelGatewayError(
            'cancelled',
            'Synthetic organization cancelled'
          )
        const fixed = initialCorpus.get(binding)
        if (
          text !== fixed.rawText ||
          sha256(text) !== fixed.textSha256 ||
          !Number.isFinite(now.getTime()) ||
          now.getTime() !== Date.parse(fixed.clockInstant)
        )
          deny('Only bound fixture text and frozen instant are allowed')
        if (used.has(binding.fixtureId) || used.size >= MAX_SYNTHETIC_CALLS)
          deny('Synthetic call budget consumed; no retries')
        used.add(binding.fixtureId)
        const record: SyntheticCallEvidence = {
          fixtureId: binding.fixtureId,
          inputSha256: binding.textSha256,
          status: 'failed'
        }
        evidence.push(record)
        try {
          // Revalidate after factory creation; edited files cannot authorize a call.
          const current = (await loadSyntheticCorpus(corpusDirectory)).get(
            binding
          )
          if (current.rawText !== text) deny('Fixture changed before execution')
          if (packet && packet.bundleSha256 !== (await syntheticBundleSha256()))
            deny('Execution bundle changed before execution')
          const input = ModelInputSchema.parse({
            system: SYNTHETIC_PROMPT,
            messages: [
              {
                role: 'user',
                content: `Instante fixo: ${fixed.clockInstant}\n${fixed.rawText}`
              }
            ]
          })
          // Reserve 2 KiB for model and public provider wire fields. Transport
          // owns token parameter/effort compatibility; no body or fetch shim.
          if (
            Buffer.byteLength(JSON.stringify(input)) + 2048 >
            MAX_SYNTHETIC_REQUEST_BYTES
          )
            throw new ModelGatewayError(
              'invalid_request',
              'Synthetic request size limit exceeded'
            )
          if (signal?.aborted)
            throw new ModelGatewayError(
              'cancelled',
              'Synthetic organization cancelled'
            )
          const response = await provider.execute({
            requestId: `synthetic-${binding.fixtureId}`,
            correlationId: `synthetic-${binding.fixtureId}`,
            tenantId: 'tenant_00000000-0000-4000-8000-000000000000',
            model,
            input,
            temperature: 0,
            maxTokens: MAX_SYNTHETIC_OUTPUT_TOKENS,
            promptSha256: SYNTHETIC_PROMPT_SHA256,
            structuredSchemaName: 'OrganizedV2',
            signal: signal ?? new AbortController().signal,
            timeoutMs
          })
          record.outputSha256 = sha256(response.text)
          record.inputTokens = response.usage.inputTokens
          record.outputTokens = response.usage.outputTokens
          if (signal?.aborted)
            throw new ModelGatewayError(
              'cancelled',
              'Synthetic organization cancelled'
            )
          if (
            response.usage.outputTokens > MAX_SYNTHETIC_OUTPUT_TOKENS ||
            response.finishReason === 'length'
          )
            throw new ModelGatewayError(
              'schema_invalid',
              'Synthetic output token limit exceeded'
            )
          let organized: OrganizedV2
          try {
            organized = parseOrganizerResponse(response.text)
          } catch {
            throw new ModelGatewayError(
              'schema_invalid',
              'Synthetic response must match OrganizedV2'
            )
          }
          record.status = 'validated_v2'
          return organized
        } catch (error) {
          const mapped = toGatewayError(error)
          record.code = mapped.code
          if (mapped.status !== undefined) record.httpStatus = mapped.status
          // No retry, including 429/5xx: do not propagate the provider's retryable flag.
          throw new ModelGatewayError(
            mapped.code,
            'Synthetic organization failed',
            mapped.status === undefined ? {} : { status: mapped.status }
          )
        }
      }
    })
  }
  return Object.freeze({
    organizerFor,
    async organizeFixture(
      binding: unknown,
      signal?: AbortSignal
    ): Promise<OrganizedV2> {
      const fixed = initialCorpus.get(binding)
      return (await organizerFor(binding).organize(
        fixed.rawText,
        new Date(fixed.clockInstant),
        signal
      )) as OrganizedV2
    },
    evidence: () => evidence.map((e) => Object.freeze({ ...e }))
  })
}
