// @vitest-environment node
import * as fs from 'node:fs'
import { createServer, type Server } from 'node:http'
import { randomUUID } from 'node:crypto'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { spawn, type ChildProcess } from 'node:child_process'
import type { AddressInfo } from 'node:net'
import { fileURLToPath } from 'node:url'
import { afterEach, describe, expect, it } from 'vitest'
import {
  LocalSyntheticMonitor,
  type AlertPayload,
  type MonitorOptions
} from '../../scripts/monitor.mjs'
import { sha256 } from '../journal.ts'

const cleanup: (() => Promise<void> | void)[] = []
afterEach(async () => {
  for (const close of cleanup.splice(0).reverse()) await close()
})
async function bind(server: Server) {
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve))
  cleanup.push(async () => {
    server.closeAllConnections()
    await new Promise<void>((resolve) => server.close(() => resolve()))
  })
  return `http://127.0.0.1:${(server.address() as AddressInfo).port}`
}
async function fixture() {
  const root = fs.mkdtempSync(join(tmpdir(), 'shift-monitor-'))
  cleanup.push(() => fs.rmSync(root, { recursive: true, force: true }))
  let mode = 'healthy'
  let receiverMode = 'accepted'
  const received: {
    payload: AlertPayload
    hash: string
    receiptID: string
    receivedAt: string
  }[] = []
  let calls = 0
  const service = createServer((request, response) => {
    if (mode === 'hang') return
    const live = request.url === '/health/live'
    response.writeHead(
      live || ['healthy', 'paused'].includes(mode) ? 200 : 503,
      { 'content-type': 'application/json' }
    )
    response.end(
      JSON.stringify({
        mode: mode === 'paused' ? 'paused' : 'running',
        reasonCodes:
          mode === 'stale'
            ? ['scheduler_stale']
            : mode === 'private'
              ? ['Patient secret cannot escape']
              : mode === 'hold'
                ? ['operational_hold']
                : []
      })
    )
  })
  const serviceBase = await bind(service)
  const receiver = createServer((request, response) => {
    void (async () => {
      calls += 1
      let data = ''
      for await (const chunk of request) data += String(chunk)
      if (receiverMode === 'hang') return
      if (receiverMode === '503') {
        response.writeHead(503)
        response.end('{}')
        return
      }
      if (receiverMode === 'noReceipt') {
        response.end('{}')
        return
      }
      const receiptID = randomUUID()
      const record = {
        payload: JSON.parse(data) as AlertPayload,
        hash: sha256(data),
        receiptID,
        receivedAt: new Date().toISOString()
      }
      fs.writeFileSync(
        join(root, 'received-' + receiptID + '.json'),
        JSON.stringify(record),
        { flag: 'wx', mode: 0o600 }
      )
      received.push(record)
      response.end(JSON.stringify({ receiptID }))
    })()
  })
  const receiverBase = await bind(receiver)
  const options: MonitorOptions = {
    liveUrl: serviceBase + '/health/live',
    readyUrl: serviceBase + '/health/ready',
    receiverUrl: receiverBase + '/alerts',
    stateDirectory: join(root, 'monitor'),
    candidateDigest: 'a'.repeat(64),
    instanceOpaqueId: randomUUID(),
    timeoutMs: 50
  }
  return {
    root,
    options,
    received,
    get calls() {
      return calls
    },
    mode: (value: string) => {
      mode = value
    },
    receiverMode: (value: string) => {
      receiverMode = value
    }
  }
}
function own(options: MonitorOptions) {
  const monitor = new LocalSyntheticMonitor(options)
  cleanup.push(() => monitor.close())
  return monitor
}
function stopProcess(child: ChildProcess) {
  return new Promise<void>((resolve) => {
    if (child.exitCode !== null || child.signalCode !== null) return resolve()
    child.once('exit', () => resolve())
    child.kill('SIGTERM')
  })
}
describe('separate durable synthetic watchdog and received alert proofs', () => {
  it('requires two failures, records a real receiver receipt, and resolves only after two good probes with rate limiting', async () => {
    const f = await fixture(),
      monitor = own(f.options),
      start = Date.now()
    f.mode('stale')
    await monitor.tick(start)
    expect(f.received).toHaveLength(0)
    await monitor.tick(start + 10000)
    expect(f.received).toHaveLength(1)
    expect(f.received[0]!.payload.reasonCode).toBe('SCHEDULER_STALE')
    expect(monitor.snapshot().queue[0]!.receiptID).toBe(
      f.received[0]!.receiptID
    )
    expect(f.received[0]!.hash).toBe(
      sha256(JSON.stringify(monitor.snapshot().queue[0]!.payload))
    )
    f.mode('healthy')
    await monitor.tick(start + 20000)
    await monitor.tick(start + 30000)
    expect(f.received).toHaveLength(1)
    await monitor.tick(start + 70000)
    expect(f.received).toHaveLength(2)
    expect(f.received[1]!.payload.state).toBe('resolved')
    expect(f.received[1]!.payload.alertId).toBe(f.received[0]!.payload.alertId)
  })
  it('treats a healthy pause as an informational state, not an availability incident', async () => {
    const f = await fixture(),
      monitor = own(f.options),
      start = Date.now()
    f.mode('paused')
    await monitor.tick(start)
    await monitor.tick(start + 10000)
    expect(
      f.received.map((x) => [x.payload.reasonCode, x.payload.severity])
    ).toEqual([['STATE_PAUSED', 'info']])
  })
  it('sanitizes unrecognized health content to a fixed reason without copying private values', async () => {
    const f = await fixture(),
      monitor = own(f.options),
      start = Date.now()
    f.mode('private')
    await monitor.tick(start)
    await monitor.tick(start + 10000)
    expect(f.received[0]!.payload.reasonCode).toBe('READINESS_UNAVAILABLE')
    expect(JSON.stringify(monitor.snapshot())).not.toContain('Patient')
    expect(Object.keys(f.received[0]!.payload).sort()).toEqual([
      'alertId',
      'candidateDigest',
      'firstObservedAt',
      'instanceOpaqueId',
      'observedAt',
      'product',
      'reasonCode',
      'severity',
      'state'
    ])
  })
  it('retains retry counts across restart and marks failure after five attempts without pretending a receipt', async () => {
    const f = await fixture(),
      first = own(f.options),
      start = Date.now()
    f.mode('hold')
    f.receiverMode('503')
    await first.tick(start)
    await first.tick(start + 10000)
    expect(first.snapshot().queue[0]!.attempts).toBe(1)
    await first.close()
    const resumed = own(f.options)
    for (const elapsed of [40000, 160000, 760000, 2560000])
      await resumed.tick(start + elapsed)
    expect(f.calls).toBe(5)
    expect(resumed.snapshot().queue[0]).toMatchObject({
      attempts: 5,
      status: 'failed'
    })
    expect(resumed.snapshot().queue[0]!.receiptID).toBeUndefined()
    await resumed.tick(start + 10000000)
    expect(f.calls).toBe(5)
  })
  it('does not count an HTTP 200 without a valid receipt as received', async () => {
    const f = await fixture(),
      monitor = own(f.options),
      start = Date.now()
    f.mode('hold')
    f.receiverMode('noReceipt')
    await monitor.tick(start)
    await monitor.tick(start + 10000)
    expect(monitor.snapshot().queue[0]!.status).toBe('queued')
    expect(monitor.snapshot().queue[0]!.receiptID).toBeUndefined()
  })
  it('bounds hung probes and aborts a hung receiver on shutdown', async () => {
    const f = await fixture(),
      monitor = own(f.options),
      start = Date.now()
    f.mode('hang')
    await monitor.tick(start)
    await monitor.tick(start + 10000)
    expect(f.received[0]!.payload.reasonCode).toBe('PROBE_UNAVAILABLE')
    f.receiverMode('hang')
    f.mode('stale')
    await monitor.tick(start + 20000)
    const cycle = monitor.tick(start + 30000)
    await new Promise((resolve) => setTimeout(resolve, 10))
    const stopping = Date.now()
    await monitor.close()
    await cycle
    expect(Date.now() - stopping).toBeLessThan(500)
  })
  it('prevents overlapping cycles and second writers, preserving the lock', async () => {
    const f = await fixture(),
      monitor = own(f.options)
    f.mode('hang')
    const one = monitor.tick()
    expect(monitor.tick()).toBe(one)
    expect(() => new LocalSyntheticMonitor(f.options)).toThrow()
    expect(fs.existsSync(join(f.options.stateDirectory, 'monitor.lock'))).toBe(
      true
    )
    await one
    await monitor.close()
    expect(fs.existsSync(join(f.options.stateDirectory, 'monitor.lock'))).toBe(
      false
    )
  })
  it.each([
    'https://api.openai.com/alerts',
    'http://localhost/alerts',
    'http://127.0.0.1/alerts?secret=x',
    'http://x:y@127.0.0.1/alerts'
  ])(
    'refuses nonqualified endpoint %s before touching state',
    async (receiverUrl) => {
      const f = await fixture()
      expect(
        () => new LocalSyntheticMonitor({ ...f.options, receiverUrl })
      ).toThrow('LOCAL_SYNTHETIC_ENDPOINT_REQUIRED')
      expect(fs.existsSync(f.options.stateDirectory)).toBe(false)
    }
  )
  it('detects actual service process termination from a separate monitor process at the default 10 second interval', async () => {
    const f = await fixture()
    const serviceFile = join(f.root, 'service.mjs')
    fs.writeFileSync(
      serviceFile,
      "import {createServer} from 'node:http'; const s=createServer((q,r)=>r.end(JSON.stringify({mode:'running',reasonCodes:[]})));s.listen(0,'127.0.0.1',()=>console.log(s.address().port));process.once('SIGTERM',()=>s.close(()=>process.exit(0)));\n"
    )
    const service = spawn(process.execPath, [serviceFile], {
      stdio: ['ignore', 'pipe', 'pipe']
    })
    cleanup.push(() => stopProcess(service))
    const port = await new Promise<number>((resolve, reject) => {
      service.once('error', reject)
      service.stdout!.once('data', (data: Buffer) =>
        resolve(Number(data.toString().trim()))
      )
    })
    const config = join(f.root, 'monitor-config.json')
    fs.writeFileSync(
      config,
      JSON.stringify({
        ...f.options,
        timeoutMs: 2000,
        liveUrl: `http://127.0.0.1:${port}/health/live`,
        readyUrl: `http://127.0.0.1:${port}/health/ready`
      })
    )
    const entry = fileURLToPath(
      new URL('../../scripts/monitor.mjs', import.meta.url)
    )
    const monitor = spawn(process.execPath, [entry, config], {
      stdio: ['ignore', 'pipe', 'pipe']
    })
    cleanup.push(() => stopProcess(monitor))
    let error = ''
    monitor.stderr!.on('data', (data: Buffer) => {
      error += data.toString()
    })
    const readyDeadline = Date.now() + 5000
    while (
      !fs.existsSync(join(f.options.stateDirectory, 'state.json')) &&
      Date.now() < readyDeadline
    )
      await new Promise((resolve) => setTimeout(resolve, 20))
    expect(fs.existsSync(join(f.options.stateDirectory, 'state.json'))).toBe(
      true
    )
    await new Promise((resolve) => setTimeout(resolve, 100))
    const stoppedAt = Date.now()
    await stopProcess(service)
    while (!f.received.length && Date.now() - stoppedAt < 30000)
      await new Promise((resolve) => setTimeout(resolve, 50))
    expect(error).toBe('')
    expect(f.received[0]!.payload.reasonCode).toBe('PROBE_UNAVAILABLE')
    const latencyMs = Date.parse(f.received[0]!.receivedAt) - stoppedAt
    expect(latencyMs).toBeLessThanOrEqual(30000)
    const proof = {
      status: 'PASS',
      scope: 'SEPARATE_LOCAL_PROCESSES_ONLY',
      remoteHostFailureQualified: false,
      latencyMs,
      receiptID: f.received[0]!.receiptID,
      payloadSha256: f.received[0]!.hash,
      defaultPollIntervalMs: 10000,
      defaultTimeoutMs: 2000
    }
    console.log('MONITOR_PROCESS_STOP_RECEIPT ' + JSON.stringify(proof))
  }, 40000)
})
