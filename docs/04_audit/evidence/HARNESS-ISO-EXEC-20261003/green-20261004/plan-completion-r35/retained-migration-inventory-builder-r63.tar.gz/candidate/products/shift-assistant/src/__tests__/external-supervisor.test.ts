// @vitest-environment node
import * as fs from 'node:fs'
import { spawn, type ChildProcess } from 'node:child_process'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { afterEach, expect, it } from 'vitest'
import { stopChildWithin } from '../../scripts/supervise-process.mjs'
import { backupStoppedVolume } from '../../scripts/backup-restore.mjs'
import { ShiftStore } from '../store.ts'
import { sha256 } from '../journal.ts'

const cleanup: (() => Promise<void> | void)[] = []
afterEach(async () => {
  for (const close of cleanup.splice(0).reverse()) await close()
})
function own(program: string, args: string[] = []) {
  const child = spawn(
    process.execPath,
    [
      '--import',
      join(process.cwd(), 'node_modules/tsx/dist/loader.mjs'),
      '--input-type=module',
      '-e',
      program,
      ...args
    ],
    { stdio: ['ignore', 'pipe', 'pipe'] }
  )
  cleanup.push(async () => {
    if (child.exitCode === null && child.signalCode === null) {
      const exit = new Promise((resolve) => child.once('exit', resolve))
      child.kill('SIGKILL')
      await exit
    }
  })
  return child
}
async function waitForOutput(child: ChildProcess, marker: string) {
  await new Promise<void>((resolve, reject) => {
    const timer = setTimeout(() => {
      close()
      reject(new Error('CHILD_FIXTURE_NOT_READY'))
    }, 5000)
    let text = ''
    const data = (chunk: Buffer) => {
      text += chunk.toString()
      if (text.includes(marker)) {
        close()
        resolve()
      }
    }
    const error = () => {
      close()
      reject(new Error('CHILD_FIXTURE_FAILED'))
    }
    const close = () => {
      clearTimeout(timer)
      child.stdout!.removeListener('data', data)
      child.removeListener('exit', error)
    }
    child.stdout!.on('data', data)
    child.once('exit', error)
  })
}
it('external supervisor contains a child blocked in synchronous journal IO within 15s and preserves residual lock/original bytes', async () => {
  const root = fs.mkdtempSync(join(tmpdir(), 'shift-supervisor-'))
  cleanup.push(() => fs.rmSync(root, { recursive: true, force: true }))
  const directory = join(root, 'source')
  const source = fileURLToPath(new URL('../store.ts', import.meta.url))
  const program = `
import * as fs from 'node:fs';import {ShiftStore} from ${JSON.stringify(source)};
let blocking=false;const store=new ShiftStore(process.argv[1],{io:{sync(fd){if(blocking){process.stdout.write('BLOCKED_SYNC\\n');Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0)}fs.fsyncSync(fd)}}});
store.append({type:'paused',at:'2026-10-03T12:00:00Z',by:'5511900000009'});
process.on('SIGTERM',()=>{store.close();process.exit(0)});
blocking=true;store.append({type:'resumed',at:'2026-10-03T12:01:00Z',by:'5511900000009'});
`
  const child = own(program, [directory])
  await waitForOutput(child, 'BLOCKED_SYNC')
  const lock = fs.readFileSync(join(directory, 'store.lock'))
  const manifest = JSON.parse(
    fs.readFileSync(join(directory, 'journal/manifest.json'), 'utf8')
  )
  const active = join(directory, manifest.segments.at(-1).path)
  const original = fs.readFileSync(active)
  expect(original.toString().endsWith('\n')).toBe(true)
  const receipt = await stopChildWithin(child)
  expect(receipt.status).toBe('contained_forced')
  expect(receipt.graceful).toBe(false)
  expect(receipt.signal).toBe('SIGKILL')
  expect(receipt.elapsedMs).toBeLessThanOrEqual(15000)
  expect(fs.readFileSync(join(directory, 'store.lock'))).toEqual(lock)
  expect(fs.readFileSync(active)).toEqual(original)
  expect(() => new ShiftStore(directory)).toThrow('STORE_LOCKED')
  expect(() =>
    backupStoppedVolume(directory, join(root, 'blocked-backup'))
  ).toThrow()
  const copy = join(root, 'reconciled-copy')
  fs.cpSync(directory, copy, { recursive: true })
  // This controlled offline reconciliation moves only the verified copied lock;
  // the original crashed volume and residual lock remain untouched.
  fs.renameSync(
    join(copy, 'store.lock'),
    join(copy, 'retained-residual-lock.json')
  )
  fs.writeFileSync(
    join(copy, 'restore-hold.json'),
    '{"version":1,"syntheticReconciliation":true}'
  )
  const reopened = new ShiftStore(copy)
  try {
    expect(reopened.storageAvailable).toBe(true)
    expect(reopened.sequence).toBe(2)
    expect(reopened.operationalHold).toBe(true)
    expect(reopened.effectsAllowed).toBe(false)
  } finally {
    reopened.close()
  }
  expect(fs.readFileSync(active)).toEqual(original)
  console.log(
    'EXTERNAL_SYNC_CONTAINMENT_RECEIPT ' +
      JSON.stringify({
        ...receipt,
        scope: 'INJECTED_SYNCHRONOUS_IO_BLOCK_IN_REAL_NODE_CHILD',
        physicalKernelOrPowerFailureQualified: false,
        originalJournalSha256: sha256(original),
        residualLockPreserved: true,
        effectsAfterReopen: false
      })
  )
}, 20000)

it('normal shutdown is graceful and removes listeners/timers without forced termination', async () => {
  const child = own(
    "process.on('SIGTERM',()=>process.exit(0));console.log('READY');setInterval(()=>{},1000)"
  )
  await waitForOutput(child, 'READY')
  const receipt = await stopChildWithin(child)
  expect(receipt.status).toBe('exited')
  expect(receipt.graceful).toBe(true)
  expect(child.listenerCount('exit')).toBe(0)
  expect(child.listenerCount('error')).toBe(0)
})

it('rejects stop configurations that remove the approved upper bound before signalling', async () => {
  const child = own(
    "process.on('SIGTERM',()=>process.exit(0));console.log('READY');setInterval(()=>{},1000)"
  )
  await waitForOutput(child, 'READY')
  await expect(
    stopChildWithin(child, { graceMs: 20000, totalMs: 30000 })
  ).rejects.toThrow('INVALID_EXTERNAL_STOP_BUDGET')
  expect(child.killed).toBe(false)
  await stopChildWithin(child)
})
