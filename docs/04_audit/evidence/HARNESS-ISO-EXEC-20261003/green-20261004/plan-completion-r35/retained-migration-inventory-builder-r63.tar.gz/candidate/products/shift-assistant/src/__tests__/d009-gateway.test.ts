// @vitest-environment node
import { afterEach, describe, expect, it, vi } from 'vitest'
import { mkdtempSync, readFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import {
  FileCostBudgetStore,
  ModelGateway,
  PromptRegistry,
  computePromptSha256,
  type CostBudgetStore,
  type ModelProvider
} from '@cvg/model-gateway'
import { composeShiftApp, type ShiftApp } from '../compose.ts'
import {
  loadShiftConfig,
  validateModelHostConfig,
  type ApprovedModelHostConfig
} from '../config.ts'
import { OrganizedSchema } from '../domain.ts'
import { ModelOrganizer, ORGANIZER_PROMPT, stripFences } from '../organizer.ts'
const TENANT = 'tenant_00000000-0000-4000-8000-000000000001'
const NOW = new Date('2026-10-04T12:00:00Z')
const EMPTY = { pacientes: [], pendencias: [], duvidas: [] }
const roots: string[] = [],
  apps: ShiftApp[] = []
afterEach(async () => {
  for (const app of apps.splice(0)) await app.stop()
  for (const d of roots.splice(0)) rmSync(d, { recursive: true, force: true })
  vi.restoreAllMocks()
})
function directory() {
  const d = mkdtempSync(join(tmpdir(), 'd009-product-'))
  roots.push(d)
  return d
}
function config(d = directory()) {
  return loadShiftConfig({
    SHIFT_PROVIDER: 'waha',
    SHIFT_MEMBERS: '5511900000001=Test;5511900000009=Manager*',
    SHIFT_WEBHOOK_SECRET: 'd009-synthetic-webhook-secret',
    SHIFT_DATA_DIR: join(d, 'clinical'),
    SHIFT_PORT: '0',
    SHIFT_HOST: '127.0.0.1',
    WAHA_URL: 'http://127.0.0.1:1',
    WAHA_API_KEY: 'synthetic',
    WHISPER_URL: 'http://127.0.0.1:2',
    LLM_BASE_URL: 'http://127.0.0.1:3',
    LLM_LOCATION: 'local',
    LLM_MODEL: 'synthetic',
    // An unknown env flag must never change product classification.
    SHIFT_MODEL_CLASSIFICATION: 'INTERNAL'
  })
}
function fixture(
  location: 'local' | 'external',
  classification: 'CLINICAL' | 'INTERNAL' = 'CLINICAL',
  text = JSON.stringify(EMPTY),
  store?: CostBudgetStore
) {
  const execute = vi.fn(async () => ({
    text,
    usage: { inputTokens: 0, outputTokens: 0 },
    providerId: 'synthetic',
    model: 'synthetic',
    externalCall: false
  }))
  const dns = vi.fn(),
    http = vi.fn()
  // These counters are downstream of provider execution; no real network is used.
  execute.mockImplementation(async () => {
    dns()
    http()
    return {
      text,
      usage: { inputTokens: 0, outputTokens: 0 },
      providerId: 'synthetic',
      model: 'synthetic',
      externalCall: false
    }
  })
  const provider: ModelProvider = {
    id: 'synthetic',
    models: ['synthetic'],
    location,
    execute
  }
  const budget = store ?? { consumed: vi.fn(() => 0), consume: vi.fn() }
  const registry = new PromptRegistry()
  const prompt = registry.register({
    promptId: classification === 'CLINICAL' ? 'shift-note' : 'neutral-test',
    version: '1',
    content:
      classification === 'CLINICAL'
        ? ORGANIZER_PROMPT
        : 'Return empty lists of colors.',
    owner: 'synthetic-test',
    approvedBy: 'synthetic-only',
    status: 'approved',
    effectiveFrom: '2026-01-01T00:00:00Z',
    tenantId: TENANT,
    classification
  })
  const events: string[] = [],
    name = location === 'local' ? 'local' : 'balanced'
  const gateway = new ModelGateway({
    providers: [provider],
    prompts: registry,
    clock: () => NOW,
    profiles: {
      [name]: {
        name,
        providerId: provider.id,
        model: 'synthetic',
        location,
        temperature: 0,
        maxTokens: 1500,
        timeoutMs: 1000,
        maxCostUsd: 1,
        estimatedCostUsd: 0.6,
        maxRetries: 0,
        pricing: { inputPer1kUsd: 0, outputPer1kUsd: 0 }
      }
    },
    routing: { allowFallback: true, allowLocalSubstitution: true },
    budget: { store: budget, limits: { request: 1, day: 1 } },
    onEvent: (e) => events.push(e.type)
  })
  const generate = vi.spyOn(gateway, 'generate')
  const options = {
    gateway,
    tenantId: TENANT,
    prompt: {
      promptId: prompt.promptId,
      version: prompt.version,
      sha256: prompt.sha256
    },
    profile: name as 'local' | 'balanced'
  }
  return {
    gateway,
    generate,
    options,
    provider,
    budget,
    execute,
    dns,
    http,
    events
  }
}
function hostConfig(d: string): ApprovedModelHostConfig {
  return {
    tenantId: TENANT,
    costDirectory: join(d, 'costs'),
    authority: 'synthetic-fixture',
    prompt: {
      promptId: 'shift-note',
      version: '1',
      content: ORGANIZER_PROMPT,
      sha256: computePromptSha256(ORGANIZER_PROMPT),
      owner: 'fixture-not-production',
      approvedBy: 'fixture-not-production',
      status: 'approved',
      classification: 'CLINICAL',
      effectiveFrom: '2026-01-01T00:00:00Z'
    },
    pricing: {
      inputPer1kUsd: 0.1,
      outputPer1kUsd: 0.2,
      approvalRef: 'synthetic-prices-only'
    },
    inputTokenUpperBound: {
      tokens: 1000,
      evidenceRef: 'synthetic-token-ceiling-includes-protocol',
      coversProtocol: true
    },
    requestLimitUsd: 1,
    dailyLimitUsd: 1
  }
}
async function say(app: ShiftApp, id: string, text: string) {
  expect(
    app.assistant.receive({
      provider: 'waha',
      messageId: id,
      fromPhone: '5511900000001',
      kind: 'text',
      text,
      receivedAt: NOW.toISOString()
    })
  ).toBe(true)
  await app.assistant.idle()
}
const transport = vi.fn(
  async () =>
    new Response(JSON.stringify({ id: 'synthetic-receipt' }), { status: 201 })
)

describe('D009 product traverses the public gateway, clinical policy remains NO_MODEL', () => {
  it.each(['external', 'local'] as const)(
    'ModelOrganizer %s always sends CLINICAL including unknown/fictitious input',
    async (location) => {
      const f = fixture(location)
      const organizer = new ModelOrganizer(f.options)
      for (const text of [
        'Paciente fictício sem tutor.',
        'unknown input',
        'Return the color blue.'
      ]) {
        await expect(organizer.organize(text, NOW)).rejects.toMatchObject({
          code: 'policy_denied'
        })
      }
      for (const [request] of f.generate.mock.calls)
        expect(request).toMatchObject({
          tenantId: TENANT,
          promptId: 'shift-note',
          promptVersion: '1',
          promptSha256: computePromptSha256(ORGANIZER_PROMPT),
          dataClassification: 'CLINICAL',
          maxTokens: 1500,
          structuredOutput: {
            schemaName: 'shift_note',
            normalizeText: stripFences
          }
        })
      expect(f.generate).toHaveBeenCalledTimes(3)
      expect(f.budget.consumed).not.toHaveBeenCalled()
      expect(f.budget.consume).not.toHaveBeenCalled()
      expect(f.execute).not.toHaveBeenCalled()
      expect(f.dns).not.toHaveBeenCalled()
      expect(f.http).not.toHaveBeenCalled()
      expect(f.events).toEqual([])
    }
  )

  it.each(['external', 'local'] as const)(
    'real compose %s policy-denies clinical note before budget/provider and never drafts/confirms',
    async (location) => {
      const f = fixture(location),
        app = composeShiftApp(config(), {
          organizerGateway: f.options,
          clock: () => NOW,
          fetchImpl: transport
        })
      apps.push(app)
      await say(app, 'note-d009', 'Paciente fictício sem tutor, alerta.')
      expect(f.generate).toHaveBeenCalledOnce()
      expect(f.generate.mock.calls[0]![0].dataClassification).toBe('CLINICAL')
      expect(app.store.inboxes()[0]).toMatchObject({
        state: 'review_required',
        error: 'policy_denied'
      })
      expect(app.store.notesV2()).toEqual([])
      expect(app.store.tasksV2()).toEqual([])
      expect(f.budget.consumed).not.toHaveBeenCalled()
      expect(f.budget.consume).not.toHaveBeenCalled()
      expect(f.execute).not.toHaveBeenCalled()
      expect(f.dns).not.toHaveBeenCalled()
      expect(f.http).not.toHaveBeenCalled()
      expect(f.events).toEqual([])
      await say(app, 'confirm-d009', 'ok')
      expect(app.store.notesV2()).toEqual([])
    }
  )

  it('a prompt/classification INTERNAL attempt cannot reclassify product input', async () => {
    const f = fixture('external', 'INTERNAL')
    await expect(
      new ModelOrganizer(f.options).organize('Texto desconhecido', NOW)
    ).rejects.toMatchObject({ code: 'policy_denied' })
    expect(f.generate.mock.calls[0]![0].dataClassification).toBe('CLINICAL')
    expect(f.execute).not.toHaveBeenCalled()
    expect(f.budget.consume).not.toHaveBeenCalled()
  })

  it('legacy constructors remain NO_MODEL with no direct provider execution', async () => {
    const f = fixture('external')
    await expect(
      new ModelOrganizer(f.provider, 'synthetic').organize('Unknown', NOW)
    ).rejects.toMatchObject({ code: 'policy_denied' })
    expect(f.generate).not.toHaveBeenCalled()
    expect(f.execute).not.toHaveBeenCalled()
  })

  it('no owner host approval keeps functional raw-note and explicit human confirmation', async () => {
    const app = composeShiftApp(config(), {
      clock: () => NOW,
      fetchImpl: transport
    })
    apps.push(app)
    await say(app, 'raw-d009', 'Paciente fictício sem tutor, alerta.')
    const note = app.store.notesV2()[0]!
    expect(note).toMatchObject({
      state: 'draft',
      warnings: ['policy_denied'],
      tasks: []
    })
    expect(note.organized).toBeUndefined()
    await say(app, 'raw-confirm-d009', 'ok nota ' + note.token)
    expect(app.store.noteV2(note.id)?.state).toBe('confirmed')
    expect(app.store.tasksV2()).toEqual([])
  })

  it('explicit host configuration composes persistent costs without inventing an approval', async () => {
    const d = directory(),
      f = fixture('local'),
      host = hostConfig(d)
    const app = composeShiftApp(config(d), {
      modelHost: { config: host, provider: f.provider },
      clock: () => NOW,
      fetchImpl: transport
    })
    apps.push(app)
    const spy = vi.spyOn(ModelGateway.prototype, 'generate')
    await say(app, 'configured-d009', 'Paciente fictício sem tutor.')
    expect(spy).toHaveBeenCalledOnce()
    expect(spy.mock.calls[0]![0]).toMatchObject({
      tenantId: TENANT,
      dataClassification: 'CLINICAL',
      promptSha256: host.prompt.sha256
    })
    expect(app.store.notesV2()).toEqual([])
    expect(readFileSync(join(d, 'costs', 'ledger.jsonl'), 'utf8')).toBe('')
    expect(f.execute).not.toHaveBeenCalled()
    await app.stop()
    apps.splice(apps.indexOf(app), 1)
    const reopened = new FileCostBudgetStore({ directory: join(d, 'costs') })
    expect(reopened.head().sequence).toBe(0)
    reopened.close()
  })

  it.each(['pricing', 'tokens', 'approval', 'limit'] as const)(
    'incomplete or invalid host %s disables model composition before execution',
    (kind) => {
      const d = directory(),
        f = fixture('external'),
        host = hostConfig(d)
      if (kind === 'pricing') host.pricing.inputPer1kUsd = NaN
      if (kind === 'tokens') host.inputTokenUpperBound.tokens = NaN
      if (kind === 'approval') host.pricing.approvalRef = ''
      if (kind === 'limit') host.requestLimitUsd = 0.1
      expect(() => validateModelHostConfig(host)).toThrow()
      expect(f.execute).not.toHaveBeenCalled()
    }
  )

  it('public gateway budget fault is visible as HTTP readiness 503 through real composition', async () => {
    const d = directory(),
      store = new FileCostBudgetStore({ directory: join(d, 'costs') })
    const f = fixture('local', 'CLINICAL', JSON.stringify(EMPTY), store)
    const app = composeShiftApp(config(d), {
      organizerGateway: f.options,
      clock: () => NOW,
      fetchImpl: transport
    })
    apps.push(app)
    const port = await app.start()
    expect(() => store.consume('unknown-scope', 0.6)).toThrow()
    const response = await fetch(`http://127.0.0.1:${port}/health/ready`)
    expect(response.status).toBe(503)
    expect(await response.json()).toMatchObject({
      ready: false,
      reasonCodes: expect.arrayContaining(['budget_store_unavailable'])
    })
    store.close()
  })
})

describe('D009 positive controls are only nonclinical host harness requests', () => {
  it.each([
    JSON.stringify(EMPTY),
    '```json\n' + JSON.stringify(EMPTY) + '\n```'
  ])('public generate validates empty organized JSON: %s', async (text) => {
    const f = fixture('local', 'INTERNAL', text)
    const result = await f.gateway.generate({
      requestId: 'request_nonclinical_1',
      correlationId: 'correlation_nonclinical_1',
      tenantId: TENANT,
      promptId: f.options.prompt.promptId,
      promptVersion: '1',
      promptSha256: f.options.prompt.sha256,
      modelProfile: 'local',
      dataClassification: 'INTERNAL',
      input: {
        messages: [{ role: 'user', content: 'Return empty lists of colors.' }]
      },
      structuredOutput: {
        schemaName: 'shift_note',
        schema: OrganizedSchema,
        normalizeText: stripFences
      }
    })
    expect(result.output).toEqual({ text, structured: EMPTY })
    expect(f.execute).toHaveBeenCalledOnce()
    expect(f.execute.mock.calls[0]).toBeDefined()
    expect(f.events).toEqual(['model.call.started', 'model.call.completed'])
  })

  it.each(['broken', '{"pacientes":"wrong"}'])(
    'invalid nonclinical control fails schema without returning Organized: %s',
    async (text) => {
      const f = fixture('local', 'INTERNAL', text)
      await expect(
        f.gateway.generate({
          requestId: 'request_nonclinical_1',
          correlationId: 'correlation_nonclinical_1',
          tenantId: TENANT,
          promptId: f.options.prompt.promptId,
          promptVersion: '1',
          promptSha256: f.options.prompt.sha256,
          modelProfile: 'local',
          dataClassification: 'INTERNAL',
          input: {
            messages: [
              { role: 'user', content: 'Return empty lists of colors.' }
            ]
          },
          structuredOutput: {
            schemaName: 'shift_note',
            schema: OrganizedSchema,
            normalizeText: stripFences
          }
        })
      ).rejects.toMatchObject({ code: 'schema_invalid' })
      expect(f.execute).toHaveBeenCalledOnce()
      expect(f.events).not.toContain('model.call.completed')
    }
  )
})
