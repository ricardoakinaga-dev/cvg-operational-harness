// @vitest-environment node
import { describe, expect, it } from 'vitest'
import type { NoteV2, OrganizedV2 } from '../domain.ts'
import { canonical, sha256 } from '../journal.ts'
import { parseOrganizerResponse } from '../organizer.ts'
import { buildSourceBlocks, validateOrganization } from '../source-evidence.ts'
import { revisionToken } from '../vertical-state.ts'
import { RAW, RESPONSE } from './vertical-test-fixture.ts'

const at = '2026-10-03T18:00:00Z'
function confirmedHistory(): NoteV2 {
  const validation = validateOrganization(RAW, RESPONSE, [], at)
  const note: NoteV2 = {
    id: 'confirmed-history',
    messageKey: 'history-key',
    authorPhone: '5511900000001',
    revision: 1,
    createdAt: at,
    rawText: RAW,
    rawTextSha256: sha256(RAW),
    organized: RESPONSE,
    organizedSha256: sha256(canonical(RESPONSE)),
    token: '',
    state: 'confirmed',
    replacementPending: false,
    ...validation,
    warnings: [],
    tasks: [],
    previewIds: ['history-preview']
  }
  note.bindings = note.bindings.map((b) => ({
    ...b,
    confirmedBy: note.authorPhone,
    confirmedAt: at
  }))
  note.token = revisionToken(note)
  return note
}

const fields = ['id', 'leito', 'nome'] as const
const relations = ['absent', 'coincident', 'divergent'] as const
const outputs = ['omitted', 'null', 'coincident', 'divergent'] as const
const rows = fields.flatMap((field) =>
  relations.flatMap((source) =>
    outputs.map((output) => ({ field, source, output }))
  )
)
describe('R2-P5 finite property matrix: source-owned identity cannot borrow memory', () => {
  it.each(['ID', 'id', 'ficha', 'prontuário'])(
    'conflicting literal %s identifiers cannot fall back to memory when no unique block ID exists',
    (label) => {
      const raw = `Paciente Rex, registro ${label} 99999, registro ${label} 88888, leito 4. Evolução: alerta.`
      const response = structuredClone(RESPONSE)
      response.pacientes[0]!.id = null
      response.pendencias = []
      response.evidence = response.evidence.filter(
        (e) => !e.path.startsWith('pendencias.') && e.path !== 'pacientes.p1.id'
      )
      response.evidence[0]!.quote = raw.split('. ')[0]!
      expect(buildSourceBlocks(raw, response)).toEqual([])
      const result = validateOrganization(
        raw,
        response,
        [confirmedHistory()],
        at
      )
      expect(result.issues.some((i) => i.path === 'pacientes.p1.id')).toBe(true)
      expect(result.bindings[0]?.provenance).toBe('unresolved')
      expect(result.bindings[0]?.idLiteral).toBeUndefined()
    }
  )
  it.each(
    ['ID', 'id', 'ficha', 'prontuário'].flatMap((label) =>
      ['99999', '20202', 'cento e um', '00101'].map((literal) => ({
        label,
        literal
      }))
    )
  )(
    'literal source block $label $literal bars memory even outside the labelled field grammar',
    ({ label, literal }) => {
      const raw = `Paciente Rex, registro ${label} ${literal}, leito 4. Evolução: alerta.`
      const response = structuredClone(RESPONSE)
      response.pacientes[0]!.id = null
      response.pendencias = []
      response.evidence = [
        {
          path: 'pacientes.p1.nome',
          patientRef: 'p1',
          quote: raw.split('. ')[0]!
        },
        { path: 'pacientes.p1.leito', patientRef: 'p1', quote: 'leito 4' },
        {
          path: 'pacientes.p1.evolucao',
          patientRef: 'p1',
          quote: 'Evolução: alerta'
        }
      ]
      expect(buildSourceBlocks(raw, response)[0]?.idLiteral).toBe(literal)
      const result = validateOrganization(
        raw,
        response,
        [confirmedHistory()],
        at
      )
      expect(result.issues).toContainEqual(
        expect.objectContaining({
          code: 'UNSOURCED_ID',
          path: 'pacientes.p1.id',
          severity: 'blocking'
        })
      )
      expect(result.bindings[0]).toMatchObject({ provenance: 'unresolved' })
      expect(result.bindings[0]?.idLiteral).toBeUndefined()
      expect(result.bindings[0]?.normalizedId).toBeUndefined()
    }
  )
  it.each(rows)(
    '$field / source $source / output $output',
    ({ field, source, output }) => {
      const history = confirmedHistory()
      const sourceValues = { id: '20202', leito: '4', nome: 'Rex' }
      const otherValues = { id: '99999', leito: '7', nome: 'Lua' }
      const values: Record<string, string | undefined> = { ...sourceValues }
      // For the bed/name properties, leave the ID genuinely absent, so the
      // confirmed-history branch is exercised rather than masked by explicit ID.
      if (field !== 'id') delete values.id
      values[field] =
        source === 'absent'
          ? undefined
          : source === 'coincident'
            ? sourceValues[field]
            : otherValues[field]
      const raw =
        (values.nome ? 'Paciente ' + values.nome : 'Paciente sem nome') +
        (values.id ? ', ID ' + values.id : '') +
        (values.leito ? ', leito ' + values.leito : '') +
        '. Evolução: alerta.'
      const response: OrganizedV2 = structuredClone(RESPONSE)
      response.pendencias = []
      const p = response.pacientes[0]!
      p.id = values.id
      p.leito = values.leito
      p.nome = values.nome ?? 'Rex'
      if (output === 'omitted') Reflect.deleteProperty(p, field)
      else if (output === 'null') Object.assign(p, { [field]: null })
      else
        Object.assign(p, {
          [field]:
            output === 'coincident'
              ? (values[field] ?? sourceValues[field])
              : otherValues[field] === values[field]
                ? sourceValues[field]
                : otherValues[field]
        })
      const anchor = raw.split('. ')[0]!
      response.evidence = [
        { path: 'pacientes.p1.nome', patientRef: 'p1', quote: anchor },
        {
          path: 'pacientes.p1.evolucao',
          patientRef: 'p1',
          quote: 'Evolução: alerta'
        }
      ]
      for (const f of ['id', 'leito'] as const)
        if (p[f])
          response.evidence.push({
            path: 'pacientes.p1.' + f,
            patientRef: 'p1',
            quote: (f === 'id' ? 'ID ' : 'leito ') + p[f]
          })
      if (field === 'nome' && ['omitted', 'null'].includes(output)) {
        // Name is required by the strict V2 schema, so omission never reaches memory.
        expect(() => parseOrganizerResponse(response)).toThrow()
        return
      }
      const result = validateOrganization(
        raw,
        parseOrganizerResponse(response),
        [history],
        at
      )
      const matching = output === 'coincident' && source !== 'absent'
      const safeAbsent =
        source === 'absent' &&
        field !== 'nome' &&
        ['omitted', 'null'].includes(output)
      const expectedValid =
        field === 'id'
          ? matching || safeAbsent
          : field === 'leito'
            ? safeAbsent || (matching && source === 'coincident')
            : matching && source === 'coincident'
      if (expectedValid) {
        expect(result.issues).toEqual([])
        expect(result.bindings[0]?.idLiteral).toBe(
          field === 'id' && matching ? values.id : '20202'
        )
        expect(result.bindings[0]?.provenance).toBe(
          field === 'id' && matching
            ? 'source_explicit'
            : 'confirmed_history_candidate'
        )
      } else {
        expect(result.issues.some((i) => i.severity === 'blocking')).toBe(true)
        expect(
          result.bindings.every(
            (b) =>
              b.provenance === 'unresolved' && !b.idLiteral && !b.normalizedId
          )
        ).toBe(true)
      }
    }
  )
})
