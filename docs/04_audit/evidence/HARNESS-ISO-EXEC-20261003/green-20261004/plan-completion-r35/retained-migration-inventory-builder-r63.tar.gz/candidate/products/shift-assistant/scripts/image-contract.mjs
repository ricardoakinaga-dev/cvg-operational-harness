import { execFileSync } from 'node:child_process'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { randomUUID, createHash } from 'node:crypto'
import assert from 'node:assert/strict'

// Run only against an explicitly named local candidate image. No .env, API
// credential, clinical data or host network is passed into the probe container.
const image = process.argv[2]
const output = process.argv[3]
if (!image || image.startsWith('-') || !output)
  throw new Error('Usage: image-contract.mjs <local-image> <report.json>')
const docker = (args) =>
  execFileSync('docker', args, { encoding: 'utf8' }).trim()
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cvg-image-contract-'))
const name = 'cvg-green-image-proof-' + randomUUID().slice(0, 8)
let created = false
try {
  const inspection = JSON.parse(docker(['image', 'inspect', image]))[0]
  assert.equal(inspection.Config.User, '10001:10001')
  assert(
    !inspection.Config.Env.some((s) =>
      /^(OPENAI_API_KEY|SHIFT_WEBHOOK_SECRET|WAHA_API_KEY|EVOLUTION_API_KEY)=/.test(
        s
      )
    )
  )
  docker([
    'create',
    '--name',
    name,
    '--label',
    'cvg.owner=HARNESS_ISO_GREEN_20261004',
    '--read-only',
    '--tmpfs',
    '/tmp',
    '--cap-drop',
    'ALL',
    '--security-opt',
    'no-new-privileges:true',
    '--network',
    'none',
    image,
    '/usr/local/bin/node',
    '-e',
    'setInterval(()=>{},1000)'
  ])
  created = true
  docker(['export', '--output', path.join(dir, 'rootfs.tar'), name])
  const files = execFileSync('tar', ['-tf', path.join(dir, 'rootfs.tar')], {
    encoding: 'utf8'
  })
    .split('\n')
    .filter(Boolean)
  const forbidden = files.filter(
    (file) =>
      /(^|\/)(sh|bash|dash|busybox|npm|npx|apt|apt-get|dpkg|apk|yum|dnf|sudo|su)$/.test(
        file
      ) || /(^|\/)\.env(?:\.|$)/.test(file)
  )
  assert.deepEqual(forbidden, [])
  assert(files.includes('usr/local/bin/node'))
  assert(files.includes('app/shift-assistant.mjs'))
  assert(files.includes('etc/ssl/certs/ca-certificates.crt'))
  docker(['start', name])
  const probe = JSON.parse(
    docker([
      'exec',
      name,
      '/usr/local/bin/node',
      '-e',
      `
    const fs=require('node:fs'), cp=require('node:child_process');
    const missing={}; for(const executable of ['/bin/sh','/bin/bash','/usr/bin/bash','/bin/busybox','/usr/bin/npm','/usr/local/bin/npm','/usr/local/bin/npx']) {
      try{cp.execFileSync(executable,['--version']);missing[executable]=false}catch(e){missing[executable]=e.code==='ENOENT'}
    }
    let rootWriteDenied=false;try{fs.writeFileSync('/app/forbidden','x')}catch(e){rootWriteDenied=['EROFS','EACCES'].includes(e.code)}
    fs.writeFileSync('/data/synthetic-proof','synthetic-only');
    console.log(JSON.stringify({uid:process.getuid(),gid:process.getgid(),node:process.version,rootWriteDenied,dataWritable:fs.readFileSync('/data/synthetic-proof','utf8')==='synthetic-only',missing}));
  `
    ])
  )
  assert.equal(probe.uid, 10001)
  assert.equal(probe.gid, 10001)
  assert.equal(probe.node.startsWith('v22.'), true)
  assert.equal(probe.rootWriteDenied, true)
  assert.equal(probe.dataWritable, true)
  assert(Object.values(probe.missing).every(Boolean))
  const runtime = JSON.parse(docker(['inspect', name]))[0]
  assert.equal(runtime.HostConfig.ReadonlyRootfs, true)
  assert(runtime.HostConfig.CapDrop.includes('ALL'))
  assert.equal(runtime.HostConfig.NetworkMode, 'none')
  const report = {
    status: 'PASS',
    imageId: inspection.Id,
    repoDigests: inspection.RepoDigests,
    rootfsInventorySha256: createHash('sha256')
      .update(files.join('\n'))
      .digest('hex'),
    fileCount: files.length,
    probe,
    readOnly: true,
    capDropAll: true,
    network: 'none',
    infrastructureEgressQualified: false,
    scope:
      'Local scratch-image filesystem and process hardening only. Network none proves isolation for the probe, not an operational allowlist.'
  }
  fs.writeFileSync(output, JSON.stringify(report, null, 2) + '\n')
  process.stdout.write(
    JSON.stringify({ status: 'PASS', imageId: inspection.Id, output }) + '\n'
  )
} finally {
  if (created) docker(['rm', '-f', '-v', name])
  fs.rmSync(dir, { recursive: true, force: true })
}
