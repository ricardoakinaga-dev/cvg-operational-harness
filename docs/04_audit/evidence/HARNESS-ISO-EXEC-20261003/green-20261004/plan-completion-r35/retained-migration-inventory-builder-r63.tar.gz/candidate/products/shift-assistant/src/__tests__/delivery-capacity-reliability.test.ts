// @vitest-environment node
import * as fs from 'node:fs'
import { createServer, type Server, type ServerResponse } from 'node:http'
import type { AddressInfo } from 'node:net'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, expect, it } from 'vitest'
import { ShiftStore } from '../store.ts'
import { ShiftAssistant } from '../assistant.ts'
import { WahaClient } from '../whatsapp.ts'
import { buildShiftServer } from '../server.ts'
import { RAW, staticOrganizer } from './vertical-test-fixture.ts'

const ANA = '5511900000001',
  MANAGER = '5511900000009',
  SECRET = 'synthetic-input-secret',
  DELIVERY = 'synthetic-delivery-secret'
const cleanup: (() => Promise<void> | void)[] = []
afterEach(async () => {
  for (const close of cleanup.splice(0).reverse()) await close()
})
async function bind(server: Server) {
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve))
  cleanup.push(async () => {
    server.closeAllConnections()
    await new Promise<void>((resolve) => server.close(() => resolve()))
  })
  return `http://127.0.0.1:${(server.address() as AddressInfo).port}`
}
it('authenticates 1000 early callbacks through real HTTP/durable journal, rejects the 1001st, and expires only unmatched projections after 24h', async () => {
  const directory = fs.mkdtempSync(join(tmpdir(), 'delivery-capacity-'))
  cleanup.push(() => fs.rmSync(directory, { recursive: true, force: true }))
  let held: ServerResponse | undefined
  const receiver = createServer(async (request, response) => {
    for await (const chunk of request) void chunk
    held = response
    response.writeHead(201, { 'content-type': 'application/json' })
    response.flushHeaders()
  })
  const baseUrl = await bind(receiver)
  const store = new ShiftStore(directory)
  cleanup.push(() => store.close())
  const whatsapp = new WahaClient({
    baseUrl,
    session: 'fixture',
    apiKey: 'synthetic',
    fetch: async (url, init) => fetch(url, init),
    sendTimeoutMs: 10000
  })
  let now = new Date('2026-10-03T18:00:00Z')
  const assistant = new ShiftAssistant({
    store,
    whatsapp,
    members: [
      { phone: ANA, name: 'Ana', manager: false },
      { phone: MANAGER, name: 'Manager', manager: true }
    ],
    organizer: staticOrganizer,
    transcriber: {
      async transcribe() {
        return RAW
      }
    },
    clock: () => now
  })
  cleanup.push(() => assistant.stop())
  const server = buildShiftServer({
    assistant,
    store,
    whatsapp,
    webhookSecret: SECRET,
    deliverySimulationSecret: DELIVERY,
    clock: () => now
  })
  const url = await bind(server)
  const response = await fetch(url + '/webhooks/waha', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-cvg-webhook-secret': SECRET
    },
    body: JSON.stringify({
      event: 'message',
      session: 'fixture',
      payload: { id: 'synthetic-note', from: ANA + '@c.us', body: RAW }
    })
  })
  expect(response.status).toBe(200)
  const deadline = Date.now() + 5000
  while (!held && Date.now() < deadline)
    await new Promise((resolve) => setTimeout(resolve, 5))
  expect(held).toBeDefined()
  expect(store.outboxes().some((b) => b.state === 'dispatching')).toBe(true)
  const payload = (id: string) => ({
    provider: 'waha',
    accountRef: 'fixture',
    providerMessageId: id,
    recipient: ANA,
    deliveryStatus: 'delivery_confirmed',
    simulation: true
  })
  async function callback(id: string) {
    const response = await fetch(url + '/callbacks/delivery-simulation', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-cvg-webhook-secret': DELIVERY
      },
      body: JSON.stringify(payload(id))
    })
    const status = response.status
    await response.arrayBuffer()
    return status
  }
  const started = performance.now()
  for (let index = 0; index < 1000; index += 1)
    expect(await callback('early-' + index)).toBe(200)
  expect(store.deliveries()).toHaveLength(1000)
  expect(store.deliveries().every((d) => d.commitVerified)).toBe(true)
  const sequenceBeforeRefusal = store.sequence
  expect(await callback('over-capacity')).toBe(400)
  expect(store.sequence).toBe(sequenceBeforeRefusal)
  expect(store.storageAvailable).toBe(true)
  expect(store.deliveries()).toHaveLength(1000)
  const manifest = JSON.parse(
    fs.readFileSync(join(directory, 'journal/manifest.json'), 'utf8')
  )
  const segment = join(directory, manifest.segments.at(-1).path)
  const previousBytes = fs.readFileSync(segment)
  now = new Date(+now + 86400001)
  expect(await callback('after-expiration')).toBe(200)
  expect(store.deliveries()).toHaveLength(1)
  expect(store.deliveries()[0]!.providerMessageId).toBe('after-expiration')
  expect(fs.readFileSync(segment).subarray(0, previousBytes.length)).toEqual(
    previousBytes
  )
  held!.end(JSON.stringify({ id: 'early-0' }))
  await assistant.idle()
  await assistant.stop()
  const sequence = store.sequence
  store.close()
  const reopened = new ShiftStore(directory)
  cleanup.push(() => reopened.close())
  expect(reopened.storageAvailable).toBe(true)
  expect(reopened.sequence).toBe(sequence)
  expect(reopened.deliveries()).toHaveLength(1)
  expect(reopened.deliveries()[0]!.commitVerified).toBe(true)
  expect(fs.readFileSync(segment).subarray(0, previousBytes.length)).toEqual(
    previousBytes
  )
  console.log(
    'DELIVERY_CAPACITY_RECEIPT ' +
      JSON.stringify({
        status: 'PASS',
        scope: 'LOCAL_SIMULATOR_ONLY',
        admitted: 1000,
        rejectedAtCapacity: true,
        originalJournalPrefixPreserved: true,
        expirationMs: 86400001,
        remainingProjection: 1,
        reopenedSequence: sequence,
        elapsedMs: performance.now() - started
      })
  )
}, 120000)
