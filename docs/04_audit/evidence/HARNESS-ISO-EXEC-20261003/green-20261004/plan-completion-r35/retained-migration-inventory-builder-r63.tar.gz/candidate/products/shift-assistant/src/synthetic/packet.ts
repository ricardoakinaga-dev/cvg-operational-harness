import { readFile, readdir, lstat } from 'node:fs/promises'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { z } from 'zod'
import { AMENDMENT_SHA256, CORPUS_SHA256 } from './manifest.ts'
import {
  FixtureBindingSchema,
  assertBinding,
  deny,
  loadSyntheticCorpus,
  sha256,
  type FixtureBinding
} from './corpus.ts'

// No assumed API identifier: the Lead supplies the confirmed model explicitly.
export const SyntheticModelSchema = z
  .string()
  .regex(/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,119}$/)
export const SYNTHETIC_BASE_URL = 'https://api.openai.com/v1'
export const MAX_SYNTHETIC_CALLS = 20
export const MAX_SYNTHETIC_OUTPUT_TOKENS = 2048
export const SYNTHETIC_TIMEOUT_MS = 60_000
export const MAX_SYNTHETIC_REQUEST_BYTES = 32_768
// A separate V2 prompt: the default organizer and its V1 prompt are untouched.
export const SYNTHETIC_PROMPT = `Organize exclusivamente a fixture sintética fornecida. Responda somente JSON V2:
{"schemaVersion":2,"pacientes":[{"localRef":"p1","nome":"...","id":null,"leito":null,"especie":null,"tutor":null,"motivo":null,"evolucao":null,"exames_pedidos":[],"condutas":[]}],"pendencias":[{"localRef":"t1","descricao":"...","pacienteRef":"p1","pacienteId":null,"quando":null}],"duvidas":[],"evidence":[{"path":"pacientes.p1.nome","patientRef":"p1","quote":"citação literal"}]}
Use p1..p20 e t1..t20 únicos. Não acrescente campos. Cite trechos literais exatos em evidence para cada valor e use paths como pacientes.p1.id, pacientes.p1.exames_pedidos.0 e pendencias.t1.descricao. Não invente, normalize ou deduza IDs, números, unidades, doses, nomes, valores ou associações. Copie literalmente o que consta na fonte. quando somente com hora explícita, usando o instante informado e UTC-03:00. Registre ambiguidades em duvidas. Não dê diagnóstico, conselho ou recomendação, não execute ações e não use ferramentas.`
export const SYNTHETIC_PROMPT_SHA256 = sha256(SYNTHETIC_PROMPT)
const hash = z.string().regex(/^[a-f0-9]{64}$/)
export const SyntheticPacketSchema = z
  .strictObject({
    version: z.literal(1),
    mode: z.literal('synthetic-openai-test-only'),
    amendmentSha256: z.literal(AMENDMENT_SHA256),
    corpusSha256: z.literal(CORPUS_SHA256),
    bundleSha256: hash,
    promptSha256: z.literal(SYNTHETIC_PROMPT_SHA256),
    model: SyntheticModelSchema,
    baseUrl: z.literal(SYNTHETIC_BASE_URL),
    maxCalls: z.literal(MAX_SYNTHETIC_CALLS),
    maxOutputTokens: z.literal(MAX_SYNTHETIC_OUTPUT_TOKENS),
    timeoutMs: z.literal(SYNTHETIC_TIMEOUT_MS),
    maxRequestBytes: z.literal(MAX_SYNTHETIC_REQUEST_BYTES),
    retries: z.literal(0),
    fixtureBindings: z
      .array(FixtureBindingSchema)
      .min(1)
      .max(MAX_SYNTHETIC_CALLS)
  })
  .superRefine((p, ctx) => {
    if (
      new Set(p.fixtureBindings.map((b) => b.fixtureId)).size !==
      p.fixtureBindings.length
    )
      ctx.addIssue({ code: 'custom', message: 'Duplicate fixture identity' })
  })
export type SyntheticPacket = z.infer<typeof SyntheticPacketSchema>
export const HumanExecutionReceiptSchema = z.strictObject({
  decision: z.literal('AUTHORIZE_SYNTHETIC_EXTERNAL_EXECUTION'),
  packetSha256: hash,
  humanId: z.string().trim().min(1).max(120),
  evidenceRef: z.string().trim().min(1).max(512),
  recordedAtUtc: z.string().datetime(),
  executionId: z.string().regex(/^[a-zA-Z0-9_-]{8,120}$/)
})

/** Freeze the local source boundary, lockfile and config; no .env or other cache. */
export async function syntheticBundleSha256(): Promise<string> {
  const root = fileURLToPath(new URL('../../../../', import.meta.url))
  const paths = [
    'package-lock.json',
    'tsconfig.base.json',
    'products/shift-assistant/src/domain.ts',
    'products/shift-assistant/src/domain-v2.ts',
    'products/shift-assistant/src/organizer.ts',
    'products/shift-assistant/src/source-evidence.ts'
  ]
  async function sourceFiles(relative: string) {
    const stat = await lstat(join(root, relative))
    if (!stat.isDirectory() || stat.isSymbolicLink())
      deny('Bundle directory must be physical')
    for (const entry of await readdir(join(root, relative), {
      withFileTypes: true
    })) {
      if (entry.name === '__tests__') continue
      const path = `${relative}/${entry.name}`
      if (entry.isDirectory()) await sourceFiles(path)
      else if (entry.isFile() && entry.name.endsWith('.ts')) paths.push(path)
      else if (entry.isSymbolicLink()) deny('Bundle contains a symbolic link')
    }
  }
  await sourceFiles('products/shift-assistant/src/synthetic')
  for (const name of ['model-gateway', 'shared']) {
    paths.push(`packages/${name}/package.json`)
    await sourceFiles(`packages/${name}/src`)
  }
  const entries = []
  for (const path of paths.sort()) {
    const stat = await lstat(join(root, path))
    if (!stat.isFile() || stat.isSymbolicLink())
      deny('Bundle file must be physical')
    entries.push([path, sha256(await readFile(join(root, path)))])
  }
  return sha256(JSON.stringify(entries))
}

/** Preparation is read-only. It neither creates an approval nor calls a provider. */
export async function prepareSyntheticPacket(
  bindings: readonly FixtureBinding[],
  model: string,
  corpusDirectory?: string
) {
  const corpus = await loadSyntheticCorpus(corpusDirectory)
  const fixtureBindings = bindings.map((b) => {
    corpus.get(b)
    return assertBinding(b)
  })
  const packet = SyntheticPacketSchema.parse({
    version: 1,
    mode: 'synthetic-openai-test-only',
    amendmentSha256: AMENDMENT_SHA256,
    corpusSha256: CORPUS_SHA256,
    bundleSha256: await syntheticBundleSha256(),
    promptSha256: SYNTHETIC_PROMPT_SHA256,
    model: SyntheticModelSchema.parse(model),
    baseUrl: SYNTHETIC_BASE_URL,
    maxCalls: MAX_SYNTHETIC_CALLS,
    maxOutputTokens: MAX_SYNTHETIC_OUTPUT_TOKENS,
    timeoutMs: SYNTHETIC_TIMEOUT_MS,
    maxRequestBytes: MAX_SYNTHETIC_REQUEST_BYTES,
    retries: 0,
    fixtureBindings
  })
  const packetBytes = JSON.stringify(packet, null, 2) + '\n'
  return Object.freeze({ packetBytes, packetSha256: sha256(packetBytes) })
}

export async function authorizeSyntheticPacket(
  packetBytes: string,
  receipt: unknown
) {
  if (Buffer.byteLength(packetBytes) > 16_384)
    deny('Execution packet too large')
  let value: unknown
  try {
    value = JSON.parse(packetBytes)
  } catch {
    deny('Invalid execution packet JSON')
  }
  const parsed = SyntheticPacketSchema.safeParse(value)
  const approval = HumanExecutionReceiptSchema.safeParse(receipt)
  if (!parsed.success || !approval.success)
    deny('Frozen packet and human execution receipt required')
  if (approval.data.packetSha256 !== sha256(packetBytes))
    deny('Human receipt packet hash mismatch')
  for (const binding of parsed.data.fixtureBindings) assertBinding(binding)
  if (parsed.data.bundleSha256 !== (await syntheticBundleSha256()))
    deny('Execution bundle hash mismatch')
  // The receipt is an operator-supplied authority record, not an authentication service.
  return parsed.data
}
