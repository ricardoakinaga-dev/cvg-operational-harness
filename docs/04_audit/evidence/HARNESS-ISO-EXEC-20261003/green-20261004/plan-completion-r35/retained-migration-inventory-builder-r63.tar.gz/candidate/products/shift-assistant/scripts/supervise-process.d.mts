import type { ChildProcess } from 'node:child_process'
export interface StopReceipt {
  status: 'already_exited' | 'contained_forced' | 'exited'
  graceful: boolean
  elapsedMs: number
  exitCode: number | null
  signal: NodeJS.Signals | null
}
export function stopChildWithin(
  child: ChildProcess,
  options?: { graceMs?: number; totalMs?: number }
): Promise<StopReceipt>
