// @vitest-environment node
import { createServer, request, type Server } from 'node:http'
import type { AddressInfo } from 'node:net'
import { mkdtempSync, writeFileSync, symlinkSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { afterEach, expect, it } from 'vitest'
import { ShiftStore } from '../store.ts'
import { ShiftAssistant } from '../assistant.ts'
import { WahaClient, EvolutionClient } from '../whatsapp.ts'
import { WhisperTranscriber } from '../transcriber.ts'
import { allowlistedFetch } from '../egress.ts'
import { buildShiftServer } from '../server.ts'
import { loadShiftConfig } from '../config.ts'
import { composeShiftApp } from '../compose.ts'
import { ModelOrganizer } from '../organizer.ts'
import { decodeBase64, boundedRequest } from '../transport-limits.ts'
const ANA = '5511900000001',
  MANAGER = '5511900000009',
  SECRET = 'synthetic-webhook-secret-12345'
const members = [
  { phone: ANA, name: 'Ana', manager: false },
  { phone: MANAGER, name: 'Manager', manager: true }
]
const closers: (() => Promise<void> | void)[] = []
afterEach(async () => {
  for (const close of closers.reverse()) await close()
  closers.length = 0
})
async function bind(s: Server) {
  await new Promise<void>((r) => s.listen(0, '127.0.0.1', r))
  closers.push(() => {
    s.closeAllConnections()
    return new Promise<void>((r) => s.close(() => r()))
  })
  return `http://127.0.0.1:${(s.address() as AddressInfo).port}`
}
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))
async function until(p: () => boolean) {
  for (let i = 0; i < 300; i++) {
    if (p()) return
    await sleep(10)
  }
  throw new Error('predicate_timeout')
}
function volume() {
  return mkdtempSync(join(tmpdir(), 'operations-control-'))
}
function message(id: string, text: string, phone = ANA) {
  return {
    provider: 'waha' as const,
    messageId: id,
    fromPhone: phone,
    kind: 'text' as const,
    text,
    receivedAt: new Date().toISOString()
  }
}
it.each(['invalid', 'symlink', 'valid'])(
  'restore-hold %s constructor/reopen fails closed without changing journal bytes; resume cannot release',
  async (mode) => {
    const dir = volume(),
      store = new ShiftStore(dir)
    store.append({ type: 'paused', at: new Date().toISOString(), by: MANAGER })
    store.close()
    const manifestBefore = readFileSync(join(dir, 'journal/manifest.json'))
    const marker = join(dir, 'restore-hold.json')
    if (mode === 'symlink') symlinkSync(join(dir, 'missing-target'), marker)
    else writeFileSync(marker, mode === 'valid' ? '{}' : 'invalid')
    const reopened = new ShiftStore(dir)
    closers.push(() => reopened.close())
    expect(reopened.storageAvailable).toBe(true)
    expect(reopened.operationalHold).toBe(true)
    expect(reopened.effectsAllowed).toBe(false)
    expect(readFileSync(join(dir, 'journal/manifest.json'))).toEqual(
      manifestBefore
    )
    const client = new WahaClient({
      baseUrl: 'http://127.0.0.1:1',
      apiKey: 'synthetic',
      session: 'fixture',
      fetch: fetch
    })
    const assistant = new ShiftAssistant({
      store: reopened,
      members,
      whatsapp: client,
      organizer: new ModelOrganizer(),
      transcriber: {
        async transcribe() {
          throw new Error('unexpected')
        }
      }
    })
    expect(
      assistant.receive(message('resume', 'retomar assistente', MANAGER))
    ).toBe(true)
    expect(reopened.operationalHold).toBe(true)
    expect(reopened.effectsAllowed).toBe(false)
    expect(assistant.health().reasonCodes).toContain('operational_hold')
    const server = buildShiftServer({
      store: reopened,
      assistant,
      whatsapp: client,
      webhookSecret: SECRET
    })
    const url = await bind(server)
    expect((await fetch(url + '/health/ready')).status).toBe(503)
    expect((await fetch(url + '/health/live')).status).toBe(200)
    await assistant.stop()
  }
)
it('absence of restore marker keeps original healthy semantics on reopen', () => {
  const dir = volume(),
    first = new ShiftStore(dir)
  expect(first.effectsAllowed).toBe(true)
  first.close()
  const second = new ShiftStore(dir)
  closers.push(() => second.close())
  expect(second.storageAvailable).toBe(true)
  expect(second.operationalHold).toBe(false)
  expect(second.effectsAllowed).toBe(true)
})
it('config short scheduler default/ranges and every deadline ceiling reject old upgrade values and secrets never appear', () => {
  const env = {
    SHIFT_PROVIDER: 'waha',
    SHIFT_MEMBERS: `${ANA}=Ana;${MANAGER}=Manager*`,
    SHIFT_WEBHOOK_SECRET: SECRET,
    SHIFT_DATA_DIR: volume(),
    WAHA_URL: 'http://127.0.0.1:1',
    WAHA_API_KEY: 'synthetic',
    WHISPER_URL: 'http://127.0.0.1:1',
    LLM_BASE_URL: 'http://127.0.0.1:1',
    LLM_LOCATION: 'local',
    LLM_MODEL: 'synthetic'
  }
  expect(loadShiftConfig(env).env.SHIFT_TICK_SECONDS).toBe(1)
  for (const value of ['0', '6', '60', '3600'])
    expect(() =>
      loadShiftConfig({ ...env, SHIFT_TICK_SECONDS: value })
    ).toThrow('SHIFT_TICK_SECONDS')
  for (const [key, value] of Object.entries({
    SHIFT_SEND_TIMEOUT_MS: '10001',
    SHIFT_MEDIA_TIMEOUT_MS: '15001',
    SHIFT_WHISPER_TIMEOUT_MS: '120001',
    SHIFT_MODEL_TIMEOUT_MS: '60001',
    SHIFT_JOB_TIMEOUT_MS: '210001',
    SHIFT_SHUTDOWN_TIMEOUT_MS: '10001',
    SHIFT_MAX_MEDIA_BYTES: '10485761',
    SHIFT_MAX_PENDING_MESSAGES: '1001',
    SHIFT_HEALTH_STALE_MS: '30001'
  }))
    expect(() => loadShiftConfig({ ...env, [key]: value })).toThrow(key)
  expect(() =>
    loadShiftConfig({
      ...env,
      SHIFT_HOST: '0.0.0.0',
      SHIFT_DELIVERY_SIMULATION_SECRET: SECRET
    })
  ).toThrow('SHIFT_DELIVERY_SIMULATION_SECRET')
})
it.each(['send', 'download', 'whisper'])(
  '%s: real headers early/body hang deadline includes body and cancellation closes socket',
  async (kind) => {
    let calls = 0,
      closed = 0
    const url = await bind(
      createServer((req, res) => {
        calls++
        req.resume()
        res.writeHead(200, {
          'content-type': kind === 'download' ? 'audio/ogg' : 'application/json'
        })
        res.flushHeaders()
        res.write(kind === 'download' ? 'audio' : '{')
        res.on('close', () => closed++)
      })
    )
    const client = new WahaClient({
      baseUrl: url,
      apiKey: 'synthetic',
      session: 'fixture',
      fetch: allowlistedFetch([url]),
      sendTimeoutMs: 1000,
      mediaTimeoutMs: 1000
    })
    const transcriber = new WhisperTranscriber({
      baseUrl: url,
      model: 'synthetic',
      language: 'pt',
      fetch: allowlistedFetch([url]),
      timeoutMs: 1000
    })
    const start = performance.now()
    if (kind === 'send')
      expect(await client.sendText(ANA, 'synthetic')).toMatchObject({
        status: 'uncertain'
      })
    if (kind === 'download')
      await expect(
        client.downloadMedia({
          ...message('audio', ''),
          kind: 'audio',
          mediaRef: url + '/media',
          mimetype: 'audio/ogg'
        })
      ).rejects.toThrow('TRANSPORT_TIMEOUT')
    if (kind === 'whisper')
      await expect(
        transcriber.transcribe({
          bytes: new Uint8Array([1, 2, 3]),
          mimetype: 'audio/ogg'
        })
      ).rejects.toThrow('TRANSPORT_TIMEOUT')
    expect(performance.now() - start).toBeLessThan(2000)
    expect(calls).toBe(1)
    await until(() => closed === 1)
  }
)
it('real chunked paced media excess aborts without content-length; MIME/redirect/URL/text/base64 and Whisper caps reject', async () => {
  let hits = 0
  const url = await bind(
    createServer((req, res) => {
      hits++
      req.resume()
      if (req.url === '/redirect') {
        res.writeHead(302, { location: '/good' })
        res.end()
        return
      }
      if (req.url === '/badmime') {
        res.writeHead(200, { 'content-type': 'text/plain' })
        res.end('abc')
        return
      }
      if (req.url?.includes('transcriptions')) {
        res.end(JSON.stringify({ text: 'a'.repeat(16385) }))
        return
      }
      if (req.url?.includes('sendText')) {
        res.end('a'.repeat(65537))
        return
      }
      res.writeHead(200, { 'content-type': 'audio/ogg' })
      let n = 0
      const timer = setInterval(() => {
        res.write(Buffer.alloc(600))
        if (++n === 4) {
          clearInterval(timer)
          res.end()
        }
      }, 20)
      res.on('close', () => clearInterval(timer))
    })
  )
  const client = new WahaClient({
    baseUrl: url,
    apiKey: 'synthetic',
    session: 'fixture',
    fetch: allowlistedFetch([url]),
    maxMediaBytes: 1024
  })
  const audio = {
    ...message('audio', ''),
    kind: 'audio' as const,
    mimetype: 'audio/ogg'
  }
  await expect(
    client.downloadMedia({ ...audio, mediaRef: url + '/chunked' })
  ).rejects.toThrow('RESPONSE_TOO_LARGE')
  await expect(
    client.downloadMedia({ ...audio, mediaRef: url + '/badmime' })
  ).rejects.toThrow('MEDIA_INVALID')
  await expect(
    client.downloadMedia({ ...audio, mediaRef: url + '/redirect' })
  ).rejects.toThrow('TRANSPORT_HTTP_ERROR')
  const before = hits
  await expect(
    client.downloadMedia({
      ...audio,
      mediaRef: 'http://user:secret@localhost:99/private'
    })
  ).rejects.toThrow('EGRESS_DENIED')
  expect(hits).toBe(before)
  expect(await client.sendText(ANA, 'é'.repeat(16385))).toMatchObject({
    status: 'definitely_not_accepted'
  })
  expect(hits).toBe(before)
  expect(await client.sendText(ANA, 'synthetic')).toMatchObject({
    status: 'uncertain'
  })
  const whisper = new WhisperTranscriber({
    baseUrl: url,
    model: 'synthetic',
    language: 'pt',
    fetch: allowlistedFetch([url])
  })
  await expect(
    whisper.transcribe({ bytes: new Uint8Array([1]), mimetype: 'audio/ogg' })
  ).rejects.toThrow('WHISPER_SCHEMA_INVALID')
  for (const invalid of ['@@==', 'AQI', 'AR==', ''])
    expect(() => decodeBase64(invalid, 1024)).toThrow('MEDIA_INVALID')
  expect(() => decodeBase64('AAAA'.repeat(1000), 1024)).toThrow(
    'MEDIA_TOO_LARGE'
  )
  const evo = new EvolutionClient({
    baseUrl: url,
    apiKey: 'synthetic',
    instance: 'fixture',
    fetch: allowlistedFetch([url])
  })
  await expect(
    evo.downloadMedia({
      ...audio,
      provider: 'evolution',
      mediaRef: 'base64:@@=='
    })
  ).rejects.toThrow('MEDIA_INVALID')
})
it.each(['download', 'whisper', 'organizer'])(
  'pause during %s commits <1s; content retained; stop total <=10s; no late note',
  async (stage) => {
    let held = false,
      closed = 0
    const url = await bind(
      createServer((req, res) => {
        req.resume()
        if (req.url?.includes('sendText')) {
          res.end('{"id":"control"}')
          return
        }
        held = true
        res.writeHead(200, {
          'content-type':
            stage === 'download' ? 'audio/ogg' : 'application/json'
        })
        res.flushHeaders()
        res.on('close', () => closed++)
      })
    )
    const store = new ShiftStore(volume())
    closers.push(() => store.close())
    const client = new WahaClient({
      baseUrl: url,
      apiKey: 'synthetic',
      session: 'fixture',
      fetch: allowlistedFetch([url])
    })
    const transcriber = new WhisperTranscriber({
      baseUrl: url,
      model: 'synthetic',
      language: 'pt',
      fetch: allowlistedFetch([url])
    })
    const assistant = new ShiftAssistant({
      store,
      members,
      whatsapp: client,
      transcriber,
      organizer: {
        async organize(_raw, _at, signal) {
          return boundedRequest(
            allowlistedFetch([url]),
            url + '/model',
            {},
            60000,
            262144,
            signal
          )
        }
      }
    })
    closers.push(() => assistant.stop())
    const base = message('content', 'synthetic')
    if (stage === 'organizer') assistant.receive(base)
    else {
      const audio = {
        ...base,
        kind: 'audio' as const,
        mimetype: 'audio/ogg',
        mediaRef: url + '/media'
      }
      if (stage === 'whisper')
        client.downloadMedia = async () => ({
          bytes: new Uint8Array([1]),
          mimetype: 'audio/ogg'
        })
      assistant.receive(audio)
    }
    await until(() => held)
    const start = performance.now()
    expect(
      assistant.receive(message('pause', 'pausar assistente', MANAGER))
    ).toBe(true)
    expect(performance.now() - start).toBeLessThan(1000)
    await assistant.idle()
    expect(
      store.inboxes().find((i) => i.messageId === 'content')
    ).toMatchObject({ state: 'received', attempt: 0, error: 'paused' })
    expect(store.notesV2()).toHaveLength(0)
    expect(store.paused).toBe(true)
    await until(() => closed === 1)
    const stopAt = performance.now()
    await assistant.stop()
    expect(performance.now() - stopAt).toBeLessThan(10000)
  }
)
it('queue full admits only manager control; readiness redacts source/phone; paused healthy mode and shutdown idempotent', async () => {
  const store = new ShiftStore(volume())
  closers.push(() => store.close())
  const sent: string[] = []
  const client = new WahaClient({
    baseUrl: 'http://127.0.0.1:1',
    apiKey: 'synthetic',
    session: 'fixture',
    fetch: async (_url, init) => {
      sent.push(String(init?.body))
      return new Response('{"id":"synthetic"}')
    }
  })
  let release!: () => void
  const assistant = new ShiftAssistant({
    store,
    members,
    whatsapp: client,
    maxPendingMessages: 1,
    transcriber: {
      async transcribe() {
        return 'synthetic'
      }
    },
    organizer: {
      async organize() {
        await new Promise<void>((r) => {
          release = r
        })
        return {}
      }
    }
  })
  assistant.receive(message('first', 'private source'))
  expect(() => assistant.receive(message('second', 'synthetic'))).toThrow(
    'QUEUE_FULL'
  )
  expect(() =>
    assistant.receive(message('unauthorized-control', 'pausar assistente'))
  ).toThrow('QUEUE_FULL')
  expect(
    assistant.receive(message('pause', 'pausar assistente', MANAGER))
  ).toBe(true)
  await assistant.idle()
  release()
  const ready = assistant.health()
  expect(ready.reasonCodes).toContain('queue_full')
  expect(JSON.stringify(ready)).not.toContain(ANA)
  expect(JSON.stringify(ready)).not.toContain('private source')
  expect(sent).toHaveLength(1)
  const stop1 = assistant.stop(),
    stop2 = assistant.stop()
  expect(stop1).toBe(stop2)
  await stop1
})
it('HTTP ingress real incomplete body ->408, paced chunked excess ->413, invalid UTF8 ->400, 4-reader cap ->503, auth before admission', async () => {
  const store = new ShiftStore(volume())
  closers.push(() => store.close())
  const client = new WahaClient({
    baseUrl: 'http://127.0.0.1:1',
    apiKey: 'synthetic',
    session: 'fixture',
    fetch: fetch
  })
  const assistant = new ShiftAssistant({
    store,
    members,
    whatsapp: client,
    organizer: new ModelOrganizer(),
    transcriber: {
      async transcribe() {
        return ''
      }
    }
  })
  closers.push(() => assistant.stop())
  const server = buildShiftServer({
      store,
      assistant,
      whatsapp: client,
      webhookSecret: SECRET,
      maxBodyBytes: 1024,
      bodyTimeoutMs: 1000
    }),
    url = await bind(server)
  const raw = (mode: string) =>
    new Promise<number>((resolve, reject) => {
      const req = request(
        url + '/webhooks/waha',
        {
          method: 'POST',
          headers: {
            'content-type': 'application/json',
            'x-cvg-webhook-secret': SECRET
          }
        },
        (res) => {
          res.resume()
          res.on('end', () => resolve(res.statusCode!))
        }
      )
      req.on('error', reject)
      if (mode === 'hang') req.write('{')
      else if (mode === 'excess') {
        req.write(' '.repeat(700))
        setTimeout(() => req.end(' '.repeat(700)), 30)
      } else req.end(Buffer.from([0xff, 0xfe]))
    })
  const stalled = Array.from({ length: 4 }, () => raw('hang'))
  await sleep(100)
  expect(
    (
      await fetch(url + '/webhooks/waha', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'x-cvg-webhook-secret': SECRET
        },
        body: '{}'
      })
    ).status
  ).toBe(503)
  expect(await Promise.all(stalled)).toEqual([408, 408, 408, 408])
  expect(await raw('excess')).toBe(413)
  expect(await raw('utf8')).toBe(400)
  expect(
    (await fetch(url + '/webhooks/waha', { method: 'POST', body: '{}' })).status
  ).toBe(401)
  expect(store.inboxes()).toHaveLength(0)
})
it('default NO_MODEL preserves policy denial and zero model calls while source document is durable', async () => {
  let calls = 0
  const url = await bind(
    createServer((req, res) => {
      if (req.url?.includes('sendText')) {
        req.resume()
        res.end('{"id":"synthetic"}')
      } else {
        calls++
        res.end('{}')
      }
    })
  )
  const config = loadShiftConfig({
    SHIFT_PROVIDER: 'waha',
    SHIFT_MEMBERS: `${ANA}=Ana;${MANAGER}=Manager*`,
    SHIFT_WEBHOOK_SECRET: SECRET,
    SHIFT_DATA_DIR: volume(),
    SHIFT_PORT: '0',
    SHIFT_HOST: '127.0.0.1',
    WAHA_URL: url,
    WAHA_API_KEY: 'synthetic',
    WHISPER_URL: url,
    LLM_BASE_URL: url,
    LLM_LOCATION: 'local',
    LLM_MODEL: 'synthetic'
  })
  const app = composeShiftApp(config)
  await app.start()
  closers.push(() => app.stop())
  app.assistant.receive(
    message('clinical', 'Paciente sintético Rex, ID 20202.')
  )
  await app.assistant.idle()
  expect(app.store.notesV2()[0]?.warnings).toContain('policy_denied')
  expect(app.store.tasksV2()).toHaveLength(0)
  expect(calls).toBe(0)
})
it.each([
  'deadline-download',
  'deadline-whisper',
  'deadline-organizer',
  'shutdown-download',
  'shutdown-whisper',
  'shutdown-organizer'
])(
  '%s conserves checkpoint/attempt on reopen and closes blocked HTTP within total deadline',
  async (scenario) => {
    const [cause, stage] = scenario.split('-')
    let started = false,
      closed = 0
    const url = await bind(
      createServer((req, res) => {
        req.resume()
        if (req.url?.includes('sendText')) {
          res.end('{"id":"synthetic"}')
          return
        }
        started = true
        res.writeHead(200, {
          'content-type':
            stage === 'download' ? 'audio/ogg' : 'application/json'
        })
        res.flushHeaders()
        res.on('close', () => closed++)
      })
    )
    const dir = volume(),
      store = new ShiftStore(dir)
    closers.push(() => store.close())
    const client = new WahaClient({
      baseUrl: url,
      apiKey: 'synthetic',
      session: 'fixture',
      fetch: allowlistedFetch([url])
    })
    if (stage === 'whisper')
      client.downloadMedia = async () => ({
        bytes: new Uint8Array([1, 2, 3]),
        mimetype: 'audio/ogg'
      })
    const assistant = new ShiftAssistant({
      store,
      members,
      whatsapp: client,
      jobTimeoutMs: 1000,
      transcriber: new WhisperTranscriber({
        baseUrl: url,
        model: 'synthetic',
        language: 'pt',
        fetch: allowlistedFetch([url])
      }),
      organizer: {
        async organize(_raw, _at, signal) {
          return boundedRequest(
            allowlistedFetch([url]),
            url + '/model',
            {},
            60000,
            262144,
            signal
          )
        }
      }
    })
    closers.push(() => assistant.stop())
    assistant.receive(
      stage === 'organizer'
        ? message('source', 'synthetic transport input')
        : {
            ...message('source', ''),
            kind: 'audio',
            mimetype: 'audio/ogg',
            mediaRef: url + '/media'
          }
    )
    await until(() => started)
    const begin = performance.now()
    if (cause === 'shutdown') await assistant.stop()
    else await assistant.idle()
    expect(performance.now() - begin).toBeLessThan(10000)
    await until(() => closed === 1)
    const source = store.inboxes()[0]!
    expect(source).toMatchObject(
      cause === 'shutdown'
        ? { state: 'received', attempt: 0, error: 'shutdown' }
        : { state: 'retry_wait', attempt: 1, error: 'organizer_deadline' }
    )
    expect(store.notesV2()).toHaveLength(0)
    await assistant.stop()
    store.close()
    const replay = new ShiftStore(dir)
    closers.push(() => replay.close())
    expect(replay.inboxes()[0]).toMatchObject({
      state: source.state,
      attempt: source.attempt,
      error: source.error
    })
    expect(replay.notesV2()).toHaveLength(0)
  }
)
it('inline Evolution media is stored privately without base64 journal payload; valid source survives; invalid MIME refuses before transcription', async () => {
  const store = new ShiftStore(volume())
  closers.push(() => store.close())
  let transcriptions = 0
  const client = new EvolutionClient({
    baseUrl: 'http://127.0.0.1:1',
    apiKey: 'synthetic',
    instance: 'fixture',
    fetch: async () => new Response('{"key":{"id":"synthetic"}}')
  })
  const assistant = new ShiftAssistant({
    store,
    members,
    whatsapp: client,
    organizer: new ModelOrganizer(),
    transcriber: {
      async transcribe() {
        transcriptions++
        return 'synthetic source'
      }
    }
  })
  closers.push(() => assistant.stop())
  assistant.receive({
    ...message('inline', ''),
    provider: 'evolution',
    kind: 'audio',
    mediaRef: 'base64:AQID',
    mimetype: 'audio/ogg'
  })
  expect(() =>
    assistant.receive({
      ...message('inline', ''),
      provider: 'evolution',
      kind: 'audio',
      mediaRef: 'base64:AQIE',
      mimetype: 'audio/ogg'
    })
  ).toThrow('IDEMPOTENCY_CONFLICT')
  await assistant.idle()
  expect(transcriptions).toBe(1)
  expect(store.inboxes()[0]?.mediaPath).toBeDefined()
  expect(store.inboxes()[0]?.mediaRef).toBeUndefined()
  expect(store.mediaInventory().valid).toHaveLength(1)
  expect(
    assistant.receive({
      ...message('invalid', ''),
      kind: 'audio',
      mediaRef: 'base64:AQID',
      mimetype: 'text/html'
    })
  ).toBe(true)
  expect(store.inboxes().find((i) => i.messageId === 'invalid')).toMatchObject({
    state: 'review_required',
    error: 'MEDIA_INVALID',
    attempt: 0
  })
  expect(transcriptions).toBe(1)
})
it('pre-aborted transport never reaches real HTTP; unauthorized manager command bypasses suspended content processing but never changes pause', async () => {
  let calls = 0
  const url = await bind(
    createServer((req, res) => {
      calls++
      req.resume()
      res.end('{"id":"synthetic"}')
    })
  )
  const c = new AbortController()
  c.abort('paused')
  const client = new WahaClient({
    baseUrl: url,
    apiKey: 'synthetic',
    session: 'fixture',
    fetch: allowlistedFetch([url])
  })
  expect(await client.sendText(ANA, 'synthetic', c.signal)).toMatchObject({
    status: 'definitely_not_accepted'
  })
  await expect(
    client.downloadMedia(
      {
        ...message('media', ''),
        kind: 'audio',
        mediaRef: url + '/media',
        mimetype: 'audio/ogg'
      },
      c.signal
    )
  ).rejects.toThrow('TRANSPORT_TIMEOUT')
  expect(calls).toBe(0)
  const store = new ShiftStore(volume())
  closers.push(() => store.close())
  const assistant = new ShiftAssistant({
    store,
    members,
    whatsapp: client,
    organizer: {
      async organize() {
        return new Promise(() => {})
      }
    },
    transcriber: {
      async transcribe() {
        return ''
      }
    }
  })
  closers.push(() => assistant.stop())
  assistant.receive(message('source', 'synthetic'))
  const start = performance.now()
  assistant.receive(message('non-manager', 'pausar assistente'))
  expect(performance.now() - start).toBeLessThan(1000)
  expect(
    store.inboxes().find((i) => i.messageId === 'non-manager')?.state
  ).toBe('processed')
  expect(store.paused).toBe(false)
  await assistant.stop()
})
it('ready diagnostics cover stale scheduler, queue progress, deadlines and reason transition counters without arbitrary error payload', async () => {
  const { vi } = await import('vitest')
  const originalNow = Date.now(),
    dir = volume(),
    store = new ShiftStore(dir)
  closers.push(() => store.close())
  let clock = originalNow
  const alerts: unknown[] = []
  const client = new WahaClient({
    baseUrl: 'http://127.0.0.1:1',
    apiKey: 'synthetic',
    session: 'fixture',
    fetch: fetch
  })
  const assistant = new ShiftAssistant({
    store,
    members,
    whatsapp: client,
    clock: () => new Date(clock),
    jobTimeoutMs: 1000,
    organizer: {
      async organize() {
        return new Promise(() => {})
      }
    },
    transcriber: {
      async transcribe() {
        return ''
      }
    },
    logger: {
      info() {},
      error(_event, fields) {
        alerts.push(fields)
      }
    }
  })
  closers.push(() => assistant.stop())
  expect(assistant.health().ready).toBe(true)
  assistant.receive(message('source', 'private source'))
  const spy = vi.spyOn(Date, 'now').mockReturnValue(originalNow + 250001)
  try {
    clock += 250001
    expect(assistant.health().reasonCodes).toEqual(
      expect.arrayContaining([
        'scheduler_stale',
        'job_deadline',
        'queue_stalled'
      ])
    )
    const counters = assistant.health().metrics
    expect(counters).toMatchObject({
      scheduler_stale: 1,
      job_deadline: 1,
      queue_stalled: 1
    })
    expect(JSON.stringify(alerts)).not.toContain('private source')
    expect(JSON.stringify(alerts)).not.toContain(ANA)
  } finally {
    spy.mockRestore()
  }
  await assistant.stop()
})
it('pause during live HTTP send then app stop is one bounded operation, preserves uncertain and queued effects on reopen', async () => {
  let dispatching = false,
    closed = 0
  const url = await bind(
    createServer((req, res) => {
      req.resume()
      dispatching = true
      res.writeHead(201, { 'content-type': 'application/json' })
      res.flushHeaders()
      res.on('close', () => closed++)
    })
  )
  const dir = volume()
  const config = loadShiftConfig({
    SHIFT_PROVIDER: 'waha',
    SHIFT_MEMBERS: `${ANA}=Ana;${MANAGER}=Manager*`,
    SHIFT_WEBHOOK_SECRET: SECRET,
    SHIFT_DATA_DIR: dir,
    SHIFT_PORT: '0',
    SHIFT_HOST: '127.0.0.1',
    WAHA_URL: url,
    WAHA_API_KEY: 'synthetic',
    WHISPER_URL: url,
    LLM_BASE_URL: url,
    LLM_LOCATION: 'local',
    LLM_MODEL: 'synthetic'
  })
  const app = composeShiftApp(config)
  await app.start()
  closers.push(() => app.stop())
  app.assistant.receive(message('note', 'synthetic source'))
  await until(() => dispatching)
  const start = performance.now()
  await app.stop()
  expect(performance.now() - start).toBeLessThan(10000)
  await until(() => closed === 1)
  const reopened = new ShiftStore(dir)
  closers.push(() => reopened.close())
  expect(reopened.outboxes()[0]?.state).toBe('uncertain')
  expect(reopened.inboxes()[0]?.state).toBe('processed')
})
it('real TCP caps16 open connections, rejects17th503 and enforces absolute5s incomplete headers', async () => {
  const { connect } = await import('node:net')
  const store = new ShiftStore(volume())
  closers.push(() => store.close())
  const client = new WahaClient({
    baseUrl: 'http://127.0.0.1:1',
    apiKey: 'synthetic',
    session: 'fixture',
    fetch: fetch
  })
  const assistant = new ShiftAssistant({
    store,
    members,
    whatsapp: client,
    organizer: new ModelOrganizer(),
    transcriber: {
      async transcribe() {
        return ''
      }
    }
  })
  closers.push(() => assistant.stop())
  const server = buildShiftServer({
    store,
    assistant,
    whatsapp: client,
    webhookSecret: SECRET
  })
  const url = await bind(server),
    port = Number(new URL(url).port)
  const sockets = await Promise.all(
    Array.from(
      { length: 16 },
      () =>
        new Promise<import('node:net').Socket>((resolve) => {
          const socket = connect(port, '127.0.0.1', () => resolve(socket))
          socket.on('error', () => {})
        })
    )
  )
  closers.push(() => {
    for (const socket of sockets) socket.destroy()
  })
  const excess = await new Promise<string>((resolve, reject) => {
    let data = ''
    const s = connect(port, '127.0.0.1')
    s.on('error', reject)
    s.on('data', (chunk) => {
      data += String(chunk)
    })
    s.on('end', () => resolve(data))
  })
  expect(excess).toContain('503 Service Unavailable')
  for (const socket of sockets) socket.destroy()
  await sleep(50)
  const begin = performance.now()
  const timedOut = await new Promise<string>((resolve, reject) => {
    let data = ''
    const s = connect(port, '127.0.0.1', () =>
      s.write('POST /webhooks/waha HTTP/1.1\r\nHost: localhost\r\n')
    )
    s.on('error', reject)
    s.on('data', (chunk) => {
      data += String(chunk)
    })
    s.on('end', () => resolve(data))
    setTimeout(() => {
      s.destroy()
      reject(new Error('header_deadline_not_enforced'))
    }, 6500).unref()
  })
  expect(timedOut).toContain('408 Request Timeout')
  expect(performance.now() - begin).toBeLessThan(6000)
  expect(store.inboxes()).toHaveLength(0)
}, 8000)
it('whole job shares remaining1000ms across durable download/Whisper/organizer stage handoff instead of restarting deadline', async () => {
  let closed = 0
  const url = await bind(
    createServer((req, res) => {
      req.resume()
      if (req.url === '/media') {
        const timer = setTimeout(() => {
          res.writeHead(200, { 'content-type': 'audio/ogg' })
          res.end(Buffer.from([1, 2, 3]))
        }, 350)
        res.on('close', () => clearTimeout(timer))
        return
      }
      if (req.url?.includes('transcriptions')) {
        const timer = setTimeout(
          () => res.end('{"text":"synthetic source"}'),
          350
        )
        res.on('close', () => clearTimeout(timer))
        return
      }
      res.writeHead(200, { 'content-type': 'application/json' })
      res.flushHeaders()
      res.on('close', () => closed++)
    })
  )
  const store = new ShiftStore(volume())
  closers.push(() => store.close())
  const assistant = new ShiftAssistant({
    store,
    members,
    jobTimeoutMs: 1000,
    whatsapp: new WahaClient({
      baseUrl: url,
      apiKey: 'synthetic',
      session: 'fixture',
      fetch: allowlistedFetch([url])
    }),
    transcriber: new WhisperTranscriber({
      baseUrl: url,
      model: 'synthetic',
      language: 'pt',
      fetch: allowlistedFetch([url])
    }),
    organizer: {
      async organize(_text, _at, signal) {
        return boundedRequest(
          allowlistedFetch([url]),
          url + '/model',
          {},
          60000,
          262144,
          signal
        )
      }
    }
  })
  closers.push(() => assistant.stop())
  const begin = performance.now()
  assistant.receive({
    ...message('whole-job', ''),
    kind: 'audio',
    mediaRef: url + '/media',
    mimetype: 'audio/ogg'
  })
  await assistant.idle()
  expect(performance.now() - begin).toBeLessThan(1300)
  expect(store.inboxes()[0]).toMatchObject({
    state: 'retry_wait',
    attempt: 1,
    transcript: 'synthetic source',
    error: 'organizer_deadline'
  })
  expect(store.notesV2()).toHaveLength(0)
  await until(() => closed === 1)
})
