// @vitest-environment node
import { mkdtempSync, readFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, expect, it } from 'vitest'
import { ShiftStore, type CommitExpected } from '../store.ts'
import { canonical, sha256 } from '../journal.ts'
import { inputDigest } from '../vertical-state.ts'
import type { V2Event, EffectIdentity } from '../domain-v2.ts'
import { recordSimulatedDelivery } from '../delivery-receipts.ts'
import { composeShiftApp } from '../compose.ts'
import { loadShiftConfig } from '../config.ts'

const P = '5511900000001'
const EPOCH = Date.parse('2026-10-04T12:00:00Z')
const TTL = 86400000
const actor = { kind: 'member' as const, memberPhone: P }
const cleanup: Array<() => void> = []
afterEach(() => {
  for (const close of cleanup.splice(0).reverse()) close()
})
function fixture() {
  const dir = mkdtempSync(join(tmpdir(), 'ops-r6-'))
  cleanup.push(() => rmSync(dir, { recursive: true, force: true }))
  let store = new ShiftStore(dir)
  cleanup.push(() => store.close())
  let now = EPOCH
  let serial = 0
  const at = () => new Date(now).toISOString()
  const commit = (event: V2Event, id = 'own:' + ++serial) => {
    const expected: CommitExpected = {}
    for (const [entity, key] of store.references(event))
      (expected[entity] ??= {})[String(key)] = store.revision(entity, key)
    return store.commit({ transitionId: id, expected, changes: [event] })
  }
  const queue = (id = 'A', causal = true) => {
    const key = JSON.stringify(['waha', 'account-A', id])
    const inbox = {
      key,
      provider: 'waha' as const,
      session: 'account-A',
      messageId: id,
      memberPhone: P,
      kind: 'text' as const,
      text: 'ajuda',
      receivedAt: at(),
      digest: '',
      state: 'received' as const,
      stage: 'command' as const,
      attempt: 0
    }
    inbox.digest = inputDigest(inbox)
    commit({ v: 2, type: 'inbound_recorded', at: at(), actor, inbox })
    commit({
      v: 2,
      type: 'processing_started',
      at: at(),
      actor,
      key,
      stage: 'command',
      attempt: 1,
      deadline: new Date(now + 1000).toISOString(),
      draftAt: at()
    })
    const box = {
      id,
      purpose: 'response' as const,
      sourceTransitionId: 'source:' + id,
      recipientMemberId: P,
      payloadText: 'synthetic',
      payloadSha256: sha256('synthetic'),
      state: 'queued' as const,
      attempt: 0
    }
    commit(
      { v: 2, type: 'response_committed', at: at(), actor, key, outbox: box },
      causal ? box.sourceTransitionId : 'wrong:' + id
    )
    return box
  }
  const identity = (id = 'A'): EffectIdentity => ({
    provider: 'waha',
    accountRef: 'account-A',
    outboxId: id,
    sourceTransitionId: 'source:' + id,
    recipient: P
  })
  const start = (
    id = 'A',
    attempt = 1,
    proof: 'modern' | 'legacy' | 'null' = 'modern'
  ) => {
    commit({
      v: 2,
      type: 'outbox_dispatch_started',
      at: at(),
      actor,
      outboxId: id,
      attempt,
      ...(proof === 'legacy'
        ? {}
        : { identity: proof === 'null' ? null : identity(id) })
    })
  }
  const result = (
    id = 'A',
    providerId = 'receipt',
    proof: 'modern' | 'legacy' = 'modern'
  ) => {
    commit({
      v: 2,
      type: 'outbox_result',
      at: at(),
      actor,
      outboxId: id,
      state: 'provider_accepted',
      receipt: {
        status: 201,
        at: at(),
        sha256: sha256('response'),
        providerId,
        ...(proof === 'modern' ? { identity: identity(id) } : {})
      }
    })
  }
  const payload = (providerId = 'receipt') => ({
    provider: 'waha' as const,
    accountRef: 'account-A',
    providerMessageId: providerId,
    recipient: P,
    deliveryStatus: 'delivery_confirmed' as const,
    simulation: true as const
  })
  // Uses the public recording routine; app provides actual member and channel contracts.
  const app = composeShiftApp(
    loadShiftConfig({
      SHIFT_PROVIDER: 'waha',
      SHIFT_MEMBERS: `${P}=Sintetico;5511900000009=Gestor*`,
      SHIFT_WEBHOOK_SECRET: 'r6-synthetic-input-secret-24bytes',
      SHIFT_DATA_DIR: join(dir, 'app-private'),
      WAHA_URL: 'http://127.0.0.1:1',
      WAHA_API_KEY: 'synthetic',
      WAHA_SESSION: 'account-A',
      WHISPER_URL: 'http://127.0.0.1:2',
      LLM_BASE_URL: 'http://127.0.0.1:3',
      LLM_MODEL: 'disabled',
      LLM_LOCATION: 'local'
    }),
    { clock: () => new Date(now) }
  )
  cleanup.push(() => app.store.close())
  const record = (id = 'receipt') =>
    recordSimulatedDelivery(payload(id), store, app.whatsapp, app.assistant, at)
  const legacyReceipt = (id = 'receipt', verified = true) => {
    const p = payload(id),
      raw = canonical(p)
    const eventIdentity = sha256(
      JSON.stringify([
        p.provider,
        p.accountRef,
        p.providerMessageId,
        p.recipient,
        p.deliveryStatus
      ])
    )
    commit({
      v: 2,
      type: 'delivery_receipt_recorded',
      at: at(),
      actor,
      receipt: {
        ...p,
        eventIdentity,
        receivedAt: at(),
        committedAt: at(),
        raw,
        rawReceiptRef: 'journal:delivery:' + eventIdentity,
        rawSha256: sha256(raw),
        commitVerified: false
      }
    })
    if (verified)
      commit({
        v: 2,
        type: 'delivery_receipt_committed',
        at: at(),
        actor,
        eventIdentity,
        committedAt: at()
      })
    return eventIdentity
  }
  const bytes = () => {
    const manifest = JSON.parse(
      readFileSync(join(dir, 'journal/manifest.json'), 'utf8')
    ) as { segments: Array<{ path: string }> }
    return readFileSync(join(dir, manifest.segments.at(-1)!.path))
  }
  return {
    get store() {
      return store
    },
    at,
    commit,
    queue,
    start,
    result,
    identity,
    record,
    legacyReceipt,
    bytes,
    advance(ms: number) {
      now += ms
    },
    reopen() {
      store.close()
      store = new ShiftStore(dir)
      expect(store.storageAvailable).toBe(true)
    }
  }
}

it.each([TTL - 1, TTL, TTL + 1])(
  'early acceptance at %i ms honors the inclusive 24h boundary and replay without callbacks',
  (age) => {
    const f = fixture()
    f.queue()
    f.start()
    f.record()
    const prefix = f.bytes()
    f.advance(age)
    f.result()
    expect(Boolean(f.store.outbox('A')?.delivery)).toBe(age <= TTL)
    f.reopen()
    expect(Boolean(f.store.outbox('A')?.delivery)).toBe(age <= TTL)
    expect(f.bytes().subarray(0, prefix.length)).toEqual(prefix)
  }
)
it('early receipt carries exact causal attempt/start identity durably, confirms on acceptance once and keeps proved match beyond TTL', () => {
  const f = fixture()
  f.queue()
  f.start()
  f.record()
  expect(f.store.deliveries()[0]?.eligibility).toEqual({
    identity: f.identity(),
    attempt: 1,
    startedAt: f.at()
  })
  expect(f.store.outbox('A')?.delivery).toBeUndefined()
  f.result()
  const bytes = f.bytes(),
    seq = f.store.sequence
  f.advance(TTL + 1)
  f.reopen()
  expect(f.store.outbox('A')?.delivery?.commitVerified).toBe(true)
  expect(f.record()).toBe(false)
  expect(f.store.sequence).toBe(seq)
  expect(f.bytes()).toEqual(bytes)
})
it('pending receipt from prior attempt cannot certify a new attempt of the same outbox using the same id', () => {
  const f = fixture()
  f.queue()
  f.start()
  f.record()
  f.commit({
    v: 2,
    type: 'outbox_result',
    at: f.at(),
    actor,
    outboxId: 'A',
    state: 'retry_wait',
    error: 'definitely_not_accepted',
    nextAttemptAt: f.at()
  })
  f.advance(1)
  f.start('A', 2)
  f.result()
  expect(f.store.outbox('A')?.attempt).toBe(2)
  expect(f.store.outbox('A')?.delivery).toBeUndefined()
  f.reopen()
  expect(f.store.outbox('A')?.delivery).toBeUndefined()
})
it.each([1, TTL + 1])(
  'uncertain A receipt cannot bind B with same tuple/id after %i ms; no new callback',
  (age) => {
    const f = fixture()
    f.queue()
    f.start()
    f.record()
    f.commit({
      v: 2,
      type: 'outbox_result',
      at: f.at(),
      actor,
      outboxId: 'A',
      state: 'uncertain',
      error: 'synthetic-timeout'
    })
    const prefix = f.bytes()
    f.advance(age)
    f.reopen()
    f.queue('B')
    f.start('B')
    f.result('B')
    expect(f.store.outbox('A')?.state).toBe('uncertain')
    expect(f.store.outbox('A')?.delivery).toBeUndefined()
    expect(f.store.outbox('B')?.delivery).toBeUndefined()
    f.reopen()
    expect(f.store.outbox('B')?.delivery).toBeUndefined()
    expect(f.bytes().subarray(0, prefix.length)).toEqual(prefix)
  }
)
it('ambiguous historical started attempts reject new callback without any durable delta', () => {
  const f = fixture()
  f.queue()
  f.start()
  f.queue('B')
  f.start('B')
  const seq = f.store.sequence,
    bytes = f.bytes()
  expect(() => f.record()).toThrow('INVALID_DELIVERY')
  expect(f.store.sequence).toBe(seq)
  expect(f.bytes()).toEqual(bytes)
})
it('ambiguous legacy reception remains denied even after one eligible attempt becomes accepted', () => {
  const f = fixture()
  f.queue()
  f.start()
  f.queue('B')
  f.start('B')
  f.legacyReceipt()
  const prefix = f.bytes()
  f.result()
  expect(f.store.outbox('A')?.delivery).toBeUndefined()
  f.reopen()
  expect(f.store.outboxes().every((b) => !b.delivery)).toBe(true)
  expect(f.bytes().subarray(0, prefix.length)).toEqual(prefix)
})
it.each(['legacy', 'null'] as const)(
  'legacy with missing causality / explicit %s proof is denied despite later compatible input',
  (proof) => {
    const f = fixture()
    f.queue('A', proof === 'null')
    f.start('A', 1, proof)
    f.legacyReceipt()
    f.commit({
      v: 2,
      type: 'outbox_result',
      at: f.at(),
      actor,
      outboxId: 'A',
      state: 'uncertain',
      error: 'synthetic'
    })
    f.queue('B')
    f.start('B')
    f.result('B')
    f.reopen()
    expect(f.store.outboxes().every((b) => !b.delivery)).toBe(true)
  }
)
it('legacy exact started event derives only at reception and preserves journal bytes through replay', () => {
  const f = fixture()
  f.queue()
  f.start('A', 1, 'legacy')
  f.legacyReceipt()
  f.result('A', 'receipt', 'legacy')
  const bytes = f.bytes()
  expect(f.store.outbox('A')?.delivery?.commitVerified).toBe(true)
  f.reopen()
  expect(f.store.outbox('A')?.delivery?.commitVerified).toBe(true)
  expect(f.bytes()).toEqual(bytes)
})
it('legacy receipt preceding any start remains unbound when an exact later send accepts its id', () => {
  const f = fixture()
  f.queue()
  f.legacyReceipt()
  f.start()
  f.result()
  f.reopen()
  expect(f.store.outbox('A')?.delivery).toBeUndefined()
})
it('known same-tuple id collision denies reception and previously pending reconciliation', () => {
  const f = fixture()
  f.queue()
  f.start()
  f.record()
  f.queue('B')
  f.start('B')
  f.result('B')
  f.result()
  expect(f.store.outboxes().every((b) => !b.delivery)).toBe(true)
  const seq = f.store.sequence
  expect(() => f.record('receipt')).toThrow('INVALID_DELIVERY')
  expect(f.store.sequence).toBe(seq)
  f.reopen()
  expect(f.store.outboxes().every((b) => !b.delivery)).toBe(true)
})
it('saturated pending inbox allows known matched effect and dedup, caps overflow, then expires only unmatched documents', () => {
  const f = fixture()
  f.queue('known')
  f.start('known')
  f.result('known', 'known-id')
  f.queue()
  f.start()
  for (let i = 0; i < 1000; i++) f.record('pending-' + i)
  const seq = f.store.sequence
  expect(() => f.record('overflow')).toThrow()
  expect(f.store.sequence).toBe(seq)
  expect(f.record('known-id')).toBe(true)
  expect(f.store.deliveries()).toHaveLength(1001)
  const duplicate = f.store.sequence
  expect(f.record('pending-0')).toBe(false)
  expect(f.record('known-id')).toBe(false)
  expect(f.store.sequence).toBe(duplicate)
  f.result('A', 'pending-0')
  expect(f.store.outbox('A')?.delivery).toBeDefined()
  const prefix = f.bytes()
  f.advance(TTL + 1)
  f.queue('new')
  f.start('new')
  f.record('fresh')
  expect(f.store.deliveries()).toHaveLength(3)
  expect(f.store.outbox('known')?.delivery).toBeDefined()
  expect(f.store.outbox('A')?.delivery).toBeDefined()
  f.reopen()
  expect(f.store.deliveries()).toHaveLength(3)
  expect(f.bytes().subarray(0, prefix.length)).toEqual(prefix)
})

it('expired reception dedup never stages a fresh identity for B or rewrites the old receipt', () => {
  const f = fixture()
  f.queue()
  f.start()
  f.record()
  f.commit({
    v: 2,
    type: 'outbox_result',
    at: f.at(),
    actor,
    outboxId: 'A',
    state: 'uncertain',
    error: 'synthetic-timeout'
  })
  f.advance(TTL + 1)
  f.queue('B')
  f.start('B')
  f.result('B')
  f.reopen()
  const bytes = f.bytes(),
    seq = f.store.sequence
  expect(f.record()).toBe(false)
  expect(f.store.sequence).toBe(seq)
  expect(f.bytes()).toEqual(bytes)
  expect(f.store.outboxes().every((b) => !b.delivery)).toBe(true)
})
it('a reception without final fsync expires at reconciliation and cannot be resurrected by a late commit', () => {
  const f = fixture()
  f.queue()
  f.start()
  const eventIdentity = f.legacyReceipt('receipt', false)
  const prefix = f.bytes()
  f.advance(TTL + 1)
  f.result()
  expect(f.store.deliveries()).toHaveLength(0)
  f.commit({
    v: 2,
    type: 'delivery_receipt_committed',
    at: f.at(),
    actor,
    eventIdentity,
    committedAt: f.at()
  })
  f.reopen()
  expect(f.store.outbox('A')?.delivery).toBeUndefined()
  expect(f.store.deliveries()).toHaveLength(0)
  const seq = f.store.sequence
  expect(f.record()).toBe(false)
  expect(f.store.sequence).toBe(seq)
  expect(f.bytes().subarray(0, prefix.length)).toEqual(prefix)
})
it('an already proved match remains on its original effect after later tuple/id collision and TTL', () => {
  const f = fixture()
  f.queue()
  f.start()
  f.result()
  f.record()
  f.queue('B')
  f.start('B')
  f.result('B')
  f.advance(TTL + 1)
  f.reopen()
  expect(f.store.outbox('A')?.delivery?.commitVerified).toBe(true)
  expect(f.store.outbox('B')?.delivery).toBeUndefined()
})
it('historical reception dated before its recorded started attempt cannot derive legacy proof', () => {
  const f = fixture()
  f.advance(1000)
  f.queue()
  f.start()
  f.advance(-1000)
  f.legacyReceipt()
  f.advance(1000)
  f.result()
  f.reopen()
  expect(f.store.outbox('A')?.delivery).toBeUndefined()
})

it('failed multi-event validation cannot leak a receipt commit or match into the live projection', () => {
  const f = fixture()
  f.queue()
  f.start()
  const eventIdentity = f.legacyReceipt('receipt', false)
  f.result()
  const changes: V2Event[] = [
    {
      v: 2,
      type: 'delivery_receipt_committed',
      at: f.at(),
      actor,
      eventIdentity,
      committedAt: f.at()
    },
    {
      v: 2,
      type: 'outbox_result',
      at: f.at(),
      actor,
      outboxId: 'missing',
      state: 'uncertain',
      error: 'synthetic'
    }
  ]
  const expected: CommitExpected = {}
  for (const event of changes)
    for (const [entity, key] of f.store.references(event))
      (expected[entity] ??= {})[String(key)] = f.store.revision(entity, key)
  const before = f.bytes(),
    seq = f.store.sequence
  expect(() =>
    f.store.commit({ transitionId: 'own:failed-batch', expected, changes })
  ).toThrow('STATE_CONFLICT')
  expect(f.store.sequence).toBe(seq)
  expect(f.bytes()).toEqual(before)
  expect(f.store.deliveryCommitted(eventIdentity)).toBe(false)
  expect(f.store.deliveries()[0]?.commitVerified).toBe(false)
  expect(f.store.outbox('A')?.delivery).toBeUndefined()
  f.commit(changes[0]!)
  expect(f.store.outbox('A')?.delivery?.commitVerified).toBe(true)
  f.reopen()
  expect(f.store.outbox('A')?.delivery?.commitVerified).toBe(true)
})
