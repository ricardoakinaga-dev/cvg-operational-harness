export type FetchLike = (input: string, init?: RequestInit) => Promise<Response>

export class EgressDeniedError extends Error {
  constructor(url: string) {
    super('EGRESS_DENIED')
    void url
    this.name = 'EgressDeniedError'
  }
}

/**
 * Fetch restricted to an explicit list of origins (scheme + host + port).
 * Redirects are never followed, so a configured service cannot bounce the
 * assistant to an unlisted destination.
 */
export function allowlistedFetch(
  allowedOrigins: readonly string[],
  fetchImpl: FetchLike = globalThis.fetch as FetchLike
): FetchLike {
  const allowed = new Set(
    allowedOrigins.map((origin) => {
      const u = new URL(origin)
      if (!['http:', 'https:'].includes(u.protocol) || u.username || u.password)
        throw new EgressDeniedError(origin)
      return u.origin
    })
  )
  return async (input, init) => {
    let origin: string
    try {
      const u = new URL(input)
      if (u.username || u.password || !['http:', 'https:'].includes(u.protocol))
        throw new EgressDeniedError(input)
      origin = u.origin
    } catch {
      throw new EgressDeniedError(input)
    }
    if (!allowed.has(origin)) throw new EgressDeniedError(input)
    return fetchImpl(input, { ...init, redirect: 'manual' })
  }
}
