import {
  boundedRequest,
  strictJson,
  mediaMime,
  decodeBase64
} from './transport-limits.ts'
import { sha256 } from './journal.ts'
import type { Outbox } from './domain.ts'
import type { InboundMessage, MessageKind } from './domain.ts'
import { normalizePhone } from './domain.ts'
import type { FetchLike } from './egress.ts'

export interface MediaFile {
  bytes: Uint8Array
  mimetype: string
}

export interface WhatsAppClient {
  readonly provider: 'waha' | 'evolution'
  readonly session?: string
  /** Returns undefined for anything that is not a direct inbound message. */
  parseWebhook(payload: unknown, receivedAt: string): InboundMessage | undefined
  sendText(
    phone: string,
    text: string,
    signal?: AbortSignal
  ): Promise<SendResult | void>
  downloadMedia(
    message: InboundMessage,
    signal?: AbortSignal
  ): Promise<MediaFile>
}

type Json = Record<string, unknown>

function obj(value: unknown): Json | undefined {
  return value && typeof value === 'object' && !Array.isArray(value)
    ? (value as Json)
    : undefined
}

function str(value: unknown): string | undefined {
  return typeof value === 'string' && value.length > 0 ? value : undefined
}

function kindFromMime(mimetype: string | undefined): MessageKind | undefined {
  if (!mimetype) return undefined
  if (mimetype.startsWith('audio/')) return 'audio'
  if (mimetype.startsWith('image/')) return 'image'
  return undefined
}

export type SendResult =
  | { status: 'provider_accepted'; receipt: NonNullable<Outbox['receipt']> }
  | { status: 'definitely_not_accepted'; code: string }
  | { status: 'uncertain'; code: string }

export interface WahaOptions {
  baseUrl: string
  apiKey: string
  session: string
  sendTimeoutMs?: number
  mediaTimeoutMs?: number
  maxMediaBytes?: number
  fetch: FetchLike
}

/** WAHA (WhatsApp HTTP API): `message` webhook event, `/api/sendText`. */
export class WahaClient implements WhatsAppClient {
  readonly provider = 'waha' as const
  readonly #options: WahaOptions

  constructor(options: WahaOptions) {
    this.#options = { ...options, baseUrl: options.baseUrl.replace(/\/+$/, '') }
  }

  parseWebhook(
    payload: unknown,
    receivedAt: string
  ): InboundMessage | undefined {
    const root = obj(payload)
    if (root?.session !== undefined && root.session !== this.#options.session)
      return undefined
    if (root?.event !== 'message') return undefined
    const message = obj(root.payload)
    const id = str(message?.id)
    const from = str(message?.from)
    if (!message || !id || !from || message.fromMe === true) return undefined
    if (!from.endsWith('@c.us')) return undefined // groups, broadcasts, newsletters
    const media = obj(message.media)
    const mimetype = str(media?.mimetype)
    const mediaKind =
      message.hasMedia === true ? kindFromMime(mimetype) : undefined
    const text = str(message.body) ?? ''
    if (!mediaKind && !text.trim()) return undefined
    return {
      provider: 'waha',
      messageId: id,
      fromPhone: normalizePhone(from),
      kind: mediaKind ?? 'text',
      text,
      ...(mediaKind && str(media?.url) ? { mediaRef: str(media?.url)! } : {}),
      ...(mediaKind && mimetype ? { mimetype } : {}),
      receivedAt
    }
  }

  get session(): string {
    return this.#options.session
  }
  sendText(
    phone: string,
    text: string,
    signal?: AbortSignal
  ): Promise<SendResult> {
    return boundedSend(
      this.#options.fetch,
      `${this.#options.baseUrl}/api/sendText`,
      { 'content-type': 'application/json', 'x-api-key': this.#options.apiKey },
      {
        session: this.#options.session,
        chatId: `${normalizePhone(phone)}@c.us`,
        text
      },
      this.#options.sendTimeoutMs ?? 10000,
      signal
    )
  }

  async downloadMedia(
    message: InboundMessage,
    signal?: AbortSignal
  ): Promise<MediaFile> {
    if (!message.mediaRef) throw new Error('Message has no media')
    const u = new URL(message.mediaRef)
    if (
      u.origin !== new URL(this.#options.baseUrl).origin ||
      u.username ||
      u.password
    )
      throw new Error('EGRESS_DENIED')
    const { response, bytes } = await boundedRequest(
      this.#options.fetch,
      message.mediaRef,
      {
        headers: { 'x-api-key': this.#options.apiKey }
      },
      this.#options.mediaTimeoutMs ?? 15000,
      this.#options.maxMediaBytes ?? 10485760,
      signal
    )
    const mime = mediaMime(
      response.headers.get('content-type') ?? message.mimetype
    )
    if (message.mimetype && mediaMime(message.mimetype) !== mime)
      throw new Error('MEDIA_INVALID')
    return { bytes, mimetype: mime }
  }
}

export interface EvolutionOptions {
  baseUrl: string
  apiKey: string
  instance: string
  sendTimeoutMs?: number
  mediaTimeoutMs?: number
  maxMediaBytes?: number
  fetch: FetchLike
}

/** Evolution API v2: `messages.upsert` webhook event, `/message/sendText`. */
export class EvolutionClient implements WhatsAppClient {
  readonly provider = 'evolution' as const
  readonly #options: EvolutionOptions

  constructor(options: EvolutionOptions) {
    this.#options = { ...options, baseUrl: options.baseUrl.replace(/\/+$/, '') }
  }

  parseWebhook(
    payload: unknown,
    receivedAt: string
  ): InboundMessage | undefined {
    const root = obj(payload)
    if (
      root?.instance !== undefined &&
      root.instance !== this.#options.instance
    )
      return undefined
    const event = str(root?.event)?.toLowerCase().replace('_', '.')
    if (event !== 'messages.upsert') return undefined
    const data = obj(root?.data)
    const key = obj(data?.key)
    const id = str(key?.id)
    const remoteJid = str(key?.remoteJid)
    if (!data || !id || !remoteJid || key?.fromMe === true) return undefined
    if (!remoteJid.endsWith('@s.whatsapp.net')) return undefined
    const content = obj(data.message)
    if (!content) return undefined
    const audio = obj(content.audioMessage)
    const image = obj(content.imageMessage)
    const extended = obj(content.extendedTextMessage)
    const text =
      str(content.conversation) ??
      str(extended?.text) ??
      str(image?.caption) ??
      ''
    const kind: MessageKind = audio ? 'audio' : image ? 'image' : 'text'
    if (kind === 'text' && !text.trim()) return undefined
    const mimetype = str(audio?.mimetype) ?? str(image?.mimetype)
    // With `webhook_base64` enabled the media arrives inline; otherwise it is
    // fetched by message id.
    const inline = str(content.base64)
    return {
      provider: 'evolution',
      messageId: id,
      fromPhone: normalizePhone(remoteJid),
      kind,
      text,
      ...(kind !== 'text'
        ? { mediaRef: inline ? `base64:${inline}` : `id:${id}` }
        : {}),
      ...(kind !== 'text' && mimetype ? { mimetype } : {}),
      receivedAt
    }
  }

  get session(): string {
    return this.#options.instance
  }
  sendText(
    phone: string,
    text: string,
    signal?: AbortSignal
  ): Promise<SendResult> {
    return boundedSend(
      this.#options.fetch,
      `${this.#options.baseUrl}/message/sendText/${encodeURIComponent(this.#options.instance)}`,
      { 'content-type': 'application/json', apikey: this.#options.apiKey },
      { number: normalizePhone(phone), text },
      this.#options.sendTimeoutMs ?? 10000,
      signal
    )
  }

  async downloadMedia(
    message: InboundMessage,
    signal?: AbortSignal
  ): Promise<MediaFile> {
    const ref = message.mediaRef
    if (!ref) throw new Error('Message has no media')
    const fallbackMime = mediaMime(message.mimetype)
    const max = this.#options.maxMediaBytes ?? 10485760
    if (signal?.aborted) throw new Error('TRANSPORT_TIMEOUT')
    if (ref.startsWith('base64:'))
      return { bytes: decodeBase64(ref.slice(7), max), mimetype: fallbackMime }
    if (ref !== `id:${message.messageId}`) throw new Error('MEDIA_INVALID')
    const { bytes } = await boundedRequest(
      this.#options.fetch,
      `${this.#options.baseUrl}/chat/getBase64FromMediaMessage/${encodeURIComponent(this.#options.instance)}`,
      {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          apikey: this.#options.apiKey
        },
        body: JSON.stringify({
          message: { key: { id: message.messageId } },
          convertToMp4: false
        })
      },
      this.#options.mediaTimeoutMs ?? 15000,
      16777216,
      signal
    )
    const body = obj(strictJson(bytes))
    const base64 = str(body?.base64)
    if (!base64) throw new Error('MEDIA_INVALID')
    return {
      bytes: decodeBase64(base64, max),
      mimetype: mediaMime(str(body?.mimetype) ?? fallbackMime)
    }
  }
}

async function boundedSend(
  fetchImpl: FetchLike,
  url: string,
  headers: Record<string, string>,
  payload: Record<string, unknown>,
  timeout: number,
  external?: AbortSignal
): Promise<SendResult> {
  if (
    Buffer.byteLength(String(payload.text)) > 32768 ||
    external?.aborted ||
    !Number.isFinite(timeout) ||
    timeout <= 0 ||
    timeout > 10000
  )
    return { status: 'definitely_not_accepted', code: 'local_validation' }
  try {
    const { response, bytes: body } = await boundedRequest(
      fetchImpl,
      url,
      { method: 'POST', headers, body: JSON.stringify(payload) },
      timeout,
      65536,
      external
    )
    const json = obj(strictJson(body))
    if (!json) throw new Error('invalid_receipt')
    const providerId = str(json.id) ?? str(obj(json.key)?.id)
    return {
      status: 'provider_accepted',
      receipt: {
        status: response.status,
        at: new Date().toISOString(),
        sha256: sha256(body),
        ...(providerId && providerId.length <= 256 ? { providerId } : {})
      }
    }
  } catch {
    return { status: 'uncertain', code: 'post_start_failure' }
  }
}
