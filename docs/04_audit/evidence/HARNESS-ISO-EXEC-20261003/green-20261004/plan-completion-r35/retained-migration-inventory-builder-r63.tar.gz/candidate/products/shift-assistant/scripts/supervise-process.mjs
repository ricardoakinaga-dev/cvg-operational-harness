import { spawn } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'

/** External process control; a blocked child cannot delay this process's timer. */
export function stopChildWithin(child, options = {}) {
  const graceMs = options.graceMs ?? 10000,
    totalMs = options.totalMs ?? 15000
  if (
    !Number.isSafeInteger(graceMs) ||
    !Number.isSafeInteger(totalMs) ||
    graceMs < 0 ||
    graceMs > 10000 ||
    totalMs <= graceMs ||
    totalMs > 15000
  )
    return Promise.reject(new Error('INVALID_EXTERNAL_STOP_BUDGET'))
  if (!Number.isInteger(child.pid) || !child.kill || !child.once)
    return Promise.reject(new Error('OWN_CHILD_PROCESS_REQUIRED'))
  const started = performance.now()
  if (child.exitCode !== null || child.signalCode !== null)
    return Promise.resolve({
      status: 'already_exited',
      graceful: false,
      elapsedMs: 0,
      exitCode: child.exitCode,
      signal: child.signalCode
    })
  return new Promise((resolve, reject) => {
    let forced = false
    const cleanup = () => {
      clearTimeout(killTimer)
      clearTimeout(totalTimer)
      child.removeListener('error', failed)
      child.removeListener('exit', exited)
    }
    const failed = () => {
      cleanup()
      reject(new Error('EXTERNAL_PROCESS_STOP_FAILED'))
    }
    const exited = (code, signal) => {
      const elapsedMs = performance.now() - started
      cleanup()
      if (elapsedMs > totalMs) {
        reject(new Error('EXTERNAL_STOP_DEADLINE_EXCEEDED'))
        return
      }
      resolve({
        status: forced ? 'contained_forced' : 'exited',
        graceful: !forced && code === 0 && signal === null,
        elapsedMs,
        exitCode: code,
        signal
      })
    }
    const killTimer = setTimeout(() => {
      forced = true
      try {
        child.kill('SIGKILL')
      } catch {
        failed()
      }
    }, graceMs)
    const totalTimer = setTimeout(() => {
      cleanup()
      reject(new Error('EXTERNAL_STOP_DEADLINE_EXCEEDED'))
    }, totalMs)
    child.once('error', failed)
    child.once('exit', exited)
    try {
      child.kill('SIGTERM')
    } catch {
      failed()
    }
  })
}

if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href
) {
  let child
  try {
    const bundle = path.resolve(process.argv[2] ?? '')
    if (
      !process.argv[2] ||
      !bundle.endsWith('.mjs') ||
      !fs.lstatSync(bundle).isFile() ||
      fs.realpathSync(bundle) !== bundle
    )
      throw new Error('EXPLICIT_PHYSICAL_NODE_BUNDLE_REQUIRED')
    child = spawn(process.execPath, [bundle], {
      stdio: 'inherit',
      env: process.env
    })
    let stopping = false
    const stop = async () => {
      if (stopping) return
      stopping = true
      try {
        const receipt = await stopChildWithin(child)
        console.log(JSON.stringify({ event: 'supervisor.stop', ...receipt }))
        process.exitCode = receipt.graceful ? 0 : 1
      } catch {
        console.error('EXTERNAL_SUPERVISOR_CONTAINMENT_FAILED')
        process.exitCode = 1
      }
    }
    process.once('SIGTERM', () => void stop())
    process.once('SIGINT', () => void stop())
    child.once('error', () => {
      console.error('NODE_CHILD_START_FAILED')
      process.exitCode = 1
    })
    child.once('exit', (code, signal) => {
      if (!stopping) process.exitCode = signal || code !== 0 ? 1 : 0
    })
  } catch {
    console.error('EXTERNAL_SUPERVISOR_FAILED_CLOSED')
    process.exitCode = 1
  }
}
