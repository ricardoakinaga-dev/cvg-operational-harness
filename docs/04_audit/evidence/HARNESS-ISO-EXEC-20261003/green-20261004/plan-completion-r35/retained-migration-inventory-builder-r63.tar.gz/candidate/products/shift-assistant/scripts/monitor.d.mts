export interface MonitorOptions {
  liveUrl: string
  readyUrl: string
  receiverUrl: string
  stateDirectory: string
  candidateDigest: string
  instanceOpaqueId: string
  pollIntervalMs?: number
  timeoutMs?: number
}
export interface AlertPayload {
  alertId: string
  product: 'shift-assistant'
  candidateDigest: string
  instanceOpaqueId: string
  reasonCode: string
  firstObservedAt: string
  observedAt: string
  severity: 'info' | 'warning'
  state: 'firing' | 'resolved'
}
export interface MonitorJob {
  payload: AlertPayload
  attempts: number
  dueAt: number
  status: 'queued' | 'receipted' | 'failed'
  receiptID?: string
}
export interface MonitorState {
  version: 1
  queue: MonitorJob[]
  episodes: Record<
    string,
    { failures: number; good: number; firstAt: number; alertId?: string }
  >
}
export class LocalSyntheticMonitor {
  constructor(options: MonitorOptions)
  tick(now?: number): Promise<void>
  snapshot(): MonitorState
  run(signal: AbortSignal): Promise<void>
  close(): Promise<void>
}
