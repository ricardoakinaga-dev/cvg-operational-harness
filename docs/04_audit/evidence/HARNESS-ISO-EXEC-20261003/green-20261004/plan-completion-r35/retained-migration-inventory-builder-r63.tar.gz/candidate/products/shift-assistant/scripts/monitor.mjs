import fs from 'node:fs'
import path from 'node:path'
import { randomUUID } from 'node:crypto'
import { pathToFileURL } from 'node:url'
import { setTimeout as delay } from 'node:timers/promises'

const REASONS = new Set([
  'storage_unavailable',
  'operational_hold',
  'stopping',
  'inhibited',
  'queue_full',
  'scheduler_stale',
  'job_deadline',
  'dispatch_deadline',
  'queue_stalled',
  'outbox_review',
  'processing_review',
  'dependency_unavailable',
  'delivery_overdue'
])
const RETRIES = [30000, 120000, 600000, 1800000]
const SAFE_CODES = new Set(
  [...REASONS]
    .map((x) => x.toUpperCase())
    .concat(['PROBE_UNAVAILABLE', 'READINESS_UNAVAILABLE', 'STATE_PAUSED'])
)
function localEndpoint(value, suffix) {
  const url = new URL(value)
  if (
    url.protocol !== 'http:' ||
    !['127.0.0.1', '[::1]'].includes(url.hostname) ||
    url.username ||
    url.password ||
    url.search ||
    url.hash ||
    !url.pathname.endsWith(suffix)
  )
    throw new Error('LOCAL_SYNTHETIC_ENDPOINT_REQUIRED')
  return url.href
}
function boundedInteger(value, fallback, min, max) {
  const selected = value ?? fallback
  if (!Number.isSafeInteger(selected) || selected < min || selected > max)
    throw new Error('INVALID_MONITOR_LIMIT')
  return selected
}
function fsync(file) {
  const fd = fs.openSync(file, 'r')
  try {
    fs.fsyncSync(fd)
  } finally {
    fs.closeSync(fd)
  }
}
function validPayload(p) {
  return (
    p &&
    Object.keys(p).sort().join(',') ===
      [
        'alertId',
        'candidateDigest',
        'firstObservedAt',
        'instanceOpaqueId',
        'observedAt',
        'product',
        'reasonCode',
        'severity',
        'state'
      ]
        .sort()
        .join(',') &&
    /^[a-f0-9-]{36}$/.test(p.alertId) &&
    /^[a-f0-9]{64}$/.test(p.candidateDigest) &&
    /^[a-f0-9-]{36}$/.test(p.instanceOpaqueId) &&
    p.product === 'shift-assistant' &&
    SAFE_CODES.has(p.reasonCode) &&
    ['warning', 'info'].includes(p.severity) &&
    ['firing', 'resolved'].includes(p.state) &&
    Number.isFinite(Date.parse(p.firstObservedAt)) &&
    Number.isFinite(Date.parse(p.observedAt))
  )
}
export class LocalSyntheticMonitor {
  #state
  #directory
  #lock
  #owner = randomUUID()
  #options
  #controllers = new Set()
  #work
  #closed = false
  constructor(options) {
    if (
      !/^[a-f0-9]{64}$/.test(options.candidateDigest) ||
      !/^[a-f0-9-]{36}$/.test(options.instanceOpaqueId)
    )
      throw new Error('OPAQUE_IDENTITY_REQUIRED')
    this.#options = {
      ...options,
      liveUrl: localEndpoint(options.liveUrl, '/health/live'),
      readyUrl: localEndpoint(options.readyUrl, '/health/ready'),
      receiverUrl: localEndpoint(options.receiverUrl, '/alerts'),
      pollIntervalMs: boundedInteger(options.pollIntervalMs, 10000, 1, 10000),
      timeoutMs: boundedInteger(options.timeoutMs, 2000, 1, 2000)
    }
    this.#directory = path.resolve(options.stateDirectory)
    const parent = path.dirname(this.#directory)
    if (
      !fs.lstatSync(parent).isDirectory() ||
      fs.realpathSync(parent) !== parent
    )
      throw new Error('PHYSICAL_MONITOR_DIRECTORY_REQUIRED')
    fs.mkdirSync(this.#directory, { recursive: true, mode: 0o700 })
    if (
      fs.lstatSync(this.#directory).isSymbolicLink() ||
      fs.realpathSync(this.#directory) !== this.#directory
    )
      throw new Error('PHYSICAL_MONITOR_DIRECTORY_REQUIRED')
    fs.chmodSync(this.#directory, 0o700)
    this.#lock = path.join(this.#directory, 'monitor.lock')
    fs.writeFileSync(this.#lock, this.#owner, { flag: 'wx', mode: 0o600 })
    try {
      fsync(this.#lock)
      const file = path.join(this.#directory, 'state.json')
      if (fs.existsSync(file) && fs.lstatSync(file).isSymbolicLink())
        throw new Error('MONITOR_STATE_SYMLINK_REFUSED')
      this.#state = fs.existsSync(file)
        ? JSON.parse(fs.readFileSync(file, 'utf8'))
        : {
            version: 1,
            candidateDigest: options.candidateDigest,
            instanceOpaqueId: options.instanceOpaqueId,
            episodes: {},
            queue: [],
            lastNewSend: {}
          }
      if (
        this.#state.version !== 1 ||
        this.#state.candidateDigest !== options.candidateDigest ||
        this.#state.instanceOpaqueId !== options.instanceOpaqueId ||
        !Array.isArray(this.#state.queue) ||
        !this.#state.episodes ||
        !this.#state.lastNewSend ||
        this.#state.queue.some(
          (job) =>
            !validPayload(job.payload) ||
            job.payload.candidateDigest !== options.candidateDigest ||
            job.payload.instanceOpaqueId !== options.instanceOpaqueId ||
            !Number.isSafeInteger(job.attempts) ||
            job.attempts < 0 ||
            job.attempts > 5 ||
            !Number.isFinite(job.dueAt) ||
            !['queued', 'receipted', 'failed'].includes(job.status)
        )
      )
        throw new Error('INVALID_DURABLE_MONITOR_STATE')
      for (const [code, episode] of Object.entries(this.#state.episodes))
        if (
          !SAFE_CODES.has(code) ||
          !episode ||
          !Number.isSafeInteger(episode.failures) ||
          !Number.isSafeInteger(episode.good) ||
          !Number.isFinite(episode.firstAt) ||
          (episode.alertId !== undefined &&
            !/^[a-f0-9-]{36}$/.test(episode.alertId))
        )
          throw new Error('INVALID_MONITOR_EPISODE')
      this.#persist()
    } catch (error) {
      if (fs.readFileSync(this.#lock, 'utf8') === this.#owner)
        fs.unlinkSync(this.#lock)
      throw error
    }
  }
  #persist() {
    const file = path.join(this.#directory, 'state.json'),
      temporary = path.join(this.#directory, 'state-' + randomUUID() + '.tmp')
    fs.writeFileSync(temporary, JSON.stringify(this.#state) + '\n', {
      flag: 'wx',
      mode: 0o600
    })
    fsync(temporary)
    fs.renameSync(temporary, file)
    fsync(this.#directory)
  }
  async #json(url, init = {}) {
    const controller = new AbortController()
    this.#controllers.add(controller)
    const timer = setTimeout(() => controller.abort(), this.#options.timeoutMs)
    let reader
    try {
      const response = await fetch(url, {
        ...init,
        signal: controller.signal,
        redirect: 'error'
      })
      reader = response.body?.getReader()
      const chunks = []
      let bytes = 0
      if (reader)
        for (;;) {
          const chunk = await reader.read()
          if (chunk.done) break
          bytes += chunk.value.byteLength
          if (bytes > 16384) throw new Error('MONITOR_RESPONSE_LIMIT')
          chunks.push(chunk.value)
        }
      const body = JSON.parse(
        new TextDecoder('utf-8', { fatal: true }).decode(Buffer.concat(chunks))
      )
      return { status: response.status, body }
    } finally {
      clearTimeout(timer)
      this.#controllers.delete(controller)
      if (reader) {
        try {
          await reader.cancel()
        } catch {
          /* Cancellation already performed by deadline/shutdown. */
        }
      }
    }
  }
  #enqueue(code, episode, state, now) {
    const payload = {
      alertId: episode.alertId,
      product: 'shift-assistant',
      candidateDigest: this.#options.candidateDigest,
      instanceOpaqueId: this.#options.instanceOpaqueId,
      reasonCode: code,
      firstObservedAt: new Date(episode.firstAt).toISOString(),
      observedAt: new Date(now).toISOString(),
      severity: code === 'STATE_PAUSED' ? 'info' : 'warning',
      state
    }
    this.#state.queue.push({
      payload,
      attempts: 0,
      dueAt: Math.max(now, (this.#state.lastNewSend[code] ?? 0) + 60000),
      status: 'queued'
    })
  }
  async #cycle(now) {
    const reasons = new Set()
    try {
      const [live, ready] = await Promise.all([
        this.#json(this.#options.liveUrl),
        this.#json(this.#options.readyUrl)
      ])
      if (live.status !== 200) reasons.add('PROBE_UNAVAILABLE')
      if (ready.status !== 200 && ready.status !== 503)
        reasons.add('READINESS_UNAVAILABLE')
      const codes = ready.body?.reasonCodes
      if (
        !Array.isArray(codes) ||
        codes.some((code) => typeof code !== 'string' || !REASONS.has(code))
      )
        reasons.add('READINESS_UNAVAILABLE')
      else for (const code of codes) reasons.add(code.toUpperCase())
      if (ready.status === 503 && reasons.size === 0)
        reasons.add('READINESS_UNAVAILABLE')
      if (ready.status === 200 && ready.body?.mode === 'paused')
        reasons.add('STATE_PAUSED')
    } catch {
      reasons.add('PROBE_UNAVAILABLE')
    }
    if (this.#closed) return
    for (const code of new Set([
      ...Object.keys(this.#state.episodes),
      ...reasons
    ])) {
      const episode = (this.#state.episodes[code] ??= {
        failures: 0,
        good: 0,
        firstAt: now
      })
      if (reasons.has(code)) {
        if (!episode.failures && !episode.alertId) episode.firstAt = now
        episode.failures += 1
        episode.good = 0
        if (episode.failures >= 2 && !episode.alertId) {
          episode.alertId = randomUUID()
          this.#enqueue(code, episode, 'firing', now)
        }
      } else {
        episode.failures = 0
        episode.good += 1
        if (episode.good >= 2) {
          if (episode.alertId) this.#enqueue(code, episode, 'resolved', now)
          delete this.#state.episodes[code]
        }
      }
    }
    this.#persist()
    for (const job of this.#state.queue) {
      if (this.#closed) break
      if (job.status !== 'queued' || job.dueAt > now) continue
      if (job.attempts >= 5) {
        job.status = 'failed'
        this.#persist()
        continue
      }
      if (
        job.attempts === 0 &&
        now < (this.#state.lastNewSend[job.payload.reasonCode] ?? 0) + 60000
      ) {
        job.dueAt = this.#state.lastNewSend[job.payload.reasonCode] + 60000
        this.#persist()
        continue
      }
      // A restart after send begins consumes this attempt; receipt absence never
      // fabricates success. Stable alertId/state allows an idempotent receiver.
      job.attempts += 1
      if (job.attempts === 1)
        this.#state.lastNewSend[job.payload.reasonCode] = now
      job.dueAt = now + (RETRIES[job.attempts - 1] ?? 1800000)
      this.#persist()
      try {
        const response = await this.#json(this.#options.receiverUrl, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify(job.payload)
        })
        if (
          response.status < 200 ||
          response.status >= 300 ||
          !/^[a-f0-9-]{36}$/.test(response.body?.receiptID)
        )
          throw new Error('VALID_ALERT_RECEIPT_REQUIRED')
        job.status = 'receipted'
        job.receiptID = response.body.receiptID
        job.receivedAt = new Date().toISOString()
      } catch {
        if (job.attempts >= 5) job.status = 'failed'
      }
      this.#persist()
    }
  }
  tick(now = Date.now()) {
    if (this.#closed) return Promise.reject(new Error('MONITOR_CLOSED'))
    if (!Number.isFinite(now) || now < 0)
      return Promise.reject(new Error('INVALID_MONITOR_CLOCK'))
    if (!this.#work)
      this.#work = this.#cycle(now).finally(() => {
        this.#work = undefined
      })
    return this.#work
  }
  snapshot() {
    return structuredClone(this.#state)
  }
  async run(signal) {
    while (!signal.aborted && !this.#closed) {
      const started = Date.now()
      await this.tick(started)
      try {
        await delay(
          Math.max(0, this.#options.pollIntervalMs - (Date.now() - started)),
          undefined,
          { signal }
        )
      } catch {
        if (!signal.aborted) throw new Error('MONITOR_DELAY_FAILED')
      }
    }
  }
  async close() {
    this.#closed = true
    for (const controller of this.#controllers) controller.abort()
    await this.#work
    if (
      fs.existsSync(this.#lock) &&
      fs.readFileSync(this.#lock, 'utf8') === this.#owner
    ) {
      fs.unlinkSync(this.#lock)
      fsync(this.#directory)
    }
  }
}
if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href
) {
  let monitor
  try {
    const file = process.argv[2]
    if (!file) throw new Error('EXPLICIT_SYNTHETIC_MONITOR_CONFIG_REQUIRED')
    monitor = new LocalSyntheticMonitor(
      JSON.parse(fs.readFileSync(file, 'utf8'))
    )
    const stop = new AbortController()
    for (const name of ['SIGTERM', 'SIGINT'])
      process.once(name, () => {
        stop.abort()
        void monitor.close()
      })
    await monitor.run(stop.signal)
  } catch {
    console.error('SYNTHETIC_MONITOR_FAILED_CLOSED')
    process.exitCode = 1
  } finally {
    await monitor?.close()
  }
}
