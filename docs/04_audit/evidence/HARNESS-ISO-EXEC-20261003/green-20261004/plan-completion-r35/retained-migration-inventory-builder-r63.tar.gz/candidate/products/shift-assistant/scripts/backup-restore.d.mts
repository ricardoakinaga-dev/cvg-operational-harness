export interface BackupReceipt {
  status: 'backup_verified' | 'restored_under_hold'
  manifestSha256: string
  documents: number
  originalsPreserved: true
  effectsEnabled?: false
}
export function backupStoppedVolume(
  source: string,
  destination: string
): Readonly<BackupReceipt>
export function restoreBackup(
  backup: string,
  destination: string
): Readonly<BackupReceipt>
