// @vitest-environment node
import { afterEach, describe, expect, it, vi } from 'vitest'
import { cp, mkdtemp, readFile, rm, writeFile, symlink } from 'node:fs/promises'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { ModelOrganizer } from '../organizer.ts'
import { validateOrganization } from '../source-evidence.ts'
import { OrganizedV2Schema, type OrganizedV2 } from '../domain.ts'
import { createSyntheticOpenAIRun } from '../synthetic/adapter.ts'
import {
  DEFAULT_CORPUS_DIRECTORY,
  fixtureBinding,
  loadSyntheticCorpus,
  sha256
} from '../synthetic/corpus.ts'
import { CORPUS_SHA256, SYNTHETIC_FIXTURES } from '../synthetic/manifest.ts'
import {
  authorizeSyntheticPacket,
  MAX_SYNTHETIC_REQUEST_BYTES,
  prepareSyntheticPacket,
  SYNTHETIC_PROMPT,
  SYNTHETIC_PROMPT_SHA256
} from '../synthetic/packet.ts'
import {
  runSyntheticOpenAIPacket,
  runSyntheticOpenAIMock
} from '../synthetic/runner.ts'
import type { FetchLike } from '@cvg/model-gateway'

const MOCK_MODEL = 'gpt-6-luna'
const outputRoot = tmpdir()
const folders: string[] = []
afterEach(async () => {
  vi.restoreAllMocks()
  await Promise.all(
    folders.splice(0).map((p) => rm(p, { recursive: true, force: true }))
  )
})
const empty: OrganizedV2 = {
  schemaVersion: 2,
  pacientes: [],
  pendencias: [],
  duvidas: [],
  evidence: []
}
const binding = fixtureBinding('SYN-REL-02')
// DNS is injected as well as HTTP; none of these tests resolve a real hostname.
const dnsLookup = vi.fn(async () => ['93.184.216.34'])
function envelope(text: string, tokens = 100) {
  return new Response(
    JSON.stringify({
      choices: [{ message: { content: text }, finish_reason: 'stop' }],
      usage: { prompt_tokens: 200, completion_tokens: tokens }
    }),
    { status: 200 }
  )
}
async function mockRun(
  transport: FetchLike = async () => envelope(JSON.stringify(empty)),
  ids = [binding.fixtureId],
  corpusDirectory?: string,
  timeoutMs?: number
) {
  return createSyntheticOpenAIRun({
    mode: 'mock',
    model: MOCK_MODEL,
    fixtureBindings: ids.map(fixtureBinding),
    transport,
    dnsLookup,
    ...(corpusDirectory ? { corpusDirectory } : {}),
    ...(timeoutMs ? { timeoutMs } : {})
  })
}
async function copyCorpus() {
  const directory = await mkdtemp(join(outputRoot, 'corpus-'))
  folders.push(directory)
  await cp(DEFAULT_CORPUS_DIRECTORY, directory, { recursive: true })
  return directory
}
function receipt(packetSha256: string) {
  return {
    decision: 'AUTHORIZE_SYNTHETIC_EXTERNAL_EXECUTION',
    packetSha256,
    humanId: 'unit-test-human',
    evidenceRef: 'unit-test-receipt-not-real-authorization',
    recordedAtUtc: '2026-10-04T12:00:00Z',
    executionId: 'unit-test-run'
  }
}
async function fixtureResponse(): Promise<OrganizedV2> {
  const data = JSON.parse(
    await readFile(join(DEFAULT_CORPUS_DIRECTORY, 'cases/case02.json'), 'utf8')
  )
  const v1 = data.expectedOutput.organizedV1
  return OrganizedV2Schema.parse({
    schemaVersion: 2,
    pacientes: v1.pacientes.map((p: object, i: number) => ({
      ...p,
      localRef: `p${i + 1}`
    })),
    pendencias: [],
    duvidas: v1.duvidas,
    evidence: data.expectedOutput.sourceFields.map(
      (e: { field: string; quote: string }) => ({
        path: e.field.replace('pacientes[0]', 'pacientes.p1'),
        patientRef: 'p1',
        quote: e.quote
      })
    )
  })
}

describe('fixed synthetic corpus authority', () => {
  it('binds exactly the existing 20 primary texts and original file hashes', async () => {
    const corpus = await loadSyntheticCorpus()
    expect(SYNTHETIC_FIXTURES).toHaveLength(20)
    for (const entry of SYNTHETIC_FIXTURES) {
      const fixed = corpus.get(fixtureBinding(entry.id))
      expect(sha256(fixed.rawText)).toBe(entry.textSha256)
      expect(fixed.corpusSha256).toBe(CORPUS_SHA256)
    }
  })
  it('rejects unknown fixture, missing manifest, incoming hash and wrong identity', async () => {
    expect(() => fixtureBinding('arbitrary')).toThrow()
    const run = await mockRun()
    for (const value of [
      undefined,
      { fixtureId: binding.fixtureId },
      { ...binding, textSha256: '0'.repeat(64) },
      { ...binding, corpusSha256: '0'.repeat(64) },
      { ...binding, fixtureId: 'SYN-REL-01' },
      { ...binding, synthetic: true }
    ])
      expect(() => run.organizerFor(value)).toThrow()
  })
  it.each([
    'real patient text',
    'SYN-Unknown ID SYN-X',
    'Treinamento inteiramente fictício.',
    ''
  ])('rejects unknown/free text %j without transport', async (text) => {
    const transport = vi.fn(async () => envelope(JSON.stringify(empty)))
    const run = await mockRun(transport)
    await expect(
      run.organizerFor(binding).organize(text, new Date('2026-10-03T17:00:00Z'))
    ).rejects.toMatchObject({ code: 'policy_denied' })
    expect(transport).not.toHaveBeenCalled()
  })
  it('rejects valid text with an unbound id, changed text/hash or changed clock', async () => {
    const transport = vi.fn(async () => envelope(JSON.stringify(empty)))
    const corpus = await loadSyntheticCorpus()
    const fixed = corpus.get(binding)
    const run = await mockRun(transport)
    expect(() => run.organizerFor(fixtureBinding('SYN-REL-01'))).toThrow()
    await expect(
      run
        .organizerFor(binding)
        .organize(fixed.rawText + ' ', new Date(fixed.clockInstant))
    ).rejects.toThrow()
    await expect(
      run.organizerFor(binding).organize(fixed.rawText, new Date())
    ).rejects.toThrow()
    expect(transport).not.toHaveBeenCalled()
  })
  it('rejects a missing corpus and oversized incoming text before transport', async () => {
    const directory = await mkdtemp(join(outputRoot, 'missing-corpus-'))
    folders.push(directory)
    const transport = vi.fn(async () => envelope(JSON.stringify(empty)))
    await expect(
      mockRun(transport, [binding.fixtureId], directory)
    ).rejects.toThrow()
    const run = await mockRun(transport)
    await expect(
      run.organizerFor(binding).organize('x'.repeat(100_000), new Date())
    ).rejects.toMatchObject({ code: 'policy_denied' })
    expect(transport).not.toHaveBeenCalled()
  })
  it.each([
    'manifest',
    'selected case',
    'unselected case',
    'audio',
    'inventory',
    'missing',
    'symlink'
  ])('rejects corpus tamper: %s', async (kind) => {
    const directory = await copyCorpus()
    if (kind === 'inventory')
      await writeFile(join(directory, 'extra.txt'), 'unapproved')
    else if (kind === 'missing') await rm(join(directory, 'cases/case01.json'))
    else if (kind === 'symlink') {
      await rm(join(directory, 'cases/case01.json'))
      await symlink(
        join(DEFAULT_CORPUS_DIRECTORY, 'cases/case01.json'),
        join(directory, 'cases/case01.json')
      )
    } else {
      const file =
        kind === 'manifest'
          ? 'corpus-manifest.json'
          : kind === 'selected case'
            ? 'cases/case02.json'
            : kind === 'audio'
              ? 'audio/audio01.txt'
              : 'cases/case01.json'
      await writeFile(
        join(directory, file),
        (await readFile(join(directory, file))).toString() + ' '
      )
    }
    const transport = vi.fn(async () => envelope(JSON.stringify(empty)))
    await expect(
      mockRun(transport, [binding.fixtureId], directory)
    ).rejects.toMatchObject({ code: 'policy_denied' })
    expect(transport).not.toHaveBeenCalled()
  })
  it('rejects file tamper after creation, before provider call', async () => {
    const directory = await copyCorpus()
    const transport = vi.fn(async () => envelope(JSON.stringify(empty)))
    const run = await mockRun(transport, [binding.fixtureId], directory)
    await writeFile(join(directory, 'cases/case02.json'), '{}')
    await expect(run.organizeFixture(binding)).rejects.toMatchObject({
      code: 'policy_denied',
      retryable: false
    })
    expect(transport).not.toHaveBeenCalled()
  })
  it('does not grant the production ModelOrganizer a direct provider call', async () => {
    const execute = vi.fn()
    const corpus = await loadSyntheticCorpus()
    const organizer = new ModelOrganizer({
      id: 'mock',
      location: 'external',
      models: [MOCK_MODEL],
      execute
    })
    await expect(
      organizer.organize(corpus.get(binding).rawText, new Date())
    ).rejects.toMatchObject({ code: 'policy_denied' })
    await expect(
      organizer.organize('unknown clinical text', new Date())
    ).rejects.toMatchObject({ code: 'policy_denied' })
    expect(execute).not.toHaveBeenCalled()
  })
})

describe('frozen packet and explicit external runner gates', () => {
  it('prepares a packet without HTTP and requires the exact human receipt', async () => {
    const fetchSpy = vi
      .spyOn(globalThis, 'fetch')
      .mockRejectedValue(new Error('Network forbidden'))
    const prepared = await prepareSyntheticPacket([binding], MOCK_MODEL)
    expect(sha256(prepared.packetBytes)).toBe(prepared.packetSha256)
    await expect(
      authorizeSyntheticPacket(prepared.packetBytes, undefined)
    ).rejects.toThrow()
    await expect(
      authorizeSyntheticPacket(prepared.packetBytes, receipt('0'.repeat(64)))
    ).rejects.toThrow()
    await expect(
      authorizeSyntheticPacket(
        prepared.packetBytes + ' ',
        receipt(prepared.packetSha256)
      )
    ).rejects.toThrow()
    const packet = await authorizeSyntheticPacket(
      prepared.packetBytes,
      receipt(prepared.packetSha256)
    )
    expect(packet.fixtureBindings).toEqual([binding])
    expect(fetchSpy).not.toHaveBeenCalled()
  })
  it.each([
    'promptSha256',
    'corpusSha256',
    'bundleSha256',
    'maxCalls',
    'maxOutputTokens',
    'retries',
    'baseUrl'
  ])(
    'rejects packet change even with matching receipt hash: %s',
    async (field) => {
      const prepared = await prepareSyntheticPacket([binding], MOCK_MODEL)
      const packet = JSON.parse(prepared.packetBytes)
      packet[field] =
        typeof packet[field] === 'number' ? packet[field] + 1 : '0'.repeat(64)
      const bytes = JSON.stringify(packet)
      await expect(
        authorizeSyntheticPacket(bytes, receipt(sha256(bytes)))
      ).rejects.toThrow()
    }
  )
  it('rejects unknown text binding, duplicate and >20 fixture packets', async () => {
    await expect(
      prepareSyntheticPacket(
        [{ ...binding, textSha256: '0'.repeat(64) }],
        MOCK_MODEL
      )
    ).rejects.toThrow()
    await expect(
      prepareSyntheticPacket([binding, binding], MOCK_MODEL)
    ).rejects.toThrow()
    await expect(
      prepareSyntheticPacket(
        Array.from({ length: 21 }, () => binding),
        MOCK_MODEL
      )
    ).rejects.toThrow()
  })
  it('binds the explicitly configured model to the exact packet receipt', async () => {
    const fetchSpy = vi
      .spyOn(globalThis, 'fetch')
      .mockRejectedValue(new Error('Network forbidden'))
    const prepared = await prepareSyntheticPacket(
      [binding],
      'synthetic-other-model'
    )
    const approved = receipt(prepared.packetSha256)
    const packet = await authorizeSyntheticPacket(
      prepared.packetBytes,
      approved
    )
    expect(packet.model).toBe('synthetic-other-model')
    const modified = JSON.parse(prepared.packetBytes)
    modified.model = MOCK_MODEL
    await expect(
      authorizeSyntheticPacket(JSON.stringify(modified), approved)
    ).rejects.toThrow()
    // Creating the external factory does not send a request. The identifier
    // remains an explicit operator decision, pending the Lead's API check.
    await createSyntheticOpenAIRun({
      mode: 'external',
      packetBytes: prepared.packetBytes,
      humanExecutionReceipt: approved,
      apiKey: 'unit-test-placeholder-only'
    })
    expect(fetchSpy).not.toHaveBeenCalled()
    for (const model of [
      '',
      'bad model',
      'https://unapproved/model',
      'x'.repeat(121)
    ])
      await expect(prepareSyntheticPacket([binding], model)).rejects.toThrow()
  })
  it('rejects absent/blank credential and absent receipt before any network', async () => {
    const fetchSpy = vi
      .spyOn(globalThis, 'fetch')
      .mockRejectedValue(new Error('Network forbidden'))
    const prepared = await prepareSyntheticPacket([binding], MOCK_MODEL)
    for (const apiKey of ['', ' ', 'bad\nkey']) {
      await expect(
        runSyntheticOpenAIPacket({
          ...prepared,
          humanExecutionReceipt: receipt(prepared.packetSha256),
          apiKey
        })
      ).rejects.toMatchObject({ code: 'provider_auth_failed' })
    }
    await expect(
      runSyntheticOpenAIPacket({
        ...prepared,
        humanExecutionReceipt: undefined,
        apiKey: 'mock-only'
      })
    ).rejects.toThrow()
    expect(fetchSpy).not.toHaveBeenCalled()
  })
  it('does not let extra caller properties downgrade the external runner to mock mode', async () => {
    const prepared = await prepareSyntheticPacket([binding], MOCK_MODEL)
    const transport = vi.fn(async () => envelope(JSON.stringify(empty)))
    const options = {
      ...prepared,
      humanExecutionReceipt: receipt(prepared.packetSha256),
      apiKey: '',
      mode: 'mock',
      model: MOCK_MODEL,
      fixtureBindings: [binding],
      transport,
      dnsLookup
    }
    await expect(runSyntheticOpenAIPacket(options)).rejects.toMatchObject({
      code: 'provider_auth_failed'
    })
    expect(transport).not.toHaveBeenCalled()
  })
})

describe('public OpenAI transport with no actions or retries', () => {
  it('blocks schema-valid output with source issues and stops the mocked runner', async () => {
    const response = await fixtureResponse()
    const transport = vi.fn(async () => envelope(JSON.stringify(response)))
    const result = await runSyntheticOpenAIMock({
      model: MOCK_MODEL,
      fixtureBindings: [binding, fixtureBinding('SYN-REL-01')],
      transport,
      dnsLookup
    })
    expect(result.status).toBe('source_blocked')
    expect(result.qualification).toBe('FAILED')
    expect(result.results).toEqual([])
    if (result.status !== 'source_blocked')
      throw new Error('Expected source block')
    expect(result.blocked.sourceValidation.issues.length).toBeGreaterThan(0)
    expect(result.evidence[0]!.status).toBe('source_blocked')
    expect(result.evidence[0]!.code).toBe('source_invalid')
    expect(result.evidence[0]).toMatchObject({
      qualification: 'FAILED',
      blockingCount: result.blocked.sourceValidation.issues.length,
      warningCount: response.duvidas.length
    })
    const persisted = JSON.stringify({
      qualification: result.qualification,
      evidence: result.evidence
    })
    expect(persisted).not.toContain('quote')
    expect(persisted).not.toContain('SYN-B02')
    expect(transport).toHaveBeenCalledTimes(1)
  })
  it('stops a runner on the first quota failure and returns sanitized failure evidence', async () => {
    const transport = vi.fn(
      async () => new Response('do not log auth headers', { status: 429 })
    )
    const result = await runSyntheticOpenAIMock({
      model: MOCK_MODEL,
      fixtureBindings: [binding, fixtureBinding('SYN-REL-01')],
      transport,
      dnsLookup
    })
    expect(result).toMatchObject({
      status: 'failed',
      code: 'provider_rate_limited',
      results: []
    })
    expect(result.evidence).toHaveLength(1)
    expect(result.evidence[0]).toMatchObject({
      fixtureId: binding.fixtureId,
      httpStatus: 429,
      status: 'failed'
    })
    expect(transport).toHaveBeenCalledTimes(1)
    expect(JSON.stringify(result.evidence)).not.toContain('auth headers')
  })
  it('does not qualify unresolved model questions', async () => {
    const transport = vi.fn(async () =>
      envelope(
        JSON.stringify({ ...empty, duvidas: ['Unresolved synthetic identity'] })
      )
    )
    const result = await runSyntheticOpenAIMock({
      model: MOCK_MODEL,
      fixtureBindings: [binding],
      transport,
      dnsLookup
    })
    expect(result).toMatchObject({
      status: 'source_blocked',
      qualification: 'FAILED',
      results: []
    })
    expect(result.evidence[0]).toMatchObject({
      qualification: 'FAILED',
      blockingCount: 0,
      warningCount: 1
    })
    expect(JSON.stringify(result.evidence)).not.toContain('Unresolved')
  })
  it('uses fixed prompt/model, bounded request/tokens and preserves V2 IDs/numbers/quotes', async () => {
    const response = await fixtureResponse()
    const transport = vi.fn(async (url: string, init: RequestInit) => {
      expect(url).toBe('https://api.openai.com/v1/chat/completions')
      expect(init.redirect).toBe('manual')
      expect(Buffer.byteLength(String(init.body))).toBeLessThanOrEqual(
        MAX_SYNTHETIC_REQUEST_BYTES
      )
      const body = JSON.parse(String(init.body))
      expect(body.model).toBe(MOCK_MODEL)
      expect(body.messages[0]).toEqual({
        role: 'system',
        content: SYNTHETIC_PROMPT
      })
      expect(sha256(body.messages[0].content)).toBe(SYNTHETIC_PROMPT_SHA256)
      const tokenLimit = body.max_completion_tokens ?? body.max_tokens
      expect(tokenLimit).toBe(2048)
      expect(tokenLimit).toBeLessThanOrEqual(2048)
      expect(body.max_completion_tokens).toBe(2048)
      expect(body.max_tokens).toBeUndefined()
      expect(body.reasoning_effort).toBe('none')
      expect(body.store).toBe(false)
      expect(body.tools).toBeUndefined()
      expect(body.stream).toBe(false)
      expect(body.response_format).toEqual({ type: 'json_object' })
      return envelope(JSON.stringify(response))
    })
    const fetchSpy = vi
      .spyOn(globalThis, 'fetch')
      .mockRejectedValue(new Error('Network forbidden'))
    const run = await mockRun(transport)
    expect(transport).not.toHaveBeenCalled()
    const organized = await run.organizeFixture(binding)
    expect(organized).toEqual(response)
    expect(organized.pacientes[0]!.id).toBe('SYN-B02')
    expect(organized.pacientes[0]!.evolucao).toContain('1,0 mL às 13:45')
    expect(organized.evidence).toEqual(response.evidence)
    const fixed = (await loadSyntheticCorpus()).get(binding)
    // Existing legacy SYN fixtures do not imply clinical qualification. The
    // unmodified consumer validator retains its blocking provenance decisions.
    expect(
      validateOrganization(fixed.rawText, organized).issues.length
    ).toBeGreaterThan(0)
    expect(transport).toHaveBeenCalledTimes(1)
    expect(fetchSpy).not.toHaveBeenCalled()
    expect(run.evidence()).toEqual([
      {
        fixtureId: binding.fixtureId,
        inputSha256: binding.textSha256,
        outputSha256: sha256(JSON.stringify(response)),
        status: 'validated_v2',
        inputTokens: 200,
        outputTokens: 100
      }
    ])
    expect(JSON.stringify(run.evidence())).not.toContain('Bearer')
    expect(JSON.stringify(run.evidence())).not.toContain('synthetic-mock-only')
  })
  it('permits at most one attempt per fixed fixture and 20 calls per run', async () => {
    const transport = vi.fn(async () => envelope(JSON.stringify(empty)))
    const run = await mockRun(
      transport,
      SYNTHETIC_FIXTURES.map((e) => e.id)
    )
    for (const entry of SYNTHETIC_FIXTURES)
      await run.organizeFixture(fixtureBinding(entry.id))
    await expect(run.organizeFixture(binding)).rejects.toMatchObject({
      code: 'policy_denied'
    })
    expect(transport).toHaveBeenCalledTimes(20)
  })
  it.each([
    [401, 'provider_auth_failed'],
    [403, 'provider_auth_failed'],
    [429, 'provider_rate_limited'],
    [500, 'provider_unavailable'],
    [503, 'provider_unavailable'],
    [400, 'provider_invalid_request']
  ])(
    'maps HTTP %i, sanitizes errors and never retries',
    async (status, code) => {
      const transport = vi.fn(
        async () =>
          new Response('secret or header must never be logged', {
            status: Number(status)
          })
      )
      const run = await mockRun(transport)
      await expect(run.organizeFixture(binding)).rejects.toMatchObject({
        code,
        retryable: false,
        status
      })
      await expect(run.organizeFixture(binding)).rejects.toMatchObject({
        code: 'policy_denied'
      })
      expect(transport).toHaveBeenCalledTimes(1)
      expect(run.evidence()[0]).toMatchObject({
        status: 'failed',
        code,
        httpStatus: status
      })
      expect(JSON.stringify(run.evidence())).not.toContain('secret')
    }
  )
  it.each([
    'invalid provider JSON',
    'invalid provider schema',
    'invalid organized JSON',
    'V1 schema',
    'extra schema field',
    'invalid evidence',
    'duplicate refs',
    'response too large',
    'output tokens'
  ])('fails closed: %s', async (kind) => {
    const transport = vi.fn(async () => {
      if (kind === 'invalid provider JSON') return new Response('{')
      if (kind === 'invalid provider schema') return new Response('{}')
      if (kind === 'response too large')
        return new Response('x'.repeat(256 * 1024 + 1))
      if (kind === 'output tokens') return envelope(JSON.stringify(empty), 2049)
      let candidate: unknown =
        kind === 'invalid organized JSON' ? '{' : JSON.stringify(empty)
      if (kind === 'V1 schema')
        candidate = JSON.stringify({
          pacientes: [],
          pendencias: [],
          duvidas: []
        })
      if (kind === 'extra schema field')
        candidate = JSON.stringify({ ...empty, actions: ['execute'] })
      if (kind === 'invalid evidence')
        candidate = JSON.stringify({
          ...empty,
          evidence: [{ path: 'id', patientRef: 'p999', quote: 'x' }]
        })
      if (kind === 'duplicate refs') {
        const patient = (await fixtureResponse()).pacientes[0]!
        candidate = JSON.stringify({ ...empty, pacientes: [patient, patient] })
      }
      return envelope(String(candidate))
    })
    const run = await mockRun(transport)
    await expect(run.organizeFixture(binding)).rejects.toMatchObject({
      retryable: false
    })
    expect(transport).toHaveBeenCalledTimes(1)
    expect(run.evidence()[0]!.status).toBe('failed')
  })
  it('rejects pre-aborted input without transport', async () => {
    const transport = vi.fn(async () => envelope(JSON.stringify(empty)))
    const run = await mockRun(transport)
    await expect(
      run.organizeFixture(binding, AbortSignal.abort())
    ).rejects.toMatchObject({ code: 'cancelled' })
    expect(transport).not.toHaveBeenCalled()
  })
  it.each(['cancel', 'timeout'])(
    'preserves public provider %s behavior',
    async (kind) => {
      const controller = new AbortController()
      const transport = vi.fn(
        async (_url: string, init: RequestInit) =>
          new Promise<Response>((_resolve, reject) => {
            const signal = init.signal!
            signal.addEventListener('abort', () => reject(signal.reason), {
              once: true
            })
            if (kind === 'cancel') controller.abort()
          })
      )
      const run = await mockRun(transport, [binding.fixtureId], undefined, 25)
      await expect(
        run.organizeFixture(binding, controller.signal)
      ).rejects.toMatchObject({
        code: kind === 'cancel' ? 'cancelled' : 'provider_timeout',
        retryable: false
      })
      expect(transport).toHaveBeenCalledTimes(1)
    }
  )
  it('preserves SSRF rejection with no HTTP', async () => {
    const transport = vi.fn(async () => envelope(JSON.stringify(empty)))
    const run = await createSyntheticOpenAIRun({
      mode: 'mock',
      model: MOCK_MODEL,
      fixtureBindings: [binding],
      transport,
      dnsLookup: async () => ['127.0.0.1']
    })
    await expect(run.organizeFixture(binding)).rejects.toMatchObject({
      code: 'provider_invalid_request'
    })
    expect(transport).not.toHaveBeenCalled()
  })
})
