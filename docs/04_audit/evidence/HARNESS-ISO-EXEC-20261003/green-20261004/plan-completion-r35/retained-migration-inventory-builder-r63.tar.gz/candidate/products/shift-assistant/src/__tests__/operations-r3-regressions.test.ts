// @vitest-environment node
import * as fs from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, expect, it, vi } from 'vitest'
import {
  FileCostBudgetStore,
  ModelGateway,
  PromptRegistry,
  computePromptSha256
} from '@cvg/model-gateway'
import { composeShiftApp, type ShiftApp } from '../compose.ts'
import { loadShiftConfig, type ApprovedModelHostConfig } from '../config.ts'
import { ORGANIZER_PROMPT } from '../organizer.ts'
import { ShiftStore } from '../store.ts'
import { recordSimulatedDelivery } from '../delivery-receipts.ts'
const ANA = '5511900000001',
  MAN = '5511900000009',
  NOW = new Date('2026-10-04T12:00:00Z'),
  TENANT = 'tenant_00000000-0000-4000-8000-000000000001'
const cleanup: Array<() => void | Promise<void>> = []
afterEach(async () => {
  vi.restoreAllMocks()
  for (const f of cleanup.splice(0).reverse()) await f()
})
function directory() {
  const d = fs.mkdtempSync(join(tmpdir(), 'ops-r3-'))
  cleanup.push(() => fs.rmSync(d, { recursive: true, force: true }))
  return d
}
function config(d: string) {
  return loadShiftConfig({
    SHIFT_PROVIDER: 'waha',
    SHIFT_MEMBERS: `${ANA}=Ana;${MAN}=Manager*`,
    SHIFT_WEBHOOK_SECRET: 'ops-r3-synthetic-webhook',
    SHIFT_DELIVERY_SIMULATION_SECRET: 'ops-r3-synthetic-delivery',
    SHIFT_DATA_DIR: join(d, 'clinical'),
    SHIFT_HOST: '127.0.0.1',
    SHIFT_PORT: '0',
    WAHA_URL: 'http://127.0.0.1:1',
    WAHA_API_KEY: 'synthetic',
    WAHA_SESSION: 'ops-r3',
    WHISPER_URL: 'http://127.0.0.1:2',
    LLM_BASE_URL: 'http://127.0.0.1:3',
    LLM_LOCATION: 'local',
    LLM_MODEL: 'synthetic'
  })
}
function model(d: string) {
  let fault = false,
    providerCalls = 0
  const ledger = new FileCostBudgetStore({
    directory: join(d, 'costs'),
    io: {
      fsyncSync(fd) {
        if (fault) throw new Error('OPS_R3_COST_FSYNC')
        fs.fsyncSync(fd)
      }
    }
  })
  cleanup.push(() => ledger.close())
  const prompts = new PromptRegistry()
  const prompt = prompts.register({
    tenantId: TENANT,
    promptId: 'shift-note',
    version: '1',
    content: ORGANIZER_PROMPT,
    classification: 'CLINICAL',
    owner: 'ops-r3',
    approvedBy: 'synthetic',
    status: 'approved',
    effectiveFrom: '2026-01-01T00:00:00Z'
  })
  const provider = {
    id: 'ops-r3',
    models: ['synthetic'],
    location: 'local' as const,
    async execute() {
      providerCalls++
      throw new Error('CLINICAL_MUST_NOT_RUN')
    }
  }
  const gateway = new ModelGateway({
    providers: [provider],
    prompts,
    profiles: {
      local: {
        name: 'local',
        providerId: provider.id,
        model: 'synthetic',
        location: 'local',
        temperature: 0,
        maxTokens: 1500,
        timeoutMs: 1000,
        maxCostUsd: 1,
        estimatedCostUsd: 0.5,
        maxRetries: 0,
        pricing: { inputPer1kUsd: 0.1, outputPer1kUsd: 0.2 }
      }
    },
    routing: { allowFallback: false, allowLocalSubstitution: false },
    budget: { store: ledger, limits: { request: 1, day: 1 } },
    clock: () => NOW
  })
  return {
    ledger,
    gateway,
    provider,
    providerCalls: () => providerCalls,
    fail() {
      fault = true
      expect(() => ledger.consume('request:ops-r3-fault', 0.1)).toThrow()
    },
    options: {
      gateway,
      tenantId: TENANT,
      prompt: {
        promptId: prompt.promptId,
        version: prompt.version,
        sha256: prompt.sha256
      },
      profile: 'local' as const
    }
  }
}
function app(d: string, options: Parameters<typeof composeShiftApp>[1] = {}) {
  const a = composeShiftApp(config(d), { clock: () => NOW, ...options })
  cleanup.push(() => a.stop())
  return a
}
async function say(a: ShiftApp, id: string, text: string, phone = ANA) {
  a.assistant.receive({
    provider: 'waha',
    messageId: id,
    fromPhone: phone,
    kind: 'text',
    text,
    receivedAt: NOW.toISOString()
  })
  await a.assistant.idle()
}
async function until(f: () => boolean) {
  for (let i = 0; i < 200 && !f(); i++)
    await new Promise((r) => setTimeout(r, 5))
  expect(f()).toBe(true)
}
function documents(d: string, rel = ''): Record<string, string> {
  const r: Record<string, string> = {}
  for (const n of fs.readdirSync(join(d, rel))) {
    const p = rel ? rel + '/' + n : n
    if (p === 'store.lock') continue
    const s = fs.lstatSync(join(d, p))
    if (s.isDirectory()) Object.assign(r, documents(d, p))
    else r[p] = fs.readFileSync(join(d, p)).toString('hex')
  }
  return r
}
it('budget fault stops command/audio/tick without any health poll; durable hold survives healthy gateway restart and manager resume', async () => {
  const d = directory(),
    m = model(d)
  let sends = 0
  let a = app(d, {
    organizerGateway: m.options,
    fetchImpl: async () => {
      sends++
      return new Response(JSON.stringify({ id: 'positive-' + sends }), {
        status: 201
      })
    }
  })
  await say(a, 'healthy', 'ajuda')
  expect(sends).toBe(1)
  m.fail()
  await say(a, 'fault', 'ajuda')
  a.assistant.receive({
    provider: 'waha',
    messageId: 'audio',
    fromPhone: ANA,
    kind: 'audio',
    text: '',
    mediaRef: 'http://127.0.0.1:1/media',
    mimetype: 'audio/ogg',
    receivedAt: NOW.toISOString()
  })
  await a.assistant.idle()
  await a.assistant.tick()
  expect(sends).toBe(1)
  expect(a.store.operationalHold).toBe(true)
  expect(a.store.effectsAllowed).toBe(false)
  const marker = fs.readFileSync(join(d, 'clinical/budget-hold.json'))
  expect(JSON.parse(marker.toString())).toMatchObject({
    reason: 'budget_store_unavailable',
    reconciliationRequired: true
  })
  for (let i = 0; i < 3; i++) a.assistant.health()
  expect(fs.readFileSync(join(d, 'clinical/budget-hold.json'))).toEqual(marker)
  expect(m.providerCalls()).toBe(0)
  await a.stop()
  const healthy = model(directory())
  a = app(d, {
    organizerGateway: healthy.options,
    fetchImpl: async () => {
      sends++
      throw new Error('NO_RESTART_SEND')
    }
  })
  await a.start()
  await say(a, 'resume', 'retomar assistente', MAN)
  await a.assistant.tick()
  expect(a.store.operationalHold).toBe(true)
  expect(sends).toBe(1)
  expect(a.store.outboxes().filter((b) => b.state === 'dispatching')).toEqual(
    []
  )
})
it('budget fault cancels a held send without health polling, marks it uncertain, and never retries after restart', async () => {
  const d = directory(),
    m = model(d)
  let signal: AbortSignal | undefined,
    calls = 0
  const a = app(d, {
    organizerGateway: m.options,
    fetchImpl: async (_url, init) => {
      calls++
      signal = init?.signal as AbortSignal
      return await new Promise<Response>(() => {})
    }
  })
  a.assistant.receive({
    provider: 'waha',
    messageId: 'held',
    fromPhone: ANA,
    kind: 'text',
    text: 'ajuda',
    receivedAt: NOW.toISOString()
  })
  await until(() => !!signal)
  m.fail()
  await until(() => !!signal?.aborted)
  await a.assistant.idle()
  expect(a.store.outboxes()[0]!.state).toBe('uncertain')
  expect(a.store.operationalHold).toBe(true)
  await a.stop()
  const next = app(d, {
    fetchImpl: async () => {
      calls++
      throw new Error('NO_RESEND')
    }
  })
  await next.start()
  await next.assistant.tick()
  expect(calls).toBe(1)
  expect(next.store.outboxes()[0]!.state).toBe('uncertain')
})
it('hold persistence fsync failure retains a reconciliation lock and marker, never enabling effects', () => {
  const d = directory(),
    p = join(d, 'clinical')
  let fault = false,
    syncCalls = 0
  const store = new ShiftStore(p, {
    io: {
      sync(fd) {
        syncCalls++
        if (fault) throw new Error('OPS_R3_HOLD_FSYNC')
        fs.fsyncSync(fd)
      }
    }
  })
  cleanup.push(() => store.close())
  const before = syncCalls
  fault = true
  expect(() => store.holdBudget(NOW.toISOString())).toThrow(
    'STORAGE_UNAVAILABLE'
  )
  expect(syncCalls).toBeGreaterThan(before)
  expect(store.effectsAllowed).toBe(false)
  expect(store.storageAvailable).toBe(false)
  expect(fs.existsSync(join(p, 'budget-hold.json'))).toBe(true)
  const marker = fs.readFileSync(join(p, 'budget-hold.json'))
  store.holdBudget(NOW.toISOString())
  expect(fs.readFileSync(join(p, 'budget-hold.json'))).toEqual(marker)
  store.close()
  const lock = fs.readFileSync(join(p, 'store.lock'))
  expect(() => new ShiftStore(p)).toThrow('STORE_LOCKED')
  expect(fs.readFileSync(join(p, 'store.lock'))).toEqual(lock)
})
it('modelHost fault also holds effects before dispatch and leaves clinical provider untouched', async () => {
  const d = directory(),
    m = model(directory())
  const host: ApprovedModelHostConfig = {
    tenantId: TENANT,
    costDirectory: join(d, 'host-costs'),
    authority: 'synthetic-fixture',
    prompt: {
      promptId: 'shift-note',
      version: '1',
      content: ORGANIZER_PROMPT,
      sha256: computePromptSha256(ORGANIZER_PROMPT),
      owner: 'ops-r3',
      approvedBy: 'synthetic',
      status: 'approved',
      effectiveFrom: '2026-01-01T00:00:00Z',
      classification: 'CLINICAL'
    },
    pricing: {
      inputPer1kUsd: 0.1,
      outputPer1kUsd: 0.2,
      approvalRef: 'synthetic'
    },
    inputTokenUpperBound: {
      tokens: 1000,
      evidenceRef: 'synthetic',
      coversProtocol: true
    },
    requestLimitUsd: 1,
    dailyLimitUsd: 1
  }
  let sends = 0
  const a = app(d, {
    modelHost: { config: host, provider: m.provider },
    fetchImpl: async () => {
      sends++
      return new Response(JSON.stringify({ id: 'host-positive' }), {
        status: 201
      })
    }
  })
  await say(a, 'positive', 'ajuda')
  expect(sends).toBe(1)
  vi.spyOn(ModelGateway.prototype, 'budgetHealth').mockReturnValue({
    ready: false,
    reasonCodes: ['budget_store_unavailable'],
    inhibitedProfiles: []
  })
  await say(a, 'negative', 'ajuda')
  expect(sends).toBe(1)
  expect(a.store.operationalHold).toBe(true)
  expect(m.providerCalls()).toBe(0)
})
it('reopen narrows all owned documents including future recovery/orphan inventory without changing bytes', () => {
  const d = directory(),
    p = join(d, 'v')
  let s = new ShiftStore(p)
  s.append({ type: 'paused', at: NOW.toISOString(), by: MAN })
  s.saveMedia('orphan.bin', Buffer.from('synthetic'))
  s.close()
  fs.mkdirSync(join(p, 'recovery/future'), { mode: 0o775 })
  fs.writeFileSync(
    join(p, 'recovery/future/evidence.json'),
    'future evidence',
    { mode: 0o664 }
  )
  fs.writeFileSync(join(p, 'future-document.json'), 'future document', {
    mode: 0o664
  })
  const before = documents(p)
  for (const n of Object.keys(before)) fs.chmodSync(join(p, n), 0o664)
  s = new ShiftStore(p)
  cleanup.push(() => s.close())
  expect(s.storageAvailable).toBe(true)
  expect(documents(p)).toEqual(before)
  for (const n of Object.keys(before))
    expect(fs.statSync(join(p, n)).mode & 0o777).toBe(0o600)
  expect(fs.statSync(join(p, 'recovery/future')).mode & 0o777).toBe(0o700)
})
it.each(['symlink', 'hardlink', 'nested-symlink'])(
  'unsafe existing orphan %s refuses replay/effects while outside evidence stays unchanged',
  (kind) => {
    const d = directory(),
      p = join(d, 'v')
    const s = new ShiftStore(p)
    s.close()
    const target = join(d, 'outside')
    fs.writeFileSync(target, 'outside evidence', { mode: 0o664 })
    const unsafe = join(p, 'recovery/unsafe')
    if (kind === 'symlink') fs.symlinkSync(target, unsafe)
    else if (kind === 'hardlink') fs.linkSync(target, unsafe)
    else {
      fs.mkdirSync(unsafe, { mode: 0o700 })
      fs.symlinkSync(target, join(unsafe, 'indirect'))
    }
    const reopened = new ShiftStore(p)
    cleanup.push(() => reopened.close())
    expect(reopened.storageAvailable).toBe(false)
    expect(reopened.effectsAllowed).toBe(false)
    expect(fs.readFileSync(target, 'utf8')).toBe('outside evidence')
    expect(fs.statSync(target).mode & 0o777).toBe(0o664)
  }
)
it('saturation accepts only exact known matches; still denies new unmatched, collisions, account/recipient mismatch and duplicates without rewriting journal', async () => {
  const d = directory()
  let calls = 0,
    release: ((r: Response) => void) | undefined
  const a = app(d, {
    fetchImpl: async () => {
      if (++calls === 1)
        return new Response(JSON.stringify({ id: 'known' }), { status: 201 })
      return await new Promise<Response>((r) => {
        release = r
      })
    }
  })
  await say(a, 'first', 'ajuda')
  a.assistant.receive({
    provider: 'waha',
    messageId: 'second',
    fromPhone: ANA,
    kind: 'text',
    text: 'ajuda',
    receivedAt: NOW.toISOString()
  })
  await until(() => !!release)
  cleanup.push(() => {
    release?.(new Response(JSON.stringify({ id: 'second' }), { status: 201 }))
  })
  const payload = (id: string) => ({
    provider: 'waha',
    accountRef: 'ops-r3',
    providerMessageId: id,
    recipient: ANA,
    deliveryStatus: 'delivery_confirmed',
    simulation: true
  })
  const cb = (p: unknown) =>
    recordSimulatedDelivery(p, a.store, a.whatsapp, a.assistant, () =>
      NOW.toISOString()
    )
  for (let i = 0; i < 1000; i++) expect(cb(payload('early-' + i))).toBe(true)
  const seq = a.store.sequence
  expect(() => cb(payload('overflow'))).toThrow()
  expect(() => cb({ ...payload('known'), accountRef: 'wrong' })).toThrow()
  expect(() => cb({ ...payload('known'), recipient: MAN })).toThrow()
  expect(a.store.sequence).toBe(seq)
  expect(cb(payload('known'))).toBe(true)
  expect(a.store.deliveries()).toHaveLength(1001)
  expect(a.store.outboxes()[0]!.delivery?.commitVerified).toBe(true)
  const committed = a.store.sequence
  expect(cb(payload('known'))).toBe(false)
  expect(() => cb(payload('still-overflow'))).toThrow()
  expect(a.store.sequence).toBe(committed)
  release!(new Response(JSON.stringify({ id: 'second' }), { status: 201 }))
  await a.assistant.idle()
  await a.stop()
  const next = app(d)
  expect(next.store.deliveries()).toHaveLength(1001)
  expect(next.store.outboxes()[0]!.delivery?.commitVerified).toBe(true)
})
it.each(['download', 'transcribe', 'organize'] as const)(
  'budget fault aborts in-flight %s with no downstream effects and no health poll',
  async (stage) => {
    const d = directory(),
      m = model(d)
    let blocked: AbortSignal | undefined
    const paths: string[] = []
    let organizes = 0
    const a = app(d, {
      organizerGateway: m.options,
      organizer: {
        async organize(_raw, _at, signal) {
          organizes++
          if (stage === 'organize') {
            blocked = signal
            return await new Promise(() => {})
          }
          throw new Error('NO_DOWNSTREAM_MODEL')
        }
      },
      fetchImpl: async (url, init) => {
        const path = new URL(url).pathname
        paths.push(path)
        if (stage === 'download' && path.includes('media')) {
          blocked = init?.signal as AbortSignal
          return await new Promise(() => {})
        }
        if (stage === 'transcribe' && new URL(url).port === '2') {
          blocked = init?.signal as AbortSignal
          return await new Promise(() => {})
        }
        if (path.includes('media'))
          return new Response(Buffer.from('SYNTHETIC_AUDIO'), {
            status: 200,
            headers: { 'content-type': 'audio/ogg' }
          })
        throw new Error('UNEXPECTED_EFFECT')
      }
    })
    a.assistant.receive({
      provider: 'waha',
      messageId: 'held-' + stage,
      fromPhone: ANA,
      kind: stage === 'organize' ? 'text' : 'audio',
      text: stage === 'organize' ? 'Nota fictícia OPS-R3' : '',
      mediaRef: 'http://127.0.0.1:1/media',
      mimetype: 'audio/ogg',
      receivedAt: NOW.toISOString()
    })
    await until(() => !!blocked)
    const before = paths.length
    m.fail()
    await until(() => !!blocked?.aborted)
    await a.assistant.idle()
    expect(a.store.operationalHold).toBe(true)
    expect(paths).toHaveLength(before)
    expect(a.store.notesV2()).toEqual([])
    expect(a.store.tasksV2()).toEqual([])
    expect(a.store.outboxes()).toEqual([])
    expect(organizes).toBe(stage === 'organize' ? 1 : 0)
    expect(m.providerCalls()).toBe(0)
  }
)
it('gateway health exception durably inhibits effects before inbound dispatch', async () => {
  const d = directory(),
    m = model(d)
  let calls = 0
  const a = app(d, {
    organizerGateway: m.options,
    fetchImpl: async () => {
      calls++
      throw new Error('NO_EFFECT')
    }
  })
  vi.spyOn(m.gateway, 'budgetHealth').mockImplementation(() => {
    throw new Error('UNKNOWN_COST_STATE')
  })
  await say(a, 'health-exception', 'ajuda')
  expect(calls).toBe(0)
  expect(a.store.operationalHold).toBe(true)
  expect(
    JSON.parse(fs.readFileSync(join(d, 'clinical/budget-hold.json'), 'utf8'))
      .reconciliationRequired
  ).toBe(true)
})
it('provider id collision refuses callback even for exact account and recipient without changing journal', async () => {
  const d = directory(),
    a = app(d, {
      fetchImpl: async () =>
        new Response(JSON.stringify({ id: 'colliding-id' }), { status: 201 })
    })
  await say(a, 'one', 'ajuda')
  await say(a, 'two', 'ajuda')
  expect(a.store.outboxes()).toHaveLength(2)
  const sequence = a.store.sequence
  expect(() =>
    recordSimulatedDelivery(
      {
        provider: 'waha',
        accountRef: 'ops-r3',
        providerMessageId: 'colliding-id',
        recipient: ANA,
        deliveryStatus: 'delivery_confirmed',
        simulation: true
      },
      a.store,
      a.whatsapp,
      a.assistant,
      () => NOW.toISOString()
    )
  ).toThrow('INVALID_DELIVERY')
  expect(a.store.sequence).toBe(sequence)
  expect(a.store.deliveries()).toEqual([])
})
