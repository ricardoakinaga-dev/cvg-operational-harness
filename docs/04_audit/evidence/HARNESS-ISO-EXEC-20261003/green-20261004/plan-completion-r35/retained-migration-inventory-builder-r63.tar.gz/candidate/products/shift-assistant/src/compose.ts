import type { Server } from 'node:http'
import { resolve, sep } from 'node:path'
import {
  FileCostBudgetStore,
  ModelGateway,
  PromptRegistry,
  computePromptSha256,
  type ModelProvider
} from '@cvg/model-gateway'
import { ShiftAssistant, type ShiftLogger } from './assistant.ts'
import {
  validateModelHostConfig,
  type ApprovedModelHostConfig,
  type ShiftConfig
} from './config.ts'
import { allowlistedFetch, type FetchLike } from './egress.ts'
import {
  ModelOrganizer,
  ORGANIZER_PROMPT,
  type ModelOrganizerOptions,
  type Organizer
} from './organizer.ts'
import { withModelBudgetHealth } from './health.ts'
import { buildShiftServer } from './server.ts'
import { ShiftStore } from './store.ts'
import { WhisperTranscriber } from './transcriber.ts'
import { EvolutionClient, WahaClient, type WhatsAppClient } from './whatsapp.ts'

export interface ShiftApp {
  assistant: ShiftAssistant
  store: ShiftStore
  whatsapp: WhatsAppClient
  server: Server
  /** Starts listening and the reminder loop; returns the bound port. */
  start(): Promise<number>
  stop(): Promise<void>
}

export interface ComposeOptions {
  organizer?: Organizer
  /** Trusted host/test injection; ModelOrganizer still sends CLINICAL. */
  organizerGateway?: ModelOrganizerOptions
  /** Explicit owner configuration or synthetic fixture; never inferred from env. */
  modelHost?: { config: ApprovedModelHostConfig; provider: ModelProvider }
  logger?: ShiftLogger
  clock?: () => Date
  /** Network implementation under the egress allowlist (tests only). */
  fetchImpl?: FetchLike
}

/**
 * Single composition of the shift assistant, shared by the process entry
 * point, the demo and the integration tests.
 */
export function composeShiftApp(
  config: ShiftConfig,
  options: ComposeOptions = {}
): ShiftApp {
  const { env, members } = config
  let costStore: FileCostBudgetStore | undefined
  let modelOptions = options.organizerGateway
  if (options.modelHost) {
    const { config: host, provider } = options.modelHost
    const { estimatedCostUsd } = validateModelHostConfig(host)
    const { sha256, ...prompt } = host.prompt
    if (
      host.prompt.content !== ORGANIZER_PROMPT ||
      sha256 !== computePromptSha256(ORGANIZER_PROMPT)
    )
      throw new Error('Unapproved organizer prompt identity')
    if (
      estimatedCostUsd === 0 &&
      (host.authority !== 'synthetic-fixture' || provider.location !== 'local')
    )
      throw new Error('Zero pricing requires a declared free local fixture')
    const clinicalDirectory = resolve(env.SHIFT_DATA_DIR)
    const costDirectory = resolve(host.costDirectory)
    if (
      costDirectory === clinicalDirectory ||
      costDirectory.startsWith(clinicalDirectory + sep) ||
      clinicalDirectory.startsWith(costDirectory + sep)
    )
      throw new Error('Model costs must be separate from clinical storage')
    const prompts = new PromptRegistry()
    prompts.register({ ...prompt, tenantId: host.tenantId })
    const name = provider.location === 'local' ? 'local' : 'balanced'
    const model = provider.models[0]
    if (!model) throw new Error('Model profile has no model')
    costStore = new FileCostBudgetStore({
      directory: host.costDirectory,
      ...(host.restore ? { restore: host.restore } : {})
    })
    const gateway = new ModelGateway({
      providers: [provider],
      prompts,
      profiles: {
        [name]: {
          name,
          providerId: provider.id,
          model,
          location: provider.location,
          temperature: 0,
          maxTokens: 1500,
          timeoutMs: env.SHIFT_MODEL_TIMEOUT_MS,
          maxCostUsd: host.requestLimitUsd,
          estimatedCostUsd,
          maxRetries: 0,
          pricing: {
            inputPer1kUsd: host.pricing.inputPer1kUsd,
            outputPer1kUsd: host.pricing.outputPer1kUsd
          }
        }
      },
      routing: { allowFallback: false, allowLocalSubstitution: false },
      budget: {
        store: costStore,
        limits: { request: host.requestLimitUsd, day: host.dailyLimitUsd }
      },
      ...(options.clock ? { clock: options.clock } : {}),
      onEvent: (event) =>
        options.logger?.info('shift.model.event', {
          type: event.type,
          requestId: event.requestId,
          tenantId: event.tenantId,
          correlationId: event.correlationId,
          profile: event.profile,
          code: event.code,
          attempt: event.attempt,
          costUsd: event.costUsd
        })
    })
    modelOptions = {
      gateway,
      tenantId: host.tenantId,
      prompt: {
        promptId: host.prompt.promptId,
        version: host.prompt.version,
        sha256: host.prompt.sha256
      },
      profile: name,
      timeoutMs: env.SHIFT_MODEL_TIMEOUT_MS
    }
  }

  const store = new ShiftStore(env.SHIFT_DATA_DIR, {
    legacySession:
      env.SHIFT_PROVIDER === 'waha' ? env.WAHA_SESSION : env.EVOLUTION_INSTANCE!
  })
  const budgetHealth = () => {
    try {
      return (
        modelOptions?.gateway.budgetHealth() ?? { ready: true, reasonCodes: [] }
      )
    } catch {
      return { ready: false, reasonCodes: ['budget_store_unavailable'] }
    }
  }
  const budgetAuthority = () => {
    if (!budgetHealth().ready) {
      store.holdBudget((options.clock?.() ?? new Date()).toISOString())
      return false
    }
    return true
  }
  const guarded = (origins: string[]) => {
    const fetch = allowlistedFetch(origins, options.fetchImpl)
    return ((url, init) => {
      if (!assistant.checkEffectAuthority())
        throw new Error('EFFECTS_INHIBITED')
      return fetch(url, init)
    }) as FetchLike
  }

  const whatsapp: WhatsAppClient =
    env.SHIFT_PROVIDER === 'waha'
      ? new WahaClient({
          baseUrl: env.WAHA_URL!,
          apiKey: env.WAHA_API_KEY!,
          session: env.WAHA_SESSION,
          fetch: guarded([env.WAHA_URL!]),
          sendTimeoutMs: env.SHIFT_SEND_TIMEOUT_MS,
          mediaTimeoutMs: env.SHIFT_MEDIA_TIMEOUT_MS,
          maxMediaBytes: env.SHIFT_MAX_MEDIA_BYTES
        })
      : new EvolutionClient({
          baseUrl: env.EVOLUTION_URL!,
          apiKey: env.EVOLUTION_API_KEY!,
          instance: env.EVOLUTION_INSTANCE!,
          fetch: guarded([env.EVOLUTION_URL!]),
          sendTimeoutMs: env.SHIFT_SEND_TIMEOUT_MS,
          mediaTimeoutMs: env.SHIFT_MEDIA_TIMEOUT_MS,
          maxMediaBytes: env.SHIFT_MAX_MEDIA_BYTES
        })

  const transcriber = new WhisperTranscriber({
    baseUrl: env.WHISPER_URL,
    model: env.WHISPER_MODEL,
    language: 'pt',
    fetch: guarded([env.WHISPER_URL]),
    timeoutMs: env.SHIFT_WHISPER_TIMEOUT_MS
  })

  const modelOrganizer = new ModelOrganizer(modelOptions)
  // The assistant recognizes the exact default ModelOrganizer as intentional
  // NO_MODEL/raw-note mode. A configured gateway must traverse organize and
  // surface its policy denial as a failed organization, without drafting a note.
  const organizer =
    options.organizer ??
    (modelOptions
      ? { organize: modelOrganizer.organize.bind(modelOrganizer) }
      : modelOrganizer)

  const assistant = new ShiftAssistant({
    store,
    effectAuthority: budgetAuthority,
    members,
    whatsapp,
    transcriber,
    organizer,
    modelTimeoutMs: env.SHIFT_MODEL_TIMEOUT_MS,
    jobTimeoutMs: env.SHIFT_JOB_TIMEOUT_MS,
    shutdownTimeoutMs: env.SHIFT_SHUTDOWN_TIMEOUT_MS,
    sendTimeoutMs: env.SHIFT_SEND_TIMEOUT_MS,
    maxPendingMessages: env.SHIFT_MAX_PENDING_MESSAGES,
    tickSeconds: env.SHIFT_TICK_SECONDS,
    healthStaleMs: env.SHIFT_HEALTH_STALE_MS,
    ...(options.logger ? { logger: options.logger } : {}),
    ...(options.clock ? { clock: options.clock } : {})
  })

  assistant.checkEffectAuthority()

  if (modelOptions) {
    const originalHealth = assistant.health.bind(assistant)
    assistant.health = () =>
      withModelBudgetHealth(originalHealth(), budgetHealth())
  }

  const server = buildShiftServer({
    assistant,
    store,
    whatsapp,
    webhookSecret: env.SHIFT_WEBHOOK_SECRET,
    ...(env.SHIFT_DELIVERY_SIMULATION_SECRET
      ? { deliverySimulationSecret: env.SHIFT_DELIVERY_SIMULATION_SECRET }
      : {}),
    ...(options.clock ? { clock: options.clock } : {})
  })

  let timer: ReturnType<typeof setTimeout> | undefined
  let stopPromise: Promise<void> | undefined
  let watchdog: ReturnType<typeof setInterval> | undefined
  const schedule = () => {
    timer = setTimeout(
      () => {
        void assistant
          .tick()
          .catch(() => {
            assistant.inhibit('scheduler')
            options.logger?.error('shift.scheduler.failed', {
              code: 'SCHEDULER_FAILED'
            })
          })
          .finally(() => {
            if (!assistant.stopping) schedule()
          })
      },
      assistant.nextTickDelay(env.SHIFT_TICK_SECONDS * 1000)
    )
  }

  return {
    assistant,
    store,
    whatsapp,
    server,
    async start() {
      assistant.recoverPending()
      await new Promise<void>((resolve) =>
        server.listen(env.SHIFT_PORT, env.SHIFT_HOST, resolve)
      )
      schedule()
      watchdog = setInterval(() => assistant.health(), 1000)
      const address = server.address()
      return typeof address === 'object' && address
        ? address.port
        : env.SHIFT_PORT
    },
    async stop() {
      if (stopPromise) return stopPromise
      stopPromise = (async () => {
        if (timer) clearTimeout(timer)
        if (watchdog) clearInterval(watchdog)
        const workers = assistant.stop()
        const http = new Promise<void>((resolve) => {
          server.close(() => resolve())
          server.closeIdleConnections()
          server.closeAllConnections()
        })
        let shutdownTimer: ReturnType<typeof setTimeout> | undefined
        try {
          await Promise.race([
            Promise.all([workers, http]),
            new Promise<never>((_, reject) => {
              shutdownTimer = setTimeout(
                () => reject(new Error('SHUTDOWN_TIMEOUT')),
                env.SHIFT_SHUTDOWN_TIMEOUT_MS
              )
            })
          ])
        } finally {
          if (shutdownTimer) clearTimeout(shutdownTimer)
        }
        store.close()
        costStore?.close()
      })()
      return stopPromise
    }
  }
}
