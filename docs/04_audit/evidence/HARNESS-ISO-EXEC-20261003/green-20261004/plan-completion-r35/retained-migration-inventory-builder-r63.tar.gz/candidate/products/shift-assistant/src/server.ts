import { timingSafeEqual } from 'node:crypto'
import {
  createServer,
  type IncomingMessage,
  type Server,
  type ServerResponse
} from 'node:http'
import { TransportError } from './transport-limits.ts'
import { recordSimulatedDelivery } from './delivery-receipts.ts'
import { StoreError } from './journal.ts'
import type { ShiftAssistant } from './assistant.ts'
import type { ShiftStore } from './store.ts'
import type { WhatsAppClient } from './whatsapp.ts'

export interface ShiftServerOptions {
  assistant: ShiftAssistant
  store: ShiftStore
  whatsapp: WhatsAppClient
  webhookSecret: string
  clock?: () => Date
  /** Webhooks may carry inline media (Evolution `webhook_base64`). */
  maxBodyBytes?: number
  bodyTimeoutMs?: number
  deliverySimulationSecret?: string
}

function secretMatches(expected: string, received: unknown): boolean {
  if (typeof received !== 'string') return false
  const a = Buffer.from(expected)
  const b = Buffer.from(received)
  return a.length === b.length && timingSafeEqual(a, b)
}

class BodyTooLargeError extends Error {}
class BodyTimeoutError extends Error {}
function readJson(
  request: IncomingMessage,
  limit: number,
  timeout: number
): Promise<unknown> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = []
    let size = 0
    const cleanup = () => {
      clearTimeout(timer)
      request.removeListener('data', data)
      request.removeListener('end', end)
      request.removeListener('error', fail)
      request.removeListener('aborted', aborted)
    }
    const fail = (error: Error) => {
      cleanup()
      request.pause()
      reject(error)
    }
    const aborted = () => fail(new Error('invalid_json'))
    const data = (chunk: Buffer) => {
      size += chunk.length
      if (size > limit) {
        fail(new BodyTooLargeError())
        return
      }
      chunks.push(chunk)
    }
    const end = () => {
      cleanup()
      try {
        resolve(
          JSON.parse(
            new TextDecoder('utf-8', { fatal: true }).decode(
              Buffer.concat(chunks)
            )
          )
        )
      } catch {
        reject(new Error('invalid_json'))
      }
    }
    const timer = setTimeout(() => fail(new BodyTimeoutError()), timeout)
    if (Number(request.headers['content-length']) > limit) {
      fail(new BodyTooLargeError())
      return
    }
    request.on('data', data)
    request.once('end', end)
    request.once('error', fail)
    request.once('aborted', aborted)
  })
}

function send(response: ServerResponse, status: number, body: unknown): void {
  response.writeHead(status, { 'content-type': 'application/json' })
  response.end(JSON.stringify(body))
}

/**
 * Webhook endpoint for the configured WhatsApp provider (node:http, no
 * framework). It acknowledges quickly; the assistant records the message
 * before processing it.
 */
export function buildShiftServer(options: ShiftServerOptions): Server {
  const clock = options.clock ?? (() => new Date())
  const limit = options.maxBodyBytes ?? 25 * 1024 * 1024
  const webhookPath = `/webhooks/${options.whatsapp.provider}`

  let reading = 0
  const server = createServer(
    {
      headersTimeout: 5000,
      requestTimeout: 15000,
      connectionsCheckingInterval: 250,
      keepAliveTimeout: 5000
    },
    (request, response) => {
      void (async () => {
        const url = new URL(request.url ?? '/', 'http://shift.local')
        if (
          request.method === 'GET' &&
          ['/health', '/health/live', '/health/ready'].includes(url.pathname)
        ) {
          const live = url.pathname === '/health/live'
          if (live) {
            send(response, 200, { ok: true })
            return
          }
          const health = options.assistant.health()
          send(response, live || health.ready ? 200 : 503, {
            ok: live || health.ready,
            ...health,
            provider: options.whatsapp.provider,
            paused: options.store.paused,
            pendingMessages: options.store
              .inboxes()
              .filter((i) => i.state !== 'processed').length,
            openTasks: options.store.openTasks().length
          })
          return
        }
        const delivery =
          url.pathname === '/callbacks/delivery-simulation' &&
          !!options.deliverySimulationSecret
        if (
          request.method !== 'POST' ||
          (url.pathname !== webhookPath && !delivery)
        ) {
          send(response, 404, { error: 'not_found' })
          return
        }
        const provided =
          request.headers['x-cvg-webhook-secret'] ??
          url.searchParams.get('secret')
        if (
          !secretMatches(
            delivery
              ? options.deliverySimulationSecret!
              : options.webhookSecret,
            provided
          )
        ) {
          request.resume()
          send(response, 401, { error: 'unauthorized' })
          return
        }
        if (reading >= 4) {
          response.setHeader('connection', 'close')
          send(response, 503, { error: 'body_capacity' })
          response.once('finish', () => request.socket.end())
          return
        }
        if (
          !/^application\/json(?:\s*;\s*charset=utf-8)?$/i.test(
            String(request.headers['content-type'] ?? '')
          ) ||
          (request.headers['content-encoding'] &&
            request.headers['content-encoding'] !== 'identity')
        ) {
          send(response, 400, { error: 'invalid_payload' })
          request.resume()
          return
        }
        reading++
        let payload: unknown
        try {
          payload = await readJson(
            request,
            limit,
            options.bodyTimeoutMs ?? 10000
          )
        } catch (error) {
          response.setHeader('connection', 'close')
          send(
            response,
            error instanceof BodyTimeoutError
              ? 408
              : error instanceof BodyTooLargeError
                ? 413
                : 400,
            {
              error:
                error instanceof BodyTimeoutError
                  ? 'request_timeout'
                  : error instanceof BodyTooLargeError
                    ? 'too_large'
                    : 'invalid_json'
            }
          )
          response.once('finish', () => request.socket.end())
          return
        } finally {
          reading--
        }
        if (delivery) {
          try {
            const accepted = recordSimulatedDelivery(
              payload,
              options.store,
              options.whatsapp,
              options.assistant,
              () => clock().toISOString()
            )
            send(response, 200, {
              accepted,
              simulation: true,
              providerQualification: 'NOT_QUALIFIED'
            })
          } catch (error) {
            if (
              error instanceof StoreError &&
              error.code === 'STORAGE_UNAVAILABLE'
            ) {
              options.assistant.inhibit('storage')
              send(response, 503, { error: 'storage_unavailable' })
            } else send(response, 400, { error: 'invalid_delivery' })
          }
          return
        }
        const message = options.whatsapp.parseWebhook(
          payload,
          clock().toISOString()
        )
        const accepted = message ? options.assistant.receive(message) : false
        send(response, 200, { accepted })
      })().catch((error: unknown) => {
        const code =
          error instanceof StoreError
            ? error.code
            : error instanceof TransportError
              ? error.code === 'MEDIA_TOO_LARGE'
                ? 'TOO_LARGE'
                : 'INVALID_TRANSITION'
              : error instanceof Error && error.message === 'QUEUE_FULL'
                ? 'QUEUE_FULL'
                : ''
        if (code === 'QUEUE_FULL') response.setHeader('retry-after', '30')
        if (!response.headersSent)
          send(
            response,
            code === 'IDEMPOTENCY_CONFLICT'
              ? 409
              : code === 'TOO_LARGE'
                ? 413
                : code === 'STORAGE_UNAVAILABLE' || code === 'QUEUE_FULL'
                  ? 503
                  : code === 'INVALID_TRANSITION'
                    ? 400
                    : 500,
            { error: code.toLowerCase() || 'internal' }
          )
      })
    }
  )
  server.headersTimeout = 5000
  server.requestTimeout = 15000
  server.keepAliveTimeout = 5000
  let connections = 0
  server.on('connection', (socket) => {
    if (connections >= 16) {
      socket.end(
        'HTTP/1.1 503 Service Unavailable\r\nConnection: close\r\nContent-Length: 0\r\n\r\n'
      )
      return
    }
    connections++
    socket.once('close', () => {
      connections--
    })
  })
  return server
}
