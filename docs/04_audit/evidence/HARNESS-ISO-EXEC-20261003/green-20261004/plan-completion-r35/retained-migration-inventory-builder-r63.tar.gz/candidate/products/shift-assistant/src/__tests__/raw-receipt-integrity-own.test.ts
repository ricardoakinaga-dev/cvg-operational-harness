// @vitest-environment node
import { mkdtempSync, readFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, expect, it } from 'vitest'
import { ShiftStore, type CommitExpected } from '../store.ts'
import { canonical, Journal, sha256 } from '../journal.ts'
import { inputDigest } from '../vertical-state.ts'
import type { DeliveryReceipt, V2Event } from '../domain-v2.ts'

const PHONE = '5511900000001'
const actor = { kind: 'member' as const, memberPhone: PHONE }
const EPOCH = Date.parse('2026-10-04T12:00:00Z')
const cleanup: Array<() => void> = []
afterEach(() => {
  for (const close of cleanup.splice(0).reverse()) close()
})
const payload = {
  provider: 'waha' as const,
  accountRef: 'account-A',
  providerMessageId: 'message-A',
  recipient: PHONE,
  deliveryStatus: 'delivery_confirmed' as const,
  simulation: true as const
}
const identity = {
  provider: payload.provider,
  accountRef: payload.accountRef,
  outboxId: 'A',
  sourceTransitionId: 'source:A',
  recipient: PHONE
}
const eventIdentity = sha256(
  JSON.stringify([
    payload.provider,
    payload.accountRef,
    payload.providerMessageId,
    payload.recipient,
    payload.deliveryStatus
  ])
)
const badRaw: Array<[string, string]> = [
  ['provider', canonical({ ...payload, provider: 'evolution' })],
  ['accountRef', canonical({ ...payload, accountRef: 'other-account' })],
  [
    'providerMessageId',
    canonical({ ...payload, providerMessageId: 'other-id' })
  ],
  ['recipient', canonical({ ...payload, recipient: '5511900000009' })],
  ['deliveryStatus', canonical({ ...payload, deliveryStatus: 'read' })],
  ['simulation', canonical({ ...payload, simulation: false })],
  ['invalid JSON', '{broken'],
  ['extra property', canonical({ ...payload, extra: true })],
  [
    'missing simulation',
    canonical({
      provider: payload.provider,
      accountRef: payload.accountRef,
      providerMessageId: payload.providerMessageId,
      recipient: payload.recipient,
      deliveryStatus: payload.deliveryStatus
    })
  ],
  ['null', 'null'],
  ['array', canonical([payload])],
  ['string', JSON.stringify(canonical(payload))],
  ['number', '42'],
  ['account length', canonical({ ...payload, accountRef: 'x'.repeat(513) })]
]

function fixture() {
  const dir = mkdtempSync(join(tmpdir(), 'raw-receipt-own-'))
  cleanup.push(() => rmSync(dir, { recursive: true, force: true }))
  let store = new ShiftStore(dir)
  cleanup.push(() => store.close())
  let time = EPOCH
  let serial = 0
  const at = () => new Date(time).toISOString()
  const commit = (event: V2Event, transitionId = 'own:' + ++serial) => {
    const expected: CommitExpected = {}
    for (const [entity, key] of store.references(event))
      (expected[entity] ??= {})[String(key)] = store.revision(entity, key)
    return store.commit({ transitionId, expected, changes: [event] })
  }
  const key = JSON.stringify(['waha', 'account-A', 'input-A'])
  const inbox = {
    key,
    provider: payload.provider,
    session: payload.accountRef,
    messageId: 'input-A',
    memberPhone: PHONE,
    kind: 'text' as const,
    text: 'ajuda',
    receivedAt: at(),
    digest: '',
    state: 'received' as const,
    stage: 'command' as const,
    attempt: 0
  }
  inbox.digest = inputDigest(inbox)
  commit({ v: 2, type: 'inbound_recorded', at: at(), actor, inbox })
  commit({
    v: 2,
    type: 'processing_started',
    at: at(),
    actor,
    key,
    stage: 'command',
    attempt: 1,
    deadline: new Date(time + 1000).toISOString(),
    draftAt: at()
  })
  commit(
    {
      v: 2,
      type: 'response_committed',
      at: at(),
      actor,
      key,
      outbox: {
        id: 'A',
        purpose: 'response',
        sourceTransitionId: 'source:A',
        recipientMemberId: PHONE,
        payloadText: 'synthetic',
        payloadSha256: sha256('synthetic'),
        state: 'queued',
        attempt: 0
      }
    },
    'source:A'
  )
  commit({
    v: 2,
    type: 'outbox_dispatch_started',
    at: at(),
    actor,
    outboxId: 'A',
    attempt: 1,
    identity
  })
  commit({
    v: 2,
    type: 'outbox_result',
    at: at(),
    actor,
    outboxId: 'A',
    state: 'provider_accepted',
    receipt: {
      status: 201,
      at: at(),
      sha256: sha256('response'),
      providerId: payload.providerMessageId,
      identity
    }
  })
  const completion = (): V2Event => ({
    v: 2,
    type: 'delivery_receipt_committed',
    at: at(),
    actor,
    eventIdentity,
    committedAt: at()
  })
  const reception = (
    raw: string,
    legacy: boolean,
    claimedVerified = false
  ): V2Event => {
    const receipt: DeliveryReceipt = {
      ...payload,
      eventIdentity,
      receivedAt: at(),
      committedAt: at(),
      rawReceiptRef: 'journal:delivery:' + eventIdentity,
      rawSha256: sha256(raw),
      raw,
      commitVerified: claimedVerified,
      ...(legacy
        ? {}
        : { eligibility: { identity, attempt: 1, startedAt: at() } })
    }
    return { v: 2, type: 'delivery_receipt_recorded', at: at(), actor, receipt }
  }
  const bytes = () => {
    const manifest = JSON.parse(
      readFileSync(join(dir, 'journal/manifest.json'), 'utf8')
    ) as { segments: Array<{ path: string }> }
    return readFileSync(join(dir, manifest.segments.at(-1)!.path))
  }
  const reopen = () => {
    store.close()
    store = new ShiftStore(dir)
    expect(store.storageAvailable).toBe(true)
  }
  const proof = () => ({
    history: store.deliveryCommitted(eventIdentity),
    receipt: store.deliveries()[0]?.commitVerified,
    outbox: store.outbox('A')?.delivery?.commitVerified
  })
  return {
    get store() {
      return store
    },
    at,
    commit,
    completion,
    reception,
    bytes,
    reopen,
    proof,
    advance() {
      time += 86400001
    },
    // Append valid hash-chain records without ShiftStore admission to isolate replay.
    appendForReplay(events: V2Event[]) {
      store.close()
      const journal = new Journal(dir)
      try {
        journal.replay(() => {})
        for (const event of events)
          journal.append('own:replay:' + ++serial, [event])
      } finally {
        journal.close()
      }
      store = new ShiftStore(dir)
      expect(store.storageAvailable).toBe(true)
    }
  }
}

for (const legacy of [false, true]) {
  const shape = legacy ? 'legacy' : 'explicit eligibility'
  it(`${shape}: unverified completion is recorded once without permitting repeated final events`, () => {
    const f = fixture()
    f.commit(f.reception('{broken', legacy))
    f.commit(f.completion())
    for (const replay of [false, true]) {
      if (replay) f.reopen()
      const before = f.bytes(),
        sequence = f.store.sequence
      expect(() => f.commit(f.completion())).toThrow('STATE_CONFLICT')
      expect(f.store.sequence).toBe(sequence)
      expect(f.bytes()).toEqual(before)
      expect(f.proof()).toEqual({
        history: false,
        receipt: false,
        outbox: undefined
      })
    }
  })
  it.each(badRaw)(
    `${shape}: direct commit %s cannot prove delivery before or after reopen`,
    (_field, raw) => {
      const f = fixture()
      f.commit(f.reception(raw, legacy))
      const recorded = f.proof()
      f.commit(f.completion())
      const committed = f.proof()
      const before = f.bytes()
      f.reopen()
      const replayed = f.proof()
      expect(f.bytes()).toEqual(before)
      expect(f.store.deliveries()[0]?.raw).toBe(raw)
      expect(f.store.deliveries()[0]?.rawSha256).toBe(sha256(raw))
      expect(recorded).toEqual({
        history: false,
        receipt: false,
        outbox: undefined
      })
      expect(committed).toEqual(recorded)
      expect(replayed).toEqual(recorded)
    }
  )

  it.each(badRaw)(
    `${shape}: journal append %s cannot prove delivery on replay`,
    (_field, raw) => {
      const f = fixture()
      f.appendForReplay([f.reception(raw, legacy), f.completion()])
      const first = f.proof()
      const before = f.bytes()
      f.reopen()
      expect(f.bytes()).toEqual(before)
      expect(f.store.deliveries()[0]?.raw).toBe(raw)
      expect(first).toEqual({
        history: false,
        receipt: false,
        outbox: undefined
      })
      expect(f.proof()).toEqual(first)
    }
  )

  it.each([canonical(payload), JSON.stringify(payload, null, 2)])(
    `${shape}: matching raw %s requires final commit and remains verified after replay`,
    (raw) => {
      const f = fixture()
      f.commit(f.reception(raw, legacy))
      expect(f.proof()).toEqual({
        history: false,
        receipt: false,
        outbox: undefined
      })
      f.commit(f.completion())
      const before = f.bytes()
      f.reopen()
      expect(f.bytes()).toEqual(before)
      expect(f.proof()).toEqual({ history: true, receipt: true, outbox: true })
    }
  )

  it.each([canonical(payload), '{broken'])(
    `${shape}: journal claimed verification is bounded by raw proof (%s)`,
    (raw) => {
      const f = fixture()
      f.appendForReplay([f.reception(raw, legacy, true)])
      const valid = raw === canonical(payload)
      const expected = {
        history: valid,
        receipt: valid,
        outbox: valid ? true : undefined
      }
      expect(f.proof()).toEqual(expected)
      const before = f.bytes()
      f.reopen()
      expect(f.bytes()).toEqual(before)
      expect(f.proof()).toEqual(expected)
    }
  )
}

it('unverifiable raw proof stays denied after pending receipt pruning and late completion', () => {
  const f = fixture()
  f.commit(f.reception('{broken', true))
  f.advance()
  const inbox = {
    key: JSON.stringify(['waha', 'account-A', 'prune']),
    provider: payload.provider,
    session: payload.accountRef,
    messageId: 'prune',
    memberPhone: PHONE,
    kind: 'text' as const,
    text: 'ajuda',
    receivedAt: f.at(),
    digest: '',
    state: 'received' as const,
    stage: 'command' as const,
    attempt: 0
  }
  inbox.digest = inputDigest(inbox)
  f.commit({ v: 2, type: 'inbound_recorded', at: f.at(), actor, inbox })
  expect(f.store.deliveries()).toHaveLength(0)
  f.commit(f.completion())
  const before = f.bytes()
  f.reopen()
  expect(f.bytes()).toEqual(before)
  expect(f.proof()).toEqual({
    history: false,
    receipt: undefined,
    outbox: undefined
  })
})
