import { spawnSync } from 'node:child_process';
const node='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node';
const npm='/home/ricardo/.nvm/versions/node/v22.23.2/lib/node_modules/npm/bin/npm-cli.js';
for(const task of ['build:shift-assistant','typecheck','lint']){console.log('GATE '+task);const p=spawnSync(node,[npm,'run',task],{stdio:'inherit',env:process.env});if(p.status!==0) process.exit(p.status??1);}
