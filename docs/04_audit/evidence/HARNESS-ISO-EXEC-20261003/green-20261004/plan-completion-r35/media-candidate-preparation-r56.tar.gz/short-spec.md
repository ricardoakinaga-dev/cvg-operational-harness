# R56 — nova candidata de mídia e captura correta

Task R56_NEXT_CANDIDATE_MEDIA_AND_GATES; T2 existing0179/media invariant and priorCIcapture contract. SourceR44 completed, all16localgatesPASS but qualificationDENIED because a nestedVitegeneratedcache was force-tracked during baseline prep. R49 REJECTmedia reference; builderR53isolatedpayload pending freeze.

Rules: integrate only frozenR53changedproductpaths after byte/hashreview; no publicschema/migration/policy/security waiver. Preserve original371tests/281coverage and all existing50newtestpaths. Stage privateGit only actualsourceFiles selected by originalproducer, excluding node_modules at all depths as installation/caches and compileroutputs already excluded by existingproducer; never patch gateconditions to accept changed inputs. Generated XML drift captured separately and never merged into sourcequalification.

Preparation: copiedR44source without .git/allnode_modules/coverage/testresults; rawR44 archives durable. Physical deps17,394records/48internal links transferred from OWNinactiveR44 with sourcebeforeafterMATCH, oldinstallDETACHED. No privateenv or Root runtime promotion.

Ready: publicbuild/types/lint/focusedmedia exactcase + allfullPG55599/E2E3268/4268/certify16gates inNode22 PASS with candidateinputs exact beforeafter, rawlogs saved; image rebuilt from newDockerfile inputs, new freshcritics, neutralproject currentandallconstraints. Unknowninstalledclosure remainsINCOMPLETE. No finalreleaseclaim or externalprovidercall.

Builder/test approvals not transitive to newbinary; futurefreshreview required. FailuresR44/R49/R50retained. ExternalT4/egress/humanqualification separate.
