# R38 — correção interna de integridade persistente

Task LIVE_JOURNAL_AND_OFFLINE_VALIDATION_R38. Trilha T2 sob SPEC0179 aprovada, SHA-256 988192fe48737b4571ed659f051e22f3a9283d5c433e7c6c078e1dd0f7be86c3, e autorização vigente de correção contínua. Sem contrato público, schema, migration, identidade, policy ou approval novos.

## Reconhecimento

R36 reproduziu alteração de um byte em segmento do journal de processo vivo: webhook200, sendText e readiness200; restart503. R37 reproduziu backup_verified/restored_under_hold em quatro volumes recusados pelo runtime: revision ausente, prefixSha256 divergente, evento desconhecido com checksum válido e mídia referenciada ausente. As críticas e seus resultados desfavoráveis devem ser preservados; R36 também violou sua fronteira de leitura Q7 e não concede aceite independente.

## Invariantes e implementação

Produto isolado. Ingresso, efeito e readiness não podem confiar apenas em disponibilidade memorizada após mudança indevida no estado persistente. Falha torna armazenamento indisponível, sem novos efeitos ou reescrita destrutiva. Manter orçamento original de desempenho, inclusive 1000 transições e limites existentes, sem hash/replay integral quadrático no caminho quente. Declarar o modelo POSIX local e limites reais da detecção. Backup/restore só emitem sucesso quando a validação completa do formato e referências exigidos pelo consumidor aprova; hashes da cópia não substituem validade semântica. Não abrir writer nem modificar documentos durante validação offline; manter lock exclusivo de backup, retenção integral, destino novo e restore sob hold. Preferir contrato de validação compartilhado no próprio produto a duas gramáticas divergentes.

## Critério de pronto

Reproduções discriminantes antes/depois para os cinco defeitos, negativos adicionais pertinentes de truncamento/substituição/manifest/media e controles saudáveis. Bytes corrompidos preservados; zero envio indevido. Regressões originais não alteradas, sem skips/assertions enfraquecidas. Typecheck/lint/testes focados Node22; antes de integração/promover: suíte completa, PostgreSQL, E2E, certify e crítico novo do artefato compilado e backup/restore. NO_MODEL, T4 separado, sem provider/dados reais/push/deploy. Resultado por gate explícito; nenhuma produção concedida.
