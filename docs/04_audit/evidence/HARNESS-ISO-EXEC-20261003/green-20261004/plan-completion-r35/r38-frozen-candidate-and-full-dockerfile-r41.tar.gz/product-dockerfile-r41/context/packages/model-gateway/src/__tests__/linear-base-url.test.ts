import { describe, expect, it, vi } from 'vitest'
import { trimTrailingSlashes } from '../trim-trailing-slashes.ts'
import { OpenAICompatibleProvider } from '../providers/openai-compatible.ts'
import { OllamaProvider } from '../providers/ollama.ts'

describe('linear base URL normalization', () => {
  it.each([
    'https://synthetic.example',
    'https://synthetic.example/',
    'https://synthetic.example/a////',
    '/',
    '',
    'https://synthetic.example/a/ x',
    'http://127.0.0.1:1////'
  ])('matches previous literal suffix for %s', (value) => {
    expect(trimTrailingSlashes(value)).toBe(value.replace(/\/+$/, ''))
  })
  it.each([2048, 4096, 8192, 16384])(
    'preserves %i final slashes in real constructors without I/O',
    (length) => {
      const fetchImpl = vi.fn()
      const baseUrl = `https://synthetic.example/${'/'.repeat(length)}`
      expect(
        () =>
          new OpenAICompatibleProvider({
            id: 'synthetic',
            baseUrl,
            model: 'synthetic',
            location: 'external',
            requiresApiKey: false,
            fetchImpl
          })
      ).not.toThrow()
      expect(
        () => new OllamaProvider({ baseUrl, model: 'synthetic', fetchImpl })
      ).not.toThrow()
      expect(fetchImpl).not.toHaveBeenCalled()
    }
  )
  it.each([
    'file:///synthetic',
    'http://169.254.169.254////',
    'http://127.0.0.1:1////'
  ])('keeps SSRF/protocol denial for %s before I/O', (baseUrl) => {
    const fetchImpl = vi.fn()
    expect(
      () =>
        new OpenAICompatibleProvider({
          id: 'synthetic',
          baseUrl,
          model: 'synthetic',
          location: 'external',
          requiresApiKey: false,
          fetchImpl
        })
    ).toThrow()
    expect(
      () => new OllamaProvider({ baseUrl, model: 'synthetic', fetchImpl })
    ).toThrow()
    expect(fetchImpl).not.toHaveBeenCalled()
  })
})
