// @vitest-environment node
import { expect, it } from 'vitest'
import { createServer } from 'node:http'
import { once, getEventListeners } from 'node:events'
import type { Socket, AddressInfo } from 'node:net'
import {
  ModelGateway,
  PromptRegistry,
  OpenAICompatibleProvider
} from '../index.ts'
import { CircuitBreaker } from '../circuit-breaker.ts'
const tick = () => new Promise<void>((r) => setImmediate(r))
function deferred() {
  let resolve!: () => void
  const promise = new Promise<void>((r) => (resolve = r))
  return { promise, resolve }
}
it('fresh acquired probe cancelled after reopen cannot release a newer acquired probe', async () => {
  let now = Date.parse('2026-10-04T12:00:00Z'),
    calls = 0
  const entered = [deferred(), deferred(), deferred(), deferred()] as const
  let failOld = () => {},
    finishNew = () => {}
  const sockets = new Set<Socket>(),
    events: unknown[] = []
  const server = createServer((_req, res) => {
    calls++
    if (calls === 1) {
      failOld = () => {
        res.writeHead(500)
        res.flushHeaders()
      }
      entered[0].resolve()
    } else if (calls === 2) {
      res.writeHead(500)
      res.flushHeaders()
      entered[1].resolve()
    } else if (calls === 3) {
      res.writeHead(200)
      res.flushHeaders()
      entered[2].resolve()
    } else if (calls === 4) {
      res.writeHead(200)
      res.flushHeaders()
      finishNew = () =>
        res.end(JSON.stringify({ choices: [{ message: { content: 'blue' } }] }))
      entered[3].resolve()
    } else
      res.end(
        JSON.stringify({
          choices: [{ message: { content: 'unexpected extra probe' } }]
        })
      )
  })
  server.on('connection', (s) => {
    sockets.add(s)
    s.on('close', () => sockets.delete(s))
  })
  server.listen(0, '127.0.0.1')
  await once(server, 'listening')
  const oldCaller = new AbortController(),
    newCaller = new AbortController()
  const prompts = new PromptRegistry(),
    tenant = 'tenant_00000000-0000-4000-8000-000000000001'
  prompts.register({
    promptId: 'fresh-probe-generation',
    version: '1',
    content: 'Sort synthetic colors',
    classification: 'INTERNAL',
    tenantId: tenant,
    owner: 'own local fixture',
    approvedBy: 'synthetic reviewer',
    status: 'approved',
    effectiveFrom: '2026-01-01T00:00:00Z'
  })
  const c = new CircuitBreaker({
    failureThreshold: 1,
    openMs: 10,
    halfOpenSuccesses: 1,
    clock: () => now,
    onTransition: (e) => events.push(e)
  })
  const g = new ModelGateway({
    prompts,
    circuitBreaker: c,
    clock: () => new Date(now),
    providers: [
      new OpenAICompatibleProvider({
        id: 'fresh',
        model: 'synthetic',
        location: 'local',
        baseUrl: `http://127.0.0.1:${(server.address() as AddressInfo).port}`,
        allowHttp: true,
        allowPrivateNetworks: true
      })
    ],
    profiles: {
      local: {
        name: 'local',
        providerId: 'fresh',
        model: 'synthetic',
        location: 'local',
        temperature: 0,
        maxTokens: 8,
        maxRetries: 0,
        timeoutMs: 3000,
        maxCostUsd: 0,
        estimatedCostUsd: 0,
        pricing: { inputPer1kUsd: 0, outputPer1kUsd: 0 }
      }
    }
  })
  const request = (signal?: AbortSignal) => ({
    requestId: 'req_fresh_generation',
    correlationId: 'corr_fresh_generation',
    tenantId: tenant,
    promptId: 'fresh-probe-generation',
    promptVersion: '1',
    modelProfile: 'local' as const,
    dataClassification: 'INTERNAL' as const,
    input: {
      messages: [{ role: 'user' as const, content: 'Sort fictional blue red' }]
    },
    ...(signal ? { signal } : {})
  })
  const outcome = (p: ReturnType<ModelGateway['generate']>) =>
    p.then((r) => ({ text: r.output.text })).catch((e) => ({ code: e.code }))
  let oldProbe: ReturnType<typeof outcome> | undefined,
    newProbe: ReturnType<typeof outcome> | undefined
  try {
    const earlier = outcome(g.generate(request()))
    await entered[0].promise
    expect(await outcome(g.generate(request()))).toEqual({
      code: 'provider_unavailable'
    })
    expect(c.state('fresh:synthetic')).toBe('OPEN')
    now += 11
    oldProbe = outcome(g.generate(request(oldCaller.signal)))
    await entered[2].promise
    expect(c.state('fresh:synthetic')).toBe('HALF_OPEN')
    // An older CLOSED request fails while the admitted HALF_OPEN request is still running.
    failOld()
    expect(await earlier).toEqual({ code: 'provider_unavailable' })
    expect(c.state('fresh:synthetic')).toBe('OPEN')
    now += 11
    newProbe = outcome(g.generate(request(newCaller.signal)))
    await entered[3].promise
    const positiveControl = await outcome(g.generate(request()))
    expect(positiveControl).toEqual({ code: 'circuit_open' })
    expect(calls).toBe(4)
    oldCaller.abort(new Error('cancel stale owned probe'))
    expect(await oldProbe).toEqual({ code: 'cancelled' })
    const next = await outcome(g.generate(request())),
      after = c.state('fresh:synthetic')
    console.log(
      'fresh-probe-generation',
      JSON.stringify({
        node: process.version,
        calls,
        positiveControl,
        next,
        after,
        transitions: events,
        oldCallerListeners: getEventListeners(oldCaller.signal, 'abort').length
      })
    )
    finishNew()
    await newProbe
    await tick()
    expect(next).toEqual({ code: 'circuit_open' })
    expect(calls).toBe(4)
  } finally {
    oldCaller.abort()
    newCaller.abort()
    await oldProbe
    await newProbe
    const closes = [...sockets].map((s) => once(s, 'close'))
    server.closeAllConnections()
    await new Promise<void>((r) => server.close(() => r()))
    await Promise.all(closes)
  }
}, 6000)
