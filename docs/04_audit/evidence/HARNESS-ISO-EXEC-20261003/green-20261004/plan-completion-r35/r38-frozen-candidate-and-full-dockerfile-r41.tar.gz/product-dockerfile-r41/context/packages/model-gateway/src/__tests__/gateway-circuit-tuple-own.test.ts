// @vitest-environment node
import { describe, expect, it } from 'vitest'
import {
  ModelGateway,
  ModelProviderError,
  PromptRegistry,
  type ModelProfile,
  type ModelProvider
} from '../index.ts'

const tenantId = 'tenant_00000000-0000-4000-8000-000000000180'

describe('independent circuits for public provider/model identities', () => {
  it.each([
    ['alpha', 'beta:gamma', 'alpha:beta', 'gamma'],
    ['alpha%3Abeta', 'gamma', 'alpha', 'beta:gamma'],
    ['synthetic-primary', 'color', 'synthetic-secondary', 'color']
  ])(
    'isolates failure and half-open recovery for %s/%s and %s/%s',
    async (firstId, firstModel, secondId, secondModel) => {
      let time = 0,
        firstCalls = 0,
        secondCalls = 0
      const prompts = new PromptRegistry()
      prompts.register({
        promptId: 'synthetic-circuit-tuple',
        version: '1',
        content: 'Synthetic colors.',
        owner: 'fixture',
        approvedBy: 'synthetic-only',
        status: 'approved',
        classification: 'INTERNAL',
        tenantId,
        effectiveFrom: '2026-01-01T00:00:00Z'
      })
      const provider = (
        id: string,
        model: string,
        primary: boolean
      ): ModelProvider => ({
        id,
        models: [model],
        location: 'local',
        async execute(request) {
          if (primary) {
            firstCalls += 1
            if (firstCalls === 1)
              throw new ModelProviderError(
                id,
                'timeout',
                'Synthetic unavailable'
              )
          } else secondCalls += 1
          return {
            text: 'blue',
            providerId: id,
            model: request.model,
            usage: { inputTokens: 0, outputTokens: 0 },
            externalCall: false
          }
        }
      })
      const profile = (
        name: ModelProfile['name'],
        providerId: string,
        model: string
      ): ModelProfile => ({
        name,
        providerId,
        model,
        location: 'local',
        temperature: 0,
        maxTokens: 16,
        timeoutMs: 1000,
        maxRetries: 0,
        maxCostUsd: 1,
        estimatedCostUsd: 0,
        pricing: { inputPer1kUsd: 0, outputPer1kUsd: 0 }
      })
      const gateway = new ModelGateway({
        prompts,
        providers: [
          provider(firstId, firstModel, true),
          provider(secondId, secondModel, false)
        ],
        profiles: {
          fast: profile('fast', firstId, firstModel),
          local: profile('local', secondId, secondModel)
        },
        clock: () => new Date(Date.parse('2026-10-04T12:00:00Z') + time),
        circuitBreaker: {
          failureThreshold: 1,
          openMs: 10,
          halfOpenSuccesses: 1,
          clock: () => time
        }
      })
      const request = (modelProfile: 'fast' | 'local') => ({
        requestId: 'synthetic-circuit-request',
        correlationId: 'synthetic-circuit-correlation',
        tenantId,
        promptId: 'synthetic-circuit-tuple',
        promptVersion: '1',
        modelProfile,
        dataClassification: 'INTERNAL' as const,
        input: {
          messages: [{ role: 'user' as const, content: 'Synthetic colors.' }]
        }
      })
      await expect(gateway.generate(request('fast'))).rejects.toMatchObject({
        code: 'provider_timeout'
      })
      expect(await gateway.generate(request('local'))).toMatchObject({
        providerId: secondId,
        model: secondModel,
        output: { text: 'blue' }
      })
      expect(firstCalls).toBe(1)
      expect(secondCalls).toBe(1)
      expect(Object.values(gateway.circuitSnapshot()).sort()).toEqual([
        'CLOSED',
        'OPEN'
      ])
      await expect(gateway.generate(request('fast'))).rejects.toMatchObject({
        code: 'circuit_open'
      })
      expect(firstCalls).toBe(1)
      time = 11
      expect(await gateway.generate(request('fast'))).toMatchObject({
        providerId: firstId,
        model: firstModel
      })
      expect(firstCalls).toBe(2)
      expect(await gateway.generate(request('local'))).toMatchObject({
        providerId: secondId,
        model: secondModel
      })
      expect(secondCalls).toBe(2)
      expect(Object.values(gateway.circuitSnapshot())).toEqual([
        'CLOSED',
        'CLOSED'
      ])
      if (firstId === 'synthetic-primary')
        expect(gateway.circuitSnapshot()).toEqual({
          'synthetic-primary:color': 'CLOSED',
          'synthetic-secondary:color': 'CLOSED'
        })
    }
  )
})
