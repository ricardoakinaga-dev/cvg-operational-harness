import { describe, expect, it } from 'vitest'
import { hasUntrustedInstructionContent } from '../state.ts'

// Frozen previous implementation; scoped differential oracle, never runtime.
// SHA256 of complete previous function/comment: e17fa76dff5031b17738708d517a16f1bedefc519d6b135cb9ccad2b308643d9
const previous =
  /ignore\s+(?:all|any|the|previous|prior|earlier|as?|os|todas?)\s*(?:rules?|regras?|instructions?|instruções?)?|desconsid(?:ere|erar)\s+(?:todas?|as)\s+(?:rules?|regras?|instruções?)|system\s+(?:message|prompt)|assistant\s+instructions?|execute\s+(?:the\s+)?(?:hidden|arbitrary|untrusted)?\s*tool|grant\s+approval|override\s+(?:the\s+)?policy|reveal\s+(?:secrets?|credentials?|reasoning)|call\s+hidden\.?capability/i
const phrases = [
  'ignore all',
  'ignore as regras',
  'ignore todas instruções',
  'desconsidere todas as regras',
  'desconsidere todas regras',
  'desconsiderar as instruções',
  'system prompt',
  'system message',
  'assistant instructions',
  'execute tool',
  'execute the hidden tool',
  'execute arbitrarytool',
  'grant approval',
  'override the policy',
  'reveal credentials',
  'reveal secrets',
  'reveal reasoning',
  'call hidden.capability',
  'call hiddencapability',
  'preignore all suffix',
  'ignore\u00a0all',
  'system\u2028prompt',
  'texto institucional aprovado'
]
describe('linear instruction filtering under SPEC0159', () => {
  it.each(phrases)('preserves the frozen result for %s', (text) => {
    expect(hasUntrustedInstructionContent(text)).toBe(previous.test(text))
  })
  it('matches a deterministic Unicode/substring corpus with seed 0xC0DE0159', () => {
    let seed = 0xc0de0159
    const random = () => {
      seed ^= seed << 13
      seed ^= seed >>> 17
      seed ^= seed << 5
      return seed >>> 0
    }
    const spaces = [
      ' ',
      '\t',
      '\n',
      '\u00a0',
      '\u2028',
      '\u2029',
      '\u3000',
      '\ufeff'
    ]
    for (let i = 0; i < 4096; i++) {
      let phrase = phrases[random() % phrases.length]!
      phrase = phrase.replace(/ /g, () =>
        spaces[random() % spaces.length]!.repeat(1 + (random() % 13))
      )
      if (random() % 2) phrase = phrase.toUpperCase()
      const text =
        ['before', '.', 'pre', ''][random() % 4]! +
        phrase +
        ['suffix', '.', 'texto', ''][random() % 4]!
      expect(hasUntrustedInstructionContent(text), `corpus case ${i}`).toBe(
        previous.test(text)
      )
    }
  })
  it.each([2048, 4096, 8192, 16384])(
    'preserves benign long nonmatches at %i UTF16 units',
    (length) => {
      const text = 'execute ' + ' '.repeat(length - 9) + 'x'
      expect(text.length).toBe(length)
      expect(hasUntrustedInstructionContent(text)).toBe(false)
      expect(hasUntrustedInstructionContent(' '.repeat(length))).toBe(false)
    }
  )
  it('rejects oversize input before any scan', () => {
    expect(hasUntrustedInstructionContent('b'.repeat(16384))).toBe(false)
    expect(hasUntrustedInstructionContent('b'.repeat(16385))).toBe(true)
    expect(hasUntrustedInstructionContent('😀'.repeat(8192))).toBe(false)
    expect(hasUntrustedInstructionContent('😀'.repeat(8193))).toBe(true)
  })
})
