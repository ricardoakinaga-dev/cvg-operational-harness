// @vitest-environment node
import { expect, it } from 'vitest'
import { z } from 'zod'
import type { Socket, AddressInfo } from 'node:net'
import type { ModelProvider } from '../contracts.ts'
import { createServer } from 'node:http'
import { once, getEventListeners } from 'node:events'
import {
  ModelGateway,
  OpenAICompatibleProvider,
  PromptRegistry
} from '../index.ts'
import { CircuitBreaker } from '../circuit-breaker.ts'

it.each(['none', 'microtask', 'parse', 'clock'] as const)(
  'benign minimum real Node HALF_OPEN completion boundary stop=%s',
  async (stopAt) => {
    const stop = stopAt !== 'none'
    let providerFinished = false
    const charges: number[] = []
    const caller = new AbortController()
    const sockets = new Set<Socket>()
    const ordering: Array<{
      stage: string
      callerAborted?: boolean
      state?: string
      token?: string
    }> = []
    let calls = 0
    const server = createServer((_req, res) => {
      calls++
      res.end(
        JSON.stringify({
          choices: [
            {
              message: {
                content: stopAt === 'parse' ? '{"color":"blue"}' : 'blue'
              }
            }
          ],
          usage: { prompt_tokens: 8, completion_tokens: 8, total_tokens: 16 }
        })
      )
    })
    server.on('connection', (s) => {
      sockets.add(s)
      s.on('close', () => sockets.delete(s))
    })
    server.listen(0, '127.0.0.1')
    await once(server, 'listening')
    // Seed OPEN at the controlled fixture clock, then cross its cooldown.
    let now = 0
    const c = new CircuitBreaker({
      failureThreshold: 1,
      openMs: 10,
      halfOpenSuccesses: 1,
      clock: () => now
    })
    c.onFailure('minimum:synthetic')
    now = 11
    const real = new OpenAICompatibleProvider({
      id: 'minimum',
      model: 'synthetic',
      location: 'local',
      baseUrl: `http://127.0.0.1:${(server.address() as AddressInfo).port}`,
      allowHttp: true,
      allowPrivateNetworks: true
    })
    const prompts = new PromptRegistry()
    const tenant = 'tenant_00000000-0000-4000-8000-000000000009'
    prompts.register({
      promptId: 'minimum-colors',
      version: '1',
      content: 'Sort fictional colors',
      tenantId: tenant,
      classification: 'INTERNAL',
      owner: 'I1',
      approvedBy: 'synthetic fixture',
      status: 'approved',
      effectiveFrom: '2026-01-01T00:00:00Z'
    })
    // The wrapper preserves the real provider and only schedules the caller interleaving.
    const p: ModelProvider = {
      id: real.id,
      location: real.location,
      models: real.models,
      execute: (req) =>
        real.execute(req).then((result) => {
          ordering.push({
            stage: 'real-provider-result',
            state: c.state('minimum:synthetic'),
            token: typeof c.probeToken('minimum:synthetic')
          })
          providerFinished = true
          if (stopAt === 'microtask')
            queueMicrotask(() => {
              ordering.push({ stage: 'caller-abort' })
              caller.abort(
                new Error(
                  'synthetic caller stop before gateway publishes completion'
                )
              )
            })
          return result
        })
    }
    const g = new ModelGateway({
      providers: [p],
      circuitBreaker: c,
      prompts,
      budget: {
        limits: { request: 1 },
        store: {
          consumed: () => 0,
          consume: (_key, amount) => {
            charges.push(amount)
          }
        }
      },
      clock: () => {
        if (providerFinished && stopAt === 'clock')
          caller.abort(new Error('synthetic stop during completion clock'))
        return new Date('2026-10-04T12:00:00Z')
      },
      profiles: {
        local: {
          name: 'local',
          providerId: 'minimum',
          model: 'synthetic',
          location: 'local',
          temperature: 0,
          maxTokens: 8,
          maxRetries: 0,
          timeoutMs: 1000,
          estimatedCostUsd: 0,
          maxCostUsd: 1,
          pricing: { inputPer1kUsd: 1, outputPer1kUsd: 1 }
        }
      },
      onEvent: (e) =>
        ordering.push({
          stage: e.type,
          callerAborted: caller.signal.aborted,
          state: c.state('minimum:synthetic')
        })
    })
    try {
      const result = await g
        .generate({
          requestId: 'req_minimum',
          correlationId: 'corr_minimum',
          tenantId: tenant,
          promptId: 'minimum-colors',
          promptVersion: '1',
          modelProfile: 'local',
          dataClassification: 'INTERNAL',
          input: {
            messages: [{ role: 'user', content: 'Sort fictional blue red' }]
          },
          signal: caller.signal,
          ...(stopAt === 'parse'
            ? {
                structuredOutput: {
                  schemaName: 'synthetic-colors',
                  schema: z.object({ color: z.string() }).superRefine(() => {
                    caller.abort(
                      new Error('synthetic stop during output validation')
                    )
                  })
                }
              }
            : {})
        })
        .then((r) => ({ text: r.output.text }))
        .catch((e) => ({ code: e.code }))
      await new Promise((r) => setTimeout(r, 20))
      const state = c.state('minimum:synthetic')
      console.log(
        'MINIMUM_BOUNDARY_HEALTH',
        JSON.stringify({
          node: process.version,
          stopAt,
          result,
          ordering,
          finalState: state,
          token: typeof c.probeToken('minimum:synthetic'),
          calls,
          sockets: sockets.size,
          callerListeners: getEventListeners(caller.signal, 'abort').length
        })
      )
      expect(calls).toBe(1)
      expect(sockets.size).toBe(0)
      expect(getEventListeners(caller.signal, 'abort')).toHaveLength(0)
      if (stop) {
        expect(result).toEqual({ code: 'cancelled' })
        expect(charges.filter((amount) => amount > 0)).toHaveLength(0)
        expect(state).toBe('HALF_OPEN')
        expect(c.probeToken('minimum:synthetic')).toBeUndefined()
        expect(ordering.some((x) => x.stage === 'model.call.completed')).toBe(
          false
        )
      } else {
        expect(result).toEqual({ text: 'blue' })
        expect(state).toBe('CLOSED')
        expect(charges.filter((amount) => amount > 0)).toEqual([0.016])
      }
    } finally {
      server.closeAllConnections()
      await new Promise<void>((r) => server.close(() => r()))
    }
  }
)
