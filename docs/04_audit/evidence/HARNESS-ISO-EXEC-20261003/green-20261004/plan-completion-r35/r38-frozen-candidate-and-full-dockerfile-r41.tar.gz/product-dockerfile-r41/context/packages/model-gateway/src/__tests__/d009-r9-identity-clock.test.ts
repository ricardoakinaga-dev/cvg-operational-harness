// @vitest-environment node
import { describe, expect, it, vi } from 'vitest'
import { z } from 'zod'
import {
  ModelGateway,
  PromptRegistry,
  type ModelProvider,
  type PromptRecordInput
} from '../index.ts'

const TENANT = 'tenant_00000000-0000-4000-8000-000000000909'
const NOW = new Date('2026-10-04T12:00:00Z')
const INPUT: PromptRecordInput = {
  promptId: 'authority@v',
  version: '1',
  content: 'Synthetic colors only.',
  owner: 'r9-test',
  approvedBy: 'synthetic-test-only',
  status: 'approved',
  effectiveFrom: '2026-01-01T00:00:00Z',
  effectiveUntil: '2027-01-01T00:00:00Z',
  classification: 'INTERNAL',
  tenantId: TENANT
}

function fixture(
  clock: () => Date,
  budgetEnabled: boolean,
  prompt: Partial<PromptRecordInput> = {}
) {
  const prompts = new PromptRegistry()
  const record = prompts.register({ ...INPUT, ...prompt })
  const execute = vi.fn<ModelProvider['execute']>(async () => ({
    text: '{"color":"blue"}',
    usage: { inputTokens: 1, outputTokens: 0 },
    providerId: 'r9-test',
    model: 'color',
    externalCall: false
  }))
  const store = { consumed: vi.fn(() => 0), consume: vi.fn() }
  const normalizeText = vi.fn((text: string) => text)
  const onEvent = vi.fn()
  const gateway = new ModelGateway({
    prompts,
    clock,
    providers: [
      { id: 'r9-test', location: 'external', models: ['color'], execute }
    ],
    profiles: {
      fast: {
        name: 'fast',
        providerId: 'r9-test',
        model: 'color',
        location: 'external',
        temperature: 0,
        maxTokens: 32,
        timeoutMs: 1000,
        maxCostUsd: 1,
        estimatedCostUsd: 0.6,
        maxRetries: 0,
        pricing: { inputPer1kUsd: 600, outputPer1kUsd: 0 }
      }
    },
    ...(budgetEnabled
      ? { budget: { store, limits: { request: 2, day: 2 } } }
      : {}),
    onEvent
  })
  const request = {
    requestId: 'request-r9-test',
    correlationId: 'correlation-r9-test',
    tenantId: TENANT,
    promptId: record.promptId,
    promptVersion: record.version,
    promptSha256: record.sha256,
    modelProfile: 'fast' as const,
    dataClassification: 'INTERNAL' as const,
    input: {
      messages: [{ role: 'user' as const, content: 'Synthetic colors.' }]
    },
    structuredOutput: {
      schemaName: 'color',
      schema: z.object({ color: z.string() }),
      normalizeText
    }
  }
  return { gateway, request, execute, store, normalizeText, onEvent }
}

const identities = [
  ['authority@v', '1', 'authority', 'v@1'],
  ['a@@b', '@c', 'a@', 'b@@c'],
  ['unicode\u0000@😀', 'x', 'unicode\u0000', '😀@x'],
  ['"a"@', '[b]', '"a"', '@[b]'],
  ['a'.repeat(119) + '@', 'b'.repeat(59), 'a'.repeat(119), '@' + 'b'.repeat(59)]
] as const

describe('D009 R9 exact prompt tuples', () => {
  for (const [id, version, otherId, otherVersion] of identities) {
    it(`does not resolve unregistered tuple ${JSON.stringify([otherId, otherVersion])}`, () => {
      const prompts = new PromptRegistry()
      const original = prompts.register({ ...INPUT, promptId: id, version })
      expect(prompts.get(otherId, otherVersion)).toBeUndefined()
      expect(() =>
        prompts.resolve(
          { promptId: otherId, version: otherVersion, sha256: original.sha256 },
          { at: NOW, tenantId: TENANT }
        )
      ).toThrow(expect.objectContaining({ code: 'prompt_unknown' }))
    })
    for (const metadata of [
      { classification: 'CLINICAL' as const },
      { status: 'revoked' as const },
      { tenantId: 'other-tenant' },
      {
        status: 'draft' as const,
        owner: 'separate-owner',
        approvedBy: 'other-test-only'
      }
    ]) {
      it(`keeps same-content distinct tuple metadata ${JSON.stringify([id, version, metadata])}`, () => {
        const prompts = new PromptRegistry()
        const original = prompts.register({ ...INPUT, promptId: id, version })
        const other = prompts.register({
          ...INPUT,
          promptId: otherId,
          version: otherVersion,
          ...metadata
        })
        expect(other).not.toBe(original)
        expect(other).toMatchObject({
          promptId: otherId,
          version: otherVersion,
          ...metadata
        })
        expect(other.sha256).toBe(original.sha256)
        expect(prompts.get(id, version)).toBe(original)
        expect(prompts.get(otherId, otherVersion)).toBe(other)
        expect(prompts.list()).toEqual([original, other])
        expect(
          prompts.resolve(
            { promptId: id, version },
            { at: NOW, tenantId: TENANT }
          )
        ).toBe(original)
        if ('status' in metadata || 'tenantId' in metadata) {
          const code =
            'status' in metadata
              ? metadata.status === 'revoked'
                ? 'prompt_revoked'
                : 'prompt_not_effective'
              : 'prompt_tenant_mismatch'
          expect(() =>
            prompts.resolve(
              { promptId: otherId, version: otherVersion },
              { at: NOW, tenantId: TENANT }
            )
          ).toThrow(expect.objectContaining({ code }))
        } else {
          expect(
            prompts.resolve(
              { promptId: otherId, version: otherVersion },
              { at: NOW, tenantId: TENANT }
            )
          ).toBe(other)
        }
        expect(Object.isFrozen(original)).toBe(true)
        expect(Object.isFrozen(other)).toBe(true)
      })
    }
  }
  it('retains exact-pair duplicate authority and rejects content replacement', () => {
    const prompts = new PromptRegistry()
    const original = prompts.register(INPUT)
    expect(
      prompts.register({
        ...INPUT,
        status: 'revoked',
        classification: 'CLINICAL'
      })
    ).toBe(original)
    expect(() =>
      prompts.register({ ...INPUT, content: 'Other content.' })
    ).toThrow(expect.objectContaining({ code: 'prompt_duplicate' }))
  })
})

describe('D009 R9 finite execution clock before admission', () => {
  for (const budgetEnabled of [false, true]) {
    for (const effectiveFrom of [
      '2026-01-01T00:00:00Z',
      '2030-01-01T00:00:00Z'
    ]) {
      for (const firstInvalidRead of [1, 2]) {
        it(`denies invalid clock read ${firstInvalidRead}, budget ${budgetEnabled}, effective ${effectiveFrom}`, async () => {
          let reads = 0
          const f = fixture(
            () => (++reads >= firstInvalidRead ? new Date(NaN) : NOW),
            budgetEnabled,
            { effectiveFrom, effectiveUntil: '2031-01-01T00:00:00Z' }
          )
          await expect(f.gateway.generate(f.request)).rejects.toMatchObject({
            code: 'invalid_request',
            retryable: false
          })
          expect(f.execute).not.toHaveBeenCalled()
          expect(f.store.consumed).not.toHaveBeenCalled()
          expect(f.store.consume).not.toHaveBeenCalled()
          expect(f.normalizeText).not.toHaveBeenCalled()
          expect(f.onEvent).not.toHaveBeenCalled()
          expect(f.gateway.circuitSnapshot()).toEqual({})
        })
      }
    }
    it(`valid clock permits real admission, budget ${budgetEnabled}`, async () => {
      const f = fixture(() => NOW, budgetEnabled)
      const result = await f.gateway.generate(f.request)
      expect(result.output.structured).toEqual({ color: 'blue' })
      expect(result.createdAt).toBe(NOW.toISOString())
      expect(f.execute).toHaveBeenCalledTimes(1)
      expect(f.normalizeText).toHaveBeenCalledTimes(1)
      expect(f.store.consume).toHaveBeenCalledTimes(budgetEnabled ? 2 : 0)
    })
    it(`valid clock rejects future approval, budget ${budgetEnabled}`, async () => {
      const f = fixture(() => NOW, budgetEnabled, {
        effectiveFrom: '2030-01-01T00:00:00Z',
        effectiveUntil: '2031-01-01T00:00:00Z'
      })
      await expect(f.gateway.generate(f.request)).rejects.toMatchObject({
        code: 'prompt_unknown'
      })
      expect(f.execute).not.toHaveBeenCalled()
      expect(f.store.consume).not.toHaveBeenCalled()
      expect(f.normalizeText).not.toHaveBeenCalled()
    })
  }
  it('direct public registry resolve refuses NaN', () => {
    const prompts = new PromptRegistry()
    prompts.register({
      ...INPUT,
      effectiveFrom: '2030-01-01T00:00:00Z',
      effectiveUntil: '2031-01-01T00:00:00Z'
    })
    expect(() =>
      prompts.resolve(
        { promptId: INPUT.promptId, version: INPUT.version },
        { at: new Date(NaN) }
      )
    ).toThrow(expect.objectContaining({ code: 'prompt_not_effective' }))
  })
  for (const at of ['2026-01-01T00:00:00Z', '2027-01-01T00:00:00Z']) {
    it(`retains inclusive effectivity boundary ${at}`, () => {
      const prompts = new PromptRegistry()
      const record = prompts.register(INPUT)
      expect(
        prompts.resolve(
          { promptId: record.promptId, version: record.version },
          { at: new Date(at) }
        )
      ).toBe(record)
    })
  }
})
