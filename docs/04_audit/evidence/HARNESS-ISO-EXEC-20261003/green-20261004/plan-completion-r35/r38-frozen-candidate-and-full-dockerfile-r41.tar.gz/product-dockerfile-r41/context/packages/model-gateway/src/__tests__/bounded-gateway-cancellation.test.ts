// @vitest-environment node
import { createServer, type ServerResponse } from 'node:http'
import type { AddressInfo, Socket } from 'node:net'
import { getEventListeners } from 'node:events'
import { expect, it } from 'vitest'
import {
  ModelGateway,
  PromptRegistry,
  OpenAICompatibleProvider,
  InMemoryCostBudgetStore,
  DeterministicModelProvider
} from '../index.ts'
import type {
  ModelProfile,
  ModelGatewayRequest,
  ModelGatewayOptions
} from '../index.ts'

const tenant = 'tenant_00000000-0000-4000-8000-000000000001'
const pause = (ms: number) =>
  new Promise<void>((resolve) => setTimeout(resolve, ms))
function prompt() {
  const p = new PromptRegistry()
  p.register({
    promptId: 'synthetic-colors',
    version: '1',
    content: 'Sort synthetic colors',
    owner: 'test-fixture',
    approvedBy: 'synthetic-test-reviewer',
    status: 'approved',
    effectiveFrom: '2026-01-01T00:00:00.000Z',
    classification: 'INTERNAL',
    tenantId: tenant
  })
  return p
}
function input(
  signal?: AbortSignal
): ModelGatewayRequest & { signal?: AbortSignal } {
  return {
    requestId: 'req_synthetic_gateway',
    correlationId: 'corr_synthetic_gateway',
    tenantId: tenant,
    promptId: 'synthetic-colors',
    promptVersion: '1',
    modelProfile: 'local',
    dataClassification: 'INTERNAL',
    input: {
      messages: [{ role: 'user', content: 'Sort synthetic colors red blue' }]
    },
    ...(signal ? { signal } : {})
  }
}
function profile(overrides: Partial<ModelProfile> = {}): ModelProfile {
  return {
    name: 'local',
    providerId: 'synthetic',
    model: 'synthetic',
    location: 'local',
    temperature: 0,
    maxTokens: 8,
    timeoutMs: 120,
    maxCostUsd: 1,
    estimatedCostUsd: 0.1,
    maxRetries: 0,
    pricing: { inputPer1kUsd: 0, outputPer1kUsd: 0 },
    ...overrides
  }
}
async function fixture(
  handler: (res: ServerResponse) => void,
  run: (url: string, sockets: Set<Socket>, calls: () => number) => Promise<void>
) {
  let n = 0
  const sockets = new Set<Socket>()
  const server = createServer((_req, res) => {
    n++
    handler(res)
  })
  server.on('connection', (s) => {
    sockets.add(s)
    s.on('close', () => sockets.delete(s))
  })
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve))
  try {
    await run(
      `http://127.0.0.1:${(server.address() as AddressInfo).port}`,
      sockets,
      () => n
    )
  } finally {
    server.closeAllConnections()
    await new Promise<void>((resolve) => server.close(() => resolve()))
    await pause(5)
    expect(sockets.size).toBe(0)
  }
}
const provider = (url: string, limit = 1024) =>
  new OpenAICompatibleProvider({
    id: 'synthetic',
    model: 'synthetic',
    location: 'local',
    baseUrl: url,
    allowHttp: true,
    allowPrivateNetworks: true,
    maxResponseBytes: limit
  })
function gateway(url: string, options: Partial<ModelGatewayOptions> = {}) {
  return new ModelGateway({
    providers: [provider(url)],
    profiles: { local: profile() },
    prompts: prompt(),
    ...options
  })
}
it('R14 public generate pre-abort has zero provider/DNS/HTTP/budget/events', async () => {
  await fixture(
    (res) => res.end(),
    async (url, _sockets, calls) => {
      const store = new InMemoryCostBudgetStore()
      let consumed = 0,
        reserved = 0,
        dns = 0,
        providerCalls = 0
      const events: string[] = []
      const actual = provider(url)
      const gateway = new ModelGateway({
        providers: [
          {
            id: actual.id,
            location: actual.location,
            models: actual.models,
            execute: async (request) => {
              providerCalls++
              return actual.execute(request)
            }
          }
        ],
        profiles: { local: profile() },
        prompts: prompt(),
        budget: {
          store: {
            consumed: (key) => {
              consumed++
              return store.consumed(key)
            },
            consume: (key, n) => {
              reserved++
              store.consume(key, n)
            }
          },
          limits: { day: 1 }
        },
        onEvent: (e) => events.push(e.type)
      })
      const controller = new AbortController()
      controller.abort(new Error('synthetic shutdown'))
      await expect(
        gateway.generate(input(controller.signal))
      ).rejects.toMatchObject({ code: 'cancelled', retryable: false })
      expect(providerCalls).toBe(0)
      expect(calls()).toBe(0)
      expect(consumed).toBe(0)
      expect(reserved).toBe(0)
      expect(events).toEqual([])
      // Explicit DNS seam on a real provider, still behind generate's pre-abort fence.
      const dnsProvider = new OpenAICompatibleProvider({
        id: 'synthetic',
        baseUrl: 'https://provider.invalid',
        model: 'synthetic',
        location: 'local',
        dnsLookup: async () => {
          dns++
          return ['127.0.0.1']
        }
      })
      await expect(
        new ModelGateway({
          providers: [dnsProvider],
          profiles: { local: profile() },
          prompts: prompt()
        }).generate(input(controller.signal))
      ).rejects.toMatchObject({ code: 'cancelled' })
      expect(dns).toBe(0)
    }
  )
})
it('R14 abort in started listener prevents execute; retry wait abort cleans listener/timer and forbids fallback', async () => {
  await fixture(
    (res) => {
      res.writeHead(500)
      res.flushHeaders()
    },
    async (url, _sockets, calls) => {
      const controller = new AbortController()
      const events: string[] = []
      const g = gateway(url, {
        onEvent: (e) => {
          events.push(e.type)
          if (e.type === 'model.call.started')
            controller.abort(new Error('synthetic pause'))
        }
      })
      await expect(g.generate(input(controller.signal))).rejects.toMatchObject({
        code: 'cancelled'
      })
      expect(calls()).toBe(0)
      const retryController = new AbortController()
      const baseline = getEventListeners(retryController.signal, 'abort').length
      const retryEvents: string[] = []
      const retryGateway = gateway(url, {
        profiles: {
          local: profile({ maxRetries: 2, fallbackProfile: 'fast' }),
          fast: profile({ name: 'fast', providerId: 'fallback' })
        },
        providers: [
          provider(url),
          new DeterministicModelProvider({ id: 'fallback', model: 'synthetic' })
        ],
        routing: { allowFallback: true },
        retry: { baseDelayMs: 5000, maxDelayMs: 5000, jitterRatio: 0 },
        onEvent: (e) => {
          retryEvents.push(e.type)
          if (e.type === 'model.retry.scheduled')
            setTimeout(
              () => retryController.abort(new Error('synthetic shutdown')),
              20
            )
        }
      })
      const start = performance.now()
      await expect(
        retryGateway.generate(input(retryController.signal))
      ).rejects.toMatchObject({ code: 'cancelled' })
      expect(performance.now() - start).toBeLessThan(1000)
      expect(calls()).toBe(1)
      expect(
        retryEvents.filter((x) => x === 'model.call.started')
      ).toHaveLength(1)
      expect(retryEvents).not.toContain('model.routing.fallback')
      expect(getEventListeners(retryController.signal, 'abort').length).toBe(
        baseline
      )
    }
  )
})
it.each(['deadline', 'caller', 'pause', 'shutdown'])(
  'R15 public gateway -> real Node body suspended: %s and budget reconciliation',
  async (mode) => {
    await fixture(
      (res) => {
        res.writeHead(200)
        res.flushHeaders()
      },
      async (url, sockets, calls) => {
        const controller = new AbortController()
        const reason = new Error(`synthetic ${mode}`)
        const events: string[] = []
        const store = new InMemoryCostBudgetStore()
        let reservations = 0
        const baseline = getEventListeners(controller.signal, 'abort').length
        const g = gateway(url, {
          budget: {
            store: {
              consumed: (key) => store.consumed(key),
              consume: (key, n) => {
                reservations++
                store.consume(key, n)
              }
            },
            limits: { day: 1 }
          },
          onEvent: (e) => events.push(e.type)
        })
        const p = g.generate(input(controller.signal))
        const timer =
          mode === 'deadline'
            ? undefined
            : setTimeout(() => controller.abort(reason), 35)
        try {
          await expect(p).rejects.toMatchObject({
            code: mode === 'deadline' ? 'provider_timeout' : 'cancelled',
            retryable: mode === 'deadline'
          })
        } finally {
          if (timer) clearTimeout(timer)
        }
        await pause(20)
        expect(calls()).toBe(1)
        expect(sockets.size).toBe(0)
        expect(reservations).toBe(1)
        expect(
          store.consumed(
            `day:${tenant}:${new Date().toISOString().slice(0, 10)}`
          )
        ).toBe(0.1)
        expect(getEventListeners(controller.signal, 'abort').length).toBe(
          baseline
        )
        expect(events).not.toContain('model.call.completed')
        expect(events).not.toContain('model.retry.scheduled')
        expect(events).not.toContain('model.routing.fallback')
        if (mode !== 'deadline') expect(controller.signal.reason).toBe(reason)
      }
    )
  }
)
it('R15 deadline then pause retains first reason even when a provider rejects later', async () => {
  // Delay the settlement of the REAL provider promise, never replace its transport.
  await fixture(
    (res) => {
      res.writeHead(200)
      res.flushHeaders()
    },
    async (url, sockets, calls) => {
      const actual = provider(url)
      const caller = new AbortController()
      let reason: unknown
      const g = gateway(url, {
        providers: [
          {
            id: actual.id,
            location: actual.location,
            models: actual.models,
            execute: async (req) => {
              req.signal.addEventListener(
                'abort',
                () => {
                  reason = req.signal.reason
                  caller.abort(new Error('synthetic pause after deadline'))
                },
                { once: true }
              )
              try {
                return await actual.execute(req)
              } catch (error) {
                await pause(20)
                throw error
              }
            }
          }
        ]
      })
      await expect(g.generate(input(caller.signal))).rejects.toMatchObject({
        code: 'provider_timeout'
      })
      expect(reason).toMatchObject({ name: 'TimeoutError' })
      await pause(40)
      expect(calls()).toBe(1)
      expect(sockets.size).toBe(0)
    }
  )
})
it('R13 oversized kind/code is not retryable with either fallback setting; transient fallback remains configured policy', async () => {
  for (const fallback of [false, true])
    await fixture(
      (res) => {
        res.writeHead(200, { 'content-length': '1025' })
        res.flushHeaders()
      },
      async (url, _sockets, calls) => {
        const events: string[] = []
        const g = gateway(url, {
          profiles: {
            local: profile({ maxRetries: 2, fallbackProfile: 'fast' }),
            fast: profile({ name: 'fast', providerId: 'fallback' })
          },
          providers: [
            provider(url),
            new DeterministicModelProvider({
              id: 'fallback',
              model: 'synthetic'
            })
          ],
          routing: { allowFallback: fallback },
          onEvent: (e) => events.push(e.type)
        })
        await expect(g.generate(input())).rejects.toMatchObject({
          code: 'provider_response_too_large',
          retryable: false
        })
        expect(calls()).toBe(1)
        expect(events).not.toContain('model.retry.scheduled')
        expect(events).not.toContain('model.routing.fallback')
        expect(g.circuitSnapshot()).toEqual({ 'synthetic:synthetic': 'CLOSED' })
      }
    )
  await fixture(
    (res) => {
      res.writeHead(500)
      res.flushHeaders()
    },
    async (url, _sockets, calls) => {
      const g = gateway(url, {
        profiles: {
          local: profile({ fallbackProfile: 'fast' }),
          fast: profile({ name: 'fast', providerId: 'fallback' })
        },
        providers: [
          provider(url),
          new DeterministicModelProvider({ id: 'fallback', model: 'synthetic' })
        ],
        routing: { allowFallback: true }
      })
      expect((await g.generate(input())).fallbackUsed).toBe(true)
      expect(calls()).toBe(1)
    }
  )
})
it('R14 CLASSIFICATION-NO-MODEL remains zero provider/budget for a non-aborted restricted class', async () => {
  const store = {
    consumed: () => {
      throw new Error('budget must not be read')
    },
    consume: () => {
      throw new Error('budget must not be written')
    }
  }
  const g = gateway('http://127.0.0.1:9', {
    budget: { store, limits: { day: 1 } }
  })
  await expect(
    g.generate({ ...input(), dataClassification: 'CLINICAL' })
  ).rejects.toMatchObject({ code: 'policy_denied' })
})
