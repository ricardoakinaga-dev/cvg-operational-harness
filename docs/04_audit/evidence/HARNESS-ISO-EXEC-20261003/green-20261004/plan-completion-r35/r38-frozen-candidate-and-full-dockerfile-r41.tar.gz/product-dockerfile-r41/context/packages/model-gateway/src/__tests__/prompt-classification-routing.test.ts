// @vitest-environment node
import { describe, expect, it, vi } from 'vitest'
import { z } from 'zod'
import type { DataClassification } from '@cvg/shared'
import {
  ModelGateway,
  ModelProviderError,
  PromptRegistry,
  type GenerateRequest,
  type ModelProfile,
  type ModelProvider
} from '../index.ts'

const TENANT = 'tenant_00000000-0000-4000-8000-000000000901'
const NOW = new Date('2026-10-04T12:00:00Z')

function fixture(
  classification: DataClassification,
  location: 'local' | 'external',
  fallback = false,
  actualLocalFallback = false
) {
  const prompts = new PromptRegistry()
  const prompt = prompts.register({
    promptId: 'r7-synthetic',
    version: '1',
    content: 'Synthetic classification fixture only.',
    owner: 'fixture',
    approvedBy: 'synthetic-test-only',
    status: 'approved',
    effectiveFrom: '2026-01-01T00:00:00Z',
    classification,
    tenantId: TENANT
  })
  const execute = vi.fn<ModelProvider['execute']>(async (request) => ({
    text: '{"color":"blue"}',
    usage: { inputTokens: 1, outputTokens: 1 },
    providerId:
      actualLocalFallback && request.model === 'fallback'
        ? 'synthetic-local'
        : 'synthetic',
    model: request.model,
    externalCall: false
  }))
  const budget = { consumed: vi.fn(() => 0), consume: vi.fn() }
  const normalizeText = vi.fn((text: string) => text)
  const events: string[] = []
  const profile: ModelProfile = {
    name: 'fast',
    providerId: 'synthetic',
    model: 'primary',
    location,
    temperature: 0,
    maxTokens: 32,
    timeoutMs: 1000,
    maxCostUsd: 1,
    estimatedCostUsd: 0.01,
    maxRetries: 0,
    pricing: { inputPer1kUsd: 0, outputPer1kUsd: 0 },
    ...(fallback ? { fallbackProfile: 'local' as const } : {})
  }
  const gateway = new ModelGateway({
    prompts,
    providers: [
      { id: 'synthetic', location, models: ['primary', 'fallback'], execute },
      ...(actualLocalFallback
        ? [
            {
              id: 'synthetic-local',
              location: 'local' as const,
              models: ['fallback'],
              execute
            }
          ]
        : [])
    ],
    profiles: {
      fast: profile,
      local: {
        ...profile,
        name: 'local',
        location: 'local',
        model: 'fallback',
        providerId: actualLocalFallback ? 'synthetic-local' : profile.providerId
      }
    },
    routing: { allowFallback: fallback, allowLocalSubstitution: fallback },
    budget: { store: budget, limits: { request: 1, day: 1 } },
    clock: () => NOW,
    onEvent: (event) => events.push(event.type)
  })
  // Deliberately omit the field; this exercises the existing wire default.
  const request = {
    requestId: 'request_r7_0001',
    correlationId: 'correlation_r7_0001',
    tenantId: TENANT,
    promptId: prompt.promptId,
    promptVersion: prompt.version,
    promptSha256: prompt.sha256,
    modelProfile: 'fast' as const,
    metadata: { synthetic: 'only' },
    input: {
      messages: [{ role: 'user' as const, content: 'Synthetic fixture only.' }]
    },
    structuredOutput: {
      schemaName: 'neutral',
      schema: z.object({ color: z.string() }),
      normalizeText
    }
  }
  return { gateway, request, prompt, execute, budget, normalizeText, events }
}

type Fixture = ReturnType<typeof fixture>
function withClass(
  f: Fixture,
  classification: string | undefined
): GenerateRequest {
  return (
    classification === undefined
      ? { ...f.request }
      : { ...f.request, dataClassification: classification }
  ) as GenerateRequest
}
function expectUntouched(f: Fixture) {
  expect(f.execute).not.toHaveBeenCalled()
  expect(f.budget.consumed).not.toHaveBeenCalled()
  expect(f.budget.consume).not.toHaveBeenCalled()
  expect(f.normalizeText).not.toHaveBeenCalled()
  expect(f.events).toEqual([])
}

describe('R7 approved prompt classification controls model admission', () => {
  for (const promptClass of ['CLINICAL', 'FINANCIAL', 'CREDENTIAL'] as const) {
    for (const location of ['local', 'external'] as const) {
      it.each([undefined, 'INTERNAL', 'PUBLIC', promptClass])(
        `${promptClass} prompt denies ${location} with request class %s, including fallback/substitution`,
        async (classification) => {
          const f = fixture(promptClass, location, true)
          const request = withClass(f, classification)
          expect(Object.hasOwn(request, 'dataClassification')).toBe(
            classification !== undefined
          )
          await expect(f.gateway.generate(request)).rejects.toMatchObject({
            code: 'policy_denied',
            retryable: false
          })
          expectUntouched(f)
        }
      )
    }
  }

  it.each(['CLINICAL', 'INTERNAL'] as const)(
    'literal UNKNOWN remains invalid for approved %s prompt with zero effects',
    async (promptClass) => {
      const f = fixture(promptClass, 'local', true)
      const request = withClass(f, 'UNKNOWN')
      expect(request.dataClassification).toBe('UNKNOWN')
      await expect(f.gateway.generate(request)).rejects.toMatchObject({
        code: 'invalid_request'
      })
      expectUntouched(f)
    }
  )

  for (const location of ['local', 'external'] as const) {
    it.each([undefined, 'INTERNAL', 'PUBLIC'])(
      `INTERNAL approved prompt preserves ${location} positive request class %s`,
      async (classification) => {
        const f = fixture('INTERNAL', location)
        const request = withClass(f, classification)
        const result = await f.gateway.generate(request)
        expect(result).toMatchObject({
          requestId: request.requestId,
          tenantId: TENANT,
          correlationId: request.correlationId,
          promptSha256: f.prompt.sha256,
          profile: 'fast',
          fallbackUsed: false,
          attempts: 1,
          output: { text: '{"color":"blue"}', structured: { color: 'blue' } }
        })
        expect(f.execute).toHaveBeenCalledOnce()
        expect(f.execute.mock.calls[0]![0]).toMatchObject({
          promptSha256: f.prompt.sha256,
          metadata: { synthetic: 'only' },
          structuredSchemaName: 'neutral'
        })
        expect(f.budget.consume).toHaveBeenCalledTimes(2)
        expect(f.normalizeText).toHaveBeenCalledOnce()
        expect(f.events).toEqual(['model.call.started', 'model.call.completed'])
        expect(Object.hasOwn(request, 'dataClassification')).toBe(
          classification !== undefined
        )
      }
    )
  }

  it.each(['CONFIDENTIAL', 'CLINICAL', 'FINANCIAL', 'CREDENTIAL'])(
    'request %s exceeding approved INTERNAL prompt stays denied',
    async (classification) => {
      const f = fixture('INTERNAL', 'local', true)
      await expect(
        f.gateway.generate(withClass(f, classification))
      ).rejects.toMatchObject({ code: 'policy_denied' })
      expectUntouched(f)
    }
  )

  it.each([undefined, 'INTERNAL', 'PUBLIC', 'CONFIDENTIAL'])(
    'CONFIDENTIAL approved prompt denies external placement for caller %s',
    async (classification) => {
      const f = fixture('CONFIDENTIAL', 'external')
      await expect(
        f.gateway.generate(withClass(f, classification))
      ).rejects.toMatchObject({ code: 'policy_denied' })
      expectUntouched(f)
    }
  )

  it('CONFIDENTIAL prompt substitutes only to local and preserves the prompt hash/result/metadata', async () => {
    const f = fixture('CONFIDENTIAL', 'external', true, true)
    const result = await f.gateway.generate(withClass(f, undefined))
    expect(result).toMatchObject({
      profile: 'local',
      substitutedProfile: 'fast',
      promptSha256: f.prompt.sha256
    })
    expect(f.execute.mock.calls[0]![0]).toMatchObject({
      model: 'fallback',
      promptSha256: f.prompt.sha256,
      metadata: { synthetic: 'only' }
    })
    expect(f.events).toEqual([
      'model.routing.substituted',
      'model.call.started',
      'model.call.completed'
    ])
  })

  it('INTERNAL positive fallback retains approved prompt and caller metadata after primary failure', async () => {
    const f = fixture('INTERNAL', 'external', true)
    f.execute.mockRejectedValueOnce(
      new ModelProviderError(
        'synthetic',
        'unavailable',
        'Synthetic failure',
        503
      )
    )
    const result = await f.gateway.generate(withClass(f, undefined))
    expect(result).toMatchObject({
      profile: 'local',
      fallbackUsed: true,
      promptSha256: f.prompt.sha256,
      output: { structured: { color: 'blue' } }
    })
    expect(f.execute.mock.calls.map(([request]) => request.model)).toEqual([
      'primary',
      'fallback'
    ])
    for (const [request] of f.execute.mock.calls)
      expect(request).toMatchObject({
        promptSha256: f.prompt.sha256,
        metadata: { synthetic: 'only' }
      })
    expect(f.normalizeText).toHaveBeenCalledOnce()
    expect(f.events).toContain('model.routing.fallback')
  })
})
