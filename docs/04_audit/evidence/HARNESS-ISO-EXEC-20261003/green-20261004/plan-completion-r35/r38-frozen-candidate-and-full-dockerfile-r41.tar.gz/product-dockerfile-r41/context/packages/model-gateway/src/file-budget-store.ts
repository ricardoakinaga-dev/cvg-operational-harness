import { createHash, randomUUID } from 'node:crypto'
import * as fs from 'node:fs'
import { dirname, join, parse, resolve } from 'node:path'
import type { CostBudgetStore } from './budget.ts'
import { ModelGatewayError } from './errors.ts'

const GENESIS = '0'.repeat(64)
const TENANT = 'tenant_[0-9a-f-]{36}'
const SCOPES = new RegExp(
  `^(request:[^:\\r\\n]{1,120}|tenant:${TENANT}|(?:session|agent):${TENANT}:[^:\\r\\n]{1,120}|day:${TENANT}:\\d{4}-\\d{2}-\\d{2})$`
)

export function usdToMicrousd(usd: number, rounding: 'ceil' | 'floor'): number {
  if (!Number.isFinite(usd) || usd < 0) throw unavailable()
  // Interpret the API's decimal number once, avoiding binary multiplication
  // adding a phantom microUSD to an already rounded reservation.
  const [mantissa = '0', exponent = '0'] = usd.toString().split('e')
  const fractional = mantissa.split('.')[1]?.length ?? 0
  const digits = BigInt(mantissa.replace('.', ''))
  const scale = 6 + Number(exponent) - fractional
  let value: bigint
  if (scale >= 0) value = digits * 10n ** BigInt(scale)
  else {
    const divisor = 10n ** BigInt(-scale)
    value = digits / divisor
    if (rounding === 'ceil' && digits % divisor !== 0n) value += 1n
  }
  if (value > BigInt(Number.MAX_SAFE_INTEGER)) throw unavailable()
  return Number(value)
}

function unavailable(): ModelGatewayError {
  return new ModelGatewayError(
    'budget_store_unavailable',
    'Cost budget requires replay or explicit offline reconciliation',
    { status: 503 }
  )
}

function validScope(key: string): boolean {
  if (!SCOPES.test(key)) return false
  if (!key.startsWith('day:')) return true
  const day = key.slice(-10)
  const at = new Date(`${day}T00:00:00.000Z`)
  return Number.isFinite(at.getTime()) && at.toISOString().slice(0, 10) === day
}

interface LedgerBody {
  version: 1
  sequence: number
  scopeKey: string
  amountMicrousd: number
  totalMicrousd: number
  previousHash: string
}

export interface CostLedgerHead {
  sequence: number
  hash: string
}

export interface FileCostBudgetStoreOptions {
  directory: string
  /** Set for any restored/copied ledger. A trusted latest head is mandatory. */
  restore?: { reconciledHead?: CostLedgerHead }
  /** Trusted synchronous filesystem hooks for deterministic fault tests. */
  io?: Partial<Pick<typeof fs, 'writeSync' | 'fsyncSync'>>
}

/** Local single-writer ledger. A stale lock is an operator boundary, never a lease. */
export class FileCostBudgetStore implements CostBudgetStore {
  readonly durable = true
  readonly directory: string
  readonly #totals = new Map<string, number>()
  readonly #write: typeof fs.writeSync
  readonly #sync: typeof fs.fsyncSync
  readonly #lockPath: string
  #fd: number | undefined
  #directoryFd: number | undefined
  #head: CostLedgerHead = { sequence: 0, hash: GENESIS }
  #latestDay = ''
  #ready = false
  #reason = 'budget_store_unavailable'
  #ownsLock = false

  constructor(options: FileCostBudgetStoreOptions) {
    this.directory = resolve(options.directory)
    this.#lockPath = join(this.directory, 'writer.lock')
    this.#write = options.io?.writeSync ?? fs.writeSync
    this.#sync = options.io?.fsyncSync ?? fs.fsyncSync
    try {
      ensurePhysicalDirectory(this.directory)
      this.#directoryFd = fs.openSync(
        this.directory,
        fs.constants.O_RDONLY |
          fs.constants.O_DIRECTORY |
          fs.constants.O_NOFOLLOW
      )
      const lock = fs.openSync(
        this.#lockPath,
        fs.constants.O_WRONLY |
          fs.constants.O_CREAT |
          fs.constants.O_EXCL |
          fs.constants.O_NOFOLLOW,
        0o600
      )
      this.#ownsLock = true
      try {
        privateFile(lock)
        this.#writeAll(
          lock,
          Buffer.from(
            JSON.stringify({
              version: 1,
              writerId: randomUUID(),
              pid: process.pid
            }) + '\n'
          )
        )
        this.#sync(lock)
        this.#sync(this.#directoryFd)
      } finally {
        fs.closeSync(lock)
      }
      const ledger = join(this.directory, 'ledger.jsonl')
      try {
        this.#fd = fs.openSync(
          ledger,
          fs.constants.O_RDWR |
            fs.constants.O_APPEND |
            fs.constants.O_CREAT |
            fs.constants.O_EXCL |
            fs.constants.O_NOFOLLOW,
          0o600
        )
        this.#sync(this.#fd)
        this.#sync(this.#directoryFd)
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== 'EEXIST') throw error
        this.#fd = fs.openSync(
          ledger,
          fs.constants.O_RDWR | fs.constants.O_APPEND | fs.constants.O_NOFOLLOW
        )
      }
      privateFile(this.#fd)
      this.#replay(fs.readFileSync(this.#fd))
      if (options.restore) {
        const trusted = options.restore.reconciledHead
        if (
          !trusted ||
          trusted.sequence !== this.#head.sequence ||
          trusted.hash !== this.#head.hash
        )
          throw unavailable()
      }
      this.#ready = true
      this.#reason = ''
    } catch {
      this.#closeDescriptors()
      // Retain any acquired lock and every ledger byte. Startup uncertainty is not a refund.
      throw unavailable()
    }
  }

  health(): { ready: boolean; reasonCodes: string[]; uncertain: boolean } {
    return {
      ready: this.#ready,
      reasonCodes: this.#ready ? [] : [this.#reason],
      uncertain: !this.#ready && this.#reason !== 'budget_store_closed'
    }
  }

  head(): CostLedgerHead {
    this.#assertReady()
    return { ...this.#head }
  }

  checkDay(now: Date): void {
    this.#assertReady()
    try {
      const day = now.toISOString().slice(0, 10)
      if (day < this.#latestDay) throw unavailable()
      this.#latestDay = day
    } catch {
      this.#fail()
    }
  }

  consumed(scopeKey: string): number {
    return this.consumedMicrousd(scopeKey) / 1_000_000
  }

  consumedMicrousd(scopeKey: string): number {
    this.#assertReady()
    if (!validScope(scopeKey)) this.#fail()
    return this.#totals.get(scopeKey) ?? 0
  }

  consume(scopeKey: string, amountUsd: number): void {
    this.#assertReady()
    try {
      if (!validScope(scopeKey)) throw unavailable()
      if (scopeKey.startsWith('day:'))
        this.checkDay(new Date(`${scopeKey.slice(-10)}T00:00:00.000Z`))
      const amount = usdToMicrousd(amountUsd, 'ceil')
      const total = (this.#totals.get(scopeKey) ?? 0) + amount
      const sequence = this.#head.sequence + 1
      if (!Number.isSafeInteger(total) || !Number.isSafeInteger(sequence))
        throw unavailable()
      const body: LedgerBody = {
        version: 1,
        sequence,
        scopeKey,
        amountMicrousd: amount,
        totalMicrousd: total,
        previousHash: this.#head.hash
      }
      const hash = digest(Buffer.from(JSON.stringify(body)))
      this.#writeAll(
        this.#fd!,
        Buffer.from(JSON.stringify({ ...body, hash }) + '\n')
      )
      this.#sync(this.#fd!)
      // Publish only after the complete append is durable.
      this.#totals.set(scopeKey, total)
      this.#head = { sequence, hash }
    } catch {
      this.#fail()
    }
  }

  close(): void {
    const clean = this.#ready
    this.#ready = false
    if (clean) this.#reason = 'budget_store_closed'
    try {
      if (clean && this.#ownsLock) {
        fs.unlinkSync(this.#lockPath)
        this.#ownsLock = false
        this.#sync(this.#directoryFd!)
      }
    } catch {
      this.#reason = 'budget_store_unavailable'
      throw unavailable()
    } finally {
      this.#closeDescriptors()
    }
  }

  #replay(bytes: Buffer): void {
    const lastNewline = bytes.lastIndexOf(10)
    if (bytes.length > 0 && lastNewline !== bytes.length - 1) {
      const tail = bytes.subarray(lastNewline + 1)
      const evidence = join(this.directory, `recovery-tail-${digest(tail)}.bin`)
      let fd: number | undefined
      try {
        fd = fs.openSync(evidence, 'wx', 0o600)
        this.#writeAll(fd, tail)
        this.#sync(fd)
        this.#sync(this.#directoryFd!)
      } catch (error) {
        if (
          (error as NodeJS.ErrnoException).code !== 'EEXIST' ||
          !fs.readFileSync(evidence).equals(tail)
        )
          throw error
      } finally {
        if (fd !== undefined) fs.closeSync(fd)
      }
      throw unavailable()
    }
    if (!bytes.length) return
    const utf8 = new TextDecoder('utf-8', { fatal: true }).decode(bytes)
    for (const line of utf8.slice(0, -1).split('\n')) {
      const value = JSON.parse(line) as LedgerBody & { hash: string }
      if (
        !value ||
        Object.keys(value).sort().join(',') !==
          'amountMicrousd,hash,previousHash,scopeKey,sequence,totalMicrousd,version'
      )
        throw unavailable()
      const {
        version,
        sequence,
        scopeKey,
        amountMicrousd,
        totalMicrousd,
        previousHash,
        hash
      } = value
      if (
        version !== 1 ||
        sequence !== this.#head.sequence + 1 ||
        !Number.isSafeInteger(sequence) ||
        typeof scopeKey !== 'string' ||
        !validScope(scopeKey) ||
        !Number.isSafeInteger(amountMicrousd) ||
        amountMicrousd < 0 ||
        !Number.isSafeInteger(totalMicrousd) ||
        totalMicrousd < 0 ||
        previousHash !== this.#head.hash
      )
        throw unavailable()
      const sum = (this.#totals.get(scopeKey) ?? 0) + amountMicrousd
      const body: LedgerBody = {
        version,
        sequence,
        scopeKey,
        amountMicrousd,
        totalMicrousd,
        previousHash
      }
      if (
        !Number.isSafeInteger(sum) ||
        sum !== totalMicrousd ||
        hash !== digest(Buffer.from(JSON.stringify(body))) ||
        line !== JSON.stringify({ ...body, hash })
      )
        throw unavailable()
      this.#totals.set(scopeKey, sum)
      this.#head = { sequence, hash }
      if (scopeKey.startsWith('day:'))
        this.#latestDay = [this.#latestDay, scopeKey.slice(-10)].sort()[1]!
    }
  }

  #writeAll(fd: number, bytes: Buffer): void {
    let offset = 0
    while (offset < bytes.length) {
      const written = this.#write(
        fd,
        bytes,
        offset,
        bytes.length - offset,
        null
      )
      if (
        !Number.isSafeInteger(written) ||
        written <= 0 ||
        written > bytes.length - offset
      )
        throw unavailable()
      offset += written
    }
  }

  #assertReady(): void {
    if (!this.#ready) throw unavailable()
  }

  #fail(): never {
    this.#ready = false
    this.#reason = 'budget_store_unavailable'
    throw unavailable()
  }

  #closeDescriptors(): void {
    for (const fd of [this.#fd, this.#directoryFd]) {
      if (fd !== undefined) fs.closeSync(fd)
    }
    this.#fd = undefined
    this.#directoryFd = undefined
  }
}

function digest(bytes: Buffer): string {
  return createHash('sha256').update(bytes).digest('hex')
}

function privateFile(fd: number): void {
  const st = fs.fstatSync(fd)
  if (
    !st.isFile() ||
    st.nlink !== 1 ||
    st.uid !== process.getuid?.() ||
    (st.mode & 0o777) !== 0o600
  )
    throw unavailable()
}

function ensurePhysicalDirectory(directory: string): void {
  const root = parse(directory).root
  let current = root
  const parts = directory.slice(root.length).split('/').filter(Boolean)
  for (const part of parts) {
    current = join(current, part)
    try {
      fs.mkdirSync(current, { mode: 0o700 })
      const parentFd = fs.openSync(
        dirname(current),
        fs.constants.O_RDONLY |
          fs.constants.O_DIRECTORY |
          fs.constants.O_NOFOLLOW
      )
      try {
        fs.fsyncSync(parentFd)
      } finally {
        fs.closeSync(parentFd)
      }
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'EEXIST') throw error
    }
    const st = fs.lstatSync(current)
    if (!st.isDirectory() || st.isSymbolicLink()) throw unavailable()
    // Parent paths must be physical and trusted; the owned cost root is always 0700.
    if ((st.mode & 0o002) !== 0 && (st.mode & 0o1000) === 0) throw unavailable()
    if (
      (st.mode & 0o020) !== 0 &&
      st.uid !== process.getuid?.() &&
      (st.mode & 0o1000) === 0
    )
      throw unavailable()
  }
  const st = fs.lstatSync(directory)
  if (st.uid !== process.getuid?.() || (st.mode & 0o777) !== 0o700)
    throw unavailable()
}
