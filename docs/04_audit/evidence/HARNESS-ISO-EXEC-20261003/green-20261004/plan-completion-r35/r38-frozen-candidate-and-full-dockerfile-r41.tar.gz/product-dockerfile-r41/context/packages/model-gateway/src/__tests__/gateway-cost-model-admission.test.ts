// @vitest-environment node
import { describe, expect, it } from 'vitest'
import { z } from 'zod'
import {
  ModelGateway,
  ModelProviderError,
  PromptRegistry,
  type CostBudgetLimits,
  type GenerateRequest,
  type ModelProfile,
  type ModelProvider
} from '../index.ts'

const tenantId = 'tenant_00000000-0000-4000-8000-000000000180'
const now = new Date('2026-10-04T12:00:00Z')

function profile(overrides: Partial<ModelProfile> = {}): ModelProfile {
  return {
    name: 'fast',
    providerId: 'cost-model',
    model: 'color',
    location: 'local',
    temperature: 0,
    maxTokens: 10,
    timeoutMs: 1000,
    maxRetries: 0,
    maxCostUsd: 2,
    estimatedCostUsd: 0.6,
    pricing: { inputPer1kUsd: 600, outputPer1kUsd: 0 },
    ...overrides
  }
}

function fixture(
  options: {
    profile?: Partial<ModelProfile>
    fallback?: Partial<ModelProfile>
    limits?: CostBudgetLimits
    withoutBudget?: boolean
    models?: string[]
    failPrimary?: boolean
    failOnce?: boolean
    wrongResultModel?: boolean
    sleep?: (ms: number) => Promise<void>
  } = {}
) {
  const counts = { provider: 0, reads: 0, writes: 0, normalizer: 0 }
  const reservations: number[] = []
  const attemptedModels: string[] = []
  const events: string[] = []
  const prompts = new PromptRegistry()
  const prompt = prompts.register({
    promptId: 'cost-model-fixture',
    version: '1',
    content: 'Synthetic colors only.',
    owner: 'fixture',
    approvedBy: 'synthetic-only',
    status: 'approved',
    classification: 'INTERNAL',
    tenantId,
    effectiveFrom: '2026-01-01T00:00:00Z'
  })
  const provider: ModelProvider = {
    id: 'cost-model',
    location: 'local',
    models: options.models ?? ['color', 'backup'],
    async execute(request) {
      counts.provider++
      attemptedModels.push(request.model)
      if (
        (options.failPrimary && request.model === 'color') ||
        (options.failOnce && counts.provider === 1)
      )
        throw new ModelProviderError('cost-model', 'unavailable', 'fixture')
      return {
        providerId: 'cost-model',
        model: options.wrongResultModel ? 'alias' : request.model,
        text: '{"color":"blue"}',
        usage: { inputTokens: 1, outputTokens: 0 },
        externalCall: false
      }
    }
  }
  const primary = profile(options.profile)
  const fallback = profile({
    name: 'balanced',
    model: 'backup',
    ...options.fallback
  })
  const limits = options.limits ?? { request: 2, day: 4 }
  const gateway = new ModelGateway({
    providers: [provider],
    profiles: {
      fast: primary,
      ...(options.fallback ? { balanced: fallback } : {})
    },
    prompts,
    routing: { allowFallback: true },
    retry: { baseDelayMs: 1, maxDelayMs: 1, jitterRatio: 0 },
    ...(options.sleep ? { sleep: options.sleep } : {}),
    ...(options.withoutBudget
      ? {}
      : {
          budget: {
            limits,
            store: {
              consumed: () => {
                counts.reads++
                return 0
              },
              consume: (_key: string, amount: number) => {
                counts.writes++
                reservations.push(amount)
              }
            }
          }
        }),
    clock: () => now,
    onEvent: (event) => events.push(event.type)
  })
  const request: GenerateRequest = {
    requestId: 'cost-model-request',
    correlationId: 'cost-model-correlation',
    tenantId,
    promptId: prompt.promptId,
    promptVersion: prompt.version,
    promptSha256: prompt.sha256,
    modelProfile: 'fast',
    dataClassification: 'INTERNAL',
    input: { messages: [{ role: 'user', content: 'Synthetic colors.' }] },
    structuredOutput: {
      schemaName: 'color',
      schema: z.object({ color: z.string() }),
      normalizeText: (text) => {
        counts.normalizer++
        return text
      }
    }
  }
  return {
    gateway,
    request,
    counts,
    events,
    reservations,
    attemptedModels,
    primary,
    limits
  }
}

function expectNoWork(f: ReturnType<typeof fixture>) {
  expect(f.counts).toEqual({ provider: 0, reads: 0, writes: 0, normalizer: 0 })
  expect(f.events).not.toContain('model.call.started')
  expect(f.events).not.toContain('model.retry.scheduled')
  expect(f.events).not.toContain('model.routing.fallback')
  expect(f.gateway.circuitSnapshot()).toEqual({})
}

describe('approved cost and exact model admission', () => {
  for (const capSource of ['request', 'profile', 'budget'] as const) {
    for (const cap of [0, 0.5, 0.6, 0.8]) {
      for (const estimate of [undefined, 0, 0.1, 0.6, 0.8]) {
        it(`${capSource} cap ${cap}, request estimate ${estimate}`, async () => {
          const f = fixture({
            ...(capSource === 'profile'
              ? { profile: { maxCostUsd: cap } }
              : {}),
            ...(capSource === 'budget'
              ? { limits: { request: cap, day: 4 } }
              : {})
          })
          const bound = Math.max(0.6, estimate ?? 0)
          const call = f.gateway.generate({
            ...f.request,
            ...(capSource === 'request' ? { maxCostUsd: cap } : {}),
            ...(estimate !== undefined ? { estimatedCostUsd: estimate } : {})
          })
          if (bound > cap) {
            await expect(call).rejects.toMatchObject({
              code: 'budget_exceeded',
              retryable: false
            })
            expectNoWork(f)
          } else {
            await expect(call).resolves.toMatchObject({
              model: 'color',
              costUsd: 0.6,
              attempts: 1,
              fallbackUsed: false
            })
            expect(f.reservations).toEqual([bound, bound])
            expect(f.counts.provider).toBe(1)
            expect(f.counts.normalizer).toBe(1)
          }
        })
      }
    }
  }

  for (const capSource of ['request', 'profile', 'budget'] as const) {
    it(`zero ${capSource} admits a zero bound`, async () => {
      const f = fixture({
        profile: {
          estimatedCostUsd: 0,
          pricing: { inputPer1kUsd: 0, outputPer1kUsd: 0 },
          ...(capSource === 'profile' ? { maxCostUsd: 0 } : {})
        },
        ...(capSource === 'budget' ? { limits: { request: 0, day: 0 } } : {})
      })
      await expect(
        f.gateway.generate({
          ...f.request,
          estimatedCostUsd: 0,
          ...(capSource === 'request' ? { maxCostUsd: 0 } : {})
        })
      ).resolves.toMatchObject({ costUsd: 0 })
      expect(f.counts.provider).toBe(1)
      expect(f.reservations).toEqual([0, 0])
    })
  }

  for (const field of [
    'requestCap',
    'requestEstimate',
    'profileCap',
    'profileEstimate',
    'budgetCap'
  ] as const) {
    for (const value of [NaN, Infinity, -Infinity, -1, null, '0.6']) {
      it(`rejects ${field} ${String(value)} without work`, async () => {
        const f = fixture()
        // Deliberately exercise invalid host configuration at the JS boundary.
        const options: Parameters<typeof fixture>[0] = {}
        if (field === 'profileCap' || field === 'profileEstimate') {
          options.profile = {}
          Reflect.set(
            options.profile,
            field === 'profileCap' ? 'maxCostUsd' : 'estimatedCostUsd',
            value
          )
        }
        if (field === 'budgetCap') {
          options.limits = { day: 4 }
          Reflect.set(options.limits, 'request', value)
        }
        const configured = field.startsWith('request') ? f : fixture(options)
        const request = { ...configured.request }
        if (field.startsWith('request'))
          Reflect.set(
            request,
            field === 'requestCap' ? 'maxCostUsd' : 'estimatedCostUsd',
            value
          )
        await expect(
          configured.gateway.generate(request)
        ).rejects.toMatchObject({
          code: 'invalid_request',
          retryable: false
        })
        expectNoWork(configured)
      })
    }
  }

  for (const field of ['maxCostUsd', 'estimatedCostUsd'] as const) {
    it(`requires profile ${field}`, async () => {
      const overrides = { [field]: undefined }
      const options = { profile: {} }
      Object.assign(options.profile, overrides)
      const f = fixture(options)
      await expect(f.gateway.generate(f.request)).rejects.toMatchObject({
        code: 'invalid_request'
      })
      expectNoWork(f)
    })
  }

  for (const withoutBudget of [false, true]) {
    it(`missing request cap keeps profile cap; budget absent ${withoutBudget}`, async () => {
      const f = fixture({ withoutBudget, profile: { maxCostUsd: 0.5 } })
      await expect(f.gateway.generate(f.request)).rejects.toMatchObject({
        code: 'budget_exceeded'
      })
      expectNoWork(f)
    })
    it(`missing request fields remain optional; budget absent ${withoutBudget}`, async () => {
      const f = fixture({ withoutBudget, limits: { day: 4 } })
      await expect(f.gateway.generate(f.request)).resolves.toMatchObject({
        costUsd: 0.6
      })
      expect(f.counts.provider).toBe(1)
    })
  }

  it('snapshots BudgetGuard limits independently of the caller', async () => {
    const f = fixture({ limits: { request: 0.5, day: 4 } })
    f.limits.request = 2
    await expect(f.gateway.generate(f.request)).rejects.toMatchObject({
      code: 'budget_exceeded'
    })
    expectNoWork(f)
    const g = fixture({ limits: { request: 2, day: 0.5 } })
    g.limits.day = 4
    await expect(g.gateway.generate(g.request)).rejects.toMatchObject({
      code: 'budget_exceeded'
    })
    expect(g.counts.writes).toBe(0)
    expect(g.counts.provider).toBe(0)
  })

  for (const model of ['unknown', 'Color', 'color ', 'COLOR', '']) {
    it(`model ${JSON.stringify(model)} is an exact member before reserve`, async () => {
      const f = fixture({ profile: { model } })
      await expect(f.gateway.generate(f.request)).rejects.toMatchObject({
        code: 'provider_invalid_request',
        retryable: false
      })
      expectNoWork(f)
    })
  }

  it('rejects result aliases before normalizing or publishing completion', async () => {
    const f = fixture({ wrongResultModel: true })
    await expect(f.gateway.generate(f.request)).rejects.toMatchObject({
      code: 'provider_malformed_response'
    })
    expect(f.counts.normalizer).toBe(0)
    expect(f.events).not.toContain('model.call.completed')
  })

  for (const fallback of [
    { maxCostUsd: 0.5 },
    { estimatedCostUsd: 0.8 },
    { model: 'unannounced' },
    { maxCostUsd: NaN }
  ]) {
    it(`revalidates fallback ${JSON.stringify(fallback)}`, async () => {
      const f = fixture({
        profile: { fallbackProfile: 'balanced' },
        fallback,
        failPrimary: true
      })
      await expect(
        f.gateway.generate({ ...f.request, maxCostUsd: 0.6 })
      ).rejects.toMatchObject({
        code:
          'model' in fallback
            ? 'provider_invalid_request'
            : Number.isNaN(fallback.maxCostUsd)
              ? 'invalid_request'
              : 'budget_exceeded'
      })
      expect(f.counts.provider).toBe(1)
      expect(f.counts.writes).toBe(2)
      expect(f.counts.normalizer).toBe(0)
      expect(f.attemptedModels).toEqual(['color'])
    })
  }

  it('keeps legitimate fallback identity and its own pricing', async () => {
    const f = fixture({
      profile: { fallbackProfile: 'balanced' },
      fallback: {
        estimatedCostUsd: 0.8,
        pricing: { inputPer1kUsd: 800, outputPer1kUsd: 0 }
      },
      failPrimary: true
    })
    await expect(
      f.gateway.generate({ ...f.request, maxCostUsd: 0.8 })
    ).resolves.toMatchObject({
      profile: 'balanced',
      model: 'backup',
      costUsd: 0.8,
      fallbackUsed: true
    })
    expect(f.reservations).toEqual([0.6, 0.6, 0.8, 0.8])
  })

  it('keeps retry and circuit transitions for admitted models', async () => {
    const f = fixture({ profile: { maxRetries: 1 }, failOnce: true })
    await expect(f.gateway.generate(f.request)).resolves.toMatchObject({
      attempts: 2
    })
    expect(f.reservations).toEqual([0.6, 0.6])
    expect(f.events).toContain('model.retry.scheduled')
    expect(f.gateway.circuitSnapshot()).toEqual({
      'cost-model:color': 'CLOSED'
    })
  })

  it('pre-abort wins over invalid cost/model and reserves nothing', async () => {
    const f = fixture({ profile: { model: 'unknown', maxCostUsd: NaN } })
    const controller = new AbortController()
    controller.abort()
    await expect(
      f.gateway.generate({ ...f.request, signal: controller.signal })
    ).rejects.toMatchObject({ code: 'cancelled' })
    expectNoWork(f)
  })

  it('cancel during retry wait prevents further attempts and fallback', async () => {
    const controller = new AbortController()
    const f = fixture({
      profile: { maxRetries: 1, fallbackProfile: 'balanced' },
      fallback: {},
      failPrimary: true,
      sleep: async () => {
        controller.abort(new Error('synthetic shutdown'))
      }
    })
    await expect(
      f.gateway.generate({ ...f.request, signal: controller.signal })
    ).rejects.toMatchObject({ code: 'cancelled' })
    expect(f.counts.provider).toBe(1)
    expect(f.reservations).toEqual([0.6, 0.6])
    expect(f.events).not.toContain('model.routing.fallback')
  })
})
