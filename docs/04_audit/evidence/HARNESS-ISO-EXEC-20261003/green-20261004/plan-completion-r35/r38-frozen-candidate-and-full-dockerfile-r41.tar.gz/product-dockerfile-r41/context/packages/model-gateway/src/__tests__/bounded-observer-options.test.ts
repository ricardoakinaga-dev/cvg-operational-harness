// @vitest-environment node
import { expect, it } from 'vitest'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

it.each([
  ['options', 'sync'],
  ['options', 'async'],
  ['instance', 'sync'],
  ['instance', 'async']
])(
  'circuit observer %s/%s cannot crash Node after success',
  (composition, mode) => {
    const result = spawnSync(
      process.execPath,
      [
        '--unhandled-rejections=strict',
        '--import',
        'tsx',
        fileURLToPath(
          new URL('./fixtures/observer-options-child.mjs', import.meta.url)
        ),
        composition!,
        mode!
      ],
      {
        cwd: process.cwd(),
        env: {
          PATH: process.env.PATH,
          NODE_ENV: 'test',
          TZ: 'UTC',
          TSX_CACHE_DIR: process.env.TSX_CACHE_DIR ?? process.env.TMPDIR
        },
        encoding: 'utf8',
        timeout: 10000
      }
    )
    expect(result.error).toBeUndefined()
    expect(result.status, result.stderr).toBe(0)
    const proof = JSON.parse(result.stdout.trim())
    expect(proof).toEqual({
      composition,
      failureMode: mode,
      calls: 2,
      completed: 1,
      initialFailure: 1,
      charges: [0.016, 0.016],
      observerFailures: 1,
      listeners: 0,
      status: 'PASS'
    })
  }
)
