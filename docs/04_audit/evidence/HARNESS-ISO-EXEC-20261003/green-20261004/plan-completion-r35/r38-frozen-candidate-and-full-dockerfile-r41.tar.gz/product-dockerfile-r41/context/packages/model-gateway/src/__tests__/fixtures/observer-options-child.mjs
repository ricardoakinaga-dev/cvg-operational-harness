import assert from 'node:assert/strict'
import { getEventListeners } from 'node:events'
import { ModelGateway, ModelGatewayError, PromptRegistry } from '../../index.ts'
import { CircuitBreaker } from '../../circuit-breaker.ts'

const [composition, failureMode] = process.argv.slice(2)
assert(['options', 'instance'].includes(composition))
assert(['sync', 'async'].includes(failureMode))
let now = 0,
  calls = 0
const events = [],
  charges = []
const caller = new AbortController()
const onTransition = (event) => {
  if (event.to !== 'CLOSED') return
  const error = new Error('synthetic observer transition failure')
  if (failureMode === 'async') return Promise.reject(error)
  throw error
}
const circuitOptions = {
  failureThreshold: 1,
  openMs: 10,
  halfOpenSuccesses: 1,
  clock: () => now,
  onTransition
}
const tenantId = 'tenant_00000000-0000-4000-8000-000000000018'
const prompts = new PromptRegistry()
prompts.register({
  promptId: 'observer-options-colors',
  version: '1',
  content: 'Sort synthetic colors',
  classification: 'INTERNAL',
  tenantId,
  owner: 'synthetic test',
  approvedBy: 'synthetic test',
  status: 'approved',
  effectiveFrom: '2026-01-01T00:00:00Z'
})
const gateway = new ModelGateway({
  providers: [
    {
      id: 'observer-options',
      location: 'local',
      models: ['synthetic'],
      execute: async () => {
        calls++
        if (calls === 1)
          throw new ModelGatewayError(
            'internal_error',
            'synthetic first failure'
          )
        return {
          text: 'blue',
          providerId: 'observer-options',
          model: 'synthetic',
          usage: { inputTokens: 8, outputTokens: 8, totalTokens: 16 }
        }
      }
    }
  ],
  prompts,
  clock: () => new Date(Date.parse('2026-10-04T00:00:00Z') + now),
  circuitBreaker:
    composition === 'instance'
      ? new CircuitBreaker(circuitOptions)
      : circuitOptions,
  budget: {
    limits: { request: 1 },
    store: { consumed: () => 0, consume: (_key, value) => charges.push(value) }
  },
  profiles: {
    local: {
      name: 'local',
      providerId: 'observer-options',
      model: 'synthetic',
      location: 'local',
      temperature: 0,
      maxTokens: 16,
      maxRetries: 0,
      timeoutMs: 1000,
      estimatedCostUsd: 0.016,
      maxCostUsd: 1,
      pricing: { inputPer1kUsd: 1, outputPer1kUsd: 1 }
    }
  },
  onEvent: (event) => events.push(event.type)
})
const request = {
  requestId: 'req_observer_options',
  correlationId: 'corr_observer_options',
  tenantId,
  promptId: 'observer-options-colors',
  promptVersion: '1',
  modelProfile: 'local',
  dataClassification: 'INTERNAL',
  input: {
    messages: [{ role: 'user', content: 'Sort fictional colors blue red' }]
  },
  signal: caller.signal
}
await assert.rejects(
  gateway.generate(request),
  (error) => error.code === 'internal_error'
)
now = 11
const result = await gateway.generate(request)
await new Promise((resolve) => setImmediate(resolve))
assert.equal(result.output.text, 'blue')
assert.equal(calls, 2)
assert.equal(events.filter((type) => type === 'model.call.completed').length, 1)
assert.equal(events.filter((type) => type === 'model.call.failed').length, 1)
assert.equal(
  events.filter(
    (type) =>
      type === 'model.retry.scheduled' || type === 'model.routing.fallback'
  ).length,
  0
)
assert.deepEqual(charges, [0.016, 0.016])
assert.equal(gateway.observerFailureCount(), 1)
assert.equal(getEventListeners(caller.signal, 'abort').length, 0)
console.log(
  JSON.stringify({
    composition,
    failureMode,
    calls,
    completed: 1,
    initialFailure: 1,
    charges,
    observerFailures: gateway.observerFailureCount(),
    listeners: 0,
    status: 'PASS'
  })
)
