// @vitest-environment node
import { createServer } from 'node:https'
import type { AddressInfo, Socket } from 'node:net'
import { mkdtemp, readFile, writeFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { expect, it } from 'vitest'

const exec = promisify(execFile)
it('R10 TLS preserves SNI/authority under real pin and verifies the certificate', async () => {
  const folder = await mkdtemp(join(tmpdir(), 'd011-tls-'))
  const key = join(folder, 'synthetic.key'),
    cert = join(folder, 'synthetic.crt'),
    child = join(folder, 'tls-child.mts')
  const sockets = new Set<Socket>()
  const authorities: string[] = []
  const names: string[] = []
  await exec(
    'openssl',
    [
      'req',
      '-x509',
      '-newkey',
      'rsa:2048',
      '-nodes',
      '-days',
      '1',
      '-keyout',
      key,
      '-out',
      cert,
      '-subj',
      '/CN=synthetic-provider.invalid',
      '-addext',
      'subjectAltName=DNS:synthetic-provider.invalid'
    ],
    { timeout: 10000 }
  )
  const server = createServer(
    { key: await readFile(key), cert: await readFile(cert) },
    (req, res) => {
      authorities.push(req.headers.host ?? '')
      res.end('synthetic TLS ok')
    }
  )
  server.on('connection', (s) => {
    sockets.add(s)
    s.on('close', () => sockets.delete(s))
  })
  server.on('secureConnection', (s) =>
    names.push(typeof s.servername === 'string' ? s.servername : '')
  )
  server.on('tlsClientError', () => {})
  await new Promise<void>((done) => server.listen(0, '127.0.0.1', done))
  const port = (server.address() as AddressInfo).port
  await writeFile(
    child,
    `import { fetchWithResolvedAddress } from ${JSON.stringify(resolve('packages/model-gateway/src/providers/ssrf-node.ts'))};\ntry {const r=await fetchWithResolvedAddress(process.argv[2],{headers:{host:'forged.invalid'}},['127.0.0.1']);process.stdout.write(await r.text())}catch(e){process.stderr.write(String(e));process.exitCode=1}\n`
  )
  const node = process.execPath
  const loader = resolve('node_modules/tsx/dist/loader.mjs')
  const url = `https://synthetic-provider.invalid:${port}/`
  const ownEnv = { ...process.env }
  delete ownEnv.NODE_EXTRA_CA_CERTS
  delete ownEnv.NODE_TLS_REJECT_UNAUTHORIZED
  try {
    const trusted = await exec(node, ['--import', loader, child, url], {
      env: { ...ownEnv, NODE_EXTRA_CA_CERTS: cert },
      timeout: 5000
    })
    expect(trusted.stdout).toBe('synthetic TLS ok')
    expect(authorities).toEqual([`synthetic-provider.invalid:${port}`])
    expect(names).toContain('synthetic-provider.invalid')
    await expect(
      exec(
        node,
        ['--import', loader, child, `https://wrong-authority.invalid:${port}/`],
        { env: { ...ownEnv, NODE_EXTRA_CA_CERTS: cert }, timeout: 5000 }
      )
    ).rejects.toMatchObject({ code: 1 })
    await expect(
      exec(node, ['--import', loader, child, url], {
        env: ownEnv,
        timeout: 5000
      })
    ).rejects.toMatchObject({ code: 1 })
    expect(authorities).toHaveLength(1)
    process.stdout.write(
      'R10 TLS ' +
        JSON.stringify({
          node: process.version,
          authorities,
          names,
          certificateChecks: [
            'trusted CA success',
            'wrong authority rejected',
            'untrusted CA rejected'
          ]
        }) +
        '\n'
    )
  } finally {
    server.closeAllConnections()
    await new Promise<void>((done) => server.close(() => done()))
    await new Promise((done) => setTimeout(done, 10))
    expect(sockets.size).toBe(0)
    await rm(folder, { recursive: true, force: true })
  }
}, 15000)
