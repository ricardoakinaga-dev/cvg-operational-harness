// @vitest-environment node
import { afterEach, describe, expect, it, vi } from 'vitest'
import {
  appendFileSync,
  chmodSync,
  fsyncSync,
  mkdtempSync,
  readFileSync,
  readdirSync,
  rmSync,
  statSync,
  symlinkSync,
  writeFileSync,
  writeSync
} from 'node:fs'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { spawnSync } from 'node:child_process'
import {
  BudgetGuard,
  usdToMicrousd,
  CircuitBreaker,
  FileCostBudgetStore,
  InMemoryCostBudgetStore,
  ModelGateway,
  PromptRegistry,
  type CostBudgetStore,
  type ModelProfile,
  type ModelProvider
} from '../index.ts'

const TENANT = 'tenant_00000000-0000-4000-8000-000000000001'
const NOW = new Date('2026-10-04T12:00:00Z')
const DAY = `day:${TENANT}:2026-10-04`
const folders: string[] = []
const stores: FileCostBudgetStore[] = []
afterEach(() => {
  for (const store of stores.splice(0)) {
    try {
      store.close()
    } catch {
      /* retained lock asserted separately */
    }
  }
  for (const folder of folders.splice(0))
    rmSync(folder, { recursive: true, force: true })
})
function directory() {
  const d = mkdtempSync(join(tmpdir(), 'd009-budget-'))
  folders.push(d)
  return join(d, 'costs')
}
function track(store: FileCostBudgetStore) {
  stores.push(store)
  return store
}
function req(id = 'request_00000001') {
  return {
    requestId: id,
    tenantId: TENANT,
    correlationId: 'correlation_00000001',
    promptId: 'neutral-test',
    promptVersion: '1',
    modelProfile: 'balanced' as const,
    dataClassification: 'INTERNAL' as const,
    input: {
      messages: [{ role: 'user' as const, content: 'Return the color blue.' }]
    }
  }
}
function gateway(
  store: CostBudgetStore,
  overrides: Partial<ModelProfile> = {}
) {
  const execute = vi.fn(async () => ({
    text: 'blue',
    usage: { inputTokens: 0, outputTokens: 0 },
    providerId: 'fixture',
    model: 'fixture',
    externalCall: false
  }))
  const provider: ModelProvider = {
    id: 'fixture',
    location: 'local',
    models: ['fixture'],
    execute
  }
  const prompts = new PromptRegistry()
  prompts.register({
    promptId: 'neutral-test',
    version: '1',
    content: 'Return a color.',
    owner: 'synthetic-test',
    approvedBy: 'synthetic-test-only',
    status: 'approved',
    effectiveFrom: '2026-01-01T00:00:00Z',
    tenantId: TENANT,
    classification: 'INTERNAL'
  })
  const events: string[] = []
  const circuit = new CircuitBreaker()
  const onSuccess = vi.spyOn(circuit, 'onSuccess')
  const profile: ModelProfile = {
    name: 'balanced',
    providerId: 'fixture',
    model: 'fixture',
    location: 'local',
    temperature: 0,
    maxTokens: 1500,
    timeoutMs: 1000,
    maxCostUsd: 1,
    estimatedCostUsd: 0.6,
    maxRetries: 0,
    pricing: { inputPer1kUsd: 0, outputPer1kUsd: 0 },
    ...overrides
  }
  return {
    execute,
    events,
    onSuccess,
    gateway: new ModelGateway({
      circuitBreaker: circuit,
      providers: [provider],
      prompts,
      profiles: { balanced: profile },
      clock: () => NOW,
      budget: { store, limits: { request: 1, day: 1 } },
      onEvent: (event) => events.push(`${event.type}:${event.code ?? ''}`)
    })
  }
}

describe('D009 durable public cost store', () => {
  it('rounds consumes up, limits down, and keeps a canonical SHA chain on restart', () => {
    const d = directory()
    const store = track(new FileCostBudgetStore({ directory: d }))
    store.consume(DAY, 0.0000001)
    expect(store.consumed(DAY)).toBe(0.000001)
    const guard = new BudgetGuard({
      store,
      limits: { day: 0.0000019 },
      clock: () => NOW
    })
    expect(
      guard.authorize({ request: req(), estimatedCostUsd: 0.0000001 }).allowed
    ).toBe(false)
    const head = store.head()
    store.close()
    const again = track(new FileCostBudgetStore({ directory: d }))
    expect(again.head()).toEqual(head)
    expect(again.consumed(DAY)).toBe(0.000001)
    expect(statSync(d).mode & 0o777).toBe(0o700)
    expect(statSync(join(d, 'ledger.jsonl')).mode & 0o777).toBe(0o600)
    expect(statSync(join(d, 'writer.lock')).mode & 0o777).toBe(0o600)
    expect(
      JSON.parse(readFileSync(join(d, 'ledger.jsonl'), 'utf8').trim())
    ).toMatchObject({
      version: 1,
      sequence: 1,
      amountMicrousd: 1,
      totalMicrousd: 1,
      previousHash: '0'.repeat(64)
    })
  })

  it('BUDGET-RESTART uses distinct real processes; second 0.6 under daily 1 denies without a call', () => {
    const d = directory()
    const source = resolve('packages/model-gateway/src/index.ts')
    const script = `import {pathToFileURL} from 'node:url'; const {FileCostBudgetStore,BudgetGuard}=await import(pathToFileURL(process.argv[2]).href); const store=new FileCostBudgetStore({directory:process.argv[1]});const guard=new BudgetGuard({store,limits:{day:1},clock:()=>new Date('2026-10-04T12:00:00Z')});let calls=0;const a=guard.authorize({request:JSON.parse(process.argv[3]),estimatedCostUsd:0.6});if(a.allowed)calls++;console.log(JSON.stringify({pid:process.pid,allowed:a.allowed,calls,spent:store.consumed(process.argv[4])}));store.close();`
    const run = () => {
      const result = spawnSync(
        process.execPath,
        [
          '--import',
          'tsx',
          '--input-type=module',
          '-e',
          script,
          d,
          source,
          JSON.stringify(req()),
          DAY
        ],
        { cwd: process.cwd(), encoding: 'utf8' }
      )
      expect(result.status, result.stderr).toBe(0)
      return JSON.parse(result.stdout)
    }
    const first = run(),
      second = run()
    expect(first).toMatchObject({ allowed: true, calls: 1, spent: 0.6 })
    expect(second).toMatchObject({ allowed: false, calls: 0, spent: 0.6 })
    expect(first.pid).not.toBe(second.pid)
    // Known-bad control: the same restart oracle fails for ephemeral stores.
    const bad = () =>
      new BudgetGuard({
        store: new InMemoryCostBudgetStore(),
        limits: { day: 1 },
        clock: () => NOW
      }).authorize({ request: req(), estimatedCostUsd: 0.6 }).allowed
    expect([bad(), bad()]).toEqual([true, true])
  })

  it('simultaneous public requests admit at most one; clean reopening preserves 0.6', async () => {
    const d = directory(),
      store = track(new FileCostBudgetStore({ directory: d }))
    const fixture = gateway(store)
    const results = await Promise.allSettled([
      fixture.gateway.generate(req('request_00000001')),
      fixture.gateway.generate(req('request_00000002'))
    ])
    expect(results.filter((x) => x.status === 'fulfilled')).toHaveLength(1)
    expect(fixture.execute).toHaveBeenCalledTimes(1)
    expect(store.consumed(DAY)).toBe(0.6)
    store.close()
    expect(track(new FileCostBudgetStore({ directory: d })).consumed(DAY)).toBe(
      0.6
    )
  })

  it('rejects a duplicate writer and residual lock without age/PID stealing', () => {
    const d = directory()
    const store = track(new FileCostBudgetStore({ directory: d }))
    const lock = readFileSync(join(d, 'writer.lock'))
    expect(() => new FileCostBudgetStore({ directory: d })).toThrowError(
      expect.objectContaining({ code: 'budget_store_unavailable' })
    )
    expect(readFileSync(join(d, 'writer.lock'))).toEqual(lock)
    store.close()
    writeFileSync(join(d, 'writer.lock'), '{"pid":-1,"old":true}', {
      mode: 0o600
    })
    expect(() => new FileCostBudgetStore({ directory: d })).toThrow()
    expect(readFileSync(join(d, 'writer.lock'), 'utf8')).toContain('"pid":-1')
  })

  it('loops on short writes and fsyncs every configured scope before public provider execution', async () => {
    const writes: number[] = [],
      syncs: number[] = []
    const io = {
      writeSync: ((
        fd: number,
        bytes: Uint8Array,
        offset: number,
        length: number
      ) => {
        const n = Math.min(7, length)
        writes.push(n)
        return writeSync(fd, bytes, offset, n, null)
      }) as typeof writeSync,
      fsyncSync: (fd: number) => {
        syncs.push(fd)
        fsyncSync(fd)
      }
    }
    const store = track(new FileCostBudgetStore({ directory: directory(), io }))
    syncs.length = 0
    const fixture = gateway(store)
    fixture.execute.mockImplementationOnce(async () => {
      expect(syncs).toHaveLength(2)
      expect(store.consumed(DAY)).toBe(0.6)
      return {
        text: 'blue',
        usage: { inputTokens: 0, outputTokens: 0 },
        providerId: 'fixture',
        model: 'fixture',
        externalCall: false
      }
    })
    await fixture.gateway.generate(req())
    expect(writes.length).toBeGreaterThan(10)
  })

  it.each([
    'before-write',
    'zero-write',
    'partial-write',
    'before-fsync',
    'after-fsync'
  ] as const)(
    'reservation failure %s is typed, inhibited, retains bytes/locks and makes zero provider calls',
    async (fault) => {
      let armed = false,
        writes = 0
      const d = directory()
      const io = {
        writeSync: ((
          fd: number,
          bytes: Uint8Array,
          offset: number,
          length: number
        ) => {
          if (armed) {
            if (fault === 'before-write') throw new Error('write failed')
            if (fault === 'zero-write') return 0
            if (fault === 'partial-write' && writes++ > 0)
              throw new Error('partial failed')
            if (fault === 'partial-write')
              return writeSync(fd, bytes, offset, Math.min(8, length), null)
          }
          return writeSync(fd, bytes, offset, length, null)
        }) as typeof writeSync,
        fsyncSync: (fd: number) => {
          if (armed && fault === 'before-fsync') throw new Error('sync failed')
          fsyncSync(fd)
          if (armed && fault === 'after-fsync')
            throw new Error('sync result unknown')
        }
      }
      const store = track(new FileCostBudgetStore({ directory: d, io })),
        fixture = gateway(store)
      armed = true
      await expect(fixture.gateway.generate(req())).rejects.toMatchObject({
        code: 'budget_store_unavailable',
        status: 503,
        retryable: false
      })
      expect(fixture.execute).not.toHaveBeenCalled()
      expect(fixture.events).not.toContain('model.call.started:')
      expect(fixture.gateway.budgetHealth().ready).toBe(false)
      const bytes = readFileSync(join(d, 'ledger.jsonl'))
      await expect(
        fixture.gateway.generate(req('request_00000002'))
      ).rejects.toMatchObject({ code: 'budget_store_unavailable' })
      expect(readFileSync(join(d, 'ledger.jsonl'))).toEqual(bytes)
      store.close()
      expect(readdirSync(d)).toContain('writer.lock')
      // Explicit stopped-process lock reconciliation, not automatic recovery by store.
      rmSync(join(d, 'writer.lock'))
      if (fault === 'partial-write') {
        expect(() => new FileCostBudgetStore({ directory: d })).toThrow()
        expect(readFileSync(join(d, 'ledger.jsonl'))).toEqual(bytes)
        expect(readdirSync(d).some((x) => x.startsWith('recovery-tail-'))).toBe(
          true
        )
      } else {
        const recovered = track(new FileCostBudgetStore({ directory: d }))
        expect(recovered.consumed('request:request_00000001')).toBe(
          fault.includes('fsync') ? 0.6 : 0
        )
      }
    }
  )

  it.each([1, 2, 3, 4, 5])(
    'scope %i fsync failure leaves a conservative prefix; no provider before all scopes',
    async (failAt) => {
      let armed = false,
        count = 0
      const d = directory()
      const store = track(
        new FileCostBudgetStore({
          directory: d,
          io: {
            fsyncSync(fd) {
              fsyncSync(fd)
              if (armed && ++count === failAt)
                throw new Error('unknown fsync outcome')
            }
          }
        })
      )
      const execute = vi.fn()
      const request = {
        ...req(),
        sessionId: 'session_test',
        agentId: 'agent_test'
      }
      const guard = new BudgetGuard({
        store,
        limits: { request: 1, session: 1, tenant: 1, agent: 1, day: 1 },
        clock: () => NOW
      })
      armed = true
      expect(() => {
        if (guard.authorize({ request, estimatedCostUsd: 0.6 }).allowed)
          execute()
      }).toThrowError(
        expect.objectContaining({ code: 'budget_store_unavailable' })
      )
      expect(execute).not.toHaveBeenCalled()
      store.close()
      rmSync(join(d, 'writer.lock'))
      const recovered = track(new FileCostBudgetStore({ directory: d }))
      expect(recovered.head().sequence).toBe(failAt)
      expect(recovered.consumed('request:request_00000001')).toBe(0.6)
    }
  )

  it.each([NaN, Infinity, -1, Number.MAX_SAFE_INTEGER])(
    'invalid money %s fails closed instead of resetting budget',
    (amount) => {
      const d = directory(),
        store = track(new FileCostBudgetStore({ directory: d }))
      store.consume(DAY, 0.6)
      const bytes = readFileSync(join(d, 'ledger.jsonl'))
      expect(() => store.consume(DAY, amount)).toThrowError(
        expect.objectContaining({ code: 'budget_store_unavailable' })
      )
      expect(store.health()).toMatchObject({ ready: false, uncertain: true })
      expect(readFileSync(join(d, 'ledger.jsonl'))).toEqual(bytes)
    }
  )

  it('safe integer total overflow is blocked without appending or publishing', () => {
    const store = track(new FileCostBudgetStore({ directory: directory() }))
    store.consume(DAY, (Number.MAX_SAFE_INTEGER - 100) / 1_000_000)
    expect(() => store.consume(DAY, 1)).toThrow()
    expect(store.health().ready).toBe(false)
  })

  it.each([
    'scope',
    'amount',
    'sequence',
    'hash',
    'sum',
    'unknown-field'
  ] as const)(
    'replay rejects internal %s corruption and preserves original bytes',
    (kind) => {
      const d = directory(),
        store = track(new FileCostBudgetStore({ directory: d }))
      store.consume(DAY, 0.6)
      store.close()
      const ledger = join(d, 'ledger.jsonl'),
        record = JSON.parse(readFileSync(ledger, 'utf8'))
      if (kind === 'scope') record.scopeKey = 'unrecognized:x'
      if (kind === 'amount') record.amountMicrousd = -1
      if (kind === 'sequence') record.sequence = 8
      if (kind === 'hash') record.hash = '1'.repeat(64)
      if (kind === 'sum') record.totalMicrousd += 1
      if (kind === 'unknown-field') record.extra = true
      const bytes = JSON.stringify(record) + '\n'
      writeFileSync(ledger, bytes)
      expect(() => new FileCostBudgetStore({ directory: d })).toThrowError(
        expect.objectContaining({ code: 'budget_store_unavailable' })
      )
      expect(readFileSync(ledger, 'utf8')).toBe(bytes)
      expect(readdirSync(d)).toContain('writer.lock')
    }
  )

  it('preserves incomplete recovery tail in hash-bound evidence, never truncates', () => {
    const d = directory(),
      store = track(new FileCostBudgetStore({ directory: d }))
    store.consume(DAY, 0.6)
    store.close()
    const ledger = join(d, 'ledger.jsonl')
    appendFileSync(ledger, '{"incomplete":')
    const before = readFileSync(ledger)
    expect(() => new FileCostBudgetStore({ directory: d })).toThrow()
    expect(readFileSync(ledger)).toEqual(before)
    const tail = readdirSync(d).find((x) =>
      /^recovery-tail-[0-9a-f]{64}\.bin$/.test(x)
    )!
    expect(readFileSync(join(d, tail), 'utf8')).toBe('{"incomplete":')
    expect(statSync(join(d, tail)).mode & 0o777).toBe(0o600)
  })

  it('UTC clock rollback after reopen inhibits; next day keeps history', () => {
    const d = directory(),
      store = track(new FileCostBudgetStore({ directory: d }))
    store.consume(DAY, 0.6)
    store.close()
    const recovered = track(new FileCostBudgetStore({ directory: d }))
    const guard = new BudgetGuard({
      store: recovered,
      limits: { day: 1 },
      clock: () => new Date('2026-10-03T12:00:00Z')
    })
    expect(() =>
      guard.authorize({ request: req(), estimatedCostUsd: 0.6 })
    ).toThrow()
    recovered.close()
    rmSync(join(d, 'writer.lock'))
    const forward = track(new FileCostBudgetStore({ directory: d }))
    const next = new BudgetGuard({
      store: forward,
      limits: { day: 1 },
      clock: () => new Date('2026-10-05T12:00:00Z')
    })
    expect(
      next.authorize({ request: req(), estimatedCostUsd: 0.6 }).allowed
    ).toBe(true)
    expect(forward.consumed(DAY)).toBe(0.6)
    expect(forward.consumed(`day:${TENANT}:2026-10-05`)).toBe(0.6)
  })

  it('a declared restore requires an explicit latest reconciled head', () => {
    const d = directory(),
      store = track(new FileCostBudgetStore({ directory: d }))
    store.consume(DAY, 0.6)
    const head = store.head()
    store.close()
    expect(
      () => new FileCostBudgetStore({ directory: d, restore: {} })
    ).toThrow()
    rmSync(join(d, 'writer.lock'))
    expect(
      () =>
        new FileCostBudgetStore({
          directory: d,
          restore: { reconciledHead: { ...head, sequence: head.sequence + 1 } }
        })
    ).toThrow()
    rmSync(join(d, 'writer.lock'))
    const restored = track(
      new FileCostBudgetStore({
        directory: d,
        restore: { reconciledHead: head }
      })
    )
    expect(restored.consumed(DAY)).toBe(0.6)
  })

  it('rejects symlink parents, insecure ledger modes and hardlinks/unknown scopes', () => {
    const base = mkdtempSync(join(tmpdir(), 'd009-physical-'))
    folders.push(base)
    symlinkSync(base, join(base, 'alias'))
    expect(
      () => new FileCostBudgetStore({ directory: join(base, 'alias', 'costs') })
    ).toThrow()
    const d = directory(),
      store = track(new FileCostBudgetStore({ directory: d }))
    expect(() => store.consume('scope', 0.6)).toThrow()
    store.close()
    rmSync(join(d, 'writer.lock'))
    chmodSync(join(d, 'ledger.jsonl'), 0o644)
    expect(() => new FileCostBudgetStore({ directory: d })).toThrow()
  })
})

// Deliberately keep direct BudgetGuard legacy behavior in the original regression tests.

describe('D009 settlement failures and ceiling violations', () => {
  it('charges the overrun once before success, reports it, inhibits the profile and never refunds', async () => {
    const store = track(new FileCostBudgetStore({ directory: directory() }))
    const fixture = gateway(store, {
      pricing: { inputPer1kUsd: 0.7, outputPer1kUsd: 0 }
    })
    fixture.execute.mockResolvedValue({
      text: 'blue',
      usage: { inputTokens: 1000, outputTokens: 0 },
      providerId: 'fixture',
      model: 'fixture',
      externalCall: false
    })
    await expect(fixture.gateway.generate(req())).resolves.toMatchObject({
      costUsd: 0.7
    })
    expect(store.consumed(DAY)).toBeCloseTo(0.7, 6)
    expect(fixture.onSuccess).toHaveBeenCalledOnce()
    expect(fixture.events).toContain(
      'model.budget.violation:budget_estimate_violated'
    )
    expect(fixture.gateway.budgetHealth()).toMatchObject({
      ready: false,
      inhibitedProfiles: ['balanced']
    })
    await expect(
      fixture.gateway.generate(req('request_00000002'))
    ).rejects.toMatchObject({ code: 'budget_store_unavailable' })
    expect(fixture.execute).toHaveBeenCalledOnce()
    expect(store.consumed(DAY)).toBeCloseTo(0.7, 6)
  })

  it.each(['before-write', 'after-fsync'] as const)(
    'settlement %s fails typed before circuit success, retains possibly durable charges',
    async (fault) => {
      let armed = false
      const d = directory()
      const store = track(
        new FileCostBudgetStore({
          directory: d,
          io: {
            writeSync: ((
              fd: number,
              bytes: Uint8Array,
              offset: number,
              length: number
            ) => {
              if (armed && fault === 'before-write')
                throw new Error('settlement write failed')
              return writeSync(fd, bytes, offset, length, null)
            }) as typeof writeSync,
            fsyncSync(fd) {
              fsyncSync(fd)
              if (armed && fault === 'after-fsync')
                throw new Error('settlement outcome uncertain')
            }
          }
        })
      )
      const fixture = gateway(store, {
        pricing: { inputPer1kUsd: 0.7, outputPer1kUsd: 0 }
      })
      fixture.execute.mockImplementation(async () => {
        armed = true
        return {
          text: 'blue',
          usage: { inputTokens: 1000, outputTokens: 0 },
          providerId: 'fixture',
          model: 'fixture',
          externalCall: false
        }
      })
      await expect(fixture.gateway.generate(req())).rejects.toMatchObject({
        code: 'budget_store_unavailable',
        status: 503
      })
      expect(fixture.onSuccess).not.toHaveBeenCalled()
      expect(fixture.events).not.toContain('model.call.completed:')
      expect(fixture.events).toContain(
        'model.call.failed:budget_store_unavailable'
      )
      expect(fixture.gateway.budgetHealth().ready).toBe(false)
      const before = readFileSync(join(d, 'ledger.jsonl'))
      await expect(
        fixture.gateway.generate(req('request_00000002'))
      ).rejects.toMatchObject({ code: 'budget_store_unavailable' })
      expect(fixture.execute).toHaveBeenCalledOnce()
      expect(readFileSync(join(d, 'ledger.jsonl'))).toEqual(before)
      store.close()
      rmSync(join(d, 'writer.lock'))
      const recovered = track(new FileCostBudgetStore({ directory: d }))
      expect(recovered.consumed('request:request_00000001')).toBeCloseTo(
        fault === 'after-fsync' ? 0.7 : 0.6,
        6
      )
      expect(recovered.consumed(DAY)).toBe(0.6)
    }
  )
})

describe('D009 additional physical crash and precision controls', () => {
  it('a real exit after durable reservation leaves a lock; offline identified lock removal/replay never resets spend', () => {
    const d = directory(),
      source = resolve('packages/model-gateway/src/index.ts')
    const script = `import {FileCostBudgetStore} from ${JSON.stringify(source)};const s=new FileCostBudgetStore({directory:process.argv[1]});s.consume(${JSON.stringify(DAY)},0.6);process.exit(73);`
    const child = spawnSync(
      process.execPath,
      ['--import', 'tsx', '--input-type=module', '-e', script, d],
      { encoding: 'utf8' }
    )
    expect(child.status, child.stderr).toBe(73)
    const bytes = readFileSync(join(d, 'ledger.jsonl'))
    expect(() => new FileCostBudgetStore({ directory: d })).toThrow()
    expect(readFileSync(join(d, 'ledger.jsonl'))).toEqual(bytes)
    rmSync(join(d, 'writer.lock'))
    expect(track(new FileCostBudgetStore({ directory: d })).consumed(DAY)).toBe(
      0.6
    )
  })

  it.each([1, 2, 3, 4])(
    'startup sync failure %i preserves any acquired lock and blocks duplicate startup',
    (failAt) => {
      let count = 0
      const d = directory()
      expect(
        () =>
          new FileCostBudgetStore({
            directory: d,
            io: {
              fsyncSync(fd) {
                fsyncSync(fd)
                if (++count === failAt)
                  throw new Error('startup sync uncertain')
              }
            }
          })
      ).toThrowError(
        expect.objectContaining({ code: 'budget_store_unavailable' })
      )
      expect(readdirSync(d)).toContain('writer.lock')
      expect(() => new FileCostBudgetStore({ directory: d })).toThrow()
    }
  )

  it('decimal reservation at the limit does not acquire phantom microUSD on conversion', () => {
    const store = track(new FileCostBudgetStore({ directory: directory() }))
    const guard = new BudgetGuard({
      store,
      limits: { day: 1.000001 },
      clock: () => NOW
    })
    expect(
      guard.authorize({ request: req(), estimatedCostUsd: 1.000001 }).allowed
    ).toBe(true)
    expect(store.consumed(DAY)).toBe(1.000001)
    expect(
      guard.authorize({ request: req(), estimatedCostUsd: 0.0000001 }).allowed
    ).toBe(false)
  })

  it.each([1, 2, 3, 4, 5])(
    'store write failure at scope %i preserves earlier scopes and inhibits guard',
    (failAt) => {
      let armed = false,
        count = 0
      const d = directory()
      const store = track(
        new FileCostBudgetStore({
          directory: d,
          io: {
            writeSync: ((
              fd: number,
              bytes: Uint8Array,
              offset: number,
              length: number
            ) => {
              if (armed && ++count === failAt)
                throw new Error('scope write failed')
              return writeSync(fd, bytes, offset, length, null)
            }) as typeof writeSync
          }
        })
      )
      const guard = new BudgetGuard({
        store,
        limits: { request: 1, session: 1, tenant: 1, agent: 1, day: 1 },
        clock: () => NOW
      })
      armed = true
      expect(() =>
        guard.authorize({
          request: {
            ...req(),
            sessionId: 'session_test',
            agentId: 'agent_test'
          },
          estimatedCostUsd: 0.6
        })
      ).toThrowError(
        expect.objectContaining({ code: 'budget_store_unavailable' })
      )
      expect(guard.health().ready).toBe(false)
      store.close()
      rmSync(join(d, 'writer.lock'))
      const recovered = track(new FileCostBudgetStore({ directory: d }))
      expect(recovered.head().sequence).toBe(failAt - 1)
      if (failAt > 1)
        expect(recovered.consumed('request:request_00000001')).toBe(0.6)
    }
  )

  it.each([1, 2, 3, 4, 5])(
    'settlement fsync failure at scope %i retains reservations and uncertain delta without reset',
    (failAt) => {
      let armed = false,
        count = 0
      const d = directory()
      const store = track(
        new FileCostBudgetStore({
          directory: d,
          io: {
            fsyncSync(fd) {
              fsyncSync(fd)
              if (armed && ++count === failAt)
                throw new Error('settlement prefix uncertain')
            }
          }
        })
      )
      const guard = new BudgetGuard({
        store,
        limits: { request: 1, session: 1, tenant: 1, agent: 1, day: 1 },
        clock: () => NOW
      })
      const authorization = guard.authorize({
        request: { ...req(), sessionId: 'session_test', agentId: 'agent_test' },
        estimatedCostUsd: 0.6
      })
      armed = true
      expect(() =>
        guard.settle({
          reservedKeys: authorization.reservedKeys,
          estimatedCostUsd: 0.6,
          actualCostUsd: 0.7
        })
      ).toThrowError(
        expect.objectContaining({ code: 'budget_store_unavailable' })
      )
      expect(() =>
        guard.authorize({ request: req(), estimatedCostUsd: 0 })
      ).toThrow()
      store.close()
      rmSync(join(d, 'writer.lock'))
      const recovered = track(new FileCostBudgetStore({ directory: d }))
      expect(recovered.head().sequence).toBe(5 + failAt)
      expect(
        recovered.consumed('request:request_00000001')
      ).toBeGreaterThanOrEqual(0.7)
      expect(recovered.consumed(DAY)).toBeGreaterThanOrEqual(0.6)
    }
  )
})

it('D009 rejects complete invalid UTF8 ledger bytes even with a hash matching replacement decoding', () => {
  const d = directory(),
    store = track(new FileCostBudgetStore({ directory: d }))
  store.consume('request:bad_�', 0.6)
  store.close()
  const ledger = join(d, 'ledger.jsonl'),
    bytes = readFileSync(ledger)
  const replacement = bytes.indexOf(Buffer.from('�'))
  expect(replacement).toBeGreaterThan(0)
  const corrupted = Buffer.concat([
    bytes.subarray(0, replacement),
    Buffer.from([0xff]),
    bytes.subarray(replacement + 3)
  ])
  writeFileSync(ledger, corrupted)
  expect(() => new FileCostBudgetStore({ directory: d })).toThrowError(
    expect.objectContaining({ code: 'budget_store_unavailable' })
  )
  expect(readFileSync(ledger)).toEqual(corrupted)
})

it('D009 decimal microUSD conversions cover subnormal, exponent, fractional, exact limit and overflow', () => {
  expect(usdToMicrousd(Number.MIN_VALUE, 'ceil')).toBe(1)
  expect(usdToMicrousd(Number.MIN_VALUE, 'floor')).toBe(0)
  expect(usdToMicrousd(1.000001, 'ceil')).toBe(1000001)
  expect(usdToMicrousd(1.000001, 'floor')).toBe(1000001)
  expect(usdToMicrousd(0.0000001, 'ceil')).toBe(1)
  expect(usdToMicrousd(0.0000001, 'floor')).toBe(0)
  expect(() => usdToMicrousd(1e200, 'ceil')).toThrow()
})
