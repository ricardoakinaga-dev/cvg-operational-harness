// @vitest-environment node
import { expect, it } from 'vitest'
import { createServer } from 'node:http'
import { once, getEventListeners } from 'node:events'
import type { AddressInfo, Socket } from 'node:net'
import {
  ModelGateway,
  PromptRegistry,
  OpenAICompatibleProvider
} from '../index.ts'
import { CircuitBreaker } from '../circuit-breaker.ts'

it.each(['started', 'transition', 'completed'] as const)(
  'observer exceptions at %s cannot create another terminal outcome',
  async (stage) => {
    const sockets = new Set<Socket>()
    let requests = 0
    const server = createServer((_req, res) => {
      requests++
      res.end(
        JSON.stringify({
          choices: [{ message: { content: 'blue' } }],
          usage: { prompt_tokens: 8, completion_tokens: 8 }
        })
      )
    })
    server.on('connection', (socket) => {
      sockets.add(socket)
      socket.on('close', () => sockets.delete(socket))
    })
    server.listen(0, '127.0.0.1')
    await once(server, 'listening')
    const caller = new AbortController(),
      events: string[] = [],
      charges: number[] = []
    let now = 0,
      async = false
    const fail = () => {
      if (async)
        return Promise.reject(new Error('synthetic async observer fault'))
      throw new Error('synthetic sync observer fault')
    }
    const circuit = new CircuitBreaker({
      failureThreshold: 1,
      openMs: 10,
      halfOpenSuccesses: 1,
      clock: () => now,
      onTransition: (transition) => {
        if (stage === 'transition' && transition.to === 'CLOSED') return fail()
      }
    })
    circuit.onFailure('observer:synthetic')
    now = 11
    const prompts = new PromptRegistry(),
      tenant = 'tenant_00000000-0000-4000-8000-000000000008'
    prompts.register({
      promptId: 'observer-colors',
      version: '1',
      content: 'Sort fictional colors',
      classification: 'INTERNAL',
      tenantId: tenant,
      owner: 'synthetic fixture',
      approvedBy: 'test fixture only',
      status: 'approved',
      effectiveFrom: '2026-01-01T00:00:00Z'
    })
    const gateway = new ModelGateway({
      providers: [
        new OpenAICompatibleProvider({
          id: 'observer',
          model: 'synthetic',
          location: 'local',
          baseUrl: `http://127.0.0.1:${(server.address() as AddressInfo).port}`,
          allowHttp: true,
          allowPrivateNetworks: true
        })
      ],
      prompts,
      circuitBreaker: circuit,
      budget: {
        limits: { request: 1 },
        store: {
          consumed: () => 0,
          consume: (_key, value) => {
            charges.push(value)
          }
        }
      },
      profiles: {
        local: {
          name: 'local',
          providerId: 'observer',
          model: 'synthetic',
          location: 'local',
          temperature: 0,
          maxTokens: 16,
          maxRetries: 0,
          timeoutMs: 1000,
          estimatedCostUsd: 0.016,
          maxCostUsd: 1,
          pricing: { inputPer1kUsd: 1, outputPer1kUsd: 1 }
        }
      },
      onEvent: (event) => {
        events.push(event.type)
        if (event.type === `model.call.${stage}`) return fail()
      }
    })
    const request = () => ({
      requestId: 'req_observer_control',
      correlationId: 'corr_observer_control',
      tenantId: tenant,
      promptId: 'observer-colors',
      promptVersion: '1',
      modelProfile: 'local' as const,
      dataClassification: 'INTERNAL' as const,
      input: {
        messages: [
          { role: 'user' as const, content: 'Sort fictional colors blue red' }
        ]
      },
      signal: caller.signal
    })
    try {
      for (const mode of ['sync', 'async'] as const) {
        async = mode === 'async'
        if (stage === 'transition' && async) {
          circuit.onFailure('observer:synthetic')
          now += 11
        }
        const result = await gateway.generate(request())
        await new Promise<void>((resolve) => setImmediate(resolve))
        expect(result.output.text).toBe('blue')
        expect(circuit.state('observer:synthetic')).toBe('CLOSED')
      }
      expect(gateway.observerFailureCount()).toBe(2)
      expect(
        events.filter((type) => type === 'model.call.completed')
      ).toHaveLength(2)
      expect(
        events.filter((type) => type === 'model.call.failed')
      ).toHaveLength(0)
      expect(
        events.filter(
          (type) =>
            type === 'model.retry.scheduled' ||
            type === 'model.routing.fallback'
        )
      ).toHaveLength(0)
      expect(charges.filter((value) => value > 0)).toEqual([0.016, 0.016])
      expect(requests).toBe(2)
      expect(getEventListeners(caller.signal, 'abort')).toHaveLength(0)
      await new Promise((resolve) => setTimeout(resolve, 20))
      expect(sockets.size).toBe(0)
      console.log(
        'OBSERVER_TERMINAL_PROOF',
        JSON.stringify({
          stage,
          requests,
          events,
          failures: gateway.observerFailureCount(),
          charges,
          sockets: sockets.size
        })
      )
    } finally {
      server.closeAllConnections()
      await new Promise<void>((resolve) => server.close(() => resolve()))
    }
  }
)
