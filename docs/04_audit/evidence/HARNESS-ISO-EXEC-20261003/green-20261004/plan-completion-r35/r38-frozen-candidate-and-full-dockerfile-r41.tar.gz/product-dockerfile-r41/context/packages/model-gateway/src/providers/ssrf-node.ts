import {
  request as httpRequest,
  type IncomingMessage,
  type ClientRequest
} from 'node:http'
import { request as httpsRequest } from 'node:https'
import { isIP, type LookupFunction } from 'node:net'
import { Readable, pipeline, type Transform } from 'node:stream'
import { createGunzip, createInflate, createBrotliDecompress } from 'node:zlib'
import { ModelProviderError } from '../errors.ts'
import {
  abortReason,
  RECEIVE_CHUNK_BYTES as Q,
  validateResponseLimit
} from './bounded-reader.ts'

/** Internal instrumentation; never exported from the package's public index. */
export interface ReceiveMetrics {
  wireObserved: number
  wireAccepted: number
  decodedObserved: number
  decodedAccepted: number
  maxNativeChunk: number
  maxWireQueue: number
  maxDecoderReadQueue: number
  maxDecoderWriteQueue: number
  maxWebQueue: number
}
interface ReceivePolicy {
  maxResponseBytes?: number
  providerId?: string
  metrics?: ReceiveMetrics
}

/** Connect only to the validated pin; retain URL authority and verified TLS SNI. */
export async function fetchWithResolvedAddress(
  rawUrl: string,
  init: Record<string, unknown>,
  resolvedAddresses: readonly string[],
  policy: ReceivePolicy = {}
): Promise<Response> {
  const signal = asAbortSignal(init.signal)
  if (signal?.aborted) throw abortReason(signal)
  const limit = validateResponseLimit(
    policy.providerId ?? 'node-transport',
    policy.maxResponseBytes ?? 262144
  )
  const url = new URL(rawUrl)
  const address = resolvedAddresses[0]
  if (!address) throw new Error('No resolved address available')
  const hostname = stripBrackets(url.hostname)
  if (isIP(stripBrackets(address)) === 0)
    throw new Error('Resolved address is not an IP literal')
  if (url.protocol !== 'http:' && url.protocol !== 'https:')
    throw new Error('Unsupported transport protocol')
  const body = await encodeBody(init.body)
  if (signal?.aborted) throw abortReason(signal)
  const headers = toHeaders(init.headers)
  headers.delete('host')
  headers.set('host', url.host)
  headers.set('accept-encoding', 'identity')
  if (body !== undefined && !headers.has('content-length'))
    headers.set('content-length', String(body.byteLength))
  const method = typeof init.method === 'string' ? init.method : 'GET'
  const options = {
    agent: false,
    hostname,
    port: url.port || undefined,
    path: `${url.pathname || '/'}${url.search}`,
    method,
    headers: Object.fromEntries(headers.entries()),
    lookup: pinnedLookup(stripBrackets(address)),
    maxHeaderSize: 16384,
    highWaterMark: Q,
    ...(url.protocol === 'https:' ? { servername: hostname } : {})
  }
  return new Promise<Response>((resolve, reject) => {
    let terminal = false,
      headersReturned = false
    let response: IncomingMessage | undefined
    let source: Readable | undefined
    let decoder: Transform | undefined
    let controller: ReadableStreamDefaultController<Uint8Array> | undefined
    const errorFor = (
      kind: 'response_too_large' | 'malformed_response',
      message: string
    ) =>
      new ModelProviderError(
        policy.providerId ?? 'node-transport',
        kind,
        message
      )
    const cleanup = () => {
      signal?.removeEventListener('abort', onAbort)
    }
    const destroy = () => {
      source?.destroy()
      decoder?.destroy()
      response?.destroy()
      request.destroy()
    }
    const fail = (error: unknown) => {
      if (terminal) return
      const rawCode = (error as NodeJS.ErrnoException | null)?.code
      const code = typeof rawCode === 'string' ? rawCode : undefined
      const mapped =
        error instanceof ModelProviderError
          ? error
          : code?.startsWith('Z_') ||
              code?.startsWith('ERR_PADDING_') ||
              code?.startsWith('ERR_CL_SPACE') ||
              code?.startsWith('ERR_HUFFMAN_') ||
              code?.startsWith('HPE_')
            ? errorFor(
                'malformed_response',
                'Invalid provider response framing or compression'
              )
            : error
      terminal = true
      cleanup()
      controller?.error(mapped)
      destroy()
      if (!headersReturned) reject(mapped)
    }
    const onAbort = () => {
      if (signal) fail(abortReason(signal))
    }
    const receive = (incoming: IncomingMessage) => {
      response = incoming
      // Disable Node's default silent truncation of a large number of small headers/trailers.
      request.maxHeadersCount = 0
      const responseHeaders = new Headers()
      for (const [name, value] of Object.entries(incoming.headers)) {
        if (Array.isArray(value))
          for (const item of value) responseHeaders.append(name, item)
        else if (value !== undefined) responseHeaders.append(name, value)
      }
      const status = incoming.statusCode ?? 0
      const bodyless =
        method.toUpperCase() === 'HEAD' ||
        status === 204 ||
        status === 205 ||
        status === 304 ||
        status < 200 ||
        status >= 300
      if (bodyless) {
        try {
          const result = new Response(null, {
            status,
            statusText: incoming.statusMessage ?? '',
            headers: responseHeaders
          })
          headersReturned = true
          resolve(result)
          terminal = true
          cleanup()
          destroy()
        } catch (error) {
          fail(error)
        }
        return
      }
      const encoding = (incoming.headers['content-encoding'] ?? 'identity')
        .trim()
        .toLowerCase()
      const length = incoming.headers['content-length']
      let early: ModelProviderError | undefined
      if (length !== undefined && !/^\d+$/.test(length))
        early = errorFor(
          'malformed_response',
          'Invalid provider Content-Length'
        )
      else if (length !== undefined && BigInt(length) > BigInt(limit))
        early = errorFor(
          'response_too_large',
          `Provider wire response exceeded ${limit} bytes`
        )
      else if (!['identity', 'gzip', 'deflate', 'br'].includes(encoding))
        early = errorFor(
          'malformed_response',
          'Unsupported provider Content-Encoding'
        )
      if (encoding !== 'identity') {
        responseHeaders.delete('content-length')
        responseHeaders.delete('content-encoding')
      }
      const metrics = policy.metrics
      let wireAccepted = 0,
        decodedAccepted = 0
      const sample = () => {
        if (!metrics) return
        metrics.maxWireQueue = Math.max(
          metrics.maxWireQueue,
          source?.readableLength ?? 0
        )
        metrics.maxDecoderReadQueue = Math.max(
          metrics.maxDecoderReadQueue,
          decoder?.readableLength ?? 0
        )
        metrics.maxDecoderWriteQueue = Math.max(
          metrics.maxDecoderWriteQueue,
          decoder?.writableLength ?? 0
        )
      }
      async function* wireChunks() {
        for await (const raw of incoming) {
          const chunk = Buffer.isBuffer(raw) ? raw : Buffer.from(raw)
          if (metrics) {
            metrics.wireObserved += chunk.byteLength
            metrics.maxNativeChunk = Math.max(
              metrics.maxNativeChunk,
              chunk.byteLength
            )
          }
          for (let offset = 0; offset < chunk.byteLength; offset += Q) {
            const view = chunk.subarray(
              offset,
              Math.min(offset + Q, chunk.byteLength)
            )
            if (view.byteLength > limit - wireAccepted)
              throw errorFor(
                'response_too_large',
                `Provider wire response exceeded ${limit} bytes`
              )
            wireAccepted += view.byteLength
            if (metrics) metrics.wireAccepted = wireAccepted
            sample()
            yield view
          }
        }
      }
      source = Readable.from(wireChunks(), {
        objectMode: false,
        highWaterMark: 1
      })
      let pipelineCompletion: Promise<Error | null> | undefined
      if (!early && encoding !== 'identity') {
        const zoptions = { chunkSize: Q, highWaterMark: 1 }
        decoder =
          encoding === 'gzip'
            ? createGunzip(zoptions)
            : encoding === 'deflate'
              ? createInflate(zoptions)
              : createBrotliDecompress(zoptions)
        decoder.on('error', (error) =>
          fail(
            error instanceof ModelProviderError
              ? error
              : errorFor(
                  'malformed_response',
                  'Invalid compressed provider response'
                )
          )
        )
        source.on('error', fail)
        const wireSource = source
        const connectedDecoder = decoder
        pipelineCompletion = new Promise((done) => {
          pipeline(wireSource, connectedDecoder, (error) => {
            if (error) fail(error)
            done(error)
          })
        })
      } else source.on('error', fail)
      const output = decoder ?? source
      async function* decodedViews() {
        for await (const raw of output.iterator({ destroyOnReturn: false })) {
          const chunk = Buffer.isBuffer(raw) ? raw : Buffer.from(raw)
          for (let offset = 0; offset < chunk.byteLength; offset += Q)
            yield chunk.subarray(offset, Math.min(offset + Q, chunk.byteLength))
        }
      }
      const iterator = decodedViews()
      const stream = new ReadableStream<Uint8Array>(
        {
          start(webController) {
            controller = webController
          },
          async pull(webController) {
            if (terminal) return
            try {
              const { done, value } = await iterator.next()
              if (terminal) return
              if (done) {
                // A decoder may end at its compressed frame before HTTP EOF.
                // Wire limits and framing remain authoritative until the source completes.
                if (pipelineCompletion) await pipelineCompletion
                if (terminal) return
                terminal = true
                cleanup()
                webController.close()
                return
              }
              const view = value
              if (metrics) metrics.decodedObserved += view.byteLength
              if (view.byteLength > limit - decodedAccepted)
                throw errorFor(
                  'response_too_large',
                  `Provider response exceeded ${limit} bytes`
                )
              decodedAccepted += view.byteLength
              if (metrics) metrics.decodedAccepted = decodedAccepted
              webController.enqueue(view)
              sample()
              if (metrics)
                metrics.maxWebQueue = Math.max(
                  metrics.maxWebQueue,
                  -(webController.desiredSize ?? 0)
                )
            } catch (error) {
              fail(error)
            }
          },
          cancel() {
            if (!terminal) {
              terminal = true
              cleanup()
              destroy()
            }
          }
        },
        { highWaterMark: 0, size: (chunk) => chunk.byteLength }
      )
      try {
        const result = new Response(stream, {
          status,
          statusText: incoming.statusMessage ?? '',
          headers: responseHeaders
        })
        headersReturned = true
        resolve(result)
        if (early) fail(early)
      } catch (error) {
        fail(error)
      }
    }
    const request: ClientRequest =
      url.protocol === 'https:'
        ? httpsRequest(options, receive)
        : httpRequest(options, receive)
    request.maxHeadersCount = 0
    request.on('error', (error: NodeJS.ErrnoException) =>
      fail(
        error.code?.startsWith('HPE_')
          ? errorFor('malformed_response', 'Invalid provider HTTP headers')
          : error
      )
    )
    signal?.addEventListener('abort', onAbort, { once: true })
    if (signal?.aborted) {
      onAbort()
      return
    }
    request.end(body === undefined ? undefined : Buffer.from(body))
  })
}

function stripBrackets(value: string): string {
  return value.replace(/^\[|\]$/g, '')
}

function pinnedLookup(address: string): LookupFunction {
  const family = isIP(address)
  if (family === 0) throw new Error('Resolved address is not an IP literal')
  // Node 22+ connect lookup asks for every address (`all: true`, used by
  // autoSelectFamily); answer in the shape requested, always with the pin.
  return (_hostname, options, callback) => {
    if (options.all === true) {
      callback(null, [{ address, family }])
      return
    }
    callback(null, address, family)
  }
}

function toHeaders(value: unknown): Headers {
  const headers = new Headers()
  if (value instanceof Headers) {
    value.forEach((entry, name) => headers.set(name, entry))
    return headers
  }
  if (Array.isArray(value)) {
    for (const entry of value) {
      if (Array.isArray(entry) && entry.length >= 2) {
        headers.set(String(entry[0]), String(entry[1]))
      }
    }
    return headers
  }
  if (value && typeof value === 'object') {
    for (const [name, entry] of Object.entries(value)) {
      if (Array.isArray(entry)) {
        headers.set(name, entry.map(String).join(', '))
      } else if (entry !== undefined) {
        headers.set(name, String(entry))
      }
    }
  }
  return headers
}

async function encodeBody(value: unknown): Promise<Uint8Array | undefined> {
  if (value === undefined || value === null) return undefined
  if (typeof value === 'string') return new TextEncoder().encode(value)
  if (value instanceof Uint8Array) return value
  if (value instanceof ArrayBuffer) return new Uint8Array(value)
  if (ArrayBuffer.isView(value)) {
    return new Uint8Array(value.buffer, value.byteOffset, value.byteLength)
  }
  if (value instanceof URLSearchParams) {
    return new TextEncoder().encode(value.toString())
  }
  if (typeof Blob !== 'undefined' && value instanceof Blob) {
    return new Uint8Array(await value.arrayBuffer())
  }
  throw new Error('Unsupported request body for bound Node transport')
}

function asAbortSignal(value: unknown): AbortSignal | undefined {
  if (
    value &&
    typeof value === 'object' &&
    'aborted' in value &&
    'addEventListener' in value &&
    'removeEventListener' in value
  ) {
    return value as AbortSignal
  }
  return undefined
}
