import { describe, expect, it } from 'vitest'
import { PromptRegistry, type PromptRecordInput } from '../prompt-registry.ts'

const input: PromptRecordInput = {
  promptId: 'r8-authority',
  version: '1',
  content: 'Synthetic classification fixture.',
  owner: 'synthetic-owner',
  approvedBy: 'synthetic-approval',
  status: 'approved',
  effectiveFrom: '2026-01-01T00:00:00Z',
  effectiveUntil: '2027-01-01T00:00:00Z',
  classification: 'CLINICAL',
  tenantId: 'tenant_00000000-0000-4000-8000-000000000998'
}

describe('D009-R8 prompt authority', () => {
  for (const access of ['register', 'get', 'list', 'resolve']) {
    for (const [field, value] of Object.entries({
      classification: 'INTERNAL',
      status: 'draft',
      tenantId: 'other',
      sha256: '0'.repeat(64),
      content: 'changed',
      owner: 'other',
      approvedBy: 'other',
      effectiveFrom: '2028-01-01T00:00:00Z',
      effectiveUntil: '2026-01-01T00:00:00Z',
      promptId: 'other',
      version: '2'
    })) {
      it(`${access} alias cannot change ${field}`, () => {
        const registry = new PromptRegistry()
        const first = registry.register(input)
        const original = { ...first }
        const alias =
          access === 'register'
            ? first
            : access === 'get'
              ? registry.get(input.promptId, input.version)
              : access === 'list'
                ? registry.list()[0]
                : registry.resolve(
                    { promptId: input.promptId, version: input.version },
                    {
                      ...(input.tenantId ? { tenantId: input.tenantId } : {}),
                      at: new Date('2026-10-04')
                    }
                  )
        expect(alias).toBeDefined()
        expect(() => Object.defineProperty(alias, field, { value })).toThrow()
        expect(registry.get(input.promptId, input.version)).toEqual(original)
      })
    }
  }

  it('duplicate same-content registration preserves original approval metadata', () => {
    const registry = new PromptRegistry()
    const first = registry.register(input)
    const duplicate = registry.register({
      ...input,
      classification: 'INTERNAL',
      status: 'draft',
      owner: 'replacement',
      approvedBy: 'replacement',
      tenantId: 'replacement',
      effectiveFrom: '2028-01-01T00:00:00Z',
      effectiveUntil: '2029-01-01T00:00:00Z'
    })
    expect(duplicate).toBe(first)
    expect(duplicate).toMatchObject(input)
    expect(Object.isFrozen(duplicate)).toBe(true)
  })

  it('cannot approve a previously draft version by duplicate registration', () => {
    const registry = new PromptRegistry()
    registry.register({ ...input, status: 'draft' })
    registry.register(input)
    expect(() =>
      registry.resolve({ promptId: input.promptId, version: input.version })
    ).toThrow(/not approved/)
  })

  it('different-content duplicates still reject and retain the pinned version', () => {
    const registry = new PromptRegistry()
    const first = registry.register(input)
    expect(() => registry.register({ ...input, content: 'other' })).toThrow(
      /different content/
    )
    expect(registry.list()).toEqual([first])
  })

  it('list array changes cannot remove authoritative records', () => {
    const registry = new PromptRegistry()
    const first = registry.register(input)
    registry.list().splice(0)
    expect(registry.get(input.promptId, input.version)).toBe(first)
  })
})
