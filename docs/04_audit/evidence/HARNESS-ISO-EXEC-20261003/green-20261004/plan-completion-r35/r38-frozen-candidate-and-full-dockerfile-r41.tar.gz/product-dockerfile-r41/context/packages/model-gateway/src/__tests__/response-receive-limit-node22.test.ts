// @vitest-environment node
import { createServer } from 'node:http'
import type { AddressInfo } from 'node:net'
import { expect, it } from 'vitest'
import { OpenAICompatibleProvider } from '../providers/openai-compatible.ts'
import type { ProviderRequest } from '../contracts.ts'

const request = (signal = new AbortController().signal): ProviderRequest => ({
  requestId: 'req_synthetic_receive',
  tenantId: 'tenant_00000000-0000-4000-8000-000000000001',
  correlationId: 'corr_synthetic_receive',
  model: 'synthetic',
  input: { messages: [{ role: 'user', content: 'Sort synthetic colors' }] },
  temperature: 0,
  maxTokens: 8,
  promptSha256: 'a'.repeat(64),
  timeoutMs: 10000,
  signal
})
it('R02 / P12 rejects before the paced server finishes, without waiting for EOF', async () => {
  const planned = 1048631
  let sent = 0,
    finished = false,
    crossed = 0,
    closed = 0
  const timers = new Set<ReturnType<typeof setTimeout>>()
  const later = (fn: () => void, ms: number) => {
    const timer = setTimeout(() => {
      timers.delete(timer)
      fn()
    }, ms)
    timers.add(timer)
  }
  const server = createServer((_req, res) => {
    res.on('close', () => {
      closed = performance.now()
      for (const t of timers) clearTimeout(t)
      timers.clear()
    })
    res.writeHead(200, { 'content-type': 'application/json' })
    res.flushHeaders()
    const send = () => {
      if (res.destroyed) return
      const count = Math.min(512, planned - sent)
      res.write(Buffer.alloc(count, 32))
      sent += count
      if (sent > 1024 && !crossed) {
        crossed = performance.now()
        later(send, 2100)
        return
      }
      if (sent === planned) {
        finished = true
        res.end()
        return
      }
      later(send, 1)
    }
    send()
  })
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve))
  try {
    const provider = new OpenAICompatibleProvider({
      id: 'synthetic',
      model: 'synthetic',
      location: 'local',
      baseUrl: `http://127.0.0.1:${(server.address() as AddressInfo).port}`,
      allowPrivateNetworks: true,
      allowHttp: true,
      maxResponseBytes: 1024
    })
    await expect(provider.execute(request())).rejects.toMatchObject({
      kind: 'response_too_large',
      retryable: false
    })
    const elapsed = performance.now() - crossed

    expect(crossed).toBeGreaterThan(0)
    expect(elapsed).toBeLessThan(1000)
    expect(finished).toBe(false)
    await new Promise((resolve) => setTimeout(resolve, 30))
    expect(closed - crossed).toBeLessThan(1000)
    expect(closed).toBeGreaterThan(0)
    process.stdout.write(
      'P12 ' +
        JSON.stringify({
          planned,
          sent,
          finished,
          elapsed,
          closed,
          crossed,
          closeElapsed: closed - crossed,
          node: process.version
        }) +
        '\n'
    )
  } finally {
    for (const t of timers) clearTimeout(t)
    server.closeAllConnections()
    await new Promise<void>((resolve) => server.close(() => resolve()))
  }
}, 10000)

import { createServer as createTcpServer, type Socket } from 'node:net'
import type { ServerResponse, IncomingMessage } from 'node:http'
import { gzipSync, deflateSync, brotliCompressSync } from 'node:zlib'
import { getEventListeners } from 'node:events'
import { OllamaProvider } from '../providers/ollama.ts'
import {
  fetchWithResolvedAddress,
  type ReceiveMetrics
} from '../providers/ssrf-node.ts'
import { fetchWithSsrfGuard } from '@cvg/shared'

const pause = (ms: number) =>
  new Promise<void>((resolve) => setTimeout(resolve, ms))
function metrics(): ReceiveMetrics {
  return {
    wireObserved: 0,
    wireAccepted: 0,
    decodedObserved: 0,
    decodedAccepted: 0,
    maxNativeChunk: 0,
    maxWireQueue: 0,
    maxDecoderReadQueue: 0,
    maxDecoderWriteQueue: 0,
    maxWebQueue: 0
  }
}
async function httpFixture(
  handler: (req: IncomingMessage, res: ServerResponse) => void,
  run: (url: string, sockets: Set<Socket>) => Promise<void>
) {
  const sockets = new Set<Socket>()
  const server = createServer(handler)
  server.on('connection', (s) => {
    sockets.add(s)
    s.on('close', () => sockets.delete(s))
  })
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve))
  try {
    await run(
      `http://127.0.0.1:${(server.address() as AddressInfo).port}`,
      sockets
    )
  } finally {
    server.closeAllConnections()
    await new Promise<void>((resolve) => server.close(() => resolve()))
    await pause(5)
    expect(sockets.size).toBe(0)
  }
}
const openai = (url: string, limit?: number) =>
  new OpenAICompatibleProvider({
    id: 'synthetic',
    model: 'synthetic',
    location: 'local',
    baseUrl: url,
    allowPrivateNetworks: true,
    allowHttp: true,
    ...(limit === undefined ? {} : { maxResponseBytes: limit })
  })
const ollama = (url: string, limit?: number) =>
  new OllamaProvider({
    model: 'synthetic',
    baseUrl: url,
    allowPrivateNetworks: true,
    ...(limit === undefined ? {} : { maxResponseBytes: limit })
  })
const json = (n: number) =>
  Buffer.from(
    JSON.stringify({
      choices: [{ message: { content: 'é🙂' + 'x'.repeat(n) } }]
    })
  )
async function pinned(
  url: string,
  limit = 1024,
  m = metrics(),
  signal = new AbortController().signal
) {
  return fetchWithResolvedAddress(url, { signal }, ['127.0.0.1'], {
    maxResponseBytes: limit,
    providerId: 'synthetic',
    metrics: m
  })
}

it('R01 byte boundaries B-1/B/B+1 and split multibyte UTF-8', async () => {
  const data = json(970)
  const B = data.byteLength
  for (const delta of [-1, 0, 1])
    await httpFixture(
      (_req, res) => {
        const body = json(970 + delta)
        res.writeHead(200)
        for (let i = 0; i < body.length; i++) res.write(body.subarray(i, i + 1))
        res.end()
      },
      async (url) => {
        if (delta === 1)
          await expect(openai(url, B).execute(request())).rejects.toMatchObject(
            { kind: 'response_too_large' }
          )
        else
          expect((await openai(url, B).execute(request())).text).toBe(
            'é🙂' + 'x'.repeat(970 + delta)
          )
      }
    )
})

it('R03 Content-Length over W rejects on headers before a blocked body; exact and absent CL pass', async () => {
  await httpFixture(
    (_req, res) => {
      res.writeHead(200, { 'content-length': '1025' })
      res.flushHeaders()
    },
    async (url, sockets) => {
      const start = performance.now()
      await expect(openai(url, 1024).execute(request())).rejects.toMatchObject({
        kind: 'response_too_large'
      })
      expect(performance.now() - start).toBeLessThan(1000)
      await pause(20)
      expect(sockets.size).toBe(0)
    }
  )
  for (const cl of [true, false])
    await httpFixture(
      (_req, res) => {
        const b = json(30)
        res.writeHead(200, cl ? { 'content-length': String(b.length) } : {})
        res.end(b)
      },
      async (url) => {
        expect(
          (await openai(url, json(30).length).execute(request())).text
        ).toBe('é🙂' + 'x'.repeat(30))
      }
    )
})

async function tcpFixture(bytes: string, run: (url: string) => Promise<void>) {
  const sockets = new Set<Socket>()
  const server = createTcpServer((socket) => {
    sockets.add(socket)
    socket.on('close', () => sockets.delete(socket))
    socket.once('data', () => socket.end(bytes))
  })
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve))
  try {
    await run(`http://127.0.0.1:${(server.address() as AddressInfo).port}`)
  } finally {
    for (const socket of sockets) socket.destroy()
    await new Promise<void>((resolve) => server.close(() => resolve()))
    await pause(5)
    expect(sockets.size).toBe(0)
  }
}
it.each([
  ['invalid CL', 'Content-Length: nope\r\n', 'malformed_response'],
  [
    'duplicate CL',
    'Content-Length: 2\r\nContent-Length: 3\r\n',
    'malformed_response'
  ],
  [
    'CL + TE',
    'Content-Length: 2\r\nTransfer-Encoding: chunked\r\n',
    'malformed_response'
  ],
  ['truncated high CL', 'Content-Length: 100\r\n', 'connection']
])(
  'R04 raw TCP %s fails without partial result',
  async (_name, headers, kind) => {
    await tcpFixture(
      'HTTP/1.1 200 OK\r\n' + headers + '\r\n{}',
      async (url) =>
        await expect(
          openai(url, 1024).execute(request())
        ).rejects.toMatchObject({ kind })
    )
  }
)
it('R04 low CL counts only the framed message; reset yields connection', async () => {
  await tcpFixture(
    'HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\n{}',
    async (url) => {
      const r = await pinned(url)
      expect(await r.text()).toBe('{}')
    }
  )
  // Bytes after the framed message trigger Node's parser; they aren't counted as payload.
  await tcpFixture(
    'HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\n{}OUTSIDE_MESSAGE',
    async (url) =>
      await expect(openai(url).execute(request())).rejects.toMatchObject({
        kind: 'malformed_response'
      })
  )
  await httpFixture(
    (_req, res) => {
      res.writeHead(200)
      res.write('{')
      setTimeout(() => res.destroy(), 10)
    },
    async (url) =>
      await expect(openai(url).execute(request())).rejects.toMatchObject({
        kind: 'connection'
      })
  )
})

it.each([
  ['gzip', gzipSync],
  ['deflate', deflateSync],
  ['br', brotliCompressSync]
] as const)(
  'R05 %s decoded success/bomb/checksum/truncation and cleanup',
  async (encoding, compress) => {
    const good = json(40),
      bomb = json(10000)
    for (const [body, kind] of [
      [compress(good), null],
      [compress(bomb), 'response_too_large'],
      [compress(good).subarray(0, 3), 'malformed_response'],
      [Buffer.from('broken-compressed-stream'), 'malformed_response']
    ] as const) {
      await httpFixture(
        (_req, res) => {
          res.writeHead(200, { 'content-encoding': encoding })
          res.end(body)
        },
        async (url, sockets) => {
          if (kind)
            await expect(
              openai(url, 1024).execute(request())
            ).rejects.toMatchObject({ kind })
          else
            expect((await openai(url, 1024).execute(request())).text).toBe(
              'é🙂' + 'x'.repeat(40)
            )
          await pause(10)
          expect(sockets.size).toBe(0)
        }
      )
    }
    // Incompressible compressed body is larger than its decoded body; W independently wins.
    const tiny = json(0)
    const wire = compress(tiny)
    expect(wire.length).toBeGreaterThan(tiny.length)
    await httpFixture(
      (_req, res) => {
        res.writeHead(200, { 'content-encoding': encoding })
        res.end(wire)
      },
      async (url) =>
        await expect(
          openai(url, tiny.length).execute(request())
        ).rejects.toMatchObject({ kind: 'response_too_large' })
    )
  }
)
it.each(['unknown', 'gzip, br', 'gzip, gzip'])(
  'R05 unknown/chained encoding %s errors early',
  async (encoding) => {
    await httpFixture(
      (_req, res) => {
        res.writeHead(200, { 'content-encoding': encoding })
        res.flushHeaders()
      },
      async (url) =>
        await expect(openai(url).execute(request())).rejects.toMatchObject({
          kind: 'malformed_response'
        })
    )
  }
)
it('R05 gzip checksum and decoded metadata; metrics and backpressure bounded by Q', async () => {
  const encoded = gzipSync(json(800))
  encoded[encoded.length - 1] = (encoded[encoded.length - 1] ?? 0) ^ 255
  await httpFixture(
    (_req, res) => {
      res.writeHead(200, { 'content-encoding': 'gzip' })
      res.end(encoded)
    },
    async (url) =>
      await expect(openai(url).execute(request())).rejects.toMatchObject({
        kind: 'malformed_response'
      })
  )
  const data = json(200000),
    wire = gzipSync(data),
    m = metrics()
  await httpFixture(
    (_req, res) => {
      res.writeHead(200, {
        'content-encoding': 'gzip',
        'content-length': String(wire.length)
      })
      res.end(wire)
    },
    async (url) => {
      const r = await pinned(url, 262144, m)
      expect(r.headers.has('content-length')).toBe(false)
      expect(r.headers.has('content-encoding')).toBe(false)
      await pause(20)
      expect(m.decodedAccepted).toBe(0)
      expect(await r.text()).toBe(data.toString())
      expect(m.wireAccepted).toBe(wire.length)
      expect(m.decodedAccepted).toBe(data.length)
      for (const key of [
        'maxWireQueue',
        'maxDecoderReadQueue',
        'maxDecoderWriteQueue',
        'maxWebQueue'
      ] as const)
        expect(m[key]).toBeLessThanOrEqual(65536)
      console.log('R05 metrics', JSON.stringify(m))
    }
  )
})
it('R06 headers, many small headers and oversized trailers fail closed', async () => {
  for (const headers of [
    'X-Big: ' + 'x'.repeat(17000) + '\r\n',
    Array.from({ length: 2200 }, (_, i) => `x-${i}: v\r\n`).join('')
  ])
    await tcpFixture(
      'HTTP/1.1 200 OK\r\n' + headers + 'Content-Length: 2\r\n\r\n{}',
      async (url) =>
        await expect(openai(url).execute(request())).rejects.toMatchObject({
          kind: 'malformed_response'
        })
    )
  await tcpFixture(
    'HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n1\r\n{\r\n0\r\nX-Trailer: ' +
      'x'.repeat(17000) +
      '\r\n\r\n',
    async (url) =>
      await expect(openai(url).execute(request())).rejects.toMatchObject({
        kind: 'malformed_response'
      })
  )
  // More than Node's usual 2000-count default, but under H: no silent truncation.
  const headers = Array.from(
    { length: 2050 },
    (_, i) => `a${i.toString(36)}: \r\n`
  ).join('')
  await tcpFixture(
    'HTTP/1.1 200 OK\r\n' + headers + 'Content-Length: 2\r\n\r\n{}',
    async (url) => {
      const r = await pinned(url)
      expect(r.headers.get('a' + (2049).toString(36))).toBe('')
      expect(await r.text()).toBe('{}')
    }
  )
})
it('R07 pre-abort zero HTTP/DNS; post-header caller reason and timeout without EOF; reader cancel', async () => {
  let calls = 0,
    dns = 0
  await httpFixture(
    (_req, res) => {
      calls++
      res.writeHead(200)
      res.flushHeaders()
    },
    async (url, sockets) => {
      const aborted = new AbortController()
      aborted.abort(new Error('synthetic shutdown'))
      await expect(
        openai(url).execute(request(aborted.signal))
      ).rejects.toMatchObject({ kind: 'cancelled' })
      expect(calls).toBe(0)
      await expect(
        fetchWithSsrfGuard(
          async () => {
            throw new Error('unreachable')
          },
          'https://provider.invalid',
          { signal: aborted.signal },
          {},
          {
            dnsLookup: async () => {
              dns++
              return ['127.0.0.1']
            }
          }
        )
      ).rejects.toThrow('synthetic shutdown')
      expect(dns).toBe(0)
      const caller = new AbortController()
      const p = openai(url).execute(request(caller.signal))
      await pause(30)
      caller.abort(new Error('synthetic pause'))
      await expect(p).rejects.toMatchObject({ kind: 'cancelled' })
      const deadline = request()
      deadline.timeoutMs = 60
      await expect(openai(url).execute(deadline)).rejects.toMatchObject({
        kind: 'timeout'
      })
      const response = await pinned(url)
      await response.body?.getReader().cancel()
      await pause(20)
      expect(sockets.size).toBe(0)
    }
  )
})
it('R07 abort during a gzip stream preserves caller reason and closes decoder/socket', async () => {
  const data = gzipSync(json(100000))
  await httpFixture(
    (_req, res) => {
      res.writeHead(200, { 'content-encoding': 'gzip' })
      res.write(data.subarray(0, 25))
    },
    async (url, sockets) => {
      const signal = new AbortController()
      const p = openai(url).execute(request(signal.signal))
      await pause(20)
      signal.abort(new Error('synthetic shutdown'))
      await expect(p).rejects.toMatchObject({ kind: 'cancelled' })
      await pause(20)
      expect(sockets.size).toBe(0)
    }
  )
})
it.each([
  [401, 'auth'],
  [429, 'rate_limited'],
  [500, 'unavailable'],
  [301, 'invalid_request'],
  [302, 'invalid_request'],
  [307, 'invalid_request'],
  [308, 'invalid_request']
])(
  'R08 status %s takes priority over huge slow/unknown-encoding body',
  async (status, kind) => {
    let targetCalls = 0
    await httpFixture(
      (_req, res) => {
        targetCalls++
        res.end()
      },
      async (target) => {
        await httpFixture(
          (_req, res) => {
            res.writeHead(Number(status), {
              location: target,
              'content-length': '1048576',
              'content-encoding': 'unknown'
            })
            res.flushHeaders()
          },
          async (url, sockets) => {
            const start = performance.now()
            await expect(
              openai(url, 1024).execute(request())
            ).rejects.toMatchObject({ kind })
            expect(performance.now() - start).toBeLessThan(1000)
            await pause(20)
            expect(sockets.size).toBe(0)
            expect(targetCalls).toBe(0)
          }
        )
      }
    )
  }
)
it.each([openai, ollama])(
  'R11 both providers default B, invalid limits before I/O and custom stream cancelled before EOF',
  async (make) => {
    for (const n of [0, -1, NaN, Infinity, 1.5, 16777217])
      expect(() => make('http://127.0.0.1:9', n)).toThrowError(/byte limit/)
    await httpFixture(
      (_req, res) => {
        res.writeHead(200, { 'content-length': '262145' })
        res.flushHeaders()
      },
      async (url) =>
        await expect(make(url).execute(request())).rejects.toMatchObject({
          kind: 'response_too_large'
        })
    )
    let cancelled = 0,
      pulls = 0
    const fetchImpl = async () =>
      new Response(
        new ReadableStream<Uint8Array>(
          {
            pull(c) {
              pulls++
              c.enqueue(new Uint8Array(1025))
            },
            cancel() {
              cancelled++
            }
          },
          { highWaterMark: 0 }
        )
      )
    const common = {
      model: 'synthetic',
      baseUrl: 'http://127.0.0.1:9',
      allowPrivateNetworks: true,
      maxResponseBytes: 1024,
      fetchImpl
    }
    const provider =
      make === openai
        ? new OpenAICompatibleProvider({
            ...common,
            id: 'synthetic',
            location: 'local',
            allowHttp: true
          })
        : new OllamaProvider(common)
    await expect(provider.execute(request())).rejects.toMatchObject({
      kind: 'response_too_large'
    })
    expect(cancelled).toBe(1)
    expect(pulls).toBe(1)
  }
)
it('R12 100 sequential valid/cancelled/oversized calls release sockets and abort listeners', async () => {
  const before = process.memoryUsage()
  const unhandled: unknown[] = []
  const onUnhandled = (reason: unknown) => unhandled.push(reason)
  process.on('unhandledRejection', onUnhandled)
  let calls = 0
  try {
    await httpFixture(
      (_req, res) => {
        const mode = calls++ % 3
        res.writeHead(200, mode === 2 ? { 'content-encoding': 'gzip' } : {})
        if (mode === 0) res.end(json(2))
        else if (mode === 1) res.flushHeaders()
        else res.end(gzipSync(json(10000)))
      },
      async (url, sockets) => {
        for (let i = 0; i < 100; i++) {
          const controller = new AbortController()
          const count = getEventListeners(controller.signal, 'abort').length
          const p = openai(url, 1024).execute(request(controller.signal))
          if (i % 3 === 1) {
            await pause(5)
            controller.abort(new Error('synthetic pause'))
            await expect(p).rejects.toMatchObject({ kind: 'cancelled' })
          } else if (i % 3 === 2)
            await expect(p).rejects.toMatchObject({
              kind: 'response_too_large'
            })
          else expect((await p).text).toBe('é🙂xx')
          await pause(2)
          expect(sockets.size).toBe(0)
          expect(getEventListeners(controller.signal, 'abort').length).toBe(
            count
          )
        }
      }
    )
    expect(unhandled).toEqual([])
    console.log(
      'R12 memory',
      JSON.stringify({ before, after: process.memoryUsage(), calls })
    )
  } finally {
    process.removeListener('unhandledRejection', onUnhandled)
  }
})

it('R02 / P12 real Node counters retain at most B and bounded stage queues before future EOF', async () => {
  const B = 1024,
    planned = 1048631,
    m = metrics()
  let sent = 0,
    finished = false,
    crossed = 0,
    closed = 0
  const timers = new Set<ReturnType<typeof setTimeout>>()
  const later = (fn: () => void, ms: number) => {
    const t = setTimeout(() => {
      timers.delete(t)
      fn()
    }, ms)
    timers.add(t)
  }
  try {
    await httpFixture(
      (_req, res) => {
        res.on('close', () => {
          closed = performance.now()
          for (const t of timers) clearTimeout(t)
          timers.clear()
        })
        res.writeHead(200)
        res.flushHeaders()
        const send = () => {
          if (res.destroyed) return
          const n = Math.min(512, planned - sent)
          res.write(Buffer.alloc(n, 32))
          sent += n
          if (sent > B && !crossed) {
            crossed = performance.now()
            later(send, 2100)
            return
          }
          if (sent === planned) {
            finished = true
            res.end()
            return
          }
          later(send, 1)
        }
        send()
      },
      async (url) => {
        const r = await pinned(url, B, m)
        await expect(r.text()).rejects.toMatchObject({
          kind: 'response_too_large'
        })
        const elapsed = performance.now() - crossed
        await pause(25)
        expect(elapsed).toBeLessThan(1000)
        expect(closed - crossed).toBeLessThan(1000)
        expect(closed).toBeGreaterThan(0)
        expect(finished).toBe(false)
        expect(m.wireAccepted).toBeLessThanOrEqual(B)
        expect(m.decodedAccepted).toBeLessThanOrEqual(B)
        for (const key of [
          'maxWireQueue',
          'maxDecoderReadQueue',
          'maxDecoderWriteQueue',
          'maxWebQueue'
        ] as const)
          expect(m[key]).toBeLessThanOrEqual(65536)
        process.stdout.write(
          'R02 measured ' +
            JSON.stringify({
              B,
              planned,
              sent,
              finished,
              elapsed,
              closeElapsed: closed - crossed,
              ...m
            }) +
            '\n'
        )
      }
    )
  } finally {
    for (const t of timers) clearTimeout(t)
  }
})
it('R01 real paced UTF-8 split and invalid UTF-8 counts original bytes before replacement', async () => {
  const b = json(12),
    lead = b.indexOf(Buffer.from('é')),
    emoji = b.indexOf(Buffer.from('🙂'))
  await httpFixture(
    (_req, res) => {
      res.writeHead(200)
      res.write(b.subarray(0, lead + 1))
      setTimeout(() => {
        res.write(b.subarray(lead + 1, emoji + 2))
        setTimeout(() => res.end(b.subarray(emoji + 2)), 5)
      }, 5)
    },
    async (url) =>
      expect((await openai(url, b.length).execute(request())).text).toBe(
        'é🙂' + 'x'.repeat(12)
      )
  )
  const invalid = Buffer.concat([
    Buffer.from('{"choices":[{"message":{"content":"'),
    Buffer.from([255]),
    Buffer.from('"}}]}')
  ])
  await httpFixture(
    (_req, res) => res.end(invalid),
    async (url) =>
      expect((await openai(url, invalid.length).execute(request())).text).toBe(
        '\uFFFD'
      )
  )
})
it('R05 million-byte bomb stops before expansion is retained; unknown status body cancellation cannot stall', async () => {
  const b = gzipSync(json(1048576)),
    m = metrics()
  expect(b.length).toBeLessThan(2048)
  await httpFixture(
    (_req, res) => {
      res.writeHead(200, { 'content-encoding': 'gzip' })
      res.end(b)
    },
    async (url) => {
      const r = await pinned(url, 2048, m)
      await expect(r.text()).rejects.toMatchObject({
        kind: 'response_too_large'
      })
      expect(m.decodedAccepted).toBe(0)
      expect(m.decodedObserved).toBeLessThanOrEqual(65536)
      process.stdout.write('R05 bomb ' + JSON.stringify(m) + '\n')
    }
  )
  const custom = new OpenAICompatibleProvider({
    id: 'synthetic',
    baseUrl: 'http://127.0.0.1:9',
    location: 'local',
    model: 'synthetic',
    allowPrivateNetworks: true,
    allowHttp: true,
    fetchImpl: async () =>
      new Response(
        new ReadableStream({
          cancel() {
            return new Promise<void>(() => {})
          }
        }),
        { status: 401, headers: { 'content-encoding': 'unknown' } }
      )
  })
  await expect(custom.execute(request())).rejects.toMatchObject({
    kind: 'auth',
    status: 401
  })
})

it.each([
  ['gzip', gzipSync],
  ['deflate', deflateSync],
  ['br', brotliCompressSync]
] as const)(
  'R05 %s frame EOF cannot bypass the chunked wire limit or publish a partial success',
  async (encoding, compress) => {
    const B = 1024,
      data = json(0),
      wire = Buffer.concat([compress(data), Buffer.alloc(2048)]),
      m = metrics()
    let sent = 0,
      crossed = 0,
      finished = false
    const timers = new Set<ReturnType<typeof setTimeout>>()
    const later = (fn: () => void, ms: number) => {
      const t = setTimeout(() => {
        timers.delete(t)
        fn()
      }, ms)
      timers.add(t)
    }
    try {
      await httpFixture(
        (_req, res) => {
          res.on('close', () => {
            for (const timer of timers) clearTimeout(timer)
            timers.clear()
          })
          res.writeHead(200, { 'content-encoding': encoding })
          res.flushHeaders()
          const send = () => {
            if (res.destroyed) return
            const end = Math.min(sent + 512, wire.length)
            res.write(wire.subarray(sent, end))
            sent = end
            if (sent > B && !crossed) {
              crossed = performance.now()
              later(send, 2100)
              return
            }
            if (sent === wire.length) {
              finished = true
              res.end()
              return
            }
            later(send, 1)
          }
          send()
        },
        async (url, sockets) => {
          const r = await pinned(url, B, m)
          await expect(r.text()).rejects.toMatchObject({
            kind: 'response_too_large'
          })
          const elapsed = performance.now() - crossed
          await pause(20)
          expect(data.length).toBeLessThanOrEqual(B)
          expect(wire.length).toBeGreaterThan(B)
          expect(crossed).toBeGreaterThan(0)
          expect(elapsed).toBeLessThan(1000)
          expect(finished).toBe(false)
          expect(sockets.size).toBe(0)
          expect(m.wireAccepted).toBeLessThanOrEqual(B)
          expect(m.decodedAccepted).toBeLessThanOrEqual(B)
          process.stdout.write(
            'R05 frame EOF ' +
              JSON.stringify({
                encoding,
                B,
                wire: wire.length,
                decoded: data.length,
                sent,
                elapsed,
                finished,
                ...m
              }) +
              '\n'
          )
        }
      )
    } finally {
      for (const timer of timers) clearTimeout(timer)
    }
  }
)
it('R07 caller abort while decoded frame has ended still cancels the pending HTTP body', async () => {
  await httpFixture(
    (_req, res) => {
      res.writeHead(200, { 'content-encoding': 'gzip' })
      res.write(Buffer.concat([gzipSync(json(0)), Buffer.alloc(32)]))
    },
    async (url, sockets) => {
      const controller = new AbortController()
      const p = openai(url, 1024).execute(request(controller.signal))
      await pause(25)
      controller.abort(new Error('synthetic shutdown after frame EOF'))
      await expect(p).rejects.toMatchObject({ kind: 'cancelled' })
      await pause(20)
      expect(sockets.size).toBe(0)
    }
  )
})
