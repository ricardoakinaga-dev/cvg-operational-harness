// @vitest-environment node
import { describe, expect, it, vi } from 'vitest'
import { z } from 'zod'
import {
  ModelGateway,
  PromptRegistry,
  type ModelProvider,
  type StructuredOutputContract
} from '../index.ts'
const TENANT = 'tenant_00000000-0000-4000-8000-000000000001'
function fixture(text: string, maxOutputChars = 32000) {
  const execute = vi.fn(async () => ({
    text,
    usage: { inputTokens: 1, outputTokens: 1 },
    providerId: 'synthetic',
    model: 'synthetic',
    externalCall: false
  }))
  const provider: ModelProvider = {
    id: 'synthetic',
    location: 'local',
    models: ['synthetic'],
    execute
  }
  const prompts = new PromptRegistry()
  const prompt = prompts.register({
    promptId: 'neutral-test',
    version: '1',
    content: 'Return a color.',
    owner: 'fixture',
    approvedBy: 'synthetic-only',
    status: 'approved',
    classification: 'INTERNAL',
    effectiveFrom: '2026-01-01T00:00:00Z',
    tenantId: TENANT
  })
  const events: string[] = []
  const gateway = new ModelGateway({
    providers: [provider],
    prompts,
    profiles: {
      balanced: {
        name: 'balanced',
        providerId: provider.id,
        model: 'synthetic',
        location: 'local',
        temperature: 0,
        maxTokens: 1500,
        timeoutMs: 1000,
        maxCostUsd: 1,
        estimatedCostUsd: 0,
        maxRetries: 2,
        pricing: { inputPer1kUsd: 0, outputPer1kUsd: 0 }
      }
    },
    maxOutputChars,
    onEvent: (event) => events.push(event.type)
  })
  const request = {
    requestId: 'request_00000001',
    correlationId: 'correlation_00000001',
    tenantId: TENANT,
    promptId: prompt.promptId,
    promptVersion: prompt.version,
    promptSha256: prompt.sha256,
    modelProfile: 'balanced' as const,
    dataClassification: 'INTERNAL' as const,
    input: {
      messages: [{ role: 'user' as const, content: 'Return the color blue.' }]
    }
  }
  return { gateway, execute, events, request }
}
const strip = (text: string) =>
  text
    .trim()
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/\s*```$/, '')
const schema = z.object({ color: z.string() })

describe('D009 synchronous structured normalizer', () => {
  it.each(['{"color":"blue"}', ' \n```json\n{"color":"blue"}\n```  '])(
    'normalizes complete bounded text, preserving original output for %s',
    async (text) => {
      const f = fixture(text),
        normalizeText = vi.fn(strip)
      const result = await f.gateway.generate({
        ...f.request,
        structuredOutput: {
          schemaName: 'neutral',
          schema,
          normalizeText,
          failClosed: true
        }
      })
      expect(result.output).toEqual({ text, structured: { color: 'blue' } })
      expect(normalizeText).toHaveBeenCalledExactlyOnceWith(text)
      expect(f.execute).toHaveBeenCalledOnce()
      expect(f.events).toContain('model.call.completed')
    }
  )

  it('without a callback keeps plain JSON acceptance and fenced JSON rejection', async () => {
    const good = fixture('{"color":"blue"}')
    await expect(
      good.gateway.generate({
        ...good.request,
        structuredOutput: { schemaName: 'neutral', schema }
      })
    ).resolves.toMatchObject({ output: { structured: { color: 'blue' } } })
    const bad = fixture('```json\n{"color":"blue"}\n```')
    await expect(
      bad.gateway.generate({
        ...bad.request,
        structuredOutput: { schemaName: 'neutral', schema }
      })
    ).rejects.toMatchObject({ code: 'schema_invalid', retryable: false })
    expect(bad.execute).toHaveBeenCalledOnce()
  })

  it.each([
    [
      'throw',
      () => {
        throw new Error('secret callback reason')
      }
    ],
    ['number', () => 3],
    ['promise', () => Promise.resolve('{"color":"blue"}')],
    [
      'rejected promise',
      () => Promise.reject(new Error('async callback invalid'))
    ],
    ['expansion', (text: string) => text + ' '],
    ['invalid JSON', () => 'broken'],
    ['invalid schema', () => '{}']
  ])('fails closed without retry or output on %s', async (_kind, callback) => {
    const f = fixture('{"color":"blue"}')
    const normalizeText = callback as StructuredOutputContract['normalizeText']
    await expect(
      f.gateway.generate({
        ...f.request,
        structuredOutput: {
          schemaName: 'neutral',
          schema,
          normalizeText: normalizeText!,
          failClosed: false
        }
      })
    ).rejects.toMatchObject({ code: 'schema_invalid', retryable: false })
    expect(f.execute).toHaveBeenCalledOnce()
    expect(f.events).not.toContain('model.retry.scheduled')
    expect(f.events).not.toContain('model.call.completed')
  })

  it('rejects UTF8 byte expansion even when UTF16 length does not grow', async () => {
    const f = fixture('"a"')
    await expect(
      f.gateway.generate({
        ...f.request,
        structuredOutput: {
          schemaName: 'unicode',
          schema: z.string(),
          normalizeText: () => '"é"'
        }
      })
    ).rejects.toMatchObject({ code: 'schema_invalid' })
  })

  it('schema safeParse throw is schema_invalid, including async refinements', async () => {
    for (const schema of [
      z.string().transform(() => {
        throw new Error('untrusted transform reason')
      }),
      z.string().transform(async (x) => x)
    ]) {
      const f = fixture('"blue"')
      await expect(
        f.gateway.generate({
          ...f.request,
          structuredOutput: {
            schemaName: 'throwing',
            schema,
            normalizeText: strip
          }
        })
      ).rejects.toMatchObject({ code: 'schema_invalid' })
      expect(f.execute).toHaveBeenCalledOnce()
    }
  })

  it('rejects an oversized full normalization input before invoking the callback', async () => {
    const f = fixture(' '.repeat(1000) + '{"color":"blue"}', 32)
    const normalizeText = vi.fn(strip)
    await expect(
      f.gateway.generate({
        ...f.request,
        structuredOutput: { schemaName: 'neutral', schema, normalizeText }
      })
    ).rejects.toMatchObject({ code: 'schema_invalid' })
    expect(normalizeText).not.toHaveBeenCalled()
    expect(f.events).not.toContain('model.call.completed')
  })
})
