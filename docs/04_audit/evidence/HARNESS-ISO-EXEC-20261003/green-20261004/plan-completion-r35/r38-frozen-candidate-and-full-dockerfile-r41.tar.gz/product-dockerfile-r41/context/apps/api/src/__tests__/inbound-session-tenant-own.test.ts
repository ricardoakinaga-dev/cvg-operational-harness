// @vitest-environment node
import Fastify from 'fastify'
import { describe, expect, it, vi } from 'vitest'
import { buildServer } from '../server.ts'
import { installOperatorSessionHook } from '../operator-session-hook.ts'
import { requiresOperatorSessionBoundary } from '../operator-session-route-boundary.ts'
import type { OperatorSessionStore } from '../operator-session.ts'
import {
  HmacWebhookVerifier,
  createWebhookSignature
} from '../webhook-security.ts'

const tenantA = 'tenant_11111111-1111-4111-8111-111111111111'
const tenantB = 'tenant_22222222-2222-4222-8222-222222222222'
const secret = 'inbound-synthetic-signing-secret-0123456789'
const route = '/v1/webhooks/channels/web/messages'
const template = '/v1/webhooks/channels/:channel/messages'
const cookies = ['unknown', 'expired', 'revoked', 'storefailure', 'valid']

function store() {
  const get = vi.fn(async (id: string) => {
    if (id === 'opsess_storefailure') throw new Error('synthetic store failure')
    if (id === 'opsess_unknown' || id === 'opsess_revoked') return null
    return {
      sessionId: id,
      expiresAt: id === 'opsess_expired' ? 1 : Date.now() + 60_000,
      identity: {
        operatorId: 'synthetic',
        role: 'Admin' as const,
        tenantId: tenantB
      }
    }
  })
  const value: OperatorSessionStore = {
    get,
    async create(input) {
      return { ...input, sessionId: 'valid' }
    },
    async revoke() {}
  }
  return { get, value }
}

function signed(body: unknown, eventId: string) {
  const input = {
    body,
    rawBody: JSON.stringify(body),
    eventId,
    channel: 'web',
    timestampSeconds: Math.floor(Date.now() / 1000)
  }
  return {
    'content-type': 'application/json',
    'x-cvg-webhook-id': eventId,
    'x-cvg-webhook-timestamp': String(input.timestampSeconds),
    'x-cvg-webhook-signature': createWebhookSignature(secret, input)
  }
}

function payload(id: string) {
  return {
    externalMessageId: id,
    senderRef: 'synthetic-sender',
    body: 'Synthetic input',
    receivedAt: new Date().toISOString()
  }
}

describe('own exact operator boundary', () => {
  it('classifies only exact public pairs and defaults every registered alias to operator', () => {
    for (const path of ['/health', '/live', '/ready', '/health/metrics']) {
      for (const method of ['GET', 'HEAD'])
        expect(requiresOperatorSessionBoundary(method, path)).toBe(false)
      for (const method of ['POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'])
        expect(requiresOperatorSessionBoundary(method, path)).toBe(true)
    }
    expect(requiresOperatorSessionBoundary('POST', template)).toBe(false)
    for (const method of ['GET', 'HEAD', 'PUT', 'OPTIONS'])
      expect(requiresOperatorSessionBoundary(method, template)).toBe(true)
    for (const path of [
      '/health/:id',
      '/health/metrics/:id',
      '/health?public=true',
      '/v1/session',
      '/v1/session/logout',
      '/new-route',
      route
    ]) {
      expect(requiresOperatorSessionBoundary('GET', path)).toBe(true)
      expect(requiresOperatorSessionBoundary('POST', path)).toBe(true)
    }
  })

  it.each(cookies)(
    'never looks up cookie %s on resolved public routes, including query strings',
    async (cookie) => {
      const app = Fastify()
      const sessions = store()
      const cookieRead = vi.fn()
      app.addHook('onRequest', async (request) => {
        const value = request.headers.cookie
        Object.defineProperty(request.headers, 'cookie', {
          get() {
            cookieRead()
            return value
          }
        })
      })
      installOperatorSessionHook({
        app,
        enforceHttps: false,
        operatorSessionStore: sessions.value,
        sessionIdentityByHeaders: new WeakMap(),
        sessionRecordByHeaders: new WeakMap(),
        sessionStoreFailureByHeaders: new WeakSet()
      })
      for (const path of ['/health', '/live', '/ready', '/health/metrics'])
        app.get(path, async () => ({ ok: true }))
      app.post(template, async () => ({ ok: true }))
      // Same raw public path with a different method, and an alias template.
      app.post('/health', async () => ({ ok: true }))
      app.get('/health/:alias', async () => ({ ok: true }))
      try {
        for (const path of ['/health', '/live', '/ready', '/health/metrics']) {
          for (const method of ['GET', 'HEAD'] as const) {
            expect(
              (
                await app.inject({
                  method,
                  url: `${path}?q=1`,
                  headers: { cookie: `cvg_operator_session=opsess_${cookie}` }
                })
              ).statusCode
            ).toBe(200)
          }
        }
        expect(
          (
            await app.inject({
              method: 'POST',
              url: `${route}?q=1`,
              headers: { cookie: `cvg_operator_session=opsess_${cookie}` }
            })
          ).statusCode
        ).toBe(200)
        expect(sessions.get).not.toHaveBeenCalled()
        expect(cookieRead).not.toHaveBeenCalled()
        const expected =
          cookie === 'storefailure' ? 503 : cookie === 'valid' ? 200 : 401
        for (const [method, url] of [
          ['POST', '/health'],
          ['GET', '/health/alias']
        ] as const) {
          expect(
            (
              await app.inject({
                method,
                url,
                headers: { cookie: `cvg_operator_session=opsess_${cookie}` }
              })
            ).statusCode
          ).toBe(expected)
        }
        expect(sessions.get).toHaveBeenCalledTimes(2)
        expect(cookieRead).toHaveBeenCalledTimes(2)
      } finally {
        await app.close()
      }
    }
  )
})

describe('own signed ingress corroboration', () => {
  it.each(cookies)(
    'HMAC alone admits input with cookie %s; invalid HMAC stays 401; replay stays 401',
    async (cookie) => {
      const sessions = store()
      const verifier = new HmacWebhookVerifier({ secret })
      const app = buildServer({
        operatorSessionStore: sessions.value,
        webhookVerifier: (input) => verifier.verifyWithLease(input),
        inboundTenantResolver: () => tenantA
      })
      try {
        const body = payload(cookie)
        const headers = {
          ...signed(body, cookie),
          cookie: `cvg_operator_session=opsess_${cookie}`
        }
        const invalid = await app.inject({
          method: 'POST',
          url: route,
          headers: { ...headers, 'x-cvg-webhook-signature': 'sha256=invalid' },
          payload: body
        })
        expect(invalid.statusCode).toBe(401)
        const accepted = await app.inject({
          method: 'POST',
          url: route,
          headers,
          payload: body
        })
        expect(accepted.statusCode).toBe(200)
        expect(accepted.json().data.accepted).toBe(true)
        expect(
          (
            await app.inject({
              method: 'POST',
              url: route,
              headers,
              payload: body
            })
          ).statusCode
        ).toBe(401)
        expect(sessions.get).not.toHaveBeenCalled()
      } finally {
        await app.close()
      }
    }
  )

  it.each([
    tenantB,
    '',
    'invalid',
    null,
    42,
    [tenantA],
    { tenantId: tenantA },
    tenantA.toUpperCase(),
    ` ${tenantA}`
  ])(
    'rejects explicit body claim %j after HMAC and releases its replay lease',
    async (claim) => {
      const resolver = vi.fn(() => tenantA)
      const verifier = new HmacWebhookVerifier({ secret })
      const app = buildServer({
        inboundTenantResolver: resolver,
        webhookVerifier: (input) => verifier.verifyWithLease(input)
      })
      try {
        const body = { ...payload('claim-rejected'), tenantId: claim }
        const headers = signed(body, 'claim-event')
        // Bad HMAC must fail before resolving or inspecting the claim.
        expect(
          (
            await app.inject({
              method: 'POST',
              url: route,
              payload: body,
              headers: { ...headers, 'x-cvg-webhook-signature': 'invalid' }
            })
          ).statusCode
        ).toBe(401)
        expect(resolver).not.toHaveBeenCalled()
        for (let attempt = 0; attempt < 2; attempt++) {
          const rejected = await app.inject({
            method: 'POST',
            url: route,
            payload: body,
            headers
          })
          expect(rejected.statusCode).toBe(403)
          expect(rejected.json().error).toEqual({
            code: 'forbidden',
            message: 'Inbound tenant claim is invalid'
          })
          expect(rejected.json().data).toBeNull()
        }
        expect(resolver).toHaveBeenCalledTimes(2)
        const corrected = { ...body, tenantId: tenantA }
        const accepted = await app.inject({
          method: 'POST',
          url: route,
          payload: corrected,
          headers: signed(corrected, 'claim-event')
        })
        expect(accepted.statusCode).toBe(200)
        expect(accepted.json().data.accepted).toBe(true)
      } finally {
        await app.close()
      }
    }
  )

  it.each([
    tenantB,
    '',
    'invalid',
    tenantA.toUpperCase(),
    `${tenantA},${tenantA}`
  ])('rejects header claim %j even when body agrees', async (claim) => {
    const verifier = new HmacWebhookVerifier({ secret })
    const app = buildServer({
      inboundTenantResolver: () => tenantA,
      webhookVerifier: (input) => verifier.verifyWithLease(input)
    })
    try {
      const body = { ...payload('header-claim'), tenantId: tenantA }
      expect(
        (
          await app.inject({
            method: 'POST',
            url: route,
            payload: body,
            headers: { ...signed(body, 'header-event'), 'x-tenant-id': claim }
          })
        ).statusCode
      ).toBe(403)
      expect(
        (
          await app.inject({
            method: 'POST',
            url: route,
            payload: body,
            headers: { ...signed(body, 'header-event'), 'x-tenant-id': tenantA }
          })
        ).statusCode
      ).toBe(200)
    } finally {
      await app.close()
    }
  })

  it('honors injected tenant authority and ignores nested metadata and operator cookies', async () => {
    let canonical = tenantB
    const sessions = store()
    const verifier = new HmacWebhookVerifier({ secret })
    const app = buildServer({
      operatorSessionStore: sessions.value,
      inboundTenantResolver: () => canonical,
      webhookVerifier: (input) => verifier.verifyWithLease(input)
    })
    try {
      const body = {
        ...payload('independent-tenant'),
        metadata: { tenantId: tenantA },
        operator: { tenantId: tenantA }
      }
      const first = await app.inject({
        method: 'POST',
        url: route,
        payload: body,
        headers: {
          ...signed(body, 'independent-b'),
          cookie: 'cvg_operator_session=opsess_valid'
        }
      })
      canonical = tenantA
      const second = await app.inject({
        method: 'POST',
        url: route,
        payload: body,
        headers: signed(body, 'independent-a')
      })
      expect(first.statusCode).toBe(200)
      expect(second.statusCode).toBe(200)
      expect(first.json().data.accepted).toBe(true)
      expect(second.json().data.accepted).toBe(true)
      expect(first.json().data.conversationId).not.toBe(
        second.json().data.conversationId
      )
      expect(sessions.get).not.toHaveBeenCalled()
    } finally {
      await app.close()
    }
  })
})
