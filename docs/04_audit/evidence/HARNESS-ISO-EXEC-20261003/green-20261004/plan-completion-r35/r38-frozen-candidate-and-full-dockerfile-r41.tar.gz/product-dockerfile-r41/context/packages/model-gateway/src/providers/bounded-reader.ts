import { ModelProviderError } from '../errors.ts'

export const MAX_RESPONSE_BYTES = 16 * 1024 * 1024
export const RECEIVE_CHUNK_BYTES = 64 * 1024

export function validateResponseLimit(
  providerId: string,
  value: number
): number {
  if (
    !Number.isSafeInteger(value) ||
    value <= 0 ||
    value > MAX_RESPONSE_BYTES
  ) {
    throw new ModelProviderError(
      providerId,
      'invalid_request',
      'Invalid provider response byte limit'
    )
  }
  return value
}

export function abortReason(signal: AbortSignal): Error {
  return signal.reason instanceof Error
    ? signal.reason
    : new DOMException('Request aborted', 'AbortError')
}

export async function cancelBody(response: Response): Promise<void> {
  try {
    void response.body?.cancel().catch(() => {})
  } catch {
    /* Cleanup cannot replace the primary error. */
  }
}

/** Custom fetch guarantees decoded bytes only. Count original bytes before UTF-8 replacement. */
export async function readBoundedResponse(
  response: Response,
  providerId: string,
  limit: number,
  signal: AbortSignal
): Promise<string> {
  if (signal.aborted) {
    await cancelBody(response)
    throw abortReason(signal)
  }
  if (response.body === undefined)
    throw new Error('Provider response has no readable body')
  if (!response.body) return ''
  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let accepted = 0
  const parts: string[] = []
  let rejectAbort: (error: Error) => void = () => {}
  const aborted = new Promise<never>((_resolve, reject) => {
    rejectAbort = reject
  })
  const onAbort = () => {
    rejectAbort(abortReason(signal))
    void reader.cancel().catch(() => {})
  }
  signal.addEventListener('abort', onAbort, { once: true })
  if (signal.aborted) onAbort()
  try {
    for (;;) {
      const { done, value } = await Promise.race([reader.read(), aborted])
      if (signal.aborted) throw abortReason(signal)
      if (done) break
      if (value.byteLength > limit - accepted) {
        throw new ModelProviderError(
          providerId,
          'response_too_large',
          `Provider response exceeded ${limit} bytes`
        )
      }
      accepted += value.byteLength
      parts.push(decoder.decode(value, { stream: true }))
    }
    parts.push(decoder.decode())
    return parts.join('')
  } catch (error) {
    parts.length = 0
    // A custom underlying cancel may never resolve. Invoke it but don't wait for EOF.
    void reader.cancel(error).catch(() => {})
    throw error
  } finally {
    signal.removeEventListener('abort', onAbort)
    reader.releaseLock()
  }
}
