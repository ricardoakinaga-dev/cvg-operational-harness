import { expect, it } from 'vitest'
import { CircuitBreaker } from '../circuit-breaker.ts'
import {
  ModelGateway,
  PromptRegistry,
  DeterministicModelProvider
} from '../index.ts'

it('neutral completion releases a HALF_OPEN probe and preserves accumulated successes', () => {
  let now = 0
  const circuit = new CircuitBreaker({
    failureThreshold: 1,
    openMs: 10,
    halfOpenSuccesses: 2,
    clock: () => now
  })
  circuit.onFailure('synthetic')
  now = 11
  expect(circuit.canRequest('synthetic')).toBe(true)
  circuit.onSuccess('synthetic')
  expect(circuit.state('synthetic')).toBe('HALF_OPEN')
  expect(circuit.canRequest('synthetic')).toBe(true)
  expect(circuit.canRequest('synthetic')).toBe(false)
  circuit.onNeutral('synthetic', circuit.probeToken('synthetic'))
  expect(circuit.state('synthetic')).toBe('HALF_OPEN')
  expect(circuit.canRequest('synthetic')).toBe(true)
  circuit.onSuccess('synthetic')
  expect(circuit.state('synthetic')).toBe('CLOSED')
})

it('neutral completion never fabricates success, failure, refresh or reopening in a closed/open circuit', () => {
  let now = 0
  const circuit = new CircuitBreaker({
    failureThreshold: 2,
    openMs: 10,
    clock: () => now
  })
  circuit.onFailure('synthetic')
  circuit.onNeutral('synthetic', undefined)
  circuit.onFailure('synthetic')
  expect(circuit.state('synthetic')).toBe('OPEN')
  now = 100
  circuit.onNeutral('synthetic', undefined)
  expect(circuit.state('synthetic')).toBe('HALF_OPEN')
  expect(circuit.canRequest('synthetic')).toBe(true)
})

it('releases the probe when canRequest itself crosses the OPEN deadline before admission', async () => {
  let now = Date.parse('2026-10-04T12:00:00Z')
  class BoundaryClockCircuit extends CircuitBreaker {
    override canRequest(key: string): boolean {
      now += 2
      return super.canRequest(key)
    }
  }
  const circuit = new BoundaryClockCircuit({
    failureThreshold: 1,
    openMs: 10,
    halfOpenSuccesses: 1,
    clock: () => now
  })
  circuit.onFailure('synthetic:synthetic')
  now += 9
  const caller = new AbortController()
  let calls = 0
  const provider = new DeterministicModelProvider({
    id: 'synthetic',
    model: 'synthetic',
    respond: () => {
      calls += 1
      if (calls === 1) caller.abort()
      return {
        text: 'blue',
        providerId: 'synthetic',
        model: 'synthetic',
        externalCall: false,
        usage: { inputTokens: 1, outputTokens: 1 }
      }
    }
  })
  const prompts = new PromptRegistry()
  prompts.register({
    promptId: 'colors',
    version: '1',
    content: 'Sort colors',
    classification: 'INTERNAL',
    tenantId: 'tenant_00000000-0000-4000-8000-000000000001',
    owner: 'test',
    approvedBy: 'test',
    status: 'approved',
    effectiveFrom: '2026-01-01T00:00:00Z'
  })
  const gateway = new ModelGateway({
    providers: [provider],
    prompts,
    circuitBreaker: circuit,
    clock: () => new Date(now),
    profiles: {
      local: {
        name: 'local',
        providerId: 'synthetic',
        model: 'synthetic',
        location: 'local',
        temperature: 0,
        maxTokens: 8,
        timeoutMs: 100,
        maxCostUsd: 0,
        estimatedCostUsd: 0,
        maxRetries: 0,
        pricing: { inputPer1kUsd: 0, outputPer1kUsd: 0 }
      }
    }
  })
  const request = {
    requestId: 'req_synthetic',
    correlationId: 'corr_synthetic',
    tenantId: 'tenant_00000000-0000-4000-8000-000000000001',
    promptId: 'colors',
    promptVersion: '1',
    modelProfile: 'local' as const,
    dataClassification: 'INTERNAL' as const,
    input: {
      messages: [{ role: 'user' as const, content: 'Sort red blue colors' }]
    }
  }
  await expect(
    gateway.generate({ ...request, signal: caller.signal })
  ).rejects.toMatchObject({ code: 'cancelled' })
  expect(gateway.circuitSnapshot()['synthetic:synthetic']).toBe('HALF_OPEN')
  expect((await gateway.generate(request)).output.text).toBe('blue')
  expect(gateway.circuitSnapshot()['synthetic:synthetic']).toBe('CLOSED')
})
