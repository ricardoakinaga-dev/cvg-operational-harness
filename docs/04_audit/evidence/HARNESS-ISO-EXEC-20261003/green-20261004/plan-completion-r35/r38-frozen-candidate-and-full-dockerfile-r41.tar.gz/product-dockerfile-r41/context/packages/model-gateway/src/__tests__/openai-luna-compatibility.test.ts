import { describe, expect, it, vi } from 'vitest'
import {
  OpenAICompatibleProvider,
  type FetchLike
} from '../providers/openai-compatible.ts'
import type { ProviderRequest } from '../contracts.ts'

const request = (): ProviderRequest => ({
  requestId: 'synthetic_luna_compat_0001',
  tenantId: 'tenant_00000000-0000-4000-8000-000000000001',
  correlationId: 'synthetic_luna_correlation',
  model: 'gpt-6-luna',
  input: {
    system: 'Return only JSON from this synthetic fixture.',
    messages: [{ role: 'user', content: '{"synthetic":true}' }]
  },
  temperature: 0,
  maxTokens: 2048,
  promptSha256: 'a'.repeat(64),
  structuredSchemaName: 'SyntheticFixture',
  signal: new AbortController().signal,
  timeoutMs: 1000
})
function transport() {
  return vi.fn<FetchLike>(
    async () =>
      new Response(
        JSON.stringify({
          choices: [
            {
              message: { content: '{"synthetic":true}' },
              finish_reason: 'stop'
            }
          ],
          usage: { prompt_tokens: 20, completion_tokens: 10 }
        }),
        { status: 200, headers: { 'content-type': 'application/json' } }
      )
  )
}
function provider(baseUrl: string, model: string, fetchImpl: FetchLike) {
  return new OpenAICompatibleProvider({
    id: 'synthetic-luna',
    baseUrl,
    model,
    location: 'external',
    apiKey: 'SYNTHETIC_TEST_KEY',
    fetchImpl,
    dnsLookup: async () => ['93.184.216.34']
  })
}
describe('official OpenAI GPT-6 Luna wire compatibility', () => {
  it('uses modern bounded token count and no reasoning while preserving JSON, timeout and redirect guard', async () => {
    const fetchImpl = transport()
    const client = provider(
      'https://api.openai.com/v1',
      'gpt-6-luna',
      fetchImpl
    )
    const result = await client.execute(request())
    expect(result.text).toBe('{"synthetic":true}')
    expect(result.usage).toEqual({ inputTokens: 20, outputTokens: 10 })
    const [url, init] = fetchImpl.mock.calls[0]!
    expect(url).toBe('https://api.openai.com/v1/chat/completions')
    expect(init.redirect).toBe('manual')
    expect(init.signal).toBeInstanceOf(AbortSignal)
    const body = JSON.parse(String(init.body))
    expect(body).toMatchObject({
      model: 'gpt-6-luna',
      temperature: 0,
      max_completion_tokens: 2048,
      reasoning_effort: 'none',
      store: false,
      stream: false,
      response_format: { type: 'json_object' }
    })
    expect(body).not.toHaveProperty('max_tokens')
    expect(body).not.toHaveProperty('tools')
    expect(body.messages).toEqual([
      { role: 'system', content: request().input.system },
      ...request().input.messages
    ])
  })
  it.each([
    ['https://api.openai.com/v1', 'gpt-4.1-mini'],
    ['https://api.example.com/v1', 'gpt-6-luna'],
    ['https://api.openai.com.example.com/v1', 'gpt-6-luna']
  ])(
    'preserves existing generic contract for %s / %s',
    async (baseUrl, model) => {
      const fetchImpl = transport()
      await provider(baseUrl, model, fetchImpl).execute(request())
      const body = JSON.parse(String(fetchImpl.mock.calls[0]![1].body))
      expect(body.max_tokens).toBe(2048)
      expect(body.temperature).toBe(0)
      expect(body).not.toHaveProperty('max_completion_tokens')
      expect(body).not.toHaveProperty('reasoning_effort')
    }
  )
  it('fails closed on private DNS before making any provider request', async () => {
    const fetchImpl = transport()
    const client = new OpenAICompatibleProvider({
      id: 'synthetic-luna',
      baseUrl: 'https://api.openai.com/v1',
      model: 'gpt-6-luna',
      location: 'external',
      apiKey: 'SYNTHETIC_TEST_KEY',
      fetchImpl,
      dnsLookup: async () => ['127.0.0.1']
    })
    await expect(client.execute(request())).rejects.toMatchObject({
      kind: 'invalid_request'
    })
    expect(fetchImpl).not.toHaveBeenCalled()
  })
  it('does not expose credentials through provider HTTP errors', async () => {
    const client = provider(
      'https://api.openai.com/v1',
      'gpt-6-luna',
      async () =>
        new Response(JSON.stringify({ error: 'SYNTHETIC_TEST_KEY' }), {
          status: 401
        })
    )
    await expect(client.execute(request())).rejects.toMatchObject({
      kind: 'auth',
      status: 401
    })
    try {
      await client.execute(request())
    } catch (error) {
      expect(String(error)).not.toContain('SYNTHETIC_TEST_KEY')
    }
  })
})
