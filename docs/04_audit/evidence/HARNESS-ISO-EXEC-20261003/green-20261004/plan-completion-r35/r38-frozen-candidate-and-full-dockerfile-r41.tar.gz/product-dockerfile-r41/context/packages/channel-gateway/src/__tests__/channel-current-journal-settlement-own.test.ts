// @vitest-environment node
import { createHash } from 'node:crypto'
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { ChatwootChannelAdapter } from '../adapters/chatwoot.ts'
import { FileChannelEffectJournal } from '../effect-journal-file.ts'
import {
  CHANNEL_OPERATION_KIND,
  CURRENT_HASH_VERSION,
  channelEffectKey,
  type ChannelEffectIdentity
} from '../effect-journal.ts'

// Reproduce a real filesystem race deterministically: a competing process
// releases its lock between this process's EEXIST and stat. The real stat then
// throws ENOENT; only scheduling is controlled, not the journal result.
const lockRace = vi.hoisted(() => ({ path: '', releases: 0 }))
vi.mock('node:fs/promises', async (importOriginal) => {
  const fs = await importOriginal<typeof import('node:fs/promises')>()
  return {
    ...fs,
    stat: async (...args: Parameters<typeof fs.stat>) => {
      if (String(args[0]) === lockRace.path) {
        lockRace.path = ''
        lockRace.releases += 1
        await fs.unlink(args[0])
      }
      return fs.stat(...args)
    }
  }
})

const directories: string[] = []
const context = {
  tenantId: 'tenant_00000000-0000-4000-8000-000000000181',
  conversationId: 'conv_synthetic_channel_settlement',
  correlationId: 'corr_synthetic_channel_settlement'
}

afterEach(async () => {
  await Promise.all(
    directories
      .splice(0)
      .map((directory) => rm(directory, { recursive: true, force: true }))
  )
})

describe('durable channel settlement survives reopening', () => {
  it.each([
    ['fail', 'FAILED', 'replay'],
    ['release', 'PENDING', 'reserved'],
    ['markUncertain', 'UNCERTAIN', 'uncertain']
  ] as const)(
    '%s fences the wrong owner and persists its exact state',
    async (method, state, nextOutcome) => {
      const directory = await mkdtemp(join(tmpdir(), 'cvg-channel-settlement-'))
      directories.push(directory)
      const journal = new FileChannelEffectJournal({ directory })
      const identity: ChannelEffectIdentity = {
        tenantId: context.tenantId,
        channel: 'web',
        operationKind: CHANNEL_OPERATION_KIND,
        idempotencyKey: `synthetic-settlement-${method}`
      }
      const input = {
        identity,
        payloadHash: 'synthetic-fixed-payload',
        hashVersion: CURRENT_HASH_VERSION,
        leaseOwner: 'synthetic-owner',
        leaseMs: 60_000
      }
      expect((await journal.reserve(input)).outcome).toBe('reserved')
      expect((await journal.claimSend(identity, input.leaseOwner)).state).toBe(
        'SENDING'
      )
      expect(
        await journal[method](identity, 'wrong-owner', 'send_failed')
      ).toBe('lease_lost')
      expect((await journal.find(identity))?.state).toBe('SENDING')
      expect(
        await journal[method](identity, input.leaseOwner, 'send_failed')
      ).toBe('committed')

      const reopened = new FileChannelEffectJournal({ directory })
      expect(await reopened.find(identity)).toMatchObject({
        state,
        payloadHash: input.payloadHash,
        hashVersion: CURRENT_HASH_VERSION,
        leaseOwner: null,
        leaseExpiresAtMs: null,
        result: null,
        errorCode: 'send_failed',
        revision: 3,
        attempt: 1
      })
      const retry = await reopened.reserve({
        ...input,
        leaseOwner: 'synthetic-reopened-owner'
      })
      expect(retry.outcome).toBe(nextOutcome)
      if (retry.outcome === 'reserved') {
        expect(retry.record).toMatchObject({
          state: 'PENDING',
          attempt: 2,
          leaseOwner: 'synthetic-reopened-owner',
          errorCode: null
        })
      } else {
        expect(retry).toMatchObject({ record: { state, attempt: 1 } })
      }
      expect(
        (await reopened.reserve({ ...input, payloadHash: 'different-payload' }))
          .outcome
      ).toBe('conflict')
    }
  )
})

describe('optional synthetic webhook fields retain canonical meaning', () => {
  it.each([
    [{ sender: { id: 0, name: '' } }, '0'],
    [
      { conversation: { meta: { sender: { identifier: 'synthetic-peer' } } } },
      'synthetic-peer'
    ],
    [{}, 'unknown']
  ])(
    'normalizes sender metadata without a real channel call: %j',
    (fields, senderId) => {
      const adapter = new ChatwootChannelAdapter({
        enabled: true,
        baseUrl: 'https://synthetic-channel.invalid',
        apiKey: 'synthetic-only',
        accountId: 'synthetic-account',
        clock: () => new Date('2026-10-04T12:00:00Z')
      })
      const result = adapter.normalize(
        {
          id: 0,
          content: 'Synthetic color message',
          ...fields
        },
        context
      )
      expect(result.sender.id).toBe(senderId)
      expect(result.externalId).toBe('0')
      expect(result.conversationId).toBe(context.conversationId)
      expect(result.timestamp).toBe('2026-10-04T12:00:00.000Z')
      expect(result.body).toEqual({
        text: 'Synthetic color message',
        attachments: []
      })
    }
  )
})

describe('competing process releases a lock during acquisition', () => {
  it('recovers from ENOENT after EEXIST and persists a single reservation', async () => {
    const directory = await mkdtemp(join(tmpdir(), 'cvg-channel-lock-race-'))
    directories.push(directory)
    const identity: ChannelEffectIdentity = {
      tenantId: context.tenantId,
      channel: 'web',
      operationKind: CHANNEL_OPERATION_KIND,
      idempotencyKey: 'synthetic-lock-acquisition-race'
    }
    const digest = createHash('sha256')
      .update(channelEffectKey(identity))
      .digest('hex')
    const recordPath = join(directory, `${digest}.json`)
    const lockPath = `${recordPath}.lock`
    const input = {
      identity,
      payloadHash: 'synthetic-race-payload',
      hashVersion: CURRENT_HASH_VERSION,
      leaseOwner: 'surviving-synthetic-owner',
      leaseMs: 60_000
    }
    const journal = new FileChannelEffectJournal({ directory, pollMs: 1 })
    expect((await journal.reserve(input)).outcome).toBe('reserved')
    await writeFile(lockPath, 'competing-synthetic-process')
    lockRace.path = lockPath
    lockRace.releases = 0
    expect(
      (await journal.reserve({ ...input, leaseOwner: 'contending-owner' }))
        .outcome
    ).toBe('in_flight')
    expect(lockRace.releases).toBe(1)
    await expect(readFile(lockPath, 'utf8')).rejects.toMatchObject({
      code: 'ENOENT'
    })
    const reopened = new FileChannelEffectJournal({ directory })
    expect(await reopened.find(identity)).toMatchObject({
      state: 'PENDING',
      revision: 1,
      attempt: 1,
      payloadHash: input.payloadHash,
      leaseOwner: input.leaseOwner
    })
    expect(
      (await reopened.reserve({ ...input, leaseOwner: 'another-owner' }))
        .outcome
    ).toBe('in_flight')
    expect((await reopened.find(identity))?.attempt).toBe(1)
  })
})

describe('enabled channel rejects incomplete configuration', () => {
  it('rejects an omitted base URL before any outbound request', () => {
    const fetchImpl = vi.fn()
    expect(
      () =>
        new ChatwootChannelAdapter({
          enabled: true,
          apiKey: 'synthetic-only',
          accountId: 'synthetic-account',
          fetchImpl
        })
    ).toThrow(expect.objectContaining({ code: 'invalid_config' }))
    expect(fetchImpl).not.toHaveBeenCalled()
  })
})
