// @vitest-environment node
import { it, expect } from 'vitest'
import { createServer } from 'node:http'
import { once, getEventListeners } from 'node:events'
import type { AddressInfo, Socket } from 'node:net'
import {
  ModelGateway,
  OpenAICompatibleProvider,
  PromptRegistry
} from '../index.ts'
const pause = (ms: number) => new Promise<void>((r) => setTimeout(r, ms))
it('I1-F02 public gateway real Node half-open caller cancel must release probe without failure', async () => {
  let now = Date.parse('2026-10-04T12:00:00.000Z'),
    http = 0
  let headers: (v?: unknown) => void = () => {}
  const headersSeen = new Promise((r) => (headers = r))
  const sockets = new Set<Socket>()
  const server = createServer((_req, res) => {
    http++
    if (http === 1) {
      res.writeHead(500)
      res.flushHeaders()
    } else if (http === 2) {
      res.writeHead(200)
      res.flushHeaders()
      headers()
    } else
      res.end(JSON.stringify({ choices: [{ message: { content: 'blue' } }] }))
  })
  server.on('connection', (s) => {
    sockets.add(s)
    s.on('close', () => sockets.delete(s))
  })
  server.listen(0, '127.0.0.1')
  await once(server, 'listening')
  const port = (server.address() as AddressInfo).port
  const tenant = 'tenant_00000000-0000-4000-8000-000000000001'
  const prompts = new PromptRegistry()
  prompts.register({
    promptId: 'i1-colors',
    version: '1',
    content: 'Sort colors',
    classification: 'INTERNAL',
    tenantId: tenant,
    owner: 'i1 local fixture',
    approvedBy: 'synthetic test reviewer',
    status: 'approved',
    effectiveFrom: '2026-01-01T00:00:00.000Z'
  })
  const events: unknown[] = []
  const gateway = new ModelGateway({
    providers: [
      new OpenAICompatibleProvider({
        id: 'i1',
        model: 'synthetic',
        location: 'local',
        baseUrl: `http://127.0.0.1:${port}`,
        allowPrivateNetworks: true,
        allowHttp: true
      })
    ],
    profiles: {
      local: {
        name: 'local',
        providerId: 'i1',
        model: 'synthetic',
        location: 'local',
        temperature: 0,
        maxTokens: 8,
        maxRetries: 0,
        timeoutMs: 2000,
        maxCostUsd: 0,
        estimatedCostUsd: 0,
        pricing: { inputPer1kUsd: 0, outputPer1kUsd: 0 }
      }
    },
    prompts,
    circuitBreaker: { failureThreshold: 1, openMs: 10, halfOpenSuccesses: 1 },
    clock: () => new Date(now),
    onEvent: (e) => events.push(e)
  })
  const request = (signal?: AbortSignal) => ({
    requestId: 'req_i1_circuit',
    correlationId: 'corr_i1_circuit',
    tenantId: tenant,
    promptId: 'i1-colors',
    promptVersion: '1',
    modelProfile: 'local' as const,
    dataClassification: 'INTERNAL' as const,
    input: {
      messages: [
        { role: 'user' as const, content: 'Sort synthetic colors red blue' }
      ]
    },
    ...(signal ? { signal } : {})
  })
  const errorOf = async (p: ReturnType<ModelGateway['generate']>) =>
    p
      .then((r) => ({ result: r }))
      .catch((e) => ({ code: e.code, retryable: e.retryable }))
  try {
    const initial = await errorOf(gateway.generate(request()))
    expect(initial).toMatchObject({ code: 'provider_unavailable' })
    expect(gateway.circuitSnapshot()).toEqual({ 'i1:synthetic': 'OPEN' })
    now += 20
    const caller = new AbortController()
    const cancelledPromise = errorOf(gateway.generate(request(caller.signal)))
    await headersSeen
    await pause(10)
    caller.abort(new Error('synthetic half-open pause'))
    const cancelled = await cancelledPromise
    expect(cancelled).toMatchObject({ code: 'cancelled', retryable: false })
    await pause(30)
    const afterCancel = gateway.circuitSnapshot()
    const next = await errorOf(gateway.generate(request()))
    now += 86400000
    const oneDayLater = await errorOf(gateway.generate(request()))
    await pause(30)
    const record = {
      node: process.version,
      initial,
      cancelled,
      afterCancel,
      next,
      oneDayLater,
      http,
      sockets: sockets.size,
      callerListeners: getEventListeners(caller.signal, 'abort').length,
      events
    }
    console.log('I1-F02', JSON.stringify(record))
    expect(sockets.size).toBe(0)
    expect(record.callerListeners).toBe(0)
    expect(next).toHaveProperty('result.output.text', 'blue')
  } finally {
    server.closeAllConnections()
    await new Promise<void>((r) => server.close(() => r()))
  }
}, 6000)

it('I1-F02 positive control real Node half-open success releases the probe', async () => {
  let http = 0,
    now = Date.parse('2026-10-04T12:00:00Z')
  const server = createServer((_req, res) => {
    http++
    if (http === 1) {
      res.writeHead(500)
      res.flushHeaders()
    } else
      res.end(JSON.stringify({ choices: [{ message: { content: 'blue' } }] }))
  })
  server.listen(0, '127.0.0.1')
  await once(server, 'listening')
  const port = (server.address() as AddressInfo).port
  const tenant = 'tenant_00000000-0000-4000-8000-000000000001',
    prompts = new PromptRegistry()
  prompts.register({
    promptId: 'i1-colors',
    version: '1',
    content: 'Sort colors',
    classification: 'INTERNAL',
    tenantId: tenant,
    owner: 'i1 fixture',
    approvedBy: 'synthetic reviewer',
    status: 'approved',
    effectiveFrom: '2026-01-01T00:00:00Z'
  })
  const g = new ModelGateway({
    providers: [
      new OpenAICompatibleProvider({
        id: 'i1',
        model: 'synthetic',
        location: 'local',
        baseUrl: `http://127.0.0.1:${port}`,
        allowPrivateNetworks: true,
        allowHttp: true
      })
    ],
    profiles: {
      local: {
        name: 'local',
        providerId: 'i1',
        model: 'synthetic',
        location: 'local',
        temperature: 0,
        maxTokens: 8,
        maxRetries: 0,
        timeoutMs: 2000,
        maxCostUsd: 0,
        estimatedCostUsd: 0,
        pricing: { inputPer1kUsd: 0, outputPer1kUsd: 0 }
      }
    },
    prompts,
    circuitBreaker: { failureThreshold: 1, openMs: 10, halfOpenSuccesses: 1 },
    clock: () => new Date(now)
  })
  const input = {
    requestId: 'req_i1_control',
    correlationId: 'corr_i1_control',
    tenantId: tenant,
    promptId: 'i1-colors',
    promptVersion: '1',
    modelProfile: 'local' as const,
    dataClassification: 'INTERNAL' as const,
    input: {
      messages: [{ role: 'user' as const, content: 'Sort synthetic blue red' }]
    }
  }
  try {
    await expect(g.generate(input)).rejects.toMatchObject({
      code: 'provider_unavailable'
    })
    now += 20
    expect((await g.generate(input)).output.text).toBe('blue')
    expect(g.circuitSnapshot()).toEqual({ 'i1:synthetic': 'CLOSED' })
    expect((await g.generate(input)).output.text).toBe('blue')
    expect(http).toBe(3)
    console.log(
      'I1-F02 control',
      JSON.stringify({ http, after: g.circuitSnapshot() })
    )
  } finally {
    server.closeAllConnections()
    await new Promise<void>((r) => server.close(() => r()))
  }
})
