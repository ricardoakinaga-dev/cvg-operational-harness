import type { ModelGatewayRequest } from './contracts.ts'
import { ModelGatewayError } from './errors.ts'
import { usdToMicrousd } from './file-budget-store.ts'

export type BudgetScope = 'request' | 'session' | 'tenant' | 'agent' | 'day'

export interface CostBudgetLimits {
  request?: number
  session?: number
  tenant?: number
  agent?: number
  day?: number
}

export interface CostBudgetStore {
  /** Strict monetary validation and durable reservation, opt-in for persistent stores. */
  readonly durable?: boolean
  consumedMicrousd?(scopeKey: string): number
  checkDay?(now: Date): void
  health?(): { ready: boolean; reasonCodes: string[] }
  consumed(scopeKey: string): number
  consume(scopeKey: string, amountUsd: number): void
}

export class InMemoryCostBudgetStore implements CostBudgetStore {
  readonly #consumed = new Map<string, number>()

  consumed(scopeKey: string): number {
    return this.#consumed.get(scopeKey) ?? 0
  }

  consume(scopeKey: string, amountUsd: number): void {
    if (!Number.isFinite(amountUsd) || amountUsd <= 0) return
    this.#consumed.set(scopeKey, this.consumed(scopeKey) + amountUsd)
  }
}

export function budgetScopeKeys(
  request: Pick<
    ModelGatewayRequest,
    'requestId' | 'tenantId' | 'sessionId' | 'agentId'
  >,
  now: Date
): Record<BudgetScope, string | null> {
  const day = now.toISOString().slice(0, 10)
  return {
    request: `request:${request.requestId}`,
    session: request.sessionId
      ? `session:${request.tenantId}:${request.sessionId}`
      : null,
    tenant: `tenant:${request.tenantId}`,
    agent: request.agentId
      ? `agent:${request.tenantId}:${request.agentId}`
      : null,
    day: `day:${request.tenantId}:${day}`
  }
}

export interface BudgetAuthorizationInput {
  request: Pick<
    ModelGatewayRequest,
    'requestId' | 'tenantId' | 'sessionId' | 'agentId'
  >
  estimatedCostUsd: number
  limits: CostBudgetLimits
  store: CostBudgetStore
  now: Date
}

export interface BudgetAuthorization {
  allowed: boolean
  deniedScope?: BudgetScope
  deniedKey?: string
  spentUsd?: number
  limitUsd?: number
  reservedKeys: string[]
}

/**
 * Two-phase guard: authorize every configured scope before reserving the
 * estimate, so a rejected call never partially consumes budget. Settlement is
 * conservative: overruns always charge the difference, refunds never happen.
 */
export class BudgetGuard {
  readonly #store: CostBudgetStore
  readonly #limits: CostBudgetLimits
  readonly #clock: () => Date
  #inhibited = false

  health(): { ready: boolean; reasonCodes: string[] } {
    if (this.#inhibited)
      return { ready: false, reasonCodes: ['budget_store_unavailable'] }
    return this.#store.health?.() ?? { ready: true, reasonCodes: [] }
  }

  constructor(options: {
    store: CostBudgetStore
    limits: CostBudgetLimits
    clock?: () => Date
  }) {
    this.#store = options.store
    this.#limits = options.limits
    this.#clock = options.clock ?? (() => new Date())
  }

  authorize(input: {
    request: Pick<
      ModelGatewayRequest,
      'requestId' | 'tenantId' | 'sessionId' | 'agentId'
    >
    estimatedCostUsd: number
  }): BudgetAuthorization {
    try {
      return this.#authorize(input)
    } catch {
      this.#unavailable()
    }
  }

  #authorize(input: {
    request: Pick<
      ModelGatewayRequest,
      'requestId' | 'tenantId' | 'sessionId' | 'agentId'
    >
    estimatedCostUsd: number
  }): BudgetAuthorization {
    if (!this.health().ready) this.#unavailable()
    const now = this.#clock()
    this.#store.checkDay?.(now)
    const keys = budgetScopeKeys(input.request, now)
    const estimate = Number.isFinite(input.estimatedCostUsd)
      ? Math.max(0, input.estimatedCostUsd)
      : 0
    const estimateMicro = this.#store.durable
      ? usdToMicrousd(input.estimatedCostUsd, 'ceil')
      : undefined
    const scopes: BudgetScope[] = [
      'request',
      'session',
      'tenant',
      'agent',
      'day'
    ]

    for (const scope of scopes) {
      const limit = this.#limits[scope]
      const key = keys[scope]
      if (limit === undefined || key === null) continue
      const spent = this.#store.consumed(key)
      const spentMicro =
        estimateMicro === undefined
          ? undefined
          : (this.#store.consumedMicrousd?.(key) ??
            usdToMicrousd(spent, 'ceil'))
      if (
        spentMicro !== undefined &&
        (!Number.isSafeInteger(spentMicro) || spentMicro < 0)
      )
        this.#unavailable()
      const exceeded =
        estimateMicro === undefined
          ? spent + estimate > limit
          : spentMicro! + estimateMicro > usdToMicrousd(limit, 'floor')
      if (exceeded) {
        return {
          allowed: false,
          deniedScope: scope,
          deniedKey: key,
          spentUsd: spent,
          limitUsd: limit,
          reservedKeys: []
        }
      }
    }

    const reservedKeys: string[] = []
    for (const scope of scopes) {
      const key = keys[scope]
      if (key === null) continue
      if (this.#limits[scope] === undefined) continue
      this.#store.consume(
        key,
        estimateMicro === undefined ? estimate : estimateMicro / 1_000_000
      )
      reservedKeys.push(key)
    }

    return { allowed: true, reservedKeys }
  }

  settle(input: {
    reservedKeys: readonly string[]
    estimatedCostUsd: number
    actualCostUsd: number
  }): void {
    if (this.#inhibited) this.#unavailable()
    if (this.#store.durable) {
      try {
        usdToMicrousd(input.estimatedCostUsd, 'ceil')
        usdToMicrousd(input.actualCostUsd, 'ceil')
      } catch {
        this.#unavailable()
      }
    }
    const delta = input.actualCostUsd - input.estimatedCostUsd
    if (!Number.isFinite(delta) || delta <= 0) return
    try {
      for (const key of input.reservedKeys) this.#store.consume(key, delta)
    } catch {
      this.#unavailable()
    }
  }

  #unavailable(): never {
    this.#inhibited = true
    throw new ModelGatewayError(
      'budget_store_unavailable',
      'Cost budget is unavailable; replay or diagnosis required',
      { status: 503 }
    )
  }
}
