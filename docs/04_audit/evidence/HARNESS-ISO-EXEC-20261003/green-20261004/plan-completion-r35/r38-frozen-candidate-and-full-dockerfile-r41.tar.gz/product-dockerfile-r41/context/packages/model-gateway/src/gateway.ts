import { z } from 'zod'
import { mayTransmitToModel, type DataClassification } from '@cvg/shared'
import {
  ModelGatewayRequestSchema,
  type ModelGatewayEvent,
  type ModelGatewayRequest,
  type ModelProfile,
  type ModelProfileName,
  type ModelProvider,
  type ModelResult,
  type ProviderResult,
  type ProviderUsage,
  type StructuredOutputContract
} from './contracts.ts'
import {
  BudgetGuard,
  type CostBudgetLimits,
  type CostBudgetStore
} from './budget.ts'
import {
  CircuitBreaker,
  type CircuitBreakerOptions
} from './circuit-breaker.ts'
import {
  ModelGatewayError,
  toGatewayError,
  type ModelGatewayErrorCode
} from './errors.ts'
import {
  computeRetryDelayMs,
  DEFAULT_RETRY_POLICY,
  type RetryPolicy
} from './retry.ts'
import {
  PromptRegistry,
  PromptRegistryError,
  type PromptRecord
} from './prompt-registry.ts'
import { ModelRouter, type ModelRoutingOptions } from './router.ts'

export interface ModelGatewayOptions {
  providers: ModelProvider[]
  profiles: Partial<Record<ModelProfileName, ModelProfile>>
  prompts: PromptRegistry
  budget?: {
    store: CostBudgetStore
    limits: CostBudgetLimits
  }
  circuitBreaker?: CircuitBreaker | CircuitBreakerOptions
  routing?: ModelRoutingOptions
  retry?: Partial<RetryPolicy>
  clock?: () => Date
  sleep?: (ms: number) => Promise<void>
  random?: () => number
  onEvent?: (event: ModelGatewayEvent) => void
  defaultTimeoutMs?: number
  maxOutputChars?: number
}

export interface GenerateRequest<
  TStructured = unknown
> extends ModelGatewayRequest {
  structuredOutput?: StructuredOutputContract<TStructured>
  signal?: AbortSignal
}

const PROMPT_ERROR_MAP: Record<
  PromptRegistryError['code'],
  ModelGatewayErrorCode
> = {
  prompt_duplicate: 'invalid_request',
  prompt_unknown: 'prompt_unknown',
  prompt_revoked: 'prompt_revoked',
  prompt_not_effective: 'prompt_unknown',
  prompt_expired: 'prompt_unknown',
  prompt_hash_mismatch: 'prompt_hash_mismatch',
  prompt_tenant_mismatch: 'policy_denied'
}

interface Candidate {
  profile: ModelProfile
  fallbackUsed: boolean
}

/**
 * Provider-agnostic model gateway.
 *
 * Model output is untrusted input: the gateway enforces deadline, retries,
 * circuit breaking, cost budgets, prompt integrity, data-placement policy and
 * fail-closed structured output before anything reaches the domain.
 */
export class ModelGateway {
  readonly #providers = new Map<string, ModelProvider>()
  readonly #router: ModelRouter
  readonly #prompts: PromptRegistry
  readonly #budget?: BudgetGuard
  readonly #budgetLimits: CostBudgetLimits
  readonly #circuit: CircuitBreaker
  readonly #retry: RetryPolicy
  readonly #clock: () => Date
  readonly #sleep: ((ms: number) => Promise<void>) | undefined
  readonly #random: () => number
  readonly #onEvent?: (event: ModelGatewayEvent) => void
  #observerFailures = 0
  readonly #defaultTimeoutMs: number
  readonly #maxOutputChars: number
  readonly #inhibitedProfiles = new Set<ModelProfileName>()

  constructor(options: ModelGatewayOptions) {
    for (const provider of options.providers) {
      this.#providers.set(provider.id, provider)
    }
    this.#router = new ModelRouter(options.profiles, options.routing ?? {})
    this.#prompts = options.prompts
    this.#retry = { ...DEFAULT_RETRY_POLICY, ...(options.retry ?? {}) }
    const clock = options.clock ?? (() => new Date())
    this.#clock = () => {
      const at = clock()
      if (!Number.isFinite(at.getTime())) {
        throw new ModelGatewayError(
          'invalid_request',
          'Model execution requires a finite clock timestamp'
        )
      }
      return at
    }
    this.#sleep = options.sleep
    this.#random = options.random ?? (() => Math.random())
    if (options.onEvent) this.#onEvent = options.onEvent
    this.#defaultTimeoutMs = options.defaultTimeoutMs ?? 30_000
    this.#maxOutputChars = options.maxOutputChars ?? 32_000
    this.#budgetLimits = Object.freeze({ ...(options.budget?.limits ?? {}) })
    if (options.budget) {
      this.#budget = new BudgetGuard({
        store: options.budget.store,
        limits: this.#budgetLimits,
        clock: this.#clock
      })
    }
    this.#circuit =
      options.circuitBreaker instanceof CircuitBreaker
        ? options.circuitBreaker
        : new CircuitBreaker({
            ...(options.circuitBreaker ?? {}),
            clock: () => this.#clock().getTime(),
            onTransition: (transition) => {
              this.#emit({
                type: 'model.circuit.transition',
                requestId: 'n/a',
                tenantId: 'n/a',
                correlationId: 'n/a',
                circuitState: transition.to,
                detail: `${transition.from}->${transition.to}`
              })
              if (
                options.circuitBreaker &&
                !(options.circuitBreaker instanceof CircuitBreaker) &&
                options.circuitBreaker.onTransition
              ) {
                return options.circuitBreaker.onTransition(transition)
              }
            }
          })
  }

  async generate<TStructured = unknown>(
    request: GenerateRequest<TStructured>
  ): Promise<ModelResult<TStructured>> {
    const { structuredOutput, signal, ...wire } = request
    assertCallerActive(signal)
    const parsed = ModelGatewayRequestSchema.safeParse(wire)
    if (!parsed.success) {
      throw new ModelGatewayError(
        'invalid_request',
        'Model request failed schema validation'
      )
    }
    const startedAt = this.#clock()
    const prompt = this.#resolvePrompt(
      parsed.data,
      parsed.data.dataClassification
    )
    // The approved prompt is the classification floor. A stricter request is
    // rejected by resolvePrompt; carry the approved class through all candidates.
    const normalized = {
      ...parsed.data,
      dataClassification: prompt.classification
    }
    const route = this.#router.resolve({
      requestedProfile: normalized.modelProfile,
      ...(normalized.task !== undefined ? { task: normalized.task } : {}),
      dataClassification: normalized.dataClassification
    })
    if (route.substitutedProfile) {
      this.#emit({
        type: 'model.routing.substituted',
        requestId: normalized.requestId,
        tenantId: normalized.tenantId,
        correlationId: normalized.correlationId,
        profile: route.profile.name,
        detail: `substituted:${route.substitutedProfile}`
      })
    }

    const candidates: Candidate[] = [
      { profile: route.profile, fallbackUsed: false }
    ]
    const fallback = this.#router.fallbackFor(route.profile)
    if (fallback) {
      candidates.push({ profile: fallback, fallbackUsed: true })
    }

    let lastError: ModelGatewayError | undefined
    for (let index = 0; index < candidates.length; index += 1) {
      const candidate = candidates[index]
      if (!candidate) continue
      assertCallerActive(signal)
      try {
        const result = await this.#runCandidate(
          normalized,
          candidate,
          prompt,
          startedAt,
          structuredOutput,
          signal
        )
        return result as ModelResult<TStructured>
      } catch (error) {
        const gatewayError = toGatewayError(error)
        lastError = gatewayError
        const hasNext = index < candidates.length - 1
        if (hasNext && gatewayError.retryable && !signal?.aborted) {
          const nextProfile = candidates[index + 1]?.profile.name
          this.#emit({
            type: 'model.routing.fallback',
            requestId: normalized.requestId,
            tenantId: normalized.tenantId,
            correlationId: normalized.correlationId,
            ...(nextProfile ? { profile: nextProfile } : {}),
            code: gatewayError.code
          })
          continue
        }
        throw gatewayError
      }
    }
    throw (
      lastError ??
      new ModelGatewayError('internal_error', 'No model candidate executed')
    )
  }

  /** Telemetry failures are observable and never become provider outcomes. */
  observerFailureCount(): number {
    return Math.min(
      Number.MAX_SAFE_INTEGER,
      this.#observerFailures + this.#circuit.observerFailureCount()
    )
  }

  circuitSnapshot(): Record<string, string> {
    return this.#circuit.snapshot()
  }

  budgetHealth(): {
    ready: boolean
    reasonCodes: string[]
    inhibitedProfiles: ModelProfileName[]
  } {
    const health = this.#budget?.health() ?? { ready: true, reasonCodes: [] }
    return {
      ready: health.ready && this.#inhibitedProfiles.size === 0,
      reasonCodes: [
        ...health.reasonCodes,
        ...(this.#inhibitedProfiles.size ? ['budget_estimate_violated'] : [])
      ],
      inhibitedProfiles: [...this.#inhibitedProfiles]
    }
  }

  async #runCandidate(
    request: z.infer<typeof ModelGatewayRequestSchema>,
    candidate: Candidate,
    prompt: PromptRecord,
    startedAt: Date,
    structuredOutput: StructuredOutputContract | undefined,
    externalSignal: AbortSignal | undefined
  ): Promise<ModelResult<unknown>> {
    assertCallerActive(externalSignal)
    const { profile } = candidate
    if (
      (profile.location !== 'local' && profile.location !== 'external') ||
      !mayTransmitToModel(request.dataClassification, profile.location)
    ) {
      throw new ModelGatewayError(
        'policy_denied',
        `Model profile ${profile.name} is not allowed for ${request.dataClassification} data`
      )
    }
    const provider = this.#providers.get(profile.providerId)
    if (!provider) {
      throw new ModelGatewayError(
        'provider_unknown',
        `Provider ${profile.providerId} is not registered`
      )
    }

    // Admission must cover the actual registered adapter as well as routing
    // configuration. A mismatch is admissible only when both placements permit
    // the approved class; unknown runtime locations always fail closed.
    if (
      (provider.location !== 'local' && provider.location !== 'external') ||
      !mayTransmitToModel(request.dataClassification, provider.location)
    ) {
      throw new ModelGatewayError(
        'policy_denied',
        `Model provider ${provider.id} is not allowed for ${request.dataClassification} data`
      )
    }

    if (
      typeof profile.model !== 'string' ||
      profile.model.length === 0 ||
      !Array.isArray(provider.models) ||
      !provider.models.includes(profile.model)
    ) {
      throw new ModelGatewayError(
        'provider_invalid_request',
        'Model profile does not select an advertised provider model'
      )
    }

    // Host configuration is not covered by the request's wire schema. Validate
    // every applicable authority before even consulting the budget store.
    const requiredCosts = [profile.maxCostUsd, profile.estimatedCostUsd]
    const optionalCosts = [
      request.maxCostUsd,
      request.estimatedCostUsd,
      ...Object.values(this.#budgetLimits)
    ]
    if (
      !requiredCosts.every(isFiniteNonnegativeCost) ||
      !profile.pricing ||
      !isFiniteNonnegativeCost(profile.pricing.inputPer1kUsd) ||
      !isFiniteNonnegativeCost(profile.pricing.outputPer1kUsd) ||
      !Object.values(profile.pricing).every(isFiniteNonnegativeCost) ||
      !optionalCosts.every(
        (cost) => cost === undefined || isFiniteNonnegativeCost(cost)
      )
    ) {
      throw new ModelGatewayError(
        'invalid_request',
        'Model cost admission requires finite nonnegative costs'
      )
    }
    const estimatedCost = Math.max(
      profile.estimatedCostUsd,
      request.estimatedCostUsd ?? profile.estimatedCostUsd
    )
    const effectiveCap = Math.min(
      profile.maxCostUsd,
      request.maxCostUsd ?? profile.maxCostUsd,
      this.#budgetLimits.request ?? profile.maxCostUsd
    )
    if (estimatedCost > effectiveCap) {
      this.#emit({
        type: 'model.budget.denied',
        requestId: request.requestId,
        tenantId: request.tenantId,
        correlationId: request.correlationId,
        profile: profile.name,
        code: 'budget_exceeded'
      })
      throw new ModelGatewayError(
        'budget_exceeded',
        'Model cost estimate exceeds the applicable request limit'
      )
    }
    if (this.#inhibitedProfiles.has(profile.name)) {
      throw new ModelGatewayError(
        'budget_store_unavailable',
        'Model profile requires budget diagnosis',
        { status: 503 }
      )
    }
    let reservedKeys: string[] = []
    if (this.#budget) {
      let authorization
      try {
        authorization = this.#budget.authorize({
          request,
          estimatedCostUsd: estimatedCost
        })
      } catch (error) {
        this.#emit({
          type: 'model.budget.denied',
          requestId: request.requestId,
          tenantId: request.tenantId,
          correlationId: request.correlationId,
          profile: profile.name,
          code: 'budget_store_unavailable'
        })
        throw error
      }
      if (!authorization.allowed) {
        this.#emit({
          type: 'model.budget.denied',
          requestId: request.requestId,
          tenantId: request.tenantId,
          correlationId: request.correlationId,
          code: authorization.deniedScope ?? 'budget_exceeded'
        })
        throw new ModelGatewayError(
          'budget_exceeded',
          `Model budget exceeded for ${authorization.deniedScope ?? 'scope'}`
        )
      }
      reservedKeys = authorization.reservedKeys
    }

    // Escape each tuple component before joining: distinct identities must not
    // share failure/probe state. Common diagnostic keys remain compatible.
    const escapeCircuitComponent = (value: string) =>
      value.replaceAll('%', '%25').replaceAll(':', '%3A')
    const circuitKey = `${escapeCircuitComponent(provider.id)}:${escapeCircuitComponent(profile.model)}`
    const timeoutMs =
      request.timeoutMs ?? profile.timeoutMs ?? this.#defaultTimeoutMs
    const maxRetries = profile.maxRetries
    const attemptsAllowed = Math.max(1, maxRetries + 1)
    let attempt = 0
    let lastError: ModelGatewayError | undefined

    while (attempt < attemptsAllowed) {
      assertCallerActive(externalSignal)
      attempt += 1
      if (!this.#circuit.canRequest(circuitKey)) {
        throw new ModelGatewayError(
          'circuit_open',
          `Circuit breaker open for ${circuitKey}`
        )
      }
      const probeToken = this.#circuit.probeToken(circuitKey)
      const controller = new AbortController()
      let cause: 'caller' | 'deadline' | undefined
      const abort = (first: 'caller' | 'deadline', reason: Error) => {
        if (cause !== undefined) return
        cause = first
        controller.abort(reason)
      }
      const timeoutHandle = setTimeout(
        () =>
          abort(
            'deadline',
            new DOMException('Model deadline exceeded', 'TimeoutError')
          ),
        timeoutMs
      )
      const onExternalAbort = () =>
        abort(
          'caller',
          externalSignal?.reason instanceof Error
            ? externalSignal.reason
            : new DOMException('Model call was cancelled', 'AbortError')
        )
      externalSignal?.addEventListener('abort', onExternalAbort, { once: true })
      if (externalSignal?.aborted) onExternalAbort()
      let rejectAbort: (error: ModelGatewayError) => void = () => {}
      const aborted = new Promise<never>((_resolve, reject) => {
        rejectAbort = reject
      })
      const cancellationError = () =>
        cause === 'deadline'
          ? new ModelGatewayError(
              'provider_timeout',
              'Model provider timed out',
              { retryable: true }
            )
          : new ModelGatewayError('cancelled', 'Model call was cancelled')
      const assertAttemptActive = () => {
        if (controller.signal.aborted) throw cancellationError()
      }
      const onAbort = () => rejectAbort(cancellationError())
      controller.signal.addEventListener('abort', onAbort, { once: true })
      const cleanup = () => {
        clearTimeout(timeoutHandle)
        externalSignal?.removeEventListener('abort', onExternalAbort)
        controller.signal.removeEventListener('abort', onAbort)
      }

      try {
        if (controller.signal.aborted) onAbort()
        if (!controller.signal.aborted)
          this.#emit({
            type: 'model.call.started',
            requestId: request.requestId,
            tenantId: request.tenantId,
            correlationId: request.correlationId,
            providerId: provider.id,
            model: profile.model,
            profile: profile.name,
            attempt
          })

        if (controller.signal.aborted) onAbort()
        const providerResult = await Promise.race([
          aborted,
          controller.signal.aborted
            ? aborted
            : provider.execute({
                requestId: request.requestId,
                tenantId: request.tenantId,
                correlationId: request.correlationId,
                model: profile.model,
                input: request.input,
                temperature: profile.temperature,
                maxTokens: request.maxTokens ?? profile.maxTokens,
                promptSha256: prompt.sha256,
                ...(structuredOutput
                  ? { structuredSchemaName: structuredOutput.schemaName }
                  : {}),
                signal: controller.signal,
                timeoutMs,
                ...(request.metadata ? { metadata: request.metadata } : {})
              })
        ])

        // A fulfilled race can resume after its caller has already aborted.
        // Parsing and clock hooks can also cancel synchronously: prepare the
        // complete result before committing any successful-call side effects.
        assertAttemptActive()
        if (
          providerResult.model !== profile.model ||
          providerResult.providerId !== provider.id
        ) {
          throw new ModelGatewayError(
            'provider_malformed_response',
            'Model provider returned a different execution identity'
          )
        }
        // Keep validated usage independent of provider-owned aliases while
        // trusted normalization and observer hooks prepare publication.
        const usage = { ...providerResult.usage }
        const costUsd = this.#computeCost(profile, usage)
        const output = this.#parseOutput(providerResult, structuredOutput)
        const completedAt = this.#clock()
        const latencyMs = completedAt.getTime() - startedAt.getTime()
        const createdAt = completedAt.toISOString()
        const substitution = routeSubstitution(
          profile.name,
          request.modelProfile
        )
        assertAttemptActive()
        // Completion commits here. Cancellation observed before this point is
        // handled by the same first-cause failure path as an in-flight abort.
        cleanup()
        if (this.#budget) {
          const overrun = costUsd > estimatedCost
          if (overrun) {
            this.#inhibitedProfiles.add(profile.name)
          }
          try {
            this.#budget.settle({
              reservedKeys,
              estimatedCostUsd: estimatedCost,
              actualCostUsd: costUsd
            })
          } catch (error) {
            this.#inhibitedProfiles.add(profile.name)
            throw error
          }
          if (overrun)
            this.#emit({
              type: 'model.budget.violation',
              requestId: request.requestId,
              tenantId: request.tenantId,
              correlationId: request.correlationId,
              profile: profile.name,
              costUsd,
              code: 'budget_estimate_violated'
            })
        }
        this.#circuit.onSuccess(circuitKey, probeToken ?? null)
        this.#emit({
          type: 'model.call.completed',
          requestId: request.requestId,
          tenantId: request.tenantId,
          correlationId: request.correlationId,
          providerId: provider.id,
          model: profile.model,
          profile: profile.name,
          attempt,
          costUsd
        })
        return {
          requestId: request.requestId,
          tenantId: request.tenantId,
          correlationId: request.correlationId,
          providerId: provider.id,
          model: profile.model,
          profile: profile.name,
          output,
          usage,
          costUsd,
          attempts: attempt,
          latencyMs,
          promptSha256: prompt.sha256,
          createdAt,
          fallbackUsed: candidate.fallbackUsed,
          ...(substitution ? { substitutedProfile: request.modelProfile } : {})
        }
      } catch (error) {
        const gatewayError =
          cause === 'caller'
            ? new ModelGatewayError('cancelled', 'Model call was cancelled')
            : cause === 'deadline'
              ? new ModelGatewayError(
                  'provider_timeout',
                  'Model provider timed out',
                  { retryable: true }
                )
              : toGatewayError(error, provider.id)
        lastError = gatewayError
        if (this.#countsAgainstCircuit(gatewayError)) {
          this.#circuit.onFailure(circuitKey, probeToken ?? null)
        } else {
          this.#circuit.onNeutral(circuitKey, probeToken)
        }
        const canRetry =
          gatewayError.retryable &&
          attempt < attemptsAllowed &&
          !externalSignal?.aborted
        if (canRetry) {
          const delayMs = computeRetryDelayMs({
            attempt,
            policy: this.#retry,
            random: this.#random
          })
          this.#emit({
            type: 'model.retry.scheduled',
            requestId: request.requestId,
            tenantId: request.tenantId,
            correlationId: request.correlationId,
            providerId: provider.id,
            model: profile.model,
            profile: profile.name,
            attempt: attempt + 1,
            delayMs,
            code: gatewayError.code
          })
          cleanup()
          await waitForRetry(delayMs, externalSignal, this.#sleep)
          assertCallerActive(externalSignal)
          continue
        }
        this.#emit({
          type: 'model.call.failed',
          requestId: request.requestId,
          tenantId: request.tenantId,
          correlationId: request.correlationId,
          providerId: provider.id,
          model: profile.model,
          profile: profile.name,
          attempt,
          code: gatewayError.code
        })
        throw gatewayError
      } finally {
        cleanup()
      }
    }

    throw (
      lastError ??
      new ModelGatewayError('internal_error', 'Model call exhausted attempts')
    )
  }

  #parseOutput(
    providerResult: ProviderResult,
    contract: StructuredOutputContract | undefined
  ): { text: string; structured?: unknown } {
    let text = providerResult.text
    if (text.length > this.#maxOutputChars) {
      text = text.slice(0, this.#maxOutputChars)
    }
    if (!contract) {
      return { text }
    }
    try {
      if (
        contract.normalizeText &&
        (providerResult.text.length > this.#maxOutputChars ||
          Buffer.byteLength(providerResult.text, 'utf8') >
            this.#maxOutputChars * 4)
      )
        throw new Error(
          'Structured normalization input exceeds the full text bound'
        )
      const normalized: unknown = contract.normalizeText
        ? contract.normalizeText(providerResult.text)
        : providerResult.text
      if (normalized instanceof Promise) {
        // Invalid asynchronous host callbacks remain schema_invalid; observe
        // rejection without awaiting or accepting their eventual output.
        void normalized.catch(() => undefined)
      }
      if (
        typeof normalized !== 'string' ||
        Buffer.byteLength(normalized, 'utf8') >
          Buffer.byteLength(providerResult.text, 'utf8')
      ) {
        throw new Error('Invalid structured normalizer output')
      }
      const parsed = contract.schema.safeParse(JSON.parse(normalized))
      if (!parsed.success) throw new Error('Invalid structured output')
      return { text, structured: parsed.data }
    } catch {
      throw new ModelGatewayError(
        'schema_invalid',
        `Structured output ${contract.schemaName} failed normalization, JSON or schema validation`
      )
    }
  }

  #computeCost(profile: ModelProfile, usage: ProviderUsage): number {
    if (
      !usage ||
      !isFiniteNonnegativeCost(usage.inputTokens) ||
      !isFiniteNonnegativeCost(usage.outputTokens)
    ) {
      throw new ModelGatewayError(
        'provider_malformed_response',
        'Model provider usage requires finite nonnegative token counts'
      )
    }
    const input = (usage.inputTokens / 1000) * profile.pricing.inputPer1kUsd
    const output = (usage.outputTokens / 1000) * profile.pricing.outputPer1kUsd
    const costUsd = Math.ceil((input + output) * 1_000_000) / 1_000_000
    if (!isFiniteNonnegativeCost(costUsd)) {
      throw new ModelGatewayError(
        'provider_malformed_response',
        'Model provider usage produced an invalid cost'
      )
    }
    return costUsd
  }

  #countsAgainstCircuit(error: ModelGatewayError): boolean {
    return (
      error.code === 'provider_timeout' ||
      error.code === 'provider_unavailable' ||
      error.code === 'provider_rate_limited' ||
      error.code === 'provider_connection_reset' ||
      error.code === 'provider_malformed_response' ||
      error.code === 'internal_error'
    )
  }

  #resolvePrompt(
    request: z.infer<typeof ModelGatewayRequestSchema>,
    dataClassification: DataClassification
  ): PromptRecord {
    try {
      const record = this.#prompts.resolve(
        {
          promptId: request.promptId,
          version: request.promptVersion,
          ...(request.promptSha256 ? { sha256: request.promptSha256 } : {})
        },
        { tenantId: request.tenantId, at: this.#clock() }
      )
      if (record.classification !== dataClassification) {
        // Data class of the request must never be broader than the prompt's own
        // class; mismatches are resolved to the strictest of the two.
        const strictest =
          classificationRank(record.classification) >=
          classificationRank(dataClassification)
            ? record.classification
            : dataClassification
        if (strictest !== record.classification) {
          throw new ModelGatewayError(
            'policy_denied',
            'Request data classification exceeds the approved prompt class'
          )
        }
      }
      return record
    } catch (error) {
      if (error instanceof ModelGatewayError) throw error
      if (error instanceof PromptRegistryError) {
        throw new ModelGatewayError(
          PROMPT_ERROR_MAP[error.code],
          `Prompt reference rejected: ${error.code}`
        )
      }
      throw error
    }
  }

  #emit(event: ModelGatewayEvent): void {
    const failed = () => {
      this.#observerFailures = Math.min(
        Number.MAX_SAFE_INTEGER,
        this.#observerFailures + 1
      )
    }
    try {
      // A host may supply an async observer despite the void callback type.
      // Observe its rejection too; neither shape controls model authorization.
      const observed: unknown = this.#onEvent?.(event)
      if (
        observed &&
        typeof (observed as PromiseLike<unknown>).then === 'function'
      )
        void Promise.resolve(observed).catch(failed)
    } catch {
      failed()
    }
  }
}

function classificationRank(classification: DataClassification): number {
  const order: DataClassification[] = [
    'PUBLIC',
    'INTERNAL',
    'CONFIDENTIAL',
    'CLINICAL',
    'FINANCIAL',
    'CREDENTIAL'
  ]
  return order.indexOf(classification)
}

function routeSubstitution(
  profile: ModelProfileName,
  requested: ModelProfileName
): boolean {
  return profile !== requested
}

function assertCallerActive(signal: AbortSignal | undefined): void {
  if (signal?.aborted)
    throw new ModelGatewayError('cancelled', 'Model call was cancelled')
}

function isFiniteNonnegativeCost(cost: unknown): cost is number {
  return typeof cost === 'number' && Number.isFinite(cost) && cost >= 0
}

function waitForRetry(
  ms: number,
  signal: AbortSignal | undefined,
  sleep: ((ms: number) => Promise<void>) | undefined
): Promise<void> {
  assertCallerActive(signal)
  return new Promise<void>((resolve, reject) => {
    let timer: ReturnType<typeof setTimeout> | undefined
    const cleanup = () => {
      if (timer !== undefined) clearTimeout(timer)
      signal?.removeEventListener('abort', onAbort)
    }
    const done = () => {
      cleanup()
      resolve()
    }
    const failed = (error: unknown) => {
      cleanup()
      reject(error)
    }
    const onAbort = () =>
      failed(new ModelGatewayError('cancelled', 'Model call was cancelled'))
    signal?.addEventListener('abort', onAbort, { once: true })
    if (signal?.aborted) {
      onAbort()
      return
    }
    if (sleep) void sleep(ms).then(done, failed)
    else timer = setTimeout(done, ms)
  })
}
