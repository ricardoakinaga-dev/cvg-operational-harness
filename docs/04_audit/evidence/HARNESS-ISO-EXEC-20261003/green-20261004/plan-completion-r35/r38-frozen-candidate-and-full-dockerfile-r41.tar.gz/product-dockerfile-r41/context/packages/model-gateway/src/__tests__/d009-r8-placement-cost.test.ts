import assert from 'node:assert/strict'
import { it as test } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import { tmpdir } from 'node:os'
import {
  ModelGateway,
  PromptRegistry,
  OpenAICompatibleProvider,
  FileCostBudgetStore,
  ModelProviderError,
  ModelGatewayError,
  ModelGatewayRequestSchema,
  type ModelLocation,
  type ModelProfile,
  type GenerateRequest,
  type CostBudgetStore,
  type PromptRecord
} from '../index.ts'
import { z } from 'zod'

const tenantId = 'tenant_00000000-0000-4000-8000-000000000998'
const now = new Date('2026-10-04T12:00:00Z')
const classes: PromptRecord['classification'][] = [
  'PUBLIC',
  'INTERNAL',
  'CONFIDENTIAL',
  'CLINICAL',
  'FINANCIAL',
  'CREDENTIAL'
]
const locations: ModelLocation[] = ['local', 'external']
const sensitive: PromptRecord['classification'][] = [
  'CLINICAL',
  'FINANCIAL',
  'CREDENTIAL'
]
function setup(
  classification: (typeof classes)[number],
  profileLocation: ModelLocation,
  providerLocation: ModelLocation,
  invalidProfile?: { location: unknown }
) {
  const prompts = new PromptRegistry()
  const record = prompts.register({
    promptId: 'r8-wire',
    version: '1',
    content: 'Synthetic color fixture.',
    owner: 'fixture',
    approvedBy: 'synthetic-only',
    status: 'approved',
    classification,
    tenantId,
    effectiveFrom: '2026-01-01T00:00:00Z'
  })
  const counts = {
    provider: 0,
    dns: 0,
    http: 0,
    budgetRead: 0,
    budgetWrite: 0,
    normalizer: 0
  }
  const bodies: unknown[] = []
  const events: string[] = []
  const provider = new OpenAICompatibleProvider({
    id: 'r8-adapter',
    location: providerLocation,
    baseUrl: 'https://synthetic-wire.invalid/v1',
    model: 'color',
    requiresApiKey: false,
    dnsLookup: async () => {
      counts.dns++
      return ['93.184.216.34']
    },
    fetchImpl: async (_url, init) => {
      counts.http++
      assert.equal(typeof init.body, 'string')
      bodies.push(JSON.parse(String(init.body)))
      return new Response(
        JSON.stringify({
          choices: [{ message: { content: '{"color":"blue"}' } }],
          usage: { prompt_tokens: 1, completion_tokens: 0 }
        }),
        { status: 200 }
      )
    }
  })
  const execute = provider.execute.bind(provider)
  provider.execute = async (request) => {
    counts.provider++
    return execute(request)
  }
  const profile: ModelProfile = {
    name: 'fast',
    providerId: provider.id,
    model: 'color',
    location: profileLocation,
    temperature: 0,
    maxTokens: 32,
    timeoutMs: 1000,
    maxCostUsd: 2,
    estimatedCostUsd: 0.6,
    maxRetries: 0,
    pricing: { inputPer1kUsd: 600, outputPer1kUsd: 0 }
  }
  if (invalidProfile)
    Object.defineProperty(profile, 'location', {
      value: invalidProfile.location
    })
  const store: CostBudgetStore = {
    consumed: () => {
      counts.budgetRead++
      return 0
    },
    consume: () => {
      counts.budgetWrite++
    }
  }
  const request: GenerateRequest<{ color: string }> = {
    ...ModelGatewayRequestSchema.parse(
      JSON.parse(
        JSON.stringify({
          requestId: 'request-r8-wire',
          correlationId: 'correlation-r8-wire',
          tenantId,
          promptId: record.promptId,
          promptVersion: record.version,
          promptSha256: record.sha256,
          modelProfile: 'fast',
          dataClassification: classification,
          input: { messages: [{ role: 'user', content: 'Synthetic colors.' }] }
        })
      )
    ),
    structuredOutput: {
      schemaName: 'r8-color',
      schema: z.object({ color: z.string() }),
      normalizeText: (text) => {
        counts.normalizer++
        return text
      }
    }
  }
  const gateway = new ModelGateway({
    providers: [provider],
    profiles: { fast: profile },
    prompts,
    budget: { store, limits: { request: 2, day: 2 } },
    clock: () => now,
    onEvent: (e) => events.push(e.type)
  })
  return {
    prompts,
    record,
    provider,
    profile,
    store,
    request,
    gateway,
    counts,
    bodies,
    events
  }
}
function noEffects(counts: ReturnType<typeof setup>['counts']) {
  assert.deepEqual(counts, {
    provider: 0,
    dns: 0,
    http: 0,
    budgetRead: 0,
    budgetWrite: 0,
    normalizer: 0
  })
}
for (const classification of classes)
  for (const profileLocation of locations)
    for (const actualLocation of locations) {
      test(`wire ${classification} profile=${profileLocation} actual=${actualLocation}`, async () => {
        const f = setup(classification, profileLocation, actualLocation)
        const allowed =
          classification === 'PUBLIC' ||
          classification === 'INTERNAL' ||
          (classification === 'CONFIDENTIAL' &&
            profileLocation === 'local' &&
            actualLocation === 'local')
        if (allowed) {
          const result = await f.gateway.generate(f.request)
          assert.equal(result.promptSha256, f.record.sha256)
          assert.deepEqual(result.output.structured, { color: 'blue' })
          assert.equal(f.counts.provider, 1)
          assert.equal(f.counts.dns, 1)
          assert.equal(f.counts.http, 1)
          assert.equal(f.counts.normalizer, 1)
          assert.deepEqual(f.bodies, [
            {
              model: 'color',
              messages: [{ role: 'user', content: 'Synthetic colors.' }],
              temperature: 0,
              max_tokens: 32,
              stream: false,
              response_format: { type: 'json_object' }
            }
          ])
        } else {
          await assert.rejects(f.gateway.generate(f.request), {
            code: 'policy_denied',
            retryable: false
          })
          noEffects(f.counts)
        }
      })
    }
for (const field of ['profile', 'provider'])
  for (const location of [undefined, 'UNKNOWN', 'edge', null]) {
    test(`unknown ${field} location ${String(location)} denies before effects`, async () => {
      const f = setup(
        'INTERNAL',
        'local',
        'local',
        field === 'profile' ? { location } : undefined
      )
      if (field === 'provider')
        Object.defineProperty(f.provider, 'location', { value: location })
      await assert.rejects(f.gateway.generate(f.request), {
        code: 'policy_denied',
        retryable: false
      })
      noEffects(f.counts)
    })
  }
for (const classification of sensitive)
  for (const access of ['register', 'get', 'list', 'resolve']) {
    test(`public ${access} alias preserves ${classification} NO_MODEL`, async () => {
      const f = setup(classification, 'local', 'local')
      const alias =
        access === 'register'
          ? f.record
          : access === 'get'
            ? f.prompts.get('r8-wire', '1')
            : access === 'list'
              ? f.prompts.list()[0]
              : f.prompts.resolve(
                  { promptId: 'r8-wire', version: '1' },
                  { tenantId, at: now }
                )
      assert.throws(
        () =>
          Object.defineProperty(alias, 'classification', { value: 'INTERNAL' }),
        TypeError
      )
      f.request.dataClassification = 'PUBLIC'
      await assert.rejects(f.gateway.generate(f.request), {
        code: 'policy_denied'
      })
      noEffects(f.counts)
    })
  }
for (const caller of [undefined, 0, 0.1, 0.6, 0.8]) {
  test(`durable estimate bound profile=0.6 caller=${String(caller)} daily=0.5`, async () => {
    const f = setup('INTERNAL', 'local', 'local')
    const directory = fs.mkdtempSync(path.join(tmpdir(), 'r8-cost-'))
    const store = new FileCostBudgetStore({ directory })
    try {
      if (caller !== undefined) f.request.estimatedCostUsd = caller
      f.gateway = new ModelGateway({
        providers: [f.provider],
        profiles: { fast: f.profile },
        prompts: f.prompts,
        budget: { store, limits: { request: 2, day: 0.5 } },
        clock: () => now
      })
      await assert.rejects(f.gateway.generate(f.request), {
        code: 'budget_exceeded'
      })
      assert.equal(f.counts.provider, 0)
      assert.equal(f.counts.dns, 0)
      assert.equal(f.counts.http, 0)
      assert.equal(store.consumed('day:' + tenantId + ':2026-10-04'), 0)
    } finally {
      store.close()
      fs.rmSync(directory, { recursive: true, force: true })
    }
  })
}
test('caller higher than profile remains a conservative reservation', async () => {
  const f = setup('INTERNAL', 'local', 'local')
  const directory = fs.mkdtempSync(path.join(tmpdir(), 'r8-higher-'))
  const store = new FileCostBudgetStore({ directory })
  try {
    f.request.estimatedCostUsd = 0.8
    f.gateway = new ModelGateway({
      providers: [f.provider],
      profiles: { fast: f.profile },
      prompts: f.prompts,
      budget: { store, limits: { request: 2, day: 1 } },
      clock: () => now
    })
    const result = await f.gateway.generate(f.request)
    assert.equal(result.costUsd, 0.6)
    assert.equal(store.consumed('day:' + tenantId + ':2026-10-04'), 0.8)
    assert.equal(f.gateway.budgetHealth().ready, true)
  } finally {
    store.close()
    fs.rmSync(directory, { recursive: true, force: true })
  }
})
test('fallback rechecks actual adapter location before fallback budget', async () => {
  const f = setup('CONFIDENTIAL', 'local', 'local')
  const external = setup('CONFIDENTIAL', 'local', 'external')
  Object.defineProperty(external.provider, 'id', { value: 'r8-fallback' })
  f.provider.execute = async () => {
    f.counts.provider++
    throw new ModelProviderError(f.provider.id, 'unavailable', 'synthetic')
  }
  f.gateway = new ModelGateway({
    providers: [f.provider, external.provider],
    profiles: {
      fast: { ...f.profile, fallbackProfile: 'local' },
      local: {
        ...f.profile,
        name: 'local',
        providerId: 'r8-fallback',
        location: 'local'
      }
    },
    prompts: f.prompts,
    budget: { store: f.store, limits: { request: 2, day: 2 } },
    routing: { allowFallback: true },
    clock: () => now
  })
  await assert.rejects(f.gateway.generate(f.request), { code: 'policy_denied' })
  assert.equal(f.counts.provider, 1)
  assert.equal(f.counts.budgetWrite, 2)
  noEffects(external.counts)
})
test('cancelled request retains typed cancellation and zero admission effects', async () => {
  const f = setup('INTERNAL', 'local', 'local')
  const controller = new AbortController()
  controller.abort()
  f.request.signal = controller.signal
  await assert.rejects(f.gateway.generate(f.request), ModelGatewayError)
  await assert.rejects(f.gateway.generate(f.request), {
    code: 'cancelled',
    retryable: false
  })
  noEffects(f.counts)
})
test('CONFIDENTIAL local substitution uses an actually local registered adapter', async () => {
  const f = setup('CONFIDENTIAL', 'external', 'external')
  const local = setup('CONFIDENTIAL', 'local', 'local')
  Object.defineProperty(local.provider, 'id', { value: 'r8-local' })
  f.request.metadata = { synthetic: 'only' }
  f.gateway = new ModelGateway({
    providers: [f.provider, local.provider],
    profiles: {
      fast: f.profile,
      local: {
        ...f.profile,
        name: 'local',
        providerId: 'r8-local',
        location: 'local'
      }
    },
    prompts: f.prompts,
    budget: { store: f.store, limits: { request: 2, day: 2 } },
    routing: { allowLocalSubstitution: true },
    clock: () => now
  })
  const result = await f.gateway.generate(f.request)
  assert.equal(result.profile, 'local')
  assert.equal(result.substitutedProfile, 'fast')
  assert.equal(result.promptSha256, f.record.sha256)
  assert.deepEqual(result.output.structured, { color: 'blue' })
  assert.equal(f.counts.provider, 0)
  assert.equal(f.counts.dns, 0)
  assert.equal(f.counts.http, 0)
  assert.equal(local.counts.provider, 1)
  assert.equal(local.counts.dns, 1)
  assert.equal(local.counts.http, 1)
})
