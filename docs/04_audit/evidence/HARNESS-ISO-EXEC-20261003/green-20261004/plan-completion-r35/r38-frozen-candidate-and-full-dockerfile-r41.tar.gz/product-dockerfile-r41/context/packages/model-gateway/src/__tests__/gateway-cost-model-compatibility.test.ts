// @vitest-environment node
import { getEventListeners } from 'node:events'
import { describe, expect, it } from 'vitest'
import {
  CircuitBreaker,
  ModelGateway,
  ModelGatewayError,
  PromptRegistry,
  type ModelProfile,
  type ProviderRequest
} from '../index.ts'

const tenantId = 'tenant_00000000-0000-4000-8000-000000000180'
function prompts(classification: 'INTERNAL' | 'CONFIDENTIAL') {
  const registry = new PromptRegistry()
  registry.register({
    promptId: 'cost-model-compatibility',
    version: '1',
    content: 'Synthetic colors.',
    classification,
    tenantId,
    owner: 'fixture',
    approvedBy: 'synthetic-only',
    status: 'approved',
    effectiveFrom: '2026-01-01T00:00:00Z'
  })
  return registry
}
function profile(
  name: ModelProfile['name'],
  providerId: string,
  location: ModelProfile['location']
): ModelProfile {
  return {
    name,
    providerId,
    location,
    model: 'synthetic',
    temperature: 0,
    maxTokens: 16,
    timeoutMs: 1000,
    maxRetries: 0,
    maxCostUsd: 1,
    estimatedCostUsd: 0.016,
    pricing: { inputPer1kUsd: 1, outputPer1kUsd: 1 }
  }
}
function request() {
  return {
    requestId: 'cost-model-compatibility-request',
    correlationId: 'cost-model-compatibility-correlation',
    tenantId,
    promptId: 'cost-model-compatibility',
    promptVersion: '1',
    modelProfile: 'local' as const,
    dataClassification: 'INTERNAL' as const,
    input: {
      messages: [{ role: 'user' as const, content: 'Synthetic colors.' }]
    }
  }
}

describe('compatible controls with advertised and returned identities', () => {
  for (const composition of ['options', 'instance'] as const) {
    for (const failureMode of ['sync', 'async'] as const) {
      it(`preserves circuit observer ${composition}/${failureMode} after half-open success`, async () => {
        let time = 0,
          calls = 0
        const charges: number[] = [],
          events: string[] = []
        const controller = new AbortController()
        const circuitOptions = {
          failureThreshold: 1,
          openMs: 10,
          halfOpenSuccesses: 1,
          clock: () => time,
          onTransition: (event: { to: string }) => {
            if (event.to !== 'CLOSED') return
            const error = new Error('synthetic observer failure')
            if (failureMode === 'async') return Promise.reject(error)
            throw error
          }
        }
        const gateway = new ModelGateway({
          providers: [
            {
              id: 'compatible-observer',
              location: 'local',
              models: ['synthetic'],
              async execute(input) {
                calls++
                if (calls === 1)
                  throw new ModelGatewayError(
                    'internal_error',
                    'synthetic first failure'
                  )
                return {
                  text: 'blue',
                  usage: { inputTokens: 8, outputTokens: 8 },
                  model: input.model,
                  providerId: 'compatible-observer',
                  externalCall: false
                }
              }
            }
          ],
          profiles: { local: profile('local', 'compatible-observer', 'local') },
          prompts: prompts('INTERNAL'),
          clock: () => new Date(Date.parse('2026-10-04T12:00:00Z') + time),
          circuitBreaker:
            composition === 'instance'
              ? new CircuitBreaker(circuitOptions)
              : circuitOptions,
          budget: {
            limits: { request: 1 },
            store: {
              consumed: () => 0,
              consume: (_scope, cost) => {
                charges.push(cost)
              }
            }
          },
          onEvent: (event) => {
            events.push(event.type)
          }
        })
        const input = { ...request(), signal: controller.signal }
        await expect(gateway.generate(input)).rejects.toMatchObject({
          code: 'internal_error'
        })
        time = 11
        await expect(gateway.generate(input)).resolves.toMatchObject({
          output: { text: 'blue' },
          model: 'synthetic',
          providerId: 'compatible-observer'
        })
        await new Promise((resolve) => setImmediate(resolve))
        expect(calls).toBe(2)
        expect(charges).toEqual([0.016, 0.016])
        expect(gateway.observerFailureCount()).toBe(1)
        expect(gateway.circuitSnapshot()).toEqual({
          'compatible-observer:synthetic': 'CLOSED'
        })
        expect(
          events.filter((type) => type === 'model.call.completed')
        ).toHaveLength(1)
        expect(
          events.filter((type) => type === 'model.call.failed')
        ).toHaveLength(1)
        expect(events).not.toContain('model.retry.scheduled')
        expect(events).not.toContain('model.routing.fallback')
        expect(getEventListeners(controller.signal, 'abort')).toHaveLength(0)
      })
    }
  }
  it('preserves CONFIDENTIAL prompt local substitution with the actual provider identity', async () => {
    const calls: ProviderRequest[] = []
    const registry = prompts('CONFIDENTIAL')
    const prompt = registry.resolve(
      { promptId: 'cost-model-compatibility', version: '1' },
      { tenantId, at: new Date('2026-10-04T12:00:00Z') }
    )
    const gateway = new ModelGateway({
      providers: [
        {
          id: 'external',
          location: 'external',
          models: ['synthetic'],
          async execute() {
            throw new Error('External execution is forbidden by this oracle')
          }
        },
        {
          id: 'local',
          location: 'local',
          models: ['synthetic'],
          async execute(input) {
            calls.push(input)
            return {
              providerId: 'local',
              model: input.model,
              text: 'blue',
              usage: { inputTokens: 8, outputTokens: 8 },
              externalCall: false
            }
          }
        }
      ],
      profiles: {
        fast: profile('fast', 'external', 'external'),
        local: profile('local', 'local', 'local')
      },
      prompts: registry,
      clock: () => new Date('2026-10-04T12:00:00Z'),
      routing: { allowLocalSubstitution: true }
    })
    await expect(
      gateway.generate({
        ...request(),
        modelProfile: 'fast',
        metadata: { fixture: 'colors' }
      })
    ).resolves.toMatchObject({
      profile: 'local',
      substitutedProfile: 'fast',
      providerId: 'local',
      model: 'synthetic',
      promptSha256: prompt.sha256,
      costUsd: 0.016
    })
    expect(calls).toHaveLength(1)
    expect(calls[0]).toMatchObject({
      model: 'synthetic',
      promptSha256: prompt.sha256,
      metadata: { fixture: 'colors' }
    })
  })
})
