// @vitest-environment node
import { describe, expect, it, vi } from 'vitest'
import {
  ModelRouter,
  ModelGateway,
  PromptRegistry,
  type ModelProfile,
  type ModelProvider
} from '../index.ts'

function profile(name: ModelProfile['name'] = 'fast'): ModelProfile {
  return {
    name,
    providerId: 'r9-profile',
    model: 'color',
    location: 'external',
    temperature: 0,
    maxTokens: 400,
    timeoutMs: 1000,
    maxCostUsd: 2,
    estimatedCostUsd: 0.6,
    maxRetries: 0,
    pricing: { inputPer1kUsd: 0, outputPer1kUsd: 2 },
    ...(name === 'fast' ? { fallbackProfile: 'balanced' as const } : {})
  }
}

function setup(
  alias: 'profile' | 'resolve' | 'fallback' | 'substitution' | 'rule'
) {
  const original = profile()
  const fallback = profile('balanced')
  const local: ModelProfile = { ...profile('local'), location: 'local' }
  const router = new ModelRouter(
    { fast: original, balanced: fallback, local },
    {
      allowFallback: true,
      allowLocalSubstitution: true,
      rules: [{ task: 'chosen', profile: 'balanced' }]
    }
  )
  const record =
    alias === 'profile'
      ? router.profile('fast')
      : alias === 'fallback'
        ? router.fallbackFor(router.profile('fast')!)
        : alias === 'substitution'
          ? router.resolve({
              requestedProfile: 'fast',
              dataClassification: 'CONFIDENTIAL'
            }).profile
          : alias === 'rule'
            ? router.resolve({
                requestedProfile: 'fast',
                task: 'chosen',
                dataClassification: 'INTERNAL'
              }).profile
            : router.resolve({
                requestedProfile: 'fast',
                dataClassification: 'INTERNAL'
              }).profile
  if (!record) throw new Error('Missing synthetic profile')
  const supplier =
    alias === 'fallback' || alias === 'rule'
      ? fallback
      : alias === 'substitution'
        ? local
        : original
  return { original, fallback, local, router, record, supplier }
}

describe('D009 R9 immutable approved routing profile snapshots', () => {
  for (const alias of [
    'profile',
    'resolve',
    'fallback',
    'substitution',
    'rule'
  ] as const) {
    it(`${alias} copies caller-owned profile and pricing without freezing the caller`, () => {
      const f = setup(alias)
      const expected = structuredClone(f.supplier)
      const supplierPricing = f.supplier.pricing
      expect(f.record).not.toBe(f.supplier)
      expect(f.record.pricing).not.toBe(supplierPricing)
      expect(f.record).toEqual(expected)
      expect(Object.isFrozen(f.supplier)).toBe(false)
      expect(Object.isFrozen(supplierPricing)).toBe(false)
      f.supplier.estimatedCostUsd = 0
      supplierPricing.inputPer1kUsd = 0
      supplierPricing.outputPer1kUsd = 0
      f.supplier.providerId = 'changed'
      f.supplier.model = 'changed'
      f.supplier.location = 'local'
      f.supplier.fallbackProfile = 'local'
      f.supplier.pricing = { inputPer1kUsd: 99, outputPer1kUsd: 99 }
      expect(f.record).toEqual(expected)
      expect(f.record.estimatedCostUsd).toBe(0.6)
      expect(f.record.pricing.outputPer1kUsd).toBe(2)
      expect(f.router.profile(expected.name)).toBe(f.record)
    })
    it(`${alias} denies every public record field mutation and price mutation`, () => {
      const f = setup(alias)
      const expected = structuredClone(f.record)
      expect(Object.isFrozen(f.record)).toBe(true)
      expect(Object.isFrozen(f.record.pricing)).toBe(true)
      for (const [key, value] of Object.entries(f.record)) {
        const replacement =
          typeof value === 'number'
            ? value + 1
            : typeof value === 'object'
              ? {}
              : 'corrupt'
        expect(Reflect.set(f.record, key, replacement)).toBe(false)
        expect(Reflect.deleteProperty(f.record, key)).toBe(false)
        expect(() =>
          Object.defineProperty(f.record, key, { value: replacement })
        ).toThrow(TypeError)
      }
      for (const [key, value] of Object.entries(f.record.pricing)) {
        expect(Reflect.set(f.record.pricing, key, value + 1)).toBe(false)
        expect(Reflect.deleteProperty(f.record.pricing, key)).toBe(false)
      }
      expect(Reflect.setPrototypeOf(f.record, null)).toBe(false)
      expect(Reflect.setPrototypeOf(f.record.pricing, null)).toBe(false)
      expect(f.record).toEqual(expected)
    })
  }
  it('shares caller pricing safely between independently snapped profiles', () => {
    const primary = profile()
    const secondary = { ...profile('balanced'), pricing: primary.pricing }
    const router = new ModelRouter(
      { fast: primary, balanced: secondary },
      { allowFallback: true }
    )
    primary.pricing.outputPer1kUsd = 0
    expect(router.profile('fast')?.pricing.outputPer1kUsd).toBe(2)
    expect(router.profile('balanced')?.pricing.outputPer1kUsd).toBe(2)
    expect(router.profile('fast')?.pricing).not.toBe(
      router.profile('balanced')?.pricing
    )
  })
  it('retains optional fields, fallbacks, task routing and unknown-profile behavior', () => {
    const f = setup('profile')
    f.original.fallbackProfile = 'local'
    expect(f.router.fallbackFor(f.record)).toBe(f.router.profile('balanced'))
    expect(
      f.router.resolve({
        requestedProfile: 'fast',
        task: 'chosen',
        dataClassification: 'INTERNAL'
      })
    ).toMatchObject({
      profile: f.router.profile('balanced'),
      ruleTask: 'chosen'
    })
    expect(f.router.profile('fast')?.fallbackProfile).toBe('balanced')
    expect(f.router.profile('balanced')).not.toHaveProperty('fallbackProfile')
    expect(f.router.profile('critical-review')).toBeUndefined()
    expect(() =>
      f.router.resolve({
        requestedProfile: 'critical-review',
        dataClassification: 'INTERNAL'
      })
    ).toThrow(expect.objectContaining({ code: 'profile_unknown' }))
  })
})

function gatewayFixture(limit: number, invalidLocation?: { value: unknown }) {
  const tenantId = 'tenant_00000000-0000-4000-8000-000000000909'
  const prompts = new PromptRegistry()
  const record = prompts.register({
    promptId: 'r9-cost',
    version: '1',
    content: 'Synthetic colors.',
    owner: 'r9-fixture',
    approvedBy: 'synthetic-test-only',
    status: 'approved',
    effectiveFrom: '2026-01-01T00:00:00Z',
    classification: 'INTERNAL',
    tenantId
  })
  const original = profile()
  if (invalidLocation) {
    Reflect.set(original, 'location', invalidLocation.value)
  }
  const pricingSupplier = original.pricing
  const execute = vi.fn<ModelProvider['execute']>(async () => ({
    text: 'blue',
    usage: { inputTokens: 0, outputTokens: 300 },
    providerId: 'r9-profile',
    model: 'color',
    externalCall: false
  }))
  const store = { consumed: vi.fn(() => 0), consume: vi.fn() }
  const gateway = new ModelGateway({
    providers: [
      { id: 'r9-profile', location: 'external', models: ['color'], execute }
    ],
    profiles: { fast: original },
    prompts,
    budget: { store, limits: { request: limit, day: 2 } },
    clock: () => new Date('2026-10-04T12:00:00Z')
  })
  original.estimatedCostUsd = 0
  pricingSupplier.outputPer1kUsd = 0
  const request = {
    requestId: 'r9-cost-request',
    correlationId: 'r9-cost-correlation',
    tenantId,
    promptId: record.promptId,
    promptVersion: record.version,
    promptSha256: record.sha256,
    dataClassification: 'INTERNAL' as const,
    modelProfile: 'fast' as const,
    input: {
      messages: [{ role: 'user' as const, content: 'Synthetic colors.' }]
    }
  }
  return { gateway, request, store, execute, original, pricingSupplier }
}

describe('D009 R9 profile and configured price remain conservative admission authority', () => {
  for (const value of [undefined, 'UNKNOWN', 'edge', null]) {
    it(`denies unknown profile location ${String(value)} supplied before composition`, async () => {
      const f = gatewayFixture(2, { value })
      await expect(f.gateway.generate(f.request)).rejects.toMatchObject({
        code: 'policy_denied',
        retryable: false
      })
      expect(f.execute).not.toHaveBeenCalled()
      expect(f.store.consumed).not.toHaveBeenCalled()
      expect(f.store.consume).not.toHaveBeenCalled()
    })
  }
  for (const requested of [undefined, 0, 0.1, 0.6, 0.8]) {
    it(`caller estimate ${requested} and supplier mutation cannot reduce approved 0.6`, async () => {
      const f = gatewayFixture(2)
      const result = await f.gateway.generate({
        ...f.request,
        ...(requested !== undefined ? { estimatedCostUsd: requested } : {})
      })
      expect(result.costUsd).toBe(0.6)
      expect(f.store.consume).toHaveBeenCalledTimes(2)
      for (const call of f.store.consume.mock.calls)
        expect(call[1]).toBe(Math.max(requested ?? 0, 0.6))
      expect(f.execute).toHaveBeenCalledTimes(1)
      expect(f.original.estimatedCostUsd).toBe(0)
      expect(f.pricingSupplier.outputPer1kUsd).toBe(0)
    })
  }
  it('denies configured request limit below the approved estimate before provider', async () => {
    const f = gatewayFixture(0.5)
    await expect(
      f.gateway.generate({ ...f.request, estimatedCostUsd: 0 })
    ).rejects.toMatchObject({ code: 'budget_exceeded' })
    expect(f.execute).not.toHaveBeenCalled()
    expect(f.store.consume).not.toHaveBeenCalled()
  })
})
