import { describe, expect, it, vi } from 'vitest'
import { trimTrailingSlashes } from '../trim-trailing-slashes.ts'
import { ChatwootChannelAdapter } from '../adapters/chatwoot.ts'
import { EvolutionChannelAdapter } from '../adapters/evolution.ts'

describe('linear channel URL normalization', () => {
  it.each([2048, 4096, 8192, 16384])(
    'preserves URL suffix at %i and performs no network in constructors',
    (length) => {
      const baseUrl = `https://synthetic.example/${'/'.repeat(length)}`
      expect(trimTrailingSlashes(baseUrl)).toBe(baseUrl.replace(/\/+$/, ''))
      const fetchImpl = vi.fn()
      expect(
        () =>
          new ChatwootChannelAdapter({
            enabled: true,
            baseUrl,
            apiKey: 'synthetic_not_a_secret',
            accountId: '1',
            fetchImpl
          })
      ).not.toThrow()
      expect(
        () =>
          new EvolutionChannelAdapter({
            enabled: true,
            baseUrl,
            apiKey: 'synthetic_not_a_secret',
            instance: 'synthetic',
            fetchImpl
          })
      ).not.toThrow()
      expect(fetchImpl).not.toHaveBeenCalled()
    }
  )
  it.each([
    'file:///synthetic',
    'http://169.254.169.254////',
    'http://127.0.0.1:1////'
  ])('preserves SSRF denial for %s', (baseUrl) => {
    const fetchImpl = vi.fn()
    expect(
      () =>
        new ChatwootChannelAdapter({
          enabled: true,
          baseUrl,
          apiKey: 'synthetic_not_a_secret',
          accountId: '1',
          fetchImpl
        })
    ).toThrow()
    expect(
      () =>
        new EvolutionChannelAdapter({
          enabled: true,
          baseUrl,
          apiKey: 'synthetic_not_a_secret',
          instance: 'synthetic',
          fetchImpl
        })
    ).toThrow()
    expect(fetchImpl).not.toHaveBeenCalled()
  })
})
