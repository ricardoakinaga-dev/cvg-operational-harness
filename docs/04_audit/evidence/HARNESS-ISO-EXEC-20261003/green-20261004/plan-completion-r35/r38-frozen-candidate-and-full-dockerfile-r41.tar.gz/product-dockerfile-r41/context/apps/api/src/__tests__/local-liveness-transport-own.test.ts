import Fastify from 'fastify'
import { afterEach, describe, expect, it } from 'vitest'
import {
  installHttpSecurityHooks,
  normalizeHttpSecurityOptions
} from '../http-security.ts'

const apps: ReturnType<typeof Fastify>[] = []
afterEach(async () => {
  await Promise.all(apps.splice(0).map((app) => app.close()))
})
function server() {
  const app = Fastify({ trustProxy: ['10.20.0.7'] })
  apps.push(app)
  installHttpSecurityHooks(
    app,
    normalizeHttpSecurityOptions({
      enforceHttps: true,
      trustedProxyAddresses: ['10.20.0.7']
    })
  )
  app.get('/live', async () => ({ status: 'alive' }))
  app.get('/health', async () => ({ status: 'health' }))
  app.get('/ready', async () => ({ status: 'ready' }))
  app.post('/live', async () => ({ status: 'effect' }))
  return app
}
describe('local image liveness transport boundary', () => {
  it.each(['127.0.0.1', '::1', '::ffff:127.0.0.1', '0:0:0:0:0:0:0:1'])(
    'allows the exact read-only probe for socket %s',
    async (remoteAddress) => {
      const response = await server().inject({
        method: 'GET',
        url: '/live',
        remoteAddress
      })
      expect(response.statusCode).toBe(200)
      expect(response.json()).toEqual({ status: 'alive' })
      expect(response.headers['strict-transport-security']).toBeUndefined()
    }
  )
  it.each([
    '10.20.0.7',
    '10.20.0.8',
    '127.0.0.2',
    '0.0.0.0',
    '::',
    '::ffff:10.20.0.8'
  ])(
    'denies insecure nonprobe socket %s despite forwarded loopback claims',
    async (remoteAddress) => {
      const response = await server().inject({
        method: 'GET',
        url: '/live',
        remoteAddress,
        headers: {
          'x-forwarded-for': '127.0.0.1',
          'x-forwarded-host': 'localhost'
        }
      })
      expect(response.statusCode).toBe(426)
      expect(response.json()).toMatchObject({
        error: { code: 'secure_transport_required' }
      })
    }
  )
  it.each([
    '/health',
    '/ready',
    '/live?probe=1',
    '/live/',
    '/%6cive',
    '/missing'
  ])('keeps HTTPS for loopback path %s', async (url) => {
    expect(
      (
        await server().inject({
          method: 'GET',
          url,
          remoteAddress: '127.0.0.1'
        })
      ).statusCode
    ).toBe(426)
  })
  it.each(['POST', 'HEAD', 'OPTIONS'] as const)(
    'keeps HTTPS for method %s',
    async (method) => {
      expect(
        (
          await server().inject({
            method,
            url: '/live',
            remoteAddress: '127.0.0.1'
          })
        ).statusCode
      ).toBe(426)
    }
  )
  it('continues to require trusted provenance for forwarded HTTPS', async () => {
    const app = server()
    expect(
      (
        await app.inject({
          method: 'GET',
          url: '/live',
          remoteAddress: '10.20.0.8',
          headers: { 'x-forwarded-proto': 'https' }
        })
      ).statusCode
    ).toBe(426)
    const allowed = await app.inject({
      method: 'GET',
      url: '/live',
      remoteAddress: '10.20.0.7',
      headers: { 'x-forwarded-proto': 'https' }
    })
    expect(allowed.statusCode).toBe(200)
    expect(allowed.headers['strict-transport-security']).toBe(
      'max-age=31536000'
    )
  })
  it('preserves CORS rejection on the local probe', async () => {
    expect(
      (
        await server().inject({
          method: 'GET',
          url: '/live',
          remoteAddress: '127.0.0.1',
          headers: { origin: 'https://unknown.example.test' }
        })
      ).statusCode
    ).toBe(403)
  })
  it('accepts the actual loopback fetch used by the image without transport headers', async () => {
    const app = server()
    await app.listen({ host: '127.0.0.1', port: 0 })
    const address = app.server.address()
    if (!address || typeof address === 'string')
      throw new Error('TCP address missing')
    const origin = 'http://127.0.0.1:' + address.port
    const live = await fetch(origin + '/live')
    expect(live.status).toBe(200)
    expect(await live.json()).toEqual({ status: 'alive' })
    expect((await fetch(origin + '/health')).status).toBe(426)
  })
})
