from pathlib import Path
import shutil,os,json,hashlib,datetime
b=Path('/home/ricardo/.cache/cvg-harness-green-20261004');s=b/'candidate-final-r25';t=b/'plan-completion-r35/candidate-journal-r38';o=b/'plan-completion-r35/lead/prepare-r38';o.mkdir(exist_ok=False)
skip={'.git','.gauntlet','coverage','playwright-report','test-results','certification'}
def ignore(d,names):
 return [n for n in names if n in skip or n=='.env' or (n.startswith('.env.') and not n.endswith(('example','sample','template')))]
def records(root):
 rows={}
 for d,dirs,files in os.walk(root,followlinks=False):
  dirs[:]=[n for n in dirs if n not in ignore(d,dirs)]
  for n in files+[x for x in dirs if (Path(d)/x).is_symlink()]:
   if n in ignore(d,[n]):continue
   p=Path(d)/n;rel=str(p.relative_to(root))
   if p.is_symlink():rows[rel]={'type':'symlink','target':os.readlink(p)}
   elif p.is_file():
    h=hashlib.sha256()
    with p.open('rb') as f:
     for c in iter(lambda:f.read(1048576),b''):h.update(c)
    rows[rel]={'type':'file','bytes':p.stat().st_size,'sha256':h.hexdigest(),'mode':p.stat().st_mode&0o7777}
 return rows
assert not t.exists();before=records(s);(o/'source-before.json').write_text(json.dumps(before,sort_keys=True)+'\n');shutil.copytree(s,t,symlinks=True,ignore=ignore);copied=records(t);after=records(s);assert copied==before==after
(o/'copied.json').write_text(json.dumps(copied,sort_keys=True)+'\n');(o/'source-after.json').write_text(json.dumps(after,sort_keys=True)+'\n');links=[k for k,v in copied.items() if v['type']=='symlink'];external=[]
for k in links:
 p=t/k
 if not p.resolve().is_relative_to(t):external.append(k)
assert not external
receipt={'task':'R38_FULL_CANDIDATE_AND_GATES','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':str(s),'target':str(t),'filesAndLinks':len(copied),'sourceBeforeCopyAfter':'MATCH','links':links,'externalLinks':external,'privateEnvCopied':False,'runtimeDeltaApplied':False,'sourceDependencies':'physical own copy'};(o/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('PHYSICAL_R38_BASE_PREPARED',len(copied),'links',len(links),flush=True)
