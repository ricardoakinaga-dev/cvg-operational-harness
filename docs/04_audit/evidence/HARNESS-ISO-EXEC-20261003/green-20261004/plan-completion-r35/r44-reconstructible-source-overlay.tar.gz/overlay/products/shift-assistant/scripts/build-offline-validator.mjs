import { fileURLToPath } from 'node:url'
import { build } from 'esbuild'

// Build-time dependency only. The operational CLI needs Node and this bundle.
await build({
  absWorkingDir: fileURLToPath(new URL('..', import.meta.url)),
  entryPoints: [fileURLToPath(new URL('../src/store.ts', import.meta.url))],
  outfile: fileURLToPath(
    new URL('../dist/offline-validator.mjs', import.meta.url)
  ),
  bundle: true,
  platform: 'node',
  target: 'node22',
  format: 'esm',
  legalComments: 'none',
  tsconfig: fileURLToPath(new URL('../tsconfig.build.json', import.meta.url))
})
