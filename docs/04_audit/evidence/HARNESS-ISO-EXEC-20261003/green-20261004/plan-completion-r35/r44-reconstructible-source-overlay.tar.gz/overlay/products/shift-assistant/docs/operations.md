# Operação e recuperação local

Este procedimento implementa as provas locais da SPEC 0179. Use somente
volumes e serviços sintéticos próprios. O monitor entregue aceita endpoints
HTTP com IP literal de loopback; não está qualificado para notificação externa,
queda física de host ou recebimento pelo gestor real.

Antes do backup, pause o assistente, encerre o processo e comprove que não há
escritor. O script adquire `store.lock` exclusivamente e recusa locks existentes,
inclusive residuais. Não apague um lock para contornar essa recusa: identifique
seu dono e preserve o volume para reconciliação.

Prepare o artefato com o build atual do produto em Node 22. Tanto `build` como
`build:vertical` geram `dist/offline-validator.mjs` a partir do replay do produto,
com as dependências incluídas. Distribua esse arquivo junto de
`scripts/backup-restore.mjs`, conservando os caminhos relativos; a CLI usa
somente Node, sem TSX, TypeScript ou instalação no runtime. O Dockerfile inclui
ambos em `/app/dist/offline-validator.mjs` e `/app/scripts/backup-restore.mjs`.

```sh
npm run build --workspace @cvg/shift-assistant
```

```sh
node products/shift-assistant/scripts/backup-restore.mjs backup /volume/sintetico /backup/novo
node products/shift-assistant/scripts/backup-restore.mjs restore /backup/novo /volume/restaurado
```

Os diretórios pais precisam existir e ser físicos. Backup e destino de restore
devem ser novos ou vazios, separados do volume de origem. A cópia inclui todos
os documentos, mídia, órfãos, recovery e manifestos. O inventário registra
bytes/SHA-256, UUID do journal, sequência, cabeça da cadeia e prefixes dos
segmentos. Não inclui configuração `.env` ou arquivos de credenciais. Um backup
só recebe `backup_verified` depois da comparação das cópias e da validação
completa pelo replay do produto, incluindo manifesto/revisão, descriptors,
gramática dos eventos, referências e mídia publicada. Essa validação não abre
escritor, não muda permissões, não migra nem recupera o volume. Um tail ainda
não recuperado exige primeiro recuperação pelo procedimento do produto em uma
cópia própria; a validação offline apenas o recusa. Os originais
permanecem intactos. Restore rejeita inventário divergente, documento ausente,
extra, symlink, path inseguro ou identidade de journal divergente.

`restore-hold.json` é criado antes de copiar o journal. O volume restaurado deve
ser aberto sob hold e com egress negado; `retomar` não remove esse marcador.
Compare notas/fonte/bindings, tarefas, inbox/outbox, receipts/uncertain, pausa,
sequência e bytes de mídia com o volume parado. Reconcilie fatos posteriores ao
backup e qualquer entrega incerta antes de autorizar operação. Uma restauração
parcial fica com lock e exige intervenção; não há limpeza, truncamento,
pruning, replay cego de envio ou liberação automática de hold.

Em processo vivo, ingresso, gravação, efeitos e readiness conferem identidade,
tamanho, permissões e timestamps POSIX dos documentos já validados, incluindo
segmentos, manifesto/revisão e mídia referenciada. Divergência torna o storage
indisponível até reconciliação com o processo parado; restaurar os bytes ou
retomar o assistente não reabre o gate. O caminho quente não relê nem calcula
hash integral do journal. O custo acompanha os arquivos monitorados, não os
bytes/eventos do segmento. Essa detecção depende de filesystem POSIX local
com inode e mtime/ctime coerentes; não exclui um escritor hostil concorrente,
mudança dentro de uma syscall de append, timestamps indistinguíveis, alteração
de disco sem atualização de metadados ou efeitos de transporte já iniciados.
Não qualifica filesystem remoto, energia, kernel ou armazenamento físico.

O watchdog roda fora do processo do assistente:

```sh
node products/shift-assistant/scripts/monitor.mjs /config/monitor-sintetico.json
```

Para execução Node local, o supervisor também precisa ficar fora do processo:

```sh
node products/shift-assistant/scripts/supervise-process.mjs /candidato/shift-assistant.mjs
```

O supervisor encaminha SIGTERM, permite até 10 segundos ao filho e usa SIGKILL
se ele continuar vivo, com orçamento total máximo de 15 segundos. Parada forçada
retorna status próprio e código não zero; não é encerramento gracioso. O filho
e o supervisor precisam de configuração sintética e permissões próprias. O
runtime nunca rouba o lock residual: conserve o volume original, pare o processo,
reconcilie em uma cópia nova sob hold e mantenha os efeitos negados. A prova local
injeta bloqueio síncrono dentro do adapter de sync de um processo Node real;
não certifica kernel em estado ininterruptível, storage físico ou falta de energia.
Se o filho não puder ser contido no prazo, o supervisor informa falha de
contenção e exige intervenção, sem receipt de sucesso. Em container, o supervisor
do host também precisa aplicar o prazo; o compose fixa grace de 15 segundos.

O arquivo JSON contém `liveUrl`, `readyUrl`, `receiverUrl` terminado em `/alerts`,
`stateDirectory`, `candidateDigest` SHA-256 e `instanceOpaqueId` UUID. Todos os
endpoints são loopback explícito e não podem conter credenciais ou query.
O padrão é poll de 10 segundos e deadline de 2 segundos por request, incluindo
a leitura do body. Dois resultados ruins iniciam um episódio; dois bons geram
resolved. Pausa saudável é aviso informativo. Motivos desconhecidos são
substituídos por código fixo. Os payloads não levam texto, paciente, telefone,
URL ou segredo.

O receptor deve persistir payload/hash/receivedAt e devolver `receiptID` UUID.
HTTP 200 sem recibo válido permanece pendente. Alertas têm identidade estável
por episódio/estado; o receptor precisa deduplicar essa identidade. A fila e o
orçamento de cinco tentativas sobrevivem ao restart, com delays de 30 segundos,
2 minutos, 10 minutos e 30 minutos. Novos eventos de um motivo respeitam um
minuto entre envios; tentativas repetidas conservam a identidade. Depois de
cinco falhas o item fica `failed`, visível em `state.json`, sem receipt fictício.
Locks residuais do monitor também não são roubados automaticamente.

A prova de queda entre processos locais não valida monitor em outro host.
Produção requer monitor e receptor em domínio de falha independente,
recebimento pelo responsável, política de rede aplicada, premissas de sync do
storage e qualificação humana do procedimento e dos dados. Esses aceites não
são emitidos por este runbook nem por um teste sintético.
