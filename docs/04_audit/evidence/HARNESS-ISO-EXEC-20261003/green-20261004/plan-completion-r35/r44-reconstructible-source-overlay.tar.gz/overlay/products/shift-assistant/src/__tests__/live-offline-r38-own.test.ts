// @vitest-environment node
import * as fs from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { createServer, type Server } from 'node:http'
import type { AddressInfo } from 'node:net'
import { afterEach, expect, it } from 'vitest'
import { ShiftStore } from '../store.ts'
import { canonical, sha256 } from '../journal.ts'
import { ShiftAssistant } from '../assistant.ts'
import { WahaClient } from '../whatsapp.ts'
import { buildShiftServer } from '../server.ts'
import {
  backupStoppedVolume,
  restoreBackup
} from '../../scripts/backup-restore.mjs'
const AT = '2026-10-03T12:00:00.000Z',
  PHONE = '5511900000001'
const closers: Array<() => void | Promise<void>> = []
afterEach(async () => {
  for (const close of closers.splice(0).reverse()) await close()
})
function fixture(media = false) {
  const root = fs.mkdtempSync(join(tmpdir(), 'r38-retained-')),
    source = join(root, 'source')
  const store = new ShiftStore(source)
  const descriptor = media
    ? store.saveMediaDescriptor(
        Buffer.from('synthetic media'),
        'image/png',
        'm1'
      )
    : undefined
  store.commit({
    transitionId: 'input:m1',
    expected: { inbox: { m1: 0 } },
    changes: [
      {
        type: 'message_received',
        at: AT,
        message: {
          provider: 'waha',
          messageId: 'm1',
          fromPhone: PHONE,
          kind: media ? 'image' : 'text',
          text: 'ajuda',
          receivedAt: AT,
          ...(descriptor ? { mediaRef: descriptor.path } : {})
        }
      }
    ]
  })
  store.close()
  return {
    root,
    source,
    media: descriptor?.path,
    backup: join(root, 'backup'),
    target: join(root, 'target')
  }
}
function manifest(root: string) {
  return JSON.parse(
    fs.readFileSync(join(root, 'journal/manifest.json'), 'utf8')
  )
}
function active(root: string) {
  return join(root, manifest(root).segments.at(-1).path)
}
function files(root: string, relative = ''): Record<string, string> {
  const values: Record<string, string> = {}
  for (const name of fs.readdirSync(join(root, relative)).sort()) {
    const rel = relative ? relative + '/' + name : name
    if (rel === 'store.lock') continue
    if (fs.statSync(join(root, rel)).isDirectory())
      Object.assign(values, files(root, rel))
    else values[rel] = sha256(fs.readFileSync(join(root, rel)))
  }
  return values
}
function mutate(root: string, mode: string, media?: string) {
  const m = manifest(root)
  if (mode === 'revision') delete m.revision
  if (mode === 'prefix') m.segments[0].prefixSha256 = 'f'.repeat(64)
  if (mode === 'revision-file') {
    fs.unlinkSync(
      join(root, 'journal/manifests/revision-' + m.revision + '.json')
    )
    return
  }
  if (mode === 'revision' || mode === 'prefix') {
    const bytes = canonical(m) + '\n'
    fs.writeFileSync(join(root, 'journal/manifest.json'), bytes)
    fs.writeFileSync(join(root, 'journal/manifests/revision-1.json'), bytes)
  } else if (mode === 'unknown' || mode === 'reference') {
    const record = JSON.parse(fs.readFileSync(active(root), 'utf8'))
    record.changes = [
      {
        type: mode === 'unknown' ? 'unrecognized_event' : 'task_done',
        at: AT,
        ...(mode === 'reference' ? { number: 1 } : {})
      }
    ]
    const { sha256: _checksum, ...body } = record
    void _checksum
    record.sha256 = sha256(canonical(body))
    fs.writeFileSync(active(root), canonical(record) + '\n')
  } else if (mode === 'media') fs.unlinkSync(join(root, media!))
  else if (mode === 'media-sidecar')
    fs.writeFileSync(join(root, media! + '.json'), '{}')
  else if (mode === 'tail') fs.appendFileSync(active(root), '{"partial":')
}
const modes = [
  'revision',
  'prefix',
  'unknown',
  'media',
  'revision-file',
  'reference',
  'media-sidecar'
]
it.each(modes)(
  'refuses offline backup and independently forged hash-consistent restore: %s',
  (mode) => {
    const f = fixture(mode.startsWith('media'))
    backupStoppedVolume(f.source, f.backup)
    mutate(f.source, mode, f.media)
    const docs = join(f.backup, 'documents')
    mutate(docs, mode, f.media)
    const receipt = JSON.parse(
      fs.readFileSync(join(f.backup, 'manifest.json'), 'utf8')
    )
    const hashes = files(docs)
    receipt.documents = receipt.documents
      .filter((d: { path: string }) => d.path in hashes)
      .map((d: { path: string }) => ({
        path: d.path,
        bytes: fs.statSync(join(docs, d.path)).size,
        sha256: hashes[d.path]
      }))
    if (mode === 'revision') delete receipt.journal.manifestRevision
    if (mode === 'unknown' || mode === 'reference') {
      const bytes = fs.readFileSync(active(docs))
      receipt.journal.headSha256 = JSON.parse(bytes.toString()).sha256
      receipt.journal.prefixes[0] = {
        path: manifest(docs).segments[0].path,
        bytes: bytes.length,
        sha256: sha256(bytes)
      }
    }
    fs.writeFileSync(join(f.backup, 'manifest.json'), JSON.stringify(receipt))
    const before = files(f.source),
      copiedBefore = files(docs)
    const runtime = new ShiftStore(f.source)
    const runtimeAvailable = runtime.storageAvailable
    runtime.close()
    let backupAccepted = false,
      restoreAccepted = false
    try {
      backupStoppedVolume(f.source, join(f.root, 'bad-backup'))
      backupAccepted = true
    } catch {
      /* expected refusal */
    }
    try {
      restoreBackup(f.backup, f.target)
      restoreAccepted = true
    } catch {
      /* expected refusal */
    }
    console.info('R38_OFFLINE', {
      mode,
      root: f.root,
      runtimeAvailable,
      backupAccepted,
      restoreAccepted
    })
    expect(files(f.source)).toEqual(before)
    expect(files(docs)).toEqual(copiedBefore)
    expect(runtimeAvailable).toBe(false)
    expect(backupAccepted).toBe(false)
    expect(restoreAccepted).toBe(false)
    expect(fs.existsSync(f.target)).toBe(false)
  }
)
async function bind(server: Server) {
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve))
  closers.push(() => {
    server.closeAllConnections()
    return new Promise<void>((resolve) => server.close(() => resolve()))
  })
  return 'http://127.0.0.1:' + (server.address() as AddressInfo).port
}
it.each([
  'byte',
  'truncate',
  'replace',
  'manifest',
  'revision-file',
  'media',
  'media-sidecar',
  'utimes'
])(
  'denies live ingress/readiness/effects and preserves corrupted bytes: %s',
  async (mode) => {
    const f = fixture(mode.startsWith('media')),
      store = new ShiftStore(f.source)
    closers.push(() => store.close())
    let sends = 0
    const receiver = createServer((req, res) => {
      req.resume()
      if (req.url === '/api/sendText') sends++
      res.setHeader('content-type', 'application/json')
      res.end('{"id":"synthetic-accepted"}')
    })
    const client = new WahaClient({
      baseUrl: await bind(receiver),
      apiKey: 'synthetic',
      session: 'r38',
      fetch
    })
    const assistant = new ShiftAssistant({
      store,
      members: [{ phone: PHONE, name: 'Synthetic', manager: true }],
      whatsapp: client,
      organizer: {
        async organize() {
          throw new Error('NO_MODEL')
        }
      },
      transcriber: {
        async transcribe() {
          throw new Error('NO_MODEL')
        }
      }
    })
    closers.push(() => assistant.stop())
    const server = buildShiftServer({
        store,
        assistant,
        whatsapp: client,
        webhookSecret: 'r38-synthetic-secret'
      }),
      url = await bind(server)
    expect((await fetch(url + '/health/ready')).status).toBe(200)
    const segment = active(f.source),
      original = fs.readFileSync(segment),
      originalStat = fs.statSync(segment)
    if (mode === 'byte' || mode === 'utimes') {
      const fd = fs.openSync(segment, 'r+')
      fs.writeSync(fd, Buffer.from('!'), 0, 1, 0)
      fs.closeSync(fd)
    }
    if (mode === 'utimes')
      fs.utimesSync(segment, originalStat.atime, originalStat.mtime)
    if (mode.startsWith('media')) mutate(f.source, mode, f.media)
    if (mode === 'truncate') fs.truncateSync(segment, original.length - 1)
    if (mode === 'replace') {
      fs.renameSync(segment, segment + '.retained')
      fs.writeFileSync(segment, original)
    }
    if (mode === 'manifest')
      fs.appendFileSync(join(f.source, 'journal/manifest.json'), ' ')
    if (mode === 'revision-file') mutate(f.source, mode)
    const before = files(f.source)
    const response = await fetch(url + '/webhooks/waha', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-cvg-webhook-secret': 'r38-synthetic-secret'
      },
      body: JSON.stringify({
        event: 'message',
        session: 'r38',
        payload: { id: 'after-corrupt', from: PHONE + '@c.us', body: 'ajuda' }
      })
    })
    await assistant.idle()
    const ready = await fetch(url + '/health/ready')
    console.info('R38_LIVE', {
      mode,
      root: f.root,
      ingress: response.status,
      readiness: ready.status,
      sends,
      bytesPreserved: canonical(files(f.source)) === canonical(before)
    })
    expect(response.status).toBe(503)
    expect(ready.status).toBe(503)
    expect(sends).toBe(0)
    expect(store.effectsAllowed).toBe(false)
    expect(files(f.source)).toEqual(before)
  }
)
it('healthy backup/restore preserves exact bytes and reopens under hold; unrecovered tail is refused without rewriting it', () => {
  const f = fixture(true),
    before = files(f.source)
  expect(backupStoppedVolume(f.source, f.backup).status).toBe('backup_verified')
  expect(restoreBackup(f.backup, f.target).status).toBe('restored_under_hold')
  expect(files(f.source)).toEqual(before)
  const reopened = new ShiftStore(f.target)
  try {
    expect(reopened.storageAvailable).toBe(true)
    expect(reopened.effectsAllowed).toBe(false)
  } finally {
    reopened.close()
  }
  mutate(f.source, 'tail')
  const corrupt = files(f.source)
  expect(() =>
    backupStoppedVolume(f.source, join(f.root, 'tail-backup'))
  ).toThrow()
  expect(files(f.source)).toEqual(corrupt)
})

it('checks readiness before ingress and keeps failure sticky after byte restoration', async () => {
  const f = fixture(),
    store = new ShiftStore(f.source)
  closers.push(() => store.close())
  const original = fs.readFileSync(active(f.source)),
    fd = fs.openSync(active(f.source), 'r+')
  fs.writeSync(fd, Buffer.from('!'), 0, 1, 0)
  fs.closeSync(fd)
  expect(store.storageAvailable).toBe(false)
  fs.writeFileSync(active(f.source), original)
  expect(store.storageAvailable).toBe(false)
  expect(() => store.append({ type: 'paused', at: AT, by: PHONE })).toThrow(
    'STORAGE_UNAVAILABLE'
  )
  expect(fs.readFileSync(active(f.source))).toEqual(original)
})

it.each(['after_journal_lf', 'after_journal_sync'])(
  'does not bless corruption in the %s checkpoint as an owned write',
  (point) => {
    const f = fixture()
    let armed = false
    const store = new ShiftStore(f.source, {
      io: {
        checkpoint(name) {
          if (armed && name === point) {
            const fd = fs.openSync(active(f.source), 'r+')
            fs.writeSync(fd, Buffer.from('!'), 0, 1, 0)
            fs.closeSync(fd)
          }
        }
      }
    })
    closers.push(() => store.close())
    armed = true
    expect(() => store.append({ type: 'paused', at: AT, by: PHONE })).toThrow(
      'STORAGE_UNAVAILABLE'
    )
    expect(store.storageAvailable).toBe(false)
    expect(store.effectsAllowed).toBe(false)
    expect(fs.readFileSync(active(f.source))[0]).toBe(33)
  }
)

it('validates offline without lock, chmod, fsync, recovery or document modification', () => {
  const f = fixture(true)
  fs.chmodSync(active(f.source), 0o640)
  const before = files(f.source),
    stat = fs.statSync(active(f.source), { bigint: true })
  const result = ShiftStore.validateStoppedVolume(f.source)
  const after = fs.statSync(active(f.source), { bigint: true })
  expect(result.sequence).toBe(1)
  expect(files(f.source)).toEqual(before)
  expect([after.mode, after.mtimeNs, after.ctimeNs, after.ino]).toEqual([
    stat.mode,
    stat.mtimeNs,
    stat.ctimeNs,
    stat.ino
  ])
  expect(fs.existsSync(join(f.source, 'store.lock'))).toBe(false)
  mutate(f.source, 'tail')
  const damaged = files(f.source)
  expect(() => ShiftStore.validateStoppedVolume(f.source)).toThrow(
    'STORAGE_UNAVAILABLE'
  )
  expect(files(f.source)).toEqual(damaged)
  expect(fs.readdirSync(join(f.source, 'recovery'))).toEqual([])
})
