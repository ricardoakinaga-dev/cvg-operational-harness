from pathlib import Path
import subprocess,json,hashlib,datetime,os
home=Path(__file__).parent;ctx=home/'context';cmd=['docker','build','--progress=plain','--pull=false','--network=default','--file',str(ctx/'products/shift-assistant/deploy/Dockerfile'),'--tag','cvg-r59-full-product:local','--iidfile',str(home/'image-id.txt'),str(ctx)]
env={k:v for k,v in os.environ.items() if k in ['HOME','LANG','PATH','DOCKER_HOST']};start=datetime.datetime.now(datetime.timezone.utc).isoformat();(home/'build-command.json').write_text(json.dumps({'command':cmd,'providerCalls':0},indent=2)+'\n')
with (home/'build.log').open('wb') as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
(home/'build-result.json').write_text(json.dumps({'exitCode':p.returncode,'startedUtc':start,'finishedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'logSha256':hashlib.sha256((home/'build.log').read_bytes()).hexdigest()},indent=2)+'\n');print('dockerBuildExit',p.returncode);raise SystemExit(p.returncode)
