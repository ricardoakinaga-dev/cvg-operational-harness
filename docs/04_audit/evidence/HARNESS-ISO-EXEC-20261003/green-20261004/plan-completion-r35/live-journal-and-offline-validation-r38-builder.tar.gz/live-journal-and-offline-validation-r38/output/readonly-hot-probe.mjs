import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { ShiftStore } from './scratch-artifact/dist/offline-validator.mjs'
const out=path.dirname(fileURLToPath(import.meta.url)), healthy=path.join(out,'tmp/compiled-cli-healthy')
console.log('R38_OFFLINE_BEGIN')
assert.equal(ShiftStore.validateStoppedVolume(healthy).sequence,1)
console.log('R38_OFFLINE_END')
assert.equal(fs.existsSync(path.join(healthy,'store.lock')),false)
const store=new ShiftStore(healthy)
try {
 console.log('R38_HOT_BEGIN')
 const started=performance.now()
 for(let i=0;i<1000;i++) {assert.equal(store.storageAvailable,true);assert.equal(store.effectsAllowed,false)}
 console.log('R38_HOT_END '+JSON.stringify({boundaries:2000,elapsedMs:performance.now()-started}))
} finally {store.close()}
