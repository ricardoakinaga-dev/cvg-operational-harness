import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { createServer } from 'node:http'
import { spawn, spawnSync } from 'node:child_process'
import { once } from 'node:events'
import { createHash } from 'node:crypto'
import { fileURLToPath } from 'node:url'
const out = path.dirname(fileURLToPath(import.meta.url)), product = path.resolve(out, '../candidate/products/shift-assistant')
const artifact = path.join(out, 'scratch-artifact')
fs.mkdirSync(path.join(artifact, 'dist'), { recursive: true }); fs.mkdirSync(path.join(artifact, 'scripts'), { recursive: true })
for (const [src, dst] of [['dist/shift-assistant.mjs', 'shift-assistant.mjs'], ['dist/offline-validator.mjs', 'dist/offline-validator.mjs'], ['scripts/backup-restore.mjs', 'scripts/backup-restore.mjs']]) fs.copyFileSync(path.join(product, src), path.join(artifact, dst))
const hash = bytes => createHash('sha256').update(bytes).digest('hex')
const cli = path.join(artifact, 'scripts/backup-restore.mjs')
const results = [], cliEnv = { PATH: process.env.PATH, HOME: process.env.HOME, TMPDIR: process.env.TMPDIR, NODE_ENV: 'test' }
const records = JSON.parse(fs.readFileSync(path.join(out, 'original-cli-reproductions.json')))
for (const record of records) {
 const mode = record.args[2], src = record.args[3], dst = record.args[4] + '-r38'
 const args = [cli, mode, src, dst], p = spawnSync(process.execPath, args, { env: cliEnv, encoding: 'utf8' })
 results.push({ args: [process.execPath, ...args], env: cliEnv, exit: p.status, stdout: p.stdout, stderr: p.stderr })
 assert.equal(p.status, 1); assert.equal(p.stdout, ''); assert.match(p.stderr, /OFFLINE_BACKUP_RESTORE_FAILED_CLOSED/); assert.equal(fs.existsSync(dst), false)
}
let sends = 0, forbidden = 0
const receiver = createServer((req, res) => { req.resume(); if (req.url === '/api/sendText') sends++; else forbidden++; fs.appendFileSync(path.join(out, 'compiled-receiver.jsonl'), JSON.stringify({ path: req.url, at: new Date().toISOString() })+'\n'); res.writeHead(201, { 'content-type': 'application/json' }); res.end(JSON.stringify({ id: 'synthetic-'+sends })) })
await new Promise(resolve => receiver.listen(0, '127.0.0.1', resolve))
const url = 'http://127.0.0.1:'+receiver.address().port, root=fs.mkdtempSync(path.join(out, 'tmp/compiled-r38-'))
const env = { ...cliEnv, SHIFT_PROVIDER: 'waha', SHIFT_MEMBERS: '5511900000001=Synthetic*', SHIFT_WEBHOOK_SECRET: 'synthetic-r38-compiled-webhook-secret', SHIFT_DATA_DIR: root, SHIFT_PORT: '0', SHIFT_HOST: '127.0.0.1', WAHA_URL: url, WAHA_API_KEY: 'synthetic', WAHA_SESSION: 'r38', WHISPER_URL: url, LLM_BASE_URL: url, LLM_LOCATION: 'local', LLM_MODEL: 'unapproved-synthetic-NO_MODEL' }
let child
async function start(label) {
 const p = spawn(process.execPath, [path.join(artifact, 'shift-assistant.mjs')], { env, stdio: ['ignore', 'pipe', 'pipe'] }); child=p
 let stdout = '', failure
 p.stdout.on('data', bytes => { stdout += bytes; fs.appendFileSync(path.join(out, label+'.stdout.log'), bytes) })
 p.stderr.on('data', bytes => fs.appendFileSync(path.join(out, label+'.stderr.log'), bytes))
 p.on('error', error => { failure = error })
 const started=Date.now()
 while (Date.now()-started<10000) {
  if (failure) throw failure
  for (const line of stdout.split('\n')) { try { const event=JSON.parse(line); if(event.event==='shift.started') return 'http://127.0.0.1:'+event.port } catch {} }
  assert.equal(p.exitCode, null, 'compiled child exited early')
  await new Promise(resolve => setTimeout(resolve, 10))
 }
 throw new Error('compiled_start_deadline')
}
async function stop() { if(!child || child.exitCode!==null) return; const done=once(child,'exit'); child.kill('SIGTERM'); const timer=setTimeout(()=>child.kill('SIGKILL'),10000); try { const [code,signal]=await done; assert.equal(code,0); assert.equal(signal,null) } finally {clearTimeout(timer); child=undefined} }
try {
 let service=await start('compiled-live')
 assert.equal((await fetch(service+'/health/ready')).status,200)
 const webhook=async id => fetch(service+'/webhooks/waha', {method:'POST',headers:{'content-type':'application/json','x-cvg-webhook-secret':env.SHIFT_WEBHOOK_SECRET},body:JSON.stringify({event:'message',session:'r38',payload:{id,from:'5511900000001@c.us',body:'ajuda'}})})
 assert.equal((await webhook('healthy')).status,200)
 const deadline=Date.now()+5000; while(sends!==1 && Date.now()<deadline) await new Promise(resolve=>setTimeout(resolve,10)); assert.equal(sends,1)
 // Wait for the successful effect's durable result, using public readiness.
 while((await (await fetch(service+'/health/ready')).json()).pendingMessages!==0 && Date.now()<deadline) await new Promise(resolve=>setTimeout(resolve,10))
 await new Promise(resolve=>setTimeout(resolve,30))
 const manifest=JSON.parse(fs.readFileSync(path.join(root,'journal/manifest.json'))), segment=path.join(root,manifest.segments.at(-1).path), original=fs.readFileSync(segment)
 const fd=fs.openSync(segment,'r+'); fs.writeSync(fd,Buffer.from('!'),0,1,0);fs.closeSync(fd);const corrupt=fs.readFileSync(segment)
 const liveReady=await fetch(service+'/health/ready'); assert.equal(liveReady.status,503)
 const ingress=await webhook('after-corrupt'); assert.equal(ingress.status,503)
 await new Promise(resolve=>setTimeout(resolve,50));assert.equal(sends,1);assert.equal(forbidden,0);assert.deepEqual(fs.readFileSync(segment),corrupt)
 await stop(); service=await start('compiled-restart');const ready=await fetch(service+'/health/ready');assert.equal(ready.status,503);assert.equal(sends,1);assert.deepEqual(fs.readFileSync(segment),corrupt);await stop()
 results.push({ kind:'compiled_live_restart',env,root,liveReady:liveReady.status,ingress:ingress.status,restartReady:ready.status,healthySends:1,corruptSends:sends-1,forbiddenRequests:forbidden,beforeSha256:hash(original),corruptSha256:hash(corrupt),afterSha256:hash(fs.readFileSync(segment)),bytesPreserved:true })
 const healthy=path.join(out,'tmp/compiled-cli-healthy'); fs.mkdirSync(healthy)
 const { ShiftStore } = await import(path.join(artifact,'dist/offline-validator.mjs'))
 const store=new ShiftStore(healthy); store.append({type:'paused',at:'2026-10-03T12:00:00.000Z',by:'5511900000001'});store.close()
 for (const [mode,src,dst] of [['backup',healthy,healthy+'-backup'],['restore',healthy+'-backup',healthy+'-restored']]) {
  const args=[cli,mode,src,dst],p=spawnSync(process.execPath,args,{env:cliEnv,encoding:'utf8'});results.push({args:[process.execPath,...args],env:cliEnv,exit:p.status,stdout:p.stdout,stderr:p.stderr});assert.equal(p.status,0)
 }
 const restored=new ShiftStore(healthy+'-restored');try {assert.equal(restored.storageAvailable,true);assert.equal(restored.operationalHold,true);assert.equal(restored.effectsAllowed,false)}finally{restored.close()}
 fs.writeFileSync(path.join(out,'compiled-results.json'),JSON.stringify({node:process.version,artifactFiles:['shift-assistant.mjs','dist/offline-validator.mjs','scripts/backup-restore.mjs'].map(p=>({path:p,sha256:hash(fs.readFileSync(path.join(artifact,p)))})),results},null,2)); console.log(JSON.stringify({status:'PASS',negativeCli:8,healthyCli:2,compiledLiveCorruption:'503/503/zero sends',restart:503,root,loader:'none',nodeModules:'none'}))
} finally { await stop(); receiver.closeAllConnections(); await new Promise(resolve=>receiver.close(resolve)) }
