import os,sys,subprocess,json,time
from pathlib import Path
base=Path(__file__).resolve().parent; candidate=base.parent/'candidate'; name=sys.argv[1]; args=sys.argv[2:]
env={'PATH':'/home/ricardo/.nvm/versions/node/v22.23.2/bin:/usr/bin:/bin','HOME':str(base/'home'),'TMPDIR':str(base/'tmp'),'XDG_CACHE_HOME':str(base/'cache'),'NODE_ENV':'test','CI':'true','NO_COLOR':'1'}
for key in ['HOME','TMPDIR','XDG_CACHE_HOME']:Path(env[key]).mkdir(exist_ok=True)
start=time.time()
with (base/(name+'.stdout.log')).open('w') as stdout,(base/(name+'.stderr.log')).open('w') as stderr:
 result=subprocess.run(args,cwd=candidate,env=env,stdout=stdout,stderr=stderr)
record={'args':args,'cwd':str(candidate),'env':env,'exit':result.returncode,'seconds':time.time()-start}
(base/(name+'.command.json')).write_text(json.dumps(record,indent=2));print(json.dumps(record));sys.exit(result.returncode)
