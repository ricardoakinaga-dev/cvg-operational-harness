import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const out=path.resolve(import.meta.dirname,'..');
const packet=JSON.parse(fs.readFileSync(out+'/../authority/packet.json','utf8'));
assert.equal(process.execPath,packet.node);assert.equal(process.version,'v22.23.2');
const technical=packet.readableSource+'/products/shift-assistant';
const {ShiftStore}=await import(pathToFileURL(technical+'/dist/offline-validator.mjs').href);
const {backupStoppedVolume,restoreBackup}=await import(pathToFileURL(technical+'/scripts/backup-restore.mjs').href);
const root=out+'/data/archive-identity-formal';fs.mkdirSync(root,{mode:0o700});
const raw=out+'/raws/archive-identity';fs.mkdirSync(raw,{mode:0o700});
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
function inventory(p,relative=''){let a=[];for(const name of fs.readdirSync(path.join(p,relative)).sort()){const rel=relative?relative+'/'+name:name;const full=p+'/'+rel;const s=fs.lstatSync(full);if(s.isDirectory())a.push(...inventory(p,rel));else a.push({path:rel,sha256:sha(fs.readFileSync(full)),bytes:s.size,mode:s.mode,ino:s.ino,nlink:s.nlink});}return a;}
function save(name,v){fs.writeFileSync(raw+'/'+name+'.json',JSON.stringify(v,null,2)+'\n',{mode:0o600});}
function corrupt(file){const b=fs.readFileSync(file);b[0]^=1;fs.writeFileSync(file,b);}
const data=root+'/baseline';fs.mkdirSync(data,{mode:0o700});fs.mkdirSync(data+'/media',{mode:0o700});
const bytes=Buffer.from('R58 INDEPENDENT MIGRATION ARCHIVE AUDIO\n');
fs.writeFileSync(data+'/media/own.ogg',bytes,{mode:0o600});
fs.writeFileSync(data+'/media/own.ogg.json',JSON.stringify({messageKey:'R58-own-archive',mime:'audio/ogg',bytes:bytes.length,sha256:sha(bytes),path:'media/own.ogg',stage:'published'})+'\n',{mode:0o600});
const at='2026-02-03T04:05:06.000Z';
fs.writeFileSync(data+'/events.jsonl',JSON.stringify({type:'message_received',at,message:{provider:'waha',messageId:'R58-archive-message',fromPhone:'00000000001',kind:'audio',text:'',mediaRef:'media/own.ogg',mimetype:'audio/ogg',receivedAt:at}})+'\n',{mode:0o600});
const s=new ShiftStore(data,{legacySession:'R58-own-archive-session'});assert(s.storageAvailable);const migration=s.migration;s.close();
const results=[];
function result(id,status,evidence){const r={id,criterion:['S2','S4'],status,evidence};results.push(r);save(id,r);console.log(JSON.stringify(r));}
const baselineIdentity=ShiftStore.validateStoppedVolume(data);
const archivedPath=entry=>data+'/'+migration.backupPath+'/'+entry.path;
for(const item of migration.inventory)assert.equal(sha(fs.readFileSync(archivedPath(item))),item.sha256);
result('D01-valid-archive-positive','PASS',{baselineIdentity,migration,allRecordedArchiveIdentitiesMatch:true});
for(const relative of ['media/own.ogg','events.jsonl']){
  const name=relative==='events.jsonl'?'archived-journal':'archived-media';const volume=root+'/'+name;fs.cpSync(data,volume,{recursive:true});
  const entry=migration.inventory.find(x=>x.path===relative);const target=volume+'/'+migration.backupPath+'/'+relative;corrupt(target);
  const before=inventory(volume);const actual=sha(fs.readFileSync(target));assert.notEqual(actual,entry.sha256);
  let identity,error;try{identity=ShiftStore.validateStoppedVolume(volume);}catch(e){error={name:e.name,code:e.code,message:e.message};}
  assert.deepEqual(inventory(volume),before);const evidence={target:path.relative(out,target),recordedIdentity:entry,actualSha256:actual,primaryMediaSha256:sha(fs.readFileSync(volume+'/media/own.ogg')),primaryJournalSha256:sha(fs.readFileSync(volume+'/events.jsonl')),validatorReadOnly:true,expected:'STORAGE_UNAVAILABLE before success',...(identity?{actual:'accepted',identity}:{actual:'rejected',error})};
  result('D02-'+name+'-validator',identity?'FAIL':'PASS',evidence);
  if(relative==='media/own.ogg'){
    const backup=root+'/backup-corrupt-archive',restored=root+'/restore-corrupt-archive';let backupResult,restoreResult,backupError;
    try{backupResult=backupStoppedVolume(volume,backup);restoreResult=restoreBackup(backup,restored);}catch(e){backupError={name:e.name,message:e.message};}
    assert.deepEqual(inventory(volume),before);
    const restoredSha256=restoreResult?sha(fs.readFileSync(restored+'/'+migration.backupPath+'/'+relative)):undefined;
    result('D03-corrupt-archive-backup-restore',backupResult&&restoreResult?'FAIL':'PASS',{expected:'Reject archived document identity mismatch before backup/restore success',backupResult,restoreResult,backupError,recordedSha256:entry.sha256,sourceSha256:actual,restoredSha256,sourceRetained:true,restoreHeld:!!restoreResult&&fs.existsSync(restored+'/restore-hold.json')});
  }
}
save('results',{node:process.version,tests:results.length,passed:results.filter(x=>x.status==='PASS').length,failed:results.filter(x=>x.status==='FAIL').length,results});
if(results.some(x=>x.status==='FAIL'))process.exitCode=1;
