import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import { spawnSync } from 'node:child_process';
import vm from 'node:vm';
import { EventEmitter } from 'node:events';

const OUT = path.resolve(import.meta.dirname, '..');
const ROOT = path.resolve(OUT, '../authority');
const RAW = OUT + '/raws/attempt-02';
const COMMANDS = OUT + '/commands/attempt-02';
fs.mkdirSync(RAW, {recursive:true});
fs.mkdirSync(COMMANDS, {recursive:true});
const packet = JSON.parse(fs.readFileSync(ROOT + '/packet.json', 'utf8'));
assert.equal(process.execPath, packet.node);
assert.equal(process.version, 'v22.23.2');
const SOURCE = packet.readableSource;
const file = (rel) => path.join(SOURCE, 'products/shift-assistant', rel);
const { ShiftStore } = await import(pathToFileURL(file('dist/offline-validator.mjs')).href);
const { backupStoppedVolume, restoreBackup } = await import(pathToFileURL(file('scripts/backup-restore.mjs')).href);
const hash = (b) => crypto.createHash('sha256').update(b).digest('hex');
const write = (p, b) => { assert(p.startsWith(OUT + '/')); fs.mkdirSync(path.dirname(p), { recursive: true, mode: 0o700 }); fs.writeFileSync(p, b, { mode: 0o600 }); };
const json = (p, value) => write(p, JSON.stringify(value, null, 2) + '\n');
const read = (p) => JSON.parse(fs.readFileSync(p, 'utf8'));
const cases = [];
const at = '2026-01-02T03:04:05.000Z';
const phone = '00000000001';
const localBytes = Buffer.from('R58-I1 OWN LOCAL AUDIO\n');
const inlineBytes = Buffer.from('R58-I1 OWN INLINE AUDIO\n');
const noteBytes = Buffer.from('R58-I1 OWN NOTE AUDIO\n');
function snapshot(root) {
  const result = [];
  function visit(dir, rel = '') {
    for (const name of fs.readdirSync(dir).sort()) {
      const sub = rel ? rel + '/' + name : name;
      const p = path.join(root, sub);
      const s = fs.lstatSync(p, { bigint: true });
      result.push({ path: sub, kind: s.isSymbolicLink() ? 'link' : s.isDirectory() ? 'directory' : 'file', mode: String(s.mode), ino: String(s.ino), nlink: String(s.nlink), uid: String(s.uid), size: String(s.size), mtimeNs: String(s.mtimeNs), ctimeNs: String(s.ctimeNs), ...(s.isFile() ? { sha256: hash(fs.readFileSync(p)) } : s.isSymbolicLink() ? { target: fs.readlinkSync(p) } : {}) });
      if (s.isDirectory()) visit(p, sub);
    }
  }
  visit(root);
  return result;
}
const bytesOnly = (s) => s.filter(x => x.kind !== 'directory').map(({path, kind, sha256, target}) => ({path, kind, sha256, ...(target ? {target} : {})}));
let count = 0;
function area(name) { const p = path.join(OUT, 'data', 'attempt-02', String(++count).padStart(3, '0') + '-' + name); fs.mkdirSync(p, {recursive: true, mode: 0o700}); return p; }
function legacy(root) {
  fs.mkdirSync(path.join(root, 'media'), { mode: 0o700 });
  write(root + '/media/published.ogg', localBytes);
  json(root + '/media/published.ogg.json', { messageKey: 'R58-published-own', mime: 'audio/ogg', bytes: localBytes.length, sha256: hash(localBytes), path: 'media/published.ogg', stage: 'published' });
  write(root + '/media/note-old.ogg', noteBytes);
  const message = (id, ref) => ({type: 'message_received', at, message: {provider: 'waha', messageId: id, fromPhone: phone, kind: 'audio', text: '', mediaRef: ref, mimetype: 'audio/ogg', receivedAt: at}});
  const events = [message('own-local', 'media/published.ogg'), message('own-inline', 'base64:' + inlineBytes.toString('base64')), {type: 'note_created', at, note: {id: 'own-note', messageId: 'own-local', authorPhone: phone, createdAt: at, kind: 'audio', rawText: 'ONLY SYNTHETIC REVIEW DATA', mediaFile: 'note-old.ogg', unverifiedNumbers: [], confirmed: false}}, {type:'message_processed', at, messageId:'own-local'}];
  write(root + '/events.jsonl', events.map(e => JSON.stringify(e)).join('\n') + '\n');
  return events;
}
function migrate(root) { const store = new ShiftStore(root, { legacySession: 'R58-own-session' }); assert.equal(store.storageAvailable, true, store.diagnostic); return store; }
function clone(base, name) { const p = area(name); fs.cpSync(base, p, {recursive:true}); return p; }
function corrupt(p) { const b = fs.readFileSync(p); assert(b.length); b[0] ^= 1; write(p, b); }
async function test(id, criterion, fn) {
  const result = {id, criterion, startedAt: new Date().toISOString()};
  try { result.evidence = await fn(); result.status = 'PASS'; }
  catch (error) { result.status = 'FAIL'; result.error = {name:error.name, message:error.message, stack:error.stack}; }
  result.finishedAt = new Date().toISOString();
  cases.push(result); json(path.join(RAW, id + '.json'), result); console.log(JSON.stringify(result));
}
function rejectOffline(root) {
  const before = snapshot(root); let error;
  try { ShiftStore.validateStoppedVolume(root); } catch (e) { error = e; }
  assert(error, 'invalid volume was accepted');
  assert.equal(error.code, 'STORAGE_UNAVAILABLE');
  assert.deepEqual(snapshot(root), before, 'offline validator mutated invalid evidence');
  return {error:error.code, sourceUnchanged:true, before};
}
const baseline = area('legacy-baseline'); legacy(baseline);
let mapping;
await test('C01-first-migration-projection', ['S1','S2','S4'], () => {
  const original = fs.readFileSync(baseline + '/events.jsonl');
  const s = migrate(baseline); mapping = s.migration;
  assert.equal(s.operationalHold, true); assert.equal(s.effectsAllowed, false);
  assert.equal(s.hasMessage('own-local'), true); assert.equal(s.hasMessage('own-inline'), true);
  assert.equal(s.unprocessedMessages().length, 0);
  assert.deepEqual(Buffer.from(s.readMedia('media/published.ogg').bytes), localBytes);
  const inline = mapping.mediaMappings.find(m => m.legacyPath.startsWith('inbound-'));
  assert(inline); assert.deepEqual(Buffer.from(s.readMedia(inline.path).bytes), inlineBytes);
  const note = s.note('own-note'); assert(note); assert.notEqual(note.mediaFile, 'note-old.ogg');
  assert.deepEqual(Buffer.from(s.readMedia('media/' + note.mediaFile).bytes), noteBytes);
  assert.deepEqual(fs.readFileSync(baseline + '/events.jsonl'), original);
  const evidence = {mapping, note, originalJournalSha256:hash(original), sequence:s.sequence, hold:s.operationalHold};
  s.close(); return evidence;
});
await test('C02-reopen-projection-readonly-validation', ['S1','S2','S4'], () => {
  const s = migrate(baseline); assert.equal(s.note('own-note').mediaFile, mapping.mediaMappings.find(m=>m.legacyPath==='media/note-old.ogg').path.slice(6)); s.close();
  const before = snapshot(baseline); const identity = ShiftStore.validateStoppedVolume(baseline);
  assert.equal(identity.sequence, 1); assert.deepEqual(snapshot(baseline), before); return {identity, noChmodNoContentWrites:true};
});
await test('C03-corrupt-local-before-first-migration', ['S1','S4'], () => {
  const p = area('corrupt-local-initial'); legacy(p); corrupt(p + '/media/published.ogg');
  const originals = bytesOnly(snapshot(p)); const s = new ShiftStore(p, {legacySession:'R58-own-session'});
  assert.equal(s.storageAvailable, false); assert.equal(s.effectsAllowed, false);
  const after = bytesOnly(snapshot(p)); for (const before of originals) assert.deepEqual(after.find(x=>x.path===before.path), before);
  const diagnostic = s.diagnostic; s.close(); return {diagnostic, existingEvidencePreserved:true};
});
const inlinePath = mapping?.mediaMappings.find(m=>m.legacyPath.startsWith('inbound-'))?.path;
const notePath = mapping?.mediaMappings.find(m=>m.legacyPath==='media/note-old.ogg')?.path;
for (const [label, rel] of [['local-primary','media/published.ogg'], ['inline-primary',inlinePath], ['note-primary',notePath]]) {
  await test('C04-offline-corrupt-' + label, ['S2','S4'], () => {
    assert(rel); const p = clone(baseline, label); const recoveryBefore = bytesOnly(snapshot(p + '/recovery')); corrupt(path.join(p,rel));
    const rejection = rejectOffline(p); assert.deepEqual(bytesOnly(snapshot(p+'/recovery')), recoveryBefore);
    return {...rejection, recoveryCopiesUnchanged:true, target:rel};
  });
}
for (const [label, rel] of [['local','media/published.ogg'], ['sidecar','media/published.ogg.json'], ['inline',inlinePath], ['note',notePath], ['legacy','events.jsonl'], ['manifest','journal/manifest.json']]) {
  await test('C05-live-corruption-' + label, ['S1','S4'], () => {
    const p = clone(baseline, 'live-'+label); const s = migrate(p); const target = path.join(p,rel); const prior = fs.statSync(target); corrupt(target); fs.utimesSync(target, prior.atime, prior.mtime);
    const before = bytesOnly(snapshot(p)); assert.equal(s.storageAvailable, false); assert.equal(s.effectsAllowed, false);
    assert.throws(()=>s.append({type:'paused',at,by:phone}), {code:'STORAGE_UNAVAILABLE'});
    assert.deepEqual(bytesOnly(snapshot(p)), before); const diagnostic=s.diagnostic; s.close(); return {target:rel, diagnostic, restoredMtimeDoesNotBypassGuard:true, appendBlocked:true, noEvidenceMutation:true};
  });
}
for (const [label, mutate] of [
  ['manifest-divergence', p=>{const m=read(p+'/journal/manifest.json');m.journalId=crypto.randomUUID();json(p+'/journal/manifest.json',m);}],
  ['journal-full-line', p=>{const m=read(p+'/journal/manifest.json');corrupt(p+'/'+m.segments.at(-1).path);}],
  ['sidecar-path-traversal', p=>{const f=p+'/media/published.ogg.json';const d=read(f);d.path='../outside';json(f,d);}],
  ['sidecar-invalid', p=>write(p+'/media/published.ogg.json','{"bytes":1}\n')],
  ['mapped-note-deleted', p=>fs.unlinkSync(p+'/'+notePath)],
  ['mapped-inline-deleted', p=>fs.unlinkSync(p+'/'+inlinePath)]
]) await test('C06-offline-' + label,['S2','S3','S4'],()=>{const p=clone(baseline,label);mutate(p);return rejectOffline(p);});

const backup = area('valid-backup');
await test('C07-backup-identity-originals', ['S2','S4'], () => {
  const before = snapshot(baseline); const result = backupStoppedVolume(baseline, backup);
  assert.equal(result.status,'backup_verified'); assert.deepEqual(snapshot(baseline),before);
  const manifest=read(backup+'/manifest.json'); assert.deepEqual(manifest.journal,ShiftStore.validateStoppedVolume(baseline));
  for(const entry of manifest.documents) assert.equal(hash(fs.readFileSync(backup+'/documents/'+entry.path)),entry.sha256);
  return {result,identity:manifest.journal,sourceIdentitiesRetained:true};
});
const restored = area('valid-restore');
await test('C08-restore-hold-identity', ['S1','S2','S4'], () => {
  const before=snapshot(backup); const result=restoreBackup(backup,restored); assert.equal(result.status,'restored_under_hold');
  assert.deepEqual(snapshot(backup),before); assert.equal(fs.existsSync(restored+'/store.lock'),false);
  assert(fs.existsSync(restored+'/restore-hold.json')); assert.deepEqual(ShiftStore.validateStoppedVolume(restored),read(backup+'/manifest.json').journal);
  const s=migrate(restored);assert.equal(s.operationalHold,true);assert.equal(s.effectsAllowed,false);assert.deepEqual(Buffer.from(s.readMedia('media/published.ogg').bytes),localBytes);s.close();return {result,restoreHold:read(restored+'/restore-hold.json'),sourceUnchanged:true};
});
for(const [label,mutate] of [
  ['traversal',m=>{m.documents[0].path='../outside';}],
  ['absolute',m=>{m.documents[0].path='/outside';}],
  ['backslash',m=>{m.documents[0].path='media\\outside';}],
  ['duplicate',m=>{m.documents.push(m.documents[0]);}],
  ['lock-entry',m=>{m.documents[0].path='store.lock';}],
  ['secret-name',m=>{m.documents[0].path='synthetic.key';}],
  ['wrong-size',m=>{m.documents[0].bytes++;}],
  ['wrong-sha',m=>{m.documents[0].sha256='0'.repeat(64);}],
  ['wrong-journal-identity',m=>{m.journal.headSha256='0'.repeat(64);}],
]) await test('C09-restore-manifest-'+label,['S2','S3','S4'],()=>{
  const p=clone(backup,'backup-'+label);const m=read(p+'/manifest.json');mutate(m);json(p+'/manifest.json',m);
  const dest=area('reject-dest-'+label);const before=snapshot(p);assert.throws(()=>restoreBackup(p,dest));assert.deepEqual(snapshot(p),before);assert.deepEqual(fs.readdirSync(dest),[]);
  return {rejectedBeforeDestinationWrites:true,sourceUnchanged:true};
});
await test('C10-recomputed-manifest-corrupt-primary', ['S2','S4'], ()=>{
  const p=clone(backup,'honest-hash-invalid-journal');corrupt(p+'/documents/media/published.ogg');const m=read(p+'/manifest.json');const e=m.documents.find(x=>x.path==='media/published.ogg');e.sha256=hash(fs.readFileSync(p+'/documents/media/published.ogg'));json(p+'/manifest.json',m);
  const dest=area('recomputed-dest');assert.throws(()=>restoreBackup(p,dest));assert.deepEqual(fs.readdirSync(dest),[]);return {validManifestFileHashesDoNotBypassRuntimeReplay:true};
});
await test('C11-fresh-destination-no-overwrite', ['S2','S3','S4'],()=>{
  const dest=area('nonempty');write(dest+'/keep.txt','R58-I1 ORIGINAL');const before=snapshot(dest);
  assert.throws(()=>backupStoppedVolume(baseline,dest));assert.deepEqual(snapshot(dest),before);
  assert.throws(()=>restoreBackup(backup,dest));assert.deepEqual(snapshot(dest),before);
  assert.throws(()=>backupStoppedVolume(baseline,baseline+'/nested'));assert.equal(fs.existsSync(baseline+'/nested'),false);
  return {backupAndRestoreRefuseOverwrite:true,insideSourceRefused:true};
});
for(const kind of ['symlink','hardlink']) await test('C12-no-'+kind,['S2','S3','S4'],()=>{
  const p=clone(baseline,'links-'+kind);const sentinel=path.join(area('sentinel-'+kind),'outside.txt');write(sentinel,'R58-I1 LINK TARGET');const before=fs.statSync(sentinel);const name=p+'/media/link.ogg';if(kind==='symlink')fs.symlinkSync(sentinel,name);else fs.linkSync(sentinel,name);
  const linkBefore=snapshot(p);rejectOffline(p);const dest=area('link-dest-'+kind);assert.throws(()=>backupStoppedVolume(p,dest));assert.deepEqual(snapshot(p),linkBefore);assert.deepEqual(fs.readdirSync(dest),[]);assert.equal(fs.readFileSync(sentinel,'utf8'),'R58-I1 LINK TARGET');assert.equal(fs.statSync(sentinel).mode,before.mode);
  const q=clone(backup,'restore-link-'+kind);fs.unlinkSync(q+'/documents/media/published.ogg');if(kind==='symlink')fs.symlinkSync(sentinel,q+'/documents/media/published.ogg');else fs.linkSync(sentinel,q+'/documents/media/published.ogg');assert.throws(()=>restoreBackup(q,dest));assert.deepEqual(fs.readdirSync(dest),[]);
  return {offlineBackupRestoreRefused:true,sentinelBytesAndModeRetained:true};
});
await test('C13-preexisting-lock-preserved',['S2','S3','S4'],()=>{
  const p=clone(baseline,'foreign-lock');write(p+'/store.lock','R58-I1 PREEXISTING SYNTHETIC OWNER');const before=snapshot(p);const dest=area('locked-dest');assert.throws(()=>backupStoppedVolume(p,dest));assert.deepEqual(snapshot(p),before);assert.deepEqual(fs.readdirSync(dest),[]);return {foreignLockNotRemoved:true};
});
const recovered=clone(baseline,'tail-recovery');let recovery;
await test('C14-unrecovered-tail-readonly',['S2','S4'],()=>{
  const m=read(recovered+'/journal/manifest.json');fs.appendFileSync(recovered+'/'+m.segments.at(-1).path,'{"ownR58Incomplete":');return rejectOffline(recovered);
});
await test('C15-runtime-recovery-and-roundtrip',['S1','S2','S4'],()=>{
  const m=read(recovered+'/journal/manifest.json');const original=recovered+'/'+m.segments.at(-1).path;const b=fs.readFileSync(original);
  const s=migrate(recovered);assert.equal(s.operationalHold,true);assert.equal(s.effectsAllowed,false);assert.deepEqual(fs.readFileSync(original),b);s.close();
  const next=read(recovered+'/journal/manifest.json');recovery=next.pendingRecovery;assert(recovery);assert.deepEqual(fs.readFileSync(recovered+'/'+recovery.copyPath),b);assert.equal(fs.readFileSync(recovered+'/'+recovery.tailPath,'utf8'),'{"ownR58Incomplete":');
  const identity=ShiftStore.validateStoppedVolume(recovered);const dest=area('recovery-backup');backupStoppedVolume(recovered,dest);const r=area('recovery-restore');restoreBackup(dest,r);assert.deepEqual(ShiftStore.validateStoppedVolume(r),identity);assert(fs.existsSync(r+'/restore-hold.json'));return {recovery,identity,originalAndCopiesPreserved:true,roundtripUnderHold:true};
});
for(const [label,key] of [['copy','copyPath'],['tail','tailPath']]) await test('C16-tampered-recovery-'+label,['S2','S4'],()=>{assert(recovery);const p=clone(recovered,'recovery-tamper-'+label);corrupt(p+'/'+recovery[key]);return rejectOffline(p);});

// Exact unmodified public bundle in a VM: native builtins, in-memory HTTP adapter,
// native application configuration loader, synthetic settings only. No sockets,
// actual environment, credentials, provider calls, or descendants are used.
async function publicCli(dataDir) {
  const logs=[], exits=[], handlers=new Map(), timers=new Set();let serverHandler;let networkCalls=0;
  const settings={SHIFT_PROVIDER:'waha',SHIFT_MEMBERS:phone+'=R58Synthetic*',SHIFT_WEBHOOK_SECRET:'R58_SYNTHETIC_AUTH_ONLY_000000',SHIFT_DATA_DIR:dataDir,SHIFT_HOST:'127.0.0.1',SHIFT_PORT:'0',WAHA_URL:'http://127.0.0.1:1',WAHA_API_KEY:'SYNTHETIC_NO_CREDENTIAL',WAHA_SESSION:'R58-own-session',WHISPER_URL:'http://127.0.0.1:1',LLM_BASE_URL:'http://127.0.0.1:1',LLM_LOCATION:'local',LLM_MODEL:'R58-own-placeholder'};
  const setTimer=(fn,ms)=>{const x={fn,ms};timers.add(x);return x;};
  const context=vm.createContext({Buffer,URL,URLSearchParams,TextDecoder,TextEncoder,AbortController,AbortSignal,Response,Request,Headers,FormData,Blob,structuredClone,console:{log:x=>logs.push({level:'info',value:x}),error:x=>logs.push({level:'error',value:x})},process:{env:settings,argv:[packet.node,file('dist/shift-assistant.mjs')],execPath:packet.node,pid:process.pid,version:process.version,getuid:()=>process.getuid(),once:(event,handler)=>handlers.set(event,handler),exit:n=>exits.push(n)},setTimeout:setTimer,setInterval:setTimer,clearTimeout:x=>timers.delete(x),clearInterval:x=>timers.delete(x),fetch:async()=>{networkCalls++;throw new Error('R58_NETWORK_FORBIDDEN');}});
  const fakeServer=Object.assign(new EventEmitter(),{listen:(_port,_host,cb)=>cb(),address:()=>({port:0}),close:cb=>cb(),closeIdleConnections:()=>{},closeAllConnections:()=>{}});
  const nativeModules=new Map();
  const module=new vm.SourceTextModule(fs.readFileSync(file('dist/shift-assistant.mjs'),'utf8'),{context,identifier:pathToFileURL(file('dist/shift-assistant.mjs')).href,initializeImportMeta:meta=>{meta.url=pathToFileURL(file('dist/shift-assistant.mjs')).href;},importModuleDynamically:()=>{throw new Error('R58_DYNAMIC_IMPORT_FORBIDDEN');}});
  await module.link(async spec=>{
    assert(['node:fs','node:path','node:crypto','node:http','node:module'].includes(spec),'unapproved import '+spec);
    if(nativeModules.has(spec))return nativeModules.get(spec);
    let values=await import(spec);
    if(spec==='node:http')values={createServer:(_opts,fn)=>{serverHandler=fn;return fakeServer;}};
    if(spec==='node:module')values={createRequire:()=>()=>{throw new Error('R58_REQUIRE_FORBIDDEN');}};
    const names=Object.keys(values);const wrapped=new vm.SyntheticModule(names,function(){for(const k of names)this.setExport(k,values[k]);},{context});nativeModules.set(spec,wrapped);return wrapped;
  });
  await module.evaluate();for(let i=0;i<10;i++)await new Promise(resolve=>setImmediate(resolve));
  assert(logs.some(x=>x.value.includes('shift.started')), 'Public CLI did not finish native start: '+JSON.stringify(logs));
  assert.deepEqual(exits,[], 'Public CLI exited during startup');
  async function request(method,url,payload){
    assert(serverHandler,'CLI failed before HTTP construction: '+JSON.stringify(logs));
    const req=new EventEmitter();Object.assign(req,{method,url,headers:{'x-cvg-webhook-secret':settings.SHIFT_WEBHOOK_SECRET,'content-type':'application/json'},resume:()=>{},pause:()=>{},socket:{end:()=>{}}});
    let status;const headers={};return await new Promise((resolve,reject)=>{
      const res=new EventEmitter();Object.assign(res,{headersSent:false,setHeader:(k,v)=>{headers[k]=v;},writeHead:s=>{status=s;res.headersSent=true;},end:body=>resolve({status,body:JSON.parse(body),headers})});
      try{serverHandler(req,res);if(payload!==undefined){req.emit('data',Buffer.from(JSON.stringify(payload)));req.emit('end');}}catch(e){reject(e);}
    });
  }
  return {logs,exits,request,networkCalls:()=>networkCalls,stop:async()=>{assert(handlers.has('SIGTERM'));handlers.get('SIGTERM')();for(let i=0;i<10;i++)await new Promise(resolve=>setImmediate(resolve));assert.deepEqual(exits,[0]);}};
}
const inbound={event:'message',session:'R58-own-session',payload:{id:'R58-own-webhook',from:phone+'@c.us',body:'SYNTHETIC OFFLINE',fromMe:false}};
await test('C17-public-cli-live-readiness-ingress',['S1','S4'],async()=>{
  const p=area('public-clean');const s=new ShiftStore(p);const d=s.saveMediaDescriptor(localBytes,'audio/ogg','R58-own-active');s.append({type:'message_received',at,message:{provider:'waha',messageId:'R58-primary',fromPhone:phone,kind:'audio',text:'',mediaRef:d.path,mimetype:'audio/ogg',receivedAt:at}});s.close();
  const cli=await publicCli(p);try{
    const ready=await cli.request('GET','/health/ready');assert.equal(ready.status,200,JSON.stringify(ready));
    corrupt(p+'/'+d.path);const evidence=bytesOnly(snapshot(p));
    const failed=await cli.request('GET','/health/ready');assert.equal(failed.status,503);assert(failed.body.reasonCodes.includes('storage_unavailable'));
    const ingress=await cli.request('POST','/webhooks/waha',inbound);assert.equal(ingress.status,503);assert.equal(ingress.body.error,'storage_unavailable');
    assert.deepEqual(bytesOnly(snapshot(p)),evidence);assert.equal(cli.networkCalls(),0);assert(!JSON.stringify(cli.logs).includes('SYNTHETIC_NO_CREDENTIAL'));
    return {ready,failed,ingress,networkCalls:0,logs:cli.logs,publicBytesUnmodified:true,inMemoryHttpAdapter:true};
  }finally{await cli.stop();}
});
await test('C18-public-cli-corrupt-legacy-and-restored-hold',['S1','S4'],async()=>{
  const p=clone(baseline,'public-corrupt-legacy');corrupt(p+'/media/published.ogg');const before=bytesOnly(snapshot(p));const cli=await publicCli(p);let bad;
  try{bad=await cli.request('GET','/health/ready');assert.equal(bad.status,503);assert(bad.body.reasonCodes.includes('storage_unavailable'));const ingress=await cli.request('POST','/webhooks/waha',inbound);assert.equal(ingress.status,503);assert.equal(cli.networkCalls(),0);}finally{await cli.stop();}
  assert.deepEqual(bytesOnly(snapshot(p)),before);
  const r=clone(restored,'public-restored-hold');const hold=await publicCli(r);let held;
  try{held=await hold.request('GET','/health/ready');assert.equal(held.status,503);assert(held.body.reasonCodes.includes('operational_hold'));assert(!held.body.reasonCodes.includes('storage_unavailable'));assert.equal(hold.networkCalls(),0);}finally{await hold.stop();}
  return {corruptLegacy:bad,restoredHold:held,networkCalls:0,existingEvidencePreserved:true};
});
await test('C19-native-public-cli-invalid-config',['S3','S4'],()=>{
  const command={executable:packet.node,args:[file('dist/shift-assistant.mjs')],cwd:OUT,syntheticEmptyEnvironment:true};json(COMMANDS+'/public-cli.json',command);
  const r=spawnSync(packet.node,command.args,{cwd:OUT,env:{},encoding:'utf8',timeout:10000});write(RAW+'/native-public.stdout',r.stdout||'');write(RAW+'/native-public.stderr',r.stderr||'');assert.equal(r.status,1);assert.match(r.stderr,/shift.start.failed/);assert(!r.stderr.includes('SYNTHETIC_NO_CREDENTIAL'));return {exit:r.status,signal:r.signal,configurationRejectedBeforeRuntime:true};
});
await test('C20-native-backup-restore-cli',['S2','S4'],()=>{
  const dest=area('native-cli-backup'),restore=area('native-cli-restore');const commands=[];
  for(const [mode,src,dst] of [['backup',baseline,dest],['restore',dest,restore]]){
    const args=[file('scripts/backup-restore.mjs'),mode,src,dst];commands.push({executable:packet.node,args,cwd:OUT,syntheticEmptyEnvironment:true});const r=spawnSync(packet.node,args,{cwd:OUT,env:{},encoding:'utf8',timeout:10000});write(RAW+'/native-'+mode+'.stdout',r.stdout||'');write(RAW+'/native-'+mode+'.stderr',r.stderr||'');assert.equal(r.status,0,r.stderr);assert.equal(JSON.parse(r.stdout).status,mode==='backup'?'backup_verified':'restored_under_hold');
  }
  json(COMMANDS+'/backup-restore-cli.json',commands);assert.deepEqual(ShiftStore.validateStoppedVolume(restore),ShiftStore.validateStoppedVolume(baseline));return {exactScriptAndCompiledValidator:true,restoreHold:read(restore+'/restore-hold.json')};
});
json(RAW+'/results.json',{node:process.version,tests:cases.length,passed:cases.filter(c=>c.status==='PASS').length,failed:cases.filter(c=>c.status==='FAIL').length,cases});
if(cases.some(c=>c.status==='FAIL'))process.exitCode=1;
