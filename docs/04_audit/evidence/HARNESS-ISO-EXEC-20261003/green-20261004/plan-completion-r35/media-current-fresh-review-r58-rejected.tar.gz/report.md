# R58 — revisão independente I1

**REJECT — escopo local; nenhum release.** Node exato: v22.23.2. Dos 46 controles válidos próprios, 43 passaram e 3 reproduziram a mesma falha de S2. Os 20 arquivos/binários permitidos em authority/source mantiveram bytes e hashes idênticos antes/depois. Nenhum source/tool/root foi alterado.

## Achado I1-F01 — identidade do backup retido da migração não validada

A migração registra sha256 e tamanho dos originais em migration.inventory e guarda cópias em migration.backupPath. Depois de uma migração íntegra, alterar um único byte de recovery/backup-*/media/own.ogg ou recovery/backup-*/events.jsonl deixa os documentos em desacordo com essa identidade registrada. Os arquivos primários e a cadeia do journal permanecem intactos.

ShiftStore.validateStoppedVolume aceita ambos os volumes. backupStoppedVolume emite backup_verified para o volume com mídia arquivada corrompida, e restoreBackup emite restored_under_hold, mantendo os mesmos bytes corrompidos e a identidade histórica incompatível. O hold impede efeitos, mas não transforma a validação em rejeição de evidência inválida. Isso viola S2 na exigência de rejeitar journal/mídia inválidos antes de sucesso e reter identidades de origem para recovery/backup/restore.

No controle D02-archived-media-validator, a mídia arquivada tinha hash registrado e1a972ca1ec9f530bcd1bdf71c8d1d5dd84712d9d2f765385c33a64444cd79bf; após mutação, o hash foi 794dbf8ad56a3556df3911f45843303f28b291ea8b98ba6870b27e28296814eb. O hash primário continuou sendo o registrado. D03 comprova que o restore materializou o segundo hash. O journal arquivado também recebeu uma mutação independente e foi aceito.

Evidência: raws/archive-identity/D02-archived-media-validator.json; raws/archive-identity/D02-archived-journal-validator.json; raws/archive-identity/D03-corrupt-archive-backup-restore.json. Reprodução: executar o Node do pacote em controls/review.mjs com --experimental-vm-modules e, em outputs novos equivalentes, controls/archive-identity.mjs. Esses scripts criam exclusivamente fixtures sintéticas próprias. Não se deve executar novamente sobre o output congelado.

Causa técnica observada nos inputs autorizados: migrate-journal.ts:50–92 cria inventory e backup; store.ts:124–162 executa replay, verifyLegacyMedia e armIntegrity; store.ts:489–496 apenas compara migration_applied com a migração do manifest; store.ts:517–525 verifica referências de mídia primária e mappings. Não há validação dos arquivos retidos da migração contra migration.inventory nesse caminho. backup-restore.mjs:10–11 delega a identidade semântica ao validador; :104–123 e :186–189 validam documentos pelo snapshot atual, que pode incorporar o arquivo já danificado. Os intervalos indicam trechos de código lidos, sem seguir nenhuma referência histórica.

Correção sugerida para o builder: validar cada documento do backup retido da migração contra os caminhos físicos, tamanho e hash já registrados em migration.inventory, sem rewrite/recovery automático no modo offline. Rejeitar inconsistências antes de emitir backup_verified/restored_under_hold, incluindo arquivo arquivado ausente ou invalidado. Não atribuo introdução temporal ao delta: nenhuma versão anterior foi consultada. A falha é observada no candidato corrente e impede aceitar S2 como escrito.

## S1–S4

| Critério | Resultado | Evidência e limite |
|---|---|---|
| S1 | PASS_LOCAL | Corrupção inicial/live de mídia local, inline, nota, sidecar, legacy journal e manifest bloqueia storage/effects/append. Bundle público íntegro inicia; readiness passa de 200 para 503 após corrupção; ingress retorna 503; bytes corrompidos preservados. Não prova exclusão de writer hostil concorrente. |
| S2 | FAIL | O caminho primário e recovery NONDELIMITED_TAIL passam nos controles negativos/roundtrip, mas o backup retido da migração aceita journal/mídia incompatíveis com sua identidade registrada. |
| S3 | PARTIAL | Traversal, caminhos absolutos/backslash, links, duplicatas, lock alheio, destino ocupado e nome de segredo sintético são recusados nos controles. Scripts permitidos inspecionados; scans e closure completa indisponíveis são NOT_RUN, sem PASS presumido. |
| S4 | PASS_LOCAL | Dois bundles reais nos hashes do pacote; testes próprios de Node; CLI backup/restore nativo; CLI público nativo com configuração vazia falha fechado; bundle público sem alteração executado com HTTP em memória, loader de configuração nativo e settings sintéticos. Source sentinel antes/depois e manifesto final por hash. |

## Controles e restrições

Os 42 controles da rodada válida cobrem migração e projeção local/inline/nota, mídia corrompida com recovery preservado, validação sem mudança de hash/mode/inode/nlink/mtime/ctime dos documentos, guarda live mesmo com mtime restaurado, corrupção de journal/manifest/sidecar, mappings ausentes, backup/restauração com identidade e hold, traversal/links/overwrite, ownership do lock, rejeição de tail incompleto em modo offline, recovery runtime preservando original/copy/tail, corrupção de recovery copy/tail, readiness e ingress do bundle público. Quatro controles adicionais validam o baseline do archive e reproduzem I1-F01.

A primeira rodada teve um defeito no meu adaptador HTTP: faltava EventEmitter.on. Suas evidências e código estão preservados, mas C17/C18 daquela rodada são CONTROL_INVALID e não sustentam o parecer. A segunda rodada usa o adaptador corrigido e assertions adicionais exigindo startup nativo completo, ausência de exit no startup e shutdown com exit 0; nenhuma assertion do candidato foi enfraquecida.

Não foram acessados governança, README, histórico, builders/revisões, Rootwalker, env real, chave real ou providers reais. Os identificadores, áudio e tokens são placeholders sintéticos. Não houve rede/socket, Docker, PostgreSQL, fullsuite/certify nem testes descendentes. As chamadas nativas ao Node são comandos locais limitados do CLI pedido. Nenhum node_modules foi carregado/escrito; caches/temps disponíveis apenas no output. Vitest não foi usado; configLoader de Vite não se aplica ao runner Node direto, e o loader real da aplicação permaneceu nativo. Não se recompilou o produto porque isso demandaria leitura/escrita fora da allowlist.

NOT_RUN: scanners SAST/SCA, SBOM/licenses, rebuild/closure completa, certificação física completa, Rootwalker, Docker/PG/network/providers. A certificação física do candidato original pertence ao lead; meu sentinel compara exclusivamente a cópia técnica authority/source autorizada. Hashes congelados não constituem defesa contra um writer hostil futuro.

Artefatos: verdict.json; raws/attempt-02/results.json; raws/archive-identity/results.json; commands/executions.json; sentinels/before.json e after.json; manifests/output-manifest.json e seu checksum; FREEZE.json. O manifesto inclui os inputs técnicos por identidade e cada arquivo/link do output; os links sintéticos são inventariados sem dereference. Sem alteração de governança/claim neste papel readonly.
