import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath,pathToFileURL } from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const packet=JSON.parse(fs.readFileSync(path.resolve(here,'../../authority/packet.json')));
const base=packet.source,cli=path.join(base,'products/shift-assistant/scripts/backup-restore.mjs'),loader=path.join(base,'node_modules/tsx/dist/loader.mjs');
const {ShiftStore}=await import(pathToFileURL(path.join(base,'products/shift-assistant/dist/offline-validator.mjs')));
const {backupStoppedVolume,restoreBackup}=await import(pathToFileURL(cli));
const hash=v=>createHash('sha256').update(v).digest('hex');
const canon=v=>v===null||typeof v!=='object'?JSON.stringify(v):Array.isArray(v)?'['+v.map(canon).join(',')+']':'{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+canon(v[k])).join(',')+'}';
const write=(name,v)=>fs.writeFileSync(path.join(here,name),JSON.stringify(v,null,2)+'\n',{mode:0o600});
const env={PATH:path.dirname(process.execPath),NODE_OPTIONS:'',TSX_DISABLE_CACHE:'1',TMPDIR:path.join(here,'tmp'),XDG_CACHE_HOME:path.join(here,'cache')};
const commands=[],checks=[],details=[];
const inputBefore=packet.allowedInputs.map(i=>({path:i.path,sha256:hash(fs.readFileSync(path.join(base,i.path)))}));
function tree(root,rel='') {
  if(!fs.existsSync(root))return null;
  const out=[];
  for(const n of fs.readdirSync(path.join(root,rel))) {
    const p=rel?rel+'/'+n:n,file=path.join(root,p),s=fs.lstatSync(file);
    if(s.isSymbolicLink())out.push({path:p,link:fs.readlinkSync(file)});
    else if(s.isDirectory())out.push(...tree(root,p));
    else out.push({path:p,bytes:s.size,sha256:hash(fs.readFileSync(file)),mode:s.mode&0o777});
  }
  return out.sort((a,b)=>a.path.localeCompare(b.path,'en'));
}
function eq(a,b){return JSON.stringify(a)===JSON.stringify(b);}
function check(id,ok){checks.push({id,status:ok?'PASS':'FAIL'});}
function cp(src,name){const dst=path.join(here,'volumes','supp-'+name);fs.cpSync(src,dst,{recursive:true,dereference:false});return dst;}
function exec(label,args){const r=spawnSync(process.execPath,args,{encoding:'utf8',env,cwd:here,timeout:15000,maxBuffer:8*1024*1024});const id='supp-'+String(commands.length+1).padStart(3,'0')+'-'+label;fs.writeFileSync(path.join(here,'raw',id+'.stdout'),r.stdout??'',{mode:0o600});fs.writeFileSync(path.join(here,'raw',id+'.stderr'),r.stderr??'',{mode:0o600});commands.push({id,command:[process.execPath,...args],env,cwd:here,exit:r.status,signal:r.signal,error:r.error?.message??null,stdout:'raw/'+id+'.stdout',stderr:'raw/'+id+'.stderr',completedAt:new Date().toISOString()});return {id,exit:r.status,stdout:r.stdout??'',stderr:r.stderr??''};}
function externalIdentity(root) {
  const m=JSON.parse(fs.readFileSync(path.join(root,'journal/manifest.json')));
  let sequence=0,headSha256=m.legacy?.prefixSha256??hash('');
  const prefixes=[];
  for(const s of m.segments){const all=fs.readFileSync(path.join(root,s.path)),bytes=s.sealed?s.bytes:all.length;const txs=all.subarray(0,bytes).toString().trim().split('\n').filter(Boolean).map(x=>JSON.parse(x));for(const tx of txs){sequence=tx.seq;headSha256=tx.sha256;}prefixes.push({path:s.path,bytes,sha256:hash(all.subarray(0,bytes))});}
  return {journalId:m.journalId,manifestRevision:m.revision,sequence,headSha256,prefixes};
}
function semanticRestore(id,root,identityMode='recompute') {
  const wrapper=path.join(here,'volumes','supp-backup-'+id);fs.mkdirSync(wrapper,{mode:0o700});fs.cpSync(root,path.join(wrapper,'documents'),{recursive:true,dereference:false});
  const m=JSON.parse(fs.readFileSync(path.join(here,'volumes/minimal-backup/manifest.json')));
  m.documents=tree(path.join(wrapper,'documents')).map(({path,bytes,sha256})=>({path,bytes,sha256}));
  if(identityMode==='recompute')m.journal=externalIdentity(root);
  fs.writeFileSync(path.join(wrapper,'manifest.json'),JSON.stringify(m,null,2)+'\n',{mode:0o600});
  const dest=path.join(here,'volumes','supp-dest-'+id),before=tree(wrapper);
  const r=exec(id+'-restore',[cli,'restore',wrapper,dest]);
  let api;
  try{api={success:restoreBackup(wrapper,dest+'-api')};}catch(e){api={name:e.name,code:e.code??null,message:e.message};}
  check(id+'-restore-semantic-before-copy',r.exit===1&&!r.stdout.includes('restored_under_hold')&&!fs.existsSync(dest)&&!fs.existsSync(dest+'-api')&&eq(before,tree(wrapper))&&!api.success);
  const runtimeRoot=cp(root,id+'-source-runtime'),run=exec(id+'-source-open',['--import',loader,path.join(here,'probe.mjs'),base,'open',runtimeRoot,'source']);
  const runtime=JSON.parse(run.stdout.trim());
  check(id+'-source-runtime-denies-effects',run.exit===0&&(runtime.storageAvailable===false||runtime.thrown)&&runtime.networkAttempts===0);
  details.push({id,root,wrapper,outerInventoryExact:eq(m.documents,tree(path.join(wrapper,'documents')).map(({path,bytes,sha256})=>({path,bytes,sha256}))),identityMode,identity:m.journal,cliCommand:r.id,api,runtimeCommand:run.id,runtime});
}
function manifestEdit(root,fn){const file=path.join(root,'journal/manifest.json'),m=JSON.parse(fs.readFileSync(file));fn(m);const bytes=JSON.stringify(m)+'\n';fs.writeFileSync(file,bytes);fs.writeFileSync(path.join(root,'journal/manifests/revision-'+m.revision+'.json'),bytes);}

// Re-run transaction attacks with ALL outer document hashes, prefixes, UUID,
// revision, head and sequence derived independently from the tampered bytes.
for(const id of ['unknown-event-correct-checksum','schema-invalid-known-event','reference-invalid-correct-checksum','sequence-invalid-correct-checksum']) {
  const root=path.join(here,'volumes','invalid-'+id);
  const m=JSON.parse(fs.readFileSync(path.join(root,'journal/manifest.json'))),tx=JSON.parse(fs.readFileSync(path.join(root,m.segments[0].path))),{sha256,...body}=tx;
  check(id+'-inner-checksum-is-valid',sha256===hash(canon(body)));
  semanticRestore(id+'-aligned-identity',root);
}

for(const id of ['duplicate-transition','duplicate-message','unknown-middle-event']) {
  const root=cp(path.join(here,'volumes/minimal'),id),m=JSON.parse(fs.readFileSync(path.join(root,'journal/manifest.json'))),file=path.join(root,m.segments[0].path);
  const first=JSON.parse(fs.readFileSync(file));
  const second={...first,seq:2,transitionId:id==='duplicate-transition'?first.transitionId:'second-review-tx',prevSha256:first.sha256};
  if(id==='unknown-middle-event')second.changes=[{type:'reviewUnknown',at:first.at}];
  delete second.sha256;second.sha256=hash(canon(second));
  const third={...first,seq:3,transitionId:'third-review-tx',prevSha256:second.sha256,changes:[{type:'paused',at:first.at,by:'synthetic-operator'}]};delete third.sha256;third.sha256=hash(canon(third));
  fs.writeFileSync(file,[first,second,...id==='unknown-middle-event'?[third]:[]].map(canon).join('\n')+'\n');
  const before=tree(root),dst=root+'-cli-backup';const r=exec(id+'-backup',[cli,'backup',root,dst]);
  check(id+'-backup-refused-source-stable',r.exit===1&&!fs.existsSync(dst)&&eq(before,tree(root)));
  semanticRestore(id,root);
}

const rich=path.join(here,'volumes/healthy');
for(const id of ['missing-recovery-copy','missing-recovery-tail','sealed-full-hash','duplicate-segment','corrupt-media-sidecar']) {
  const root=cp(rich,id);
  if(id==='missing-recovery-copy'){const item=tree(root).find(d=>/^recovery\/.*\/original-/.test(d.path));fs.unlinkSync(path.join(root,item.path));}
  if(id==='missing-recovery-tail'){const item=tree(root).find(d=>/^recovery\/.*\/tail\.jsonl$/.test(d.path));fs.unlinkSync(path.join(root,item.path));}
  if(id==='sealed-full-hash')manifestEdit(root,m=>{m.segments.find(s=>s.sealed).fullSha256='f'.repeat(64);});
  if(id==='duplicate-segment')manifestEdit(root,m=>m.segments.unshift(m.segments[0]));
  if(id==='corrupt-media-sidecar'){const item=tree(root).find(d=>/^media\/.*\.ogg\.json$/.test(d.path)),file=path.join(root,item.path),media=JSON.parse(fs.readFileSync(file));media.sha256='a'.repeat(64);fs.writeFileSync(file,JSON.stringify(media)+'\n');}
  const before=tree(root),dst=root+'-cli-backup';const r=exec(id+'-backup',[cli,'backup',root,dst]);
  check(id+'-backup-refused-source-stable',r.exit===1&&!fs.existsSync(dst)&&eq(before,tree(root)));
  semanticRestore(id,root);
}

// Hold is an observable gate: try a dispatch transition on a restored paused
// control box and on a restored RUNNING source. Both must reject before append.
const restored=cp(path.join(here,'volumes/rich-restored'),'hold-transition');
const s=new ShiftStore(restored);
try {
  const before=tree(restored).filter(d=>d.path!=='store.lock'),seq=s.sequence;
  const event={v:2,type:'outbox_dispatch_started',at:'2026-10-05T20:00:00.000Z',actor:{kind:'member',memberPhone:'synthetic-member-alpha'},outboxId:'pause-box',attempt:1};
  const expected={};for(const [ent,ref] of s.references(event))(expected[ent]??={})[String(ref)]=s.revision(ent,ref);
  let error;
  try{s.commit({transitionId:'dispatch-under-restore-hold',expected,changes:[event]});}catch(e){error={name:e.name,code:e.code??null,message:e.message};}
  check('restore-hold-rejects-even-control-dispatch',!!error&&s.sequence===seq&&s.operationalHold===true&&!s.effectsAllowed&&eq(before,tree(restored).filter(d=>d.path!=='store.lock')));
  write('hold-dispatch-proof.json',{error,sequenceBefore:seq,sequenceAfter:s.sequence,operationalHold:s.operationalHold,effectsAllowed:s.effectsAllowed});
}finally{s.close();}

// Document-rich positive: inventory beyond journals, measured retention; this
// is a bounded test volume, not a claimed production throughput benchmark.
const bulk=cp(rich,'bulk-retention');fs.mkdirSync(path.join(bulk,'retained-documents'),{mode:0o700});
for(let i=0;i<128;i++)fs.writeFileSync(path.join(bulk,'retained-documents','synthetic-'+String(i).padStart(3,'0')+'.bin'),Buffer.alloc(8192,i),{mode:0o600});
const bulkBefore=tree(bulk),bulkBackup=bulk+'-backup',bulkRestore=bulk+'-restored';
const b=exec('bulk-backup',[cli,'backup',bulk,bulkBackup]),r=exec('bulk-restore',[cli,'restore',bulkBackup,bulkRestore]);
check('bulk-139-documents-all-byte-identical',b.exit===0&&r.exit===0&&JSON.parse(b.stdout).documents===139&&eq(bulkBefore,tree(bulk))&&eq(bulkBefore,tree(path.join(bulkBackup,'documents')))&&eq(bulkBefore,tree(bulkRestore).filter(d=>d.path!=='restore-hold.json')));
write('bulk-preservation.json',{input:bulkBefore,sourceAfter:tree(bulk),backup:tree(path.join(bulkBackup,'documents')),restored:tree(bulkRestore),backupCommand:b.id,restoreCommand:r.id});
const inputAfter=packet.allowedInputs.map(i=>({path:i.path,sha256:hash(fs.readFileSync(path.join(base,i.path)))}));
check('authorized-inputs-still-stable',eq(inputBefore,inputAfter));
write('supplement-input-hashes.json',{before:inputBefore,after:inputAfter});
write('supplement-commands.json',commands);write('supplement-cases.json',details);
const result={finishedAt:new Date().toISOString(),commands:commands.length,cases:details.length,checks,pass:checks.filter(c=>c.status==='PASS').length,fail:checks.filter(c=>c.status==='FAIL').length};
write('supplement-results.json',result);console.log(JSON.stringify(result,null,2));process.exitCode=result.fail?1:0;
