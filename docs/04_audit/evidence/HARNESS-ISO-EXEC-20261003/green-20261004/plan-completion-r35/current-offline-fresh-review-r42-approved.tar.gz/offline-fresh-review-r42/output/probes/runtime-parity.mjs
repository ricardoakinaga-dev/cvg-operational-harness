import {ShiftStore} from '/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/candidate-journal-r38/products/shift-assistant/src/store.ts';
const root=process.argv[2];
let identity,validationError;try{identity=ShiftStore.validateStoppedVolume(root)}catch(e){validationError=e.code??e.name}
// Runtime bootstrap must happen on an own copy: it intentionally narrows permissions/fsyncs.
import fs from 'node:fs';import path from 'node:path';
const copy=root+'-runtime-probe';fs.cpSync(root,copy,{recursive:true});if(fs.existsSync(path.join(copy,'store.lock')))fs.unlinkSync(path.join(copy,'store.lock'));
const s=new ShiftStore(copy);const projection={sequence:s.sequence,messages:s.unprocessedMessages(),notes:s.notesV2(),tasks:s.tasksV2(),inbox:s.inboxes(),outbox:s.outboxes(),paused:s.paused,known:s.knownPatients('Rex'),media:s.mediaInventory(),migration:s.migration??null};
const result={validationAccepted:!!identity,identity:identity??null,validationError:validationError??null,runtimeStorageAvailable:s.storageAvailable,diagnostic:s.diagnostic??null,operationalHold:s.operationalHold,effectsAllowed:s.effectsAllowed,projection};s.close();console.log(JSON.stringify(result));
