import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath,pathToFileURL } from 'node:url';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
const here=path.dirname(fileURLToPath(import.meta.url));
const packet=JSON.parse(fs.readFileSync(path.resolve(here,'../../authority/packet.json'))),base=packet.source;
const {ShiftStore}=await import(pathToFileURL(path.join(base,'products/shift-assistant/dist/offline-validator.mjs')));
const sha=v=>createHash('sha256').update(v).digest('hex');
const env={PATH:path.dirname(process.execPath),NODE_OPTIONS:'',TSX_DISABLE_CACHE:'1',TMPDIR:path.join(here,'tmp'),XDG_CACHE_HOME:path.join(here,'cache')};
const checks=[],states=[],commands=[];
const event={v:2,type:'outbox_dispatch_started',at:'2026-10-05T20:00:00.000Z',actor:{kind:'member',memberPhone:'synthetic-member-alpha'},outboxId:'pause-box',attempt:1};
for(const [id,input,shouldAccept] of [['healthy-paused-control','healthy',true],['restored-held-control','rich-restored',false]]) {
  const root=path.join(here,'volumes','gate-'+id);fs.cpSync(path.join(here,'volumes',input),root,{recursive:true});
  const s=new ShiftStore(root);
  try {
    const expected={};for(const [entity,ref] of s.references(event))(expected[entity]??={})[String(ref)]=s.revision(entity,ref);
    const sequenceBefore=s.sequence;let result,error;
    try{result=s.commit({transitionId:'identical-control-dispatch',expected,changes:[event]});}catch(e){error={code:e.code??e.name,message:e.message};}
    const ok=shouldAccept?!!result&&s.sequence===sequenceBefore+1:s.sequence===sequenceBefore&&!!error&&s.operationalHold&&!s.effectsAllowed;
    checks.push({id,status:ok?'PASS':'FAIL'});states.push({id,event,expected,sequenceBefore,sequenceAfter:s.sequence,result:result??null,error:error??null,storageAvailable:s.storageAvailable,operationalHold:s.operationalHold,effectsAllowed:s.effectsAllowed,paused:s.paused});
  } finally{s.close();}
}
// Verify restore-hold denial against RUNNING input as well: the source copy
// accepts processing; the same restored inbox cannot start processing.
for(const [id,input,shouldAccept] of [['healthy-running-process','minimal',true],['restored-running-hold','minimal-restored',false]]) {
  const root=path.join(here,'volumes','gate-'+id);fs.cpSync(path.join(here,'volumes',input),root,{recursive:true});
  const s=new ShiftStore(root);
  try {
    const key=JSON.stringify(['waha','gate-synthetic','held-input']),at='2026-10-05T17:00:00.000Z';
    const i={key,provider:'waha',session:'gate-synthetic',messageId:'held-input',memberPhone:'synthetic-member-alpha',kind:'text',text:'inventado',receivedAt:at,state:'received',stage:'organize',attempt:0};
    const canonical=v=>v===null||typeof v!=='object'?JSON.stringify(v):'{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+canonical(v[k])).join(',')+'}';
    i.digest=sha(canonical({provider:i.provider,session:i.session,messageId:i.messageId,memberPhone:i.memberPhone,kind:i.kind,text:i.text,mimetype:null}));
    const commit=(transition,event)=>{const expected={};for(const [ent,ref] of s.references(event))(expected[ent]??={})[String(ref)]=s.revision(ent,ref);return s.commit({transitionId:transition,expected,changes:[event]});};
    commit('gate-inbound',{v:2,type:'inbound_recorded',at,actor:{kind:'member',memberPhone:i.memberPhone},inbox:i});
    const seq=s.sequence;let result,error;
    try{result=commit('gate-processing',{v:2,type:'processing_started',at,actor:{kind:'member',memberPhone:i.memberPhone},key,stage:'organize',attempt:1,deadline:'2026-10-05T17:03:30.000Z',draftAt:at});}catch(e){error={code:e.code??e.name,message:e.message};}
    const ok=shouldAccept?!!result&&s.sequence===seq+1:!!error&&s.sequence===seq&&!s.effectsAllowed&&s.operationalHold&&!s.paused;
    checks.push({id,status:ok?'PASS':'FAIL'});states.push({id,sequenceBefore:seq,sequenceAfter:s.sequence,result:result??null,error:error??null,paused:s.paused,operationalHold:s.operationalHold,effectsAllowed:s.effectsAllowed,inbox:s.inbox(key)});
  }finally{s.close();}
}
// Fresh empty destinations are accepted, too; existing empty target is a
// supported local contract, unlike a nonempty target already tested.
const dest=path.join(here,'volumes','gate-empty-destination');fs.mkdirSync(dest,{mode:0o700});
const cli=path.join(base,'products/shift-assistant/scripts/backup-restore.mjs'),args=[cli,'restore',path.join(here,'volumes/minimal-backup'),dest];
const r=spawnSync(process.execPath,args,{env,cwd:here,encoding:'utf8',timeout:15000});
fs.writeFileSync(path.join(here,'raw/gate-empty-destination.stdout'),r.stdout??'',{mode:0o600});fs.writeFileSync(path.join(here,'raw/gate-empty-destination.stderr'),r.stderr??'',{mode:0o600});
commands.push({id:'gate-empty-destination',command:[process.execPath,...args],cwd:here,env,exit:r.status,signal:r.signal,error:r.error?.message??null,stdout:'raw/gate-empty-destination.stdout',stderr:'raw/gate-empty-destination.stderr'});
checks.push({id:'existing-empty-destination-positive',status:r.status===0&&JSON.parse(r.stdout).status==='restored_under_hold'?'PASS':'FAIL'});
const result={finishedAt:new Date().toISOString(),checks,states,commands,pass:checks.filter(c=>c.status==='PASS').length,fail:checks.filter(c=>c.status==='FAIL').length};
fs.writeFileSync(path.join(here,'gate-controls-results.json'),JSON.stringify(result,null,2)+'\n',{mode:0o600});console.log(JSON.stringify(result,null,2));process.exitCode=result.fail?1:0;
