import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';

const [source, action, root, variant = 'source'] = process.argv.slice(2);
const target = variant === 'compiled' ? 'dist/offline-validator.mjs' : 'src/store.ts';
const { ShiftStore } = await import(pathToFileURL(path.join(source, 'products/shift-assistant', target)));
const hash = value => createHash('sha256').update(value).digest('hex');
const canon = value => value === null || typeof value !== 'object' ? JSON.stringify(value) : Array.isArray(value) ? '[' + value.map(canon).join(',') + ']' : '{' + Object.keys(value).sort().map(k => JSON.stringify(k) + ':' + canon(value[k])).join(',') + '}';
let networkAttempts = 0;
globalThis.fetch = async () => { networkAttempts++; throw new Error('REVIEW_EGRESS_DENIED'); };
const ANA = 'synthetic-member-alpha', BRUNO = 'synthetic-member-beta';
const at = '2026-10-05T17:00:00.000Z', later = '2026-10-05T19:00:00.000Z';
function projection(s) {
  return { sequence: s.sequence, paused: s.paused, messages: s.unprocessedMessages(), inbox: s.inboxes(), notes: s.notesV2(), tasks: s.tasksV2(), outbox: s.outboxes(), deliveries: s.deliveries(), known: s.knownPatients('Miragem'), lastAlpha: s.lastPresentedNote(ANA) ?? null, lastBeta: s.lastPresentedNote(BRUNO) ?? null, media: s.mediaInventory(), nextTaskNumber: s.nextTaskNumber() };
}
function status(s) { return { storageAvailable: s.storageAvailable, diagnostic: s.diagnostic ?? null, operationalHold: s.operationalHold, effectsAllowed: s.effectsAllowed, networkAttempts, projection: projection(s) }; }

if (action === 'open') {
  let s;
  try { s = new ShiftStore(root); console.log(JSON.stringify(status(s))); }
  catch(e) { console.log(JSON.stringify({thrown: true, code: e.code ?? e.name, message: e.message, networkAttempts})); }
  finally { s?.close(); }
} else if (action === 'lock') {
  const s = new ShiftStore(root);
  try {
    const lock = fs.readFileSync(path.join(root, 'store.lock'));
    let secondWriter;
    try { const other = new ShiftStore(root); other.close(); secondWriter = 'UNEXPECTED_SUCCESS'; } catch(e) { secondWriter = e.code ?? e.name; }
    const cli = path.join(source, 'products/shift-assistant/scripts/backup-restore.mjs');
    const r = spawnSync(process.execPath, [cli, 'backup', root, root + '-blocked-backup'], { encoding:'utf8', cwd: path.dirname(root), env: { PATH: path.dirname(process.execPath), NODE_OPTIONS: '' }, timeout:10000 });
    console.log(JSON.stringify({secondWriter, cli: {command:[process.execPath,cli,'backup',root,root+'-blocked-backup'], exit:r.status, signal:r.signal, stdout:r.stdout, stderr:r.stderr}, lockUnchanged:lock.equals(fs.readFileSync(path.join(root,'store.lock'))), destinationExists:fs.existsSync(root+'-blocked-backup')}));
  } finally { s.close(); }
} else if (action === 'seed') {
  const s = new ShiftStore(root);
  const commits = [];
  function commit(id, event) {
    const expected = {};
    for (const [entity, ref] of s.references(event)) (expected[entity] ??= {})[String(ref)] = s.revision(entity, ref);
    const result = s.commit({transitionId:id, expected, changes:[event]});
    commits.push({id,event,result});
  }
  function v(type, memberPhone = ANA, more = {}, when = at) { return {v:2,type,at:when,actor:{kind:'member',memberPhone},...more}; }
  function inbound(id, text, member = ANA, more = {}) {
    const i = { key:JSON.stringify(['waha','offline-review',id]), provider:'waha',session:'offline-review',messageId:id,memberPhone:member,kind:'text',text,receivedAt:at,state:'received',stage:'organize',attempt:0,...more };
    i.digest = hash(canon({provider:i.provider,session:i.session,messageId:i.messageId,memberPhone:i.memberPhone,kind:i.kind,text:i.text,mimetype:i.mimetype ?? null,...i.mediaSha256 ? {mediaSha256:i.mediaSha256} : {}}));
    commit('inbound:'+id,v('inbound_recorded',member,{inbox:i})); return i.key;
  }
  function processInput(key, member = ANA) { commit('processing:'+key,v('processing_started',member,{key,stage:'organize',attempt:1,deadline:'2026-10-05T17:03:30.000Z',draftAt:at})); }
  function box(id, purpose, transition, member = ANA, extra = {}) { const text = 'Synthetic '+id; return {id,purpose,sourceTransitionId:transition,recipientMemberId:member,payloadText:text,payloadSha256:hash(text),state:'queued',attempt:0,...extra}; }
  function dispatch(id, member = ANA, outcome = 'provider_accepted') {
    commit('dispatch:'+id,v('outbox_dispatch_started',member,{outboxId:id,attempt:1}));
    if (outcome === 'dispatching') return;
    const more = outcome === 'provider_accepted' ? {receipt:{status:201,at,sha256:hash('invented receipt '+id),providerId:'fake:'+id}} : {error:'synthetic-disconnect'};
    commit('result:'+id,v('outbox_result',member,{outboxId:id,state:outcome,...more}));
  }
  function draft(id, literal, member = ANA, replacement) {
    const rawText = `Paciente Miragem, ID ${literal}, leito Azul. Pendência: verificar registro.`;
    const key = inbound('msg:'+id,rawText,member);
    if(replacement) commit('replace-start:'+id,v('replacement_started',member,{key,noteId:replacement.id,revision:replacement.revision}));
    processInput(key,member);
    const evidence = [ ['pacientes.p1.nome','Miragem'], ['pacientes.p1.id',literal], ['pacientes.p1.leito','Azul'], ['pendencias.t1.descricao','verificar registro'] ].map(([p,q])=>({path:p,patientRef:'p1',quote:q}));
    const organized = {schemaVersion:2,pacientes:[{localRef:'p1',nome:'Miragem',id:literal,leito:'Azul',exames_pedidos:[],condutas:[]}],pendencias:[{localRef:'t1',descricao:'verificar registro',pacienteRef:'p1',pacienteId:literal}],duvidas:[],evidence};
    const revision = replacement ? replacement.revision+1 : 1;
    const task = {id:hash(JSON.stringify([id,revision,'t1'])),number:s.nextTaskNumber(),noteId:id,noteRevision:revision,localRef:'t1',ownerPhone:member,description:'verificar registro',patientRef:'p1',patientId:literal,bindingRevision:revision,sourceRefs:['pendencias.t1.descricao'],dueAt:'2026-10-05T18:00:00.000Z',createdAt:at,status:'draft',generation:1,remindedCount:0};
    const binding = {localRef:'p1',name:'Miragem',idLiteral:literal,normalizedId:literal,bed:'Azul',provenance:'source_explicit',evidenceRefs:evidence.slice(0,3).map(e=>e.path)};
    const organizedSha256 = hash(canon(organized));
    const note = {id,messageKey:key,authorPhone:member,revision,createdAt:at,rawText,rawTextSha256:hash(rawText),organizedSha256,token:`${id.slice(0,12)}-r${revision}-${organizedSha256.slice(0,12)}`,state:'draft',replacementPending:false,organized,issues:[],warnings:[],bindings:[binding],evidence:evidence.map(e=>({...e,start:rawText.indexOf(e.quote),end:rawText.indexOf(e.quote)+e.quote.length})),tasks:[task],previewIds:['preview:'+id]};
    const transition = 'draft:'+id;
    commit(transition,v(replacement ? 'replacement_prepared' : 'draft_prepared',member,{key,note,outboxes:[box('preview:'+id,'preview',transition,member,{noteId:id,noteRevision:revision})],...replacement ? {previousNoteId:replacement.id} : {}}));
    return note;
  }
  function confirm(n) {
    dispatch('preview:'+n.id,n.authorPhone);
    const key = inbound('ok:'+n.id,'ok nota '+n.token,n.authorPhone); processInput(key,n.authorPhone);
    const transition = 'confirm:'+n.id;
    commit(transition,v('confirmation_committed',n.authorPhone,{key,noteId:n.id,revision:n.revision,hash:n.organizedSha256,token:n.token,tasks:n.tasks.map(t=>({...t,status:'open'})),bindings:n.bindings.map(b=>({...b,confirmedBy:n.authorPhone,confirmedAt:at})),outbox:box('confirm-box:'+n.id,'response',transition,n.authorPhone)}));
  }
  try {
    assert.equal(s.storageAvailable,true);
    if (variant === 'minimal') {
      commit('minimal-message',{type:'message_received',at,message:{provider:'evolution',messageId:'minimal-invented',fromPhone:ANA,kind:'text',text:'ajuda sintética',receivedAt:at}});
    } else {
      const done = draft('note-done-review','000701'); confirm(done); commit('done',v('task_completed',ANA,{number:done.tasks[0].number}));
      const snooze = draft('note-snooze-review','000702'); confirm(snooze); commit('snooze',v('task_snoozed_v2',ANA,{number:snooze.tasks[0].number,dueAt:'2026-10-05T20:30:00.000Z'}));
      const prior = draft('note-old-review','000703'); confirm(prior);
      const replacement = draft('note-new-review','000704',ANA,prior); confirm(replacement);
      const task = s.task(replacement.tasks[0].number), transition = 'reminder-review';
      commit(transition,v('reminder_reserved',ANA,{number:task.number,outbox:box('uncertain-reminder','reminder',transition,ANA,{noteId:replacement.id,noteRevision:replacement.revision,taskNumber:task.number,taskGeneration:task.generation,slot:1})},later));
      dispatch('uncertain-reminder',ANA,'uncertain');
      draft('note-draft-review','00701',BRUNO);
      const retry = inbound('retry-media','invented audio',ANA,{kind:'audio',stage:'media',mimetype:'audio/ogg'}); processInput(retry);
      const media = s.saveMediaDescriptor(new Uint8Array([79,103,103,83,0,1,2,255]),'audio/ogg',retry);
      commit('media-review',v('media_attached',ANA,{key:retry,path:media.path}));
      commit('transcript-review',v('transcript_recorded',ANA,{key:retry,text:'texto de áudio inventado',sha256:hash('texto de áudio inventado')}));
      commit('retry-review',v('processing_retry_scheduled',ANA,{key:retry,state:'retry_wait',error:'synthetic-retry',attempt:0,nextAttemptAt:'2026-10-05T21:00:00.000Z'}));
      dispatch('confirm-box:'+done.id,ANA,'dispatching');
      const pause = inbound('pause','pausar sintético');
      commit('pause-review',v('operation_paused',ANA,{key:pause,outbox:box('pause-box','control','pause-review')}));
    }
    console.log(JSON.stringify({seeded:true,commits,status:status(s)}));
  } finally { s.close(); }
  if(variant !== 'minimal') {
    fs.mkdirSync(path.join(root,'inbound'),{recursive:true,mode:0o700});
    fs.writeFileSync(path.join(root,'inbound','synthetic-envelope.json'),JSON.stringify({synthetic:true,messageId:'orphan-envelope',text:'inventado'}),{mode:0o600});
    fs.writeFileSync(path.join(root,'media','orphan-uncommitted.bin'),Buffer.from([0,255,48,127]),{mode:0o600});
    const m = JSON.parse(fs.readFileSync(path.join(root,'journal/manifest.json')));
    fs.appendFileSync(path.join(root,m.segments.at(-1).path),'{"syntheticIncomplete":');
    const recovered = new ShiftStore(root);
    try { assert.equal(recovered.storageAvailable,true); console.log(JSON.stringify({recovery:true,status:status(recovered)})); } finally { recovered.close(); }
  }
} else throw new Error('Unknown probe action');
