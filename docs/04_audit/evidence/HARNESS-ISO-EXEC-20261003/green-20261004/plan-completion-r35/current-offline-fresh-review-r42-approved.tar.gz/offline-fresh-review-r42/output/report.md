Revisão independente R42 — consistência de dados exclusivamente local

**Veredito: PASS_LOCAL.** 106/106 verificações aprovadas, 0 falhas. Nenhuma aprovação de produção. O parecer se limita aos critérios B1, B2, B4 e B5 definidos em `authority/packet.json`.

Critérios congelados antes da execução em [frozen-criteria.json](review-20261005T2010Z/frozen-criteria.json). A cópia `approved-spec0179.md` coincide com o hash aprovado `988192fe48737b4571ed659f051e22f3a9283d5c433e7c6c078e1dd0f7be86c3`. Seu cabeçalho histórico PROPOSED não foi reinterpretado como autorização de produção: a autoridade desta revisão é o packet e o pedido local atual. Não consultados governança, ledgers, .gauntlet, credenciais, avaliações históricas ou relatórios da suíte paralela.

| Critério | Resultado local | Evidência principal |
| --- | --- | --- |
| B1 | PASS: lock exclusivo; recusas antes do backup; retenção integral e hashes estáveis | [preservação](review-20261005T2010Z/rich-preservation.json), [casos](review-20261005T2010Z/case-results.json), [lock](review-20261005T2010Z/active-writer-exclusion.json) |
| B2 | PASS: validação completa antes de copiar; destino novo/vazio; hold; identidades, conteúdo e pausa iguais na API | [preservação](review-20261005T2010Z/rich-preservation.json), [semântica](review-20261005T2010Z/supplement-cases.json), [controles hold](review-20261005T2010Z/gate-controls-results.json) |
| B4 | PASS: sondas próprias; CLI Node22 compilada real; assertions existentes intactas; 10 fingerprints autorizados iguais | [comandos](review-20261005T2010Z/all-commands.json), [hashes](review-20261005T2010Z/input-hash-comparison.json) |
| B5 | PASS: dados inventados, volumes próprios, execução local | Externo/humano/produção: NOT_RUN |

O processo usa `/home/ricardo/.nvm/versions/node/v22.23.2/bin/node` (v22.23.2). As 62 chamadas diretas da CLI são executadas sem TSX, sem `--import` e com `NODE_OPTIONS=''`; há mais uma CLI interna registrada na prova de exclusão por lock. 109 subprocessos estão registrados nos comandos, além desse subprocesso interno. Doze chamadas adversariais adicionais usam a API real `restoreBackup` para expor o erro, sem substituir a CLI. As sondas do fonte usam exclusivamente o loader existente com cache desabilitado e diretórios temporários próprios em output. Não feito build, instalação, alteração do candidato ou execução de outro agente.

Controles saudáveis: o volume rico contém 50 transações após recuperação, cinco notas e cinco tarefas, 11 inboxes, rawText/hash, organização/evidência/bindings e IDs literais distintos (incluindo `000701` e `00701`), revisão substituída e revisão 2, tarefa done, cancelada e snooze generation 2, preview aceito com receipt sintético, outbox uncertain e dispatching, retry com transcript e mídia, pausa true, cauda isolada/cópia original e órfãos preservados. O volume mínimo contém uma entrada sintética e pausa false. Ambos foram criados pela API real com guardas, fechados e abertos novamente em cópias independentes.

A CLI produziu `backup_verified` e `restored_under_hold`. No volume rico, os 11 documentos permaneceram byte a byte idênticos no original, backup e restore, com apenas o novo marcador `restore-hold.json` no destino. No volume mínimo, os três documentos também foram preservados. O controle ampliado acrescentou 128 arquivos sintéticos de 8192 bytes: os 139 documentos tiveram igualdade de hashes no original, backup e restauração. Destinos tiveram modo 0700 e documentos modo 0600. UUID, revisão, sequência, cabeça/prefixos do journal coincidiram; recibos de backup/restore compartilharam hash de manifesto. [Rich](review-20261005T2010Z/rich-preservation.json), [minimal](review-20261005T2010Z/minimal-preservation.json), [bulk](review-20261005T2010Z/bulk-preservation.json).

Fonte e bundle reabriram as mesmas cópias saudáveis com projeções integralmente iguais. As projeções restauradas preservaram rawText, hashes, IDs de nota/tarefa/inbox/outbox, bindings literais, revisões/estados, números/dueAt/generation/contadores, tentativas/stages/retry, receipts e uncertain/dispatching, memória confirmada, última nota apresentada, pausa e inventário de mídia. A abertura restaurada teve storage saudável, hold true e effectsAllowed false, inclusive quando pausa false. O mesmo dispatch de controle é aceito no original saudável pausado e rejeitado sob hold (STATE_CONFLICT, seq não muda); processing_started é aceito no original running e recusado na cópia restaurada running. Zero tentativas de fetch nas sondas de abertura. Esse é o limite da prova de ausência de envio: não foi iniciado o assistente com scheduler/transportes. [Controles comparativos](review-20261005T2010Z/gate-controls-results.json).

| Adversário inicial | Exit backup / restore | Abertura local do fonte | Hashes de origem/backup inválido após CLI |
| --- | --- | --- | --- |
| missing-revision | 1 / 1 | storage indisponível | idênticos |
| divergent-revision | 1 / 1 | storage indisponível | idênticos |
| prefix-checksum | 1 / 1 | storage indisponível | idênticos |
| transaction-checksum | 1 / 1 | storage indisponível | idênticos |
| unknown-event-correct-checksum | 1 / 1 | storage indisponível | idênticos |
| schema-invalid-known-event | 1 / 1 | storage indisponível | idênticos |
| reference-invalid-correct-checksum | 1 / 1 | storage indisponível | idênticos |
| sequence-invalid-correct-checksum | 1 / 1 | storage indisponível | idênticos |
| missing-referenced-media | 1 / 1 | storage indisponível | idênticos |
| referenced-media-corrupted | 1 / 1 | storage indisponível | idênticos |
| symlink-document | 1 / 1 | storage indisponível | idênticos |
| unrecovered-tail | 1 / 1 | saudável com recuperação | idênticos |

Todos esses backups/restores inválidos saíram 1, não emitiram receipt de sucesso e não criaram destino. Na CLI, stderr foi `OFFLINE_BACKUP_RESTORE_FAILED_CLOSED`. Os erros de schema/referência/checksum/mídia também produziram storage indisponível e efeitos negados na API fonte e na API compilada. Cauda sem LF é uma diferença intencional: a CLI offline a recusa sem mutação; a abertura normal em cópia própria preserva originais, isola a cauda e acrescenta recovery, tornando storage saudável. Essa recuperação não ocorreu nos inputs fornecidos à CLI. [Resultados brutos](review-20261005T2010Z/raw/), [casos](review-20261005T2010Z/case-results.json).

Prova semântica reforçada: evento desconhecido, evento conhecido sem campo obrigatório, referência inexistente e sequência inválida tiveram checksum interno correto; os wrappers de backup tiveram inventário, UUID/revisão, sequence/head e prefixes recalculados independentemente a partir dos bytes alterados. Mesmo assim restore recusou antes de copiar; a API restoreBackup lançou STORAGE_UNAVAILABLE, e o fonte abriu degradado. Assim a recusa não depende de discrepância de hash externo ou de identidade declarada. Também recusados transitionId duplicado, mensagem duplicada e evento desconhecido delimitado no meio de três transações com cadeia íntegra; este último não permitiu aplicar o evento posterior de pausa. Cópia/tail de recovery ausentes, fullSha256 selado divergente, segmento duplicado e sidecar de mídia corrompido foram recusados com hashes externos recalculados. [Doze casos adicionais](review-20261005T2010Z/supplement-cases.json), [39 verificações adicionais](review-20261005T2010Z/supplement-results.json).

Inventário também recusou documento extra, ausente, alterado e symlink, escape `../outside`, caminho absoluto, entrada duplicada, hash ausente, identidade de journal divergente e destino não vazio. O destino não vazio permaneceu intacto; um destino existente vazio foi aceito como controle. Lock de escritor ativo, segunda abertura escritora e lock residual foram recusados; identidades de lock preservadas. Não apagado lock de outro processo. Não houve processo externo parado; todos os subprocessos próprios encerraram naturalmente e os handles de store foram fechados em finally.

Comparação dos dez inputs técnicos autorizados: expected = before = after em todos, incluindo os dois testes existentes. Nenhum fingerprint de outro arquivo técnico do candidato.

| Input autorizado | SHA-256 antes | Comparação |
| --- | --- | --- |
| `products/shift-assistant/src/journal.ts` | `ba62b4674912605061e843c7a270d0ca202e7447daa6f24436e5affa2da2f937` | igual ao packet antes/depois |
| `products/shift-assistant/src/store.ts` | `f9bb144834c01a75872d25f11b35ee536ef428d5acae7e443a5b33bc0ce9eaeb` | igual ao packet antes/depois |
| `products/shift-assistant/src/migrate-journal.ts` | `8006d55bcac9505dcb1085f08e12b8a7eaa78e8abbb61076153a3614af865ad1` | igual ao packet antes/depois |
| `products/shift-assistant/src/domain-v2.ts` | `3465a229d57335aab36ac1c4ee81b55d068560918021eef033ddade21dc104ef` | igual ao packet antes/depois |
| `products/shift-assistant/scripts/backup-restore.mjs` | `5c12bf90cb08bc851bc3c81560449c77478a4b5ef9a4ab1d8d2067ee625fea4d` | igual ao packet antes/depois |
| `products/shift-assistant/scripts/build-offline-validator.mjs` | `20ed1c63f9668551cc28eab21f66a44f9e263ae56d460a67c5f967ef7e188035` | igual ao packet antes/depois |
| `products/shift-assistant/docs/operations.md` | `4226f88af37ac18b0d7241491b961fa317eaa3eb400bc03f9a5c9e2e4692277b` | igual ao packet antes/depois |
| `products/shift-assistant/dist/offline-validator.mjs` | `1cc4b512a916e4e86736df07467d70c8185b8868145485d5ecdca3f8ddae5675` | igual ao packet antes/depois |
| `products/shift-assistant/src/__tests__/offline-backup-restore.test.ts` | `33b9a26c5cdcaea0ec72109c179ce2e8ec6704f65e216605cd7be9e11f695ee6` | igual ao packet antes/depois |
| `products/shift-assistant/src/__tests__/restore-workflow.test.ts` | `7118a7a28bf03b0b5f8eb20173a8bcd9e204e37d1fbca67bcda6825bf980df77` | igual ao packet antes/depois |

O JSON [input-hash-comparison.json](review-20261005T2010Z/input-hash-comparison.json) contém expected/before/after completos, coletados também após os controles finais. Manifestos de preservação dos volumes contêm hashes por documento. [Comandos completos](review-20261005T2010Z/all-commands.json) registram argv, cwd, ambiente mínimo, status, signal e paths de stdout/stderr. [commands.txt](review-20261005T2010Z/commands.txt) fornece a forma shell; [driver-results.json](review-20261005T2010Z/driver-results.json) identifica as três execuções principais com exit 0. Os três scripts próprios e suas sondas estão em output para inspeção e reprodução em uma nova subpasta vazia de output; não reexecutar sobre os volumes preservados desta rodada.

Limitações explícitas:

- PASS cobre somente B1/B2/B4/B5 locais do packet, nas fronteiras CLI compilada e API de persistência ShiftStore. Não fecha integralmente a SPEC 0179 nem gates de release.
- Abertura do programa local usa src/store.ts com loader existente, e dist/offline-validator.mjs sem loader. Imports transitivos são resolvidos pelo runtime; fingerprints e inspeção explícita do candidato limitados aos dez arquivos autorizados.
- Não foi iniciado compose, servidor, webhook, scheduler, tick ou adapter de transporte. Zero envio observado na CLI e abertura da API; fetch canário nas sondas diretas registrou zero tentativas. Não constitui prova end-to-end de reenvio pelo assistente completo.
- Notas, confirmações, receipts e transcript são sintéticos e inseridos pela API commit com guardas reais; não são prova de fluxo humano, entrega de provider, transcrição efetiva, HIS ou organização por modelo.
- Não liberado hold para ensaio de operação pós-reconciliação, não medidos alertas, crash físico, energia, fsync sob falha, capacidade de produção ou premissas de filesystem remoto.
- A suíte completa paralela não foi executada nem consultada nesta revisão; seus relatórios não são inputs. B3 e demais critérios fora de B1/B2/B4/B5 não avaliados.
- Não foi reconstruído o bundle: testado o artefato compilado existente cujo hash coincide com o packet. Equivalência fonte/bundle observada nos controles especificados, sem claim de equivalência universal.
- Volume documental ampliado: 128 arquivos adicionais de 8192 bytes, total de 139 documentos; não é benchmark de throughput ou de máximo suportado.

Nenhuma falha bloqueante encontrada nas fronteiras testadas. Produção segue sem aprovação; revisão externa/humana, operação pós-hold, alerta e suíte paralela permanecem fora deste parecer. Próxima ação local: revisar estas evidências; nenhuma correção foi proposta ou aplicada ao candidato.
