import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const authority = path.resolve(here,'../../authority');
const packet = JSON.parse(fs.readFileSync(path.join(authority,'packet.json')));
const source = packet.source;
const cli = path.join(source,'products/shift-assistant/scripts/backup-restore.mjs');
const loader = path.join(source,'node_modules/tsx/dist/loader.mjs');
const probe = path.join(here,'probe.mjs');
const sha = data => createHash('sha256').update(data).digest('hex');
const canon = value => value === null || typeof value !== 'object' ? JSON.stringify(value) : Array.isArray(value) ? '[' + value.map(canon).join(',') + ']' : '{' + Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+canon(value[k])).join(',') + '}';
const write = (name,value) => fs.writeFileSync(path.join(here,name), typeof value === 'string' ? value : JSON.stringify(value,null,2)+'\n',{mode:0o600});
for(const d of ['raw','volumes','tmp','cache']) fs.mkdirSync(path.join(here,d),{recursive:true,mode:0o700});
const cleanEnv = {PATH:path.dirname(process.execPath),NODE_OPTIONS:'',TSX_DISABLE_CACHE:'1',TMPDIR:path.join(here,'tmp'),XDG_CACHE_HOME:path.join(here,'cache')};
let counter=0;
const commands=[],checks=[],cases=[],inputHashesBefore=hashInputs();
function hashInputs() { return packet.allowedInputs.map(i=>({path:i.path,expected:i.sha256,actual:sha(fs.readFileSync(path.join(source,i.path)))})); }
write('input-hashes-before.json',inputHashesBefore);
write('frozen-criteria.json',{task:packet.task,criteria:packet.criteria,negativeExamples:packet.negativeExamples,scope:'CLI compiled + direct-source ShiftStore API; synthetic local volumes only',node:process.execPath,nodeVersion:process.version,specExpected:packet.approvedSpecSha256,specActual:sha(fs.readFileSync(path.join(authority,'approved-spec0179.md'))),startedAt:new Date().toISOString()});
function tree(root, relative='') {
  if(!fs.existsSync(root)) return null;
  const out=[];
  for(const n of fs.readdirSync(path.join(root,relative)).sort()) {
    const rel=relative ? relative+'/'+n : n;
    const full=path.join(root,rel),stat=fs.lstatSync(full);
    if(stat.isSymbolicLink()) out.push({path:rel,kind:'symlink',target:fs.readlinkSync(full)});
    else if(stat.isDirectory()) out.push(...tree(root,rel));
    else out.push({path:rel,bytes:stat.size,sha256:sha(fs.readFileSync(full)),mode:stat.mode&0o777});
  }
  return out.sort((a,b)=>a.path.localeCompare(b.path,'en'));
}
function check(id,condition,detail={}) { checks.push({id,status:condition?'PASS':'FAIL',...detail}); }
function exec(label,args,timeout=30000) {
  const id=String(++counter).padStart(3,'0')+'-'+label;
  const start=new Date().toISOString();
  const r=spawnSync(process.execPath,args,{cwd:here,env:cleanEnv,encoding:'utf8',timeout,maxBuffer:12*1024*1024});
  fs.writeFileSync(path.join(here,'raw',id+'.stdout'),r.stdout??'',{mode:0o600});
  fs.writeFileSync(path.join(here,'raw',id+'.stderr'),r.stderr??'',{mode:0o600});
  const record={id,command:[process.execPath,...args],cwd:here,env:cleanEnv,startedAt:start,finishedAt:new Date().toISOString(),exit:r.status,signal:r.signal,error:r.error?.message??null,stdout:'raw/'+id+'.stdout',stderr:'raw/'+id+'.stderr'};
  commands.push(record); write('commands.json',commands);
  return {...record,out:r.stdout??'',err:r.stderr??''};
}
function parsed(r) { try { return r.out.trim().split('\n').map(s=>JSON.parse(s)); } catch { return []; } }
function sourceProbe(label,action,root,variant='source') { return exec(label,['--import',loader,probe,source,action,root,variant]); }
function compiledProbe(label,action,root) { return exec(label,[probe,source,action,root,'compiled']); }
function cp(sourceRoot,name) { const dst=path.join(here,'volumes',name); fs.cpSync(sourceRoot,dst,{recursive:true,dereference:false}); return dst; }
function cliRun(label,mode,src,dst) { return exec(label,[cli,mode,src,dst]); }
function openCopy(label,src,compiled=false) {
  const dst=cp(src,label+'-runtime'); const before=tree(dst);
  const r=compiled ? compiledProbe(label,'open',dst) : sourceProbe(label,'open',dst);
  const result=parsed(r).at(-1);
  return {command:r.id,result,documentsUnchanged:JSON.stringify(before)===JSON.stringify(tree(dst))};
}
function updateManifests(root,change) {
  const file=path.join(root,'journal/manifest.json'),m=JSON.parse(fs.readFileSync(file)); change(m);
  const bytes=JSON.stringify(m)+'\n'; fs.writeFileSync(file,bytes);
  fs.writeFileSync(path.join(root,'journal/manifests/revision-'+m.revision+'.json'),bytes);
}
function rewriteTransactions(root,change) {
  const m=JSON.parse(fs.readFileSync(path.join(root,'journal/manifest.json')));
  let prev=m.legacy?.prefixSha256??sha('');
  for(const seg of m.segments) {
    const file=path.join(root,seg.path),bytes=fs.readFileSync(file);
    const limit=seg.sealed ? seg.bytes : bytes.length;
    const txs=bytes.subarray(0,limit).toString('utf8').trim().split('\n').filter(Boolean).map(s=>JSON.parse(s));
    for(const tx of txs) { change(tx); tx.prevSha256=prev; delete tx.sha256; tx.sha256=sha(canon(tx)); prev=tx.sha256; }
    const prefix=Buffer.from(txs.map(canon).join('\n')+(txs.length?'\n':''));
    const next=Buffer.concat([prefix,bytes.subarray(limit)]); fs.writeFileSync(file,next);
    seg.bytes=seg.sealed ? prefix.length : 0; seg.prefixSha256=sha(seg.sealed ? prefix : ''); if(seg.sealed) seg.fullSha256=sha(next);
  }
  // Recovery references bind sealed originals. Adversarial transaction changes
  // therefore use the minimal, non-recovered independent fixture below.
  updateManifests(root,m2=>Object.assign(m2,m));
}
function wrappedInvalid(invalidRoot,template,name) {
  const backup=path.join(here,'volumes',name); fs.mkdirSync(backup,{mode:0o700}); fs.cpSync(invalidRoot,path.join(backup,'documents'),{recursive:true,dereference:false});
  const m=JSON.parse(fs.readFileSync(path.join(template,'manifest.json')));
  m.documents=tree(path.join(backup,'documents')).map(({path,bytes,sha256})=>({path,bytes,sha256}));
  fs.writeFileSync(path.join(backup,'manifest.json'),JSON.stringify(m,null,2)+'\n',{mode:0o600});
  return backup;
}
function adversarial(id,base,backupTemplate,mutate,expectedRuntime=true) {
  const invalid=cp(base,'invalid-'+id); mutate(invalid);
  const before=tree(invalid),backup=path.join(here,'volumes','refused-backup-'+id);
  const b=cliRun(id+'-backup','backup',invalid,backup);
  const sourceUnchanged=JSON.stringify(before)===JSON.stringify(tree(invalid));
  const runtime=openCopy(id+'-source-open',invalid),compiled=openCopy(id+'-compiled-open',invalid,true);
  const wrapper=wrappedInvalid(invalid,backupTemplate,'hash-consistent-'+id),wrapperBefore=tree(wrapper),destination=path.join(here,'volumes','refused-restore-'+id);
  const r=cliRun(id+'-restore','restore',wrapper,destination);
  const wrapperUnchanged=JSON.stringify(wrapperBefore)===JSON.stringify(tree(wrapper));
  const runtimeRefused=runtime.result?.storageAvailable===false || runtime.result?.thrown===true;
  const compiledRefused=compiled.result?.storageAvailable===false || compiled.result?.thrown===true;
  const result={id,backupCommand:b.id,backupExit:b.exit,backupNoReceipt:!b.out.includes('backup_verified'),backupDestinationAbsent:!fs.existsSync(backup),sourceUnchanged,runtime,compiled,restoreCommand:r.id,restoreExit:r.exit,restoreNoReceipt:!r.out.includes('restored_under_hold'),restoreDestinationAbsent:!fs.existsSync(destination),wrapperUnchanged,outerHashesRecomputed:true};
  cases.push(result); write('case-results.json',cases);
  check(id+'-backup-fails-before-success',b.exit===1 && !b.out.includes('backup_verified') && !fs.existsSync(backup) && sourceUnchanged);
  check(id+'-hash-consistent-restore-fails-before-success',r.exit===1 && !r.out.includes('restored_under_hold') && !fs.existsSync(destination) && wrapperUnchanged);
  if(expectedRuntime) check(id+'-runtime-equivalence',runtimeRefused && compiledRefused && runtime.result?.networkAttempts===0 && compiled.result?.networkAttempts===0);
  return {invalid,runtime,compiled};
}
try {
  assert.equal(process.versions.node.split('.')[0],'22');
  assert(inputHashesBefore.every(i=>i.expected===i.actual),'Authorized input fingerprint mismatch');
  assert.equal(sha(fs.readFileSync(path.join(authority,'approved-spec0179.md'))),packet.approvedSpecSha256);
  const healthy=path.join(here,'volumes','healthy'),minimal=path.join(here,'volumes','minimal');
  const seed=sourceProbe('seed-rich','seed',healthy,'rich');
  assert.equal(seed.exit,0,seed.err); const seedData=parsed(seed).at(-1); assert.equal(seedData?.status.storageAvailable,true);
  const small=sourceProbe('seed-minimal','seed',minimal,'minimal'); assert.equal(small.exit,0,small.err);
  for(const [id,volume] of [['rich',healthy],['minimal',minimal]]) {
    const before=tree(volume),backup=path.join(here,'volumes',id+'-backup'),restored=path.join(here,'volumes',id+'-restored');
    const baseline=openCopy(id+'-baseline',volume),compiledBaseline=openCopy(id+'-compiled-baseline',volume,true);
    check(id+'-source-compiled-projection-equivalence',baseline.result?.storageAvailable===true && JSON.stringify(baseline.result)===JSON.stringify(compiledBaseline.result));
    const b=cliRun(id+'-backup','backup',volume,backup),receipt=parsed(b).at(-1);
    check(id+'-backup',b.exit===0 && receipt?.status==='backup_verified' && JSON.stringify(before)===JSON.stringify(tree(volume)) && JSON.stringify(before)===JSON.stringify(tree(path.join(backup,'documents'))));
    const backupBefore=tree(backup),r=cliRun(id+'-restore','restore',backup,restored),rr=parsed(r).at(-1);
    check(id+'-restore',r.exit===0 && rr?.status==='restored_under_hold' && rr.effectsEnabled===false && JSON.stringify(before)===JSON.stringify(tree(restored)?.filter(d=>d.path!=='restore-hold.json')) && JSON.stringify(backupBefore)===JSON.stringify(tree(backup)));
    const opened=openCopy(id+'-restored-source-open',restored),bundleOpened=openCopy(id+'-restored-compiled-open',restored,true);
    check(id+'-restored-projections-identical',JSON.stringify(baseline.result?.projection)===JSON.stringify(opened.result?.projection) && JSON.stringify(opened.result)===JSON.stringify(bundleOpened.result));
    check(id+'-restored-hold-no-effects',opened.result?.storageAvailable===true && opened.result.operationalHold===true && opened.result.effectsAllowed===false && opened.result.networkAttempts===0 && bundleOpened.result.networkAttempts===0);
    check(id+'-private-destination',(fs.statSync(restored).mode&0o777)===0o700 && tree(restored).every(d=>d.mode===0o600));
    write(id+'-preservation.json',{before,sourceAfter:tree(volume),backupDocuments:tree(path.join(backup,'documents')),restored:tree(restored),backupBefore,backupAfter:tree(backup),baseline,compiledBaseline,opened,bundleOpened,receipt,restoreReceipt:rr});
  }
  const p=seedData.status.projection;
  check('rich-fixture-covers-state-contract',p.paused && p.notes.some(n=>n.state==='draft') && p.notes.some(n=>n.state==='confirmed') && p.notes.some(n=>n.state==='superseded') && p.tasks.some(t=>t.status==='done') && p.tasks.some(t=>t.generation===2) && p.tasks.some(t=>t.status==='cancelled') && p.inbox.some(i=>i.state==='retry_wait'&&i.transcript) && p.outbox.some(b=>b.state==='dispatching') && p.outbox.some(b=>b.state==='uncertain') && p.outbox.some(b=>b.state==='provider_accepted') && p.known.some(k=>k.id==='000701') && p.media.valid.length>0);
  const lock=sourceProbe('active-writer-exclusion','lock',healthy),lockData=parsed(lock).at(-1);
  check('active-writer-and-second-writer-refused',lock.exit===0 && lockData?.secondWriter==='STORE_LOCKED' && lockData.cli.exit===1 && lockData.lockUnchanged && !lockData.destinationExists);
  write('active-writer-exclusion.json',lockData);
  const residual=cp(minimal,'residual-lock'); fs.writeFileSync(path.join(residual,'store.lock'),'synthetic-residual-owned-test',{mode:0o600});
  const residualBefore=tree(residual),rl=cliRun('residual-lock','backup',residual,path.join(here,'volumes','residual-backup'));
  check('residual-lock-preserved',rl.exit===1 && JSON.stringify(residualBefore)===JSON.stringify(tree(residual)) && !fs.existsSync(path.join(here,'volumes','residual-backup')));
  const template=path.join(here,'volumes','minimal-backup');
  adversarial('missing-revision',minimal,template,root=>{const m=JSON.parse(fs.readFileSync(path.join(root,'journal/manifest.json'))); fs.unlinkSync(path.join(root,'journal/manifests/revision-'+m.revision+'.json'));});
  adversarial('divergent-revision',minimal,template,root=>{const m=JSON.parse(fs.readFileSync(path.join(root,'journal/manifest.json'))); fs.appendFileSync(path.join(root,'journal/manifests/revision-'+m.revision+'.json'),' ');});
  adversarial('prefix-checksum',minimal,template,root=>updateManifests(root,m=>{m.segments[0].bytes=1;m.segments[0].prefixSha256='0'.repeat(64);}));
  adversarial('transaction-checksum',minimal,template,root=>{const m=JSON.parse(fs.readFileSync(path.join(root,'journal/manifest.json'))),file=path.join(root,m.segments[0].path),tx=JSON.parse(fs.readFileSync(file));tx.sha256='0'.repeat(64);fs.writeFileSync(file,canon(tx)+'\n');});
  adversarial('unknown-event-correct-checksum',minimal,template,root=>rewriteTransactions(root,tx=>{tx.changes[0]={type:'offline_unknown_event',at:'2026-10-05T17:00:00.000Z'};}));
  adversarial('schema-invalid-known-event',minimal,template,root=>rewriteTransactions(root,tx=>{delete tx.changes[0].message.messageId;}));
  adversarial('reference-invalid-correct-checksum',minimal,template,root=>rewriteTransactions(root,tx=>{tx.changes[0]={type:'message_processed',at:'2026-10-05T17:00:00.000Z',messageId:'absent-invented-message'};}));
  adversarial('sequence-invalid-correct-checksum',minimal,template,root=>rewriteTransactions(root,tx=>{tx.seq=2;}));
  adversarial('missing-referenced-media',healthy,path.join(here,'volumes','rich-backup'),root=>{const media=p.media.valid[0].path;fs.unlinkSync(path.join(root,media));});
  adversarial('referenced-media-corrupted',healthy,path.join(here,'volumes','rich-backup'),root=>fs.appendFileSync(path.join(root,p.media.valid[0].path),Buffer.from([42])));
  adversarial('symlink-document',minimal,template,root=>fs.symlinkSync(path.join(minimal,'journal/manifest.json'),path.join(root,'synthetic-symlink')));
  // An unrecovered tail must be rejected offline, but ordinary local opening
  // is deliberately allowed to isolate it. Both openings use disposable copies.
  const tail=adversarial('unrecovered-tail',minimal,template,root=>{const m=JSON.parse(fs.readFileSync(path.join(root,'journal/manifest.json')));fs.appendFileSync(path.join(root,m.segments[0].path),'{"incomplete":');},false);
  check('unrecovered-tail-runtime-recovers-conservatively',tail.runtime.result?.storageAvailable===true && tail.compiled.result?.storageAvailable===true && tail.runtime.result.projection.sequence===2 && !tail.runtime.documentsUnchanged && !tail.compiled.documentsUnchanged);
  for(const id of ['extra','missing','tampered','symlink','escape','absolute','duplicate','missing-hash','identity','nonempty-destination']) {
    const backup=cp(template,'inventory-'+id),dest=path.join(here,'volumes','inventory-dest-'+id),mfile=path.join(backup,'manifest.json'),m=JSON.parse(fs.readFileSync(mfile));
    const f=path.join(backup,'documents',m.documents[0].path);
    if(id==='extra') fs.writeFileSync(path.join(backup,'documents','unlisted.bin'),'invented extra');
    if(id==='missing') fs.unlinkSync(f);
    if(id==='tampered') fs.appendFileSync(f,'invented tamper');
    if(id==='symlink') {fs.unlinkSync(f);fs.symlinkSync(path.join(minimal,m.documents[0].path),f);}
    if(id==='escape') m.documents[0].path='../outside';
    if(id==='absolute') m.documents[0].path=path.join(here,'volumes','outside');
    if(id==='duplicate') m.documents.push(m.documents[0]);
    if(id==='missing-hash') delete m.documents[0].sha256;
    if(id==='identity') m.journal.sequence++;
    if(id==='nonempty-destination') {fs.mkdirSync(dest,{mode:0o700});fs.writeFileSync(path.join(dest,'preserve.bin'),'invented keep',{mode:0o600});}
    fs.writeFileSync(mfile,JSON.stringify(m)+'\n');
    const before=tree(backup),destBefore=tree(dest),r=cliRun('inventory-'+id,'restore',backup,dest);
    check('inventory-'+id+'-refused',r.exit===1 && !r.out.includes('restored_under_hold') && JSON.stringify(before)===JSON.stringify(tree(backup)) && JSON.stringify(destBefore)===JSON.stringify(tree(dest)));
  }
} catch(e) {
  write('setup-or-run-failure.json',{name:e.name,message:e.message,stack:e.stack}); check('runner-completed',false,{message:e.message});
}
const inputHashesAfter=hashInputs();
write('input-hashes-after.json',inputHashesAfter);
check('authorized-inputs-stable',JSON.stringify(inputHashesBefore)===JSON.stringify(inputHashesAfter));
const results={finishedAt:new Date().toISOString(),node:process.execPath,nodeVersion:process.version,commands:commands.length,checks,cases:cases.length,pass:checks.filter(c=>c.status==='PASS').length,fail:checks.filter(c=>c.status==='FAIL').length};
write('results.json',results);
console.log(JSON.stringify(results,null,2));
process.exitCode=results.fail ? 1 : 0;
