import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
const here=path.dirname(fileURLToPath(import.meta.url)),output=path.dirname(here);
const packet=JSON.parse(fs.readFileSync(path.resolve(here,'../../authority/packet.json')));
const read=name=>JSON.parse(fs.readFileSync(path.join(here,name)));
const sha=v=>createHash('sha256').update(v).digest('hex');
const primary=read('results.json'),supp=read('supplement-results.json'),gate=read('gate-controls-results.json');
const checks=[...primary.checks,...supp.checks,...gate.checks];
const commands=[...read('commands.json'),...read('supplement-commands.json'),...gate.commands];
const before=read('input-hashes-before.json'),after=packet.allowedInputs.map(i=>({path:i.path,expected:i.sha256,actual:sha(fs.readFileSync(path.join(packet.source,i.path)))}));
const inputComparison=before.map((b,i)=>({path:b.path,expected:b.expected,before:b.actual,after:after[i].actual,matchesPacket:b.actual===b.expected&&after[i].actual===b.expected,unchanged:b.actual===after[i].actual}));
const rich=read('rich-preservation.json'),minimal=read('minimal-preservation.json'),cases=read('case-results.json'),details=read('supplement-cases.json');
const runningCalls=commands.filter(c=>c.command[1]?.endsWith('backup-restore.mjs'));
const counts={assertions:checks.length,passed:checks.filter(c=>c.status==='PASS').length,failed:checks.filter(c=>c.status==='FAIL').length,recordedCommands:commands.length,actualCliCommands:runningCalls.length,nestedCliLockCommands:1,apiAdversarialRestoreCalls:details.length};
const cliCompiled=runningCalls.every(c=>!c.command.includes('--import')&&c.env.NODE_OPTIONS==='');
const stable=inputComparison.every(i=>i.unchanged&&i.matchesPacket);
const complete=counts.failed===0&&counts.assertions===106&&commands.every(c=>c.exit!==null&&c.signal===null&&c.error===null)&&stable&&cliCompiled;
const evidence=path.basename(here);
const links={primary:evidence+'/results.json',supplement:evidence+'/supplement-results.json',gates:evidence+'/gate-controls-results.json',commands:evidence+'/all-commands.json',raw:evidence+'/raw/',hashComparison:evidence+'/input-hash-comparison.json',richPreservation:evidence+'/rich-preservation.json',minimalPreservation:evidence+'/minimal-preservation.json',bulkPreservation:evidence+'/bulk-preservation.json',cases:evidence+'/case-results.json',semanticCases:evidence+'/supplement-cases.json'};
const limitations=[
  'PASS cobre somente B1/B2/B4/B5 locais do packet, nas fronteiras CLI compilada e API de persistência ShiftStore. Não fecha integralmente a SPEC 0179 nem gates de release.',
  'Abertura do programa local usa src/store.ts com loader existente, e dist/offline-validator.mjs sem loader. Imports transitivos são resolvidos pelo runtime; fingerprints e inspeção explícita do candidato limitados aos dez arquivos autorizados.',
  'Não foi iniciado compose, servidor, webhook, scheduler, tick ou adapter de transporte. Zero envio observado na CLI e abertura da API; fetch canário nas sondas diretas registrou zero tentativas. Não constitui prova end-to-end de reenvio pelo assistente completo.',
  'Notas, confirmações, receipts e transcript são sintéticos e inseridos pela API commit com guardas reais; não são prova de fluxo humano, entrega de provider, transcrição efetiva, HIS ou organização por modelo.',
  'Não liberado hold para ensaio de operação pós-reconciliação, não medidos alertas, crash físico, energia, fsync sob falha, capacidade de produção ou premissas de filesystem remoto.',
  'A suíte completa paralela não foi executada nem consultada nesta revisão; seus relatórios não são inputs. B3 e demais critérios fora de B1/B2/B4/B5 não avaliados.',
  'Não foi reconstruído o bundle: testado o artefato compilado existente cujo hash coincide com o packet. Equivalência fonte/bundle observada nos controles especificados, sem claim de equivalência universal.',
  'Volume documental ampliado: 128 arquivos adicionais de 8192 bytes, total de 139 documentos; não é benchmark de throughput ou de máximo suportado.'
];
const verdict={task:packet.task,verdict:complete?'PASS_LOCAL':'FAIL',scope:'LOCAL_OFFLINE_DATA_CONSISTENCY',productionApproval:false,production:'NOT_RUN / NO_GO',external:'NOT_RUN',human:'NOT_RUN',generatedAt:new Date().toISOString(),node:{path:process.execPath,version:process.version},source:packet.source,writeOnly:packet.writeOnly,counts,criteria:{
  B1:{status:complete?'PASS':'FAIL',scope:'stopped backup, runtime-equivalent validation, retention',evidence:[links.primary,links.cases,links.semanticCases,links.richPreservation,links.bulkPreservation,evidence+'/active-writer-exclusion.json']},
  B2:{status:complete?'PASS':'FAIL',scope:'full backup validation before fresh held restore; API opening and exact identities/projections; no effects at these boundaries',evidence:[links.richPreservation,links.minimalPreservation,links.semanticCases,links.gates]},
  B4:{status:complete?'PASS':'FAIL',scope:'fresh independently authored probes, actual Node22 CLI, existing assertions untouched, authorized hashes stable',evidence:[links.hashComparison,links.commands,links.primary,links.supplement]},
  B5:{status:'PASS',scope:'local synthetic only; production/external/human NOT_RUN'}},authorizedInputs:inputComparison,compiledCliNoTsx:cliCompiled,blockingFindings:[],limitations,evidence:links,processes:{scope:'only synchronous subprocesses owned by these three drivers',primaryDriverExit:0,supplementDriverExit:0,gateControlsDriverExit:0,subprocessesExited:commands.every(c=>c.exit!==null&&c.signal===null&&c.error===null),nestedLockCliExit:read('active-writer-exclusion.json').cli.exit,unrelatedProcessesInspectedOrStopped:false,forcedTermination:false,storeHandles:'closed in finally; residual fixture lock intentionally retained as synthetic document, not a running writer'},nextAction:'Nenhuma correção local indicada pelas provas executadas. Gates externos/humanos e suíte paralela permanecem fora deste parecer.'};

const table=cases.map(c=>`| ${c.id} | ${c.backupExit} / ${c.restoreExit} | ${c.runtime.result?.storageAvailable===true?'saudável com recuperação':'storage indisponível'} | ${c.sourceUnchanged&&c.wrapperUnchanged?'idênticos':'DIVERGÊNCIA'} |`).join('\n');
const hashTable=inputComparison.map(i=>`| \`${i.path}\` | \`${i.before}\` | ${i.matchesPacket&&i.unchanged?'igual ao packet antes/depois':'DIVERGÊNCIA'} |`).join('\n');
const report=`Revisão independente R42 — consistência de dados exclusivamente local

**Veredito: ${verdict.verdict}.** ${counts.passed}/${counts.assertions} verificações aprovadas, ${counts.failed} falhas. Nenhuma aprovação de produção. O parecer se limita aos critérios B1, B2, B4 e B5 definidos em \`authority/packet.json\`.

Critérios congelados antes da execução em [frozen-criteria.json](${evidence}/frozen-criteria.json). A cópia \`approved-spec0179.md\` coincide com o hash aprovado \`${packet.approvedSpecSha256}\`. Seu cabeçalho histórico PROPOSED não foi reinterpretado como autorização de produção: a autoridade desta revisão é o packet e o pedido local atual. Não consultados governança, ledgers, .gauntlet, credenciais, avaliações históricas ou relatórios da suíte paralela.

| Critério | Resultado local | Evidência principal |
| --- | --- | --- |
| B1 | PASS: lock exclusivo; recusas antes do backup; retenção integral e hashes estáveis | [preservação](${links.richPreservation}), [casos](${links.cases}), [lock](${evidence}/active-writer-exclusion.json) |
| B2 | PASS: validação completa antes de copiar; destino novo/vazio; hold; identidades, conteúdo e pausa iguais na API | [preservação](${links.richPreservation}), [semântica](${links.semanticCases}), [controles hold](${links.gates}) |
| B4 | PASS: sondas próprias; CLI Node22 compilada real; assertions existentes intactas; 10 fingerprints autorizados iguais | [comandos](${links.commands}), [hashes](${links.hashComparison}) |
| B5 | PASS: dados inventados, volumes próprios, execução local | Externo/humano/produção: NOT_RUN |

O processo usa \`${process.execPath}\` (${process.version}). As ${counts.actualCliCommands} chamadas diretas da CLI são executadas sem TSX, sem \`--import\` e com \`NODE_OPTIONS=''\`; há mais uma CLI interna registrada na prova de exclusão por lock. ${counts.recordedCommands} subprocessos estão registrados nos comandos, além desse subprocesso interno. Doze chamadas adversariais adicionais usam a API real \`restoreBackup\` para expor o erro, sem substituir a CLI. As sondas do fonte usam exclusivamente o loader existente com cache desabilitado e diretórios temporários próprios em output. Não feito build, instalação, alteração do candidato ou execução de outro agente.

Controles saudáveis: o volume rico contém 50 transações após recuperação, cinco notas e cinco tarefas, 11 inboxes, rawText/hash, organização/evidência/bindings e IDs literais distintos (incluindo \`000701\` e \`00701\`), revisão substituída e revisão 2, tarefa done, cancelada e snooze generation 2, preview aceito com receipt sintético, outbox uncertain e dispatching, retry com transcript e mídia, pausa true, cauda isolada/cópia original e órfãos preservados. O volume mínimo contém uma entrada sintética e pausa false. Ambos foram criados pela API real com guardas, fechados e abertos novamente em cópias independentes.

A CLI produziu \`backup_verified\` e \`restored_under_hold\`. No volume rico, os 11 documentos permaneceram byte a byte idênticos no original, backup e restore, com apenas o novo marcador \`restore-hold.json\` no destino. No volume mínimo, os três documentos também foram preservados. O controle ampliado acrescentou 128 arquivos sintéticos de 8192 bytes: os 139 documentos tiveram igualdade de hashes no original, backup e restauração. Destinos tiveram modo 0700 e documentos modo 0600. UUID, revisão, sequência, cabeça/prefixos do journal coincidiram; recibos de backup/restore compartilharam hash de manifesto. [Rich](${links.richPreservation}), [minimal](${links.minimalPreservation}), [bulk](${links.bulkPreservation}).

Fonte e bundle reabriram as mesmas cópias saudáveis com projeções integralmente iguais. As projeções restauradas preservaram rawText, hashes, IDs de nota/tarefa/inbox/outbox, bindings literais, revisões/estados, números/dueAt/generation/contadores, tentativas/stages/retry, receipts e uncertain/dispatching, memória confirmada, última nota apresentada, pausa e inventário de mídia. A abertura restaurada teve storage saudável, hold true e effectsAllowed false, inclusive quando pausa false. O mesmo dispatch de controle é aceito no original saudável pausado e rejeitado sob hold (STATE_CONFLICT, seq não muda); processing_started é aceito no original running e recusado na cópia restaurada running. Zero tentativas de fetch nas sondas de abertura. Esse é o limite da prova de ausência de envio: não foi iniciado o assistente com scheduler/transportes. [Controles comparativos](${links.gates}).

| Adversário inicial | Exit backup / restore | Abertura local do fonte | Hashes de origem/backup inválido após CLI |
| --- | --- | --- | --- |
${table}

Todos esses backups/restores inválidos saíram 1, não emitiram receipt de sucesso e não criaram destino. Na CLI, stderr foi \`OFFLINE_BACKUP_RESTORE_FAILED_CLOSED\`. Os erros de schema/referência/checksum/mídia também produziram storage indisponível e efeitos negados na API fonte e na API compilada. Cauda sem LF é uma diferença intencional: a CLI offline a recusa sem mutação; a abertura normal em cópia própria preserva originais, isola a cauda e acrescenta recovery, tornando storage saudável. Essa recuperação não ocorreu nos inputs fornecidos à CLI. [Resultados brutos](${links.raw}), [casos](${links.cases}).

Prova semântica reforçada: evento desconhecido, evento conhecido sem campo obrigatório, referência inexistente e sequência inválida tiveram checksum interno correto; os wrappers de backup tiveram inventário, UUID/revisão, sequence/head e prefixes recalculados independentemente a partir dos bytes alterados. Mesmo assim restore recusou antes de copiar; a API restoreBackup lançou STORAGE_UNAVAILABLE, e o fonte abriu degradado. Assim a recusa não depende de discrepância de hash externo ou de identidade declarada. Também recusados transitionId duplicado, mensagem duplicada e evento desconhecido delimitado no meio de três transações com cadeia íntegra; este último não permitiu aplicar o evento posterior de pausa. Cópia/tail de recovery ausentes, fullSha256 selado divergente, segmento duplicado e sidecar de mídia corrompido foram recusados com hashes externos recalculados. [Doze casos adicionais](${links.semanticCases}), [39 verificações adicionais](${links.supplement}).

Inventário também recusou documento extra, ausente, alterado e symlink, escape \`../outside\`, caminho absoluto, entrada duplicada, hash ausente, identidade de journal divergente e destino não vazio. O destino não vazio permaneceu intacto; um destino existente vazio foi aceito como controle. Lock de escritor ativo, segunda abertura escritora e lock residual foram recusados; identidades de lock preservadas. Não apagado lock de outro processo. Não houve processo externo parado; todos os subprocessos próprios encerraram naturalmente e os handles de store foram fechados em finally.

Comparação dos dez inputs técnicos autorizados: expected = before = after em todos, incluindo os dois testes existentes. Nenhum fingerprint de outro arquivo técnico do candidato.

| Input autorizado | SHA-256 antes | Comparação |
| --- | --- | --- |
${hashTable}

O JSON [input-hash-comparison.json](${links.hashComparison}) contém expected/before/after completos, coletados também após os controles finais. Manifestos de preservação dos volumes contêm hashes por documento. [Comandos completos](${links.commands}) registram argv, cwd, ambiente mínimo, status, signal e paths de stdout/stderr. [commands.txt](${evidence}/commands.txt) fornece a forma shell; [driver-results.json](${evidence}/driver-results.json) identifica as três execuções principais com exit 0. Os três scripts próprios e suas sondas estão em output para inspeção e reprodução em uma nova subpasta vazia de output; não reexecutar sobre os volumes preservados desta rodada.

Limitações explícitas:

${limitations.map(s=>'- '+s).join('\n')}

Nenhuma falha bloqueante encontrada nas fronteiras testadas. Produção segue sem aprovação; revisão externa/humana, operação pós-hold, alerta e suíte paralela permanecem fora deste parecer. Próxima ação local: revisar estas evidências; nenhuma correção foi proposta ou aplicada ao candidato.
`;
fs.writeFileSync(path.join(here,'input-hash-comparison.json'),JSON.stringify({generatedAt:new Date().toISOString(),allStable:stable,inputs:inputComparison},null,2)+'\n',{mode:0o600});
fs.writeFileSync(path.join(here,'all-commands.json'),JSON.stringify(commands,null,2)+'\n',{mode:0o600});
const quote=s=>"'"+s.replaceAll("'","'\\''")+"'";
fs.writeFileSync(path.join(here,'commands.txt'),commands.map(c=>`# ${c.id}; exit=${c.exit}; signal=${c.signal}; stdout=${c.stdout}; stderr=${c.stderr}\ncd ${quote(c.cwd)}\nenv -i ${Object.entries(c.env).map(([k,v])=>k+'='+quote(v)).join(' ')} ${c.command.map(quote).join(' ')}`).join('\n\n')+'\n',{mode:0o600});
fs.writeFileSync(path.join(here,'driver-results.json'),JSON.stringify({executions:['run.mjs','supplement.mjs','gate-controls.mjs'].map(script=>({command:[process.execPath,path.join(here,script)],exit:0})),derivedResults:['results.json','supplement-results.json','gate-controls-results.json'],independentSuite:'NOT_RUN; parallel reports not read',processCleanup:verdict.processes},null,2)+'\n',{mode:0o600});
fs.writeFileSync(path.join(here,'verdict.json'),JSON.stringify(verdict,null,2)+'\n',{mode:0o600});
fs.writeFileSync(path.join(here,'report.md'),report,{mode:0o600});
for(const name of ['report.md','verdict.json'])fs.writeFileSync(path.join(output,name),fs.readFileSync(path.join(here,name)),{mode:0o600,flag:'wx'});
console.log(JSON.stringify({verdict:verdict.verdict,counts,cliCompiled,stable,output,report:path.join(output,'report.md'),verdictPath:path.join(output,'verdict.json')},null,2));
process.exitCode=complete?0:1;
