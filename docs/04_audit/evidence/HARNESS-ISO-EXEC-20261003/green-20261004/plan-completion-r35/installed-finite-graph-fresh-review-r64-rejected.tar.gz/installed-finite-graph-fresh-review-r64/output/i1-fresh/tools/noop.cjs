// Independent inert bootstrap tool, not a target.
