import pathlib,subprocess,json,time
O=pathlib.Path(__file__).resolve().parent; N='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node'
cmd=[N,str(O/'source/node_modules/vitest/vitest.mjs'),'run','--config',str(O/'vitest.i1.config.mjs'),'--configLoader','native','--reporter','json','--outputFile',str(O/'evidence/native-tests.json')]
env={'PATH':str(pathlib.Path(N).parent)+':/usr/bin:/bin','HOME':str(O/'cache'),'TMPDIR':str(O/'tmp'),'CVG_FINITE_GRAPH_PROOF_DIR':str(O/'native-test-artifacts')}
t=time.monotonic();r=subprocess.run(cmd,cwd=O/'source',env=env,text=True,capture_output=True,timeout=150)
(O/'evidence/native-run.json').write_text(json.dumps({'command':cmd,'cwd':str(O/'source'),'syntheticEnvironment':env,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'seconds':time.monotonic()-t},indent=2)+'\n');print(r.returncode,r.stdout,r.stderr)
