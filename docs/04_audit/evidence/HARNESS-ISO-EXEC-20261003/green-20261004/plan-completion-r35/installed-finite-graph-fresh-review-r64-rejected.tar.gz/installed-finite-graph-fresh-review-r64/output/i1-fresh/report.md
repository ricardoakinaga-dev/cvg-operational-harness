# R64_INSTALLED_FINITE_GRAPH_FRESH_REVIEW — crítico I1

Veredicto finito: **REJECT**, por R64-I1-F1 (P1). Autoridade exclusiva: `/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/installed-finite-graph-fresh-review-r64/authority/packet.json`. Node atual: v22.23.2. Os nove exactinputs, nas fontes da autoridade e nas cópias próprias, mantêm os hashes e tamanhos indicados pelo packet.

## Achado bloqueante

O CLI aceita `--no-experimental-require-module`, mas o subprocesso de resolução repassa apenas `--conditions`/`-C`. A condição nativa `module-sync` diverge entre processo avaliado e resolver. A política de bootstrap não recusa essa flag.

O fixture físico `fixtures/module-sync-context/node_modules/bridge/package.json` contém:

```json
{"name":"bridge","exports":{"module-sync":"./closed.cjs","require":"./acquire.cjs","default":"./closed.cjs"}}
```

`closed.cjs` contém `module.exports = 17;`. `acquire.cjs` contém `throw "NEVER_EXECUTE"; require("../../products/product/marker.js");`. O target nunca foi executado; o scanner deve preservar a referência negativa explícita, inclusive depois do throw.

| Controle/oráculo | Resultado |
|---|---|
| CLI sem flag | PASS; ambos modos em closed.cjs |
| CLI com `--no-experimental-require-module` | **PASS, exit 0, diagnostics [], PROVED/sealed**, ainda ambos em closed.cjs |
| Node resolve-only com a mesma flag | require → **acquire.cjs**; import → closed.cjs |
| CLI com ramo require explicitamente fixado em acquire.cjs, mesma flag | **FAIL / VIOLATION**, UNKNOWN retido |
| CLI com condição própria institution-test selecionando aquisição | FAIL; condição explícita corretamente propagada |

O selo positivo cobre o arquivo errado e omite uma aresta física real para o produto. Isso refuta G1 e G3 sem ampliar o grafo e sem carregar nenhum payload. Localizações técnicas: `source/scripts/check-product-boundary.mjs:478` e `source/scripts/boundary-installed-obligations.mjs:222`. Correção esperada: recusar esse contexto como UNKNOWN, ou preservar suas condições nativas e inspecionar o successor realmente selecionado. Não foi feita correção no source.

Evidências discriminantes: `evidence/module-sync-disabled.json`, `evidence/module-sync-disabled.proof.json`, `evidence/oracle-module-sync-disabled.json`, `evidence/module-sync-default.json`, `evidence/oracle-module-sync-default.json`, `evidence/module-sync-forced-require.json` e `evidence/custom-conditions.json`. Comandos completos, stdout/stderr, exits, hashes físicos antes/depois e recibos estão nos JSONs; `rawcommands.json` indexa esses comandos.

## G1–G4

| Gate | Avaliação finita | Evidência e limite |
|---|---|---|
| G1 | REJECT | Folhas CJS/ESM/TS, dois modos distintos, quatro campos e oito declarações de aliases, transitivos/nested/census positivos funcionam; F1 omite um target modal real. |
| G2 | ACCEPT nos controles materializados | SCC completo sela; UNKNOWN local, saída ausente e transitivos contaminam ancestrais; VIOLATION domina mantendo UNKNOWN. Não prova targets que F1 deixou fora do grafo. |
| G3 | REJECT | Bootstrap separado/API e flags recusadas funcionam; F1 quebra a equivalência do CLI Node22 atual. Gramáticas negativas permanecem bloqueantes. |
| G4 | ACCEPT nos controles finitos | Hashes das fontes/cópias exatos; mudanças próprias de bytes, manifest, census, target e ausência de lookup detectadas; limite direto mantém UNKNOWN. Não constitui orçamento global de recursos. |

## Controles físicos e sete famílias negativas

Foram registradas **70 execuções próprias** de checker/API instrumentada, além de oráculos resolve-only/`--check`, um probe direto do motor de prova e **50/50 testes** do único arquivo copiado `installed-finite-graph.test.js`. Vitest usa `--configLoader native`, config própria, cache próprio, um worker e symlink declarado somente para ferramentas R25. O resultado verde desses testes não supera o contraexemplo independente.

| Família negativa própria | Exercícios |
|---|---|
| N1 gramática/aquisição | eval, loader customizado, dlopen, worker, alias require, chamadas/leitura de binding, loop, getter, computed/prototype, shadow module, anotação TS |
| N2 declarações ausentes | local ausente em nested metadata nos quatro campos; registry ausente na saída de SCC |
| N3 identidade modal | require/import/both nulos; import desconhecido com require neutro; fragmento URL |
| N4 endpoint/format | package.json ausente, bytes nativos e destino físico estrangeiro |
| N5 metadata/census | nested manifest malformado; frontier nested/census desconhecido |
| N6 lookup/identidade | instalação próxima shadow com código desconhecido; symlink físico recusado |
| N7 violação real | aquisição direta e por alias do produto; SCC com VIOLATION e UNKNOWN simultâneos |

Todos esses negativos em contexto default materializado bloqueiam. F1 pertence à cobertura independente de flags/condições e permanece bloqueante na revisão. `assessments.json` conserva a interpretação das expectativas exploratórias que não bateram: as formas concatenadas `-rPATH`/`-r=PATH` são rejeitadas pelo próprio Node antes do checker; não são bugs do produto. `export const await = 1` em .ts recebe certificado e Node `--check` .ts retorna 0; a projeção exata .mjs falha. Essa observação de contexto TS/ESM fica limitada ao que foi medido e não é contada como outro falso negativo de aquisição.

Os cinco probes de mutação em processo usam wrapper API próprio que altera **somente fixtures próprios** via hooks de filesystem, mantendo o checker copiado exato. A API já é UNKNOWN por bootstrap; portanto a prova de detecção usa motivos específicos: BYTES_CHANGED_BEFORE_SEAL, MANIFEST_SNAPSHOT_UNKNOWN_OR_CHANGED, CENSUS_CHANGED, SNAPSHOT_REVALIDATION_ERROR e LOOKUP_ABSENCE_CHANGED. A expectativa inicial para o motivo da mutação de manifest estava errada; o motivo efetivamente observado bloqueia antes do selo e fica preservado sem reescrever o raw.

## Limites e integridade

O probe direto de grafo com âncoras físicas produz 20.001 nós, um frontier não expandido, FINITE_FRONTIER_LIMIT/UNEXPANDED_FRONTIER e zero discharge, em aproximadamente 362 ms no motor (heap observado ~89,6 MB). É um probe unitário direto, sujeito também ao contexto API não suportado, não um stress do CLI inteiro. O counter limita expansão de prova a 20.000 iterações; não limita todas as declarações pré-construídas, descoberta/census recursivos ou número total de subprocessos. Resolver tem timeout 30 s/buffer 16 MiB por lote; native check tem timeout 10 s/buffer 1 MiB por arquivo. Nosso harness impõe timeout 35 s por controle e 150 s à execução estreita de Vitest. Nenhum desconhecido de whole/global closure foi convertido em PASS.

Houve **ENOSPC do host**, com saída literal `cat: write error: No space left on device`, ao gravar script próprio opcional. A falha e o arquivo parcial zero bytes foram registrados em `evidence/host-enospc.json`; não são achados do produto. Foi feita somente compressão sem perda de evidência própria do limite (`evidence/limit.proof.json.gz`, hash descomprimido em `evidence/limit-compression.json`). O lead depois informou recuperação de espaço. Fontes, cópias técnicas e conteúdo dos proofs permanecem íntegros.

`hash-before.json` e `hash-after.json` verificam os nove exactinputs. Os controles guardam inventário antes/depois; somente os cinco fixtures de mutação intencional mudaram durante uma inspeção. Nenhum target foi importado/executado para justificar neutralidade. Nenhum arquivo do repositório compartilhado foi alterado; não houve leitura de docs, rationale/builder, histórico, críticas anteriores ou Rootwalker, nem fullsuite/wholeclosure/provider/private env/network/PG/Docker/descendentes. Ambiente de filhos foi sintético e local, sem inspeção de conteúdo de ambiente privado.

`findings.json`, `verdict.json`, `controls.json`, `rawcommands.json`, `manifest.json` e `freeze.json` tornam o resultado revisável e congelado. O manifest não percorre o symlink tools-only. Não há conclusão de isolamento global, release ou produção.
