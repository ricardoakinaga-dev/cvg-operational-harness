# Load independent harness definitions only; do not rerun the earlier controls.
exec(open('review.py').read().split('# Independent grammar and modal controls.')[0].replace('E.mkdir(); F=O/\'fixtures\'; F.mkdir(); T=O/\'tools\'; T.mkdir(); (O/\'cache\').mkdir(); (O/\'tmp\').mkdir()',"E.mkdir(exist_ok=True); F=O/'fixtures'; F.mkdir(exist_ok=True); T=O/'tools'; T.mkdir(exist_ok=True); (O/'cache').mkdir(exist_ok=True); (O/'tmp').mkdir(exist_ok=True)").replace('results=[]',"results=json.loads((O/'controls.json').read_text())"))
r=fixture('module-sync-context')
put(r,'node_modules/bridge/package.json',{'name':'bridge','exports':{'module-sync':'./closed.cjs','require':'./acquire.cjs','default':'./closed.cjs'}})
put(r,'node_modules/bridge/closed.cjs','module.exports = 17;')
put(r,'node_modules/bridge/acquire.cjs','throw "NEVER_EXECUTE"; require("../../products/product/marker.js");')
run('module-sync-default',r,'PASS',family='G3 paired mode/context')
run('module-sync-disabled',r,'FAIL|INCOMPLETE',flags=['--no-experimental-require-module'],family='G3 discriminating counterexample')
oracle=put(T,'resolve-oracle.mjs','import {createRequire} from "node:module"; import {pathToFileURL} from "node:url"; const file=process.argv[2]; const key=process.argv[3]; console.log(JSON.stringify({runtime:process.version,execArgv:process.execArgv,require:createRequire(file).resolve(key),import:import.meta.resolve(key,pathToFileURL(file).href)}));')
for label,flags in [('default',[]),('disabled',['--no-experimental-require-module'])]:
 cmd=[NODE,*flags,'--experimental-import-meta-resolve',str(oracle),str(r/'packages/core/package.json'),'bridge']; t=time.monotonic(); p=subprocess.run(cmd,cwd=O/'source',env=ENV,text=True,capture_output=True,timeout=10)
 (E/('oracle-module-sync-'+label+'.json')).write_text(json.dumps({'command':cmd,'raw':{'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr},'seconds':time.monotonic()-t,'targetExecuted':False},indent=2)+'\n');print(label,p.stdout)
# Paired actual Node grammar checks for JS in isolation never load payloads.
for ext,mode,code in [('js','commonjs','"use strict"; const eval = 1;'),('mjs','module','export default 1; export default 2;'),('ts','module','export const await = 1;')]:
 r=fixture('native-grammar-'+ext,ext,mode,code);run(r.name,r,'INCOMPLETE|ERROR',family='G3 native grammar')
 cmd=[NODE,'--check',str(r/('node_modules/bridge/entry.'+ext))];p=subprocess.run(cmd,cwd=O/'source',env=ENV,text=True,capture_output=True,timeout=10);(E/('oracle-grammar-'+ext+'.json')).write_text(json.dumps({'command':cmd,'raw':{'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr},'targetExecuted':False},indent=2)+'\n')
