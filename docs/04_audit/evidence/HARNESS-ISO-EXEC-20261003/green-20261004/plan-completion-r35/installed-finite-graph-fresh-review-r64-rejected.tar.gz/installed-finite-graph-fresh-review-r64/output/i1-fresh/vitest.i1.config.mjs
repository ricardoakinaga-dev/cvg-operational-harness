export default {
 root: new URL('./source/', import.meta.url).pathname,
 cacheDir: new URL('./cache/vite/', import.meta.url).pathname,
 test: {
  include: ['tests/installed-finite-graph.test.js'],
  environment: 'node',
  maxWorkers: 1,
  fileParallelism: false,
  testTimeout: 30000,
  attachmentsDir: new URL('./evidence/attachments/', import.meta.url).pathname,
 }
}
