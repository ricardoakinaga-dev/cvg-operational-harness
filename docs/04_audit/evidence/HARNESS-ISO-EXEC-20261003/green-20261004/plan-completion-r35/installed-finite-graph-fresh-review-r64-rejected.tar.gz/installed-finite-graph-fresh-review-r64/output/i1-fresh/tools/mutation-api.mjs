import fs from 'node:fs';
import path from 'node:path';
import {auditProductBoundary} from '../source/scripts/check-product-boundary.mjs';
const root=process.argv[2], kind=process.argv[3];
const entry=path.join(root,'node_modules/bridge/entry.js');
const manifest=path.join(root,'node_modules/bridge/package.json');
const dir=path.join(root,'node_modules/bridge');
const read=fs.readFileSync, list=fs.readdirSync;
let reads=0,lists=0,mutated=false;
fs.readFileSync=function(file,...args){
 const b=read.call(this,file,...args);
 if(String(file)===(kind==='manifest'?manifest:entry) && ++reads===2){
  if(kind==='bytes')fs.writeFileSync(entry,'eval("changed after code snapshot");');
  if(kind==='manifest')fs.writeFileSync(manifest,JSON.stringify({name:'bridge',main:'entry.js',dependencies:{absent:'*'}}));
  if(kind==='missing')fs.unlinkSync(entry);
  if(kind==='absence'){
   const shadow=path.join(root,'packages/core/node_modules/bridge');fs.mkdirSync(shadow,{recursive:true});fs.writeFileSync(path.join(shadow,'package.json'),JSON.stringify({name:'bridge',main:'entry.js'}));fs.writeFileSync(path.join(shadow,'entry.js'),'eval("never execute new shadow")');
  }
  mutated=kind!=='census';
 }
 return b;
};
fs.readdirSync=function(file,...args){
 if(String(file)===dir && ++lists===2 && kind==='census'){
  const nested=path.join(dir,'added');fs.mkdirSync(nested);fs.writeFileSync(path.join(nested,'package.json'),JSON.stringify({name:'added',dependencies:{absent:'*'}}));mutated=true;
 }
 return list.call(this,file,...args);
};
const audit=auditProductBoundary(root);
console.log(JSON.stringify({...audit,installedProof:audit.installedProof,ownInstrumentation:{kind,mutated,reads,lists}}));
