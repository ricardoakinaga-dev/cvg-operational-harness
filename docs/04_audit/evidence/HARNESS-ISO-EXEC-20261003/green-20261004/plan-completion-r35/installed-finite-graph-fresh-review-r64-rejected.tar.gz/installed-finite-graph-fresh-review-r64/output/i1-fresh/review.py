import pathlib,json,hashlib,subprocess,time,os
O=pathlib.Path(__file__).resolve().parent
NODE='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node'
CHECK=str(O/'source/scripts/check-product-boundary.mjs')
E=O/'evidence'; E.mkdir(); F=O/'fixtures'; F.mkdir(); T=O/'tools'; T.mkdir(); (O/'cache').mkdir(); (O/'tmp').mkdir()
# Explicit child environment is synthetic; no ambient environment contents are read/logged.
ENV={'PATH':str(pathlib.Path(NODE).parent)+':/usr/bin:/bin','HOME':str(O/'cache'),'TMPDIR':str(O/'tmp')}
results=[]
def put(root,p,v):
 f=root/p; f.parent.mkdir(parents=True,exist_ok=True); f.write_text(v if isinstance(v,str) else json.dumps(v)); return f
def fixture(label,ext='js',mode='commonjs',code=None):
 r=F/label; r.mkdir()
 put(r,'package.json',{'workspaces':['packages/*','products/*']})
 put(r,'packages/core/package.json',{'name':'@independent/core','dependencies':{'bridge':'*'}})
 put(r,'packages/core/index.ts','export const control = 7;')
 put(r,'products/product/package.json',{'name':'@independent/product'})
 put(r,'products/product/marker.js','throw "TARGET_MUST_NEVER_EXECUTE";')
 put(r,'node_modules/bridge/package.json',{'name':'bridge','type':mode,'main':'entry.'+ext})
 put(r,'node_modules/bridge/entry.'+ext,code or ('export const answer = 9;' if mode=='module' else 'module.exports = 9;'))
 return r
def inventory(root):
 rows=[]
 def walk(p):
  for f in sorted(p.iterdir()):
   if f.is_symlink(): rows.append({'path':str(f.relative_to(root)),'symlink':os.readlink(f)})
   elif f.is_dir():walk(f)
   else:
    b=f.read_bytes();rows.append({'path':str(f.relative_to(root)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 walk(root);return rows
def run(label,r,expected,flags=[],family='control',args=None,mutation=False):
 before=inventory(r); proof=E/(label+'.proof.json'); cmd=[NODE,*flags,CHECK,str(r)] if args is None else [NODE,*args]
 env=dict(ENV,CVG_INSTALLED_OBLIGATION_PROOF_FILE=str(proof)); start=time.monotonic()
 try:
  p=subprocess.run(cmd,cwd=O/'source',env=env,text=True,capture_output=True,timeout=35); raw={'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
 except subprocess.TimeoutExpired as e:raw={'exit':None,'stdout':str(e.stdout),'stderr':str(e.stderr),'timeout':True}
 after=inventory(r); audit=None; report=None
 try:audit=json.loads(raw['stdout'])
 except:pass
 if proof.exists():report=json.loads(proof.read_text())
 if audit and 'installedProof' in audit:report=audit.pop('installedProof')
 observed=audit.get('status') if audit else 'ERROR'
 row={'label':label,'family':family,'expected':expected,'observed':observed,'matches':observed in expected.split('|'),'seconds':round(time.monotonic()-start,3),'unchanged':before==after,'intentionalMutation':mutation,'obligations':[(x['status'],len(x['unknown']),len(x['violations'])) for x in (report or {}).get('obligations',[])],'nodeCount':(report or {}).get('nodeCount')}
 record={'summary':row,'command':cmd,'cwd':str(O/'source'),'syntheticEnvironment':env,'raw':raw,'before':before,'after':after,'audit':audit,'proof':report,'targetExecution':'never imported or executed; checker AST/Node --check/resolver only','sentinelAbsent':not (r/'EXECUTED').exists()}
 (E/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n');results.append(row);(O/'controls.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
 return record

def pkg(r,p,name='successor',deps=None,code='module.exports = 10;'):
 put(r,p+'/package.json',{'name':name,'main':'entry.js',**({'dependencies':deps} if deps else {})});put(r,p+'/entry.js',code)

# Independent grammar and modal controls.
for ext,mode,code in [('cjs','commonjs','"use strict"; const scalar = 1; module.exports = 2;'),('mjs','module','export const answer = 2; export default null;'),('js','commonjs','throw "FINITE_PRIMITIVE_THROW";'),('ts','module','export const answer = 2;')]:
 r=fixture('grammar-'+ext,ext,mode,code);run('grammar-'+ext,r,'PASS',family='G1-G3 positive grammar')
for name,code in [('typed','export const x: number = 1;'),('binding-read','const x = 1; const y = x;'),('module-shadow','const module = 1; module.exports = 2;'),('computed','module["exports"] = 1;'),('prototype','Object.prototype.exports = 1;'),('getter','const x = {get y(){return 1}}; x.y;'),('loop','for (;;) {}'),('native-load','process.dlopen(module,"x.node")'),('dynamic','eval("throw 1")'),('factory','require("node:module").register("./loader.mjs")'),('worker','new (require("node:worker_threads").Worker)("x")'),('alias','const acquire = require; acquire("./absent.js")')]:
 r=fixture('grammar-neg-'+name,'ts' if name=='typed' else 'js','module' if name=='typed' else 'commonjs',code);run('grammar-neg-'+name,r,'INCOMPLETE',family='N1 unsupported acquisition/grammar')
# Distinct mode identities and flag propagation.
r=fixture('modes-distinct');put(r,'node_modules/bridge/package.json',{'name':'bridge','exports':{'require':'./entry.js','import':'./import.mjs'}});put(r,'node_modules/bridge/import.mjs','export default 11;');run('modes-distinct',r,'PASS',family='G1 modes')
put(r,'node_modules/bridge/import.mjs','eval("do not run");');run('modes-distinct-unknown',r,'INCOMPLETE',family='N3 mode identity')
for m in ['require','import','both']:
 r=fixture('null-'+m);put(r,'node_modules/bridge/package.json',{'name':'bridge','exports':'./absent.js' if m=='both' else {('import' if m=='require' else 'require'):'./entry.js'}});run('null-'+m,r,'INCOMPLETE',family='N3 null modes')
for flag in ['--preserve-symlinks','--experimental-default-type=module','--experimental-transform-types']:
 r=fixture('flag-'+flag.split('=')[0][2:]);run(r.name,r,'INCOMPLETE',flags=[flag],family='G3 runtime flags')
noop=put(T,'noop.cjs','// Independent inert bootstrap tool, not a target.\n')
for name,flags in [('require-long',['--require',str(noop)]),('require-short',['-r',str(noop)]),('require-attached',['-r'+str(noop)]),('require-equals',['-r='+str(noop)])]:
 r=fixture('bootstrap-'+name);run(r.name,r,'INCOMPLETE',flags=flags,family='G3 bootstrap')
r=fixture('flag-no-require-esm','mjs','module');run(r.name,r,'INCOMPLETE',flags=['--no-experimental-require-module'],family='G3 flag semantics')
r=fixture('api-context');wrapper=put(T,'api.mjs','import {auditProductBoundary} from '+json.dumps(pathlib.Path(CHECK).as_uri())+'; const a=auditProductBoundary(process.argv[2]); console.log(JSON.stringify({...a,installedProof:a.installedProof}));');run(r.name,r,'INCOMPLETE',args=[str(wrapper),str(r)],family='G3 API host')
# All declarations, aliases, nearest shadows, and recursive metadata.
fields=['dependencies','devDependencies','optionalDependencies','peerDependencies']
r=fixture('fields-aliases');put(r,'packages/core/package.json',{'name':'@independent/core',**{f:{'bridge':'npm:actual@^1','alias':'npm:actual@^2'} for f in fields}});pkg(r,'node_modules/alias','actual');run(r.name,r,'PASS',family='G1 all declarations/aliases')
r=fixture('nearest-shadow');pkg(r,'packages/core/node_modules/bridge','bridge',code='eval("never executed")');run(r.name,r,'INCOMPLETE',family='N6 nearest shadow')
for shape in ['hoisted','nested','census']:
 r=fixture('transitive-'+shape)
 if shape=='census':put(r,'node_modules/bridge/inner/package.json',{'name':'inner','optionalDependencies':{'successor':'*'}})
 else:put(r,'node_modules/bridge/package.json',{'name':'bridge','main':'entry.js','dependencies':{'successor':'*'}})
 p='node_modules/successor' if shape=='hoisted' else 'node_modules/bridge/node_modules/successor';pkg(r,p);run(r.name,r,'PASS',family='G1 transitive/census');put(r,p+'/entry.js','while(true) {}');run(r.name+'-unknown',r,'INCOMPLETE',family='G2 transitive propagation')
for blocker in ['none','local','exit','violation']:
 r=fixture('scc-'+blocker);put(r,'node_modules/bridge/package.json',{'name':'bridge','main':'entry.js','dependencies':{'successor':'*'}})
 pkg(r,'node_modules/successor',deps={'bridge':'*',**({'absent':'*'} if blocker=='exit' else {})},code=('while(true) {}' if blocker=='local' else 'const take = require; take("../../products/product/marker.js");' if blocker=='violation' else 'module.exports = 10;'))
 run(r.name,r,'PASS' if blocker=='none' else 'FAIL' if blocker=='violation' else 'INCOMPLETE',family='G2 SCC')
for field in fields:
 r=fixture('missing-nested-'+field);put(r,'node_modules/bridge/inner/package.json',{'name':'inner',field:{'absent':'file:./absent'}});run(r.name,r,'INCOMPLETE',family='N2 unresolved nested local')
r=fixture('jsonless');(r/'node_modules/bridge/package.json').unlink();put(r,'node_modules/bridge/index.js','module.exports = 4;');run(r.name,r,'INCOMPLETE',family='N4 JSONless')
r=fixture('native','node',code='SYNTHETIC_NATIVE_BYTES');run(r.name,r,'INCOMPLETE',family='N4 native')
r=fixture('foreign');foreign=put(F,'outside.cjs','module.exports = 11;');put(r,'node_modules/bridge/package.json',{'name':'bridge','main':str(foreign)});run(r.name,r,'INCOMPLETE',family='N4 foreign')
r=fixture('url-context');put(r,'node_modules/bridge/package.json',{'name':'bridge','exports':{'require':'./entry.js','import':'./entry.js#is-distinct'}});run(r.name,r,'INCOMPLETE',family='N3 URL identity')
r=fixture('malformed-census');put(r,'node_modules/bridge/inner/package.json',{'name':'inner','dependencies':['invalid']});run(r.name,r,'ERROR',family='N5 malformed census metadata')
r=fixture('symlink');entry=r/'node_modules/bridge/entry.js';entry.rename(entry.with_suffix('.physical'));entry.symlink_to('entry.physical');run(r.name,r,'ERROR',family='N6 physical symlink')
r=fixture('product-direct',code='throw "NO_EXECUTION"; require("../../products/product/marker.js");');run(r.name,r,'FAIL',family='N7 product violation')
r=fixture('product-alias',code='const get = require; get("../../products/product/marker.js");');run(r.name,r,'FAIL',family='N7 alias product violation')
# Byte/census/target changes between separate actual CLI scans.
r=fixture('mutation');run('mutation-baseline',r,'PASS',family='G4 mutation');put(r,'node_modules/bridge/entry.js','eval("changed")');run('mutation-byte',r,'INCOMPLETE',family='G4 mutation');put(r,'node_modules/bridge/entry.js','module.exports = 9;');put(r,'node_modules/bridge/new/package.json',{'name':'new','dependencies':{'absent':'*'}});run('mutation-census',r,'INCOMPLETE',family='G4 mutation');(r/'node_modules/bridge/new/package.json').unlink();(r/'node_modules/bridge/entry.js').unlink();run('mutation-target',r,'INCOMPLETE',family='G4 mutation')
