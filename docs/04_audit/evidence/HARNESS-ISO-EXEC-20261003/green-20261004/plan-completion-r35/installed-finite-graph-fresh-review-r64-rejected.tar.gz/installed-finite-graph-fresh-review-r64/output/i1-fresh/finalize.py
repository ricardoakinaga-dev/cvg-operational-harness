import pathlib,json,hashlib,gzip,datetime,os
O=pathlib.Path(__file__).resolve().parent;A=O/'authority.json';a=json.loads(A.read_text());authority=pathlib.Path(a['source']).parent
rows=[]
for e in a['inputs']:
 origin=authority/e['path']; copy=O/e['path']; b=origin.read_bytes(); c=copy.read_bytes(); rows.append({'path':e['path'],'authorityAfterSha256':hashlib.sha256(b).hexdigest(),'copyAfterSha256':hashlib.sha256(c).hexdigest(),'bytes':len(b),'authorityUnchanged':hashlib.sha256(b).hexdigest()==e['sha256'] and len(b)==e['bytes'],'copyExact':b==c})
assert all(r['authorityUnchanged'] and r['copyExact'] for r in rows)
(O/'hash-after.json').write_text(json.dumps(rows,indent=2)+'\n')
controls=json.loads((O/'controls.json').read_text()); native=json.loads((O/'evidence/native-tests.json').read_text())
failed=[r for r in controls if not r['matches']]
# Refine exploratory expectations without rewriting their raw records.
assessments=[]
for r in failed:
 label=r['label']
 if label.startswith('bootstrap-require-attached') or label.startswith('bootstrap-require-equals'):
  disposition='Node rejects this spelling before checker bootstrap; blocking control, no product finding.'
 elif label=='flag-no-require-esm':
  disposition='Exploratory context mismatch; resolve-only proof alone does not establish loadability. Replaced by discriminating module-sync conditional-export counterexample R64-I1-F1.'
 elif label=='native-grammar-ts':
  disposition='TypeScript parser/CLI certifies reserved binding while Node --check on .ts also returns 0; identical native ESM projection fails --check. Record as unproved source-ts format/loadability observation, not a second boundary-acquisition finding.'
 else:disposition='Confirmed blocking false PASS R64-I1-F1.'
 assessments.append({'label':label,'disposition':disposition})
manifest_mut=json.loads((O/'evidence/inflight-manifest.assertion.json').read_text());assessments.append({'label':'inflight-manifest','disposition':'Original expected late byte-change reason did not match; actual MANIFEST_SNAPSHOT_UNKNOWN_OR_CHANGED detects mutation before seal. Raw assertion retained; host/API UNKNOWN is not used as mutation evidence.','observedReason':'MANIFEST_SNAPSHOT_UNKNOWN_OR_CHANGED'})
(O/'assessments.json').write_text(json.dumps(assessments,indent=2)+'\n')
(O/'evidence/host-enospc.json').write_text(json.dumps({'classification':'HOST_ENOSPC_NOT_PRODUCT','rawToolResult':{'chunk_id':'45f45b','exit_code':0,'output':'cat: write error: No space left on device\n','wall_time_seconds':0.000022713},'failedOperation':'cat > finish-probes.py (own optional discriminating-control script) via heredoc; followed by python3 finish-probes.py > finish-progress.txt','observedPartialArtifact':'finish-probes.py was zero bytes, verified by wc -c; rewritten only after own space recovery','spaceObservation':'/dev/nvme0n1p2 916G 869G 6.6M 100%','ownRecovery':'Lossless gzip of evidence/limit.proof.json; compression hashes retained. No authority/source/proof byte edits.','userSteering':'Host ENOSPC during lead R56 coverage; lead reported own cleanup recovery. Preserve own failures and do not attribute to product. No broadened scope.'},indent=2)+'\n')
findings=[{'id':'R64-I1-F1','severity':'P1','criteria':['G1','G3'],'title':'Finite installed proof seals the wrong conditional successor under --no-experimental-require-module','sourceLocations':[{'path':'source/scripts/check-product-boundary.mjs','line':478},{'path':'source/scripts/boundary-installed-obligations.mjs','line':222}],'trigger':'Actual Node22 CLI checker launched with --no-experimental-require-module; installed package exports insertion order module-sync, require, default.','fixture':'fixtures/module-sync-context','actualCLI':'evidence/module-sync-disabled.json','oracle':'evidence/oracle-module-sync-disabled.json','defaultControl':'evidence/module-sync-default.json','forcedBranchControl':'evidence/module-sync-forced-require.json','observed':'CLI exit 0 PASS, diagnostics [], obligation PROVED/sealed; both stored mode targets closed.cjs. Actual flag-identical resolve-only Node oracle selects acquire.cjs for require, closed.cjs for import. acquire.cjs contains explicit product require; forcing that same require branch returns FAIL/VIOLATION with UNKNOWN retained.','cause':'resolveRuntime forwards only custom conditions into resolver child, losing --no-experimental-require-module and its built-in module-sync condition semantics; runtime context policy does not reject this flag.','impact':'Positive code and transitive/metadata proof covers a different successor from actual require; product edge disappears from finite graph despite installed certificate claiming PROVED. No target execution was required.','expected':'Reject unsupported resolver-affecting context as UNKNOWN or preserve native context faithfully and inspect actual successor; never seal/discharge this obligation while an actual modal target remains unexamined.','scope':'finite physical synthetic installed package only; no global isolation/release claim'}]
(O/'findings.json').write_text(json.dumps(findings,indent=2)+'\n')
criteria={'G1':{'verdict':'REJECT','basis':'Positive leaves, all four fields/eight aliases, distinct modes, physical transitive/nested/census controls pass; F1 invalidates all-target completeness for admitted flag context.'},'G2':{'verdict':'ACCEPT','basis':'Finite SCC complete, local UNKNOWN, missing-exit UNKNOWN, transitive UNKNOWN, product VIOLATION with retained UNKNOWN; seven negative families blocking in sampled default CLI contexts. F1 means this does not validate unmaterialized targets.'},'G3':{'verdict':'REJECT','basis':'F1 demonstrated with current Node22 actual CLI and flag-identical resolve-only oracle. CJS/ESM/TS grammar and supported bootstrap checks sampled; source-ts projection caveat recorded separately.'},'G4':{'verdict':'ACCEPT','basis':'All nine authority/copy exactinputs unchanged. Byte, manifest, census, missing-target and negative-lookup in-flight reasons detected, separate CLI mutations block. Direct proof-engine 20001-node limit probe yields FINITE_FRONTIER_LIMIT and UNEXPANDED_FRONTIER, no discharge.','limits':'Acceptance limited to these finite controls. Direct limit probe is not CLI whole-closure stress; no global time/memory/input budget proven. Existing upstream recursive discovery/metadata and pre-limit declaration construction are not capped by the proof expansion counter.'}}
verdict={'task':a['task'],'critic':'I1 fresh readonly','verdict':'REJECT','scope':a['scope'],'authority':str(authority/'packet.json'),'criteria':criteria,'blockingFindings':['R64-I1-F1'],'ownControls':len(controls),'originalExpectationMatches':sum(r['matches'] for r in controls),'exploratoryMismatches':assessments,'copiedTestRun':{'configLoader':'native','tests':native['numTotalTests'],'passed':native['numPassedTests'],'failed':native['numFailedTests'],'raw':'evidence/native-run.json','config':'vitest.i1.config.mjs','cache':'cache/vite'},'targetsExecuted':False,'hashesExact':True,'hostFailure':'evidence/host-enospc.json','globalClosure':'UNKNOWN/NOT_ASSESSED; never converted to PASS','forbiddenOperations':'No repository writes, docs/prior reports/history, whole closure/full suite, provider/private env/network/PG/Docker/descendant reviews; only toolsReadonly symlink for dependencies.'}
(O/'verdict.json').write_text(json.dumps(verdict,indent=2)+'\n')
report=f'''# R64_INSTALLED_FINITE_GRAPH_FRESH_REVIEW — crítico I1

Veredicto finito: **REJECT**, por R64-I1-F1 (P1). Autoridade exclusiva: `{authority/'packet.json'}`. Node atual: v22.23.2. Os nove exactinputs, nas fontes da autoridade e nas cópias próprias, mantêm os hashes e tamanhos indicados pelo packet.

## Achado bloqueante

O CLI aceita `--no-experimental-require-module`, mas o subprocesso de resolução repassa apenas `--conditions`/`-C`. A condição nativa `module-sync` diverge entre processo avaliado e resolver. A política de bootstrap não recusa essa flag.

O fixture físico `fixtures/module-sync-context/node_modules/bridge/package.json` contém:

```json
{{"name":"bridge","exports":{{"module-sync":"./closed.cjs","require":"./acquire.cjs","default":"./closed.cjs"}}}}
```

`closed.cjs` contém `module.exports = 17;`. `acquire.cjs` contém `throw "NEVER_EXECUTE"; require("../../products/product/marker.js");`. O target nunca foi executado; o scanner deve preservar a referência negativa explícita, inclusive depois do throw.

| Controle/oráculo | Resultado |
|---|---|
| CLI sem flag | PASS; ambos modos em closed.cjs |
| CLI com `--no-experimental-require-module` | **PASS, exit 0, diagnostics [], PROVED/sealed**, ainda ambos em closed.cjs |
| Node resolve-only com a mesma flag | require → **acquire.cjs**; import → closed.cjs |
| CLI com ramo require explicitamente fixado em acquire.cjs, mesma flag | **FAIL / VIOLATION**, UNKNOWN retido |
| CLI com condição própria institution-test selecionando aquisição | FAIL; condição explícita corretamente propagada |

O selo positivo cobre o arquivo errado e omite uma aresta física real para o produto. Isso refuta G1 e G3 sem ampliar o grafo e sem carregar nenhum payload. Localizações técnicas: `source/scripts/check-product-boundary.mjs:478` e `source/scripts/boundary-installed-obligations.mjs:222`. Correção esperada: recusar esse contexto como UNKNOWN, ou preservar suas condições nativas e inspecionar o successor realmente selecionado. Não foi feita correção no source.

Evidências discriminantes: `evidence/module-sync-disabled.json`, `evidence/module-sync-disabled.proof.json`, `evidence/oracle-module-sync-disabled.json`, `evidence/module-sync-default.json`, `evidence/oracle-module-sync-default.json`, `evidence/module-sync-forced-require.json` e `evidence/custom-conditions.json`. Comandos completos, stdout/stderr, exits, hashes físicos antes/depois e recibos estão nos JSONs; `rawcommands.json` indexa esses comandos.

## G1–G4

| Gate | Avaliação finita | Evidência e limite |
|---|---|---|
| G1 | REJECT | Folhas CJS/ESM/TS, dois modos distintos, quatro campos e oito declarações de aliases, transitivos/nested/census positivos funcionam; F1 omite um target modal real. |
| G2 | ACCEPT nos controles materializados | SCC completo sela; UNKNOWN local, saída ausente e transitivos contaminam ancestrais; VIOLATION domina mantendo UNKNOWN. Não prova targets que F1 deixou fora do grafo. |
| G3 | REJECT | Bootstrap separado/API e flags recusadas funcionam; F1 quebra a equivalência do CLI Node22 atual. Gramáticas negativas permanecem bloqueantes. |
| G4 | ACCEPT nos controles finitos | Hashes das fontes/cópias exatos; mudanças próprias de bytes, manifest, census, target e ausência de lookup detectadas; limite direto mantém UNKNOWN. Não constitui orçamento global de recursos. |

## Controles físicos e sete famílias negativas

Foram registradas **{len(controls)} execuções próprias** de checker/API instrumentada, além de oráculos resolve-only/`--check`, um probe direto do motor de prova e **{native['numPassedTests']}/{native['numTotalTests']} testes** do único arquivo copiado `installed-finite-graph.test.js`. Vitest usa `--configLoader native`, config própria, cache próprio, um worker e symlink declarado somente para ferramentas R25. O resultado verde desses testes não supera o contraexemplo independente.

| Família negativa própria | Exercícios |
|---|---|
| N1 gramática/aquisição | eval, loader customizado, dlopen, worker, alias require, chamadas/leitura de binding, loop, getter, computed/prototype, shadow module, anotação TS |
| N2 declarações ausentes | local ausente em nested metadata nos quatro campos; registry ausente na saída de SCC |
| N3 identidade modal | require/import/both nulos; import desconhecido com require neutro; fragmento URL |
| N4 endpoint/format | package.json ausente, bytes nativos e destino físico estrangeiro |
| N5 metadata/census | nested manifest malformado; frontier nested/census desconhecido |
| N6 lookup/identidade | instalação próxima shadow com código desconhecido; symlink físico recusado |
| N7 violação real | aquisição direta e por alias do produto; SCC com VIOLATION e UNKNOWN simultâneos |

Todos esses negativos em contexto default materializado bloqueiam. F1 pertence à cobertura independente de flags/condições e permanece bloqueante na revisão. `assessments.json` conserva a interpretação das expectativas exploratórias que não bateram: as formas concatenadas `-rPATH`/`-r=PATH` são rejeitadas pelo próprio Node antes do checker; não são bugs do produto. `export const await = 1` em .ts recebe certificado e Node `--check` .ts retorna 0; a projeção exata .mjs falha. Essa observação de contexto TS/ESM fica limitada ao que foi medido e não é contada como outro falso negativo de aquisição.

Os cinco probes de mutação em processo usam wrapper API próprio que altera **somente fixtures próprios** via hooks de filesystem, mantendo o checker copiado exato. A API já é UNKNOWN por bootstrap; portanto a prova de detecção usa motivos específicos: BYTES_CHANGED_BEFORE_SEAL, MANIFEST_SNAPSHOT_UNKNOWN_OR_CHANGED, CENSUS_CHANGED, SNAPSHOT_REVALIDATION_ERROR e LOOKUP_ABSENCE_CHANGED. A expectativa inicial para o motivo da mutação de manifest estava errada; o motivo efetivamente observado bloqueia antes do selo e fica preservado sem reescrever o raw.

## Limites e integridade

O probe direto de grafo com âncoras físicas produz 20.001 nós, um frontier não expandido, FINITE_FRONTIER_LIMIT/UNEXPANDED_FRONTIER e zero discharge, em aproximadamente 362 ms no motor (heap observado ~89,6 MB). É um probe unitário direto, sujeito também ao contexto API não suportado, não um stress do CLI inteiro. O counter limita expansão de prova a 20.000 iterações; não limita todas as declarações pré-construídas, descoberta/census recursivos ou número total de subprocessos. Resolver tem timeout 30 s/buffer 16 MiB por lote; native check tem timeout 10 s/buffer 1 MiB por arquivo. Nosso harness impõe timeout 35 s por controle e 150 s à execução estreita de Vitest. Nenhum desconhecido de whole/global closure foi convertido em PASS.

Houve **ENOSPC do host**, com saída literal `cat: write error: No space left on device`, ao gravar script próprio opcional. A falha e o arquivo parcial zero bytes foram registrados em `evidence/host-enospc.json`; não são achados do produto. Foi feita somente compressão sem perda de evidência própria do limite (`evidence/limit.proof.json.gz`, hash descomprimido em `evidence/limit-compression.json`). O lead depois informou recuperação de espaço. Fontes, cópias técnicas e conteúdo dos proofs permanecem íntegros.

`hash-before.json` e `hash-after.json` verificam os nove exactinputs. Os controles guardam inventário antes/depois; somente os cinco fixtures de mutação intencional mudaram durante uma inspeção. Nenhum target foi importado/executado para justificar neutralidade. Nenhum arquivo do repositório compartilhado foi alterado; não houve leitura de docs, rationale/builder, histórico, críticas anteriores ou Rootwalker, nem fullsuite/wholeclosure/provider/private env/network/PG/Docker/descendentes. Ambiente de filhos foi sintético e local, sem inspeção de conteúdo de ambiente privado.

`findings.json`, `verdict.json`, `controls.json`, `rawcommands.json`, `manifest.json` e `freeze.json` tornam o resultado revisável e congelado. O manifest não percorre o symlink tools-only. Não há conclusão de isolamento global, release ou produção.
'''
(O/'report.md').write_text(report)
# Index actual raw child commands, without importing arbitrary files or tool links.
commands=[]
for p in sorted((O/'evidence').glob('*.json')):
 try:d=json.loads(p.read_text())
 except:continue
 if isinstance(d,dict) and 'command' in d:
  raw=d.get('raw',d);commands.append({'artifact':str(p.relative_to(O)),'command':d['command'],'cwd':d.get('cwd',str(O/'source')),'exit':raw.get('exit'),'stdoutArtifact':str(p.relative_to(O)),'stderrArtifact':str(p.relative_to(O))})
(O/'rawcommands.json').write_text(json.dumps(commands,indent=2)+'\n')
# Authority packet itself also remained byte-exact.
assert hashlib.sha256((authority/'packet.json').read_bytes()).hexdigest()==hashlib.sha256(A.read_bytes()).hexdigest()
items=[]
def walk(p):
 for f in sorted(p.iterdir()):
  rel=str(f.relative_to(O))
  if rel in ['manifest.json','freeze.json']:continue
  if f.is_symlink():items.append({'path':rel,'symlink':os.readlink(f),'traversed':False})
  elif f.is_dir():walk(f)
  else:
   b=f.read_bytes();items.append({'path':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
walk(O)
manifest={'task':a['task'],'verdict':'REJECT','scope':a['scope'],'authorityPacketSha256':hashlib.sha256(A.read_bytes()).hexdigest(),'artifacts':items,'excludes':['manifest.json','freeze.json'],'symlinksNotTraversed':True}
(O/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');mh=hashlib.sha256((O/'manifest.json').read_bytes()).hexdigest()
(O/'freeze.json').write_text(json.dumps({'frozenUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifestSha256':mh,'manifest':'manifest.json','verdict':'REJECT','authorityUnchanged':True,'exactCopiesUnchanged':True,'targetsExecuted':False,'filesMode':'0444','directoriesMode':'0555','symlinkTargetsUntouched':True,'selfExcludedFromManifest':True},indent=2)+'\n')
print(json.dumps({'verdict':'REJECT','controls':len(controls),'nativePassed':native['numPassedTests'],'artifacts':len(items),'manifestSha256':mh,'hashesExact':True},indent=2))
# Freeze only own artifacts, never chmod symlink targets.
for directory,dirs,files in os.walk(O,followlinks=False):
 for name in files:
  p=pathlib.Path(directory)/name
  if not p.is_symlink():p.chmod(0o444)
for directory,dirs,files in os.walk(O,topdown=False,followlinks=False):
 pathlib.Path(directory).chmod(0o555)
