# R49 — I1: REJECT

Required **S2 falha**. O bundle real e o CLI backup/restore retornam sucesso para um volume legado previamente válido cuja **mídia primária referenciada foi removida depois da migração**. A cópia em recovery permanece íntegra e o restore permanece sob HOLD. Esses fatos limitam o impacto; não tornam presente o arquivo referenciado.

Packet artifact: `3909fdcc7cb9f86b284682bccd7c3f46bf794d99206605a18836078eef48483c` (identificador recebido, sem consulta a Git). Escopo: LOCAL_DELTA_SECURITY_ONLY_NOT_PRODUCTION, dados sintéticos, NO_MODEL. Node executado: `/home/ricardo/.nvm/versions/node/v22.23.2/bin/node`, v22.23.2.

| Required | Resultado factual |
|---|---|
| S1 | PARTIAL: 9 controles de integridade entre fronteiras do store passaram, negando disponibilidade/efeitos/commit e preservando bytes corruptos. Encadeamento de ingress/readiness inspecionado no código; HTTP público não executado. |
| S2 | **FAIL: R49-I1-F1 confirmado**. Validação offline e CLI aceitam mídia referenciada ausente no replay legado. Os demais controles de validação e HOLD passaram. |
| S3 | PARTIAL: controles de interface de arquivos recusaram traversal, links, alias por hardlink, destinos ocupados/nested e arquivos de configuração sintéticos. Scanners **NOT_RUN** nos paths autorizados. Nenhuma evidência desconhecida tratada como PASS. |
| S4 | PASS: controles próprios contra bundle/CLI reais com Node22; hashes e tamanhos dos 19 inputs listados exatos antes/depois; Sourcefrozen preservado. |

## Achado confirmado: R49-I1-F1 (material para S2)

Severidade MEDIUM no escopo local: falso sucesso de verificação de um volume com referência de mídia quebrada. Nenhum bypass de HOLD ou efeito remoto demonstrado. É um defeito do candidato atual; a introdução em relação a versões anteriores não foi avaliada.

Em `products/shift-assistant/src/migrate-journal.ts:285`, o replay faz `LegacyEventSchema.parse`. A verificação de mídia de mensagens cobre o caso `base64:` (linhas 286–300), e a de notas cobre os mappings de `mediaFile` (302–308). Mensagens legadas com `mediaRef: "media/…"` seguem diretamente para `apply(event)` na linha 310. O callback do store usa `#applyLegacy`; `store.ts:749` copia a mensagem sem a validação de mídia utilizada no fluxo transacional normal. `validateStoppedVolume`, backup e restore compartilham esse replay.

Confirmação em [confirmed-legacy-media.json](confirmed-legacy-media.json) e [confirmed-legacy-cli-results.json](confirmed-legacy-cli-results.json):

1. O bundle criou uma mídia sintética válida com sidecar. Seus bytes foram copiados para um volume V1 contendo uma mensagem `message_received` que aponta explicitamente para esse arquivo local.
2. A migração real criou manifest e transação V2; o volume válido foi aceito antes da adulteração.
3. Somente o arquivo primário `media/4fda66aa-5613-4adb-bc6f-7958c2d0b222.png` foi removido do fixture já migrado. Journal, manifest, sidecar e recovery permaneceram preservados.
4. O validador aceitou o fixture sem escrever nele e retornou exatamente a mesma identidade do journal.
5. Os dois comandos CLI abaixo retornaram exit **0**; o destino restaurado continuou sem o arquivo primário, com sidecar presente, `storageAvailable=true`, `operationalHold=true`, `effectsAllowed=false`.
6. O recheck readonly reproduziu a aceitação nos três volumes: source, backup/documents e destino restaurado.

**Schema/canonical validity.** O evento V1 é JSON UTF-8 válido, delimitado por LF, com campos válidos para o schema estrito `message_received`; o parser real do candidato o aceitou. Seus bytes usam a ordem de `JSON.stringify`, não a ordenação textual de `canonical`; V1 não exige essa ordenação. O manifest e a transação V2 gerados pelo próprio candidato são canônicos, a cópia revision-1 é byte-exata, os hashes prefix/full do legado conferem, o checksum da transação confere, prevSha256 corresponde ao prefixo legado, seq=1 e o registro de migração da transação coincide com o manifest. Logo o contraexemplo não é JSON/schema/checksum inválido. Detalhes: [schema-canonical-evidence.json](schema-canonical-evidence.json).

**Recovery copy retained ≠ primary referenced present.** O arquivo retido em `recovery/backup-ab6b9f82-fbc3-435c-8cda-6c8d515e83bb/media/4fda66aa-5613-4adb-bc6f-7958c2d0b222.png` existe e tem SHA256 `a1bac6af9ceea686870e78c9513d65099ef175209c4a2baedf9b106e7418d6a6`, igual ao descriptor. A mensagem aponta para `media/4fda66aa-5613-4adb-bc6f-7958c2d0b222.png`, que não existe. Não há mapping que redirecione essa mensagem para a cópia retida. A presença de recovery permite reconciliação posterior; não satisfaz a rejeição de mídia inválida antes do sucesso exigida por S2.

## CLI real: comandos, saídas e exits

Comandos executados diretamente, sem processo filho iniciado pelo código revisado:

```sh
'/home/ricardo/.nvm/versions/node/v22.23.2/bin/node' '/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/candidate-inventory-r44/products/shift-assistant/scripts/backup-restore.mjs' 'backup' '/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/current-delta-security-review-r49/output/i1/fixtures/confirmed-legacy-media/source' '/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/current-delta-security-review-r49/output/i1/fixtures/confirmed-legacy-media/cli-backup' > '/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/current-delta-security-review-r49/output/i1/cli-confirmed-missing-media-backup.stdout.txt' 2> '/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/current-delta-security-review-r49/output/i1/cli-confirmed-missing-media-backup.stderr.txt'
'/home/ricardo/.nvm/versions/node/v22.23.2/bin/node' '/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/candidate-inventory-r44/products/shift-assistant/scripts/backup-restore.mjs' 'restore' '/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/current-delta-security-review-r49/output/i1/fixtures/confirmed-legacy-media/cli-backup' '/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/current-delta-security-review-r49/output/i1/fixtures/confirmed-legacy-media/cli-target' > '/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/current-delta-security-review-r49/output/i1/cli-confirmed-missing-media-restore.stdout.txt' 2> '/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/current-delta-security-review-r49/output/i1/cli-confirmed-missing-media-restore.stderr.txt'
```

Backup: actual exit **0**, stderr vazio, stdout exato:

```json
{"status":"backup_verified","manifestSha256":"3d7e46b82ac26186e6d6e88e4268df9922571ebb5dee9e5371e56d9aa9ca6bcc","documents":9,"originalsPreserved":true}
```

Restore: actual exit **0**, stderr vazio, stdout exato:

```json
{"status":"restored_under_hold","manifestSha256":"3d7e46b82ac26186e6d6e88e4268df9922571ebb5dee9e5371e56d9aa9ca6bcc","documents":9,"effectsEnabled":false,"originalsPreserved":true}
```

A expectativa adversarial de S2 era recusa. [confirm-legacy-media.mjs](confirm-legacy-media.mjs) retornou exit **1**, registrando `I1_S2_EXPECTED_REJECTION_BUT_VALIDATOR_ACCEPTED_MISSING_REFERENCED_LEGACY_MEDIA`. [recheck-confirmed-volume.mjs](recheck-confirmed-volume.mjs) é reexecutável sobre os fixtures retidos, readonly; retornou exit **1** e `I1_S2_UNEXPECTED_ACCEPTANCE_COUNT=3`. Esses exits 1 são assertions do crítico expondo o defeito, não recusa do candidato.

Todos os comandos de controles e respectivos exits reais estão em [commands-actual.json](commands-actual.json). Os 60 controles base passaram (runner exit 0); nove CLI base tiveram resultados esperados: dois exits 0 e sete exits 1. Nas recusas base, stdout vazio e stderr exatamente `OFFLINE_BACKUP_RESTORE_FAILED_CLOSED\n`. A exploração adicional de legado não transforma os 60 PASS em cobertura completa; somente o caso de mídia removida acima fundamenta o REJECT.

## Preservação, SHA e sentinelas

- Bundle executado: SHA256 `1cc4b512a916e4e86736df07467d70c8185b8868145485d5ecdca3f8ddae5675`.
- CLI source executado: SHA256 `5c12bf90cb08bc851bc3c81560449c77478a4b5ef9a4ab1d8d2067ee625fea4d`.
- Manifest do backup do defeito: SHA256 `3d7e46b82ac26186e6d6e88e4268df9922571ebb5dee9e5371e56d9aa9ca6bcc`.
- Read-set Sourcefrozen: somente 18 allowedTechnicalInputs + 1 binaryAllowed, todos regulares, hash/tamanho antes/depois iguais ao packet. Aggregate SHA256: `9cef392d94ab02e59dbd5ef77798f168b1ae5727768acf394414dc97be5f523f`. Evidências: [fingerprint-before.json](fingerprint-before.json), [fingerprint-after.json](fingerprint-after.json), [sourcefrozen.json](sourcefrozen.json).
- Sentinela externa aos volumes, mas dentro de ownoutput: bytes, inode e modo preservados, SHA256 `f6536b795ba5b0130ece625a9f5bc2e6fd78288d867709c6b190e1f3a45e381d`. Os próprios testes de hardlink mudaram nlink de 1 para 4 e ctime; nenhuma alegação de metadados totalmente iguais para essa sentinela. Destino ocupado do CLI e lock estrangeiro permaneceram preservados.
- Source e backup dos controles readonly/failures permaneceram byte/identity-exatos nos checkpoints registrados. A remoção da mídia ocorreu somente no fixture sintético do crítico, antes desses checkpoints.
- **Sem Sourcewrites; rollback de Source não necessário.** Nenhuma mudança em dependências, ledgers, código do candidato ou ambiente operacional. Fixtures e recovery mantidos para inspeção, sem limpeza ou restauração ocultando o contraexemplo.

[evidence-manifest.json](evidence-manifest.json) registra SHA256 e tamanhos dos artefatos próprios, logs e fixtures, sem seguir links. O snapshot/freeze é local; não é atestado de release.

## Limites

Scanners semgrep/gitleaks/trivy não foram fornecidos nos paths permitidos de dependências R25: **NOT_RUN**, conforme [scanner-availability.json](scanner-availability.json); não se pesquisou a máquina inteira, instalou scanner, suprimiu achado ou criou allowlist. Revisão de build é estática; os scripts não foram executados pois escrevem no candidato e/ou usam subprocessos e inputs fora do read-set. O aplicativo HTTP público não foi executado; o CLI público de backup/restore foi.

Não houve rede, serviços de terceiros, providers, leitura de env/chaves reais, Git, PG, Docker, fullsuite/certify, subagentes, comparação de históricos/critics/builders ou consulta/alteração de governança/ledgers. A falha é de verificação de integridade local sob HOLD; não se demonstrou uso clínico, efeito remoto ou liberação de produção.
