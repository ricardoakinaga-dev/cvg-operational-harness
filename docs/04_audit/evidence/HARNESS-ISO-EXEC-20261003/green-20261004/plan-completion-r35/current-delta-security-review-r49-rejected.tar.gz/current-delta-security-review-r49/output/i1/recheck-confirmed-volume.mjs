import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {ShiftStore} from '/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/candidate-inventory-r44/products/shift-assistant/dist/offline-validator.mjs';
import {tree,rejected} from './controls-lib.mjs';
const own=path.dirname(new URL(import.meta.url).pathname);
const f=JSON.parse(fs.readFileSync(path.join(own,'confirmed-legacy-media.json')));
let unexpectedAcceptance=0;
for(const root of [f.source,path.join(f.backup,'documents'),f.target]){
  assert.equal(fs.existsSync(path.join(root,f.descriptor.path)),false);
  const before=tree(root),result=rejected(()=>ShiftStore.validateStoppedVolume(root));
  assert.deepEqual(tree(root),before);
  console.log(JSON.stringify({root,missingReferencedPath:f.descriptor.path,actual:result,readonlyExact:true,expected:'STORAGE_UNAVAILABLE'}));
  if(!result.rejected)unexpectedAcceptance++;
}
console.error('I1_S2_UNEXPECTED_ACCEPTANCE_COUNT='+unexpectedAcceptance);
process.exitCode=unexpectedAcceptance?1:0;
