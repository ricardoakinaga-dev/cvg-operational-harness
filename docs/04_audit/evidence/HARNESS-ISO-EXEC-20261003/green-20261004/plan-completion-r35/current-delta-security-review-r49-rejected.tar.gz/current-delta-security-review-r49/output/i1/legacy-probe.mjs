import fs from 'node:fs';
import path from 'node:path';
import {ShiftStore} from '/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/candidate-inventory-r44/products/shift-assistant/dist/offline-validator.mjs';
import {backupStoppedVolume,restoreBackup} from '/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/candidate-inventory-r44/products/shift-assistant/scripts/backup-restore.mjs';
import {area,at,tree,rejected,sha} from './controls-lib.mjs';
const modes=['unknown-task','unknown-processed-message','missing-inbound-local-media','unknown-note-confirmation'];
const results=[];
for(const mode of modes){
  const base=area('legacy-probe-'+mode),source=path.join(base,'source'),backup=path.join(base,'backup'),target=path.join(base,'target');
  fs.mkdirSync(source);
  const event=mode==='unknown-task'?{type:'task_done',at,number:777}:mode==='unknown-processed-message'?{type:'message_processed',at,messageId:'never-recorded'}:mode==='unknown-note-confirmation'?{type:'note_confirmed',at,noteId:'never-created'}:{type:'message_received',at,message:{provider:'waha',messageId:'m1',fromPhone:'5511900000001',kind:'image',text:'I1 synthetic missing local media',mediaRef:'media/never-published.png',mimetype:'image/png',receivedAt:at}};
  const legacy=JSON.stringify(event)+'\n';fs.writeFileSync(path.join(source,'events.jsonl'),legacy);
  const runtime=rejected(()=>{const store=new ShiftStore(source,{legacySession:'I1-synthetic'});const actual={available:store.storageAvailable,hold:store.operationalHold,diagnostic:store.diagnostic??null};store.close();return actual;});
  const before=tree(source),validation=rejected(()=>ShiftStore.validateStoppedVolume(source));
  const backupResult=rejected(()=>backupStoppedVolume(source,backup));
  const restoreResult=rejected(()=>restoreBackup(backup,target));
  const after=tree(source);
  const result={mode,base,event,legacySha256:sha(legacy),runtime,validation,backup:backupResult,restore:restoreResult,sourceExact:JSON.stringify(before)===JSON.stringify(after),missingMedia:mode==='missing-inbound-local-media'?!fs.existsSync(path.join(source,'media/never-published.png')):null};
  results.push(result);console.log(JSON.stringify(result));
}
fs.writeFileSync(path.join(path.dirname(new URL(import.meta.url).pathname),'legacy-probe-results.json'),JSON.stringify(results,null,2)+'\n');
