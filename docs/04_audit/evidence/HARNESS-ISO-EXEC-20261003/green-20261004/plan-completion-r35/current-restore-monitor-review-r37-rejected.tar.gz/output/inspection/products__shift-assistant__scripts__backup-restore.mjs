import fs from 'node:fs'
import path from 'node:path'
import { createHash, randomUUID } from 'node:crypto'
import { pathToFileURL } from 'node:url'

const hash = (file) =>
  createHash('sha256').update(fs.readFileSync(file)).digest('hex')
const canonical = (value) => JSON.stringify(value)
function ordered(value) {
  if (Array.isArray(value)) return '[' + value.map(ordered).join(',') + ']'
  if (value && typeof value === 'object')
    return (
      '{' +
      Object.keys(value)
        .sort()
        .map((key) => JSON.stringify(key) + ':' + ordered(value[key]))
        .join(',') +
      '}'
    )
  return JSON.stringify(value)
}
function journalIdentity(root) {
  const manifestPath = path.join(root, 'journal/manifest.json')
  if (!fs.existsSync(manifestPath)) throw new Error('JOURNAL_MANIFEST_REQUIRED')
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'))
  if (
    manifest.v !== 2 ||
    !/^[a-f0-9-]{36}$/.test(manifest.journalId) ||
    !Array.isArray(manifest.segments) ||
    !manifest.segments.length
  )
    throw new Error('INVALID_JOURNAL_IDENTITY')
  let sequence = 0
  let head =
    manifest.legacy?.prefixSha256 ??
    createHash('sha256').update('').digest('hex')
  const prefixes = []
  for (const segment of manifest.segments) {
    safeRelative(segment.path)
    const bytes = fs.readFileSync(path.join(root, segment.path))
    const prefix = segment.sealed ? bytes.subarray(0, segment.bytes) : bytes
    if (prefix.length && prefix.at(-1) !== 10)
      throw new Error('UNRECOVERED_JOURNAL_TAIL')
    for (const line of new TextDecoder('utf-8', { fatal: true })
      .decode(prefix)
      .split('\n')
      .filter(Boolean)) {
      const record = JSON.parse(line)
      const { sha256: checksum, ...body } = record
      if (
        record.v !== 2 ||
        record.seq !== sequence + 1 ||
        record.prevSha256 !== head ||
        checksum !== createHash('sha256').update(ordered(body)).digest('hex')
      )
        throw new Error('INVALID_JOURNAL_CHAIN')
      sequence = record.seq
      head = checksum
    }
    prefixes.push({
      path: segment.path,
      bytes: prefix.length,
      sha256: createHash('sha256').update(prefix).digest('hex')
    })
  }
  return {
    journalId: manifest.journalId,
    manifestRevision: manifest.revision,
    sequence,
    headSha256: head,
    prefixes
  }
}
function safeRelative(name) {
  if (
    typeof name !== 'string' ||
    !name ||
    path.isAbsolute(name) ||
    /[\\\0]/.test(name) ||
    name.split('/').some((x) => !x || x === '.' || x === '..')
  )
    throw new Error('INVALID_BACKUP_PATH')
  if (/(^|\/)(\.env(?:\..*)?|.*\.(?:pem|key))$/i.test(name))
    throw new Error('CONFIGURATION_SECRET_NOT_A_DOCUMENT')
  return name
}
function physical(directory) {
  const absolute = path.resolve(directory)
  const stat = fs.lstatSync(absolute)
  if (
    !stat.isDirectory() ||
    stat.isSymbolicLink() ||
    fs.realpathSync(absolute) !== absolute
  )
    throw new Error('PHYSICAL_DIRECTORY_REQUIRED')
  return absolute
}
function inventory(root, relative = '') {
  const out = []
  for (const name of fs.readdirSync(path.join(root, relative)).sort()) {
    const rel = safeRelative(relative ? relative + '/' + name : name)
    if (rel === 'store.lock') continue
    const file = path.join(root, rel),
      stat = fs.lstatSync(file)
    if (stat.isSymbolicLink()) throw new Error('BACKUP_SYMLINK_REFUSED')
    if (stat.isDirectory()) out.push(...inventory(root, rel))
    else if (stat.isFile())
      out.push({ path: rel, bytes: stat.size, sha256: hash(file) })
    else throw new Error('BACKUP_NON_REGULAR_DOCUMENT')
  }
  return out.sort((a, b) => a.path.localeCompare(b.path, 'en'))
}
function sync(file) {
  const fd = fs.openSync(file, 'r')
  try {
    fs.fsyncSync(fd)
  } finally {
    fs.closeSync(fd)
  }
}
function fresh(directory) {
  const absolute = path.resolve(directory)
  physical(path.dirname(absolute))
  if (fs.existsSync(absolute)) {
    physical(absolute)
    if (fs.readdirSync(absolute).length)
      throw new Error('DESTINATION_MUST_BE_EMPTY')
  } else fs.mkdirSync(absolute, { mode: 0o700 })
  fs.chmodSync(absolute, 0o700)
  return physical(absolute)
}
function separate(source, destination) {
  const relative = path.relative(source, destination)
  if (
    !relative ||
    (!relative.startsWith('..' + path.sep) &&
      relative !== '..' &&
      !path.isAbsolute(relative))
  )
    throw new Error('DESTINATION_INSIDE_SOURCE_REFUSED')
}
function copyDocument(source, target) {
  fs.mkdirSync(path.dirname(target), { recursive: true, mode: 0o700 })
  fs.copyFileSync(source, target, fs.constants.COPYFILE_EXCL)
  fs.chmodSync(target, 0o600)
  sync(target)
  sync(path.dirname(target))
}
export function backupStoppedVolume(sourceDirectory, backupDirectory) {
  const source = physical(sourceDirectory),
    destination = path.resolve(backupDirectory)
  separate(source, destination)
  const lock = path.join(source, 'store.lock'),
    token = randomUUID()
  const fd = fs.openSync(lock, 'wx', 0o600)
  const ownership = canonical({
    version: 1,
    kind: 'offline-backup',
    token,
    pid: process.pid
  })
  try {
    fs.writeFileSync(fd, ownership)
    fs.fsyncSync(fd)
    sync(source)
    const documents = inventory(source)
    if (!documents.length) throw new Error('EMPTY_DOCUMENT_VOLUME')
    const journal = journalIdentity(source)
    fresh(destination)
    fs.mkdirSync(path.join(destination, 'documents'), { mode: 0o700 })
    for (const document of documents)
      copyDocument(
        path.join(source, document.path),
        path.join(destination, 'documents', document.path)
      )
    if (
      canonical(inventory(source)) !== canonical(documents) ||
      canonical(inventory(path.join(destination, 'documents'))) !==
        canonical(documents)
    )
      throw new Error('BACKUP_DOCUMENT_DRIFT')
    const manifest = {
      version: 1,
      tool: 'cvg-shift-offline-backup-v1',
      createdAtUtc: new Date().toISOString(),
      journal,
      documents
    }
    const manifestPath = path.join(destination, 'manifest.json')
    fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2) + '\n', {
      flag: 'wx',
      mode: 0o600
    })
    sync(manifestPath)
    sync(destination)
    return Object.freeze({
      status: 'backup_verified',
      manifestSha256: hash(manifestPath),
      documents: documents.length,
      originalsPreserved: true
    })
  } finally {
    fs.closeSync(fd)
    // Remove only the lock still carrying this backup's unique identity.
    if (
      fs.lstatSync(lock).isFile() &&
      fs.readFileSync(lock, 'utf8') === ownership
    ) {
      fs.unlinkSync(lock)
      sync(source)
    }
  }
}
export function restoreBackup(backupDirectory, destinationDirectory) {
  const backup = physical(backupDirectory),
    destination = path.resolve(destinationDirectory)
  separate(backup, destination)
  const manifestPath = path.join(backup, 'manifest.json')
  if (fs.lstatSync(manifestPath).isSymbolicLink())
    throw new Error('BACKUP_SYMLINK_REFUSED')
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'))
  if (
    manifest.version !== 1 ||
    manifest.tool !== 'cvg-shift-offline-backup-v1' ||
    !Array.isArray(manifest.documents) ||
    !manifest.documents.length
  )
    throw new Error('INVALID_BACKUP_MANIFEST')
  const names = new Set()
  for (const entry of manifest.documents) {
    safeRelative(entry.path)
    if (
      entry.path === 'store.lock' ||
      names.has(entry.path) ||
      !Number.isSafeInteger(entry.bytes) ||
      entry.bytes < 0 ||
      !/^[a-f0-9]{64}$/.test(entry.sha256)
    )
      throw new Error('INVALID_BACKUP_MANIFEST')
    names.add(entry.path)
  }
  const documents = physical(path.join(backup, 'documents'))
  if (canonical(inventory(documents)) !== canonical(manifest.documents))
    throw new Error('BACKUP_INTEGRITY_MISMATCH')
  if (canonical(journalIdentity(documents)) !== canonical(manifest.journal))
    throw new Error('BACKUP_JOURNAL_IDENTITY_MISMATCH')
  fresh(destination)
  const restorationLock = path.join(destination, 'store.lock')
  const restorationOwner = canonical({
    version: 1,
    kind: 'offline-restore',
    token: randomUUID(),
    pid: process.pid
  })
  const restorationFd = fs.openSync(restorationLock, 'wx', 0o600)
  let completed = false
  try {
    fs.writeFileSync(restorationFd, restorationOwner)
    fs.fsyncSync(restorationFd)
    sync(destination)
    // The marker is created before any journal bytes, so an accidental process
    // bootstrap cannot enable effects even if restoration is interrupted.
    const hold = path.join(destination, 'restore-hold.json')
    if (!names.has('restore-hold.json')) {
      fs.writeFileSync(
        hold,
        JSON.stringify({
          version: 1,
          reason: 'RESTORE_REQUIRES_OPERATOR_RECONCILIATION',
          manifestSha256: hash(manifestPath)
        }) + '\n',
        { flag: 'wx', mode: 0o600 }
      )
      sync(hold)
      sync(destination)
    } else copyDocument(path.join(documents, 'restore-hold.json'), hold)
    for (const entry of manifest.documents) {
      if (entry.path === 'restore-hold.json') continue
      copyDocument(
        path.join(documents, entry.path),
        path.join(destination, entry.path)
      )
    }
    for (const entry of manifest.documents) {
      const file = path.join(destination, entry.path)
      if (fs.statSync(file).size !== entry.bytes || hash(file) !== entry.sha256)
        throw new Error('RESTORE_INTEGRITY_MISMATCH')
    }
    sync(destination)
    completed = true
    return Object.freeze({
      status: 'restored_under_hold',
      manifestSha256: hash(manifestPath),
      documents: manifest.documents.length,
      effectsEnabled: false,
      originalsPreserved: true
    })
  } finally {
    fs.closeSync(restorationFd)
    // Failed partial destinations remain locked for explicit reconciliation.
    if (
      completed &&
      fs.lstatSync(restorationLock).isFile() &&
      fs.readFileSync(restorationLock, 'utf8') === restorationOwner
    ) {
      fs.unlinkSync(restorationLock)
      sync(destination)
    }
  }
}
if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href
) {
  try {
    const [mode, source, destination] = process.argv.slice(2)
    if (!source || !destination || !['backup', 'restore'].includes(mode))
      throw new Error('EXPLICIT_OPERATION_AND_PATHS_REQUIRED')
    console.log(
      JSON.stringify(
        mode === 'backup'
          ? backupStoppedVolume(source, destination)
          : restoreBackup(source, destination)
      )
    )
  } catch {
    console.error('OFFLINE_BACKUP_RESTORE_FAILED_CLOSED')
    process.exitCode = 1
  }
}
