import subprocess,pathlib,json,datetime,time
O=pathlib.Path('/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/restore-monitor-fresh-review-r37/output');S=pathlib.Path('/home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r25');N='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node'
env={'PATH':'/home/ricardo/.nvm/versions/node/v22.23.2/bin:/usr/bin:/bin','HOME':str(O/'home'),'TMPDIR':str(O/'tmp'),'XDG_CACHE_HOME':str(O/'cache'),'TSX_TSCONFIG_PATH':str(S/'tsconfig.base.json'),'TSX_DISABLE_CACHE':'1','LANG':'C.UTF-8','TZ':'UTC'}
cmd=['strace','-ff','-yy','-s','4096','-e','trace=%file,write,writev,pwrite64,fsync,fdatasync,ftruncate','-o',str(O/'logs/runtime.strace'),N,'--import',str(S/'node_modules/tsx/dist/loader.mjs'),str(O/'probes/review.ts'),str(O)]
meta={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':cmd,'cwd':str(O),'environment':env,'runtime':'Node v22.23.2','timeoutSeconds':150}
(O/'commands.json').write_text(json.dumps(meta,indent=2))
t=time.monotonic()
try:
 with (O/'logs/probes.stdout.log').open('w') as stdout,(O/'logs/probes.stderr.log').open('w') as stderr:
  p=subprocess.run(cmd,cwd=O,env=env,stdout=stdout,stderr=stderr,timeout=150)
 meta['exitCode']=p.returncode
except Exception as e:meta['error']=repr(e)
meta['elapsedSeconds']=time.monotonic()-t;meta['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();(O/'commands.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta,indent=2));print((O/'logs/probes.stdout.log').read_text()[-20000:]);print((O/'logs/probes.stderr.log').read_text()[-8000:])
