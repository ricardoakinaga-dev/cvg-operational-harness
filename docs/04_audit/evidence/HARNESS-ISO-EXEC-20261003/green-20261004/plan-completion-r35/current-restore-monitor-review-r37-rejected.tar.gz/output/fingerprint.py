from pathlib import Path
import json,hashlib,re,os,datetime
O=Path('/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/restore-monitor-fresh-review-r37/output');S=Path('/home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r25');B=O.parent
stamp=datetime.datetime.now(datetime.timezone.utc).isoformat();baseline=json.loads((O/'permitted-tree-before.json').read_text());inspection=json.loads((O/'inspection-readset-before.json').read_text());supplement=json.loads((O/'supplemental-readset-before.json').read_text())
for x in inspection+supplement:baseline.setdefault(x['path'],{'sha256':x['sha256'],'bytes':x['bytes']})
source_reads=set();runtime_open=[];mutations=[];source_mutations=[];forbidden_reads=[];pids=[]
traces=list((O/'logs').rglob('*.strace.*'))
for trace in traces:
 try:pids.append(int(trace.name.rsplit('.',1)[-1]))
 except:pass
 for line in trace.read_text(errors='replace').splitlines():
  if ('openat(' in line or 'open(' in line) and 'O_RDONLY' in line and re.search(r' = [0-9]+<',line):
   m=re.search(r' = \d+<([^>]+)>',line)
   if not m:continue
   p=m.group(1);runtime_open.append({'path':p,'trace':str(trace),'syscall':line})
   if p.startswith(str(S)+'/'):source_reads.add(p)
   if p.startswith(str(S)+'/') and any(x in p for x in ['/docs/07_agents/','/docs/99_runtime_state','/docs/20_master_execution_log','/docs/30_backlog_master','/.gauntlet/']):forbidden_reads.append(line)
  is_mutation=bool(re.search(r'^(?:[0-9. ]+)?(?:rename|renameat|unlink|unlinkat|mkdir|rmdir|chmod|fchmod|ftruncate|truncate|link|symlink|write|writev|pwrite)',line)) or (('openat(' in line or 'open(' in line) and ('O_WRONLY' in line or 'O_RDWR' in line))
  if is_mutation:
   # Path-bearing syscalls and the fd path before the buffer in write/fchmod.
   targets=[]
   if re.search(r'^(write|writev|pwrite|fchmod|ftruncate)',line):
    m=re.match(r'\w+\(\d+<([^>]+)>',line)
    if m:targets=[m.group(1)]
   else:targets=re.findall(r'"(/[^"\n]+)"',line)[:2]
   for target in targets:
    if target.startswith(str(S)+'/'):source_mutations.append({'target':target,'trace':str(trace),'syscall':line})
    if target.startswith(str(O)+'/'):mutations.append(target)
(O/'runtime-readset.json').write_text(json.dumps(runtime_open,indent=2))
readset_before=[];readset_after=[];missing_baseline=[]
for p in sorted(source_reads|{x['path'] for x in inspection}|{x['path'] for x in supplement}):
 f=Path(p);b=baseline.get(p) or baseline.get(str(f.resolve()))
 if not b:missing_baseline.append(p)
 readset_before.append({'path':p,'baseline':b,'baselineSource':'before.json technical trees; supplemental docs/deploy baseline after caller search' if p in {x['path'] for x in supplement} else 'pre-inspection technical tree capture'})
 if f.is_file():a={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size}
 else:a=None
 readset_after.append({'path':p,'after':a,'unchanged':b==a if b else None})
(O/'actual-readset-before.json').write_text(json.dumps(readset_before,indent=2));(O/'actual-readset-after.json').write_text(json.dumps(readset_after,indent=2))
after={};drift=[]
for p,b in baseline.items():
 f=Path(p);a={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} if f.is_file() else None;after[p]=a
 if a!=b:drift.append({'path':p,'before':b,'after':a})
(O/'permitted-tree-after.json').write_text(json.dumps(after,indent=2))
inputs=json.loads((O/'input-before.json').read_text());out=[]
for x in inputs['files']:
 f=Path(x['path']);d=f.read_bytes();out.append({'path':x['path'],'sha256':hashlib.sha256(d).hexdigest(),'bytes':len(d),'unchanged':hashlib.sha256(d).hexdigest()==x['sha256']})
(O/'input-after.json').write_text(json.dumps({'time':stamp,'files':out},indent=2));auth_before=json.loads((O/'authority-hashes.json').read_text());auth_after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in auth_before};(O/'authority-hashes-after.json').write_text(json.dumps(auth_after,indent=2))
alive=[]
for pid in set(pids):
 try:os.kill(pid,0);alive.append(pid)
 except ProcessLookupError:pass
 except PermissionError:alive.append(pid)
summary={'capturedAt':stamp,'technicalAndSupplementalFingerprintFiles':len(baseline),'runtimeSourceFilesOpened':len(source_reads),'actualReadsetFiles':len(readset_before),'missingBeforeFingerprints':missing_baseline,'sourceTreeDrift':drift,'allPacketInputsUnchanged':all(x['unchanged'] for x in out),'authorityUnchanged':auth_before==auth_after,'specHashMatchesPacket':auth_before[str(B/'authority/approved-spec0179.md')]==json.loads((B/'authority/packet.json').read_text())['approvedLocalSyntheticBuildSpecSha256'],'sourceMutationSyscalls':source_mutations,'forbiddenSourceRuntimeReads':forbidden_reads,'outputMutatingTargets':len(set(mutations)),'ownRuntimePids':sorted(set(pids)),'ownRuntimePidsStillAlive':alive,'systemRuntimeReadsDisclaimer':'runtime-readset.json includes loader/system libraries, public runtime configuration and boot_id read by actual Journal. System files are not frozen candidate inputs.','fingerprintDiscoveryLimitation':'Supplemental product docs/deploy hashes taken after rg caller search but before targeted operations.md read; original nine packet files and executed technical/dependency files have prior hashes.'}
(O/'mutation-sentinel.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
