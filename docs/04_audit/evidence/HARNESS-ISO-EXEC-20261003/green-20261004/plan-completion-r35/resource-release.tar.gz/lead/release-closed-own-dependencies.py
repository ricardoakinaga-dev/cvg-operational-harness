from pathlib import Path
import os, json, hashlib, shutil, datetime

base = Path('/home/ricardo/.cache/cvg-harness-green-20261004')
out = base / 'plan-completion-r35/resource-release'
out.mkdir(exist_ok=False)
names = ['c1-manifest-validity-r9-candidate', 'c1-global-discovery-r10-candidate', 'c1-workspace-local-r11-candidate', 'c1-context-dependency-syntax-r12-candidate']
def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for c in iter(lambda: f.read(1048576), b''): h.update(c)
    return h.hexdigest()
def records(root, source=False):
    rows = []
    for folder, dirs, files in os.walk(root, followlinks=False):
        if source: dirs[:] = [x for x in dirs if x not in ('node_modules', '.git')]
        for name in sorted(files + [x for x in dirs if (Path(folder) / x).is_symlink()]):
            p = Path(folder) / name
            st = p.lstat()
            row = {'path': str(p.relative_to(root)), 'mode': st.st_mode & 0o7777}
            if p.is_symlink(): row.update({'type': 'symlink', 'target': os.readlink(p)})
            elif p.is_file(): row.update({'type': 'file', 'bytes': st.st_size, 'sha256': digest(p)})
            else: raise ValueError('Unexpected special input: ' + str(p))
            rows.append(row)
    return sorted(rows, key=lambda x: x['path'])
def assert_inactive(candidate):
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit() or proc.name == str(os.getpid()): continue
        try:
            cwd = os.readlink(proc / 'cwd')
            cmd = (proc / 'cmdline').read_bytes()
        except (FileNotFoundError, PermissionError, ProcessLookupError): continue
        if cwd == str(candidate) or cwd.startswith(str(candidate) + '/') or str(candidate).encode() in cmd:
            raise ValueError('Candidate has active process pid ' + proc.name)
report = []
for name in names:
    candidate = base / name
    assert candidate.parent == base and candidate.is_dir() and not candidate.is_symlink()
    deps = candidate / 'node_modules'
    assert deps.is_dir() and not deps.is_symlink()
    assert_inactive(candidate)
    before = records(candidate, source=True)
    dependency_records = records(deps)
    (out / (name + '-source-before.json')).write_text(json.dumps(before, indent=2) + '\n')
    (out / (name + '-dependencies.json')).write_text(json.dumps(dependency_records, indent=2) + '\n')
    lock_hash = digest(candidate / 'package-lock.json')
    free_before = shutil.disk_usage(base).free
    assert_inactive(candidate)
    shutil.rmtree(deps)
    after = records(candidate, source=True)
    (out / (name + '-source-after.json')).write_text(json.dumps(after, indent=2) + '\n')
    assert before == after and digest(candidate / 'package-lock.json') == lock_hash
    row = {'candidate': name, 'sourceFilesAndLinks': len(before), 'dependencyFilesAndLinks': len(dependency_records), 'sourceSentinel': 'MATCH', 'lockSha256': lock_hash, 'dependencies': 'DETACHED', 'freeBytesBefore': free_before, 'freeBytesAfter': shutil.disk_usage(base).free, 'activeProcesses': 0, 'historicalEvidenceAltered': False, 'reinstall': 'Node22 npm ci using this exact archived lock; new installation requires fresh physical-dependency fingerprint'}
    report.append(row)
    (out / 'report.json').write_text(json.dumps({'task': 'R35_CURRENT_DOCKERFILE_AND_RESOURCES', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'releases': report, 'rootOrForeignResourceTouched': False}, indent=2) + '\n')
    print(name, row['sourceFilesAndLinks'], 'SOURCE_MATCH', row['freeBytesAfter'], flush=True)
