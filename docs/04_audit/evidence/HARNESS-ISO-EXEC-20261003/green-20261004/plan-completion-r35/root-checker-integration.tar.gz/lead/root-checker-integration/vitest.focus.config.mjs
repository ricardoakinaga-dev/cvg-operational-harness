export default {
  "root": "/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/lead/root-checker-integration/original-test-work",
  "cacheDir": "/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/lead/root-checker-integration/vite-cache",
  "test": {
    "include": [
      "tests/product-boundary.test.js"
    ],
    "environment": "node",
    "pool": "forks",
    "fileParallelism": false,
    "maxWorkers": 1
  }
}
