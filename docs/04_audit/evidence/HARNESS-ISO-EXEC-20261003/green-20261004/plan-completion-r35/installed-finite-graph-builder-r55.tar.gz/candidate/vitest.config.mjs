export default {
  cacheDir: './.vite-r55',
  test: {
    include: ['tests/*.test.js'],
    environment: 'node',
    fileParallelism: false,
    maxWorkers: 1
  }
}
