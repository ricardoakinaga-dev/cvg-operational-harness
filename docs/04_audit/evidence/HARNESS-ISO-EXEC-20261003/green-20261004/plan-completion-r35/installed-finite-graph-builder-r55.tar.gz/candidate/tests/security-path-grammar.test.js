import { afterEach, describe, expect, it } from 'vitest'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import {
  invalidTsconfigPathPatterns,
  expandSingleWildcard
} from '../scripts/tsconfig-path-grammar.mjs'
import { auditProductBoundary } from '../scripts/check-product-boundary.mjs'
const roots = []
afterEach(() => {
  for (const root of roots.splice(0))
    fs.rmSync(root, { recursive: true, force: true })
})
const malformed = [
  null,
  [],
  'x',
  4,
  { 'x**': ['x'] },
  { x: ['y**'] },
  { x: [] },
  { x: 'y' },
  { x: [null] },
  { '': ['y'] },
  { x: [''] },
  { x: [' '] }
]
function fixture(paths) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'security-paths-'))
  roots.push(root)
  for (const dir of ['packages/core/src', 'apps', 'legacy', 'products'])
    fs.mkdirSync(path.join(root, dir), { recursive: true })
  fs.writeFileSync(
    path.join(root, 'package.json'),
    JSON.stringify({ workspaces: ['packages/*'] })
  )
  fs.writeFileSync(
    path.join(root, 'packages/core/package.json'),
    JSON.stringify({ name: '@neutral/core' })
  )
  fs.writeFileSync(
    path.join(root, 'packages/core/src/index.ts'),
    'export const value = 1'
  )
  fs.writeFileSync(
    path.join(root, 'tsconfig.base.json'),
    JSON.stringify({
      compilerOptions: {
        module: 'NodeNext',
        moduleResolution: 'NodeNext',
        baseUrl: '.',
        paths
      }
    })
  )
  return root
}
describe('strict TypeScript path grammar', () => {
  it.each(malformed.map((value, i) => [i, value]))(
    'rejects malformed config %i even with no alias use',
    (_index, paths) => {
      expect(invalidTsconfigPathPatterns(paths).length).toBeGreaterThan(0)
      const root = fixture(paths)
      expect(() => auditProductBoundary(root)).toThrow('TSCONFIG_PATHS_INVALID')
      const cli = spawnSync(
        process.execPath,
        ['scripts/check-product-boundary.mjs', root],
        { encoding: 'utf8' }
      )
      expect(cli.status).not.toBe(0)
    }
  )
  it('allows exact aliases and one wildcard, expanding the literal captured star once', () => {
    expect(
      invalidTsconfigPathPatterns({
        '@neutral/*': ['packages/core/src/*'],
        exact: ['packages/core/src/index.ts']
      })
    ).toEqual([])
    expect(expandSingleWildcard('prefix/*/suffix', '$&*')).toBe(
      'prefix/$&*/suffix'
    )
    expect(expandSingleWildcard('literal', 'capture')).toBe('literal')
    expect(
      auditProductBoundary(fixture({ '@neutral/*': ['packages/core/src/*'] }))
        .passed
    ).toBe(true)
  })
})
