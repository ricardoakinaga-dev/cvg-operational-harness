import tseslint from 'typescript-eslint'
export default tseslint.config(
  { ignores: ['node_modules/**', '.vite-r55/**'] },
  ...tseslint.configs.recommended
)
