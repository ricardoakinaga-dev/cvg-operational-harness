// @vitest-environment node
// Payloads are inert .js text: AST, Node --check and resolver only.
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { createRequire } from 'node:module'
import { createHash } from 'node:crypto'
import { afterEach, describe, expect, it } from 'vitest'
import { auditProductBoundary } from '../scripts/check-product-boundary.mjs'

const roots = []
let sequence = 0
const fields = [
  'dependencies',
  'devDependencies',
  'optionalDependencies',
  'peerDependencies'
]
function fixture(shape = 'direct', mode = 'require', field = 'dependencies') {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'cvg-manifest-runtime-'))
  roots.push(root)
  const put = (relative, value) => {
    const file = path.join(root, relative)
    fs.mkdirSync(path.dirname(file), { recursive: true })
    fs.writeFileSync(
      file,
      typeof value === 'string' ? value : JSON.stringify(value)
    )
  }
  put('package.json', { workspaces: ['packages/*', 'products/*'] })
  put('packages/core/package.json', {
    name: '@synthetic/core',
    [field]: { bridge: '*' }
  })
  put('packages/core/src/index.ts', 'export const neutral = 1')
  put('products/shift/package.json', { name: '@synthetic/product' })
  put('products/shift/marker.js', 'throw new Error("PRODUCT_MUST_NOT_EXECUTE")')
  const packageType = mode === 'import' ? 'module' : 'commonjs'
  const neutral =
    mode === 'import' ? 'export const neutral = 1' : 'module.exports = 1'
  put('node_modules/bridge/package.json', {
    name: 'bridge',
    type: packageType,
    main: 'entry.js',
    ...(shape === 'direct' ? {} : { dependencies: { successor: '*' } })
  })
  put('node_modules/bridge/entry.js', neutral)
  const actor =
    shape === 'direct'
      ? 'node_modules/bridge'
      : shape === 'transitive'
        ? 'node_modules/successor'
        : 'node_modules/bridge/node_modules/successor'
  if (shape !== 'direct') {
    put(actor + '/package.json', {
      name: 'successor',
      type: packageType,
      main: 'entry.js'
    })
    put(actor + '/entry.js', neutral)
  }
  const entry = actor + '/entry.js'
  const declaring =
    shape === 'direct'
      ? 'packages/core/package.json'
      : 'node_modules/bridge/package.json'
  const key = shape === 'direct' ? 'bridge' : 'successor'
  // Node oracle resolves a path; it never loads the resolved payload.
  expect(createRequire(path.join(root, declaring)).resolve(key)).toBe(
    path.join(root, entry)
  )
  return { root, put, actor, entry, mode, neutral }
}
function inspect(f, label) {
  let audit, error
  try {
    audit = auditProductBoundary(f.root)
  } catch (caught) {
    error = caught
  }
  const directory = process.env.CVG_MANIFEST_RUNTIME_PROOF_DIR
  if (directory) {
    fs.mkdirSync(directory, { recursive: true })
    const files = []
    function collect(relative = '') {
      for (const entry of fs.readdirSync(path.join(f.root, relative), {
        withFileTypes: true
      })) {
        const name = path.join(relative, entry.name)
        if (entry.isDirectory()) collect(name)
        else if (entry.isSymbolicLink())
          files.push({
            path: name,
            symlink: fs.readlinkSync(path.join(f.root, name))
          })
        else {
          const bytes = fs.readFileSync(path.join(f.root, name))
          files.push({
            path: name,
            sha256: createHash('sha256').update(bytes).digest('hex'),
            source: bytes.toString('utf8')
          })
        }
      }
    }
    collect()
    fs.writeFileSync(
      path.join(directory, `${++sequence}.json`),
      JSON.stringify(
        {
          label,
          root: f.root,
          fixturesExecuted: false,
          audit,
          thrown: error?.message,
          files
        },
        null,
        2
      ) + '\n'
    )
  }
  if (error) throw error
  return audit
}
function installedUnknown(audit) {
  expect(audit.passed).toBe(false)
  expect(
    audit.diagnostics.some(
      (d) => d.reason === 'UNVERIFIED_INSTALLED_DEPENDENCY'
    )
  ).toBe(true)
}
function productPayload(f) {
  const target = path
    .relative(
      path.dirname(path.join(f.root, f.entry)),
      path.join(f.root, 'products/shift/marker.js')
    )
    .replaceAll(path.sep, '/')
  f.put(
    f.entry,
    'throw new Error("RUNTIME_MUST_NOT_EXECUTE");\n' +
      (f.mode === 'import'
        ? `import ${JSON.stringify(target)}`
        : `require(${JSON.stringify(target)})`)
  )
}
afterEach(() => {
  for (const root of roots.splice(0))
    fs.rmSync(root, { recursive: true, force: true })
})

describe('manifest-only physical runtime successors', () => {
  const shapes = ['direct', 'transitive', 'nested']
  const cases = shapes.flatMap((shape) =>
    (shape === 'direct' ? fields : ['dependencies']).flatMap((field) =>
      ['require', 'import'].flatMap((mode) =>
        ['product', 'codeexecution'].map((kind) => [shape, field, mode, kind])
      )
    )
  )
  it.each(cases)(
    'detects %s/%s/%s/%s without executing the successor',
    (shape, field, mode, kind) => {
      const f = fixture(shape, mode, field)
      if (kind === 'product') productPayload(f)
      else
        f.put(
          f.entry,
          'throw new Error("RUNTIME_MUST_NOT_EXECUTE");\neval("synthetic")'
        )
      const audit = inspect(f, [shape, field, mode, kind].join('/'))
      installedUnknown(audit)
      if (kind === 'product') {
        expect(audit.status).toBe('FAIL')
        expect(
          audit.violations.some(
            (v) =>
              v.reason === 'CORE_DEPENDS_ON_PRODUCT' &&
              v.trail.includes(f.entry) &&
              v.trail.includes('products/shift/marker.js') &&
              v.trail.includes('packages/core/package.json') &&
              (shape === 'direct' ||
                v.trail.includes('node_modules/bridge/package.json'))
          )
        ).toBe(true)
      } else {
        expect(audit.status).toBe('INCOMPLETE')
        expect(
          audit.diagnostics.some(
            (d) =>
              d.reason === 'UNVERIFIED_DYNAMIC_CODE_EXECUTION' &&
              d.file.startsWith(f.entry)
          )
        ).toBe(true)
      }
    }
  )
  it.each(shapes)(
    'keeps neutral %s installed implementations unknown',
    (shape) => {
      const f = fixture(shape)
      f.put(
        f.entry,
        'throw new Error("NEUTRAL_MUST_NOT_EXECUTE");\n' + f.neutral
      )
      const audit = inspect(f, 'neutral/' + shape)
      expect(audit.status).toBe('INCOMPLETE')
      expect(audit.violations).toEqual([])
      expect(
        audit.diagnostics.every(
          (d) => d.reason === 'UNVERIFIED_INSTALLED_DEPENDENCY'
        )
      ).toBe(true)
      installedUnknown(audit)
      expect(audit.sourceFiles).toBe(shape === 'direct' ? 3 : 4)
    }
  )
  it('deduplicates a manifest cycle while inspecting its runtime payload', () => {
    const f = fixture('transitive')
    f.put(f.actor + '/package.json', {
      name: 'successor',
      main: 'entry.js',
      dependencies: { bridge: '*' }
    })
    f.put(
      f.entry,
      'throw new Error("CYCLE_MUST_NOT_EXECUTE");\neval("synthetic")'
    )
    const audit = inspect(f, 'cycle')
    installedUnknown(audit)
    expect(audit.status).toBe('INCOMPLETE')
    expect(audit.sourceFiles).toBe(4)
    expect(
      audit.diagnostics.filter(
        (d) =>
          d.reason === 'UNVERIFIED_DYNAMIC_CODE_EXECUTION' &&
          d.file.startsWith(f.entry)
      )
    ).toHaveLength(1)
  })
  it('keeps a missing runtime entry fail closed', () => {
    const f = fixture()
    fs.unlinkSync(path.join(f.root, f.entry))
    const audit = inspect(f, 'missing-runtime')
    expect(audit.status).toBe('INCOMPLETE')
    installedUnknown(audit)
  })
  it('reports a missing import inside a manifest-only runtime successor', () => {
    const f = fixture()
    f.put(
      f.entry,
      'throw new Error("MISSING_MUST_NOT_EXECUTE");\nrequire("./absent.js")'
    )
    const audit = inspect(f, 'missing-runtime-import')
    installedUnknown(audit)
    expect(audit.status).toBe('INCOMPLETE')
    expect(
      audit.diagnostics.some(
        (d) =>
          d.file.startsWith(f.entry) &&
          d.reason === 'UNRESOLVED_MODULE_REFERENCE'
      )
    ).toBe(true)
  })
  it.each(['entry', 'manifest', 'nested-actor'])(
    'refuses %s symlink provenance',
    (kind) => {
      const f = fixture()
      const original =
        kind === 'entry'
          ? f.entry
          : kind === 'manifest'
            ? f.actor + '/package.json'
            : f.actor + '/inner'
      if (kind === 'nested-actor')
        f.put(original + '/package.json', { name: 'inner' })
      const absolute = path.join(f.root, original)
      fs.renameSync(absolute, absolute + '.physical')
      fs.symlinkSync(absolute + '.physical', absolute)
      expect(() => inspect(f, 'symlink/' + kind)).toThrow(
        /physical_file_required/
      )
    }
  )
  it('retains unresolved installed local-edge actor evidence', () => {
    const f = fixture()
    f.put(f.actor + '/package.json', {
      name: 'bridge',
      main: 'entry.js',
      dependencies: { absent: 'file:absent' }
    })
    const audit = inspect(f, 'actor-provenance')
    expect(audit.status).toBe('INCOMPLETE')
    installedUnknown(audit)
    expect(audit.diagnostics).toContainEqual(
      expect.objectContaining({
        reason: 'UNRESOLVED_INSTALLED_LOCAL_DEPENDENCY',
        file: 'node_modules/bridge/package.json',
        specifier: 'absent',
        dependencyField: 'dependencies',
        dependencySpecifier: 'file:absent',
        resolution: 'MISSING_LOCAL_DIRECTORY',
        installedActor: expect.objectContaining({
          manifest: 'node_modules/bridge/package.json',
          context: 'node_modules/bridge',
          declaredBy: 'packages/core/package.json',
          dependencyField: 'dependencies',
          specifier: 'bridge',
          dependencySpecifier: '*',
          manifestSha256: expect.stringMatching(/^[a-f0-9]{64}$/)
        })
      })
    )
  })
  it('validates metadata of the actor entered by a runtime successor', () => {
    const f = fixture()
    f.put(f.entry, 'require("./inner/entry.js")')
    f.put(f.actor + '/inner/package.json', {
      name: 'inner',
      dependencies: { absent: 'file:absent' }
    })
    f.put(
      f.actor + '/inner/entry.js',
      'throw new Error("INNER_MUST_NOT_EXECUTE")'
    )
    const audit = inspect(f, 'runtime-actor-provenance')
    installedUnknown(audit)
    expect(audit.status).toBe('INCOMPLETE')
    expect(
      audit.diagnostics.some(
        (d) =>
          d.file === 'node_modules/bridge/inner/package.json' &&
          d.reason === 'UNRESOLVED_INSTALLED_LOCAL_DEPENDENCY'
      )
    ).toBe(true)
  })
  it('keeps neutral type declarations independent from forbidden runtime JS', () => {
    const f = fixture()
    f.put(f.actor + '/package.json', {
      name: 'bridge',
      main: 'entry.js',
      types: 'index.d.ts'
    })
    f.put(f.actor + '/index.d.ts', 'export interface Neutral { value: number }')
    f.put(
      'packages/core/src/index.ts',
      'import type { Neutral } from "bridge"; export type Value = Neutral'
    )
    productPayload(f)
    const audit = inspect(f, 'types-neutral/runtime-product')
    installedUnknown(audit)
    expect(audit.status).toBe('FAIL')
    expect(audit.violations.some((v) => v.trail.includes(f.entry))).toBe(true)
  })
  it('keeps forbidden type closure independent from neutral runtime JS', () => {
    const f = fixture()
    f.put(f.actor + '/package.json', {
      name: 'bridge',
      main: 'entry.js',
      types: 'index.d.ts'
    })
    f.put(
      f.actor + '/index.d.ts',
      'export type { Product } from "../../products/shift/type.d.ts"'
    )
    f.put(
      'products/shift/type.d.ts',
      'export interface Product { value: number }'
    )
    f.put(
      'packages/core/src/index.ts',
      'import type { Product } from "bridge"; export type Value = Product'
    )
    const audit = inspect(f, 'types-product/runtime-neutral')
    installedUnknown(audit)
    expect(audit.status).toBe('FAIL')
    expect(
      audit.violations.some(
        (v) =>
          v.trail.includes('node_modules/bridge/index.d.ts') &&
          v.trail.includes('products/shift/type.d.ts')
      )
    ).toBe(true)
  })
  it('inspects require and import conditions as distinct runtime successors', () => {
    const f = fixture()
    f.put(f.actor + '/package.json', {
      name: 'bridge',
      type: 'module',
      exports: { require: './require.js', import: './entry.js' }
    })
    f.put(
      f.actor + '/require.js',
      'throw new Error("REQUIRE_MUST_NOT_EXECUTE");\nexport const neutral = 1'
    )
    f.mode = 'import'
    productPayload(f)
    const audit = inspect(f, 'require-neutral/import-product')
    installedUnknown(audit)
    expect(audit.status).toBe('FAIL')
    expect(audit.violations.some((v) => v.trail.includes(f.entry))).toBe(true)
    expect(audit.sourceFiles).toBe(4)
  })
})
