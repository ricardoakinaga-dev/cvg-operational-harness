// @vitest-environment node
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { fileURLToPath } from 'node:url'
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'
import { createRequire } from 'node:module'
import { afterAll, describe, expect, it } from 'vitest'

const checkerFile = fileURLToPath(
  new URL('../scripts/check-product-boundary.mjs', import.meta.url)
)
// Output routing changes no checker verdict. Integration can supply its own
// artifact directory; otherwise the standard temporary test tree is removed.
const temporary = !process.env.CVG_FINITE_GRAPH_PROOF_DIR
const own =
  process.env.CVG_FINITE_GRAPH_PROOF_DIR ??
  fs.mkdtempSync(path.join(os.tmpdir(), 'cvg-finite-installed-'))
afterAll(() => {
  if (temporary) fs.rmSync(own, { recursive: true, force: true })
})
const fixtures = path.join(own, 'fixtures/controls')
const proofs = path.join(own, 'evidence/controls')
const checksum = (bytes) => createHash('sha256').update(bytes).digest('hex')
const fields = [
  'dependencies',
  'devDependencies',
  'optionalDependencies',
  'peerDependencies'
]

function fixture(label, { mode = 'commonjs', field = 'dependencies' } = {}) {
  const root = path.join(fixtures, label)
  fs.rmSync(root, { recursive: true, force: true })
  const put = (relative, value) => {
    const file = path.join(root, relative)
    fs.mkdirSync(path.dirname(file), { recursive: true })
    fs.writeFileSync(
      file,
      typeof value === 'string' ? value : JSON.stringify(value)
    )
  }
  put('package.json', { workspaces: ['packages/*', 'products/*'] })
  put('packages/core/package.json', {
    name: '@synthetic/core',
    [field]: { bridge: '*' }
  })
  put('packages/core/src/index.ts', 'export const neutral = 1')
  put('products/shift/package.json', { name: '@synthetic/product' })
  put('products/shift/marker.js', 'throw new Error("PRODUCT_MUST_NOT_EXECUTE")')
  put('node_modules/bridge/package.json', {
    name: 'bridge',
    type: mode,
    main: 'entry.js'
  })
  put(
    'node_modules/bridge/entry.js',
    mode === 'commonjs' ? 'module.exports = 1' : 'export const neutral = 1'
  )
  return { root, put, label }
}
function inventory(root) {
  const rows = []
  const walk = (directory) => {
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
      const file = path.join(directory, entry.name)
      if (entry.isDirectory()) walk(file)
      else if (entry.isSymbolicLink())
        rows.push({
          path: path.relative(root, file),
          symlink: fs.readlinkSync(file)
        })
      else
        rows.push({
          path: path.relative(root, file),
          bytes: fs.statSync(file).size,
          sha256: checksum(fs.readFileSync(file))
        })
    }
  }
  walk(root)
  return rows.sort((a, b) => a.path.localeCompare(b.path))
}
function inspect(f) {
  const before = inventory(f.root)
  let audit, thrown
  const command = [checkerFile, f.root]
  fs.mkdirSync(proofs, { recursive: true })
  const proofFile = path.join(proofs, f.label + '.installed.json')
  const result = spawnSync(process.execPath, command, {
    encoding: 'utf8',
    timeout: 30000,
    env: { ...process.env, CVG_INSTALLED_OBLIGATION_PROOF_FILE: proofFile }
  })
  try {
    if (result.status === 2 || result.error)
      throw new Error(result.stderr || result.error?.message)
    audit = JSON.parse(result.stdout)
    audit.installedProof = JSON.parse(fs.readFileSync(proofFile, 'utf8'))
    expect(result.status).toBe(audit.passed ? 0 : 1)
  } catch (error) {
    thrown = error
  }
  const after = inventory(f.root)
  expect(after).toEqual(before)
  expect(fs.existsSync(path.join(f.root, 'EXECUTED'))).toBe(false)
  fs.mkdirSync(proofs, { recursive: true })
  fs.writeFileSync(
    path.join(proofs, f.label + '.json'),
    JSON.stringify(
      {
        root: f.root,
        command: [process.execPath, ...command],
        rawExit: result.status,
        stdout: result.stdout,
        stderr: result.stderr,
        fixturesExecuted: false,
        sentinelAbsent: true,
        before,
        after,
        audit,
        thrown: thrown?.message
      },
      null,
      2
    ) + '\n'
  )
  if (thrown) throw thrown
  return audit
}
function unknown(audit) {
  expect(audit.passed).toBe(false)
  expect(audit.status).not.toBe('PASS')
  expect(audit.installedProof.dischargedCount).toBe(0)
  expect(
    audit.diagnostics.some(
      (d) => d.reason === 'UNVERIFIED_INSTALLED_DEPENDENCY'
    )
  ).toBe(true)
  expect(
    audit.installedProof.obligations.every((o) => o.unknown.length > 0)
  ).toBe(true)
}
function product(f, entry = 'node_modules/bridge/entry.js') {
  const target = path
    .relative(
      path.dirname(path.join(f.root, entry)),
      path.join(f.root, 'products/shift/marker.js')
    )
    .replaceAll(path.sep, '/')
  f.put(
    entry,
    'throw new Error("RUNTIME_MUST_NOT_EXECUTE");\nrequire(' +
      JSON.stringify(target) +
      ')'
  )
}

describe('R55 physical installed finite obligations through the actual checker', () => {
  it.each(['commonjs', 'module'])(
    'proves a physically installed literal leaf in %s',
    (mode) => {
      const f = fixture('leaf-' + mode, { mode })
      const audit = inspect(f)
      expect(audit.status).toBe('PASS')
      expect(audit.diagnostics).toEqual([])
      expect(audit.installedProof.dischargedCount).toBe(1)
      expect(audit.installedProof.pending).toEqual([])
      expect(audit.installedProof.obligations[0]).toMatchObject({
        status: 'PROVED',
        sealed: true,
        unknown: [],
        violations: []
      })
      const modes = audit.installedProof.nodes
        .flatMap((n) => n.evidence)
        .filter((e) => e.kind === 'resolution')
      expect(modes.map((m) => m.mode).sort()).toEqual(['import', 'require'])
      expect(
        modes.every(
          (m) =>
            m.result === 'TARGET' &&
            m.target === path.join(f.root, 'node_modules/bridge/entry.js')
        )
      ).toBe(true)
      expect(
        createRequire(path.join(f.root, 'packages/core/package.json')).resolve(
          'bridge'
        )
      ).toBe(path.join(f.root, 'node_modules/bridge/entry.js'))
    }
  )
  it('keeps the original neutral/direct sentinel case unchanged and unknown', () => {
    const f = fixture('original-neutral-direct')
    f.put(
      'node_modules/bridge/entry.js',
      'throw new Error("NEUTRAL_MUST_NOT_EXECUTE");\nmodule.exports = 1'
    )
    const audit = inspect(f)
    unknown(audit)
    expect(audit.status).toBe('INCOMPLETE')
    expect(
      audit.installedProof.obligations[0].unknown.some((u) =>
        u.includes('UNSUPPORTED_CODE_GRAMMAR:ThrowStatement')
      )
    ).toBe(true)
    expect(
      audit.diagnostics.every(
        (d) => d.reason === 'UNVERIFIED_INSTALLED_DEPENDENCY'
      )
    ).toBe(true)
  })
  it('runs the public CLI and preserves physical bytes and no-execution sentinels', () => {
    const f = fixture('public-cli')
    const before = inventory(f.root)
    const command = [checkerFile, f.root]
    const result = spawnSync(process.execPath, command, {
      encoding: 'utf8',
      timeout: 30000
    })
    fs.mkdirSync(proofs, { recursive: true })
    fs.writeFileSync(
      path.join(proofs, 'public-cli.json'),
      JSON.stringify(
        {
          command: [process.execPath, ...command],
          rawExit: result.status,
          stdout: result.stdout,
          stderr: result.stderr,
          before,
          after: inventory(f.root),
          sentinelAbsent: !fs.existsSync(path.join(f.root, 'EXECUTED'))
        },
        null,
        2
      )
    )
    expect(result.status).toBe(0)
    expect(result.stderr).toBe('')
    expect(JSON.parse(result.stdout).status).toBe('PASS')
    expect(inventory(f.root)).toEqual(before)
  })
  it.each(fields)(
    'retains independent physical declaration evidence for %s',
    (field) => {
      const audit = inspect(fixture('field-' + field, { field }))
      expect(audit.status).toBe('PASS')
      const declarations = audit.installedProof.nodes
        .flatMap((n) => n.evidence)
        .filter((e) => e.kind === 'declaration')
      expect(declarations).toHaveLength(1)
      expect(declarations[0]).toMatchObject({
        field,
        name: 'bridge',
        version: '*',
        manifestSha256: expect.stringMatching(/^[a-f0-9]{64}$/)
      })
    }
  )
  it('keeps all four fields and aliases even with the same physical successor', () => {
    const f = fixture('aliases-all-fields')
    f.put('packages/core/package.json', {
      name: '@synthetic/core',
      ...Object.fromEntries(
        fields.map((field) => [field, { bridge: 'npm:some-original@1.0.0' }])
      )
    })
    const audit = inspect(f)
    expect(audit.status).toBe('PASS')
    expect(audit.installedProof.dischargedCount).toBe(4)
    const declarations = audit.installedProof.nodes
      .flatMap((n) => n.evidence)
      .filter((e) => e.kind === 'declaration')
    expect(declarations.map((d) => d.field).sort()).toEqual([...fields].sort())
    expect(
      declarations.every(
        (d) => d.name === 'bridge' && d.version === 'npm:some-original@1.0.0'
      )
    ).toBe(true)
  })
  it.each(['transitive', 'nested', 'nested-metadata'])(
    'closes physical %s frontiers',
    (shape) => {
      const f = fixture('complete-' + shape)
      const declaring =
        shape === 'nested-metadata'
          ? 'node_modules/bridge/inner/package.json'
          : 'node_modules/bridge/package.json'
      f.put(declaring, {
        name: shape === 'nested-metadata' ? 'inner' : 'bridge',
        main: 'entry.js',
        optionalDependencies: { successor: '*' }
      })
      const actor =
        shape === 'transitive'
          ? 'node_modules/successor'
          : 'node_modules/bridge/node_modules/successor'
      f.put(actor + '/package.json', {
        name: 'successor',
        type: 'commonjs',
        main: 'entry.js'
      })
      f.put(actor + '/entry.js', 'module.exports = 2')
      const audit = inspect(f)
      expect(audit.status).toBe('PASS')
      expect(audit.installedProof.dischargedCount).toBe(2)
      expect(
        audit.installedProof.obligations.every((o) => o.status === 'PROVED')
      ).toBe(true)
    }
  )
  it('settles a complete manifest SCC only after every modal frontier', () => {
    const f = fixture('complete-cycle')
    f.put('node_modules/bridge/package.json', {
      name: 'bridge',
      main: 'entry.js',
      dependencies: { successor: '*' }
    })
    f.put('node_modules/successor/package.json', {
      name: 'successor',
      main: 'entry.js',
      peerDependencies: { bridge: '*' }
    })
    f.put('node_modules/successor/entry.js', 'module.exports = 2')
    const audit = inspect(f)
    expect(audit.status).toBe('PASS')
    expect(audit.installedProof.obligations.every((o) => o.sealed)).toBe(true)
    expect(
      audit.installedProof.components.some(
        (c) =>
          c.members.filter((id) => id.endsWith('/package.json')).length >= 2
      )
    ).toBe(true)
  })
  it.each(['local', 'exit'])(
    'propagates unknown throughout a cyclic SCC with %s blocker',
    (shape) => {
      const f = fixture('unknown-cycle-' + shape)
      f.put('node_modules/bridge/package.json', {
        name: 'bridge',
        main: 'entry.js',
        dependencies: { successor: '*' }
      })
      f.put('node_modules/successor/package.json', {
        name: 'successor',
        main: 'entry.js',
        dependencies: {
          bridge: '*',
          ...(shape === 'exit' ? { absent: '*' } : {})
        }
      })
      f.put(
        'node_modules/successor/entry.js',
        shape === 'local' ? 'while (true) {}' : 'module.exports = 2'
      )
      const audit = inspect(f)
      unknown(audit)
      expect(audit.installedProof.obligations.every((o) => !o.sealed)).toBe(
        true
      )
    }
  )
  it('does not reuse a hoisted proof for a nearest shadow installation', () => {
    const f = fixture('shadowinstall')
    f.put('packages/core/node_modules/bridge/package.json', {
      name: 'bridge',
      main: 'entry.js'
    })
    f.put('packages/core/node_modules/bridge/entry.js', 'eval("synthetic")')
    const audit = inspect(f)
    unknown(audit)
    expect(
      audit.installedProof.nodes
        .flatMap((n) => n.evidence)
        .filter((e) => e.kind === 'resolution')
        .every((e) => e.target.includes('packages/core/node_modules/bridge'))
    ).toBe(true)
  })
  it('never confuses a neutral require branch with an unknown import branch', () => {
    const f = fixture('exports-mode')
    f.put('node_modules/bridge/package.json', {
      name: 'bridge',
      exports: { require: './entry.js', import: './different.mjs' }
    })
    f.put('node_modules/bridge/different.mjs', 'eval("synthetic")')
    unknown(inspect(f))
  })
  it('proves both explicitly distinct closed modes without confusing their hashes', () => {
    const f = fixture('closed-distinct-modes')
    f.put('node_modules/bridge/package.json', {
      name: 'bridge',
      exports: { require: './entry.js', import: './different.mjs' }
    })
    f.put('node_modules/bridge/different.mjs', 'export const neutral = 2')
    const audit = inspect(f)
    expect(audit.status).toBe('PASS')
    const code = audit.installedProof.nodes
      .flatMap((n) => n.evidence)
      .filter(
        (e) => e.kind === 'code' && e.path.includes('/node_modules/bridge/')
      )
    expect(code).toHaveLength(2)
    expect(new Set(code.map((e) => e.sha256)).size).toBe(2)
  })
  it.each(['require', 'import', 'both'])(
    'materializes a null %s mode as a blocking node',
    (mode) => {
      const f = fixture('unresolved-' + mode)
      f.put('node_modules/bridge/package.json', {
        name: 'bridge',
        exports:
          mode === 'both'
            ? './absent.js'
            : { [mode === 'import' ? 'require' : 'import']: './entry.js' }
      })
      const audit = inspect(f)
      unknown(audit)
      const diagnostics = audit.diagnostics.filter(
        (d) => d.reason === 'UNVERIFIED_INSTALLED_RUNTIME_RESOLUTION'
      )
      expect(diagnostics.map((d) => d.mode).sort()).toEqual(
        mode === 'both' ? ['import', 'require'] : [mode]
      )
      expect(
        audit.installedProof.obligations[0].unknown.some((u) =>
          u.includes('NULL_OR_MISSING_MODE_TARGET')
        )
      ).toBe(true)
    }
  )
  it('keeps a packageJSONless physical actor unknown despite resolvable bytes', () => {
    const f = fixture('packageJSONless')
    fs.unlinkSync(path.join(f.root, 'node_modules/bridge/package.json'))
    f.put('node_modules/bridge/index.js', 'module.exports = 1')
    unknown(inspect(f))
  })
  it('never treats native bytes as code proof', () => {
    const f = fixture('native')
    f.put('node_modules/bridge/package.json', {
      name: 'bridge',
      main: 'entry.node'
    })
    f.put('node_modules/bridge/entry.node', 'SYNTHETIC_NONEXECUTABLE_NATIVE')
    unknown(inspect(f))
  })
  it('keeps a foreign physical destination unknown', () => {
    const f = fixture('foreignedge')
    const foreign = path.join(fixtures, 'foreign-target.js')
    fs.writeFileSync(foreign, 'module.exports = 1')
    f.put('node_modules/bridge/package.json', {
      name: 'bridge',
      main: path.relative(path.join(f.root, 'node_modules/bridge'), foreign)
    })
    const audit = inspect(f)
    unknown(audit)
    expect(
      audit.diagnostics.some((d) => d.reason === 'MODULE_OUTSIDE_REPOSITORY')
    ).toBe(true)
  })
  const unsupported = [
    ['customloader', 'require("node:module").register("./hook.mjs")'],
    ['process-dynamic', 'process.dlopen(module, "entry.node")'],
    ['codeexecution', 'eval("synthetic")'],
    ['unknown-call', 'unmodelled()'],
    ['loop', 'while (true) {}'],
    ['alias', 'const load = require; load("./absent.js")'],
    ['contextshadow', 'const module = { exports: 1 }; module.exports = 2'],
    ['constructor', 'throw new Error("NEUTRAL_MUST_NOT_EXECUTE")'],
    ['getter', 'const value = { get neutral() { return 1 } }; value.neutral'],
    ['escaped-function', 'module.exports = () => import("./absent.js")'],
    ['computed', 'module["exports"] = 1'],
    ['prototype', 'Object.prototype.exports = 1'],
    ['builtin-acquisition', 'require("node:fs")'],
    ['worker', 'require("node:worker_threads").Worker("synthetic")']
  ]
  it.each(unsupported)(
    'keeps %s unknown rather than inferring inertness',
    (label, code) => {
      const f = fixture('unsupported-' + label)
      f.put('node_modules/bridge/entry.js', code)
      unknown(inspect(f))
    }
  )
  it.each(fields)(
    'keeps missing nested declarations in %s blocking',
    (field) => {
      const f = fixture('nested-missing-' + field)
      f.put('node_modules/bridge/nested/package.json', {
        name: 'inner',
        [field]: { absent: 'file:absent' }
      })
      const audit = inspect(f)
      unknown(audit)
      expect(
        audit.diagnostics.some(
          (d) => d.reason === 'UNRESOLVED_INSTALLED_LOCAL_DEPENDENCY'
        )
      ).toBe(true)
    }
  )
  it('preserves a product VIOLATION alongside intrinsic unknowns', () => {
    const f = fixture('mixed-violation')
    product(f)
    const audit = inspect(f)
    unknown(audit)
    expect(audit.status).toBe('FAIL')
    expect(
      audit.violations.some((v) => v.trail.includes('products/shift/marker.js'))
    ).toBe(true)
    expect(audit.installedProof.obligations[0].status).toBe('VIOLATION')
    expect(
      audit.installedProof.obligations[0].violations.length
    ).toBeGreaterThan(0)
    expect(audit.installedProof.obligations[0].unknown.length).toBeGreaterThan(
      0
    )
  })
  it('rejects physical symlink proof even if Node resolves the same bytes', () => {
    const f = fixture('symlink')
    const entry = path.join(f.root, 'node_modules/bridge/entry.js')
    fs.renameSync(entry, entry + '.physical')
    fs.symlinkSync(entry + '.physical', entry)
    expect(() => inspect(f)).toThrow(/physical_file_required/)
  })
  it('changes a prior proof to unknown after entry bytes change', () => {
    const f = fixture('changed-bytes')
    const before = inspect(f)
    expect(before.status).toBe('PASS')
    f.put('node_modules/bridge/entry.js', 'while (true) {}')
    const after = inspect(f)
    unknown(after)
    expect(after.installedProof.snapshotSha256).not.toBe(
      before.installedProof.snapshotSha256
    )
  })
  it('refuses to discharge from an arbitrary API host even with default flags', () => {
    const f = fixture('api-host-context')
    const checker = new URL(
      '../scripts/check-product-boundary.mjs',
      import.meta.url
    ).href
    const command = [
      '--input-type=module',
      '--eval',
      `import {auditProductBoundary} from ${JSON.stringify(checker)}; const audit=auditProductBoundary(${JSON.stringify(f.root)}); console.log(JSON.stringify({...audit,installedProof:audit.installedProof}))`
    ]
    const result = spawnSync(process.execPath, command, {
      encoding: 'utf8',
      timeout: 30000
    })
    expect(result.status).toBe(0)
    const audit = JSON.parse(result.stdout)
    unknown(audit)
    expect(audit.installedProof.runtime.standaloneCheckerEntry).toBe(false)
    expect(
      audit.installedProof.obligations[0].unknown.some((u) =>
        u.includes('UNSUPPORTED_RUNTIME_CONTEXT')
      )
    ).toBe(true)
    fs.writeFileSync(
      path.join(proofs, 'api-host-context.json'),
      JSON.stringify(
        {
          command,
          rawExit: result.status,
          stdout: result.stdout,
          stderr: result.stderr,
          audit
        },
        null,
        2
      )
    )
  })
  it('refuses unrecorded URL fragment semantics instead of merging physical bytes', () => {
    const f = fixture('entry-url-context')
    f.put('node_modules/bridge/package.json', {
      name: 'bridge',
      exports: { require: './entry.js', import: './entry.js#fragment' }
    })
    const audit = inspect(f)
    unknown(audit)
    expect(
      audit.installedProof.obligations[0].unknown.some((u) =>
        u.includes('UNSUPPORTED_ENTRY_URL_CONTEXT')
      )
    ).toBe(true)
  })
  it('preserves alias-acquired product violations and simultaneous unknowns', () => {
    const f = fixture('alias-product')
    f.put(
      'node_modules/bridge/entry.js',
      'const load = require; load("../../products/shift/marker.js")'
    )
    const audit = inspect(f)
    unknown(audit)
    expect(audit.status).toBe('FAIL')
    expect(audit.installedProof.obligations[0].status).toBe('VIOLATION')
  })
  it('keeps the API bootstrap preload unknown without whitelisting tool names', () => {
    const f = fixture('bootstrap-preload')
    // Vitest's actual runtime has a --require preload. No target is executed.
    const checker = new URL(
      '../scripts/check-product-boundary.mjs',
      import.meta.url
    ).href
    const command = [
      ...process.execArgv,
      '--input-type=module',
      '--eval',
      `import {auditProductBoundary} from ${JSON.stringify(checker)}; const audit=auditProductBoundary(${JSON.stringify(f.root)}); console.log(JSON.stringify({...audit,installedProof:audit.installedProof}))`
    ]
    const result = spawnSync(process.execPath, command, {
      encoding: 'utf8',
      timeout: 30000
    })
    expect(result.status).toBe(0)
    const audit = JSON.parse(result.stdout)
    unknown(audit)
    expect(
      audit.installedProof.obligations[0].unknown.some((u) =>
        u.includes('UNSUPPORTED_RUNTIME_CONTEXT')
      )
    ).toBe(true)
    fs.writeFileSync(
      path.join(proofs, 'bootstrap-preload.json'),
      JSON.stringify(
        {
          command,
          rawExit: result.status,
          stdout: result.stdout,
          stderr: result.stderr,
          audit
        },
        null,
        2
      )
    )
  })
  it('keeps a consumer environment violation and its unknown reason together', () => {
    const f = fixture('consumer-env-violation')
    f.put('packages/core/src/index.ts', 'export const SHIFT_NEUTRAL = 1')
    const audit = inspect(f)
    unknown(audit)
    expect(audit.status).toBe('FAIL')
    expect(audit.installedProof.obligations[0].status).toBe('VIOLATION')
    expect(
      audit.installedProof.obligations[0].violations.some((v) =>
        v.includes('CONSUMER_ENV_IN_CORE')
      )
    ).toBe(true)
  })
})
