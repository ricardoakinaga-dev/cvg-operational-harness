# R55 — task e SPEC curta antes de BUILD

Task: R55_INSTALLED_FINITE_GRAPH_BUILD; T2 authorized harness SPEC0180, continuous cycle / Lead claim. Profile: isolated correction; BUILD then bounded AUDIT. Scope exclusively this directory. No approval/release/production grant. Existing Lead claim in coordination read. Shared ledgers are read-only; own runtime/log/backlog record this round.

## Recon e problema
R25 emits UNVERIFIED_INSTALLED_DEPENDENCY at declaration and differing runtime context before a joint closure proof. A structurally valid null manifest-mode result currently has no explicit blocker. Shape/local closure cache and first installed declaration are not code proof. R52 proposes a sealed graph; its tableau is not a physical installation proof.

## Regras congeladas
1. Copy exactly five technical modules and unchanged relevant original test; R25 parser/resolver/test/lint tooling read-only, declared separately and never fixture evidence. Installations in fixtures are own physical files/manifests, not symlinks to tooling.
2. Capture each installed obligation, all four dependency fields, every nested governed manifest, declaring/alias/version/mode/nearest/runtime context and real Node22 TARGET/null receipt. Maintain pending inventory/cache. Null/missing mode is UNKNOWN. PackageJSONless is UNKNOWN. Every declaration provenance is retained despite byte/context deduplication.
3. Only a positive syntax-directed certificate over a tiny explicit grammar can discharge code: primitive literal expressions/throws, const identifier bindings to primitive literals, ESM literal export, and literal CJS module.exports assignment in actual CJS context. No general calls/new/property reads, imports, aliases, loops/functions/process/loaders/dynamic code. Existing intrinsic diagnostics always survive. The original sentinel throw new Error is unsupported and stays UNKNOWN; do not invent immutable global constructor assumptions or a new profile. If soundness cannot be established even for this closed fragment, deliver graph/helper without any discharge.
4. Freeze expansion only after original source/runtime queues drain. Derive local blockers positively from physical source/manifest census and exact resolver receipts, not absence of diagnostics. Build explicit obligations, iterative SCC condensation, propagate UNKNOWN and VIOLATION independently. Missing graph endpoint, unsupported format/context/symlink/foreign target/runtime flags/Node mismatch/frontier limit remain UNKNOWN. Visiting/cache hit never proves completion.
5. Revalidate hashed bytes, absence and census inventories before sealing; seal once after all local and successor receipts complete. Preserve existing public verdict/status; remove only the specific derived installed diagnostic whose whole obligation is PROVED. Original negative still FAIL even with unknown. No callback, user-trust flag, allowlist of names/versions/hashes or target execution.
6. Preserve every original assertion. The sole authorized original test is copied byte-exact, run unchanged; do not copy all 371 originals or claim full-suite execution. Physical test corpus includes real neutral literal direct CJS/ESM, original neutral/direct sentinel, all4/nested/transitive, alias/shadow, mode/null, native, JSONless, foreign, hooks/process/dynamic/unknown code, cycles/SCC and mixed violation/unknown.

## Pronto / evidence methods
A. Finite public CLI before/after on own physical neutral/direct installation; record output and raw exit, mode paths/hashes. Original case remains INCOMPLETE if code grammar unsupported.
B. Focused original suite unchanged + own adversarial tests; actual Node22 only. Negative families never PASS. Payload sentinel markers absent before/after and fixture bytes stable.
C. Syntax/type/lint over own delta, direct non-git diff payload, source/test/tooling before-after hashes and compact artifact manifest. No source tree scan, full closure, full certify, PG/E2E, network or Git.
D. Report IMPLEMENTED with exact grammar/soundness boundary, commands/not-run, plausible regressions, own runtime/log/backlog and new critic required. Builder is not approval.

## ExecPlan
1. Read/claim/spec/readset (current, completed before code).
2. Own minimal copy, physical fixture baseline + unchanged original tests.
3. Implement pending obligations, positive closed-fragment receipts and sealed SCC propagation; integrate only discharge of derived diagnostic.
4. Focused CLI/tests/static checks, separate self-review, fix concrete findings and rerun affected checks.
5. Freeze evidence/diff/manifests and return IMPLEMENTED with remaining critic gate.

## Resultado da rodada
IMPLEMENTED / FROZEN / NEW_CRITIC_PENDING. Literal/direct fecha pela CLI; original neutral/direct constructor permanece UNKNOWN. 1.065 testes/5 arquivos, zero skips, payload estável; helper typecheck, seis syntax checks e lint focado exit0. Contrato JSON preservado por receipt não enumerável + sidecar observacional. Public null diagnosis limitado a non-workspace installed, mantendo null UNKNOWN em grafo derivado. Ver report.md, payload-manifest.json e evidence/regression-frozen-command.json. Sem wholeclosure/full certification/371-suite/produção.
