# Revisão independente finita R45

**APPROVE_SCOPED_CI_DELTA** — somente atualização do teste CI 49→50, asserção do caminho exato e título compatível. Todos os quatro critérios passam; nenhum release concedido.

Revisão própria em Node v22.23.2, parser TypeScript 6.0.3 existente e readonly. Início: 2026-10-05T20:27:30.613Z; conclusão: 2026-10-05T20:27:30.868Z.

## Entradas e método

Somente packet.json, suas seis cópias técnicas, original-49-inventory.json e hashes readonly das seis origens exatas especificadas no packet. Nenhuma enumeração de árvore. O script reproduzível adjacente contém os controles completos, os fixtures em memória e as leituras explícitas. Saídas apenas em /home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/ci-count-fresh-review-r45/output.

Comando de verificação executado (exit 0):

```sh
/home/ricardo/.nvm/versions/node/v22.23.2/bin/node '/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/ci-count-fresh-review-r45/output/review.mjs'
```

Inspeção preliminar: cat packet.json e três invocações Node --input-type=module com heredoc para leitura das cópias, resumos JSON/hashes/delta e AST do caso alterado. A primeira leitura teve saída truncada; nenhuma conclusão depende desse dump: o script final verifica integralmente os bytes/JSON/AST. Sem npm, shell/filhos invocados pelo script, rede, provider, DB ou Docker.

Packet SHA-256: 839a4a4ffd7fb587da5a5fba40170cee077d67d6c230266ecbc2590e342045e6. Original49 SHA-256 antes/depois: 59ee0a8b39423b2ad642d522568e9d9b4c2064253892b9bfa6a531d9223e2bb5 (igual ao packet). Script de revisão SHA-256: edacf1e23844bdd721df21acc859046f605f0ca9e01fa12c5deebb7ddf5119aa.

## Delta e inventário

Uma reconstrução byte a byte aplica ao teste before somente três edições: thirty-eight→fifty no título, toHaveLength(49)→toHaveLength(50), e toContain('products/shift-assistant/src/__tests__/live-offline-r38-own.test.ts'). Resultado idêntico ao after inteiro. Todos os outros bytes do teste, e cada statement prévio do callback por AST, permanecem iguais.

Os inventários before e after já têm 50 adicionais e são idênticos: o before do teste estava defasado em relação ao JSON. Comparados com original-49-inventory.json, preservam todos os demais campos, os 371 registros completos (path/sha256/size), 275+6=281 caminhos de cobertura e os 49 adicionais em ordem. O único adicional é products/shift-assistant/src/__tests__/live-offline-r38-own.test.ts, uma única vez, sem exclusões ou duplicatas. Não houve adição de skip ou mudança de piso/política nas entradas comparadas.

## Critérios

| Critério | Resultado | Exigência |
| --- | --- | --- |
| C1 | PASS | Only own CI addition test changed count49->50, extra exact-path assertion and matching title; original371assertive source records and281coverage unchanged. |
| C2 | PASS | Original49addition paths retained and exactly one approved new path added, no skips/floors or runtime policy altered. |
| C3 | PASS | Counter and explicit membership reject count49/count51 and wrong-path count50; current50/path passes. Actual CI test body preserves aggregate zero-coverage refusal and legitimate per-file zero behavior. |
| C4 | PASS | Hash-bound inventory schema and baseline hash valid, before/after Sourceinputs specific unchanged; scoped accept only, no fullsuite or production claim. |

## Provas discriminantes

As quatro asserções efetivas do callback after foram extraídas por AST e executadas em VM, sem importar o módulo CI. Inventário atual50 passa; original49, count49 mantendo o caminho novo, count51 mantendo o caminho novo e count50 com r39 no lugar de r38 são recusados. Before49 passa com original49 e recusa o JSON atual50, demonstrando o defeito corrigido. Contagens 370/280 também são recusadas.

O corpo de cobertura tem SHA-256 1c677db6b204880076f83a6d329fc43cbb358fa5cf5453e36d2905a0a5fd8d04 em ambas as versões. AST verifica três chamadas aggregateCoverage: denominador agregado zero exige coverage_empty_executable_denominator; o fixture com arquivo não executável zero e zero legítimo de branches/functions exige pass=true; declarar o mesmo arquivo como executável exige coverage_executable_zero. Controles removendo/trocando as recusas ou alterando executable/pass são detectados. Isso prova preservação das asserções; não executa a implementação real de cobertura.

| Controle | Resultado esperado | Resultado |
| --- | --- | --- |
| C4.packet-and-original-hash | ACCEPT/INVARIANT | PASS |
| C1.only-authorized-test-delta | ACCEPT/INVARIANT | PASS |
| C1.coverage-body-byte-preservation | ACCEPT/INVARIANT | PASS |
| C1.all-other-test-source-byte-preservation | ACCEPT/INVARIANT | PASS |
| C1.baseline-and-policy-bytes-unchanged | ACCEPT/INVARIANT | PASS |
| C2.original49-schema | ACCEPT/INVARIANT | PASS |
| C2.before-and-after-inventory-retain-original | ACCEPT/INVARIANT | PASS |
| C4.schema-and-baseline-hash-binding | ACCEPT/INVARIANT | PASS |
| C3.current50-correct-path-actual-assertions-pass | ACCEPT/INVARIANT | PASS |
| C3.before49-original49-actual-assertions-pass | ACCEPT/INVARIANT | PASS |
| C3.before49-current50-rejected | REJECT | PASS |
| C3.after50-original49-rejected | REJECT | PASS |
| C3.count49-with-new-path-rejected | REJECT | PASS |
| C3.count51-with-new-path-rejected | REJECT | PASS |
| C3.wrong-path-count50-rejected | REJECT | PASS |
| C3.count370-originals-rejected | REJECT | PASS |
| C3.count280-coverage-rejected | REJECT | PASS |
| C3.actual-coverage-refusal-and-legitimate-zero-AST | ACCEPT/INVARIANT | PASS |
| C3.remove-aggregate-zero-refusal-detected | REJECT | PASS |
| C3.executable-zero-refusal-change-detected | REJECT | PASS |
| C3.legitimate-nonexecutable-zero-change-detected | REJECT | PASS |
| C3.legitimate-zero-positive-change-detected | REJECT | PASS |
| C1.unrelated-test-edit-detected | REJECT | PASS |
| C2.skip-added-detected | REJECT | PASS |
| C2.old-addition-replaced-at-count50-detected | REJECT | PASS |
| C1.original371-record-changed-detected | REJECT | PASS |
| C1.coverage281-path-substituted-detected | REJECT | PASS |
| C2.floor-change-detected | REJECT | PASS |
| C2.skip-policy-change-detected | REJECT | PASS |
| C4.schema-version-change-detected | REJECT | PASS |
| C4.baseline-hash-change-detected | REJECT | PASS |
| C4.baseline-byte-tamper-detected | REJECT | PASS |
| C4.all-specific-input-origins-stable-pre-post | ACCEPT/INVARIANT | PASS |

Schema local verifica versão/kind/chaves, tipos, hashes dos registros, sizes, unicidade de caminhos e denominadores. Binding verifica schemaVersion/contract e o SHA-256 exato do baseline registrado no contrato. Mutantes de schema, binding e bytes do baseline são recusados. JSON de política inteiro permanece idêntico; controles de floor/skip detectam diferenças.

## Hashes antes/depois

| Cópia | SHA-256 antes da revisão | SHA-256 depois da revisão | Origem readonly |
| --- | --- | --- | --- |
| before/tests/hiso-ci-scopes.test.js | b33b84065ebade07071fa13fea70f7424d2573d507b59e0b5ee471f2cc0c3097 | b33b84065ebade07071fa13fea70f7424d2573d507b59e0b5ee471f2cc0c3097 | igual à origem exata, antes/depois |
| before/scripts/hiso-baseline-inventory.json | f2d4ef6ef8c17fdf13002b01dd5ffba30fdcc89f51b8f988be6bc864b31d12b5 | f2d4ef6ef8c17fdf13002b01dd5ffba30fdcc89f51b8f988be6bc864b31d12b5 | igual à origem exata, antes/depois |
| before/scripts/hiso-ci-scopes.json | 13f82e929333604dcef0b390f776e3049ac8f765b1da1d2fb17080dc8803fc17 | 13f82e929333604dcef0b390f776e3049ac8f765b1da1d2fb17080dc8803fc17 | igual à origem exata, antes/depois |
| after/tests/hiso-ci-scopes.test.js | dff847023d7d36746f5c3fb6be8bdcbfae415634af233c6663f06abe77e83a51 | dff847023d7d36746f5c3fb6be8bdcbfae415634af233c6663f06abe77e83a51 | igual à origem exata, antes/depois |
| after/scripts/hiso-baseline-inventory.json | f2d4ef6ef8c17fdf13002b01dd5ffba30fdcc89f51b8f988be6bc864b31d12b5 | f2d4ef6ef8c17fdf13002b01dd5ffba30fdcc89f51b8f988be6bc864b31d12b5 | igual à origem exata, antes/depois |
| after/scripts/hiso-ci-scopes.json | 13f82e929333604dcef0b390f776e3049ac8f765b1da1d2fb17080dc8803fc17 | 13f82e929333604dcef0b390f776e3049ac8f765b1da1d2fb17080dc8803fc17 | igual à origem exata, antes/depois |

Cada caminho de origem absoluto e seus hashes antes/depois estão em verdict.json, junto dos comandos, controles e asserções extraídas. Thresholds preservados: {"statements":90,"branches":85,"functions":90,"lines":90}.

## Limites

- Aceitação exclusiva do delta de teste CI nas cópias vinculadas por hash; nenhuma autoridade de release.
- Não executada a suíte CI/Vitest completa, nem aggregateCoverage/validateContract/sourceFiles do Source. Recusas de cobertura verificadas por AST e preservação exata do corpo; seu comportamento de runtime não foi revalidado.
- Executadas somente as quatro asserções reais de contagem/membership extraídas por AST, em VM com matcher assert próprio e fixtures JSON em memória.
- Schema conferido por controles próprios do envelope de inventário e binding SHA-256 local; nenhuma validação global de contratos ou inventário físico da árvore.
- O caminho novo está explicitamente inventariado e exigido pelo teste. O conteúdo, existência física e execução desse arquivo não integram os inputs autorizados e não foram inspecionados.
- Hashes internos dos 371 registros foram preservados, sem abrir seus arquivos. Políticas só nas cópias JSON/teste autorizadas; nenhuma inferência sobre outros arquivos de runtime.
- A autoridade T2/SPEC0180 é declarada pelo packet; documentos de aprovação não foram acessados. Sem conclusão sobre suíte completa, runtime ou produção.

Nenhum Sourcewrite ou cache de execução gerado; apenas review.mjs, report.md e verdict.json no output autorizado. Nenhuma leitura de Root/gov/history/.gauntlet, relatórios antigos, env/key, descendentes adicionais ou documentos de governança. Strings desses caminhos contidas nos JSONs autorizados não foram resolvidas.
