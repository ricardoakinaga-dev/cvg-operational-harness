import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { createRequire } from 'node:module';

const authority = '/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/ci-count-fresh-review-r45/authority';
const output = path.resolve(authority, '../output');
const parserPath = '/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/candidate-inventory-r44/node_modules/typescript/lib/typescript.js';
const ts = createRequire(import.meta.url)(parserPath);
const startedAt = new Date().toISOString();
const packetBytes = fs.readFileSync(path.join(authority, 'packet.json'));
const packet = JSON.parse(packetBytes);
assert.equal(packet.writeOnly, output);
assert.equal(process.version, 'v22.23.2');
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const read = p => fs.readFileSync(path.join(authority, p));
const inputs = new Map(packet.inputs.map(i => [i.copy, read(i.copy)]));
const originalBytes = read('original-49-inventory.json');
const original = JSON.parse(originalBytes);
const before = inputs.get('before/tests/hiso-ci-scopes.test.js').toString();
const after = inputs.get('after/tests/hiso-ci-scopes.test.js').toString();
const baselineBefore = JSON.parse(inputs.get('before/scripts/hiso-baseline-inventory.json'));
const baseline = JSON.parse(inputs.get('after/scripts/hiso-baseline-inventory.json'));
const contractBytes = inputs.get('after/scripts/hiso-ci-scopes.json');
const contract = JSON.parse(contractBytes);
const newPath = 'products/shift-assistant/src/__tests__/live-offline-r38-own.test.ts';
const titleBefore = 'rejects zero coverage across the original and thirty-eight explicitly added test paths without inflating legitimate zero per-file metrics';
const titleAfter = titleBefore.replace('thirty-eight', 'fifty');
const oldCount = 'expect(baseline.newTests).toHaveLength(49)';
const newCount = 'expect(baseline.newTests).toHaveLength(50)';
const added = `\n    expect(baseline.newTests).toContain(\n      '${newPath}'\n    )`;
const controls = [];
function check(id, fn, detail = {}) { fn(); controls.push({ id, status: 'PASS', ...detail }); }
function rejects(id, fn) { let error; try { fn(); } catch (e) { error = e; } assert.ok(error, `control failed to reject: ${id}`); controls.push({ id, status: 'PASS', expected: 'REJECT', error: error.message }); }
function replaceOnce(text, old, replacement) { assert.equal(text.split(old).length, 2, 'exactly one replacement site'); return text.replace(old, replacement); }
function parse(text, filename) { const ast = ts.createSourceFile(filename, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS); assert.equal(ast.parseDiagnostics.length, 0); return ast; }
function nodes(root, predicate) { const result = []; function walk(n) { if (predicate(n)) result.push(n); ts.forEachChild(n, walk); } walk(root); return result; }
function target(text, expectedTitle) {
  const ast = parse(text, 'review-input.js');
  const matches = nodes(ast, n => ts.isCallExpression(n) && n.expression.getText(ast) === 'it' && ts.isStringLiteral(n.arguments[0]) && n.arguments[0].text === expectedTitle);
  assert.equal(matches.length, 1);
  const call = matches[0]; assert.equal(call.arguments.length, 2);
  const callback = call.arguments[1]; assert.ok(ts.isArrowFunction(callback)); assert.ok(ts.isBlock(callback.body));
  return { ast, call, callback, statements: [...callback.body.statements] };
}
function exactDelta(candidate) {
  let expected = replaceOnce(before, titleBefore, titleAfter);
  expected = replaceOnce(expected, oldCount, newCount + added);
  assert.equal(candidate, expected, 'full byte equality after the three authorized edits');
  const b = target(before, titleBefore), a = target(candidate, titleAfter);
  const normalizedStatements = a.statements.map(n => n.getText(a.ast)).filter(s => s !== `expect(baseline.newTests).toContain(\n      '${newPath}'\n    )`).map(s => s.replace(newCount, oldCount));
  assert.deepEqual(normalizedStatements, b.statements.map(n => n.getText(b.ast)), 'every existing callback statement retained');
  return { b, a };
}
function schema(j, count) {
  assert.deepEqual(Object.keys(j).sort(), ['schemaVersion', 'kind', 'scope', 'tests', 'coveragePaths', 'newTests', 'newCoveragePaths'].sort());
  assert.equal(j.schemaVersion, 1); assert.equal(j.kind, 'hiso-approved-source-inventory-v1'); assert.equal(typeof j.scope, 'string');
  for (const key of ['tests', 'coveragePaths', 'newTests', 'newCoveragePaths']) assert.ok(Array.isArray(j[key]));
  for (const row of j.tests) {
    assert.deepEqual(Object.keys(row).sort(), ['path', 'sha256', 'size']);
    assert.equal(typeof row.path, 'string'); assert.match(row.sha256, /^[a-f0-9]{64}$/); assert.ok(Number.isSafeInteger(row.size) && row.size >= 0);
  }
  for (const key of ['coveragePaths', 'newTests', 'newCoveragePaths']) for (const p of j[key]) {
    assert.equal(typeof p, 'string'); assert.ok(p.length > 0 && !p.startsWith('/') && !p.split('/').includes('..'));
  }
  const testPaths = [...j.tests.map(r => r.path), ...j.newTests];
  const coveragePaths = [...j.coveragePaths, ...j.newCoveragePaths];
  assert.equal(new Set(testPaths).size, testPaths.length); assert.equal(new Set(coveragePaths).size, coveragePaths.length);
  assert.equal(j.tests.length, 371); assert.equal(j.coveragePaths.length, 275); assert.equal(j.newCoveragePaths.length, 6); assert.equal(j.newTests.length, count);
}
function inventory(j) {
  schema(j, 50);
  for (const key of Object.keys(original).filter(k => k !== 'newTests')) assert.deepEqual(j[key], original[key], `original field ${key} retained exactly`);
  assert.deepEqual(j.newTests.filter(p => p !== newPath), original.newTests, 'all original49 additions retained in order');
  assert.equal(j.newTests.filter(p => p === newPath).length, 1);
}
function binding(j, bytes) {
  assert.equal(j.schemaVersion, 1); assert.equal(j.contract, 'hiso-ci-scopes-v1');
  assert.deepEqual(j.baselineInventory, { path: 'scripts/hiso-baseline-inventory.json', sha256: sha(bytes) });
  assert.match(j.approvedSpecSha256, /^[a-f0-9]{64}$/);
}

const hashRows = packet.inputs.map(i => {
  const copyHash = sha(inputs.get(i.copy));
  const originHash = sha(fs.readFileSync(i.source));
  assert.equal(copyHash, i.sha256); assert.equal(originHash, copyHash);
  return { copy: i.copy, source: i.source, expectedSha256: i.sha256, copyBeforeSha256: copyHash, originBeforeSha256: originHash, bytes: inputs.get(i.copy).length };
});
check('C4.packet-and-original-hash', () => assert.equal(sha(originalBytes), packet.original49Sha256));
check('C1.only-authorized-test-delta', () => exactDelta(after));
const { b, a } = exactDelta(after);
const coverageTail = t => t.statements.slice(t.statements.findIndex(n => n.getText(t.ast).startsWith('expect(() =>'))).map(n => n.getText(t.ast)).join('\n');
check('C1.coverage-body-byte-preservation', () => assert.equal(coverageTail(a), coverageTail(b)), { sha256: sha(coverageTail(a)) });
check('C1.all-other-test-source-byte-preservation', () => {
  assert.equal(after.slice(0, a.call.getStart(a.ast)), before.slice(0, b.call.getStart(b.ast)));
  assert.equal(after.slice(a.call.end), before.slice(b.call.end));
});
check('C1.baseline-and-policy-bytes-unchanged', () => {
  assert.ok(inputs.get('before/scripts/hiso-baseline-inventory.json').equals(inputs.get('after/scripts/hiso-baseline-inventory.json')));
  assert.ok(inputs.get('before/scripts/hiso-ci-scopes.json').equals(contractBytes));
});
check('C2.original49-schema', () => schema(original, 49));
check('C2.before-and-after-inventory-retain-original', () => { inventory(baselineBefore); inventory(baseline); });
check('C4.schema-and-baseline-hash-binding', () => { binding(contract, inputs.get('after/scripts/hiso-baseline-inventory.json')); binding(JSON.parse(inputs.get('before/scripts/hiso-ci-scopes.json')), inputs.get('before/scripts/hiso-baseline-inventory.json')); });

// Execute only the actual assertion expressions, never the imported CI module.
function assertionStatements(t) {
  return t.statements.filter(n => /^expect\((paths|baseline\.(tests|newTests))\)\./.test(n.getText(t.ast))).map(n => n.getText(t.ast));
}
const extractedAssertions = assertionStatements(a);
assert.equal(extractedAssertions.length, 4);
const expect = actual => ({
  toHaveLength: n => assert.equal(actual.length, n, `length ${actual.length} must equal ${n}`),
  toContain: p => assert.ok(actual.includes(p), `missing exact path ${p}`)
});
function executeAssertions(t, j, paths = [...j.coveragePaths, ...j.newCoveragePaths]) {
  vm.runInNewContext(assertionStatements(t).join('\n'), { baseline: j, paths, expect }, { timeout: 1000 });
}
check('C3.current50-correct-path-actual-assertions-pass', () => executeAssertions(a, baseline));
check('C3.before49-original49-actual-assertions-pass', () => executeAssertions(b, original));
rejects('C3.before49-current50-rejected', () => executeAssertions(b, baseline));
rejects('C3.after50-original49-rejected', () => executeAssertions(a, original));
const count49 = structuredClone(baseline); count49.newTests = count49.newTests.filter(p => p !== original.newTests[0]);
rejects('C3.count49-with-new-path-rejected', () => executeAssertions(a, count49));
const count51 = structuredClone(baseline); count51.newTests.push('tests/synthetic-extra.test.js');
rejects('C3.count51-with-new-path-rejected', () => executeAssertions(a, count51));
const wrongPath = structuredClone(baseline); wrongPath.newTests[wrongPath.newTests.indexOf(newPath)] = newPath.replace('r38', 'r39');
rejects('C3.wrong-path-count50-rejected', () => executeAssertions(a, wrongPath));
const wrong371 = structuredClone(baseline); wrong371.tests.pop();
rejects('C3.count370-originals-rejected', () => executeAssertions(a, wrong371));
rejects('C3.count280-coverage-rejected', () => executeAssertions(a, baseline, baseline.coveragePaths.concat(baseline.newCoveragePaths).slice(1)));

// Independent structural invariants for the unchanged coverage refusal body.
function coverageStructure(text, title) {
  const t = target(text, title);
  const aggregateCalls = nodes(t.callback, n => ts.isCallExpression(n) && n.expression.getText(t.ast) === 'aggregateCoverage');
  assert.equal(aggregateCalls.length, 3);
  assert.deepEqual(aggregateCalls.map(n => n.arguments.length), [2, 3, 3]);
  const throws = nodes(t.callback, n => ts.isCallExpression(n) && ts.isPropertyAccessExpression(n.expression) && n.expression.name.text === 'toThrow');
  assert.deepEqual(throws.map(n => n.arguments[0].text), ['coverage_empty_executable_denominator', 'coverage_executable_zero']);
  assert.equal(throws[0].expression.expression.expression.getText(t.ast), 'expect');
  assert.ok(ts.isArrowFunction(throws[0].expression.expression.arguments[0]));
  assert.ok(throws[0].getText(t.ast).includes('paths.map((p) => [p, coverage(0, 0)])'));
  const positive = nodes(t.callback, n => ts.isCallExpression(n) && ts.isPropertyAccessExpression(n.expression) && n.expression.name.text === 'toBe');
  assert.equal(positive.length, 1); assert.equal(positive[0].arguments[0].kind, ts.SyntaxKind.TrueKeyword);
  assert.ok(positive[0].getText(t.ast).includes(').pass'));
  const sources = nodes(t.callback, n => ts.isVariableDeclaration(n) && n.name.getText(t.ast) === 'sources');
  assert.equal(sources.length, 1); assert.ok(ts.isArrayLiteralExpression(sources[0].initializer));
  const rows = sources[0].initializer.elements.map(n => Object.fromEntries(n.properties.map(p => [p.name.getText(t.ast), p.initializer.getText(t.ast)])));
  assert.deepEqual(rows.map(r => [r.path, r.executable]), [["'packages/a.ts'", 'true'], ["'packages/branched-function.ts'", 'true'], ["'packages/types.ts'", 'false']]);
  const firstArgs = aggregateCalls[1].arguments[0].getText(t.ast);
  assert.ok(firstArgs.includes("'packages/types.ts': zero")); assert.ok(firstArgs.includes("'packages/branched-function.ts': coverage(2, 2)"));
  assert.equal(aggregateCalls[1].arguments[2].getText(t.ast), 'sources');
  assert.equal(aggregateCalls[2].arguments[2].getText(t.ast), 'sources.map((s) => ({ ...s, executable: true }))');
  const statements = t.statements.map(n => n.getText(t.ast));
  assert.ok(statements.includes('one.branches = zero.branches')); assert.ok(statements.includes('one.functions = zero.functions'));
  assert.ok(statements.includes('const one = coverage(10, 10),\n      zero = coverage(0, 0)'));
}
check('C3.actual-coverage-refusal-and-legitimate-zero-AST', () => { coverageStructure(before, titleBefore); coverageStructure(after, titleAfter); });
rejects('C3.remove-aggregate-zero-refusal-detected', () => coverageStructure(after.replace(".toThrow('coverage_empty_executable_denominator')", '.toBe(true)'), titleAfter));
rejects('C3.executable-zero-refusal-change-detected', () => coverageStructure(after.replace(".toThrow('coverage_executable_zero')", ".toThrow('wrong')"), titleAfter));
rejects('C3.legitimate-nonexecutable-zero-change-detected', () => coverageStructure(after.replace("{ path: 'packages/types.ts', sha256: H, executable: false }", "{ path: 'packages/types.ts', sha256: H, executable: true }"), titleAfter));
rejects('C3.legitimate-zero-positive-change-detected', () => coverageStructure(after.replace(').pass\n    ).toBe(true)', ').pass\n    ).toBe(false)'), titleAfter));
rejects('C1.unrelated-test-edit-detected', () => exactDelta(after.replace("const H = 'a'.repeat(64)", "const H = 'b'.repeat(64)")));
rejects('C2.skip-added-detected', () => exactDelta(after.replace(`it('${titleAfter}'`, `it.skip('${titleAfter}'`)));
const lostOld = structuredClone(baseline); lostOld.newTests[0] = 'tests/synthetic-replacement.test.js';
rejects('C2.old-addition-replaced-at-count50-detected', () => inventory(lostOld));
const recordChanged = structuredClone(baseline); recordChanged.tests[0].sha256 = '0'.repeat(64);
rejects('C1.original371-record-changed-detected', () => inventory(recordChanged));
const coverageChanged = structuredClone(baseline); coverageChanged.coveragePaths[0] = 'packages/synthetic.ts';
rejects('C1.coverage281-path-substituted-detected', () => inventory(coverageChanged));
const policyChanged = structuredClone(contract); policyChanged.coverage.thresholds.lines -= 1;
rejects('C2.floor-change-detected', () => assert.deepEqual(policyChanged, contract));
const skipChanged = structuredClone(contract); skipChanged.scopes[0].gates[0].skipPolicy = 'all';
rejects('C2.skip-policy-change-detected', () => assert.deepEqual(skipChanged, contract));
const badSchema = structuredClone(baseline); badSchema.schemaVersion = 2;
rejects('C4.schema-version-change-detected', () => schema(badSchema, 50));
const badHash = structuredClone(contract); badHash.baselineInventory.sha256 = '0'.repeat(64);
rejects('C4.baseline-hash-change-detected', () => binding(badHash, inputs.get('after/scripts/hiso-baseline-inventory.json')));
rejects('C4.baseline-byte-tamper-detected', () => binding(contract, Buffer.concat([inputs.get('after/scripts/hiso-baseline-inventory.json'), Buffer.from(' ')])));

for (const row of hashRows) {
  row.copyAfterSha256 = sha(read(row.copy));
  row.originAfterSha256 = sha(fs.readFileSync(row.source));
  assert.equal(row.copyAfterSha256, row.copyBeforeSha256); assert.equal(row.originAfterSha256, row.originBeforeSha256);
}
assert.equal(sha(read('original-49-inventory.json')), sha(originalBytes));
assert.equal(sha(read('packet.json')), sha(packetBytes));
check('C4.all-specific-input-origins-stable-pre-post', () => {});
const criteria = packet.criteria.map((description, i) => ({ id: `C${i + 1}`, description, status: 'PASS', controls: controls.filter(c => c.id.startsWith(`C${i + 1}.`)).map(c => c.id) }));
const limits = [
  'Aceitação exclusiva do delta de teste CI nas cópias vinculadas por hash; nenhuma autoridade de release.',
  'Não executada a suíte CI/Vitest completa, nem aggregateCoverage/validateContract/sourceFiles do Source. Recusas de cobertura verificadas por AST e preservação exata do corpo; seu comportamento de runtime não foi revalidado.',
  'Executadas somente as quatro asserções reais de contagem/membership extraídas por AST, em VM com matcher assert próprio e fixtures JSON em memória.',
  'Schema conferido por controles próprios do envelope de inventário e binding SHA-256 local; nenhuma validação global de contratos ou inventário físico da árvore.',
  'O caminho novo está explicitamente inventariado e exigido pelo teste. O conteúdo, existência física e execução desse arquivo não integram os inputs autorizados e não foram inspecionados.',
  'Hashes internos dos 371 registros foram preservados, sem abrir seus arquivos. Políticas só nas cópias JSON/teste autorizadas; nenhuma inferência sobre outros arquivos de runtime.',
  'A autoridade T2/SPEC0180 é declarada pelo packet; documentos de aprovação não foram acessados. Sem conclusão sobre suíte completa, runtime ou produção.'
];
const node = '/home/ricardo/.nvm/versions/node/v22.23.2/bin/node';
const command = `${node} '${output}/review.mjs'`;
const verdict = {
  schemaVersion: 1, task: packet.task, verdict: 'APPROVE_SCOPED_CI_DELTA', accepted: true,
  scope: '49->50 + exact new-path assertion + matching title only',
  startedAt, finishedAt: new Date().toISOString(), runtime: process.version, parser: { path: parserPath, version: ts.version, readonly: true },
  command, packetSha256: sha(packetBytes), original49Sha256: sha(originalBytes), reviewerScriptSha256: sha(fs.readFileSync(new URL(import.meta.url))),
  hashes: hashRows, criteria, controls,
  inventory: { originals: 371, coverageBase: 275, coverageAdded: 6, coverageTotal: 281, previousAdditions: 49, currentAdditions: 50, addedPath: newPath, removedPaths: [], original49RetainedInOrder: true },
  test: { beforeTitle: titleBefore, afterTitle: titleAfter, extractedAssertions, coverageTailSha256: sha(coverageTail(a)), onlyAuthorizedDelta: true },
  policy: { publicSchemaOrPolicyChangedInComparedInputs: false, coverageThresholds: contract.coverage.thresholds, skipPolicyBytesUnchanged: true },
  sourceWrites: 0, providerCalls: 0, networkCalls: 0, childProcessesFromReview: 0,
  fullSuite: 'NOT_RUN', runtimeValidation: 'NOT_RUN', productionApproval: false, releaseGranted: false, findings: [], limits
};
const hashesTable = hashRows.map(r => `| ${r.copy} | ${r.copyBeforeSha256} | ${r.copyAfterSha256} | igual à origem exata, antes/depois |`).join('\n');
const criterionRows = criteria.map(c => `| ${c.id} | PASS | ${c.description} |`).join('\n');
const controlRows = controls.map(c => `| ${c.id} | ${c.expected ?? 'ACCEPT/INVARIANT'} | ${c.status} |`).join('\n');
const report = `# Revisão independente finita R45\n\n**APPROVE_SCOPED_CI_DELTA** — somente atualização do teste CI 49→50, asserção do caminho exato e título compatível. Todos os quatro critérios passam; nenhum release concedido.\n\nRevisão própria em Node ${process.version}, parser TypeScript ${ts.version} existente e readonly. Início: ${startedAt}; conclusão: ${verdict.finishedAt}.\n\n## Entradas e método\n\nSomente packet.json, suas seis cópias técnicas, original-49-inventory.json e hashes readonly das seis origens exatas especificadas no packet. Nenhuma enumeração de árvore. O script reproduzível adjacente contém os controles completos, os fixtures em memória e as leituras explícitas. Saídas apenas em ${output}.\n\nComando de verificação executado (exit 0):\n\n\`\`\`sh\n${command}\n\`\`\`\n\nInspeção preliminar: cat packet.json e três invocações Node --input-type=module com heredoc para leitura das cópias, resumos JSON/hashes/delta e AST do caso alterado. A primeira leitura teve saída truncada; nenhuma conclusão depende desse dump: o script final verifica integralmente os bytes/JSON/AST. Sem npm, shell/filhos invocados pelo script, rede, provider, DB ou Docker.\n\nPacket SHA-256: ${sha(packetBytes)}. Original49 SHA-256 antes/depois: ${sha(originalBytes)} (igual ao packet). Script de revisão SHA-256: ${verdict.reviewerScriptSha256}.\n\n## Delta e inventário\n\nUma reconstrução byte a byte aplica ao teste before somente três edições: thirty-eight→fifty no título, toHaveLength(49)→toHaveLength(50), e toContain('${newPath}'). Resultado idêntico ao after inteiro. Todos os outros bytes do teste, e cada statement prévio do callback por AST, permanecem iguais.\n\nOs inventários before e after já têm 50 adicionais e são idênticos: o before do teste estava defasado em relação ao JSON. Comparados com original-49-inventory.json, preservam todos os demais campos, os 371 registros completos (path/sha256/size), 275+6=281 caminhos de cobertura e os 49 adicionais em ordem. O único adicional é ${newPath}, uma única vez, sem exclusões ou duplicatas. Não houve adição de skip ou mudança de piso/política nas entradas comparadas.\n\n## Critérios\n\n| Critério | Resultado | Exigência |\n| --- | --- | --- |\n${criterionRows}\n\n## Provas discriminantes\n\nAs quatro asserções efetivas do callback after foram extraídas por AST e executadas em VM, sem importar o módulo CI. Inventário atual50 passa; original49, count49 mantendo o caminho novo, count51 mantendo o caminho novo e count50 com r39 no lugar de r38 são recusados. Before49 passa com original49 e recusa o JSON atual50, demonstrando o defeito corrigido. Contagens 370/280 também são recusadas.\n\nO corpo de cobertura tem SHA-256 ${sha(coverageTail(a))} em ambas as versões. AST verifica três chamadas aggregateCoverage: denominador agregado zero exige coverage_empty_executable_denominator; o fixture com arquivo não executável zero e zero legítimo de branches/functions exige pass=true; declarar o mesmo arquivo como executável exige coverage_executable_zero. Controles removendo/trocando as recusas ou alterando executable/pass são detectados. Isso prova preservação das asserções; não executa a implementação real de cobertura.\n\n| Controle | Resultado esperado | Resultado |\n| --- | --- | --- |\n${controlRows}\n\nSchema local verifica versão/kind/chaves, tipos, hashes dos registros, sizes, unicidade de caminhos e denominadores. Binding verifica schemaVersion/contract e o SHA-256 exato do baseline registrado no contrato. Mutantes de schema, binding e bytes do baseline são recusados. JSON de política inteiro permanece idêntico; controles de floor/skip detectam diferenças.\n\n## Hashes antes/depois\n\n| Cópia | SHA-256 antes da revisão | SHA-256 depois da revisão | Origem readonly |\n| --- | --- | --- | --- |\n${hashesTable}\n\nCada caminho de origem absoluto e seus hashes antes/depois estão em verdict.json, junto dos comandos, controles e asserções extraídas. Thresholds preservados: ${JSON.stringify(contract.coverage.thresholds)}.\n\n## Limites\n\n${limits.map(l => '- ' + l).join('\n')}\n\nNenhum Sourcewrite ou cache de execução gerado; apenas review.mjs, report.md e verdict.json no output autorizado. Nenhuma leitura de Root/gov/history/.gauntlet, relatórios antigos, env/key, descendentes adicionais ou documentos de governança. Strings desses caminhos contidas nos JSONs autorizados não foram resolvidas.\n`;
fs.writeFileSync(path.join(output, 'report.md'), report);
fs.writeFileSync(path.join(output, 'verdict.json'), JSON.stringify(verdict, null, 2) + '\n');
console.log(JSON.stringify({ verdict: verdict.verdict, criteria: criteria.map(c => ({ id: c.id, status: c.status })), controls: controls.length, report: path.join(output, 'report.md'), verdictPath: path.join(output, 'verdict.json') }, null, 2));
