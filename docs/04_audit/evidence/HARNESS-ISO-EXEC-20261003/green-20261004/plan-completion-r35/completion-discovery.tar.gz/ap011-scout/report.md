# R35-AP011 — descoberta C4, 05/10/2026

**WAHA 2026.9.2 e Evolution 2.3.7/Baileys SUPORTAM documentalmente recibos correlacionáveis para mensagens individuais. AP011 operacional continua INCONCLUSIVO/NOT_QUALIFIED.** Esta é descoberta limitada, não revisão de aceite. Nenhum provider foi executado; AP011 permanece entrega comprovada em até 60 s após dueAt.

Consulta iniciada 19:08 UTC; fontes oficiais recuperadas entre 19:09 e 19:13 UTC em **05/10/2026**. URLs, SHA-256 dos bytes HTTP e hashes locais estão em [findings.json](findings.json). Documentos e código remoto foram tratados como dados. Só estes dois arquivos foram escritos; sem descendants, instalações, suites, .env, portas, DB, chamadas de canal ou mudanças Root/Source.

## Versões e classificação

As releases oficiais continuam [WAHA 2026.9.2](https://github.com/devlikeapro/waha/releases/tag/2026.9.2), commit `90ba445a0e765701c8910f0fac08176250c3e0fd`, e [Evolution 2.3.7](https://github.com/evolution-foundation/evolution-api/releases/tag/2.3.7), commit `cd800f2976e1e5b682fbf86a01ee4d85ae61f370`. A tag Evolution é anotada: objeto `6a398a6a08e59eb87dcf98b0f389e8decaf08689`, resolvido ao commit acima. Conferência feita também pelos endpoints oficiais GitHub de release/tag.

| Provider/versão/escopo | Recibo correlacionável | Limite da conclusão |
| --- | --- | --- |
| WAHA 2026.9.2, individual WEBJS/NOWEB | **SUPORTA** | Docs atuais + código congelado; wire de envio, identidade e adapter não homologados. |
| WAHA 2026.9.2, individual WPP/GOWS | **SUPORTA**, declaração documental | Matriz oficial declara message.ack; implementação desses engines não inspecionada nesta rodada. |
| Evolution 2.3.7, individual Baileys | **SUPORTA** | Handler versionado fornece campos; configuração de armazenamento pode impedir emissão. |
| Evolution outros canais/versões; entrega por destinatário em grupos | **INCONCLUSIVO** | Sem contrato equivalente qualificado neste escopo. |
| WAHA 2026.9.2 SERVER; Evolution 2.3.7 SERVER_ACK usados como entrega | **NÃO SUPORTA** | Esses estados provam aceitação pelo servidor, não entrega ao dispositivo. |
| AP011 ≤60 s no adapter real escolhido, em qualquer dos dois | **INCONCLUSIVO** | Não há execução/recibo real ou demonstração de latência nesta pesquisa. |

## Join exato e semântica

**WAHA:** [Events/message.ack](https://waha.devlike.pro/docs/how-to/events/#messageack) separa SERVER=1, DEVICE=2, READ=3 e PLAYED=4. DEVICE basta para entrega ao dispositivo; leitura é estado posterior e não exigência AP011. O [envelope/DTO congelado](https://github.com/devlikeapro/waha/blob/90ba445a0e765701c8910f0fac08176250c3e0fd/src/structures/webhooks.dto.ts) fornece `session`, `payload.id/from/fromMe/ack/ackName`; `me` é opcional. O payload mínimo publicado não garante `to`.

Join necessário: callback autenticado da implantação/conta histórica correta; `session == dispatch.identity.accountRef`; `payload.fromMe === true`; ID completo serializado do evento igual ao ID canônico persistido em `outbox.receipt.providerId`; destinatário JID igual ao destinatário histórico da mesma outbox/tentativa. No [WEBJS](https://github.com/devlikeapro/waha/blob/90ba445a0e765701c8910f0fac08176250c3e0fd/src/core/engines/webjs/session.webjs.core.ts#L2801), ACK usa ID serializado e `to`. No [NOWEB](https://github.com/devlikeapro/waha/blob/90ba445a0e765701c8910f0fac08176250c3e0fd/src/core/engines/noweb/session.noweb.core.ts#L3517), ACK de contato individual usa `from = key.remoteJid`, enquanto `to` pode faltar (helper L3899). O [construtor do ID NOWEB](https://github.com/devlikeapro/waha/blob/90ba445a0e765701c8910f0fac08176250c3e0fd/src/core/engines/noweb/utils.ts#L10) inclui fromMe, chatId, id e participante opcional. **key.id isolado não é o ID serializado de ACK.** O wire efetivo de sendText precisa de contrato por engine; o tipo WAMessage no controller não prova a forma JSON recebida.

**Evolution:** a [documentação oficial de webhooks](https://github.com/evolution-foundation/evolution-docs/blob/main/docs/02-Configuration/Webhooks.md) declara MESSAGES_UPDATE, sem schema detalhado/versionado. O [handler Baileys 2.3.7](https://github.com/evolution-foundation/evolution-api/blob/cd800f2976e1e5b682fbf86a01ee4d85ae61f370/src/api/integrations/channel/whatsapp/whatsapp.baileys.service.ts#L1558) publica `data.keyId, remoteJid, fromMe, instanceId, status`; envio retorna `key.id, key.remoteJid, key.fromMe, instanceId`. Join: `send.key.id == update.data.keyId`, destinatário `send.key.remoteJid == update.data.remoteJid`, fromMe=true, instanceId idêntico, mais `envelope.instance` vinculado à conta histórica. `data.messageId`, quando presente, é ID de registro interno, não substituto de keyId. Em HISTORIC/NEW_MESSAGE, o handler pode remapear keyId via protocol cache e executar continue antes do webhook se não encontrar registro (L1628–1650). Falta demonstrar esse ramo na configuração escolhida.

O [mapa de status](https://github.com/evolution-foundation/evolution-api/blob/cd800f2976e1e5b682fbf86a01ee4d85ae61f370/src/utils/renderStatus.ts) distingue SERVER_ACK=2, DELIVERY_ACK=3, READ=4 e PLAYED=5. Os números não são intercambiáveis com WAHA. O [controller de webhook](https://github.com/evolution-foundation/evolution-api/blob/cd800f2976e1e5b682fbf86a01ee4d85ae61f370/src/api/integrations/event/webhook/webhook.controller.ts#L93) acrescenta instance, sender e date_time; esses valores não são prova independente de conta nem timestamp de entrega ao dispositivo.

**Cross-session:** nome de sessão/instância e ID de mensagem isolados não estabelecem identidade global ou histórica da conta. É preciso vincular implantação autenticada, conta WhatsApp do envio, sessão/instância e destinatário à tentativa persistida; troca/recriação de conta sob o mesmo nome e replay após restart não podem herdar a conta atual. PN/LID precisam de correspondência comprovada, sem transformar dígitos de LID em telefone. O provider não promete devolver o ID local da outbox.

## Offline e operação saudável

A SPEC 0179 L175–183 já distingue aceitação/entrega e inclui destinatário autorizado com ao menos um dispositivo conectado, canal apto, storage/scheduler/rede disponíveis e carga qualificada. A nota adjacente de aprovação autoriza BUILD local sintético; não autoriza provider real. “Offline” aqui significa **nenhum dispositivo do destinatário alcançável**, não apenas celular desligado, ausência de leitura ou presença indisponível.

Inferência: servidor pode aceitar enquanto ainda não existe entrega comprovada. Ausência de DEVICE/DELIVERY_ACK não diagnostica offline: também pode ser callback/configuração/rede falhando. Não se deve excluir atrasos retroativamente classificando destinatário como offline. Entrega tardia/offline continua registrada com estado conservado, sem PASS, sem reenvio cego e sem relaxar 60 s. WAHA timestamp é criação do evento; Evolution date_time é do envelope; nenhum foi qualificado como deliveredAt. O gate usa committedAt local conservador, conforme SPEC.

## Provas/contratos concretos ainda ausentes

1. **Adapter real:** R25 tem apenas `recordSimulatedDelivery`, schema `simulation:true`, rota `/callbacks/delivery-simulation` e health `NOT_QUALIFIED`. Falta tradução autenticada de message.ack/messages.update reais; auth atual do simulador não homologa [HMAC WAHA](https://waha.devlike.pro/docs/how-to/events/#hmac-authentication) nem headers/JWT Evolution.
2. **Wire/ID WAHA:** falta resposta de sendText com forma por engine e transformação verificável ao ID completo do ACK. R25 whatsapp.ts L313 só extrai string `json.id` ou `json.key.id`; não comprova serialização/recipient/session do wire escolhido.
3. **Cobertura Evolution:** falta configuração congelada que demonstre emissão e correlação sob lookup ausente/remapeamento protocol, sem confundir messageId interno com keyId.
4. **Conta e destinatário históricos:** R25 vertical-state.ts L102–163 já conserva tupla sintética de despacho; falta prova real da vinculação conta↔sessão/instanceId, PN↔LID quando aplicável e negativo de recriação/replay com mesmo nome/ID.
5. **AP011-LATENCY:** falta prova do provider/adapter selecionado: dueAt→commit durável ≤60 s para caso único/lote mínimo20, carga concorrente, restart, receipt antecipado/duplicado e negativos de entrega120s/ausente/autenticação ou identidade inválida. Esta pesquisa não executou testes nem nega evidências sintéticas preexistentes.
6. **Condições saudáveis:** definição textual existe; falta prova independente de alcance do destinatário e classificação da falha, evitando usar ausência/atraso do próprio recibo como justificativa para retirar o caso da medição.

## Evidências anteriores efetivamente lidas

C4: `docs/08_runtime/handoffs/harness_isolation_audit_actions_20261003.md:77`. Prior report e correlation JSON são byte-idênticos entre Root e R25. Os três hashes remotos guardados naquele JSON foram recuperados novamente e coincidem. O excerpt WAHA anterior estava fora do DTO de ACK; nesta rodada foram inspecionados os campos reais e os helpers de engine.

| Input R25 | SHA-256 |
| --- | --- |
| ap011-provider-delivery-receipt-r1.md | `97062b799e5025f41a85473490de0c8ecc6afcf3eb0b849dd4c23872facd3e55` |
| ap011-correlation-source-observations.json | `bd12a3e82d01ba0600abb922b0e6c174b96aaaf3adbd937912ca17b220c1199e` |
| SPEC 0179 | `988192fe48737b4571ed659f051e22f3a9283d5c433e7c6c078e1dd0f7be86c3` |
| delivery-receipts.ts | `0f27fd92c015bf3b8c446c3ad0447f3f1c6c383254557400319aacaff5dcdb0e` |

Os portais doc.evolution-api.com de webhooks/send-text falharam no navegador; foram usados docs/repositório oficiais, com limitação registrada. Pesquisa C4 confirma caminhos documentais; não concede aceite de adapter, piloto ou AP011. Próxima dependência concreta: contrato do provider/engine/configuração escolhido com corpus de envio/ACK, identidade histórica e prova de latência sob autorização própria.

