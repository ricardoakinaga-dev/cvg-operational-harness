"""Verify exact reconstruction inputs directly from repository archives, without cache/env."""
from pathlib import Path
import hashlib, json, subprocess, tarfile

root = Path('/home/ricardo/Área de trabalho/cvg-operational-harness')
evidence = root / 'docs/04_audit/evidence/HARNESS-ISO-EXEC-20261003/green-20261004'
out = Path('/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/lead')
manifest_bytes = (evidence / 'final-r19-frozen-source-manifest.json').read_bytes()
manifest = json.loads(manifest_bytes)
expected = {x['path']: x for x in manifest['nativeFiles']}
stream_hash = hashlib.sha256()
parts = []
for item in manifest['orderedParts']:
    p = evidence / item['path']
    assert p.parent == evidence and p.is_file() and not p.is_symlink()
    digest = hashlib.sha256()
    count = 0
    with p.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk); stream_hash.update(chunk); count += len(chunk)
    assert digest.hexdigest() == item['sha256'] and count == item['bytes'], p.name
    parts.append({'path': item['path'], 'sha256': digest.hexdigest(), 'bytes': count})
assert stream_hash.hexdigest() == manifest['archiveSha256']
proc = subprocess.Popen(['cat', *[str(evidence / x['path']) for x in parts]], stdout=subprocess.PIPE)
seen = {}
try:
    with tarfile.open(fileobj=proc.stdout, mode='r|gz') as archive:
        for member in archive:
            p = Path(member.name)
            assert member.isfile() and not p.is_absolute() and '..' not in p.parts
            assert member.name in expected and member.name not in seen, member.name
            assert not (p.name.startswith('.env') and p.name != '.env.example'), member.name
            handle = archive.extractfile(member)
            digest = hashlib.sha256()
            size = 0
            for chunk in iter(lambda: handle.read(1024 * 1024), b''):
                digest.update(chunk); size += len(chunk)
            item = expected[member.name]
            assert digest.hexdigest() == item['sha256'] and size == item['size'], member.name
            seen[member.name] = {'sha256': digest.hexdigest(), 'size': size, 'mode': member.mode}
    assert set(seen) == set(expected)
finally:
    proc.stdout.close()
    if proc.poll() is None: proc.terminate()
    exit_code = proc.wait()
assert exit_code == 0, exit_code
overlay_bytes = (evidence / 'final-r25-nine-path-security-delta.json').read_bytes()
overlay_meta = json.loads(overlay_bytes)
overlay_path = evidence / overlay_meta['archive']
assert hashlib.sha256(overlay_path.read_bytes()).hexdigest() == overlay_meta['archiveSha256']
overlay = {}
with tarfile.open(overlay_path, 'r:gz') as archive:
    for member in archive:
        if not member.name.startswith('source/'): continue
        assert member.isfile()
        rel = member.name[len('source/'):]
        assert not Path(rel).is_absolute() and '..' not in Path(rel).parts and rel not in overlay
        data = archive.extractfile(member).read()
        overlay[rel] = {'sha256': hashlib.sha256(data).hexdigest(), 'size': len(data)}
assert len(overlay) == 9
reconstructed = {k: {'sha256': v['sha256'], 'size': v['size']} for k, v in seen.items()}
reconstructed.update(overlay)
with tarfile.open(evidence / 'final-r25-integrated-source-delta.tar.gz', 'r:gz') as archive:
    current = json.load(archive.extractfile('pre-native-source-files.json'))
if isinstance(current, dict):
    print('PRE_NATIVE_MANIFEST_DICT_KEYS', list(current)[:8], flush=True)
    raise ValueError('Inspect manifest shape before comparing; do not guess')
assert isinstance(current, list)
current_map = {x['path']: {'sha256': x['sha256'], 'size': x['size']} for x in current}
assert reconstructed == current_map
record = {'task': 'PLAN_COMPLETION_RECONCILIATION_R35', 'criterion': 'A4', 'status': 'PASS_ARCHIVE_RECONSTRUCTION_BYTES', 'method': 'Hash every ordered part and stream-decompress each archived source member; apply exact nine archived overlay bytes in memory; compare all expected pre-native input records', 'manifestSha256': hashlib.sha256(manifest_bytes).hexdigest(), 'archiveSha256': stream_hash.hexdigest(), 'parts': parts, 'baseFiles': len(seen), 'overlayPaths': overlay, 'reconstructedFiles': len(reconstructed), 'dependencyInstallation': 'NOT_RUN in R35; exact lockfile archived', 'diskExtraction': 'NOT_RUN in R35; source members reconstructed and hashed in memory', 'privateEnvRead': False, 'cacheCandidateRead': False, 'productionAcceptance': False}
(out / 'a4-repository-reconstruction-proof.json').write_text(json.dumps(record, indent=2) + '\n')
print('RECONSTRUCTION_EXACT', len(seen), len(overlay), len(reconstructed), flush=True)
