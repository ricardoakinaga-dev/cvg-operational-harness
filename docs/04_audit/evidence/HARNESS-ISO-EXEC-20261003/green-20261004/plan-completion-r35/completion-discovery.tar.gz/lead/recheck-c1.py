from pathlib import Path
import hashlib, json, os, subprocess, zipfile, datetime

root = Path('/home/ricardo/Área de trabalho/cvg-operational-harness')
base = Path('/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35')
source = base.parent / 'candidate-final-r25'
node = '/home/ricardo/.nvm/versions/node/v22.23.2/bin/node'
out = base / 'lead/c1-recheck'
out.mkdir(exist_ok=False)
env = {k: os.environ[k] for k in ['HOME', 'LANG', 'LC_ALL', 'TERM'] if k in os.environ}
env['PATH'] = str(Path(node).parent) + ':/usr/bin:/bin'
env['TMPDIR'] = str(out / 'tmp')
Path(env['TMPDIR']).mkdir()
inputs = sorted(source.joinpath('scripts').glob('*boundary*.mjs')) + [Path(node), source / 'node_modules/typescript/lib/typescript.js']
def hashes():
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
before = hashes()
results = []
archives = []
for group, rel in [('historical', 't2-critic-r2-fixtures.zip'), ('posterior', 'audit-actions/c1-posterior-fixtures.zip')]:
    archive = root / 'docs/04_audit/evidence/HARNESS-ISO-EXEC-20261003' / rel
    archives.append({'path': str(archive.relative_to(root)), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()})
    destination = out / group
    destination.mkdir()
    with zipfile.ZipFile(archive) as z:
        for info in z.infolist():
            name = Path(info.filename)
            if name.is_absolute() or '..' in name.parts:
                raise ValueError('unsafe archive path')
            if not info.filename.startswith(('fixtures/', 'proof/fixtures/', 'proof/adversarial/')):
                continue
            if info.is_dir(): continue
            p = destination / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(z.read(info))
    dirs = ['fixtures'] if group == 'historical' else ['proof/fixtures', 'proof/adversarial']
    for prefix in dirs:
        for fixture in sorted((destination / prefix).iterdir()):
            if not fixture.is_dir(): continue
            if not fixture.name.startswith(('negative-', 'positive-')):
                continue
            expected_reject = fixture.name.startswith('negative-')
            command = [node, str(source / 'scripts/check-product-boundary.mjs'), str(fixture)]
            run = subprocess.run(command, cwd=source, env=env, text=True, capture_output=True, timeout=50)
            log_prefix = out / (group + '-' + fixture.name)
            log_prefix.with_suffix('.stdout.json').write_text(run.stdout)
            log_prefix.with_suffix('.stderr.txt').write_text(run.stderr)
            try: audit = json.loads(run.stdout)
            except json.JSONDecodeError: audit = None
            rejected = audit is not None and audit.get('status') in ('FAIL', 'INCOMPLETE') and not audit.get('passed') and run.returncode == 1
            admitted = audit is not None and audit.get('status') == 'PASS' and audit.get('passed') and run.returncode == 0
            met = rejected if expected_reject else admitted
            row = {'group': group, 'fixture': fixture.name, 'expected': 'REJECT' if expected_reject else 'PASS', 'status': audit.get('status') if audit else 'NO_JSON', 'exitCode': run.returncode, 'criterionMet': met, 'violations': len(audit.get('violations', [])) if audit else None, 'diagnostics': len(audit.get('diagnostics', [])) if audit else None, 'command': command, 'stdout': log_prefix.with_suffix('.stdout.json').name, 'stderr': log_prefix.with_suffix('.stderr.txt').name}
            results.append(row)
            print(group, fixture.name, row['status'], run.returncode, 'MATCH' if met else 'MISMATCH', flush=True)
after = hashes()
record = {'task': 'PLAN_COMPLETION_RECONCILIATION_R35', 'check': 'Exact archived fixtures against current public CLI; no fixture payload executed', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'node': subprocess.check_output([node, '--version'], env=env, text=True).strip(), 'archives': archives, 'inputsBefore': before, 'inputsAfter': after, 'inputSentinel': 'MATCH' if before == after else 'DRIFT', 'results': results, 'total': len(results), 'matched': sum(r['criterionMet'] for r in results), 'productionAcceptance': False}
(out / 'results.json').write_text(json.dumps(record, indent=2) + '\n')
assert before == after
raise SystemExit(0 if all(r['criterionMet'] for r in results) else 1)
