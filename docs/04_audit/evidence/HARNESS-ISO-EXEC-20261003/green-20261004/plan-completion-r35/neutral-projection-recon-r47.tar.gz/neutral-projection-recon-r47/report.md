# R47 — reconhecimento da projeção neutral R44

**Conclusão: delta de código runtime/core neutro = 0; delta CI = 3 arquivos. A recipe não exige correção adicional do teste nem projeção adicional dos JSONs.** O teste R44 e seus metadados devem permanecer byte-exatos. A igualdade de todos os inputs neutral históricos é falsa: há também 29 diferenças em build/cache/recibos. Nenhum PASS da suíte atual, aceite independente ou autorização de produção é concedido.

Task/claim: `R47_NEUTRAL_PROJECTION_RECON`, scout do Lead. Escrita exclusivamente neste diretório. Root/07/coord/99/20/30 foram lidos; o claim R47 já constava em coordenação. A instrução explícita desta rodada impede atualizar os ledgers globais; continuidade está em `result.json` e `neutral-execution-plan.json`, para reconciliação pelo Lead. Skill usada: `orchestrate`, modo scout sem descendentes.

## O que a recipe realmente faz

`candidate-final-r25/scripts/hiso-variant.mjs`, SHA-256 `3e4122e9b9d6bdd3548c6aef05438139c68b15dfe188496f4ab23d4b4d958d2d`, continua byte-exato na R44. `without-shift-v1` remove **somente** `products/shift-assistant/**` e transforma sete configurações: package, lock v3, workspace policy, doc-link policy, TS references, TS typecheck e Vitest. As oito entradas de transformação incluem uma entrada descritiva das vinte mappings documentais, além dos sete hashes de arquivos.

O lock conserva entradas de terceiros byte-equivalentes em conteúdo canônico, removendo apenas workspace/link do produto, sem resolver novas versões. Vitest conserva os pisos 90/85/90/90 e exclui os dois testes de topologia já classificados como `transition-regression`: `workspace-scripts` e `doc-source-moves`. A recipe não altera `tests/hiso-ci-scopes.test.js`, `scripts/hiso-baseline-inventory.json` ou `scripts/hiso-ci-scopes.json`.

`final-neutral-r25/prepare.mjs` apenas chama essa recipe sobre `neutral-staging-r25` e grava o comprovante. Não há transformação escondida do teste. Reexecutei o **corpo exato** de `prepareVariant` em VM com filesystem virtual, usando listas de inputs dos recibos e bytes reais dos sete configs. A reprodução histórica igualou **todo** `preparation.json`: listas, hashes, removed mappings, IDs e mapping hash. Nenhuma árvore de variante física foi criada.

## Identidades e deltas

| Objeto | Inputs | Identidade SHA-256 |
| --- | ---: | --- |
| Candidato nativo R44 | 2.222 | `3909fdcc7cb9f86b284682bccd7c3f46bf794d99206605a18836078eef48483c` |
| Source HISO R44 do recibo `native-before` | 8.493 | `e0203fe0acf0b5099879fcb4f6f26fd545d0b8b5c98a5af5d22c676839143c93` |
| Neutral histórico | 8.068 | `23dd9a4a33d94532eb03140e872316d90aec699d9746c45d956b1c8dede7d87f` |
| Neutral R44 calculado sobre esse recibo | 8.079 | `e311da1dcb38df26275bcad997c7144a01a5b3dd96cdee1474f9a0237825d1d1` |

São universos distintos: não confundir candidate ID nativo com digest `sourceFiles`. Rules hash: `bacdeb66cc4cf7c034f314297188da8694e37a9495ced6513870e54786cf8bfb`. Mapping hash calculado: `5285aa2a6f1270d809e1981121638602eb52fdc3b71a42838609c66af80c02bb`.

R44 remove 414 entradas físicas, contra 411 históricas: duas adições de fonte R38 e o bundle offline gerado também estão dentro do produto. Os nove deltas de fonte do recibo R38 desaparecem integralmente. As duas alterações de metadata R38 e o teste R44 sobrevivem:

| Caminho | SHA-256 R44 preservado no neutral | Efeito |
| --- | --- | --- |
| `scripts/hiso-baseline-inventory.json` | `f2d4ef6ef8c17fdf13002b01dd5ffba30fdcc89f51b8f988be6bc864b31d12b5` | Adiciona exatamente `live-offline-r38-own.test.ts`; preserva os 49 anteriores em ordem. |
| `scripts/hiso-ci-scopes.json` | `13f82e929333604dcef0b390f776e3049ac8f765b1da1d2fb17080dc8803fc17` | Apenas rebind do hash desse inventário. |
| `tests/hiso-ci-scopes.test.js` | `dff847023d7d36746f5c3fb6be8bdcbfae415634af233c6663f06abe77e83a51` | Count 49→50, presença exata do novo path e título corrigido. |

No universo completo da recipe existem **32 deltas neutral**: os três acima, dez arquivos de `apps/web/dist`, um cache `_metadata.json` e dezoito entradas de certification (17 alteradas, uma adicionada). Não foram apagadas, normalizadas nem dispensadas. Seus hashes/listas estão em `delta-neutral.json`; o ID completo foi calculado com essas entradas. O delta runtime/core zero se refere aos caminhos de código/configuração técnica retidos, não a equivalência de todo o filesystem ou dos artefatos de certificação.

## Por que count 50 e o path ausente funcionam

No teste R44, linhas 290–305, `baseline` vem do JSON combinado; `toContain` verifica uma **string nesse JSON**, sem abrir o arquivo do produto. O arquivo físico é removido, a referência permanece. Reduzir count para 49, filtrar `newTests` ou excluir esse teste quebraria a evidência e não é necessário.

`expectedCoveragePaths(root, 'retained')` verifica primeiro os sete fingerprints da projeção real e retorna intencionalmente o denominador combinado **281** para a fixture adversarial de cobertura zero. Preservar essa asserção. O denominador medido pela suíte neutral é **250** (31 fontes do produto removidas); `approvedCoverageInventory` reconhece a projeção pelos sete hashes e rules hash, e esses oito vínculos continuam iguais. Nenhum rebind adicional de producer/config é necessário.

Os **371 registros originais** e os arrays de cobertura (275 + 6 = **281**) foram comparados integralmente com o neutral histórico; todos os 371 hashes de testes originais foram relidos na R44. Há 19 testes originais do produto e oito adições do produto: o inventário combinado continua completo, enquanto a projeção física conserva 352 originais + 42 adições, antes de separar specs E2E e os dois testes de transição. Os donos originais continuam responsáveis por executar os testes removidos no produto/transition, sem dispensas.

`validateContract()` exige os 371 arquivos físicos e deve validar a Source combinada, **antes** da derivação. Chamá-lo sobre a árvore neutral falha pelo contrato combinado. O comando `hiso-ci.mjs inventory` mede o neutral sem essa validação combinada. Não corrigir esse uso indevido enfraquecendo o validator.

## Evidência executada e limites

Node **22.23.2**, comando `node --experimental-vm-modules projection-recon.mjs`, **exit 0**. Foram executados **33 controles estáticos/em memória**, incluindo reprodução histórica exata, igualdade dos sete configs, delta semântico exato, 371/281 intactos, 49 adições preservadas, somente rebind autorizado e expectativas escalares reais extraídas do teste R44. Negativos count49, count51 e substituição do path mantendo count50 foram rejeitados. Essa execução isolada não importa Vitest nem executa o restante da suíte.

**1.772 verificações de hashes técnicos por caminho exato**, entre R44 e neutral histórico, coincidiram com os respectivos recibos. Não se executou `sourceFiles` real nem se percorreu node_modules, Git ou governança para construir a projeção. O adapter virtual usa os inventories congelados; sua validade foi conferida reproduzindo o comprovante histórico completo. Uma variante física futura deve conferir a lista real pós-projeção e falhar se diferir.

O comprovante antigo contém 5.100 PASS / 385 arquivos e 199 casos CI; isso foi identificado somente como histórico. **Nenhum desses resultados qualifica a R44.** A identidade de casos inclui título/ocorrência: a mudança do título exige inventário e vínculos de execução atuais.

A Source foi tratada como `certify RUNNING`, conforme o mandato, sem polling, interrupção ou nova execução. Os hashes dos logs/outputs ativos não foram relidos como prova atual. O digest neutral acima é exato **para o recibo congelado**, não um freeze terminal do filesystem vivo. Os hashes técnicos observados coincidiram, mas uma leitura por lista também não prova ausência de novo input não listado. O Lead precisa encerrar a execução atual, reconciliar o inventário real completo e revisar qualquer novo binding. Não há aprovação automática.

## Próxima execução e revisão

`neutral-execution-plan.json` contém o plano congelado, commands/argv, hashes obrigatórios e requisitos de revisão. Ele não foi executado. A sequência é: esperar recibo terminal do Lead; comparar Source real e contrato com os hashes congelados; rejeitar drift sem produzir variante; obter claim exclusivo para qualificação; derivar com a recipe sem patches; verificar ausência física do produto e os sete hashes; preparar dependências/Git privados sob o novo claim; executar CI focado, build/type/lint e suíte neutral completa com cobertura/PostgreSQL sintético próprios. Contagens e PASS devem vir dos JSONs e logs dessa execução, com run/candidate/variant vinculados.

O crítico novo deve recomputar projection/mapping IDs, revisar o adapter/recibos, conferir os três deltas exatos, preservar negativas de coverage/skip e a barra 371/281, e inspecionar evidência recém-gerada. Gates de E2E, SBOM/licenças e demais gates HISO continuam obrigações próprias do Lead; a recon não os concede nem os remove. Se os raws de certificação mudarem, revisar/reemitir os bindings antes de executar: não reutilizar silenciosamente `e311…`.

Arquivos de navegação: `result.json`, `projection-frozen.json`, `inputs-manifest.json`, `technical-hash-checks.json`, `static-controls.json`, `delta-inputs.json`, `delta-neutral.json`, `commands-exit.json`. Uma busca inicial `rg --files` retornou caminhos demais; foi encerrada e substituída por leituras exatas. Nenhuma alteração de fonte, dependências, env, Git ou ledgers globais; nenhum spawn de subagente, provider, instalação, variante física, fullPG/E2E/certify nesta rodada.
