import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { createHash } from 'node:crypto'

// Scout only: no Source walks, child processes, imports of product/vendor code,
// dependencies or real variant writes. The original recipe runs against a
// virtual filesystem fed by exact inventory receipts. Only this directory writes.
const B = '/home/ricardo/.cache/cvg-harness-green-20261004'
const OUT = path.dirname(fileURLToPath(import.meta.url))
const SRC = path.join(B, 'plan-completion-r35/candidate-inventory-r44')
const OLD = path.join(B, 'hiso-neutral-final-r25')
const RECIPE = path.join(B, 'candidate-final-r25/scripts/hiso-variant.mjs')
const CONTRACT = path.join(B, 'candidate-final-r25/scripts/hiso-contract.mjs')
const sha = b => createHash('sha256').update(b).digest('hex')
const reads = new Map()
const read = p => {
  const b = fs.readFileSync(p)
  reads.set(p, {path:p, sha256:sha(b), size:b.length})
  return b
}
const json = p => JSON.parse(read(p))
const write = (p, value) => {
  const dest = path.resolve(OUT, p)
  if (!dest.startsWith(OUT + path.sep)) throw Error('output boundary')
  fs.writeFileSync(dest, JSON.stringify(value, null, 2) + '\n')
}
const check = (yes, reason) => {if (!yes) throw Error(reason)}
const lib = await import(pathToFileURL(CONTRACT))
const { canonical, digest, safePath, requireThat, scopeContract } = lib
read(CONTRACT)
read(path.join(B, 'candidate-final-r25/scripts/hiso-ci-scopes.json'))
read(path.join(B, 'candidate-final-r25/scripts/ci-bar-contract.mjs'))
const recipeBytes = read(RECIPE)
const raw = json(path.join(B,'plan-completion-r35/certify-inventory-r44/native-before.json'))
const oldRaw = json(path.join(B,'final-neutral-r25/staging-source-files.json'))
const oldProof = json(path.join(B,'final-neutral-r25/preparation.json'))
const nativeCandidate = json(path.join(B,'plan-completion-r35/certify-inventory-r44/candidate-before.json'))
const frozen = json(path.join(B,'plan-completion-r35/lead/r44-integration/frozen.json'))
const r38Receipt = json(path.join(B,'plan-completion-r35/lead/r38-integration/receipt.json'))
const r44Receipt = json(path.join(B,'plan-completion-r35/lead/r44-integration/receipt.json'))
const controls = []
const PASS = (id, condition) => {check(condition,id); controls.push({id,status:'PASS'})}
const toMap = rows => new Map(rows.map(f => [f.path, f]))
const rawMap = toMap(raw)
for(const rows of [raw,oldRaw,oldProof.files,nativeCandidate.files]) {
  PASS('safe-and-unique-inventory-' + rows.length, new Set(rows.map(x=>x.path)).size===rows.length)
  rows.forEach(x=>safePath(x.path))
}

async function virtualProjection(inputs, configSource, label) {
  const from = '/r47-virtual/' + label + '/source'
  const to = '/r47-virtual/' + label + '/neutral'
  const source = toMap(inputs)
  const target = new Map()
  const contents = new Map()
  const dirs = new Set([from])
  const locate = p => {
    p=path.resolve(p)
    if(p.startsWith(from+'/')) return [source,p.slice(from.length+1),false]
    if(p.startsWith(to+'/')) return [target,p.slice(to.length+1),true]
    throw Error('virtual path outside roots: '+p)
  }
  const bytes = p => {
    const [map,rel,isTarget]=locate(p)
    const entry=map.get(rel); check(entry,'virtual missing '+rel)
    if(contents.has(p)) return contents.get(p)
    const b=read(path.join(configSource,rel))
    check(sha(b)===entry.sha256 && b.length===entry.size,'receipt/config drift '+rel)
    if(isTarget) contents.set(p,b)
    return b
  }
  const vfs = {
    existsSync:p=>dirs.has(path.resolve(p)),
    mkdirSync:p=>dirs.add(path.resolve(p)),
    readFileSync:(p,encoding)=>{const b=bytes(p);return encoding?b.toString(encoding):b},
    writeFileSync:(p,b)=>{b=Buffer.isBuffer(b)?b:Buffer.from(b);const [map,rel,isTarget]=locate(p);check(isTarget,'virtual source mutation');map.set(rel,{path:rel,sha256:sha(b),size:b.length});contents.set(p,b)},
    copyFileSync:(a,b)=>{const [sm,rel]=locate(a);const [tm,dest,isTarget]=locate(b);check(isTarget && sm.has(rel),'virtual copy');tm.set(dest,{...sm.get(rel),path:dest})}
  }
  const sourceFiles = root => {
    check(root===from || root===to,'virtual sourceFiles root')
    return [...(root===from?source:target).values()].sort((a,b)=>a.path.localeCompare(b.path))
  }
  // Exact original module bytes; substitute only its three imports.
  const context=vm.createContext({Buffer,structuredClone})
  const module=new vm.SourceTextModule(recipeBytes.toString(),{context,identifier:pathToFileURL(RECIPE).href})
  const synth = exports => new vm.SyntheticModule(Object.keys(exports),function(){for(const [k,v]of Object.entries(exports))this.setExport(k,v)},{context})
  await module.link(spec=>{
    if(spec==='node:fs') return synth({default:vfs})
    if(spec==='node:path') return synth({default:path})
    if(spec==='./hiso-contract.mjs') return synth({canonical,digest,requireThat,safePath,scopeContract,sha,sourceFiles})
    throw Error('unapproved import '+spec)
  })
  await module.evaluate()
  const proof=module.namespace.prepareVariant(from,to,'harness-neutral')
  return {proof,rules:JSON.parse(JSON.stringify(module.namespace.rules)),target,contents}
}

const historic = await virtualProjection(oldRaw,path.join(B,'candidate-final-r25'),'historical')
PASS('historical-exact-recipe-reproduction',canonical(historic.proof)===canonical(oldProof))
const current = await virtualProjection(raw,SRC,'r44-frozen')
const projected = current.proof
PASS('same-rules-hash',projected.rulesHash===oldProof.rulesHash)
PASS('source-receipt-bound',projected.originalCandidateId===digest(raw))
PASS('no-retained-product',projected.files.every(f=>!f.path.startsWith('products/')))
const cfgs=projected.transforms.filter(x=>x.path)
PASS('seven-transformed-configs',cfgs.length===7)
PASS('seven-config-fingerprints-exact-historical',cfgs.every(t=>oldProof.transforms.some(x=>x.path===t.path&&x.after===t.after)))
PASS('recipe-byte-unchanged-in-R44',sha(read(path.join(SRC,'scripts/hiso-variant.mjs')))===sha(recipeBytes))
PASS('contract-code-byte-unchanged-in-R44',sha(read(path.join(SRC,'scripts/hiso-contract.mjs')))===sha(read(CONTRACT)))

const classify = p => {
  if(p.startsWith('products/')) return 'removed-product'
  if(p.startsWith('certification/')) return 'retained-certification-generated-or-receipt'
  if(p.includes('/dist/') || p.includes('/node_modules/')) return 'retained-build-or-cache-output'
  if(['scripts/hiso-baseline-inventory.json','scripts/hiso-ci-scopes.json','tests/hiso-ci-scopes.test.js'].includes(p)) return 'ci-test-and-inventory'
  if(/^(apps|packages|legacy|examples)\//.test(p)) return 'neutral-runtime-or-core'
  return 'other-retained-input'
}
function differences(before,after) {
  const bm=toMap(before),am=toMap(after)
  return [...new Set([...bm.keys(),...am.keys()])].sort().filter(p=>canonical(bm.get(p))!==canonical(am.get(p))).map(p=>({path:p,kind:bm.has(p)?am.has(p)?'CHANGED':'REMOVED':'ADDED',category:classify(p),before:bm.get(p)??null,after:am.get(p)??null}))
}
const inputDelta=differences(oldRaw,raw)
const neutralDelta=differences(oldProof.files,projected.files)
const semanticDelta=neutralDelta.filter(x=>!['retained-certification-generated-or-receipt','retained-build-or-cache-output'].includes(x.category))
PASS('neutral-semantic-delta-exact-three-CI-files',semanticDelta.length===3&&semanticDelta.every(x=>x.category==='ci-test-and-inventory'))
PASS('neutral-runtime-core-source-delta-zero',neutralDelta.every(x=>x.category!=='neutral-runtime-or-core'))
PASS('nine-product-source-deltas-dropped',r38Receipt.sourceDeltas.length===9&&r38Receipt.sourceDeltas.every(x=>!toMap(projected.files).has(x.path)))
PASS('native-candidate-id-cross-receipt',frozen.candidateId===nativeCandidate.candidateId&&frozen.nativeInputs===raw.length)

// Rehash only exact technical files from receipts: do not enumerate .git,
// node_modules, caches, governance or Source trees. Mutable certification raws
// remain explicit frozen-receipt data, never silently fresh current evidence.
const technical = p => !p.includes('/dist/')&&!p.includes('/node_modules/')&&(/^(apps|packages|legacy|examples|scripts|tests|config|\.github)\//.test(p)||['package.json','package-lock.json','vitest.config.mts','tsconfig.json','tsconfig.typecheck.json','tsconfig.base.json','tsconfig.runtime.json','Dockerfile','eslint.config.js','vite.config.mts','docs/doc-link-policy.json'].includes(p))
const technicalChecks=[]
for(const f of raw.filter(x=>technical(x.path))) {
  const b=read(path.join(SRC,f.path))
  technicalChecks.push({root:'R44',path:f.path,receiptSha256:f.sha256,observedSha256:sha(b),size:b.length,status:sha(b)===f.sha256&&b.length===f.size?'MATCH':'DRIFT'})
}
for(const f of oldProof.files.filter(x=>technical(x.path))) {
  const b=read(path.join(OLD,f.path))
  technicalChecks.push({root:'historical-neutral',path:f.path,receiptSha256:f.sha256,observedSha256:sha(b),size:b.length,status:sha(b)===f.sha256&&b.length===f.size?'MATCH':'DRIFT'})
}
PASS('exact-listed-current-technical-bytes-match-receipts',technicalChecks.every(x=>x.status==='MATCH'))
const baselineRel='scripts/hiso-baseline-inventory.json'
const baseline=json(path.join(SRC,baselineRel))
const oldBaseline=json(path.join(OLD,baselineRel))
const ci=json(path.join(SRC,'scripts/hiso-ci-scopes.json'))
const oldCi=json(path.join(OLD,'scripts/hiso-ci-scopes.json'))
const newPath='products/shift-assistant/src/__tests__/live-offline-r38-own.test.ts'
const testBytes=read(path.join(SRC,'tests/hiso-ci-scopes.test.js'))
const oldTest=read(path.join(OLD,'tests/hiso-ci-scopes.test.js')).toString()
const exactExpected=oldTest.replace('expect(baseline.newTests).toHaveLength(49)',"expect(baseline.newTests).toHaveLength(50)\n    expect(baseline.newTests).toContain(\n      'products/shift-assistant/src/__tests__/live-offline-r38-own.test.ts'\n    )").replace('original and thirty-eight explicitly added test paths','original and fifty explicitly added test paths')
PASS('test-only-R44-authorized-delta',testBytes.toString()===exactExpected)
PASS('371-original-records-unchanged',baseline.tests.length===371&&canonical(baseline.tests)===canonical(oldBaseline.tests))
PASS('all-371-original-source-hashes-current',baseline.tests.every(x=>sha(read(path.join(SRC,x.path)))===x.sha256))
PASS('281-coverage-paths-unchanged',baseline.coveragePaths.length+baseline.newCoveragePaths.length===281&&canonical(baseline.coveragePaths)===canonical(oldBaseline.coveragePaths)&&canonical(baseline.newCoveragePaths)===canonical(oldBaseline.newCoveragePaths))
PASS('previous-49-additions-preserved-in-order',oldBaseline.newTests.length===49&&canonical(baseline.newTests.filter(x=>x!==newPath))===canonical(oldBaseline.newTests))
PASS('exact-fiftieth-addition-once',baseline.newTests.length===50&&baseline.newTests.filter(x=>x===newPath).length===1)
PASS('baseline-inventory-hash-rebound',sha(read(path.join(SRC,baselineRel)))===ci.baselineInventory.sha256)
const ciExpected=structuredClone(oldCi);ciExpected.baselineInventory.sha256=ci.baselineInventory.sha256
PASS('contract-only-baseline-hash-delta',canonical(ci)===canonical(ciExpected))
PASS('baseline-only-added-new-path',canonical({...baseline,newTests:oldBaseline.newTests})===canonical(oldBaseline))
const freezeFixture=json(path.join(SRC,'tests/fixtures/hiso-r6-projection.json'))
PASS('fixture-seven-config-binding-preserved',freezeFixture.rulesHash===projected.rulesHash&&cfgs.every(t=>freezeFixture.neutral[t.path].sha256===t.after))
const coverageAll=[...baseline.coveragePaths,...baseline.newCoveragePaths]
const coverageNeutral=coverageAll.filter(p=>!p.startsWith('products/shift-assistant/'))
PASS('neutral-exact-250-coverage-denominator',coverageNeutral.length===250)

// Execute just the real scalar/member expectations in a tiny in-memory harness.
// No Vitest/fixture imports or child processes. This is not the 199-case CI suite.
const scalar=testBytes.toString().match(/expect\(paths\)\.toHaveLength\(281\)[\s\S]*?(?=    expect\(\(\) =>\n      aggregateCoverage)/)[0]
const scalarExpect = value => ({toHaveLength:n=>check(value.length===n,'length '+value.length+' != '+n),toContain:p=>check(value.includes(p),'missing exact path')})
const executeScalar = b => vm.runInNewContext(scalar,{baseline:b,paths:coverageAll,expect:scalarExpect})
executeScalar(baseline)
PASS('real-R44-scalar-expectations-on-neutral-metadata',true)
for(const [id,mutator] of [
  ['reject-count49',b=>b.newTests.pop()],
  ['reject-count51',b=>b.newTests.push('tests/unapproved-r47.test.js')],
  ['reject-missing-exact-path-count50',b=>{b.newTests[b.newTests.indexOf(newPath)]='tests/replacement-r47.test.js'}]
]) {
  const changed=structuredClone(baseline);mutator(changed);let rejected=false;try{executeScalar(changed)}catch{rejected=true}PASS(id,rejected)
}
PASS('physical-product-path-absent-but-inventory-reference-preserved',!toMap(projected.files).has(newPath)&&baseline.newTests.includes(newPath))
const oldFull=json(path.join(B,'final-neutral-r25/final-neutral-r25-full.json'))
const oldVitest=json(path.join(B,'final-neutral-r25/full-vitest.json'))
const oldTestResult=oldVitest.testResults.find(x=>x.name.endsWith('/tests/hiso-ci-scopes.test.js'))
read(path.join(B,'final-neutral-r25/prepare.mjs'))
read(path.join(B,'final-neutral-r25/git-preparation.json'))
const root='/home/ricardo/Área de trabalho/cvg-operational-harness'
for(const p of ['AGENTS.md','docs/07_agents/AGENTS.md','docs/08_runtime/agent_coordination.md','docs/99_runtime_state.md','docs/20_master_execution_log.md','docs/30_backlog_master.md']) read(path.join(root,p))
const summarize=rows=>rows.reduce((acc,x)=>(acc[x.category]=(acc[x.category]??0)+1,acc),{})
const summary={schemaVersion:1,task:'R47_NEUTRAL_PROJECTION_RECON',status:'SCOUT_RECON_COMPLETE_REVIEW_REQUIRED',observedAt:new Date().toISOString(),runtime:process.version,source:SRC,sourceLifecycle:'certify RUNNING as assigned; not polled/modified/interrupted',projectionScope:'Frozen native-before receipt; technical input hashes freshly checked. Generated/raw receipt members not rehashed live.',recipe:{path:RECIPE,sha256:sha(recipeBytes),rulesHash:projected.rulesHash,transformVersion:projected.transformVersion,execution:'Exact original prepareVariant body under virtual fs/sourceFiles; original sourceFiles walk NOT executed',historicalReproduction:'exact complete proof equality'},identities:{nativeCandidateId:frozen.candidateId,nativeCandidateFiles:nativeCandidate.files.length,hisoFrozenSourceId:projected.originalCandidateId,hisoFrozenSourceFiles:raw.length,historicalSourceId:oldProof.originalCandidateId,historicalNeutralId:oldProof.derivedVariantId,frozenProjectedNeutralId:projected.derivedVariantId,frozenProjectedNeutralFiles:projected.files.length,removed:projected.removed.length,derivedMappingHash:projected.derivedMappingHash},deltas:{input:summarize(inputDelta),neutral:summarize(neutralDelta),neutralTotal:neutralDelta.length,neutralSemantic:semanticDelta,neutralRuntimeCore:0,neutralCI:3},inventory:{originalRecords:371,coverageBase:baseline.coveragePaths.length,coverageAdded:baseline.newCoveragePaths.length,coverageFull:281,coverageNeutral:250,previousAdditions:49,currentAdditions:50,newPath,neutralOriginalRecords:baseline.tests.filter(x=>!x.path.startsWith('products/')).length,neutralAddedPaths:baseline.newTests.filter(x=>!x.startsWith('products/')).length,excludedTransitionTests:current.rules.transitionOnly},CIConclusion:{additionalTestProjectionRequired:false,additionalInventoryProjectionRequired:false,keepCombinedBaselineMetadata:true,keepOriginal371RecordsAnd281Denominator:true,physicalProductFilesRemoved:true,testCount50AndExactPathAssertionKept:true,contractValidation:'validateContract on combined input before derivation; never on neutral physical tree expecting all371 product members'},staticControls:{count:controls.length,results:controls},historicalEvidenceOnly:{suiteTests:oldVitest.numPassedTests,files:oldVitest.testResults.length,ciCases:oldTestResult.assertionResults.length,receiptExit:oldFull.exitCode,currentQualification:'NOT_RUN',inheritedPass:false},limits:['No current Vitest suite/build/PG/E2E/certify or variant was executed.','Frozen native list contains generated web/cache and certification data; full-byte neutral delta is not zero.','Virtual sourceFiles adapter preserves listed retained records and hashes; historic complete proof reproduced. A future real variant must recompute sourceFiles and reject any mismatch.','Technical exact-path rehash proves listed files, not absence of new unlisted inputs; final source freeze must enumerate using producer under dedicated Lead claim.','Live certification logs may change; projected ID refers to frozen receipt only and requires terminal Source reconciliation.','No independent reviewer acceptance, waiver, release, closure or production authority.'],writes:'R47 output only',providerCalls:0,networkCalls:0,childProcesses:0}
write('projection-frozen.json',projected)
write('delta-inputs.json',inputDelta)
write('delta-neutral.json',neutralDelta)
write('technical-hash-checks.json',technicalChecks)
write('static-controls.json',{scalarCode:scalar,controls})
write('result.json',summary)
write('inputs-manifest.json',{schemaVersion:1,task:summary.task,readFiles:reads.size,inputs:[...reads.values()].sort((a,b)=>a.path.localeCompare(b.path)),frozenNativeInputInventory:{path:path.join(B,'plan-completion-r35/certify-inventory-r44/native-before.json'),sha256:reads.get(path.join(B,'plan-completion-r35/certify-inventory-r44/native-before.json')).sha256},sourceFullRehash:false,sourceWalk:false})
console.log(JSON.stringify({status:summary.status,identities:summary.identities,deltas:summary.deltas,staticControls:controls.length,technicalChecks:technicalChecks.length,readFiles:reads.size},null,2))
