import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'
import assert from 'node:assert/strict'
const own = path.dirname(fileURLToPath(import.meta.url))
const phase = process.argv[2]
assert.ok(['before', 'after'].includes(phase))
const raw = '/home/ricardo/.cache/cvg-harness-green-20261004/plan-completion-r35/current-delta-security-review-r49/output/i1/confirmed-legacy-media.json'
const record = JSON.parse(fs.readFileSync(raw))
const out = path.join(own, 'output', 'exact-r49-' + phase)
fs.mkdirSync(out, { recursive: true })
function tree(root, rel = '') {
  const all = []
  for (const name of fs.readdirSync(path.join(root, rel)).sort()) {
    const p = rel ? rel + '/' + name : name, stat = fs.lstatSync(path.join(root, p))
    assert.equal(stat.isSymbolicLink(), false)
    if (stat.isDirectory()) all.push(...tree(root, p))
    else {
      assert.equal(stat.isFile(), true)
      all.push({ path: p, bytes: stat.size, mode: stat.mode & 0o777, sha256: createHash('sha256').update(fs.readFileSync(path.join(root,p))).digest('hex') })
    }
  }
  return all
}
const rawBefore = tree(record.source)
fs.cpSync(record.source, path.join(out, 'source'), { recursive: true })
const source = path.join(out, 'source'), product = path.join(own, phase === 'before' ? 'baseline' : 'candidate', 'products/shift-assistant')
const { ShiftStore } = await import(pathToFileURL(path.join(product, 'dist/offline-validator.mjs')))
const copied = tree(source)
assert.deepEqual(copied, rawBefore)
let offlineRejected = false, identity
try { identity = ShiftStore.validateStoppedVolume(source) } catch { offlineRejected = true }
assert.deepEqual(tree(source), copied)
const s = new ShiftStore(source)
const runtime = { available: s.storageAvailable, hold: s.operationalHold, effects: s.effectsAllowed, diagnostic: s.diagnostic ?? null }
s.close()
assert.deepEqual(tree(source), copied)
const commands = []
for (const mode of ['backup', 'restore']) {
  const command = [process.execPath, path.join(product, 'scripts/backup-restore.mjs'), mode,
    mode === 'backup' ? source : path.join(out, 'backup'),
    path.join(out, mode === 'backup' ? 'backup' : 'target')]
  // For after-restore, use the canonical invalid R49 backup produced by the
  // original actual CLI; its outer receipt is valid and primary remains absent.
  if (phase === 'after' && mode === 'restore') {
    fs.cpSync(path.join(own, 'output/exact-r49-before/backup'), path.join(out, 'backup'), { recursive: true })
  }
  const r = spawnSync(command[0], command.slice(1), { encoding: 'utf8', cwd: own })
  fs.writeFileSync(path.join(out, mode + '.stdout.txt'), r.stdout ?? '')
  fs.writeFileSync(path.join(out, mode + '.stderr.txt'), r.stderr ?? '')
  commands.push({ command, exit: r.status, stdout: r.stdout, stderr: r.stderr })
}
assert.deepEqual(tree(record.source), rawBefore)
assert.deepEqual(tree(source), copied)
assert.equal(fs.existsSync(path.join(source, record.descriptor.path)), false)
const recovery = copied.find(x => x.path.endsWith('/' + record.descriptor.path))
assert.equal(recovery.sha256, record.descriptor.sha256)
const result = { phase, raw, rawSha256: createHash('sha256').update(fs.readFileSync(raw)).digest('hex'), sourceSnapshot: rawBefore, exactReadonly: true, offlineRejected, identity, runtime, commands, primaryMissing: true, recoveryCopyIntact: true,
  pass: offlineRejected && !runtime.available && runtime.hold && !runtime.effects && commands.every(c => c.exit === 1) }
fs.writeFileSync(path.join(out, 'result.json'), JSON.stringify(result, null, 2) + '\n')
console.log(JSON.stringify({ phase, pass: result.pass, offlineRejected, runtime, exits: commands.map(c => c.exit), exactReadonly: true }))
if (!result.pass) process.exitCode = 1
