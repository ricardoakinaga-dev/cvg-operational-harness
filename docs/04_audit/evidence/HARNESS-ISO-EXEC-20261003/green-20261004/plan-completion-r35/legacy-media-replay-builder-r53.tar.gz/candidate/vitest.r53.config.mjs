import { defineConfig } from 'vitest/config'
import { fileURLToPath } from 'node:url'
const local = (name) => fileURLToPath(new URL(name, import.meta.url))
export default defineConfig({
  cacheDir: local('../tool-cache/vitest'),
  resolve: {
    alias: {
      '@cvg/shared': local('./packages/shared/src/index.ts'),
      '@cvg/model-gateway': local('./packages/model-gateway/src/index.ts')
    }
  },
  test: {
    include: ['products/shift-assistant/src/__tests__/**/*.test.ts'],
    fileParallelism: false,
    maxWorkers: 1,
    testTimeout: 30000
  }
})
