// @vitest-environment node
import * as fs from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { ShiftStore } from "../store.ts";
import { Journal, sha256 } from "../journal.ts";
import { replayLegacy } from "../migrate-journal.ts";
import type { ShiftEvent } from "../domain.ts";

const AT = "2026-10-05T12:00:00.000Z";
const PHONE = "5511900000001";
const BYTES = Buffer.from("R53_SYNTHETIC_AUDIO_IMAGE_BYTES");
const kinds = ["local", "note", "inline"] as const;
type Kind = (typeof kinds)[number];
function seed(kind: Kind) {
  const root = fs.mkdtempSync(join(tmpdir(), "r53-legacy-"));
  const source = join(root, "source");
  fs.mkdirSync(join(source, "media"), { recursive: true });
  const message = {
    provider: "waha" as const,
    messageId: "m1",
    fromPhone: PHONE,
    kind: kind === "local" ? ("image" as const) : ("audio" as const),
    text: "R53 synthetic original",
    receivedAt: AT,
  };
  let local = "";
  if (kind === "local") {
    const donor = new ShiftStore(join(root, "donor"));
    const descriptor = donor.saveMediaDescriptor(
      BYTES,
      "image/png",
      "R53-local",
    );
    donor.close();
    local = descriptor.path;
    for (const suffix of ["", ".json"])
      fs.copyFileSync(
        join(root, "donor", local + suffix),
        join(source, local + suffix),
      );
  }
  if (kind === "note")
    fs.writeFileSync(join(source, "media/original.ogg"), BYTES);
  const events: ShiftEvent[] = [
    {
      type: "message_received",
      at: AT,
      message: {
        ...message,
        ...(kind === "local" ? { mediaRef: local, mimetype: "image/png" } : {}),
        ...(kind === "inline"
          ? {
              mediaRef: "base64:" + BYTES.toString("base64"),
              mimetype: "audio/ogg",
            }
          : {}),
      },
    },
    {
      type: "note_created",
      at: AT,
      note: {
        id: "n1",
        messageId: "m1",
        authorPhone: PHONE,
        createdAt: AT,
        kind: message.kind,
        rawText: message.text,
        unverifiedNumbers: [],
        confirmed: true,
        ...(kind === "note" ? { mediaFile: "original.ogg" } : {}),
      },
    },
    // Historical processed IDs need not be known: retain existing base replay semantics.
    { type: "message_processed", at: AT, messageId: "historic-unknown" },
    { type: "message_processed", at: AT, messageId: "m1" },
  ];
  fs.writeFileSync(
    join(source, "events.jsonl"),
    events.map((e) => JSON.stringify(e) + "\n").join(""),
  );
  return { root, source, local, events };
}
function migrated(kind: Kind) {
  const f = seed(kind);
  const store = new ShiftStore(f.source, { legacySession: "R53-synthetic" });
  expect(store.storageAvailable, store.diagnostic).toBe(true);
  const path =
    kind === "local" ? f.local : store.migration!.mediaMappings[0]!.path;
  const migration = store.migration!;
  store.close();
  return { ...f, path, migration };
}
function contents(root: string, relative = ""): Record<string, string> {
  const result: Record<string, string> = {};
  for (const name of fs.readdirSync(join(root, relative)).sort()) {
    const rel = relative ? relative + "/" + name : name;
    if (rel === "store.lock") continue;
    const file = join(root, rel),
      stat = fs.lstatSync(file);
    if (stat.isDirectory()) Object.assign(result, contents(root, rel));
    else
      result[rel] = stat.isSymbolicLink()
        ? "link:" + fs.readlinkSync(file)
        : sha256(fs.readFileSync(file));
  }
  return result;
}
const modes = [
  "absent",
  "same-size-bytes",
  "sidecar-missing",
  "sidecar-path",
  "sidecar-size",
  "sidecar-hash",
  "symlink",
  "hardlink",
] as const;
function corrupt(source: string, path: string, mode: (typeof modes)[number]) {
  const file = join(source, path);
  if (mode === "absent") fs.unlinkSync(file);
  else if (mode === "same-size-bytes")
    fs.writeFileSync(file, Buffer.alloc(BYTES.length, 88));
  else if (mode === "sidecar-missing") fs.unlinkSync(file + ".json");
  else if (mode === "symlink" || mode === "hardlink") {
    const retained = join(source, "retained-media");
    fs.renameSync(file, retained);
    if (mode === "symlink") fs.symlinkSync(retained, file);
    else fs.linkSync(retained, file);
  } else {
    const descriptor = JSON.parse(fs.readFileSync(file + ".json", "utf8"));
    if (mode === "sidecar-path") descriptor.path = "media/wrong.ogg";
    if (mode === "sidecar-size") descriptor.bytes += 1;
    if (mode === "sidecar-hash") descriptor.sha256 = "f".repeat(64);
    fs.writeFileSync(file + ".json", JSON.stringify(descriptor));
  }
}
describe("R53 legacy primary media integrity", () => {
  it.each(kinds)(
    "preserves genuine migrated %s bytes, identity, hold and historical processed semantics",
    (kind) => {
      const f = migrated(kind);
      const before = contents(f.source);
      const identity = ShiftStore.validateStoppedVolume(f.source);
      for (let i = 0; i < 2; i++) {
        const s = new ShiftStore(f.source);
        try {
          expect(s.storageAvailable, s.diagnostic).toBe(true);
          expect(s.operationalHold).toBe(true);
          expect(s.effectsAllowed).toBe(false);
          expect(Buffer.from(s.readMedia(f.path).bytes)).toEqual(BYTES);
          expect(s.note("n1")?.confirmed).toBe(true);
          if (kind === "note")
            expect(s.note("n1")?.mediaFile).toBe(f.path.slice(6));
          expect(s.migration).toEqual(f.migration);
        } finally {
          s.close();
        }
        expect(ShiftStore.validateStoppedVolume(f.source)).toEqual(identity);
        expect(contents(f.source)).toEqual(before);
      }
      if (kind === "local")
        expect(
          fs.readFileSync(join(f.source, f.migration.backupPath, f.path)),
        ).toEqual(BYTES);
      if (kind === "note")
        expect(fs.readFileSync(join(f.source, "media/original.ogg"))).toEqual(
          BYTES,
        );
    },
  );
  for (const kind of kinds)
    it.each(modes)(
      "rejects " +
        kind +
        " %s without altering documents or adopting recovery media",
      (mode) => {
        const f = migrated(kind);
        corrupt(f.source, f.path, mode);
        const before = contents(f.source);
        expect(() => ShiftStore.validateStoppedVolume(f.source)).toThrow();
        expect(contents(f.source)).toEqual(before);
        const s = new ShiftStore(f.source);
        try {
          expect(s.storageAvailable).toBe(false);
          // Alias refusal precedes loading any migration metadata in the existing
          // constructor. Storage/effects must close even without that projection.
          if (mode !== "symlink" && mode !== "hardlink")
            expect(s.operationalHold).toBe(true);
          expect(s.effectsAllowed).toBe(false);
        } finally {
          s.close();
        }
        expect(contents(f.source)).toEqual(before);
        if (mode === "absent")
          expect(fs.existsSync(join(f.source, f.path))).toBe(false);
      },
    );
  it("direct legacy replay refuses absent local primary before applying the message", () => {
    const f = migrated("local");
    fs.unlinkSync(join(f.source, f.path));
    const journal = new Journal(f.source, {}, true);
    const applied: ShiftEvent[] = [];
    try {
      expect(() =>
        replayLegacy(journal, (event) => applied.push(event)),
      ).toThrow();
      expect(applied).toEqual([]);
    } finally {
      journal.close();
    }
  });
  it.each(kinds)(
    "validates final %s media during first migration before appending its receipt",
    (kind) => {
      const f = seed(kind);
      const s = new ShiftStore(f.source, {
        legacySession: "R53-synthetic",
        io: {
          checkpoint(point) {
            if (point === "after_manifest_rename") {
              const target =
                kind === "local"
                  ? f.local
                  : fs
                      .readdirSync(join(f.source, "media"))
                      .find((name) => name.endsWith(".json"))!
                      .slice(0, -5);
              fs.unlinkSync(
                join(f.source, kind === "local" ? target : "media/" + target),
              );
            }
          },
        },
      });
      try {
        expect(s.storageAvailable).toBe(false);
        const manifest = JSON.parse(
          fs.readFileSync(join(f.source, "journal/manifest.json"), "utf8"),
        );
        expect(
          fs.readFileSync(join(f.source, manifest.segments[0].path), "utf8"),
        ).toBe("");
        expect(fs.readFileSync(join(f.source, "events.jsonl"), "utf8")).toBe(
          f.events.map((e) => JSON.stringify(e) + "\n").join(""),
        );
      } finally {
        s.close();
      }
    },
  );
  it.each(kinds)(
    "observes %s legacy media for live health/effects refusal after corruption",
    (kind) => {
      const f = migrated(kind);
      const s = new ShiftStore(f.source);
      try {
        expect(s.storageAvailable).toBe(true);
        fs.writeFileSync(
          join(f.source, f.path),
          Buffer.alloc(BYTES.length, 88),
        );
        expect(s.storageAvailable).toBe(false);
        expect(s.effectsAllowed).toBe(false);
      } finally {
        s.close();
      }
    },
  );
  it.each([false, true])(
    "validates retained mapping targets after a historical note overwrite, missing=%s",
    (missing) => {
      const f = seed("note");
      // The existing V1 projection permits a later note with the same ID. Its
      // mapping remains a retained document even when the final note has no ref.
      const created = f.events.find((e) => e.type === "note_created")!;
      if (created.type !== "note_created")
        throw new Error("fixture note required");
      const note = { ...created.note };
      delete note.mediaFile;
      fs.appendFileSync(
        join(f.source, "events.jsonl"),
        JSON.stringify({ type: "note_created", at: AT, note }) + "\n",
      );
      const s = new ShiftStore(f.source, {
        legacySession: "R53-synthetic",
        io: {
          checkpoint(point) {
            if (missing && point === "after_manifest_rename") {
              const name = fs
                .readdirSync(join(f.source, "media"))
                .find((n) => n.endsWith(".json"))!;
              fs.unlinkSync(join(f.source, "media", name.slice(0, -5)));
            }
          },
        },
      });
      try {
        expect(s.storageAvailable).toBe(!missing);
        expect(s.migration!.mediaMappings).toHaveLength(1);
        expect(s.note("n1")?.mediaFile).toBeUndefined();
        expect(s.operationalHold).toBe(true);
        expect(s.effectsAllowed).toBe(false);
      } finally {
        s.close();
      }
    },
  );
  it("preserves remote media references and unknown historical processed events", () => {
    const f = seed("inline");
    const message = f.events[0]!;
    if (message.type !== "message_received")
      throw new Error("fixture message required");
    message.message.mediaRef = "https://synthetic.invalid/original-audio";
    fs.writeFileSync(
      join(f.source, "events.jsonl"),
      f.events.map((e) => JSON.stringify(e) + "\n").join(""),
    );
    const s = new ShiftStore(f.source, { legacySession: "R53-synthetic" });
    expect(s.storageAvailable).toBe(true);
    expect(s.migration!.mediaMappings).toEqual([]);
    s.close();
    expect(() => ShiftStore.validateStoppedVolume(f.source)).not.toThrow();
  });
});
