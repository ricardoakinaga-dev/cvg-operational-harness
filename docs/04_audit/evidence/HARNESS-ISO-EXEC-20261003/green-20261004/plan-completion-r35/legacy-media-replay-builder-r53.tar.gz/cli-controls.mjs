import fs from 'node:fs'
import path from 'node:path'
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'
import assert from 'node:assert/strict'
import { pathToFileURL, fileURLToPath } from 'node:url'
const own = path.dirname(fileURLToPath(import.meta.url))
const phase = process.argv[2]
assert.ok(['before', 'after', 'after-final'].includes(phase))
const product = path.join(own, 'candidate/products/shift-assistant')
const { ShiftStore } = await import(pathToFileURL(path.join(product, 'dist/offline-validator.mjs')))
const root = path.join(own, 'output', phase + '-cli')
fs.mkdirSync(root, { recursive: true })
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
const bytes = Buffer.from('R53_SYNTHETIC_AUDIO_IMAGE_BYTES')
const at = '2026-10-05T12:00:00.000Z'
function inventory(dir, rel = '') {
  const out = []
  for (const name of fs.readdirSync(path.join(dir, rel)).sort()) {
    const r = rel ? rel + '/' + name : name
    if (r === 'store.lock') continue
    const p = path.join(dir, r), stat = fs.lstatSync(p)
    if (stat.isDirectory()) out.push(...inventory(dir, r))
    else out.push({ path: r, bytes: stat.size, sha256: sha(fs.readFileSync(p)) })
  }
  return out.sort((a,b) => a.path.localeCompare(b.path, 'en'))
}
function fixture(name, kind) {
  const base = path.join(root, name), source = path.join(base, 'source')
  fs.mkdirSync(path.join(source, 'media'), { recursive: true })
  let ref
  if (kind === 'local') {
    const donor = new ShiftStore(path.join(base, 'donor'))
    ref = donor.saveMediaDescriptor(bytes, 'image/png', 'R53-local').path
    donor.close()
    for (const suffix of ['', '.json']) fs.copyFileSync(path.join(base, 'donor', ref + suffix), path.join(source, ref + suffix))
  }
  if (kind === 'note') fs.writeFileSync(path.join(source, 'media/original.ogg'), bytes)
  const events = [
    { type: 'message_received', at, message: {
      provider: 'waha', messageId: 'm1', fromPhone: '5511900000001',
      kind: kind === 'local' ? 'image' : 'audio', text: 'R53 synthetic original', receivedAt: at,
      ...(kind === 'local' ? { mediaRef: ref, mimetype: 'image/png' } : {}),
      ...(kind === 'inline' ? { mediaRef: 'base64:' + bytes.toString('base64'), mimetype: 'audio/ogg' } : {})
    }},
    { type: 'note_created', at, note: {
      id: 'n1', messageId: 'm1', authorPhone: '5511900000001', createdAt: at,
      kind: kind === 'local' ? 'image' : 'audio', rawText: 'R53 synthetic original',
      unverifiedNumbers: [], confirmed: true,
      ...(kind === 'note' ? { mediaFile: 'original.ogg' } : {})
    }},
    { type: 'message_processed', at, messageId: 'unknown-historical' },
    { type: 'message_processed', at, messageId: 'm1' }
  ]
  const original = events.map(e => JSON.stringify(e) + '\n').join('')
  fs.writeFileSync(path.join(source, 'events.jsonl'), original)
  const store = new ShiftStore(source, { legacySession: 'R53-synthetic' })
  assert.equal(store.storageAvailable, true)
  assert.equal(store.operationalHold, true)
  assert.equal(store.effectsAllowed, false)
  if (kind !== 'local') ref = store.migration.mediaMappings[0].path
  const migration = store.migration
  store.close()
  assert.equal(fs.readFileSync(path.join(source, 'events.jsonl'), 'utf8'), original)
  return { base, source, ref, migration, identity: ShiftStore.validateStoppedVolume(source) }
}
const cliRuns = []
function cli(label, mode, source, destination) {
  const cmd = [path.join(product, 'scripts/backup-restore.mjs'), mode, source, destination]
  const r = spawnSync(process.execPath, cmd, { cwd: own, encoding: 'utf8' })
  fs.writeFileSync(path.join(root, label + '.stdout.txt'), r.stdout ?? '')
  fs.writeFileSync(path.join(root, label + '.stderr.txt'), r.stderr ?? '')
  const result = { label, command: [process.execPath, ...cmd], exit: r.status, stdout: r.stdout, stderr: r.stderr }
  cliRuns.push(result)
  return result
}
function mutate(dir, ref, mode) {
  const file = path.join(dir, ref)
  if (mode === 'recovery-only') fs.unlinkSync(file)
  else if (mode === 'same-size-bytes') fs.writeFileSync(file, Buffer.alloc(bytes.length, 88))
  else if (mode === 'sidecar-missing') fs.unlinkSync(file + '.json')
  else {
    const d = JSON.parse(fs.readFileSync(file + '.json'))
    if (mode === 'sidecar-path') d.path = 'media/wrong.ogg'
    if (mode === 'sidecar-size') d.bytes += 1
    if (mode === 'sidecar-hash') d.sha256 = 'f'.repeat(64)
    fs.writeFileSync(file + '.json', JSON.stringify(d))
  }
}
const results = []
for (const kind of ['local', 'note', 'inline']) {
  const f = fixture('positive-' + kind, kind), before = inventory(f.source)
  const backup = path.join(f.base, 'backup'), target = path.join(f.base, 'target')
  const b = cli('positive-' + kind + '-backup', 'backup', f.source, backup)
  assert.equal(b.exit, 0)
  assert.equal(JSON.parse(b.stdout).status, 'backup_verified')
  const r = cli('positive-' + kind + '-restore', 'restore', backup, target)
  assert.equal(r.exit, 0)
  assert.equal(JSON.parse(r.stdout).status, 'restored_under_hold')
  assert.deepEqual(inventory(f.source), before)
  assert.deepEqual(inventory(path.join(backup, 'documents')), before)
  assert.deepEqual(inventory(target).filter(x => x.path !== 'restore-hold.json'), before)
  assert.deepEqual(ShiftStore.validateStoppedVolume(target), f.identity)
  const restored = new ShiftStore(target)
  assert.equal(restored.storageAvailable, true)
  assert.equal(restored.operationalHold, true)
  assert.equal(restored.effectsAllowed, false)
  assert.deepEqual(Buffer.from(restored.readMedia(f.ref).bytes), bytes)
  assert.deepEqual(restored.migration, f.migration)
  restored.close()
  results.push({ kind, mode: 'positive', pass: true, identity: f.identity, exactDocuments: true, hold: true, effects: false })
  for (const mode of ['recovery-only', 'same-size-bytes', 'sidecar-missing', 'sidecar-path', 'sidecar-size', 'sidecar-hash']) {
    const name = kind + '-' + mode, n = fixture(name, kind)
    const backup = path.join(n.base, 'backup'), docs = path.join(backup, 'documents')
    assert.equal(cli(name + '-valid-backup', 'backup', n.source, backup).exit, 0)
    mutate(n.source, n.ref, mode)
    mutate(docs, n.ref, mode)
    // Adversary rehashes outer backup receipt. Internal runtime references must still fail.
    const receiptPath = path.join(backup, 'manifest.json'), receipt = JSON.parse(fs.readFileSync(receiptPath))
    receipt.documents = inventory(docs)
    fs.writeFileSync(receiptPath, JSON.stringify(receipt, null, 2) + '\n')
    const before = inventory(n.source), copied = inventory(docs)
    let offlineRejected = false
    try { ShiftStore.validateStoppedVolume(n.source) } catch { offlineRejected = true }
    const offlineExact = JSON.stringify(inventory(n.source)) === JSON.stringify(before)
    const s = new ShiftStore(n.source)
    const runtime = { available: s.storageAvailable, hold: s.operationalHold, effects: s.effectsAllowed, diagnostic: s.diagnostic ?? null }
    s.close()
    const rejectedBackup = cli(name + '-invalid-backup', 'backup', n.source, path.join(n.base, 'bad-backup'))
    const rejectedRestore = cli(name + '-forged-restore', 'restore', backup, path.join(n.base, 'bad-target'))
    assert.deepEqual(inventory(n.source), before)
    assert.deepEqual(inventory(docs), copied)
    if (kind === 'local' && mode === 'recovery-only') {
      assert.equal(fs.existsSync(path.join(n.source, n.ref)), false)
      assert.deepEqual(fs.readFileSync(path.join(n.source, n.migration.backupPath, n.ref)), bytes)
    }
    results.push({
      kind, mode, source: n.source, ref: n.ref, offlineRejected, offlineExact, runtime,
      backupExit: rejectedBackup.exit, restoreExit: rejectedRestore.exit,
      documentsUnchanged: true, targetAbsent: !fs.existsSync(path.join(n.base, 'bad-target')),
      pass: offlineRejected && offlineExact && !runtime.available && runtime.hold && !runtime.effects && rejectedBackup.exit === 1 && rejectedRestore.exit === 1 && !fs.existsSync(path.join(n.base, 'bad-target'))
    })
  }
}
fs.writeFileSync(path.join(root, 'commands.json'), JSON.stringify(cliRuns, null, 2) + '\n')
fs.writeFileSync(path.join(root, 'results.json'), JSON.stringify(results, null, 2) + '\n')
const summary = { phase, controls: results.length, passed: results.filter(x => x.pass).length, failed: results.filter(x => !x.pass).length, cliCommands: cliRuns.length,
  bundleSha256: sha(fs.readFileSync(path.join(product, 'dist/offline-validator.mjs'))),
  cliSha256: sha(fs.readFileSync(path.join(product, 'scripts/backup-restore.mjs'))) }
fs.writeFileSync(path.join(root, 'summary.json'), JSON.stringify(summary, null, 2) + '\n')
console.log(JSON.stringify(summary))
if (summary.failed) process.exitCode = 1
