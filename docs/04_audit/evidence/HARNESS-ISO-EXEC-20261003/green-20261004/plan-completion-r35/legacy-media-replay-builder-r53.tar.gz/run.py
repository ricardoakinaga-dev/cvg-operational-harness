import json, os, pathlib, subprocess, sys, time
root = pathlib.Path(__file__).resolve().parent
label, cwd, *cmd = sys.argv[1:]
env = dict(os.environ)
env['PATH'] = '/home/ricardo/.nvm/versions/node/v22.23.2/bin:' + env['PATH']
env['TMPDIR'] = str(root / 'tmp')
env['XDG_CACHE_HOME'] = str(root / 'tool-cache')
out = root / 'output'
start = time.time()
with (out / (label + '.stdout.txt')).open('wb') as stdout, (out / (label + '.stderr.txt')).open('wb') as stderr:
    p = subprocess.run(cmd, cwd=cwd, env=env, stdout=stdout, stderr=stderr)
record = {'label': label, 'cwd': cwd, 'command': cmd, 'exit': p.returncode, 'seconds': time.time()-start, 'node': '/home/ricardo/.nvm/versions/node/v22.23.2/bin/node', 'tmp': env['TMPDIR']}
(out / (label + '.command.json')).write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record))
sys.exit(p.returncode)
