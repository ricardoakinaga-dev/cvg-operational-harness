import * as fs from 'node:fs'
import { randomUUID } from 'node:crypto'
import { dirname, join } from 'node:path'
import type { LegacyShiftEvent, Note, Task, InboundMessage } from './domain.ts'
import {
  Journal,
  LegacyEventSchema,
  StoreError,
  MAX_V1_LINE,
  canonical,
  copySynced,
  decodeJSON,
  exclusiveFile,
  fileHash,
  lines,
  safePath,
  sha256,
  syncDir,
  type JournalManifest,
  type MigrationRecord,
  type MediaDescriptor
} from './journal.ts'

export interface MigrationOptions {
  legacySession?: string
}
export interface MigrationPreparation {
  legacy: NonNullable<JournalManifest['legacy']>
  record: MigrationRecord
  recovery?: NonNullable<JournalManifest['pendingRecovery']>
}

/** No rewriting of V1. This returns a conservative projection and an inventory-bound mapping. */
export function prepareMigration(
  journal: Journal,
  options: MigrationOptions,
  apply: (event: LegacyShiftEvent) => void
): MigrationPreparation | undefined {
  const legacyFile = safePath(journal.root, 'events.jsonl')
  if (!fs.existsSync(legacyFile)) return undefined
  if (!options.legacySession?.trim())
    throw new StoreError(
      'STORAGE_UNAVAILABLE',
      'Migration requires configured legacySession'
    )
  const inventory: MigrationRecord['inventory'] = []
  function inventoryFile(path: string): void {
    const absolute = safePath(journal.root, path)
    if (!fs.statSync(absolute).isFile())
      throw new StoreError('STORAGE_UNAVAILABLE')
    inventory.push({
      path,
      bytes: fs.statSync(absolute).size,
      sha256: fileHash(absolute)
    })
  }
  inventoryFile('events.jsonl')
  function walk(path: string): void {
    for (const name of fs.readdirSync(safePath(journal.root, path)).sort()) {
      const relative = path + '/' + name
      const absolute = safePath(journal.root, relative)
      if (fs.statSync(absolute).isDirectory()) walk(relative)
      else inventoryFile(relative)
    }
  }
  walk('media')
  const backupPath = 'recovery/backup-' + randomUUID()
  fs.mkdirSync(safePath(journal.root, backupPath))
  syncDir(join(journal.root, 'recovery'), journal.io)
  for (const item of inventory) {
    const destination = safePath(journal.root, backupPath + '/' + item.path)
    fs.mkdirSync(dirname(destination), { recursive: true })
    syncDir(dirname(dirname(destination)), journal.io)
    copySynced(safePath(journal.root, item.path), destination, journal.io)
    if (fileHash(destination) !== item.sha256)
      throw new StoreError('STORAGE_UNAVAILABLE')
  }
  exclusiveFile(
    safePath(journal.root, backupPath + '/inventory.json'),
    Buffer.from(canonical(inventory) + '\n'),
    journal.io
  )
  journal.io.checkpoint?.('migration_backup_synced')
  const notes = new Map<string, Note>()
  const tasks = new Map<number, Task>()
  const messages = new Map<string, InboundMessage>()
  const processed = new Set<string>()
  const mediaMappings: MigrationRecord['mediaMappings'] = []
  const mediaByLegacy = new Map<string, string>()
  let prefixBytes = 0
  let recovery: MigrationPreparation['recovery']
  for (const line of lines(legacyFile, MAX_V1_LINE)) {
    if (!line.delimited) {
      const originalSha256 = fileHash(legacyFile)
      const dir = 'recovery/' + randomUUID()
      fs.mkdirSync(safePath(journal.root, dir))
      syncDir(join(journal.root, 'recovery'), journal.io)
      const copyPath = dir + '/original-' + originalSha256 + '.jsonl'
      const tailPath = dir + '/tail.jsonl'
      copySynced(legacyFile, safePath(journal.root, copyPath), journal.io)
      copySynced(
        legacyFile,
        safePath(journal.root, tailPath),
        journal.io,
        prefixBytes
      )
      recovery = {
        type: 'recovery_recorded',
        at: new Date().toISOString(),
        originalPath: 'events.jsonl',
        originalSha256,
        copyPath,
        tailPath,
        prefixBytes,
        prefixSha256: fileHash(legacyFile, prefixBytes),
        reason: 'NONDELIMITED_TAIL'
      }
      break
    }
    const original = LegacyEventSchema.parse(decodeJSON(line.bytes))
    const event = structuredClone(original)
    if (event.type === 'message_received') {
      const key = JSON.stringify([
        event.message.provider,
        options.legacySession,
        event.message.messageId
      ])
      const previous = messages.get(key)
      if (
        previous &&
        canonical({ ...previous, receivedAt: '' }) !==
          canonical({ ...event.message, receivedAt: '' })
      )
        throw new StoreError(
          'STORAGE_UNAVAILABLE',
          'Legacy message collision requires review'
        )
      if (
        [...messages.values()].some(
          (m) =>
            m.messageId === event.message.messageId &&
            m.provider !== event.message.provider
        )
      )
        throw new StoreError('STORAGE_UNAVAILABLE', 'Legacy identity collision')
      // The raw envelope remains in the verified backup; V2 never copies inline blobs.
      if (event.message.mediaRef?.startsWith('base64:')) {
        const ref = event.message.mediaRef.slice(7)
        if (
          !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(
            ref
          )
        )
          throw new StoreError('STORAGE_UNAVAILABLE')
        const mime = legacyMime(event.message.mimetype)
        const mappingKey = 'inbound-' + sha256(key) + '.bin'
        const media = journal.saveMedia(Buffer.from(ref, 'base64'), mime, key)
        mediaMappings.push({ legacyPath: mappingKey, path: media.path })
        event.message.mediaRef = media.path
      }
      messages.set(key, structuredClone(event.message))
    }
    if (event.type === 'message_processed') processed.add(event.messageId)
    if (event.type === 'note_created') {
      if (event.note.mediaFile) {
        const legacyPath = 'media/' + event.note.mediaFile
        let path = mediaByLegacy.get(legacyPath)
        if (!path) {
          const media = journal.saveMedia(
            fs.readFileSync(safePath(journal.root, legacyPath)),
            mimeForExtension(event.note.mediaFile),
            JSON.stringify(['legacy-note', event.note.messageId])
          )
          path = media.path
          mediaByLegacy.set(legacyPath, path)
          mediaMappings.push({ legacyPath, path })
        }
        event.note.mediaFile = path.slice('media/'.length)
      }
      notes.set(event.note.id, structuredClone(event.note))
    }
    if (event.type === 'note_confirmed') {
      const note = notes.get(event.noteId)
      if (!note) throw new StoreError('STORAGE_UNAVAILABLE')
      note.confirmed = true
    }
    if (event.type === 'note_superseded') {
      const note = notes.get(event.noteId)
      if (!note) throw new StoreError('STORAGE_UNAVAILABLE')
      note.supersededBy = event.by
    }
    if (event.type === 'task_created')
      tasks.set(event.task.number, structuredClone(event.task))
    if (
      event.type === 'task_done' ||
      event.type === 'task_cancelled' ||
      event.type === 'task_snoozed' ||
      event.type === 'task_reminded'
    ) {
      const task = tasks.get(event.number)
      if (!task) throw new StoreError('STORAGE_UNAVAILABLE')
      if (event.type === 'task_done') {
        task.status = 'done'
        task.doneAt = event.at
      }
      if (event.type === 'task_cancelled') task.status = 'cancelled'
      if (event.type === 'task_snoozed') {
        task.dueAt = event.dueAt
        task.remindedCount = 0
        delete task.lastRemindedAt
      }
      if (event.type === 'task_reminded') {
        task.remindedCount++
        task.lastRemindedAt = event.at
      }
    }
    apply(event)
    prefixBytes = line.end
  }
  const prefixSha256 = fileHash(legacyFile, prefixBytes)
  const record: MigrationRecord = {
    id:
      'migration:' +
      sha256(canonical({ inventory, session: options.legacySession })),
    session: options.legacySession,
    readerVersion: 2,
    operationalHold: true,
    legacyReviewNoteIds: [...notes.keys()],
    heldTaskNumbers: [...tasks.values()]
      .filter((t) => t.status === 'open')
      .map((t) => t.number),
    draftTaskNumbers: [...tasks.values()]
      .filter(
        (t) =>
          t.status === 'open' && (!t.noteId || !notes.get(t.noteId)?.confirmed)
      )
      .map((t) => t.number),
    messages: [...messages.values()].map((m) => ({
      messageId: m.messageId,
      messageKey: JSON.stringify([
        m.provider,
        options.legacySession,
        m.messageId
      ]),
      state:
        [...notes.values()].some((n) => n.messageId === m.messageId) &&
        processed.has(m.messageId)
          ? 'uncertain_legacy'
          : 'review_required'
    })),
    backupPath,
    inventory,
    mediaMappings
  }
  return {
    legacy: {
      path: 'events.jsonl',
      bytes: prefixBytes,
      prefixSha256,
      sealed: true,
      fullSha256: fileHash(legacyFile),
      ...(recovery ? { reason: 'NONDELIMITED_TAIL' } : {})
    },
    record,
    ...(recovery ? { recovery } : {})
  }
}

/** Replay the approved legacy prefix using only mappings fixed by the migration. */
export function replayLegacy(
  journal: Journal,
  apply: (event: LegacyShiftEvent) => void
): void {
  const manifest = journal.manifest!
  if (!manifest.legacy) return
  journal.verifyDescriptor(manifest.legacy)
  const record = manifest.migration
  if (!record) throw new StoreError('STORAGE_UNAVAILABLE')
  for (const line of lines(
    safePath(journal.root, manifest.legacy.path),
    MAX_V1_LINE,
    manifest.legacy.bytes
  )) {
    if (!line.delimited) throw new StoreError('STORAGE_UNAVAILABLE')
    const event = LegacyEventSchema.parse(decodeJSON(line.bytes))
    if (
      event.type === 'message_received' &&
      event.message.mediaRef?.startsWith('base64:')
    ) {
      const key = JSON.stringify([
        event.message.provider,
        record.session,
        event.message.messageId
      ])
      const mapping = record.mediaMappings.find(
        (m) => m.legacyPath === 'inbound-' + sha256(key) + '.bin'
      )
      if (!mapping) throw new StoreError('STORAGE_UNAVAILABLE')
      journal.verifyMedia(mapping.path)
      event.message.mediaRef = mapping.path
    }
    // Published local V1 references are not externalized by migration. Verify
    // the primary bytes used by the projection, never its recovery copy.
    if (
      event.type === 'message_received' &&
      event.message.mediaRef?.startsWith('media/')
    )
      journal.verifyMedia(event.message.mediaRef)
    if (event.type === 'note_created' && event.note.mediaFile) {
      const mapping = record.mediaMappings.find(
        (m) => m.legacyPath === 'media/' + event.note.mediaFile
      )
      if (!mapping) throw new StoreError('STORAGE_UNAVAILABLE')
      journal.verifyMedia(mapping.path)
      event.note.mediaFile = mapping.path.slice('media/'.length)
    }
    apply(event)
  }
}

export function mimeForExtension(name: string): MediaDescriptor['mime'] {
  const extension = name.split('.').at(-1)?.toLowerCase()
  const map: Record<string, MediaDescriptor['mime']> = {
    ogg: 'audio/ogg',
    mp3: 'audio/mpeg',
    m4a: 'audio/mp4',
    wav: 'audio/wav',
    jpg: 'image/jpeg',
    jpeg: 'image/jpeg',
    png: 'image/png',
    bin: 'application/octet-stream'
  }
  if (!extension || !map[extension])
    throw new StoreError('INVALID_TRANSITION', 'Unsupported media extension')
  return map[extension]
}
function legacyMime(value?: string): MediaDescriptor['mime'] {
  const allowed = [
    'audio/ogg',
    'audio/mpeg',
    'audio/mp4',
    'audio/wav',
    'image/jpeg',
    'image/png',
    'application/octet-stream'
  ]
  if (!value || !allowed.includes(value))
    throw new StoreError('STORAGE_UNAVAILABLE', 'Unsupported legacy MIME')
  return value as MediaDescriptor['mime']
}
