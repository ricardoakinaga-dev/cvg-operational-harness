// @vitest-environment node
import * as fs from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { createServer, type Server } from 'node:http'
import type { AddressInfo } from 'node:net'
import { afterEach, expect, it } from 'vitest'
import { ShiftStore } from '../store.ts'
import { canonical, sha256 } from '../journal.ts'
import { ShiftAssistant } from '../assistant.ts'
import { WahaClient } from '../whatsapp.ts'
import { buildShiftServer } from '../server.ts'
import {
  backupStoppedVolume,
  restoreBackup
} from '../../scripts/backup-restore.mjs'
const AT = '2026-10-03T12:00:00.000Z',
  PHONE = '5511900000001'
const closers: Array<() => void | Promise<void>> = []
afterEach(async () => {
  for (const close of closers.splice(0).reverse()) await close()
})
function fixture(media = false) {
  const root = fs.mkdtempSync(join(tmpdir(), 'r38-retained-')),
    source = join(root, 'source')
  const store = new ShiftStore(source)
  const descriptor = media
    ? store.saveMediaDescriptor(
        Buffer.from('synthetic media'),
        'image/png',
        'm1'
      )
    : undefined
  store.commit({
    transitionId: 'input:m1',
    expected: { inbox: { m1: 0 } },
    changes: [
      {
        type: 'message_received',
        at: AT,
        message: {
          provider: 'waha',
          messageId: 'm1',
          fromPhone: PHONE,
          kind: media ? 'image' : 'text',
          text: 'ajuda',
          receivedAt: AT,
          ...(descriptor ? { mediaRef: descriptor.path } : {})
        }
      }
    ]
  })
  store.close()
  return {
    root,
    source,
    media: descriptor?.path,
    backup: join(root, 'backup'),
    target: join(root, 'target')
  }
}
function manifest(root: string) {
  return JSON.parse(
    fs.readFileSync(join(root, 'journal/manifest.json'), 'utf8')
  )
}
function active(root: string) {
  return join(root, manifest(root).segments.at(-1).path)
}
function files(root: string, relative = ''): Record<string, string> {
  const values: Record<string, string> = {}
  for (const name of fs.readdirSync(join(root, relative)).sort()) {
    const rel = relative ? relative + '/' + name : name
    if (rel === 'store.lock') continue
    if (fs.statSync(join(root, rel)).isDirectory())
      Object.assign(values, files(root, rel))
    else values[rel] = sha256(fs.readFileSync(join(root, rel)))
  }
  return values
}
function mutate(root: string, mode: string, media?: string) {
  const m = manifest(root)
  if (mode === 'revision') delete m.revision
  if (mode === 'prefix') m.segments[0].prefixSha256 = 'f'.repeat(64)
  if (mode === 'revision-file') {
    fs.unlinkSync(
      join(root, 'journal/manifests/revision-' + m.revision + '.json')
    )
    return
  }
  if (mode === 'revision' || mode === 'prefix') {
    const bytes = canonical(m) + '\n'
    fs.writeFileSync(join(root, 'journal/manifest.json'), bytes)
    fs.writeFileSync(join(root, 'journal/manifests/revision-1.json'), bytes)
  } else if (mode === 'unknown' || mode === 'reference') {
    const record = JSON.parse(fs.readFileSync(active(root), 'utf8'))
    record.changes = [
      {
        type: mode === 'unknown' ? 'unrecognized_event' : 'task_done',
        at: AT,
        ...(mode === 'reference' ? { number: 1 } : {})
      }
    ]
    const { sha256: _checksum, ...body } = record
    void _checksum
    record.sha256 = sha256(canonical(body))
    fs.writeFileSync(active(root), canonical(record) + '\n')
  } else if (mode === 'media') fs.unlinkSync(join(root, media!))
  else if (mode === 'media-sidecar')
    fs.writeFileSync(join(root, media! + '.json'), '{}')
  else if (mode === 'tail') fs.appendFileSync(active(root), '{"partial":')
}
const modes = [
  'revision',
  'prefix',
  'unknown',
  'media',
  'revision-file',
  'reference',
  'media-sidecar'
]
it.each(modes)(
  'refuses offline backup and independently forged hash-consistent restore: %s',
  (mode) => {
    const f = fixture(mode.startsWith('media'))
    backupStoppedVolume(f.source, f.backup)
    mutate(f.source, mode, f.media)
    const docs = join(f.backup, 'documents')
    mutate(docs, mode, f.media)
    const receipt = JSON.parse(
      fs.readFileSync(join(f.backup, 'manifest.json'), 'utf8')
    )
    const hashes = files(docs)
    receipt.documents = receipt.documents
      .filter((d: { path: string }) => d.path in hashes)
      .map((d: { path: string }) => ({
        path: d.path,
        bytes: fs.statSync(join(docs, d.path)).size,
        sha256: hashes[d.path]
      }))
    if (mode === 'revision') delete receipt.journal.manifestRevision
    if (mode === 'unknown' || mode === 'reference') {
      const bytes = fs.readFileSync(active(docs))
      receipt.journal.headSha256 = JSON.parse(bytes.toString()).sha256
      receipt.journal.prefixes[0] = {
        path: manifest(docs).segments[0].path,
        bytes: bytes.length,
        sha256: sha256(bytes)
      }
    }
    fs.writeFileSync(join(f.backup, 'manifest.json'), JSON.stringify(receipt))
    const before = files(f.source),
      copiedBefore = files(docs)
    const runtime = new ShiftStore(f.source)
    const runtimeAvailable = runtime.storageAvailable
    runtime.close()
    let backupAccepted = false,
      restoreAccepted = false
    try {
      backupStoppedVolume(f.source, join(f.root, 'bad-backup'))
      backupAccepted = true
    } catch {
      /* expected refusal */
    }
    try {
      restoreBackup(f.backup, f.target)
      restoreAccepted = true
    } catch {
      /* expected refusal */
    }
    console.info('R38_OFFLINE', {
      mode,
      root: f.root,
      runtimeAvailable,
      backupAccepted,
      restoreAccepted
    })
    expect(files(f.source)).toEqual(before)
    expect(files(docs)).toEqual(copiedBefore)
    expect(runtimeAvailable).toBe(false)
    expect(backupAccepted).toBe(false)
    expect(restoreAccepted).toBe(false)
    expect(fs.existsSync(f.target)).toBe(false)
  }
)
async function bind(server: Server) {
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve))
  closers.push(() => {
    server.closeAllConnections()
    return new Promise<void>((resolve) => server.close(() => resolve()))
  })
  return 'http://127.0.0.1:' + (server.address() as AddressInfo).port
}
it.each([
  'byte',
  'truncate',
  'replace',
  'manifest',
  'revision-file',
  'media',
  'media-sidecar',
  'utimes'
])(
  'denies live ingress/readiness/effects and preserves corrupted bytes: %s',
  async (mode) => {
    const f = fixture(mode.startsWith('media')),
      store = new ShiftStore(f.source)
    closers.push(() => store.close())
    let sends = 0
    const receiver = createServer((req, res) => {
      req.resume()
      if (req.url === '/api/sendText') sends++
      res.setHeader('content-type', 'application/json')
      res.end('{"id":"synthetic-accepted"}')
    })
    const client = new WahaClient({
      baseUrl: await bind(receiver),
      apiKey: 'synthetic',
      session: 'r38',
      fetch
    })
    const assistant = new ShiftAssistant({
      store,
      members: [{ phone: PHONE, name: 'Synthetic', manager: true }],
      whatsapp: client,
      organizer: {
        async organize() {
          throw new Error('NO_MODEL')
        }
      },
      transcriber: {
        async transcribe() {
          throw new Error('NO_MODEL')
        }
      }
    })
    closers.push(() => assistant.stop())
    const server = buildShiftServer({
        store,
        assistant,
        whatsapp: client,
        webhookSecret: 'r38-synthetic-secret'
      }),
      url = await bind(server)
    expect((await fetch(url + '/health/ready')).status).toBe(200)
    const segment = active(f.source),
      original = fs.readFileSync(segment),
      originalStat = fs.statSync(segment)
    if (mode === 'byte' || mode === 'utimes') {
      const fd = fs.openSync(segment, 'r+')
      fs.writeSync(fd, Buffer.from('!'), 0, 1, 0)
      fs.closeSync(fd)
    }
    if (mode === 'utimes')
      fs.utimesSync(segment, originalStat.atime, originalStat.mtime)
    if (mode.startsWith('media')) mutate(f.source, mode, f.media)
    if (mode === 'truncate') fs.truncateSync(segment, original.length - 1)
    if (mode === 'replace') {
      fs.renameSync(segment, segment + '.retained')
      fs.writeFileSync(segment, original)
    }
    if (mode === 'manifest')
      fs.appendFileSync(join(f.source, 'journal/manifest.json'), ' ')
    if (mode === 'revision-file') mutate(f.source, mode)
    const before = files(f.source)
    const response = await fetch(url + '/webhooks/waha', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-cvg-webhook-secret': 'r38-synthetic-secret'
      },
      body: JSON.stringify({
        event: 'message',
        session: 'r38',
        payload: { id: 'after-corrupt', from: PHONE + '@c.us', body: 'ajuda' }
      })
    })
    await assistant.idle()
    const ready = await fetch(url + '/health/ready')
    console.info('R38_LIVE', {
      mode,
      root: f.root,
      ingress: response.status,
      readiness: ready.status,
      sends,
      bytesPreserved: canonical(files(f.source)) === canonical(before)
    })
    expect(response.status).toBe(503)
    expect(ready.status).toBe(503)
    expect(sends).toBe(0)
    expect(store.effectsAllowed).toBe(false)
    expect(files(f.source)).toEqual(before)
  }
)
it('healthy backup/restore preserves exact bytes and reopens under hold; unrecovered tail is refused without rewriting it', () => {
  const f = fixture(true),
    before = files(f.source)
  expect(backupStoppedVolume(f.source, f.backup).status).toBe('backup_verified')
  expect(restoreBackup(f.backup, f.target).status).toBe('restored_under_hold')
  expect(files(f.source)).toEqual(before)
  const reopened = new ShiftStore(f.target)
  try {
    expect(reopened.storageAvailable).toBe(true)
    expect(reopened.effectsAllowed).toBe(false)
  } finally {
    reopened.close()
  }
  mutate(f.source, 'tail')
  const corrupt = files(f.source)
  expect(() =>
    backupStoppedVolume(f.source, join(f.root, 'tail-backup'))
  ).toThrow()
  expect(files(f.source)).toEqual(corrupt)
})

it('checks readiness before ingress and keeps failure sticky after byte restoration', async () => {
  const f = fixture(),
    store = new ShiftStore(f.source)
  closers.push(() => store.close())
  const original = fs.readFileSync(active(f.source)),
    fd = fs.openSync(active(f.source), 'r+')
  fs.writeSync(fd, Buffer.from('!'), 0, 1, 0)
  fs.closeSync(fd)
  expect(store.storageAvailable).toBe(false)
  fs.writeFileSync(active(f.source), original)
  expect(store.storageAvailable).toBe(false)
  expect(() => store.append({ type: 'paused', at: AT, by: PHONE })).toThrow(
    'STORAGE_UNAVAILABLE'
  )
  expect(fs.readFileSync(active(f.source))).toEqual(original)
})

it.each(['after_journal_lf', 'after_journal_sync'])(
  'does not bless corruption in the %s checkpoint as an owned write',
  (point) => {
    const f = fixture()
    let armed = false
    const store = new ShiftStore(f.source, {
      io: {
        checkpoint(name) {
          if (armed && name === point) {
            const fd = fs.openSync(active(f.source), 'r+')
            fs.writeSync(fd, Buffer.from('!'), 0, 1, 0)
            fs.closeSync(fd)
          }
        }
      }
    })
    closers.push(() => store.close())
    armed = true
    expect(() => store.append({ type: 'paused', at: AT, by: PHONE })).toThrow(
      'STORAGE_UNAVAILABLE'
    )
    expect(store.storageAvailable).toBe(false)
    expect(store.effectsAllowed).toBe(false)
    expect(fs.readFileSync(active(f.source))[0]).toBe(33)
  }
)

it('validates offline without lock, chmod, fsync, recovery or document modification', () => {
  const f = fixture(true)
  fs.chmodSync(active(f.source), 0o640)
  const before = files(f.source),
    stat = fs.statSync(active(f.source), { bigint: true })
  const result = ShiftStore.validateStoppedVolume(f.source)
  const after = fs.statSync(active(f.source), { bigint: true })
  expect(result.sequence).toBe(1)
  expect(files(f.source)).toEqual(before)
  expect([after.mode, after.mtimeNs, after.ctimeNs, after.ino]).toEqual([
    stat.mode,
    stat.mtimeNs,
    stat.ctimeNs,
    stat.ino
  ])
  expect(fs.existsSync(join(f.source, 'store.lock'))).toBe(false)
  mutate(f.source, 'tail')
  const damaged = files(f.source)
  expect(() => ShiftStore.validateStoppedVolume(f.source)).toThrow(
    'STORAGE_UNAVAILABLE'
  )
  expect(files(f.source)).toEqual(damaged)
  expect(fs.readdirSync(join(f.source, 'recovery'))).toEqual([])
})

// R53: additive legacy-media regression suite; the original R38 tests above are unchanged.
import { describe } from 'vitest'
import { Journal } from '../journal.ts'
import { replayLegacy } from '../migrate-journal.ts'
import type { ShiftEvent } from '../domain.ts'

{
  const AT = '2026-10-05T12:00:00.000Z'
  const PHONE = '5511900000001'
  const BYTES = Buffer.from('R53_SYNTHETIC_AUDIO_IMAGE_BYTES')
  const kinds = ['local', 'note', 'inline'] as const
  type Kind = (typeof kinds)[number]
  function seed(kind: Kind) {
    const root = fs.mkdtempSync(join(tmpdir(), 'r53-legacy-'))
    const source = join(root, 'source')
    fs.mkdirSync(join(source, 'media'), { recursive: true })
    const message = {
      provider: 'waha' as const,
      messageId: 'm1',
      fromPhone: PHONE,
      kind: kind === 'local' ? ('image' as const) : ('audio' as const),
      text: 'R53 synthetic original',
      receivedAt: AT
    }
    let local = ''
    if (kind === 'local') {
      const donor = new ShiftStore(join(root, 'donor'))
      const descriptor = donor.saveMediaDescriptor(
        BYTES,
        'image/png',
        'R53-local'
      )
      donor.close()
      local = descriptor.path
      for (const suffix of ['', '.json'])
        fs.copyFileSync(
          join(root, 'donor', local + suffix),
          join(source, local + suffix)
        )
    }
    if (kind === 'note')
      fs.writeFileSync(join(source, 'media/original.ogg'), BYTES)
    const events: ShiftEvent[] = [
      {
        type: 'message_received',
        at: AT,
        message: {
          ...message,
          ...(kind === 'local'
            ? { mediaRef: local, mimetype: 'image/png' }
            : {}),
          ...(kind === 'inline'
            ? {
                mediaRef: 'base64:' + BYTES.toString('base64'),
                mimetype: 'audio/ogg'
              }
            : {})
        }
      },
      {
        type: 'note_created',
        at: AT,
        note: {
          id: 'n1',
          messageId: 'm1',
          authorPhone: PHONE,
          createdAt: AT,
          kind: message.kind,
          rawText: message.text,
          unverifiedNumbers: [],
          confirmed: true,
          ...(kind === 'note' ? { mediaFile: 'original.ogg' } : {})
        }
      },
      // Historical processed IDs need not be known: retain existing base replay semantics.
      { type: 'message_processed', at: AT, messageId: 'historic-unknown' },
      { type: 'message_processed', at: AT, messageId: 'm1' }
    ]
    fs.writeFileSync(
      join(source, 'events.jsonl'),
      events.map((e) => JSON.stringify(e) + '\n').join('')
    )
    return { root, source, local, events }
  }
  function migrated(kind: Kind) {
    const f = seed(kind)
    const store = new ShiftStore(f.source, { legacySession: 'R53-synthetic' })
    expect(store.storageAvailable, store.diagnostic).toBe(true)
    const path =
      kind === 'local' ? f.local : store.migration!.mediaMappings[0]!.path
    const migration = store.migration!
    store.close()
    return { ...f, path, migration }
  }
  function contents(root: string, relative = ''): Record<string, string> {
    const result: Record<string, string> = {}
    for (const name of fs.readdirSync(join(root, relative)).sort()) {
      const rel = relative ? relative + '/' + name : name
      if (rel === 'store.lock') continue
      const file = join(root, rel),
        stat = fs.lstatSync(file)
      if (stat.isDirectory()) Object.assign(result, contents(root, rel))
      else
        result[rel] = stat.isSymbolicLink()
          ? 'link:' + fs.readlinkSync(file)
          : sha256(fs.readFileSync(file))
    }
    return result
  }
  const modes = [
    'absent',
    'same-size-bytes',
    'sidecar-missing',
    'sidecar-path',
    'sidecar-size',
    'sidecar-hash',
    'symlink',
    'hardlink'
  ] as const
  function corrupt(source: string, path: string, mode: (typeof modes)[number]) {
    const file = join(source, path)
    if (mode === 'absent') fs.unlinkSync(file)
    else if (mode === 'same-size-bytes')
      fs.writeFileSync(file, Buffer.alloc(BYTES.length, 88))
    else if (mode === 'sidecar-missing') fs.unlinkSync(file + '.json')
    else if (mode === 'symlink' || mode === 'hardlink') {
      const retained = join(source, 'retained-media')
      fs.renameSync(file, retained)
      if (mode === 'symlink') fs.symlinkSync(retained, file)
      else fs.linkSync(retained, file)
    } else {
      const descriptor = JSON.parse(fs.readFileSync(file + '.json', 'utf8'))
      if (mode === 'sidecar-path') descriptor.path = 'media/wrong.ogg'
      if (mode === 'sidecar-size') descriptor.bytes += 1
      if (mode === 'sidecar-hash') descriptor.sha256 = 'f'.repeat(64)
      fs.writeFileSync(file + '.json', JSON.stringify(descriptor))
    }
  }
  describe('R53 legacy primary media integrity', () => {
    it.each(kinds)(
      'preserves genuine migrated %s bytes, identity, hold and historical processed semantics',
      (kind) => {
        const f = migrated(kind)
        const before = contents(f.source)
        const identity = ShiftStore.validateStoppedVolume(f.source)
        for (let i = 0; i < 2; i++) {
          const s = new ShiftStore(f.source)
          try {
            expect(s.storageAvailable, s.diagnostic).toBe(true)
            expect(s.operationalHold).toBe(true)
            expect(s.effectsAllowed).toBe(false)
            expect(Buffer.from(s.readMedia(f.path).bytes)).toEqual(BYTES)
            expect(s.note('n1')?.confirmed).toBe(true)
            if (kind === 'note')
              expect(s.note('n1')?.mediaFile).toBe(f.path.slice(6))
            expect(s.migration).toEqual(f.migration)
          } finally {
            s.close()
          }
          expect(ShiftStore.validateStoppedVolume(f.source)).toEqual(identity)
          expect(contents(f.source)).toEqual(before)
        }
        if (kind === 'local')
          expect(
            fs.readFileSync(join(f.source, f.migration.backupPath, f.path))
          ).toEqual(BYTES)
        if (kind === 'note')
          expect(fs.readFileSync(join(f.source, 'media/original.ogg'))).toEqual(
            BYTES
          )
      }
    )
    for (const kind of kinds)
      it.each(modes)(
        'rejects ' +
          kind +
          ' %s without altering documents or adopting recovery media',
        (mode) => {
          const f = migrated(kind)
          corrupt(f.source, f.path, mode)
          const before = contents(f.source)
          expect(() => ShiftStore.validateStoppedVolume(f.source)).toThrow()
          expect(contents(f.source)).toEqual(before)
          const s = new ShiftStore(f.source)
          try {
            expect(s.storageAvailable).toBe(false)
            // Alias refusal precedes loading any migration metadata in the existing
            // constructor. Storage/effects must close even without that projection.
            if (mode !== 'symlink' && mode !== 'hardlink')
              expect(s.operationalHold).toBe(true)
            expect(s.effectsAllowed).toBe(false)
          } finally {
            s.close()
          }
          expect(contents(f.source)).toEqual(before)
          if (mode === 'absent')
            expect(fs.existsSync(join(f.source, f.path))).toBe(false)
        }
      )
    it('direct legacy replay refuses absent local primary before applying the message', () => {
      const f = migrated('local')
      fs.unlinkSync(join(f.source, f.path))
      const journal = new Journal(f.source, {}, true)
      const applied: ShiftEvent[] = []
      try {
        expect(() =>
          replayLegacy(journal, (event) => applied.push(event))
        ).toThrow()
        expect(applied).toEqual([])
      } finally {
        journal.close()
      }
    })
    it.each(kinds)(
      'validates final %s media during first migration before appending its receipt',
      (kind) => {
        const f = seed(kind)
        const s = new ShiftStore(f.source, {
          legacySession: 'R53-synthetic',
          io: {
            checkpoint(point) {
              if (point === 'after_manifest_rename') {
                const target =
                  kind === 'local'
                    ? f.local
                    : fs
                        .readdirSync(join(f.source, 'media'))
                        .find((name) => name.endsWith('.json'))!
                        .slice(0, -5)
                fs.unlinkSync(
                  join(f.source, kind === 'local' ? target : 'media/' + target)
                )
              }
            }
          }
        })
        try {
          expect(s.storageAvailable).toBe(false)
          const manifest = JSON.parse(
            fs.readFileSync(join(f.source, 'journal/manifest.json'), 'utf8')
          )
          expect(
            fs.readFileSync(join(f.source, manifest.segments[0].path), 'utf8')
          ).toBe('')
          expect(fs.readFileSync(join(f.source, 'events.jsonl'), 'utf8')).toBe(
            f.events.map((e) => JSON.stringify(e) + '\n').join('')
          )
        } finally {
          s.close()
        }
      }
    )
    it.each(kinds)(
      'observes %s legacy media for live health/effects refusal after corruption',
      (kind) => {
        const f = migrated(kind)
        const s = new ShiftStore(f.source)
        try {
          expect(s.storageAvailable).toBe(true)
          fs.writeFileSync(
            join(f.source, f.path),
            Buffer.alloc(BYTES.length, 88)
          )
          expect(s.storageAvailable).toBe(false)
          expect(s.effectsAllowed).toBe(false)
        } finally {
          s.close()
        }
      }
    )
    it.each([false, true])(
      'validates retained mapping targets after a historical note overwrite, missing=%s',
      (missing) => {
        const f = seed('note')
        // The existing V1 projection permits a later note with the same ID. Its
        // mapping remains a retained document even when the final note has no ref.
        const created = f.events.find((e) => e.type === 'note_created')!
        if (created.type !== 'note_created')
          throw new Error('fixture note required')
        const note = { ...created.note }
        delete note.mediaFile
        fs.appendFileSync(
          join(f.source, 'events.jsonl'),
          JSON.stringify({ type: 'note_created', at: AT, note }) + '\n'
        )
        const s = new ShiftStore(f.source, {
          legacySession: 'R53-synthetic',
          io: {
            checkpoint(point) {
              if (missing && point === 'after_manifest_rename') {
                const name = fs
                  .readdirSync(join(f.source, 'media'))
                  .find((n) => n.endsWith('.json'))!
                fs.unlinkSync(join(f.source, 'media', name.slice(0, -5)))
              }
            }
          }
        })
        try {
          expect(s.storageAvailable).toBe(!missing)
          expect(s.migration!.mediaMappings).toHaveLength(1)
          expect(s.note('n1')?.mediaFile).toBeUndefined()
          expect(s.operationalHold).toBe(true)
          expect(s.effectsAllowed).toBe(false)
        } finally {
          s.close()
        }
      }
    )
    it('preserves remote media references and unknown historical processed events', () => {
      const f = seed('inline')
      const message = f.events[0]!
      if (message.type !== 'message_received')
        throw new Error('fixture message required')
      message.message.mediaRef = 'https://synthetic.invalid/original-audio'
      fs.writeFileSync(
        join(f.source, 'events.jsonl'),
        f.events.map((e) => JSON.stringify(e) + '\n').join('')
      )
      const s = new ShiftStore(f.source, { legacySession: 'R53-synthetic' })
      expect(s.storageAvailable).toBe(true)
      expect(s.migration!.mediaMappings).toEqual([])
      s.close()
      expect(() => ShiftStore.validateStoppedVolume(f.source)).not.toThrow()
    })
  })
}
