import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {createBoundaryLexical} from '../../candidate-final-r25/scripts/boundary-lexical.mjs';
import {auditDynamicCodeExecution} from '../../candidate-final-r25/scripts/boundary-code-execution.mjs';

// Static tooling only. Never import the inspected fixture or installed payload.
const base='/home/ricardo/.cache/cvg-harness-green-20261004';
const root=path.join(base,'candidate-final-r25');
const out=path.dirname(fileURLToPath(import.meta.url));
if(process.execPath!=='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node')throw Error('Absolute Node22 required');
if(out!==path.join(base,'plan-completion-r35/installed-closure-next-correction-r39'))throw Error('Output confinement');
const hash=x=>createHash('sha256').update(x).digest('hex');
const inputPaths=[
 'c1-nonbinding-label-r22/output/r22-label-installed.log',
 'c1-nonbinding-label-r22/output/installed-summary.json',
 'installed-frontier-plan-r22/output/diagnostic.json',
 'installed-frontier-plan-r22/output/analysis-corrected.json',
 'installed-frontier-plan-r22/output/proposal.json',
 'installed-frontier-plan-r22/output/method.json',
 'firstparty-frontier-disposition-r26/output/report.json',
 'firstparty-frontier-disposition-r26/output/proposed-dispositions.json',
 'decimal-frontier-disposition-r29/output/report.json',
 'decimal-frontier-disposition-r29/output/proposed-dispositions.json',
 ...['check-product-boundary.mjs','boundary-code-execution.mjs','boundary-lexical.mjs','boundary-manifests.mjs','tsconfig-path-grammar.mjs'].flatMap(n=>['candidate-final-r25/scripts/'+n,'c1-nonbinding-label-r22/candidate/scripts/'+n]),
 ...['node_modules/drizzle-orm/pg-core/columns/int.common.cjs','node_modules/drizzle-orm/package.json','node_modules/decimal.js/decimal.js','node_modules/decimal.js/decimal.mjs'].flatMap(n=>['candidate-final-r25/'+n,'c1-nonbinding-label-r22/candidate/'+n]),
 'candidate-final-r25/node_modules/typescript/lib/typescript.js',
 'candidate-final-r25/node_modules/typescript/package.json'
];
const inventory=()=>inputPaths.map(p=>{const f=path.join(base,p),bytes=fs.readFileSync(f),s=fs.statSync(f);return{path:f,realpath:fs.realpathSync(f),bytes:bytes.length,sha256:hash(bytes),nlink:s.nlink};});
const before=inventory();
const ts=createRequire(path.join(root,'scripts/check-product-boundary.mjs'))('typescript');
const json=p=>JSON.parse(fs.readFileSync(path.join(base,p),'utf8'));
const baseline=json(inputPaths[0]);
const counter=xs=>Object.fromEntries([...xs.reduce((m,k)=>m.set(k,(m.get(k)||0)+1),new Map())].sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0])));
const fileOf=r=>r.file.replace(/:\d+$/,'');
const packageOf=r=>{const parts=fileOf(r).split('/');return parts[0]==='node_modules'?parts.slice(0,parts[1]?.startsWith('@')?3:2).join('/'):parts.slice(0,2).join('/');};
const groups=counter(baseline.diagnostics.map(packageOf));
const groupMap={diagnosticSource:inputPaths[0],sourceHash:before[0].sha256,total:baseline.diagnostics.length,status:baseline.status,passed:baseline.passed,violations:baseline.violations.length,reasonCounts:counter(baseline.diagnostics.map(r=>r.reason)),byPackageOrFirstPartyRoot:Object.entries(groups).map(([name,count])=>({name,count,reasons:counter(baseline.diagnostics.filter(r=>packageOf(r)===name).map(r=>r.reason))})),byFile:Object.entries(counter(baseline.diagnostics.map(fileOf))).map(([file,count])=>({file,count})),distinctFiles:new Set(baseline.diagnostics.map(fileOf)).size,legacyPlan:{total:json('installed-frontier-plan-r22/output/diagnostic.json').diagnostics.length,method:json('installed-frontier-plan-r22/output/method.json'),usableAsCurrentBaseline:false},sourceRowsChanged:false};
const canonical=x=>JSON.stringify(Object.fromEntries(Object.entries(x).sort(([a],[b])=>a.localeCompare(b))));
const unwrap=n=>{while(n&&(ts.isParenthesizedExpression(n)||ts.isAsExpression(n)||ts.isSatisfiesExpression(n)||ts.isTypeAssertionExpression(n)||ts.isNonNullExpression(n)))n=n.expression;return n;};
const literal=n=>{n=unwrap(n);return n&&ts.isStringLiteralLike(n)?n.text:undefined;};
const property=n=>n&&(ts.isPropertyAccessExpression(n)?n.name.text:ts.isElementAccessExpression(n)?literal(n.argumentExpression):undefined);
function analyze(name,text,commonJs=true){
 const source=ts.createSourceFile(name,text,ts.ScriptTarget.Latest,true),all=[];
 const collect=n=>{all.push(n);ts.forEachChild(n,collect);};collect(source);
 const unavailable=[];
 const lexical=createBoundaryLexical(ts,source,commonJs,d=>unavailable.push(d));
 const runtimeNodes=all.filter(n=>!lexical.erased(n));
 const ident=(n,names)=>{n=unwrap(n);return !!n&&ts.isIdentifier(n)&&names.some(k=>lexical.identity(n)===lexical.global(k));};
 const isGlobal=n=>ident(n,['globalThis','global']);
 const isLoader=n=>ident(n,['require'])||(property(n)==='require'&&ident(n.expression,['module']));
 const isBuiltinGetter=n=>property(n)==='getBuiltinModule'&&ident(n.expression,['process']);
 const span=n=>{const start=n.getStart(source),end=n.getEnd(),lc=source.getLineAndCharacterOfPosition(start);return{kind:ts.SyntaxKind[n.kind],startUtf16:start,endUtf16:end,startUtf8:Buffer.byteLength(text.slice(0,start)),endUtf8:Buffer.byteLength(text.slice(0,end)),line:lc.line+1,column:lc.character+1,text:n.getText(source),textSha256:hash(n.getText(source))};};
 const diagnostics=[];
 auditDynamicCodeExecution({ts,source,lexical,runtimeNodes,typeOnly:lexical.erased,literal,isLoader,isBuiltinGetter,isGlobal,isDeclarationName:lexical.isDeclarationName,loaderDiagnostic:(n,reason)=>diagnostics.push({reason,...span(n)})});
 const keys=new Map();
 const keyId=k=>{if(!k)return null;if(!keys.has(k))keys.set(k,keys.size+1);return keys.get(k);};
 const lexicalReferences=all.filter(n=>ts.isIdentifier(n)&&['__copyProps','__toCommonJS','__export','__getOwnPropDesc','__defProp','int_common_exports','from','desc'].includes(n.text)).filter(n=>!(ts.isPropertyAccessExpression(n.parent)&&n.parent.name===n)).map(n=>({name:n.text,bindingId:keyId(lexical.identity(n)),declarationName:lexical.isDeclarationName(n),...span(n),declarations:(lexical.identity(n)?.declarations||[]).map(span)}));
 const calls=all.filter(ts.isCallExpression).map(n=>({callee:n.expression.getText(source),calleeBindingId:ts.isIdentifier(n.expression)?keyId(lexical.identity(n.expression)):null,arguments:n.arguments.map(span),...span(n)}));
 return{sourceSha256:hash(text),parser:ts.version,parseErrors:source.parseDiagnostics.map(d=>({start:d.start,message:ts.flattenDiagnosticMessageText(d.messageText,' ')})),unavailable,diagnostics,lexicalReferences,calls,nodeCount:all.length};
}
const selected='node_modules/drizzle-orm/pg-core/columns/int.common.cjs';
const realText=fs.readFileSync(path.join(root,selected),'utf8');
const start=performance.now();
const real=analyze(selected,realText);
const selectedRows=baseline.diagnostics.flatMap((row,index)=>row.file===selected+':14'?[{diagnosticIndexZeroBased:index,diagnosticIndexOneBased:index+1,row,rowCanonicalSortedSha256:hash(canonical(row))}]:[]);
const fixture=`var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all) __defProp(target, name, {get: all[name], enumerable: true});
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, {get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable});
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", {value: true}), mod);
var int_common_exports = {};
__export(int_common_exports, {PgIntColumnBaseBuilder: () => PgIntColumnBaseBuilder});
module.exports = __toCommonJS(int_common_exports);
class PgIntColumnBaseBuilder {}
`;
const minimal=analyze('minimal-fixture.cjs',fixture);
const cases=[
 ['descriptor own literal metadata','characterization','const data={value:1};const d=Object.getOwnPropertyDescriptor(data,"value");export const flag=!!d&&d.enumerable;'],
 ['prototype boolean comparator','characterization','function plain(value){const p=Object.getPrototypeOf(value);return p===Object.prototype||p===null;}'],
 ['direct evaluator','negative','eval('+JSON.stringify('require("products/shift-assistant/src/main.ts")')+')'],
 ['Function literal','negative','Function('+JSON.stringify('return import("products/shift-assistant/src/main.ts")')+')()'],
 ['descriptor value invocation','negative','const d=Object.getOwnPropertyDescriptor({x:Function},"x");d.value("return 1")()'],
 ['descriptor getter invocation','negative','const d=Object.getOwnPropertyDescriptor({get x(){return Function}},"x");d.get()("return 1")()'],
 ['reflect construct','negative','Reflect.construct(Function,["return 1"])()'],
 ['constructor chain','negative','(()=>{}).constructor("return 1")()'],
 ['prototype recovery','negative','Object.getPrototypeOf(()=>{}).constructor("return 1")()'],
 ['executor alias bind','negative','const F=Function.bind(null);F("return 1")()'],
 ['worker sink','negative','const {Worker:Start}=require("node:worker_threads");new Start("products/shift-assistant/src/main.ts")'],
 ['process sink','negative','const {execFileSync:run}=require("node:child_process");run("node",["products/shift-assistant/src/main.ts"])'],
 ['vm sink','negative','import {runInThisContext as run} from "node:vm";run("1")'],
 ['descriptor exported','negative','export const d=Object.getOwnPropertyDescriptor({x:Function},"x")'],
 ['metadata computed key invokes capability','negative','const d=Object.getOwnPropertyDescriptor({x:1},"x");d[Function("return 1")()]'],
 ['descriptor transferred','negative','const d=Object.getOwnPropertyDescriptor({x:Function},"x");consume(d)'],
 ['descriptor metadata reassigned callable','negative','const d=Object.getOwnPropertyDescriptor({x:1},"x");d.enumerable=Function;d.enumerable("return 1")()'],
 ['shadowed Object','unknown-preservation','function inspect(Object,data){const d=Object.getOwnPropertyDescriptor(data,"x");return d.enumerable;}'],
 ['mutated intrinsic alias','negative','var get=Object.getOwnPropertyDescriptor;get=Function;get("return 1")()'],
 ['Proxy source callbacks','unknown-preservation','const data=new Proxy({x:1},{getOwnPropertyDescriptor(){eval("1");return {value:1,enumerable:true,configurable:true}}});const d=Object.getOwnPropertyDescriptor(data,"x");d.enumerable;'],
 ['unknown helper incoming','characterization','var get=Object.getOwnPropertyDescriptor;function inspect(from,key){const d=get(from,key);return !!d&&d.enumerable;}inspect(external,"x");'],
 ['literal constructor scalar existing positive','positive','const data={constructor:"label"};export const value=data.constructor;'],
 ['Function metadata existing positive','positive','export const value=Function.name;'],
 ['neutral keys existing positive','positive','export const value=Object.keys({x:1});']
];
const controls=cases.map(([name,expectation,text])=>{const r=analyze('control.mts',text,false);return{name,expectation,text,sha256:hash(text),parseErrors:r.parseErrors,unavailable:r.unavailable,diagnostics:r.diagnostics,baselineExpectationMet:expectation==='negative'?r.diagnostics.length>0:expectation==='positive'?r.diagnostics.length===0:null,proposedRuleExpectation:expectation==='negative'?'RETAIN_FLAG':expectation==='unknown-preservation'?'NO_INERT_PROOF':expectation==='positive'?'REMAIN_UNFLAGGED':'ONLY_EXACT_PROOF_MAY_CHANGE',proposedRuleExecuted:false};});
const durationMs=performance.now()-start;
const reproducedRows=real.diagnostics.filter(d=>d.line===14);
const comparison={historicalRows:selectedRows.length,reproducedRows:reproducedRows.length,sameMultiset:selectedRows.length===reproducedRows.length&&reproducedRows.every(d=>d.reason==='UNVERIFIED_DYNAMIC_CODE_EXECUTION'),historicalTokenCorrespondence:'UNAVAILABLE; no mapping of duplicate ordinal to fresh token asserted',newOccurrenceIdentity:'SourceR25 dynamic analyzer/binder replay with exact UTF-16/UTF-8 offsets; tooling predicates sufficient for this selected helper; fullCLI not run'};
const after=inventory();
const drift=before.flatMap((p,i)=>p.sha256===after[i].sha256&&p.realpath===after[i].realpath&&p.bytes===after[i].bytes?[]:[{before:p,after:after[i]}]);
const write=(name,data)=>fs.writeFileSync(path.join(out,name),typeof data==='string'?data:JSON.stringify(data,null,2)+'\n',{flag:'wx'});
write('group-map.json',groupMap);
write('minimal-fixture.txt',fixture);
write('ast-reproduction.json',{createdAt:new Date().toISOString(),runtime:{node:process.version,execPath:process.execPath,parser:ts.version},scope:'Original dynamic analyzer and lexical binder only; TS is parser tooling, no installed runtime payload import, no child process, no CLI, no suite',selected,selectedRows,comparison,real,minimal,durationMs,payloadsExecuted:0,diagnosticsSuppressed:0});
write('controls.json',{kind:'STATIC_AST_CHARACTERIZATION_ONLY',count:controls.length,baselineMismatches:controls.filter(c=>c.baselineExpectationMet===false).map(c=>c.name),cases:controls,payloadsExecuted:0,proposedAnalyzerImplemented:false});
write('read-set-integrity.json',{before,after,drift,scope:'Only the declared read set, not a complete candidate inventory or historical hardlink attestation'});
console.log(JSON.stringify({total:groupMap.total,reasons:groupMap.reasonCounts,selectedRows,comparison,reproduced:reproducedRows,minimalDiagnostics:minimal.diagnostics,controls:controls.length,baselineMismatches:controls.filter(c=>c.baselineExpectationMet===false).map(c=>c.name),durationMs,drift},null,2));
