import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
const base='/home/ricardo/.cache/cvg-harness-green-20261004';
const root=path.join(base,'candidate-final-r25');
const out=path.dirname(fileURLToPath(import.meta.url));
if(process.execPath!=='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node')throw Error('Node22 required');
const ts=createRequire(path.join(root,'scripts/check-product-boundary.mjs'))('typescript');
const hash=s=>createHash('sha256').update(s).digest('hex');
const rows=JSON.parse(fs.readFileSync(path.join(base,'c1-nonbinding-label-r22/output/r22-label-installed.log'),'utf8')).diagnostics;
const files=new Map();
for(const [index,row] of rows.entries()){
 if(row.reason!=='UNVERIFIED_DYNAMIC_CODE_EXECUTION'||!row.file.startsWith('node_modules/drizzle-orm/'))continue;
 const m=/^(.*):(\d+)$/.exec(row.file);if(!m)continue;
 if(!files.has(m[1])){
  const filename=path.join(root,m[1]),bytes=fs.readFileSync(filename),text=bytes.toString('utf8');
  files.set(m[1],{file:m[1],filename,text,sha256:hash(bytes),lines:text.split(/\r?\n/),rows:[]});
 }
 const f=files.get(m[1]),line=Number(m[2]);
 if(f.lines[line-1].includes('__getOwnPropDesc(from, key)')&&f.lines[line-1].includes('desc.enumerable'))f.rows.push({diagnosticIndexZeroBased:index,diagnosticIndexOneBased:index+1,row,line});
}
const matches=[];
for(const f of files.values()){
 if(!f.rows.length)continue;
 const source=ts.createSourceFile(f.file,f.text,ts.ScriptTarget.Latest,true),nodes=[];
 const visit=n=>{nodes.push(n);ts.forEachChild(n,visit);};visit(source);
 const spans=nodes.filter(n=>ts.isCallExpression(n)&&n.expression.getText(source)==='__getOwnPropDesc'&&n.arguments.length===2&&n.arguments[0].getText(source)==='from'&&n.arguments[1].getText(source)==='key').map(n=>({startUtf16:n.getStart(source),endUtf16:n.getEnd(),line:source.getLineAndCharacterOfPosition(n.getStart(source)).line+1,text:n.getText(source),textSha256:hash(n.getText(source))}));
 matches.push({file:f.file,sha256:f.sha256,bytes:Buffer.byteLength(f.text),rows:f.rows,syntaxOnlyCandidateCalls:spans,parseDiagnosticCount:source.parseDiagnostics.length,afterSha256:hash(fs.readFileSync(f.filename)),callerReceiverIntrinsicProof:'NOT_ADJUDICATED'});
}
const artifact={scope:'Text pattern matched on current diagnosed lines, then AST CallExpression confirmed. Candidate inventory only; no lexical or caller summary acceptance for the 67 files.',node:process.version,files:matches.length,rows:matches.reduce((n,f)=>n+f.rows.length,0),matches,drift:matches.filter(f=>f.sha256!==f.afterSha256).map(f=>f.file),diagnosticsSuppressed:0};
fs.writeFileSync(path.join(out,'candidate-pattern-inventory.json'),JSON.stringify(artifact,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({files:artifact.files,rows:artifact.rows,drift:artifact.drift,parseErrors:matches.filter(f=>f.parseDiagnosticCount).map(f=>f.file)}));
