# R39 — próxima correção finita da closure instalada

`INSTALLED_CLOSURE_NEXT_CORRECTION_R39`; diagnóstico READONLY, sem descendentes. Fonte: `/home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r25`. Estado da entrega: diagnóstico/reprodução/proposta concluídos; **closure INCOMPLETE, nenhum diagnóstico aceito ou suprimido, produção NO_GO**. A proposta não foi implementada nem recebeu revisão independente.

A lacuna mecânica reproduzida é a promoção incondicional do resultado de reflexão a executor. O próximo caso real recomendado é `node_modules/drizzle-orm/pg-core/columns/int.common.cjs:14`: o helper consulta um descriptor de um objeto de exports criado por literal e usa somente sua existência e `enumerable`. O caller local e os três spans foram recuperados pela reprodução do analisador original. Isso permite propor uma prova estreita de metadata; não permite tratar reflexão, objetos desconhecidos ou todo o pacote Drizzle como seguros.

## Baseline e maiores grupos

O JSON completo dentro de `c1-nonbinding-label-r22/output/r22-label-installed.log` foi relido e recontado: **8.882 diagnósticos, 1.334 arquivos distintos, zero violations, status INCOMPLETE, passed=false**. O summary registra zero indisponibilidades lexicais. Não houve nova execução da CLI. SHA-256 do log: `ea1083becf459d98b65f4baf54c806e97b96c9c29e9533d30aa95790570cace0`.

| Código | Registros |
| --- | ---: |
| UNVERIFIED_DYNAMIC_CODE_EXECUTION | 6.802 |
| UNVERIFIED_INSTALLED_DEPENDENCY | 1.196 |
| UNVERIFIED_MODULE_LOADER_ESCAPE | 404 |
| UNVERIFIED_MODULE_LOADER_PROPERTY | 217 |
| UNRESOLVED_MODULE_REFERENCE | 85 |
| NON_LITERAL_MODULE_REFERENCE | 70 |
| UNVERIFIED_PROCESS_CAPABILITY_PROPERTY | 50 |
| Demais oito códigos, preservados em group-map.json | 58 |

| Grupo físico por pathname do diagnóstico | Total | Execução dinâmica |
| --- | ---: | ---: |
| playwright-core | 1.417 | 1.351 |
| decimal.js | 1.072 | 1.072 |
| @typescript-eslint/eslint-plugin | 553 | 493 |
| playwright | 535 | ver group-map.json |
| zod | 493 | ver group-map.json |
| jsdom | 478 | ver group-map.json |
| axe-core | 264 | ver group-map.json |
| drizzle-orm | 261 | 227 |
| vite | 213 | ver group-map.json |
| @typescript-eslint/typescript-estree | 155 | 140 |

Esse agrupamento é por arquivo/pacote aparente, não por módulo resolvido/contexto transitivo. `group-map.json` preserva o mapa completo de códigos, grupos e arquivos. Decimal domina os dois maiores arquivos individuais: 536 registros em cada entry CJS/ESM; depois vêm axe.js (256), expectBundleImpl.js (219), babelBundleImpl.js (136), utilsBundleImpl/index.js (127) e Vite node.js (121).

O plano anterior `installed-frontier-plan-r22/output/diagnostic.json` tem **2.809** registros e nasceu em R19, com substituições estáticas/in-process; seu method declara que não executou o checker exato. Ele não é a baseline instalada atual. Seus hashes históricos de checker/binder também não identificam os bytes atuais. R26 continua sendo proposta por linha de 222 registros: 140 finitos/82 desconhecidos. R29 continua sendo proposta por linha de 1.072 registros: 16 constructor/732 data/324 desconhecidos. Nada foi convertido em recibo de supressão.

## Caso escolhido e identidade nova

Arquivo real SHA-256: `af4544248c85962a82ff420efedfdcba3ac1655ef4dad7d35f1b801af05041fa`. Os bytes desse arquivo e dos cinco módulos do checker são iguais entre R22 e Source R25; hashes completos em `read-set-integrity.json`.

```js
__defProp(to, key, {
  get: () => from[key],
  enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
});
```

Três linhas históricas idênticas: índices **8872–8874, zero-based**, ou 8873–8875, one-based. SHA-256 de cada row em JSON compacto com chaves ordenadas: `2b412a7691cac2f9e43f4d16dc37767856fd751b333807e6b0b711e83b9e97c6`. Esse hash sozinho não diferencia duplicatas; índice + hash do log preservam a identidade do registro.

Reprodução AST com Source R25, TypeScript 6.0.3 e binder/analisador originais:

| AST emitida agora | UTF-16 zero-based, fim exclusivo | Coluna one-based |
| --- | --- | ---: |
| Identifier `desc`, destino da atribuição | [628, 632) | 66 |
| CallExpression `__getOwnPropDesc(from, key)` | [635, 662) | 73 |
| PropertyAccessExpression `desc.enumerable` | [667, 682) | 105 |

Esses spans também coincidem com os offsets UTF-8 neste trecho ASCII. A reprodução tem exatamente três flags do mesmo código/linha. **A ordem das duplicatas históricas não foi atribuída aos tokens novos.** O log antigo não contém essa prova. O próximo checker terá de emitir identidade própria por ocorrência.

`minimal-fixture.txt` preserva os helpers, o objeto de exports e o caller; substitui a classe de domínio por uma classe vazia. Foi somente parseado, nunca executado. Reproduz os mesmos três tipos de flags em offsets próprios. `ast-reproduction.json` contém spans, hashes do texto, declarations e referências lexicais.

O grafo local observado é:

1. `int_common_exports = {}` cria um objeto próprio, sem Proxy.
2. `__export(int_common_exports, { PgIntColumnBaseBuilder: () => PgIntColumnBaseBuilder })` define um getter próprio com `enumerable: true`; não chama esse getter.
3. `__toCommonJS(int_common_exports)` é o único caller direto dessa binding. Ele passa `mod` ao único caller de `__copyProps`.
4. `__copyProps` recebe `from` desse objeto; `key` vem de `__getOwnPropNames(from)`. O quarto argumento `desc` não é fornecido. A consulta obtém o descriptor; a expressão consulta existência e `enumerable` para construir outro descriptor.
5. Os getters copiados permanecem arestas callable para análise posterior. `require("../../entity.cjs")`, `require("./common.cjs")`, a classe derivada e os exports continuam na AST/closure; não são eliminados por esta prova de metadata.

## Correção mínima proposta

Mecanismo atual em `scripts/boundary-code-execution.mjs`: linhas 271–274 classificam a seleção reflexiva como executor; linha 291 classifica qualquer retorno de chamada a executor como executor; linhas 371–393 propagam isso para `desc`; a emissão nas linhas 431–505 relata atribuição, chamada e metadata. O arquivo não distingue um descriptor próprio de uma função capaz de executar código.

Propor um resumo **local e condicionado** de `Object.getOwnPropertyDescriptor`: resultado `undefined | own descriptor record`, cujos campos `enumerable/configurable` são booleans. Começar somente com `enumerable`, existência e esta forma de expressão. Não remover métodos do conjunto `reflection` nem retornar undefined para todas as suas chamadas. `value/get/set`, constructor recovery e escapes mantêm análise de capacidades/desconhecidos.

Antes de emitir prova positiva, o analisador precisa verificar:

- identidade lexical real do intrinsic/alias; nenhum shadow, reassignment, write por padrão/desestruturação, mutation ou escape que invalide a binding;
- grafo de todos os callers lexicais do helper fechado, com parâmetros ligados aos argumentos efetivos; nenhum caller externo, alias de função, export ou uso não suportado;
- receptor próprio criado por literal, acompanhado até o snapshot, com mutadores conhecidos (`defineProperty` neste caso); sem Proxy, getter/trap externo, spread desconhecido ou escape anterior;
- chave scalar e origem concreta; descriptor sem escrita/escape e consumidores limitados à existência e ao campo booleano explicitamente conhecido;
- prova ligada a source/manifest/checker/parser/caller/context hashes e spans dos nós originais. Budget/depth exhaustion, binding indisponível ou branch não coberto retorna UNKNOWN;
- cada AST filha continua visitada: condição, chave, argumento, getter, setter, callback e sibling sink. O resumo não substitui o walker nem corta transitiveclosure.

**Limite material:** a evidência local não prova que outro módulo executado antes deste arquivo não alterou os intrinsics. Spelling global + ausência de escrita neste arquivo não bastam para uma garantia absoluta. A futura prova deve explicitar o perfil confiável de intrinsics já admitido pelo checker ou demonstrar sua estabilidade no contexto de entrada; se isso não estiver estabelecido, conservar o diagnóstico. Proxies externos também não recebem dispensa porque `enumerable` parece scalar. A claim é de ausência de aquisição de capacidade nesta rota, não de sandbox geral nem ausência de toda ação do domínio.

Uma correção anterior/adjacente pequena é emitir identidade por ocorrência em `scripts/check-product-boundary.mjs:1053`: arquivo físico/hash, reason, syntaxKind, start/end UTF-16, coluna, perfil e identificador estável; preservar file/reason existentes. Conferir compatibilidade do schema/report antes de integrar. Isso prepara provas novas; não recria offsets históricos nem suprime flags por si só. O binder atual é reutilizado; não criar resolução por nome textual.

## Controles e custo

Foram parseados **24 controles** pelo analisador original: 16 negativos, três positivos preexistentes, três caracterizações e dois casos de preservação de unknown. Zero divergências nas expectativas negativas/positivas; nenhum payload executado. O caso com `Object` shadowed tem zero flags atuais: isso não concede uma prova nova, e o resumo proposto deve recusá-lo.

Mais **12 mutações AST** da reprodução real preservam flags atuais: caller externo, Proxy, caller adicional, helper escape, descriptor escape, `value()`/`get()`, intrinsic sobrescrito, alias reatribuído, objeto escapando antes do snapshot, campo metadata convertido em Function e eval independente. `proposal-controls.json` especifica por que a futura regra deve recusar cada prova. A regra proposta não foi implementada; esses controles não são um resultado de regressão dela. Não foi executada testsuite nem CLI.

`candidate-pattern-inventory.json` encontra a mesma chamada AST em **67 arquivos/201 registros** do Drizzle, todos sem erro sintático e sem drift no read set. É inventário de candidatos: não adjudica caller/receiver/intrinsics desses 67 arquivos. O delta imediato plausível é de três registros no caso escolhido, **condicionado à prova e revisão futuras**; delta observado nesta rodada é zero.

Custo observado do replay real + minimal + 24 controles válidos: cerca de **79,6 ms dentro da etapa AST**, além da inicialização do tooling. Instrumentação de emissão tem superfície pequena; resumo contextual exige índices de bindings/referências/callers e um fixed point finito por arquivo. Preferir cache por binding/contexto e índices construídos uma vez; evitar scan de toda AST por referência. Não há benchmark de throughput do checker futuro. A CLI histórica levou 13 min 46,6 s e não foi repetida. A extensão a minificados, compilers, Decimal e demais pacotes tem custo/provas próprios.

A checagem final recusou o primeiro ensaio de controles porque dois textos tinham aspas malformadas. Esse ensaio está preservado em `initial-parse-invalid/`, explicitamente rejeitado. Os textos foram corrigidos e só a rodada AST curta foi repetida. Os artefatos atuais têm zero erros sintáticos; a reprodução do arquivo real não mudou.

## Próxima execução autorizável e prova para gate completo

Paths de implementação sugeridos: `scripts/boundary-code-execution.mjs` e callback de emissão em `scripts/check-product-boundary.mjs`; controles futuros em `tests/product-boundary-code-execution.test.js` e `tests/product-boundary-lexical-static.test.js`. `boundary-lexical.mjs`, `boundary-manifests.mjs` e `tsconfig-path-grammar.mjs` permanecem inputs hash-bound; só alterar o binder se nova reprodução exigir. Nenhum desses paths foi escrito nesta lane.

Próximo passo: Lead congela a reprodução/contrato curto e implementa o menor resumo em candidata própria, exige a prova completa do caller escolhido e os controles, depois obtém crítico novo. A posterior CLI instalada precisa produzir tokens e closure completos no candidato final. O gate integral ainda exige tratar as 1.196 dependências instaladas e seus destinos físicos/contextos, preservar os unknowns restantes, resolver loaders/nonliteral/format/proxies/public receivers/generators concretos, rever SCC/transitiveclosure e obter aceites hash-bound. Nem três nem 201 metadata flags fecham esse gate.

Sentinelas desta rodada: 30 inputs principais sem drift, 67 candidatos do inventário sem drift; ver artefatos JSON para paths/hashes. Essas sentinelas não certificam toda a árvore não lida ou a topologia histórica de hardlinks. Fonte/Root/env/provider/DB/Docker/rede/npm/history não foram escritos; parser TypeScript foi carregado somente como ferramenta AST. Apenas este diretório recebeu arquivos. Continuidade para o Lead fica em findings.json; ledgers compartilhados não foram alterados por restrição explícita do usuário. Sem aceite de closure, HISO-005 ou release.
