import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {createBoundaryLexical} from '../../candidate-final-r25/scripts/boundary-lexical.mjs';
import {auditDynamicCodeExecution} from '../../candidate-final-r25/scripts/boundary-code-execution.mjs';
const out=path.dirname(fileURLToPath(import.meta.url));
const root='/home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r25';
if(process.execPath!=='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node')throw Error('Node22 required');
const ts=createRequire(path.join(root,'scripts/check-product-boundary.mjs'))('typescript');
const fixture=fs.readFileSync(path.join(out,'minimal-fixture.txt'),'utf8');
const cases=[
 ['unknown incoming receiver',fixture.replace('__toCommonJS(int_common_exports)','__toCommonJS(external)'), 'Receiver must lack own-literal proof'],
 ['Proxy incoming receiver',fixture.replace('var int_common_exports = {};','var int_common_exports = new Proxy({}, unknownTraps);'),'Receiver may execute getOwnPropertyDescriptor/ownKeys traps'],
 ['extra helper caller',fixture+'\n__copyProps({}, external);','All lexical callers must be covered; one unknown joins UNKNOWN'],
 ['helper escape',fixture+'\nconsume(__copyProps);','No closed incoming call graph after helper escape'],
 ['descriptor escape',fixture.replace('return to;','consume(desc); return to;'),'Descriptor cannot be summarized when passed to unknown consumer'],
 ['descriptor value call',fixture.replace('return to;','desc.value("return 1")(); return to;'),'Value may be an executor'],
 ['descriptor getter call',fixture.replace('return to;','desc.get(); return to;'),'Getter is callable even when enumerable is scalar'],
 ['intrinsic method overwrite',fixture.replace('var __getOwnPropDesc', 'Object.getOwnPropertyDescriptor = Function;\nvar __getOwnPropDesc'),'Lexical global spelling does not prove an unchanged intrinsic'],
 ['reflect alias reassignment',fixture.replace('var __copyProps', '__getOwnPropDesc = Function;\nvar __copyProps'),'var alias stability must include all writes'],
 ['object escapes before snapshot',fixture.replace('__export(int_common_exports', 'mutate(int_common_exports);\n__export(int_common_exports'),'Earlier object escape invalidates own receiver proof'],
 ['descriptor field write',fixture.replace('return to;','desc.enumerable = Function; desc.enumerable("return 1")(); return to;'),'Scalar field fact is invalidated by writes'],
 ['separate sink beside metadata',fixture+'\neval("1");','Metadata summary must not hide independent sibling sinks']
];
const results=cases.map(([name,text,mustRejectProofBecause])=>{
 const source=ts.createSourceFile('proposal-control.cjs',text,ts.ScriptTarget.Latest,true),nodes=[];
 const visit=n=>{nodes.push(n);ts.forEachChild(n,visit);};visit(source);
 const lexical=createBoundaryLexical(ts,source,true);
 const literal=n=>n&&ts.isStringLiteralLike(n)?n.text:undefined;
 const isLoader=n=>n&&ts.isIdentifier(n)&&lexical.identity(n)===lexical.global('require');
 const diagnostics=[];
 auditDynamicCodeExecution({ts,source,lexical,runtimeNodes:nodes.filter(n=>!lexical.erased(n)),typeOnly:lexical.erased,literal,isLoader,isBuiltinGetter:()=>false,isGlobal:n=>n&&ts.isIdentifier(n)&&['global','globalThis'].some(k=>lexical.identity(n)===lexical.global(k)),isDeclarationName:lexical.isDeclarationName,loaderDiagnostic:(n,reason)=>diagnostics.push({reason,kind:ts.SyntaxKind[n.kind],startUtf16:n.getStart(source),endUtf16:n.getEnd(),text:n.getText(source)})});
 return{name,text,textSha256:createHash('sha256').update(text).digest('hex'),mustRejectProofBecause,parseErrors:source.parseDiagnostics.length,baselineFlags:diagnostics.length,diagnostics,proposedProofStatus:'MUST_REFUSE_INERT_PROOF; NOT_IMPLEMENTED_NOT_EXECUTED'};
});
fs.writeFileSync(path.join(out,'proposal-controls.json'),JSON.stringify({scope:'Mutations of the real helper reproduction, parsed only through original analyzer. Future proof obligations; no proposed summary was run.',node:process.version,count:results.length,results,payloadsExecuted:0},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({count:results.length,parseErrors:results.filter(r=>r.parseErrors).map(r=>r.name),baselineFlags:results.map(r=>({name:r.name,count:r.baselineFlags})),proposedRuleExecuted:false}));
