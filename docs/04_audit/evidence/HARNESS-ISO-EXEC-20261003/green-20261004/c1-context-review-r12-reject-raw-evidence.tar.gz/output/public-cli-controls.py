import pathlib,subprocess,json
p=pathlib.Path(__file__).resolve().parent;b=p.parent;n='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node';rows=[]
for case,expected in [('reached-mts-array',0),('workspace-mts-array',2),('opaque-mts-array',0)]:
 args=['strace','-ff','-qq','-e','trace=network','-o',str(p/(case+'.network')),'python3',str(p/'guard.py'),n,str(p/'runtime/scripts/check-product-boundary.mjs'),str(p/'actor-controls'/case)]
 r=subprocess.run(args,cwd=b,capture_output=True,text=True,timeout=60)
 (p/(case+'-cli.log')).write_text(r.stdout+r.stderr)
 rows.append({'id':case,'argv':args,'cwd':str(b),'exitCode':r.returncode,'expectedExitCode':expected,'matches':r.returncode==expected,'stdout':r.stdout,'stderr':r.stderr,'fixturesExecuted':False})
 assert r.returncode==expected
(p/'public-cli-controls.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps([{'id':x['id'],'exitCode':x['exitCode']} for x in rows]))
