import pathlib,os,json,hashlib,math
p=pathlib.Path(__file__).resolve().parent
entries={};bad=[];own_json=0
for d,ds,ns in os.walk(p,followlinks=False):
 for n in ns:
  f=pathlib.Path(d)/n;rel=f.relative_to(p).as_posix()
  if rel in ['artifact-sha256.json','artifact-sha256.sha256']:continue
  if f.is_symlink():entries[rel]={'kind':'link','target':os.readlink(f)};continue
  b=f.read_bytes();entries[rel]={'kind':'file','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
  # Opaque copied Source JSON includes historical machine material; never parse.
  if f.suffix=='.json' and not rel.startswith('runtime/'):
   try:json.loads(b,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)));own_json+=1
   except Exception as e:bad.append({'path':rel,'error':str(e)})
assert not bad,bad
record={'algorithm':'sha256','manifestSelfHash':'artifact-sha256.sha256','excludedSelfReference':['artifact-sha256.json','artifact-sha256.sha256'],'files':entries,'count':len(entries),'ownFiniteJSONValidated':own_json,'copiedSourceJSON':'Opaque hashes only; no prohibited source/history/test payload reads.'}
f=p/'artifact-sha256.json';f.write_text(json.dumps(record,sort_keys=True,indent=2)+'\n');h=hashlib.sha256(f.read_bytes()).hexdigest();(p/'artifact-sha256.sha256').write_text(h+'  artifact-sha256.json\n')
r=json.loads((p/'report.json').read_text());assert r['verdict']=='REJECT' and r['sourceInventoryEntries']==19383
proof=json.loads((p/'preservation-proof.json').read_text());assert proof['inventoryEqual'] and proof['metadataEqual']
assert not json.loads((p/'no-egress-proof.json').read_text())['nonDeniedNetworkCalls']
assert all(x['equal'] for x in json.loads((p/'reviewed-copy-hashes.json').read_text()))
for k in ['report.json','report.md','native-static-vitest.json','native-discriminants.json','native-actor-controls.json','public-cli-controls.json','pre-inventory.json','post-inventory.json','pre-metadata.json','post-metadata.json']:
 assert k in entries and entries[k]['bytes']>0
print(json.dumps({'sealedArtifacts':len(entries),'finiteOwnJSON':own_json,'manifestSha256':h,'reportJsonSha256':entries['report.json']['sha256'],'reportMdSha256':entries['report.md']['sha256'],'verdict':r['verdict']}))
