import ctypes,ctypes.util,os,sys
lib=ctypes.CDLL(ctypes.util.find_library('seccomp'),use_errno=True)
lib.seccomp_init.argtypes=[ctypes.c_uint32];lib.seccomp_init.restype=ctypes.c_void_p
lib.seccomp_rule_add.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_int,ctypes.c_uint]
lib.seccomp_syscall_resolve_name.argtypes=[ctypes.c_char_p];lib.seccomp_syscall_resolve_name.restype=ctypes.c_int
lib.seccomp_load.argtypes=[ctypes.c_void_p]
ctx=lib.seccomp_init(0x7fff0000)
for name in ['socket','connect','bind','listen','accept','accept4','sendto','sendmsg','sendmmsg','recvfrom','recvmsg','recvmmsg']:
 nr=lib.seccomp_syscall_resolve_name(name.encode()); assert nr>=0
 assert lib.seccomp_rule_add(ctx,0x00050000|1,nr,0)==0
assert lib.seccomp_load(ctx)==0
os.execv(sys.argv[1],sys.argv[1:])
