import os,json,hashlib,pathlib,stat,sys
base=pathlib.Path(__file__).resolve().parent.parent
root=base/'source'; expected=json.loads((base/'frozen-inventory.json').read_text())
items={}; meta={}
for directory,dirs,names in os.walk(root,followlinks=False):
 for name in ['.']+dirs+names:
  p=pathlib.Path(directory) if name=='.' else pathlib.Path(directory)/name
  r=p.relative_to(root).as_posix(); s=p.lstat()
  meta[r]={'mode':s.st_mode,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'inode':s.st_ino,'dev':s.st_dev,'uid':s.st_uid,'gid':s.st_gid}
  if stat.S_ISLNK(s.st_mode): items[r]={'kind':'link','target':os.readlink(p)}
  elif stat.S_ISREG(s.st_mode): items[r]={'kind':'file','bytes':s.st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
missing=sorted(set(expected)-set(items)); extra=sorted(set(items)-set(expected)); changed=[k for k in expected.keys()&items.keys() if expected[k]!=items[k]]
label=sys.argv[1]
(base/'output'/f'{label}-inventory.json').write_text(json.dumps(items,sort_keys=True,indent=2)+'\n')
(base/'output'/f'{label}-metadata.json').write_text(json.dumps(meta,sort_keys=True,indent=2)+'\n')
result={'entries':len(items),'expected':len(expected),'missing':missing,'extra':extra,'changed':changed,'metadataEntries':len(meta),'freezeSha256':hashlib.sha256((base/'freeze.json').read_bytes()).hexdigest(),'frozenInventorySha256':hashlib.sha256((base/'frozen-inventory.json').read_bytes()).hexdigest()}
(base/'output'/f'{label}-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));assert not missing and not extra and not changed
