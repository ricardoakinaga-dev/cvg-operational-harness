from pathlib import Path
import json,subprocess,os
OUT=Path('/home/ricardo/.cache/cvg-harness-green-20261004/ci-native-summary-fresh-review-r22/output');R=OUT/'runtime';raw=OUT/'raw'
a=[{'id':'git-init','exitCode':0,'stdout':'raw/git-init.stdout','stderr':'raw/git-init.stderr'},{'id':'git-add','exitCode':1,'stdout':'raw/git-add.stdout','stderr':'raw/git-add.stderr','reason':'Explicit paths included files ignored by existing .gitignore; retry uses Git standard ignore selection without changing it.'}]
def run(name,argv):
 p=subprocess.run(argv,cwd=R,capture_output=True);(raw/(name+'.stdout')).write_bytes(p.stdout);(raw/(name+'.stderr')).write_bytes(p.stderr)
 a.append({'id':name,'command':argv,'cwd':str(R),'exitCode':p.returncode,'stdout':'raw/'+name+'.stdout','stderr':'raw/'+name+'.stderr'})
 (OUT/'preparation-attempts.json').write_text(json.dumps(a,indent=2)+'\n')
 assert p.returncode==0,p.stderr.decode()
 return p.stdout
paths=run('git-standard-selection',['git','ls-files','--others','--exclude-standard','-z']).decode().split('\0')
paths=[p for p in paths if p]
if paths:run('git-add-standard',['git','add','--',*paths])
run('git-commit',['git','-c','user.name=Independent reviewer','-c','user.email=review@example.invalid','-c','core.hooksPath=/dev/null','commit','-m','Independent physical review inputs'])
head=run('git-head',['git','rev-parse','--verify','HEAD^{commit}']).decode().strip()
cache=R/'node_modules/.vite/review-cache-probe';cache.parent.mkdir(exist_ok=True,parents=True);cache.write_text('mutable review cache\n')
ignore=run('git-cache-ignore',['git','check-ignore','-v','node_modules/.vite/review-cache-probe']).decode().strip()
tracked=run('git-cache-tracked',['git','ls-files','--','node_modules/.vite/review-cache-probe'])
assert not tracked
links=[str(f.relative_to(R)) for f in R.rglob('*') if f.is_symlink()]
assert all((R/p).resolve().is_relative_to(R) for p in links)
S=Path('/home/ricardo/.cache/cvg-harness-green-20261004/candidate-ci-summary-r22')
assert (R/'.gitignore').read_bytes()==(S/'.gitignore').read_bytes()
(OUT/'preparation.json').write_text(json.dumps({'runtime':str(R),'head':head,'gitignoreUnchanged':True,'cacheIgnored':ignore,'cacheTracked':False,'escapingSymlinks':0,'physicalDependencyCopy':True,'attempts':a},indent=2)+'\n')
print(json.dumps({'head':head,'cacheIgnored':ignore,'physicalDependencyCopy':True,'escapingLinks':0}))
