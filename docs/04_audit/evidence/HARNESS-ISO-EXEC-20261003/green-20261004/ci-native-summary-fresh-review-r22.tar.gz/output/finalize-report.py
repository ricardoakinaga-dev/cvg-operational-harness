from pathlib import Path
import json,hashlib,stat,os,ast,subprocess,datetime
P=Path('/home/ricardo/.cache/cvg-harness-green-20261004/ci-native-summary-fresh-review-r22');OUT=P/'output';R=OUT/'runtime'
S=Path('/home/ricardo/.cache/cvg-harness-green-20261004/candidate-ci-summary-r22');O=Path('/home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r19')
# Reuse only the side-effect-free inventory function and its literal path lists.
tree=ast.parse((OUT/'prepare.py').read_text());selected=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='inventory' or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ['ROOTS','LEAVES'] for t in n.targets)]
ctx={'Path':Path,'hashlib':hashlib,'stat':stat,'os':os};exec(compile(ast.Module(body=selected,type_ignores=[]),'inventory-only','exec'),ctx)
before=json.loads((OUT/'inputs-before.json').read_text());after={'source':ctx['inventory'](S),'original':ctx['inventory'](O)}
(OUT/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
mutations={side:[p for p in sorted(set(before[side])|set(after[side])) if before[side].get(p)!=after[side].get(p)] for side in before}
immutability={'fields':['sha256','size','mode','mtimeNs','symlink'],'before':'inputs-before.json','after':'inputs-after.json','sourceInputCount':len(before['source']),'originalInputCount':len(before['original']),'changed':mutations,'pass':not any(mutations.values())}
(OUT/'immutability.json').write_text(json.dumps(immutability,indent=2)+'\n')
p=subprocess.run(['git','status','--porcelain=v1','--untracked-files=all'],cwd=R,capture_output=True)
(OUT/'raw/git-status-after.stdout').write_bytes(p.stdout);(OUT/'raw/git-status-after.stderr').write_bytes(p.stderr)
ind=json.loads((OUT/'independent-results.json').read_text());prep=json.loads((OUT/'preparation.json').read_text());vit=json.loads((OUT/'vitest-attempt.json').read_text())
paths=json.loads((OUT/'raw/path-delta.json').read_text())
expected=['scripts/hiso-baseline-inventory.json','scripts/lib/certification-rules.mjs','tests/certification-summary-ansi-own.test.js','tests/hiso-ci-scopes.test.js']
# Recompute the complete permitted executable/configuration tree delta, including legacy.
logical=[f for f in sorted(set(before['source'])|set(before['original'])) if not f.startswith('node_modules/')]
def contentmode(x):return (x.get('sha256'),x.get('symlink'),x.get('mode')) if x else None
fullDelta=[f for f in logical if contentmode(before['source'].get(f))!=contentmode(before['original'].get(f))]
(OUT/'raw/complete-relevant-path-delta.json').write_text(json.dumps(fullDelta,indent=2)+'\n')
checks=[{'id':'exact-four-path-delta','pass':fullDelta==expected,'detail':fullDelta},*ind['metadata'],{'id':'independent-parser-cases','pass':ind['failed']==0,'detail':{'total':ind['total'],'passed':ind['passed'],'failed':ind['failed']}},{'id':'focused-vitest','pass':vit['exitCode']==0,'detail':{'files':2,'tests':26,'newRegressionCases':23,'coverageGateCases':3}},{'id':'own-git-preparation','pass':prep['gitignoreUnchanged'] and not prep['cacheTracked'] and prep['escapingSymlinks']==0 and len(prep['head'])==40,'detail':{'head':prep['head'],'existingIgnore':prep['cacheIgnored'],'physicalDependencyCopy':True}},{'id':'input-bytes-modes-mtime-preserved','pass':immutability['pass'],'detail':immutability}]
verdict='ACCEPT' if all(c['pass'] for c in checks) else 'REJECT'
report={'schemaVersion':1,'task':'CI_NATIVE_SUMMARY_FRESH_REVIEW_R22','verdict':verdict,'scope':'Exact four-path R22 versus original R19 parser normalization, regression addition, 46-to-47 test inventory and CI assertion; physical local review preparation.','authority':str(P/'authority.json'),'sourceReadonly':str(S),'originalReadonly':str(O),'runtime':str(R),'node':ind['node'],'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'findings':[c for c in checks if not c['pass']],'evidence':{'diff':'raw/four-path.diff','independent':'independent-results.json','caseInputs':'raw/case-inputs/','originalPlainOracle':'original-summary-parser.mjs','testExecution':'vitest-attempt.json','preparation':'preparation.json','immutability':'immutability.json','gitStatusAfter':'raw/git-status-after.stdout'},'rawAttemptsPreserved':True,'preparationRetry':{'initial':'raw/git-add.stderr','result':'Git rejected explicitly named ignored paths. Standard Git selection honored the unchanged existing .gitignore; retry succeeded. No forced addition or new exclusions.'},'limitations':['Finite parser cases and focused tests only; the complete 371-file suite and global certification were not executed.','No global or production approval, provider/PG/network/install or repository changes.','Mutable own output and Vite cache were allowed; they are not additional freeze requirements.','No default-root governance, previous reviews/verdicts or Git history was consulted. Permitted executable/configuration inputs and physical dependencies were compared and snapshotted.'],'collectorUnmodified':True}
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
md=f'''# {verdict} — independent bounded R22 review

Scope: exactly the four candidate paths versus R19: `scripts/lib/certification-rules.mjs`, `tests/certification-summary-ansi-own.test.js`, `scripts/hiso-baseline-inventory.json`, and `tests/hiso-ci-scopes.test.js`. No scoped defects reproduced.

- **214/214 independent parser cases passed** on Node v22.23.2. Complete OSC titles with spaces were tested with both ESC and C1 introducers, BEL/ESC-ST/C1-ST terminators, hyperlinks, embedded summary-looking title text, multiple positions and SGR. First failure followed by later pass retained the failure. Incomplete OSC returned null; missing summaries, plain logs, skipped/zero counts, separate file/test labels, explicit and inferred totals preserved their expected behavior. Fourteen plain cases also matched an exact physical copy of the original parser function.
- **26/26 focused Vitest tests passed**: 23 new regression cases and 3 existing coverage-gate cases, using copied dependencies and one thread worker inside the own physical runtime.
- The **371 original test inventory records and their actual candidate/original file bytes and modes are identical**. Original assertions were preserved except the intended existing new-test inventory assertion changing 46 to 47. The inventory gains exactly the new regression file. Its remaining fields are identical.
- The **281 coverage source paths are unchanged** and independently derived from the original collector/configuration without modifications or extra exclusions. The four-path diff also covers `legacy` and all permitted executable/configuration trees.
- Own Git HEAD is `{prep['head']}`. The copied existing `.gitignore` is byte-identical; `node_modules/.vite/review-cache-probe` is ignored by its existing `node_modules/` rule and is untracked. Dependencies are physical copies with no symlinks escaping the runtime.
- **Source and original inputs preserved bytes, modes and mtime:** {len(before['source'])} source and {len(before['original'])} original relevant files/links compared before/after; zero changes. Snapshots include executable/configuration trees and physical dependencies.

Raw attempts and individual input logs are retained in `raw/`, with structured results in `independent-results.json`, `vitest-attempt.json`, and `preparation.json`. Initial Git staging explicitly named ignored generated files and exited 1; its raw output remains. The successful retry used standard Git selection with the same ignore rules. No implementation was changed.

This ACCEPT applies only to the stated parser/delta/preparation scope. The full original suite, global certification and production release are outside this verdict. Own output/cache remain mutable; no extra freezing requirement is imposed. Source root governance, earlier verdicts/history, descendants, network, PG, provider, private environment files and installation were not used.
'''
(OUT/'report.md').write_text(md)
# Evidence manifest records completed report artifacts, not a freeze requirement on mutable runtime/cache.
artifacts=[]
for f in sorted(OUT.rglob('*')):
 if not f.is_file() or f.is_symlink() or f.is_relative_to(R) or f.name=='manifest.json':continue
 st=f.stat();artifacts.append({'path':str(f.relative_to(OUT)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'size':st.st_size,'mode':stat.S_IMODE(st.st_mode)})
manifest={'schemaVersion':1,'task':report['task'],'verdict':verdict,'authority':{'path':'../authority.json','sha256':hashlib.sha256((P/'authority.json').read_bytes()).hexdigest()},'artifacts':artifacts,'inputSnapshots':['inputs-before.json','inputs-after.json'],'runtime':{'path':'runtime','head':prep['head'],'moduleSha256':hashlib.sha256((R/'scripts/lib/certification-rules.mjs').read_bytes()).hexdigest(),'dependenciesPhysicallyCopied':True},'note':'Hashes describe generated review evidence at completion. Mutable runtime/output/cache are not acceptance freeze requirements.'}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'verdict':verdict,'sourceCount':len(before['source']),'originalCount':len(before['original']),'mutations':mutations,'exactDelta':fullDelta,'checksPassed':sum(c['pass'] for c in checks),'checksTotal':len(checks),'evidenceArtifacts':len(artifacts),'gitStatus':p.stdout.decode()}))
