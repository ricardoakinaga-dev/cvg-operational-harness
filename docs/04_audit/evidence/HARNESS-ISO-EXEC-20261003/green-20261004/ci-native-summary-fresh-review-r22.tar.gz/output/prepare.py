from pathlib import Path
import json,hashlib,stat,shutil,os,subprocess
P=Path('/home/ricardo/.cache/cvg-harness-green-20261004/ci-native-summary-fresh-review-r22')
S=Path('/home/ricardo/.cache/cvg-harness-green-20261004/candidate-ci-summary-r22')
O=Path('/home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r19')
OUT=P/'output'; R=OUT/'runtime'
ROOTS=['scripts','tests','.github','apps','packages','products','config','certification','legacy','node_modules']
LEAVES=['package.json','package-lock.json','.gitignore','.gitattributes','vitest.config.mts','vite.config.mts','tsconfig.json','tsconfig.base.json','tsconfig.typecheck.json','tsconfig.runtime.json','eslint.config.js','.prettierrc.json','.prettierignore']
def inventory(root):
 d={}
 for top in ROOTS+LEAVES:
  p=root/top
  if not p.exists():continue
  paths=[p]+list(p.rglob('*')) if p.is_dir() else [p]
  for f in paths:
   if '.env' in f.name:continue
   st=f.lstat(); rel=str(f.relative_to(root))
   if f.is_symlink():v={'symlink':os.readlink(f)}
   elif f.is_file():v={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'size':st.st_size}
   else:continue
   d[rel]={**v,'mode':stat.S_IMODE(st.st_mode),'mtimeNs':str(st.st_mtime_ns)}
 return d
before={'source':inventory(S),'original':inventory(O)}
(OUT/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
R.mkdir()
for top in ROOTS:
 shutil.copytree(S/top,R/top,symlinks=True,ignore=shutil.ignore_patterns('.env','.env.*'))
for name in LEAVES:
 if (S/name).exists():shutil.copy2(S/name,R/name)
links=[]
for f in R.rglob('*'):
 if not f.is_symlink():continue
 target=os.readlink(f)
 resolved=f.resolve()
 if not resolved.is_relative_to(R):
  src=S/f.relative_to(R)
  original=src.resolve()
  if not original.is_relative_to(S):raise RuntimeError('dependency outside authorized source: '+str(src))
  new=R/original.relative_to(S)
  f.unlink();f.symlink_to(os.path.relpath(new,f.parent));links.append(str(f.relative_to(R)))
for f in R.rglob('*'):
 if f.is_symlink() and not f.resolve().is_relative_to(R):raise RuntimeError('escaping link '+str(f))
raw=OUT/'raw'; attempts=[]
def run(name,argv):
 p=subprocess.run(argv,cwd=R,capture_output=True)
 (raw/(name+'.stdout')).write_bytes(p.stdout);(raw/(name+'.stderr')).write_bytes(p.stderr)
 attempts.append({'id':name,'command':argv,'cwd':str(R),'exitCode':p.returncode,'stdout':'raw/'+name+'.stdout','stderr':'raw/'+name+'.stderr'})
 if p.returncode:raise RuntimeError(name+' failed: '+p.stderr.decode())
 return p.stdout.decode().strip()
run('git-init',['git','init','--initial-branch=review'])
tracked=[str(f.relative_to(R)) for f in R.rglob('*') if f.is_file() and not f.is_symlink() and not str(f.relative_to(R)).startswith(('node_modules/','.git/'))]
# Git's existing .gitignore chooses what is staged; no additional ignore rules.
run('git-add',['git','add','--ignore-errors','--',*tracked])
run('git-commit',['git','-c','user.name=Independent reviewer','-c','user.email=review@example.invalid','-c','core.hooksPath=/dev/null','commit','-m','Independent physical review inputs'])
head=run('git-head',['git','rev-parse','--verify','HEAD^{commit}'])
cache=R/'node_modules/.vite/review-cache-probe';cache.parent.mkdir(exist_ok=True,parents=True);cache.write_text('mutable review cache\n')
ignore=run('git-cache-ignore',['git','check-ignore','-v','node_modules/.vite/review-cache-probe'])
trackedcache=run('git-cache-tracked',['git','ls-files','--','node_modules/.vite/review-cache-probe'])
assert trackedcache==''
assert (R/'.gitignore').read_bytes()==(S/'.gitignore').read_bytes()
(OUT/'preparation.json').write_text(json.dumps({'runtime':str(R),'head':head,'gitignoreUnchanged':True,'cacheIgnored':ignore,'cacheTracked':False,'escapingSymlinks':0,'rewrittenWorkspaceLinks':links,'attempts':attempts},indent=2)+'\n')
print(json.dumps({'copiedRuntime':str(R),'sourceInputs':len(before['source']),'originalInputs':len(before['original']),'head':head,'cacheIgnored':ignore,'rewrittenLinks':links}))
