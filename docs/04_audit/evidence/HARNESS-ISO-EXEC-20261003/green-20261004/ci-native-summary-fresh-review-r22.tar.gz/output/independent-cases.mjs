import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {parseVitestSummary as parse} from './runtime/scripts/lib/certification-rules.mjs';
import {parseVitestSummary as original} from './original-summary-parser.mjs';
import {sourceFiles} from './runtime/scripts/hiso-contract.mjs';
import {coverageInventory} from './runtime/scripts/hiso-inventory.mjs';
const out=path.dirname(fileURLToPath(import.meta.url));
const runtime=path.join(out,'runtime');
fs.mkdirSync(path.join(out,'raw','case-inputs'),{recursive:true});
const cases=[];
function check(id,log,label,expected){
 const input=path.join('raw','case-inputs',id+'.log');fs.writeFileSync(path.join(out,input),log);
 let actual,error;try{actual=parse(log,label);assert.deepEqual(actual,expected);}catch(e){error=e.stack;}
 cases.push({id,input,inputUtf8Base64:Buffer.from(log).toString('base64'),label,expected,actual,pass:!error,...(error?{error}:{})});
}
const fail={passed:3,failed:2,skipped:4,total:9};
const plain=[
 ['', 'Tests',null],['runner without summary\nDone', 'Tests',null],['Test Files 3 passed (3)','Tests',null],
 ['Tests 3 passed | 2 failed | 4 skipped (9)','Tests',fail],
 ['\r\n\tTests 3 passed | 2 failed | 4 skipped\r\n','Tests',fail],
 ['Tests 0 passed (0)','Tests',{passed:0,failed:0,skipped:0,total:0}],
 ['Tests 4 skipped (4)','Tests',{passed:0,failed:0,skipped:4,total:4}],
 ['Test Files 2 passed | 1 failed | 2 skipped (5)\nTests 123 passed (123)','Test Files',{passed:2,failed:1,skipped:2,total:5}],
 ['Tests 3 passed | 2 failed | 4 skipped (20)','Tests',{...fail,total:20}],
 ['Tests 1 passed | 2 passed | 1 skipped','Tests',{passed:3,failed:0,skipped:1,total:4}],
 ['Tests\nTests 900 passed (900)','Tests',{passed:0,failed:0,skipped:0,total:0}],
 ['Tests 1 failed (1)\nTests 900 passed (900)','Tests',{passed:0,failed:1,skipped:0,total:1}],
 ['Tests 2 skipped (2)\nTests 900 passed (900)','Tests',{passed:0,failed:0,skipped:2,total:2}],
 ['Tests 1 passed (1)\nTests 2 failed (2)','Tests',{passed:1,failed:0,skipped:0,total:1}],
];
for(let i=0;i<plain.length;i++){const [log,label,expected]=plain[i];assert.deepEqual(original(log,label),expected);check(`plain-${i}`,log,label,expected);}
const starts=[['esc','\x1b]'],['c1','\x9d']];
const ends=[['bel','\x07'],['st','\x1b\\'],['c1st','\x9c']];
const titles=['0;Vitest runner title with multiple spaces','2;title\nTests 888 passed (888)\n hidden summary','8;;https://example.invalid/a path with spaces','0;','0;ANSI \x1b[31m title'];
for(const [sn,start] of starts)for(const [en,end]of ends)for(let ti=0;ti<titles.length;ti++){
 const osc=start+titles[ti]+end;
 const variants=[`${osc}Tests 3 passed | 2 failed | 4 skipped (9)`,
 `Te${osc}sts 3 passed | 2 failed | 4 skipped (9)`,
 `Tests 3 pa${osc}ssed | 2 failed | 4 skipped (9)`,
 `Tests 3 passed | 2 failed | 4 skipped ${osc}(9)`,
 `${osc}\x1b[2m Tests\x1b[22m \x1b[32m3 passed\x1b[0m | \x1b[31m2 failed\x1b[0m | 4 skipped (9)`,
 `${osc}Tests 3 passed | 2 failed | 4 skipped (9)${start}8;;${end}`];
 variants.forEach((log,i)=>check(`osc-${sn}-${en}-title${ti}-pos${i}`,log+'\nTests 999 passed (999)','Tests',fail));
}
const sgr=['\x1b[m','\x1b[0m','\x1b[1;2;31m','\x1b[38;5;196m','\x1b[38;2;255;0;1m','\x9b31m'];
sgr.forEach((s,i)=>check(`sgr-${i}`,`${s}Tests${s} 3 ${s}passed\x1b[0m | 2 ${s}failed\x1b[0m | 4 ${s}skipped\x1b[0m (${s}9${s})\nTests 999 passed (999)`,'Tests',fail));
for(const [sn,start]of starts){
 ['0;unfinished title with spaces','8;;https://example.invalid/unfinished','0;unfinished\x1b'].forEach((body,i)=>{
 check(`incomplete-${sn}-${i}`,start+body+'\nTests 999 passed (999)','Tests',null);
 check(`incomplete-after-${sn}-${i}`,'Tests 1 failed (1)\n'+start+body+'\nTests 999 passed (999)','Tests',null);
 });
}
check('complete-title-only','\x1b]0;Tests 999 passed (999) with spaces\x07','Tests',null);
check('complete-title-files','\x9d2;title with spaces\x1b\\Test Files \x1b[31m1 failed\x1b[m (1)\nTest Files 999 passed (999)','Test Files',{passed:0,failed:1,skipped:0,total:1});
const candidate=JSON.parse(fs.readFileSync(path.join(runtime,'scripts/hiso-baseline-inventory.json')));
const originalInventory=JSON.parse(fs.readFileSync('/home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r19/scripts/hiso-baseline-inventory.json'));
const metadata=[];
function meta(id,fn){try{const detail=fn();metadata.push({id,pass:true,detail});}catch(e){metadata.push({id,pass:false,error:e.stack});}}
meta('baseline371-identical',()=>{assert.equal(candidate.tests.length,371);assert.deepEqual(candidate.tests,originalInventory.tests);return{count:371};});
meta('all-original-test-bytes-and-modes-identical',()=>{const before=JSON.parse(fs.readFileSync(path.join(out,'inputs-before.json')));for(const f of candidate.tests){const a=before.source[f.path],b=before.original[f.path];assert.ok(a&&b,f.path);assert.equal(a.sha256,b.sha256,f.path);assert.equal(a.mode,b.mode,f.path);}return{files:371};});
meta('single-new-test-46-to47',()=>{assert.equal(originalInventory.newTests.length,46);assert.equal(candidate.newTests.length,47);const additions=candidate.newTests.filter(p=>!originalInventory.newTests.includes(p));assert.deepEqual(additions,['tests/certification-summary-ansi-own.test.js']);assert.ok(originalInventory.newTests.every(p=>candidate.newTests.includes(p)));return{original:46,candidate:47,additions};});
meta('coverage281-identical-and-derived',()=>{assert.deepEqual(candidate.coveragePaths,originalInventory.coveragePaths);assert.deepEqual(candidate.newCoveragePaths,originalInventory.newCoveragePaths);const expected=[...candidate.coveragePaths,...candidate.newCoveragePaths].sort();assert.equal(expected.length,281);const actual=coverageInventory(runtime,sourceFiles(runtime));assert.deepEqual(actual,expected);return{count:281,derivedFromUnmodifiedCollector:true};});
meta('inventory-only-newTests-changed',()=>{const {newTests:a,...restA}=candidate;const {newTests:b,...restB}=originalInventory;assert.deepEqual(restA,restB);return true;});
const result={node:process.version,cwd:process.cwd(),module:path.join(runtime,'scripts/lib/certification-rules.mjs'),cases,metadata,total:cases.length,passed:cases.filter(c=>c.pass).length,failed:cases.filter(c=>!c.pass).length};
fs.writeFileSync(path.join(out,'independent-results.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({node:result.node,total:result.total,passed:result.passed,failed:result.failed,metadata}));
if(result.failed||metadata.some(c=>!c.pass))process.exitCode=1;
