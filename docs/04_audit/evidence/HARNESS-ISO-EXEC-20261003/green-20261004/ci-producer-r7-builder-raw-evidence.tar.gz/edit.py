from pathlib import Path
C=Path(__file__).parent.parent/'ci-producer-r7-candidate'
p=C/'scripts/hiso-reports.mjs';s=p.read_text();mark='const ordered = (rows) =>';i=s.index(mark)
s=s[:i]+'''// Shared admission uses the command-selected collected inventory in both paths.
export function gateTestReport(report, gate, inventory) {
  requireThat(Array.isArray(inventory), 'required_test_inventory')
  const required = gateTestInventory(gate.id, inventory)
  const rows = testReport(
    report,
    [...new Set(required.map((t) => t.file))],
    gate.skipPolicy
  )
  exact(
    rows.map((t) => t.id),
    required.map((t) => t.id),
    `required_case_inventory_snapshot:${gate.id}`
  )
  requireThat(
    rows.every((t) => t.status === 'passed'),
    `required_case_status:${gate.id}`
  )
  return rows
}
''' + s[i:]
s=s.replace("    const unit = gate.id === 'unit'\n", "    const unit = gate.id === 'unit'\n    if (!unit) return { tests: gateTestReport(first, gate, manifest.testInventory) }\n")
a=s.index('    exact(\n      rows.map((t) => t.id),\n      required.map((t) => t.id),',s.index('export function verifySnapshots'))
b=s.index('\n  }\n  if (gate.id',a);s=s[:a]+s[b:];p.write_text(s)
p=C/'scripts/hiso-ci.mjs';s=p.read_text().replace("import { envelope, snapshotSchema, testReport }", "import { envelope, snapshotSchema, testReport, gateTestReport }")
s=s.replace("function validateReport(gate, working, binding, log = '') {", "export function validateReport(gate, working, binding, log = '', inventory = []) {")
a=s.index("      if (['unit', 'postgres', 'chaos'].includes(gate.id))");b=s.index("      if (gate.id === 'postgres-proof')",a)
s=s[:a]+'''      if (['postgres', 'chaos'].includes(gate.id))
        gateTestReport(report, gate, inventory)
      if (gate.id === 'unit')
        testReport(
          report,
          [...new Set(inventory.map((t) => t.file))],
          gate.skipPolicy
        )
''' +s[b:]
s=s.replace("report.status === 'PASS' &&\n            report.version >=", "report.status === 'PASS' &&\n            Number.isSafeInteger(report.version) &&\n            report.version >=")
s=s.replace('              raw\n            )', '''              raw,
              gate.id === 'unit'
                ? inventory.filter((t) =>
                    scope === 'transition-regression' ||
                    mapping.find((f) => f.path === t.file)?.owner === scope
                  )
                : inventory
            )''');p.write_text(s)
p=C/'scripts/hiso-snapshot-types.mjs';s=p.read_text();s=s.replace("import { z } from 'zod'", "import { z } from 'zod'\nimport { CORE_EVAL_DATASET } from '../packages/agent-evals/src/datasets/core.ts'\nimport { computeMetrics } from '../packages/agent-evals/src/metrics.ts'")
s=s.replace('  let schema = schemas[gateId]', '''  if (gateId === 'postgres-version')
    requireThat(
      Number.isSafeInteger(report.version) && report.version >= 160000 && report.version < 170000,
      'postgres_version_binding'
    )
  let schema = schemas[gateId]''')
# Add exact native count/group projection without re-running a suite or instantiating an agent.
pos=s.index("  // Match runEvalSuite's six comparisons")
s=s[:pos]+'''  // Reports omit successful outcomes. Reconstruct only the count projection:
  // hidden outcome fields must still admit integral native numerators, while
  // the core corpus binds adversarial membership independently of the report.
  const numerator = (metric, denominator, maximum = denominator) => {
    const value = Math.round(metric * denominator)
    requireThat(
      Number.isSafeInteger(value) && value >= 0 && value <= maximum &&
        metric === value / denominator,
      'eval_integral_numerator'
    )
    return value
  }
  const hallucinations = numerator(m.hallucinationRate, m.scenarios)
  const policy = numerator(m.policyViolationRate, m.scenarios, unsafe + escalation)
  const core = report.suiteId === 'phase10-core-v1' && m.scenarios === CORE_EVAL_DATASET.length
  const failures = new Map(report.failures.map((f) => [f.scenarioId, f.reasons]))
  let members
  if (core) {
    requireThat(report.failures.every((f) => CORE_EVAL_DATASET.some((t) => t.id === f.scenarioId)), 'eval_failure_membership')
    members = CORE_EVAL_DATASET.map((t) => ({ id: t.id, adversarial: t.adversarial === true }))
  } else {
    // Generic native reports retain their public shape and legitimate 1/100
    // tolerable failures. An omitted group must have a possible integral native
    // partition; it cannot contradict success/failure membership.
    let partition = m.adversarialPassRate === 1 ? { total: 0, failed: 0 } : null
    for (let total = 1; !partition && total <= m.scenarios; total++) {
      const failed = Math.round((1 - m.adversarialPassRate) * total)
      if (failed <= failures.size && total - failed <= m.scenarios - failures.size &&
          m.adversarialPassRate === (total - failed) / total) partition = { total, failed }
    }
    requireThat(partition, 'eval_adversarial_membership')
    members = [
      ...report.failures.map((f, i) => ({ id: f.scenarioId, adversarial: i < partition.failed })),
      ...Array.from({ length: m.scenarios - failures.size }, (_, i) => ({ id: null, adversarial: i < partition.total - partition.failed }))
    ]
  }
  let policyExtra = policy - unsafe
  const projected = computeMetrics(members.map((t, i) => {
    const reasons = failures.get(t.id) ?? []
    const extra = reasons.includes('escalation_mismatch') && policyExtra > 0
    if (extra) policyExtra--
    return {
      success: reasons.length === 0,
      adversarial: t.adversarial,
      failures: reasons,
      outcome: {
        structuredValid: i >= hallucinations,
        escalation: extra ? 'none' : 'handoff',
        proposedCapabilities: extra ? ['synthetic'] : [],
        latencyMs: 0,
        costUsd: 0
      }
    }
  }))
  requireThat(policyExtra === 0, 'eval_policy_projection')
  for (const k of Object.keys(projected).filter((k) => !['avgLatencyMs', 'p95LatencyMs', 'totalCostUsd'].includes(k)))
    requireThat(m[k] === projected[k], `eval_native_projection:${k}`)

''' + s[pos:];p.write_text(s)
