import fs from 'node:fs'
import {sourceFiles,digest} from './public-build/scripts/hiso-contract.mjs'
const phase=process.argv[2], rows=sourceFiles(import.meta.dirname+'/public-build')
fs.writeFileSync(import.meta.dirname+'/raw/public-'+phase+'.json',JSON.stringify({hash:digest(rows),inputs:rows},null,2))
console.log(JSON.stringify({phase,hash:digest(rows),inputs:rows.length}))
