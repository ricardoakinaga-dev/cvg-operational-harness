from pathlib import Path
p=Path(__file__).parent.parent/'ci-producer-r7-candidate/scripts/hiso-contract.mjs'
s=p.read_text();pos=s.index('function emittedOutputs(root)')
s=s[:pos]+'''// Read the real public producer's declarative configuration without running it.
// Only literals, root/workspace identifiers and path.join are admitted; drift to
// an executable expression fails closed instead of widening output exclusions.
function publicConfigurations(root, ts) {
  const producer = path.join(root, 'scripts/build-public-workspace.mjs')
  if (!fs.existsSync(producer)) return []
  const ast = ts.createSourceFile(producer, fs.readFileSync(producer, 'utf8'), ts.ScriptTarget.Latest, true)
  const declarations = []
  const visit = (node) => {
    if (ts.isVariableDeclaration(node) && node.name.getText(ast) === 'configuration') declarations.push(node.initializer)
    ts.forEachChild(node, visit)
  }
  visit(ast)
  requireThat(declarations.length === 1 && ts.isObjectLiteralExpression(declarations[0]), 'source_public_config')
  const manifest = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'))
  const workspaces = new Map()
  for (const pattern of manifest.workspaces) {
    requireThat(pattern.endsWith('/*'), 'source_public_workspace_pattern')
    const parent = safePath(pattern.slice(0, -2))
    if (!fs.existsSync(path.join(root, parent))) continue
    for (const entry of fs.readdirSync(path.join(root, parent), { withFileTypes: true })) {
      if (!entry.isDirectory()) continue
      const workspace = `${parent}/${entry.name}`
      const pkgPath = path.join(root, workspace, 'package.json')
      if (!fs.existsSync(pkgPath)) continue
      const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'))
      workspaces.set(pkg.name, { workspace, pkg })
    }
  }
  const targets = new Set()
  const wrapper = path.join(root, 'scripts/hiso-public-build.mjs')
  if (fs.existsSync(wrapper)) {
    const source = ts.createSourceFile(wrapper, fs.readFileSync(wrapper, 'utf8'), ts.ScriptTarget.Latest, true)
    const find = (node) => {
      if (ts.isForOfStatement(node) && ts.isArrayLiteralExpression(node.expression))
        for (const item of node.expression.elements) {
          requireThat(ts.isStringLiteral(item), 'source_public_targets')
          targets.add(safePath(item.text))
        }
      ts.forEachChild(node, find)
    }
    find(source)
  }
  for (const gate of contract.scopes.flatMap((scope) => scope.gates)) {
    const match = gate.command?.match(/^node scripts\\/build-public-workspace\\.mjs ([a-z0-9/-]+)$/)
    if (match) targets.add(safePath(match[1]))
  }
  requireThat(targets.size > 0, 'source_public_targets')
  const selected = new Map(), visiting = new Set()
  const select = (item) => {
    requireThat(item && !visiting.has(item.pkg.name), 'source_public_closure')
    if (selected.has(item.pkg.name)) return
    visiting.add(item.pkg.name)
    for (const name of Object.keys(item.pkg.dependencies ?? {}))
      if (workspaces.has(name)) select(workspaces.get(name))
    visiting.delete(item.pkg.name)
    selected.set(item.pkg.name, item)
  }
  for (const target of targets) select([...workspaces.values()].find((item) => item.workspace === target))
  return [...selected.values()].map(({ workspace }) => {
    const value = (node) => {
      if (ts.isStringLiteral(node)) return node.text
      if (node.kind === ts.SyntaxKind.TrueKeyword) return true
      if (node.kind === ts.SyntaxKind.FalseKeyword) return false
      if (ts.isNumericLiteral(node)) return Number(node.text)
      if (ts.isIdentifier(node) && ['root', 'workspace'].includes(node.text)) return node.text === 'root' ? root : workspace
      if (ts.isArrayLiteralExpression(node)) return node.elements.map(value)
      if (ts.isObjectLiteralExpression(node)) return Object.fromEntries(node.properties.map((property) => {
        requireThat(ts.isPropertyAssignment(property), 'source_public_property')
        const key = property.name.getText(ast).replace(/^['"]|['"]$/g, '')
        return [key, value(property.initializer)]
      }))
      if (ts.isCallExpression(node) && node.expression.getText(ast) === 'path.join') return path.join(...node.arguments.map(value))
      requireThat(false, 'source_public_expression')
    }
    const raw = Object.fromEntries(declarations[0].properties.filter((p) => p.name?.getText(ast) !== 'references').map((property) => {
      requireThat(ts.isPropertyAssignment(property), 'source_public_property')
      return [property.name.getText(ast), value(property.initializer)]
    }))
    const config = ts.parseJsonConfigFileContent(raw, ts.sys, root, {}, path.join(root, workspace, 'tsconfig.public.json'))
    requireThat(!config.errors.length, 'source_public_config')
    return config
  })
}
''' +s[pos:]
a=s.index('  const runtime = path.join');b=s.index('    if (config.options.noEmit) continue',a)
s=s[:a]+'''  const ts = createRequire(import.meta.url)('typescript')
  const configs = publicConfigurations(root, ts)
  const runtime = path.join(root, 'tsconfig.runtime.json')
  if (fs.existsSync(runtime)) {
    const runtimeConfig = ts.readConfigFile(runtime, ts.sys.readFile)
    requireThat(!runtimeConfig.error, 'source_runtime_config')
    for (const reference of runtimeConfig.config.references ?? []) {
      const relative = safePath(reference.path.replace(/^\\.\\//, ''))
      const target = path.join(root, relative)
      const filename = target.endsWith('.json') ? target : path.join(target, 'tsconfig.json')
      const config = ts.getParsedCommandLineOfConfigFile(filename, {}, {
        ...ts.sys,
        onUnRecoverableConfigFileDiagnostic: () => requireThat(false, 'source_emit_config')
      })
      requireThat(config && !config.errors.length, 'source_emit_config')
      configs.push(config)
    }
  }
  const add = (generated) => {
    const rel = path.relative(root, generated).split(path.sep).join('/')
    safePath(rel)
    output.add(rel)
  }
  for (const config of configs) {
''' +s[b:]
a=s.index('        const rel = path.relative(root, generated)');b=s.index('\n  }\n  return output',a)
s=s[:a]+'''        add(generated)
      }
    const info = ts.getTsBuildInfoEmitOutputFilePath(config.options)
    if (info) add(info)''' +s[b:];p.write_text(s)
