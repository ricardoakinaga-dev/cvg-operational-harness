import pathlib,shutil,json,sys
O=pathlib.Path(__file__).parent; C=O.parent/'ci-producer-r7-candidate'; S=O.parent/'candidate';W=O/'work'
if not W.exists():shutil.copytree(C,W,symlinks=False,ignore=lambda p,ns:[n for n in ns if n=='.vite' or n=='.git' or n.startswith('.env') and n!='.env.example'])
paths=['scripts/hiso-contract.mjs','scripts/hiso-ci.mjs','scripts/hiso-reports.mjs','scripts/hiso-snapshot-types.mjs','tests/hiso-effective-inputs-own.test.js','tests/hiso-snapshot-membership-own.test.js']
for p in paths: shutil.copy2(C/p,W/p)
for r in json.loads((O.parent/'ci-review-r6-staging/output/raw/authorized-machine-fixtures.json').read_text()):
 p=r['path'];t=W/p;t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(S/p,t)
print('work copy with seven exact immutable machine fixtures')
