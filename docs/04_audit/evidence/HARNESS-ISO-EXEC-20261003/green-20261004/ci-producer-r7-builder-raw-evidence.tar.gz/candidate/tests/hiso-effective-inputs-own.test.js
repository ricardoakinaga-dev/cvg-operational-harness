// @vitest-environment node
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { afterAll, expect, it } from 'vitest'
import { sourceFiles, digest } from '../scripts/hiso-contract.mjs'
const parent = fs.mkdtempSync(path.join(os.tmpdir(), 'hiso-effective-inputs-'))
afterAll(() => fs.rmSync(parent, { recursive: true, force: true }))
for (const location of [
  'certification/helper.mjs',
  'certification/logs/active/helper.mjs',
  'packages/synthetic/src/dist/helper.mjs',
  'packages/synthetic/src/.gauntlet/dist/helper.mjs',
  'packages/synthetic/src/node_modules/helper.mjs',
  '.gauntlet/dist/helper.mjs',
  'dist/helper.mjs'
])
  it('seals the effective inert input ' + location, () => {
    const root = fs.mkdtempSync(path.join(parent, 'case-'))
    const target = path.join(root, location)
    fs.mkdirSync(path.dirname(target), { recursive: true })
    fs.writeFileSync(target, 'export const label=1;')
    const before = sourceFiles(root)
    expect(before.map((f) => f.path)).toContain(location)
    fs.writeFileSync(target, 'export const label=2;')
    const after = sourceFiles(root)
    expect(digest(after)).not.toBe(digest(before))
  })
it('does not omit undeclared documentary JSON under certification', () => {
  const root = fs.mkdtempSync(path.join(parent, 'case-'))
  fs.mkdirSync(path.join(root, 'certification'))
  fs.writeFileSync(
    path.join(root, 'certification', 'consumer-input.json'),
    '{"label":1}'
  )
  expect(sourceFiles(root).map((f) => f.path)).toContain(
    'certification/consumer-input.json'
  )
})
it('retains only exact owned report leaves outside the source inventory', () => {
  const root = fs.mkdtempSync(path.join(parent, 'case-'))
  fs.mkdirSync(path.join(root, 'certification'))
  fs.writeFileSync(
    path.join(root, 'certification', 'unit-test-report.json'),
    '{}'
  )
  fs.writeFileSync(
    path.join(root, 'certification', 'unit-test-report.json.mjs'),
    'export const label=1;'
  )
  const files = sourceFiles(root).map((f) => f.path)
  expect(files).not.toContain('certification/unit-test-report.json')
  expect(files).toContain('certification/unit-test-report.json.mjs')
})

it('inventories a compiler-configured variant before dependencies are installed', () => {
  const root = fs.mkdtempSync(path.join(parent, 'case-'))
  fs.writeFileSync(path.join(root, 'package.json'), '{"private":true}')
  fs.writeFileSync(
    path.join(root, 'tsconfig.runtime.json'),
    '{"files":[],"references":[]}'
  )
  fs.writeFileSync(
    path.join(root, 'consumer-input.mjs'),
    'export const label=1;'
  )
  expect(fs.existsSync(path.join(root, 'node_modules'))).toBe(false)
  expect(sourceFiles(root).map((f) => f.path)).toEqual([
    'consumer-input.mjs',
    'package.json',
    'tsconfig.runtime.json'
  ])
})

function publicInputFixture() {
  const root = fs.mkdtempSync(path.join(parent, 'public-'))
  const source = path.resolve(import.meta.dirname, '..')
  const put = (p, text) => {
    fs.mkdirSync(path.dirname(path.join(root, p)), { recursive: true })
    fs.writeFileSync(path.join(root, p), text)
  }
  for (const p of [
    'scripts/build-public-workspace.mjs',
    'scripts/hiso-public-build.mjs'
  ])
    put(p, fs.readFileSync(path.join(source, p)))
  put('package.json', JSON.stringify({ workspaces: ['packages/*'] }))
  put(
    'tsconfig.base.json',
    JSON.stringify({ compilerOptions: { composite: true, declaration: true } })
  )
  for (const name of [
    'shared',
    'contracts',
    'model-gateway',
    'orchestrator',
    'harness'
  ]) {
    const p = `packages/${name}`
    put(
      `${p}/package.json`,
      fs.readFileSync(path.join(source, p, 'package.json'))
    )
    put(`${p}/src/index.ts`, 'export const label = 1;')
    put(`${p}/dist/tsconfig.public.tsbuildinfo`, '{}')
  }
  return { root, put }
}
it('excludes only build-info leaves emitted by the effective public configuration', () => {
  const { root, put } = publicInputFixture()
  put('packages/shared/dist/unknown.tsbuildinfo', '{}')
  put(
    'packages/shared/dist/tsconfig.public.tsbuildinfo.mjs',
    'export const label = 1;'
  )
  const before = sourceFiles(root)
  expect(
    before.filter((f) => f.path.endsWith('/tsconfig.public.tsbuildinfo'))
  ).toHaveLength(0)
  expect(before.map((f) => f.path)).toContain(
    'packages/shared/dist/unknown.tsbuildinfo'
  )
  expect(before.map((f) => f.path)).toContain(
    'packages/shared/dist/tsconfig.public.tsbuildinfo.mjs'
  )
  put('packages/shared/dist/unknown.tsbuildinfo', '{"label":2}')
  expect(digest(sourceFiles(root))).not.toBe(digest(before))
})
it('derives a changed finite build-info leaf from the actual producer config', () => {
  const { root, put } = publicInputFixture()
  const p = 'scripts/build-public-workspace.mjs'
  put(
    p,
    fs
      .readFileSync(path.join(root, p), 'utf8')
      .replace("'tsconfig.public.tsbuildinfo'", "'owned-public.tsbuildinfo'")
  )
  put('packages/shared/dist/owned-public.tsbuildinfo', '{}')
  const paths = sourceFiles(root).map((f) => f.path)
  expect(paths).toContain('packages/shared/dist/tsconfig.public.tsbuildinfo')
  expect(paths).not.toContain('packages/shared/dist/owned-public.tsbuildinfo')
})
for (const leaf of [
  'packages/shared/dist/hidden.mjs',
  'packages/shared/src/.gauntlet/dist/hidden.mjs',
  'certification/logs/nested/hidden.mjs'
])
  it('binds an adjacent inert public-build input ' + leaf, () => {
    const { root, put } = publicInputFixture()
    put(leaf, 'export const label = 1;')
    const before = sourceFiles(root)
    expect(before.map((f) => f.path)).toContain(leaf)
    put(leaf, 'export const label = 2;')
    expect(digest(sourceFiles(root))).not.toBe(digest(before))
  })
