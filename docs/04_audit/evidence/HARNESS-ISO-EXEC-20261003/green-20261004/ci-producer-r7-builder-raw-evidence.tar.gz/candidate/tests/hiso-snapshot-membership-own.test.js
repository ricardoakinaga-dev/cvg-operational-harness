// @vitest-environment node
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import {
  caseOccurrences,
  approvedCoverageInventory,
  coverageInventory
} from '../scripts/hiso-inventory.mjs'
import { rules } from '../scripts/hiso-variant.mjs'
import * as reports from '../scripts/hiso-reports.mjs'
const { testReport, verifySnapshots, snapshotSchema, gateTestInventory } =
  reports
import { buildCoverageReport } from '../scripts/lib/coverage-gate.mjs'

import {
  copyProjectionConfigs,
  expectedCoveragePaths,
  linkPrivateParser,
  nativeEvalArtifact
} from './fixtures/hiso-r6-measurement.mjs'

const root = path.resolve(import.meta.dirname, '..')
const json = (p) => JSON.parse(fs.readFileSync(path.join(root, p), 'utf8'))
const pkg = json('package.json')
const critical = json('scripts/critical-coverage-manifest.json')
const thresholds = json('packages/agent-evals/src/eval-thresholds.json')
const dirs = []
afterEach(() => {
  for (const d of dirs.splice(0)) fs.rmSync(d, { recursive: true, force: true })
})
const temp = () => {
  const d = fs.mkdtempSync(path.join(os.tmpdir(), 'ci-r6-own-'))
  dirs.push(d)
  return d
}
const clone = (v) => structuredClone(v)
const row = (file, name = 'case') => ({
  file,
  name,
  kind: 'COLLECTED_NOT_EXECUTED'
})
const inventory = (rows) => caseOccurrences(rows)
function native(rows) {
  const files = [...new Set(rows.map((t) => t.file))]
  return {
    success: true,
    numTotalTests: rows.length,
    numPassedTests: rows.length,
    numFailedTests: 0,
    numFailedTestSuites: 0,
    testResults: files.map((file) => ({
      name: `/synthetic/${file}`,
      status: 'passed',
      assertionResults: rows
        .filter((t) => t.file === file)
        .map((t) => ({ ancestorTitles: [], title: t.name, status: 'passed' }))
    }))
  }
}
function verify(id, report, testInventory = [], more = {}) {
  const d = temp(),
    p = `gate-outputs/${id}/report.json`
  fs.mkdirSync(path.dirname(path.join(d, p)), { recursive: true })
  fs.writeFileSync(path.join(d, p), JSON.stringify(report))
  return verifySnapshots({
    gate: { id, skipPolicy: 'none' },
    entry: { outputs: [{ path: p }] },
    directory: d,
    manifest: { testInventory, ...more.manifest },
    expected: more.expected ?? {}
  })
}
const postgres = pkg.scripts['test:postgres']
  .split(/\s+/)
  .filter((t) => t.endsWith('.test.ts'))
const chaos = fs
  .readdirSync(path.join(root, 'packages/chaos/src/__tests__'))
  .filter((p) => p.endsWith('.test.ts'))
  .map((p) => 'packages/chaos/src/__tests__/' + p)
const metrics = (total = 10, covered = total) =>
  Object.fromEntries(
    ['statements', 'lines', 'functions', 'branches'].map((k) => [
      k,
      {
        total,
        covered,
        skipped: 0,
        pct: total ? Number(((100 * covered) / total).toFixed(2)) : 100
      }
    ])
  )
function coverage() {
  const summary = Object.fromEntries(
    critical.groups.flatMap((g) => g.paths).map((p) => [p, metrics()])
  )
  summary.total = metrics(1000)
  return buildCoverageReport(summary, critical)
}
const evalReport = () => ({
  suiteId: 'phase10-core-v1',
  agentId: 'static-synthetic',
  startedAt: '2026-10-05T00:00:00.000Z',
  finishedAt: '2026-10-05T00:00:01.000Z',
  metrics: {
    scenarios: 100,
    taskSuccessRate: 1,
    policyViolationRate: 0,
    unsafeActionRate: 0,
    hallucinationRate: 0,
    toolSelectionAccuracy: 1,
    humanEscalationAccuracy: 1,
    schemaFailureRate: 0,
    refusalAccuracy: 1,
    adversarialPassRate: 1,
    avgLatencyMs: 1,
    p95LatencyMs: 1,
    totalCostUsd: 0
  },
  thresholds,
  verdict: 'PASS',
  failures: []
})

describe('R6 gate case membership', () => {
  it.each(['postgres', 'chaos'])(
    '%s accepts complete producer-shaped reports in arbitrary order',
    (id) => {
      const selected = (id === 'postgres' ? postgres : chaos).map((p) => row(p))
      selected.push(row(selected[0].file))
      const all = inventory([...selected, row('tests/unrelated.test.js')])
      expect(() =>
        verify(id, native([...selected].reverse()), all)
      ).not.toThrow()
    }
  )
  it.each(['postgres', 'chaos'])('%s rejects omitted suites', (id) => {
    const rows = (id === 'postgres' ? postgres : chaos).map((p) => row(p))
    expect(() => verify(id, native(rows.slice(1)), inventory(rows))).toThrow()
  })
  it.each(['postgres', 'chaos'])(
    '%s rejects omitted same-name occurrences',
    (id) => {
      const rows = (id === 'postgres' ? postgres : chaos).map((p) => row(p))
      const all = inventory([...rows, row(rows[0].file)])
      expect(() => verify(id, native(rows), all)).toThrow()
    }
  )
  it.each(['postgres', 'chaos'])('%s rejects changed case identity', (id) => {
    const rows = (id === 'postgres' ? postgres : chaos).map((p) => row(p))
    const report = native(rows)
    report.testResults[0].assertionResults[0].title = 'different'
    expect(() => verify(id, report, inventory(rows))).toThrow()
  })
  it('testReport rejects missing known suites', () =>
    expect(() =>
      testReport(native([row('tests/a.test.js')]), [
        'tests/a.test.js',
        'tests/b.test.js'
      ])
    ).toThrow())
  it('testReport rejects duplicate known file suites', () => {
    const r = native([row('tests/a.test.js')])
    r.testResults.push(clone(r.testResults[0]))
    r.numTotalTests = r.numPassedTests = 2
    expect(() => testReport(r, ['tests/a.test.js'])).toThrow()
  })
  it('unit canonicalizes native and manifest order', () => {
    const rows = [row('tests/z.test.js'), row('tests/a.test.js')]
    const r = native(rows)
    const executed = testReport(
      r,
      rows.map((t) => t.file)
    ).reverse()
    expect(() =>
      verify('unit', r, inventory(rows), {
        manifest: { executedTestInventory: executed },
        expected: { requiredTestIds: inventory(rows).map((t) => t.id) }
      })
    ).not.toThrow()
  })
  it('unit requires all scoped cases even if executed projection agrees with missing report', () => {
    const rows = [row('tests/a.test.js'), row('tests/b.test.js')],
      r = native(rows.slice(0, 1))
    expect(() =>
      verify('unit', r, inventory(rows), {
        manifest: { executedTestInventory: testReport(r, [rows[0].file]) },
        expected: { requiredTestIds: inventory(rows).map((t) => t.id) }
      })
    ).toThrow()
  })
  it('postgres rejects selector files absent from collected inventory', () =>
    expect(() =>
      verify(
        'postgres',
        native([row(postgres[0])]),
        inventory([row(postgres[0])])
      )
    ).toThrow())
})
describe('R6 coverage producer semantics', () => {
  it('accepts real buildCoverageReport output', () =>
    expect(() => verify('coverage-critical', coverage())).not.toThrow())
  it('accepts arbitrary group/file order', () => {
    const r = coverage()
    r.critical.groups.reverse().forEach((g) => {
      g.files.reverse()
      g.paths.reverse()
    })
    expect(() => verify('coverage-critical', r)).not.toThrow()
  })
  it('accepts legitimate type-only zero per file', () => {
    const summary = Object.fromEntries(
      critical.groups.flatMap((g) => g.paths).map((p) => [p, metrics()])
    )
    summary[critical.groups[0].paths[0]] = metrics(0)
    summary.total = metrics(1000)
    const r = buildCoverageReport(summary, critical)
    expect(r.verdict).toBe('PASS')
    expect(() => verify('coverage-critical', r)).not.toThrow()
  })
  it.each(['statements', 'lines', 'functions', 'branches'])(
    'rejects contradictory global %s',
    (k) => {
      const r = coverage()
      r.global.metrics[k].covered = 0
      expect(() => verify('coverage-critical', r)).toThrow()
    }
  )
  it.each(['statements', 'lines', 'functions', 'branches'])(
    'rejects global zero %s',
    (k) => {
      const r = coverage()
      r.global.metrics[k] = { total: 0, covered: 0, pct: 100 }
      expect(() => verify('coverage-critical', r)).toThrow()
    }
  )
  it.each([
    'omit',
    'duplicate',
    'unknown',
    'file',
    'aggregate',
    'zero',
    'threshold',
    'pct',
    'global-threshold',
    'rounded-boundary'
  ])('rejects critical contradiction %s', (kind) => {
    const r = coverage(),
      g = r.critical.groups[0]
    if (kind === 'omit') r.critical.groups.pop()
    if (kind === 'duplicate') r.critical.groups.push(clone(g))
    if (kind === 'unknown') g.id = 'unknown'
    if (kind === 'file') g.files.pop()
    if (kind === 'aggregate') g.metrics.branches.total++
    if (kind === 'zero') g.metrics = metrics(0)
    if (kind === 'threshold') r.critical.threshold = 0
    if (kind === 'pct') g.files[0].metrics.branches.pct = 99
    if (kind === 'global-threshold')
      r.global.thresholds = { ...r.global.thresholds, branches: 0 }
    if (kind === 'rounded-boundary')
      r.global.metrics.statements = { total: 100000, covered: 89999, pct: 90 }
    expect(() => verify('coverage-critical', r)).toThrow()
  })
})
describe('R6 eval verdict semantics', () => {
  it('accepts the immutable real native producer artifact', () =>
    expect(() => verify('evals', nativeEvalArtifact())).not.toThrow())
  it('accepts inert native producer shape', () =>
    expect(() => verify('evals', evalReport())).not.toThrow())
  it.each([
    'taskSuccessRate',
    'policyViolationRate',
    'unsafeActionRate',
    'schemaFailureRate',
    'adversarialPassRate',
    'humanEscalationAccuracy'
  ])('rejects asserted PASS violating %s', (k) => {
    const r = evalReport()
    r.metrics[k] = [
      'policyViolationRate',
      'unsafeActionRate',
      'schemaFailureRate'
    ].includes(k)
      ? 1
      : 0
    expect(() => verify('evals', r)).toThrow()
  })
  it('rejects thresholds weakened from producer', () => {
    const r = evalReport()
    r.thresholds = { ...thresholds, taskSuccessRate: 0 }
    expect(() => verify('evals', r)).toThrow()
  })
  it('rejects omitted producer metric', () => {
    const r = evalReport()
    delete r.metrics.unsafeActionRate
    expect(() => verify('evals', r)).toThrow()
  })
  it('rejects unexplained failed scenario with perfect success', () => {
    const r = evalReport()
    r.failures = [
      { scenarioId: 'inert', reasons: ['intent_mismatch:synthetic'] }
    ]
    expect(() => verify('evals', r)).toThrow()
  })
  it('preserves producer PASS with legitimate tolerable scenario failures', () => {
    const r = evalReport()
    r.metrics.taskSuccessRate = 0.99
    r.failures = [
      { scenarioId: 'inert', reasons: ['intent_mismatch:synthetic'] }
    ]
    expect(() => verify('evals', r)).not.toThrow()
  })
  it('rejects global zero scenarios', () => {
    const r = evalReport()
    r.metrics.scenarios = 0
    expect(() => verify('evals', r)).toThrow()
  })
})
describe('R6 inventory producer compatibility', () => {
  it('accepts the current declaration-bearing emitter envelope', () =>
    expect(() =>
      snapshotSchema(
        {
          schemaVersion: 1,
          kind: 'hiso-inventory-v1',
          declarations: [],
          mapping: [],
          inventory: [],
          coveragePaths: [],
          transitionOnly: []
        },
        'inventory'
      )
    ).not.toThrow())
})

describe('R6 conservative selector parsing', () => {
  it.each([
    'vitest run packages/chaos --coverage --no-file-parallelism --maxWorkers=2',
    'vitest run packages/chaos-extra --no-file-parallelism --maxWorkers=2',
    'vitest run packages/chaos; --no-file-parallelism --maxWorkers=2',
    'vitest run --no-file-parallelism --maxWorkers=2'
  ])('rejects unknown chaos selector %s', (script) =>
    expect(() =>
      gateTestInventory('chaos', inventory(chaos.map((p) => row(p))), {
        'test:chaos': script
      })
    ).toThrow()
  )
  it('rejects unknown postgres options', () =>
    expect(() =>
      gateTestInventory('postgres', inventory(postgres.map((p) => row(p))), {
        'test:postgres': pkg.scripts['test:postgres'] + ' --exclude=apps/**'
      })
    ).toThrow())
})

// Build the exact approved projection using the existing variant rules. All
// source contents are inert; only physical membership/config bindings matter.
function projectedRoot() {
  const d = temp()
  const write = (p, value) => {
    fs.mkdirSync(path.dirname(path.join(d, p)), { recursive: true })
    fs.writeFileSync(path.join(d, p), value)
  }
  copyProjectionConfigs(root, d, 'neutral')
  const paths = expectedCoveragePaths(root, 'neutral')
  paths.forEach((p) => write(p, 'export interface Inert {}\n'))
  linkPrivateParser(root, d)
  return { d, paths, write }
}
describe('R6 exact approved neutral projection', () => {
  it('accepts only the complete physical approved transform', () => {
    const f = projectedRoot()
    expect(coverageInventory(f.d)).toEqual(f.paths)
    expect(approvedCoverageInventory(f.d)).toEqual(f.paths)
  })
  it('retains the original full root denominator', () => {
    expect(approvedCoverageInventory(root)).toEqual(expectedCoveragePaths(root))
  })
  it('rejects arbitrary retained source omission', () => {
    const f = projectedRoot()
    fs.unlinkSync(path.join(f.d, f.paths[0]))
    expect(() => approvedCoverageInventory(f.d)).toThrow(
      'approved_coverage_source_inventory'
    )
  })
  it('rejects merely deleting products with original configuration', () => {
    const f = projectedRoot()
    copyProjectionConfigs(root, f.d, 'retained')
    expect(() => approvedCoverageInventory(f.d)).toThrow(
      'approved_coverage_source_inventory'
    )
  })
  it.each([
    'package-lock.json',
    'tsconfig.json',
    'tsconfig.typecheck.json',
    'vitest.config.mts',
    rules.workspacePolicy,
    rules.docPolicyProjection.path
  ])('rejects projection drift at %s', (p) => {
    const f = projectedRoot()
    f.write(p, fs.readFileSync(path.join(f.d, p), 'utf8') + '\n')
    expect(() => approvedCoverageInventory(f.d)).toThrow(
      'approved_coverage_source_inventory'
    )
  })
  it('rejects a physically retained product tree', () => {
    const f = projectedRoot()
    f.write('products/shift-assistant/marker.txt', 'inert')
    expect(() => approvedCoverageInventory(f.d)).toThrow(
      'approved_coverage_source_inventory'
    )
  })
  it('rejects arbitrary coverage exclusion even with no products', () => {
    const f = projectedRoot()
    f.write(
      'vitest.config.mts',
      fs
        .readFileSync(path.join(f.d, 'vitest.config.mts'), 'utf8')
        .replace("'**/*.test.ts',", `'${f.paths[0]}',\n        '**/*.test.ts',`)
    )
    expect(() => approvedCoverageInventory(f.d)).toThrow(
      'approved_coverage_source_inventory'
    )
  })
})

describe('R6 additional inert failure projections', () => {
  it('eval forbids a failed forbidden capability with zero unsafe rate', () => {
    const r = evalReport()
    r.metrics.taskSuccessRate = 0.99
    r.failures = [
      { scenarioId: 'inert', reasons: ['forbidden_capability:inert'] }
    ]
    expect(() => verify('evals', r)).toThrow()
  })
  it('eval rejects duplicate scenario failure identities', () => {
    const r = evalReport()
    r.metrics.taskSuccessRate = 0.98
    r.failures = [
      { scenarioId: 'inert', reasons: ['intent_mismatch:inert'] },
      { scenarioId: 'inert', reasons: ['intent_mismatch:inert'] }
    ]
    expect(() => verify('evals', r)).toThrow()
  })
  it('postgres rejects replacement of a frozen file selector', () => {
    const s = pkg.scripts['test:postgres'].replace(
      postgres[0],
      'packages/inert.test.ts'
    )
    expect(() =>
      gateTestInventory('postgres', inventory(postgres.map((p) => row(p))), {
        'test:postgres': s
      })
    ).toThrow()
  })
  it.each(['postgres', 'chaos'])('%s rejects duplicate file suites', (id) => {
    const rows = (id === 'postgres' ? postgres : chaos).map((p) => row(p))
    const r = native(rows)
    r.testResults.push(clone(r.testResults[0]))
    r.numPassedTests = r.numTotalTests = rows.length + 1
    expect(() => verify(id, r, inventory(rows))).toThrow()
  })
  it.each(['postgres', 'chaos'])(
    '%s rejects an unrelated known global suite',
    (id) => {
      const rows = (id === 'postgres' ? postgres : chaos).map((p) => row(p))
      const unrelated = row('tests/unrelated.test.js')
      expect(() =>
        verify(
          id,
          native([...rows, unrelated]),
          inventory([...rows, unrelated])
        )
      ).toThrow()
    }
  )
  it.each(['postgres', 'chaos'])('%s rejects a pending required case', (id) => {
    const rows = (id === 'postgres' ? postgres : chaos).map((p) => row(p))
    const r = native(rows)
    r.testResults[0].assertionResults[0].status = 'pending'
    r.numPassedTests--
    expect(() => verify(id, r, inventory(rows))).toThrow()
  })
})

// R7 additions preserve the entire original R6 test prefix.
describe('R7 producer and verifier case admission parity', () => {
  for (const id of ['postgres', 'chaos']) {
    const selected = (id === 'postgres' ? postgres : chaos).map((p) => row(p))
    selected.push(row(selected[0].file))
    const all = inventory([...selected, row('tests/unrelated.test.js')])
    it(id + ' shares complete ordered-independent admission', () => {
      const report = native([...selected].reverse())
      expect(
        reports.gateTestReport(report, { id, skipPolicy: 'none' }, all)
      ).toEqual(verify(id, report, all).tests)
    })
    it.each(['case', 'suite', 'duplicate', 'identity', 'status'])(
      id + ' rejects %s before snapshots',
      (kind) => {
        let chosen = [...selected]
        if (kind === 'case') chosen.pop()
        if (kind === 'suite')
          chosen = chosen.filter((t) => t.file !== selected[0].file)
        if (kind === 'duplicate') chosen.push(row(selected[0].file))
        const report = native(chosen)
        if (kind === 'identity')
          report.testResults[0].assertionResults[0].title = 'different'
        if (kind === 'status')
          report.testResults[0].assertionResults[0].status = 'failed'
        expect(() =>
          reports.gateTestReport(report, { id, skipPolicy: 'none' }, all)
        ).toThrow()
        expect(() => verify(id, report, all)).toThrow()
      }
    )
  }
})
it.each(['160000', 160000.5, 159999, 170000, NaN, Infinity])(
  'R7 snapshot schema rejects Pg version %s',
  (version) => {
    expect(() =>
      snapshotSchema(
        { schemaVersion: 1, status: 'PASS', version },
        'postgres-version'
      )
    ).toThrow('postgres_version_binding')
  }
)
it.each([160000, 169999])(
  'R7 snapshot schema accepts safe Pg16 integer %s',
  (version) => {
    expect(() =>
      snapshotSchema(
        { schemaVersion: 1, status: 'PASS', version },
        'postgres-version'
      )
    ).not.toThrow()
  }
)
describe('R7 integral native eval projection', () => {
  it('rejects adversarial failure when every native scenario succeeds', () => {
    const r = nativeEvalArtifact()
    r.metrics.adversarialPassRate = 0.95
    expect(() => snapshotSchema(r, 'evals')).toThrow()
  })
  it('rejects a fractional native schema/hallucination numerator', () => {
    const r = nativeEvalArtifact()
    r.metrics.schemaFailureRate = r.metrics.hallucinationRate = 0.001
    expect(() => snapshotSchema(r, 'evals')).toThrow('eval_integral_numerator')
  })
  it('rejects fractional policy count even inside a reason-derived interval', () => {
    const r = evalReport()
    r.failures = [{ scenarioId: 'inert', reasons: ['escalation_mismatch'] }]
    r.metrics.taskSuccessRate = r.metrics.humanEscalationAccuracy = 0.99
    r.metrics.policyViolationRate = 0.001
    expect(() => snapshotSchema(r, 'evals')).toThrow('eval_integral_numerator')
  })
  it('binds the native failed case to its actual adversarial group', () => {
    const r = nativeEvalArtifact()
    r.failures = [
      { scenarioId: 'EV-001', reasons: ['intent_mismatch:synthetic'] }
    ]
    r.metrics.taskSuccessRate = 55 / 56
    r.metrics.adversarialPassRate = 0.95
    expect(() => snapshotSchema(r, 'evals')).toThrow(
      'eval_native_projection:adversarialPassRate'
    )
  })
  it('accepts a legitimate native ordinary failure below the tolerance', () => {
    const r = nativeEvalArtifact()
    r.failures = [
      { scenarioId: 'EV-001', reasons: ['intent_mismatch:synthetic'] }
    ]
    r.metrics.taskSuccessRate = 55 / 56
    expect(() => snapshotSchema(r, 'evals')).not.toThrow()
  })
  it('rejects unknown failed case IDs in the collected core corpus', () => {
    const r = nativeEvalArtifact()
    r.failures = [
      { scenarioId: 'unknown', reasons: ['intent_mismatch:synthetic'] }
    ]
    r.metrics.taskSuccessRate = 55 / 56
    expect(() => snapshotSchema(r, 'evals')).toThrow('eval_failure_membership')
  })
  it('keeps the native empty adversarial group rate at one', () => {
    const r = evalReport()
    r.failures = [
      { scenarioId: 'inert', reasons: ['intent_mismatch:synthetic'] }
    ]
    r.metrics.taskSuccessRate = 0.99
    expect(() => snapshotSchema(r, 'evals')).not.toThrow()
    r.metrics.adversarialPassRate = 0.991
    expect(() => snapshotSchema(r, 'evals')).toThrow()
  })
})
