import {prepareVariant} from './work/scripts/hiso-variant.mjs'
console.log(prepareVariant(import.meta.dirname+'/work',import.meta.dirname+'/public-build','harness-neutral'))
