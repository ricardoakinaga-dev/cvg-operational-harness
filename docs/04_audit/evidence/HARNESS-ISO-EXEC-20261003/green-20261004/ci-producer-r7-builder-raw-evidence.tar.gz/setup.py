import os,json,pathlib,hashlib,shutil
B=pathlib.Path('/home/ricardo/.cache/cvg-harness-green-20261004'); O=B/'ci-producer-r7-builder'; S=B/'candidate'; C=B/'ci-producer-r7-candidate'; R=pathlib.Path('/home/ricardo/Área de trabalho/cvg-operational-harness')
def private(n): return n=='.env' or n.startswith('.env.') and n!='.env.example'
def snapshot(root):
 rows=[]; excluded=[]
 for p,ds,fs in os.walk(root,followlinks=False):
  ds.sort(); fs.sort()
  for n in list(ds):
   f=pathlib.Path(p)/n
   if n=='.git' or private(n): ds.remove(n); excluded.append(str(f.relative_to(root)))
   elif f.is_symlink(): ds.remove(n); rows.append({'path':str(f.relative_to(root)),'link':os.readlink(f)})
  for n in fs:
   f=pathlib.Path(p)/n; rel=str(f.relative_to(root))
   if private(n): excluded.append(rel); continue
   st=f.lstat(); row={'path':rel,'inode':st.st_ino,'size':st.st_size,'mtimeNs':st.st_mtime_ns,'mode':st.st_mode}
   if f.is_symlink(): row['link']=os.readlink(f)
   elif f.is_file(): row['sha256']=hashlib.sha256(f.read_bytes()).hexdigest()
   else: row['special']=True
   rows.append(row)
 rows.sort(key=lambda r:r['path'])
 return {'root':str(root),'excludedPrivateAndGit':excluded,'files':rows,'sha256':hashlib.sha256(json.dumps(rows,sort_keys=True).encode()).hexdigest()}
def save(n,v): (O/n).write_text(json.dumps(v,indent=2)+'\n')
if __name__=='__main__':
 assert not C.exists()
 save('claim.json',{'task':'CI_PRODUCER_PARITY_R7','sourceReadonly':str(S),'rootReadonly':str(R),'candidate':str(C),'output':str(O),'paths':['scripts/hiso-contract.mjs','scripts/hiso-ci.mjs','scripts/hiso-reports.mjs','scripts/hiso-snapshot-types.mjs','tests/hiso-effective-inputs-own.test.js','tests/hiso-snapshot-membership-own.test.js'],'rootLedgers':'Lead','authorization':'user explicit + registered Lead claim/T2'})
 for name,root in [('source-before.json',S),('root-before.json',R)]: save(name,snapshot(root))
 def ignore(p,ns):
  return [n for n in ns if private(n) or n=='.git' or n in ['coverage','test-results','playwright-report','blob-report','certification','.vite'] or n.endswith('.log')]
 # No symlink outside Source is read or copied; every dependency is dereferenced physically.
 for p,ds,fs in os.walk(S,followlinks=False):
  ds[:]=[d for d in ds if d not in ignore(p,ds)]
  for n in ds+fs:
   f=pathlib.Path(p)/n
   if f.is_symlink(): assert f.resolve().is_relative_to(S),str(f)
 shutil.copytree(S,C,symlinks=False,ignore=ignore)
 for d in ['home','tmp','cache','raw','patches']: (O/d).mkdir()
 save('candidate-before.json',snapshot(C))
 print('physical copy and inventories complete')
