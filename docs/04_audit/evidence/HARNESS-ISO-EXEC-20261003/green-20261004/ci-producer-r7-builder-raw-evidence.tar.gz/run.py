import pathlib,json,subprocess,time,sys,fcntl
O=pathlib.Path(__file__).parent; C=O.parent/'ci-producer-r7-candidate'; N='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node'
def run(name,args,cwd=C):
 env={'HOME':str(O/'home'),'TMPDIR':str(O/'tmp'),'XDG_CACHE_HOME':str(O/'cache'),'npm_config_cache':str(O/'cache/npm'),'PATH':str(pathlib.Path(N).parent)+':/usr/bin:/bin'}
 argv=['env','-i']+[k+'='+v for k,v in env.items()]+[N]+args
 t=time.time(); r=subprocess.run(argv,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (O/'raw'/f'{name}.log').write_bytes(r.stdout)
 p=O/'raw/commands.json'
 with (O/'raw/commands.lock').open('w') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  v=json.loads(p.read_text()) if p.exists() else []; v.append({'id':name,'argv':argv,'cwd':str(cwd),'exitCode':r.returncode,'seconds':time.time()-t,'log':f'raw/{name}.log'}); p.write_text(json.dumps(v,indent=2)+'\n')
 print(name,r.returncode,r.stdout.decode(errors='replace')[-1500:]);return r.returncode
if __name__=='__main__':sys.exit(run(sys.argv[1],sys.argv[2:]))
