import fs from 'node:fs'
import path from 'node:path'
import {pathToFileURL} from 'node:url'
const O=import.meta.dirname, C=path.join(O,'../ci-producer-r7-candidate'), phase=process.argv[2]
const reports=await import(pathToFileURL(C+'/scripts/hiso-reports.mjs'))
const ci=await import(pathToFileURL(C+'/scripts/hiso-ci.mjs'))
const {caseOccurrences}=await import(pathToFileURL(C+'/scripts/hiso-inventory.mjs'))
const {nativeEvalArtifact}=await import(pathToFileURL(C+'/tests/fixtures/hiso-r6-measurement.mjs'))
const raw=O+'/raw', rows=[]
const capture=(label,fn)=>{try{const v=fn();rows.push({label,status:'ACCEPTED',result:v})}catch(e){rows.push({label,status:'REJECTED',error:e.message,stack:e.stack})}}
const binding={runId:'synthetic-r7',candidateId:'a'.repeat(64)}
const working=raw+'/inert-'+phase;fs.mkdirSync(working,{recursive:true})
const admit=(gate,report,inventory=[])=>{fs.writeFileSync(working+'/report.json',JSON.stringify(report,null,2));if(ci.validateReport)return ci.validateReport({id:gate,artifacts:['report.json'],skipPolicy:'none'},working,binding,'',inventory);reports.snapshotSchema(report,gate);if(gate==='postgres-version'){if(!(report.status==='PASS'&&report.version>=160000&&report.version<170000&&report.runId===binding.runId&&report.candidateId===binding.candidateId))throw Error('hiso:postgres_version_binding');return 'EXACT_R6_PREDICATE'}return reports.testReport(report,[...new Set(report.testResults.map(f=>path.relative(working,f.name)))],'none')}
for(const version of [160000,169999,'160000',160000.5,159999,170000,NaN,Infinity]){
 const report={schemaVersion:1,status:'PASS',version,...binding};capture('pg-schema-'+String(version),()=>reports.snapshotSchema(report,'postgres-version'));capture('pg-producer-'+String(version),()=>admit('postgres-version',report))
}
for(const kind of ['native','adversarial-impossible','fractional-schema']){const r=nativeEvalArtifact();if(kind==='adversarial-impossible')r.metrics.adversarialPassRate=.95;if(kind==='fractional-schema')r.metrics.schemaFailureRate=r.metrics.hallucinationRate=.001;fs.writeFileSync(raw+'/'+phase+'-eval-'+kind+'.json',JSON.stringify(r,null,2));capture('eval-'+kind,()=>reports.snapshotSchema(r,'evals'))}
const collected=JSON.parse(fs.readFileSync('/home/ricardo/.cache/cvg-harness-green-20261004/ci-review-r6-staging/output/raw/collected-case-inventory.json'))
const inventory=Array.isArray(collected)?collected:collected.testInventory
for(const gate of ['postgres','chaos']){
 const required=reports.gateTestInventory(gate,inventory), files=[...new Set(required.map(t=>t.file))]
 const native=rs=>({success:true,numTotalTests:rs.length,numPassedTests:rs.length,numFailedTests:0,numFailedTestSuites:0,testResults:files.filter(f=>rs.some(t=>t.file===f)).map(f=>({name:working+'/'+f,status:'passed',assertionResults:rs.filter(t=>t.file===f).map(t=>({ancestorTitles:t.name.split(' > ').slice(0,-1),title:t.name.split(' > ').at(-1),status:'passed'}))}))})
 for(const kind of ['complete','omit-case','omit-suite','identity','duplicate','pending']){let rr=[...required].reverse();if(kind==='omit-case')rr=rr.slice(1);if(kind==='omit-suite')rr=rr.filter(t=>t.file!==files[0]);const r=native(rr);if(kind==='identity')r.testResults[0].assertionResults[0].title='inert-alternate';if(kind==='duplicate'){r.testResults[0].assertionResults.push({...r.testResults[0].assertionResults[0]});r.numTotalTests++;r.numPassedTests++}if(kind==='pending'){r.testResults[0].assertionResults[0].status='pending';r.numPassedTests--}
 fs.writeFileSync(raw+'/'+phase+'-'+gate+'-'+kind+'.json',JSON.stringify(r,null,2));capture(gate+'-producer-'+kind,()=>admit(gate,r,inventory));const p='gate-outputs/'+gate+'/report.json';fs.mkdirSync(path.dirname(working+'/'+p),{recursive:true});fs.writeFileSync(working+'/'+p,JSON.stringify(r));capture(gate+'-verifier-'+kind,()=>reports.verifySnapshots({gate:{id:gate,skipPolicy:'none'},entry:{outputs:[{path:p}]},directory:working,manifest:{testInventory:inventory},expected:{}}))
 }
 rows.push({gate,files:files.length,cases:required.length})
}
fs.writeFileSync(raw+'/'+phase+'-probes.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows.map(({label,status,error,gate,files,cases})=>({label,status,error,gate,files,cases})),null,2))
