import fs from 'node:fs'
import path from 'node:path'
import {CORE_EVAL_DATASET} from '../ci-producer-r7-candidate/packages/agent-evals/src/datasets/core.ts'
import {computeMetrics} from '../ci-producer-r7-candidate/packages/agent-evals/src/metrics.ts'
import {snapshotSchema,gateTestInventory,verifySnapshots} from '../ci-producer-r7-candidate/scripts/hiso-reports.mjs'
import {validateReport,snapshotOutputs} from '../ci-producer-r7-candidate/scripts/hiso-ci.mjs'
const O=import.meta.dirname, rows=[],capture=(label,fn)=>{try{rows.push({label,status:'ACCEPTED',result:fn()})}catch(e){rows.push({label,status:'REJECTED',error:e.message,stack:e.stack})}}
const thresholds=JSON.parse(fs.readFileSync(O+'/work/packages/agent-evals/src/eval-thresholds.json'))
for(const fail of [null,'REF-001','REF-035']){
 const results=CORE_EVAL_DATASET.map(t=>({scenarioId:t.id,adversarial:t.adversarial===true,success:t.id!==fail,failures:t.id===fail?['intent_mismatch:synthetic']:[],outcome:{structuredValid:true,escalation:'handoff',proposedCapabilities:[],latencyMs:1,costUsd:0}}))
 const report={suiteId:'phase10-core-v1',agentId:'deterministic-eval-agent-v1',startedAt:'2026-10-05T00:00:00.000Z',finishedAt:'2026-10-05T00:00:01.000Z',metrics:computeMetrics(results),thresholds,verdict:'PASS',failures:results.filter(t=>!t.success).map(t=>({scenarioId:t.scenarioId,reasons:t.failures}))}
 capture('native-metrics-48-'+fail,()=>snapshotSchema(report,'evals'))
 if(fail==='REF-035'){report.metrics.adversarialPassRate=1;capture('native-metrics-48-adversarial-group-contradiction',()=>snapshotSchema(report,'evals'))}
}
const manifest=JSON.parse(fs.readFileSync(O+'/freeze-cli/expected.json'))
const prior=JSON.parse(fs.readFileSync('/home/ricardo/.cache/cvg-harness-green-20261004/ci-review-r6-staging/output/raw/collected-case-inventory.json'))
for(const id of ['postgres','chaos']){
 const now=gateTestInventory(id,manifest.testInventory),was=gateTestInventory(id,Array.isArray(prior)?prior:prior.testInventory)
 rows.push({label:id+'-actual-collected-identity',files:new Set(now.map(t=>t.file)).size,cases:now.length,idsUnchanged:JSON.stringify(now.map(t=>t.id).sort())===JSON.stringify(was.map(t=>t.id).sort()),execution:'NOT_RUN'})
 const working=O+'/raw/inert-final',report=JSON.parse(fs.readFileSync(O+'/raw/final-'+id+'-complete.json'))
 fs.writeFileSync(working+'/report.json',JSON.stringify(report)); const gate={id,artifacts:['report.json'],skipPolicy:'none'},binding={runId:'synthetic-r7',candidateId:'a'.repeat(64)},out=O+'/raw/emission-'+id
 capture(id+'-admit-snapshot-verify',()=>{validateReport(gate,working,binding,'',manifest.testInventory);const outputs=snapshotOutputs(working,out,gate);return verifySnapshots({gate,entry:{outputs},directory:out,manifest,expected:{}})})
 const omit=JSON.parse(fs.readFileSync(O+'/raw/final-'+id+'-omit-case.json'));fs.writeFileSync(working+'/report.json',JSON.stringify(omit));capture(id+'-reject-before-snapshot',()=>{validateReport(gate,working,binding,'',manifest.testInventory);return snapshotOutputs(working,O+'/raw/rejected-emission-'+id,gate)})
 rows.push({label:id+'-no-rejected-snapshot-directory',pass:!fs.existsSync(O+'/raw/rejected-emission-'+id)})
}
fs.writeFileSync(O+'/raw/final-data-proof.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows.map(({label,status,error,files,cases,idsUnchanged,pass})=>({label,status,error,files,cases,idsUnchanged,pass})),null,2))
