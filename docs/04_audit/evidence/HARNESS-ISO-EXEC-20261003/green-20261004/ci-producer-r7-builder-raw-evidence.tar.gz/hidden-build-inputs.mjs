import fs from 'node:fs'
import path from 'node:path'
import {sourceFiles,digest} from './public-build/scripts/hiso-contract.mjs'
const root=import.meta.dirname+'/public-build', baseline=digest(sourceFiles(root)),rows=[]
for(const p of ['packages/shared/dist/r7-inert.mjs','packages/shared/src/.gauntlet/dist/r7-inert.mjs','certification/logs/nested/r7-inert.mjs','packages/shared/dist/r7-unknown.tsbuildinfo']){
 const f=path.join(root,p);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,p.endsWith('.mjs')?'export const label=1;':'{"label":1}');const first=digest(sourceFiles(root));fs.writeFileSync(f,p.endsWith('.mjs')?'export const label=2;':'{"label":2}');const second=digest(sourceFiles(root));rows.push({path:p,included:sourceFiles(root).some(r=>r.path===p),baseline,first,second,changesHash:first!==baseline&&first!==second});fs.unlinkSync(f)
}
fs.writeFileSync(import.meta.dirname+'/raw/hidden-build-inputs.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows,null,2))
