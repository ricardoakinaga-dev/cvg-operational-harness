# R21 — REJECT do reparo

O reparo R19/R20 mantém um defeito concreto de consulta sem binding lexical: `BindingElement.propertyName` em `length: length2` ainda solicita `getSymbolAtLocation`. No TypeScript instalado (SHA-256 `569177652966bd528c319171c7dd22860dbf72bde116cbc4f644f1d02bb12e39`), posição **4023392**, linha81351 coluna33, a consulta gera stack exhaustion e `UNAVAILABLE_LEXICAL_BINDING_ANALYSIS`. É um **falso INCOMPLETE**, sem evidência de falso PASS.

O caminho independente está em `isHost` (`check-product-boundary.mjs:898`), chamado para cada runtime node na linha1146 antes da guarda `isDeclarationName` da linha1334. `boundary-lexical.mjs:187–196` exclui apenas nomes de PropertyAccess/MetaProperty; a consulta restante ocorre na linha213. O contador próprio confirma a consulta ao rótulo `length`, enquanto `length2` mantém a declaração real. A integração inerte com RangeError controlado no rótulo passa de PASS para INCOMPLETE por arquivo. Nenhum candidato foi modificado para essa reprodução.

- **1245/1245** testes passaram, zero failed/pending/todo: originais1185 + manifestos38 + novos22. Sem filtro por nome nem skips. Witnesses Node originais usaram apenas fixtures sintéticas autorizadas.
- **32/32** controles próprios passaram após correção de um erro de montagem da sonda, cuja tentativa falha foi preservada. Negativos incluem binding, shorthand, local export, parameter, CJS, namespace, constructor e nomes computados.
- Exact-file `type.flags`, posição2725992: **RangeError antes**, **NON_LEXICAL depois**, receptor `type` preservado como VariableDeclaration.
- Os quatro tipos de consulta necessários preservam identidade indeterminada distinta de global. Integração: stack RangeError exato produz INCOMPLETE por arquivo; TypeError, outro RangeError e erro do callback propagam.
- Os **371 testes originais** coincidem com hashes registrados; todos os **411 arquivos de teste** físicos da base também foram preservados. Nenhuma asserção removida ou confiança ampla adicionada.
- Clone físico independente, **48 links internos originais**, destinos idênticos, zero hardlinks compartilhados. A menção anterior a47 era contagem textual incorreta; o perfil real foi mantido. Somente3 overlays congelados; Source/deps preservados, exceto cache derivado do Vitest. Originais e hashes R20 intactos.

CLI instalado independente: **INCOMPLETE**, exit `1`, 878.39s. Contagens: `{"diagnostics": 8883, "violations": 0, "sourceFiles": 8065, "coreFiles": 593, "workspaceCount": 26, "edgeCount": 41873}`. Perfil com48 links, Node22.23.2, argv/cwd/ambiente explícito e hashes de Node/checker/helper/deps registrados no receipt. Raw stdout/stderr preservados, sem aceitar dependências desconhecidas ou inferir release.

Evidências: [report.json](report.json), [achado](finding-R21-F1.json), [suite](suite1245.json), [integridade](integrity.json), [antes exato](attempts/exact-file-before/stdout.log), [depois exato](attempts/exact-file-after/stdout.log), [contador](attempts/label-counter/stdout.log), [caller](attempts/label-caller-per-file/stdout.log), [fallback integrado](attempts/fault-per-file-integration-corrected/stdout.log), [CLI raw](attempts/actual-installed-original-links/stdout.log), [CLI receipt](attempts/actual-installed-original-links/receipt.json).

Próxima ação: reparo separado e limitado ao rótulo sem binding, com regressão que preserve `item.name`, nomes computados, shorthand e referências lexicais reais. Metadata da nova file R20 pertence ao Lead. Este veredito avalia o reparo; não fecha a frontier, não decide unknowns e não libera produção.
