import subprocess,json,time,hashlib,os
from pathlib import Path
p=Path(__file__).resolve().parents[1];c=p/'candidate';o=p/'output';node='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node'
env={'PATH':str(Path(node).parent)+':/usr/bin:/bin','HOME':str(o/'home'),'TMPDIR':str(o/'tmp'),'LANG':'C.UTF-8','TZ':'UTC','CVG_MANIFEST_RUNTIME_PROOF_DIR':str(o/'manifest-proofs')}
for d in ['home','tmp','attempts','manifest-proofs']:(o/d).mkdir(exist_ok=True)
def sha(a):return hashlib.sha256(Path(a).read_bytes()).hexdigest()
def run(label,args,cwd=c,timeout=900):
 d=o/'attempts'/label;d.mkdir(parents=True,exist_ok=True);start=time.time();receipt={'argv':[node]+args,'cwd':str(cwd),'environment':env,'nodeSha256':sha(node),'startUnix':start,'timeoutSeconds':timeout,'inputHashes':{str(a):sha(a) for a in [c/'scripts/check-product-boundary.mjs',c/'scripts/boundary-lexical.mjs',c/'scripts/boundary-manifests.mjs',c/'scripts/boundary-code-execution.mjs',c/'node_modules/typescript/lib/typescript.js',c/'vitest.config.mts'] if a.exists()}}
 (d/'receipt-start.json').write_text(json.dumps(receipt,indent=2)+'\n')
 with (d/'stdout.log').open('w') as stdout,(d/'stderr.log').open('w') as stderr:
  try:r=subprocess.run([node]+args,cwd=cwd,env=env,stdout=stdout,stderr=stderr,timeout=timeout);receipt['exitCode']=r.returncode
  except subprocess.TimeoutExpired:receipt['exitCode']=None;receipt['timeout']=True
 receipt['elapsedSeconds']=time.time()-start;(d/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(label,receipt.get('exitCode'),receipt['elapsedSeconds'],flush=True)
 return receipt
if __name__=='__main__':
 run('suite1245',['node_modules/vitest/vitest.mjs','run','tests/product-boundary.test.js','tests/product-boundary-code-execution.test.js','tests/product-boundary-lexical-static.test.js','tests/product-boundary-manifest-runtime.test.js','tests/product-boundary-binding-query.test.js','--no-file-parallelism','--maxWorkers=1','--reporter=json','--outputFile='+str(o/'suite1245.json')])
 run('actual-installed-original-links',['scripts/check-product-boundary.mjs',str(c)])
