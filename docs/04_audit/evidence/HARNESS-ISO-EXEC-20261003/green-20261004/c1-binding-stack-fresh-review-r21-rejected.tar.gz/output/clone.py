from pathlib import Path
import json, shutil,hashlib,os
p=Path(__file__).resolve().parents[1];f=json.loads((p/'freeze.json').read_text());src=Path(f['original']);overlay=Path(f['sourceOverlay']);dest=p/'candidate'
def inventory(root):
 out={}
 for base,ds,fs in os.walk(root,followlinks=False):
  for n in ds+fs:
   a=Path(base)/n;rel=a.relative_to(root).as_posix();st=a.lstat()
   if a.is_symlink():out[rel]={'kind':'symlink','target':os.readlink(a),'mode':st.st_mode&0o777,'internal':a.resolve().is_relative_to(root.resolve())}
   elif a.is_file():
    with a.open('rb') as stream:h=hashlib.file_digest(stream,'sha256').hexdigest()
    out[rel]={'kind':'file','size':st.st_size,'sha256':h,'mode':st.st_mode&0o777}
 return out
if __name__=='__main__':
 assert not dest.exists()
 before=inventory(src);links=[k for k,v in before.items() if v['kind']=='symlink'];assert all(before[k]['internal'] for k in links)
 for rel,h in f['paths'].items():assert hashlib.sha256((overlay/rel).read_bytes()).hexdigest()==h
 (p/'output/original-inventory-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
 shutil.copytree(src,dest,symlinks=True);assert inventory(dest)==before
 for rel in f['paths']:
  (dest/rel).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(overlay/rel,dest/rel)
 after=inventory(dest);changed=[k for k in sorted(set(before)|set(after)) if before.get(k)!=after.get(k)];assert changed==sorted(f['paths'])
 shared=[k for k in before if before[k]['kind']=='file' and (src/k).stat().st_ino==(dest/k).stat().st_ino];assert not shared
 (p/'output/candidate-inventory-before.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
 (p/'output/clone-receipt.json').write_text(json.dumps({'original':str(src),'overlay':str(overlay),'destination':str(dest),'symlinks':links,'linkCount':len(links),'allInternal':True,'baseBytesAndModesIdentical':True,'changedPaths':changed,'hardlinkedFiles':shared,'fileCount':sum(v['kind']=='file' for v in after.values()),'bytes':sum(v.get('size',0) for v in after.values()),'profileDiscrepancy':'authority says47; physical source has48; all preserved'},indent=2)+'\n')
 print('Verified physical clone:',len(links),'internal links;',len(after),'entries;',changed,flush=True)
