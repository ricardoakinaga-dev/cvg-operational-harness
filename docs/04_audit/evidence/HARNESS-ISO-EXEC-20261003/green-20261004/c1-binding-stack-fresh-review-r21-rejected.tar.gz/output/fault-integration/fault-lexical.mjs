export * from './boundary-lexical.mjs';
import {createBoundaryLexical as real} from './boundary-lexical.mjs';
export function createBoundaryLexical(ts,source,commonJs,callback){
 const facade={...ts,createProgram(...args){const checker=ts.createProgram(...args).getTypeChecker();return{getTypeChecker:()=>new Proxy(checker,{get(t,k){if(k==='getSymbolAtLocation')return n=>{if(source.fileName.endsWith('/entry.mts')&&n.text==='bridge'&&ts.isExpressionStatement(n.parent)){throw globalThis.__ownReviewFault}return t[k](n)};return t[k]}})}}};
 return real(facade,source,commonJs,callback);
}
