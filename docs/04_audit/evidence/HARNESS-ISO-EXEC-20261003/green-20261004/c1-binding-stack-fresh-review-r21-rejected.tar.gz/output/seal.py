from pathlib import Path
import hashlib,json,datetime,os
from clone import inventory
p=Path(__file__).resolve().parents[1];o=p/'output';r=json.loads((o/'report.json').read_text());assert r['verdict']=='REJECT'
rows=inventory(p)
excluded=['output/hashmanifest.json','output/FROZEN.json']
for x in excluded:rows.pop(x,None)
manifest={'packet':str(p),'algorithm':'SHA-256','excludedSealFiles':excluded,'kind':'R21 physical packet inputs/evidence hash manifest','entries':rows}
(o/'hashmanifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
sha=lambda a:hashlib.sha256(a.read_bytes()).hexdigest()
seal={'task':r['task'],'state':'FROZEN','verdict':r['verdict'],'scope':r['verdictScope'],'sealedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'hashmanifest':{'path':'output/hashmanifest.json','sha256':sha(o/'hashmanifest.json'),'entries':len(rows)},'authoritySha256':sha(p/'authority.json'),'freezeSha256':sha(p/'freeze.json'),'reportJsonSha256':sha(o/'report.json'),'reportMdSha256':sha(o/'report.md'),'integritySha256':sha(o/'integrity.json'),'originalLinkCount':48,'mode':'hash-bound freeze; no further packet writes after seal; source file modes preserved','hashmanifestExcluded':excluded,'CLI':r['installedCLI']['status']}
(o/'FROZEN.json').write_text(json.dumps(seal,indent=2)+'\n');print(json.dumps(seal,indent=2),flush=True)
