import os,json,gzip,hashlib,re,difflib
from pathlib import Path
from collections import Counter
out=Path(__file__).parent;raw=out/'raw';src=out.parent/'candidate';dst=out.parent/'ci-raw-critical-r9-candidate'
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def read(p):return json.loads(p.read_text())
def inventory(root):
 rows=[]
 for parent,dirs,files in os.walk(root,followlinks=False):
  for p in [Path(parent)]+[Path(parent)/n for n in files]+[Path(parent)/n for n in dirs if (Path(parent)/n).is_symlink()]:
   s=p.lstat();r={'path':str(p.relative_to(root)),'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'nlink':s.st_nlink,'uid':s.st_uid,'gid':s.st_gid,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns}
   if p.is_symlink():r['link']=os.readlink(p)
   elif p.is_dir():r['members']=sorted(os.listdir(p))
   elif p.name=='.env' or (p.name.startswith('.env.') and p.name not in ['.env.example','.env.sample','.env.template']):r['private']='metadata-only'
   else:
    with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOATIME),'rb') as f:r['sha256']=hashlib.file_digest(f,'sha256').hexdigest()
   rows.append(r)
 return sorted(rows,key=lambda r:r['path'])
with gzip.open(out/'source-before.json.gz','rt') as f:before=json.load(f)
after=inventory(src)
with gzip.open(out/'source-after.json.gz','wt',compresslevel=9) as f:json.dump(after,f,indent=2);f.write('\n')
a={r['path']:r for r in before};b={r['path']:r for r in after}
proof={'status':'PASS' if before==after else 'FAIL','entriesBefore':len(before),'entriesAfter':len(after),'changed':sorted(p for p in a.keys()&b.keys() if a[p]!=b[p]),'added':sorted(b.keys()-a.keys()),'removed':sorted(a.keys()-b.keys()),'beforeSha256':sha(json.dumps(before,sort_keys=True).encode()),'afterSha256':sha(json.dumps(after,sort_keys=True).encode()),'compared':'Every Source file content hash, symlink target, directory membership and dev/ino/mode/nlink/uid/gid/size/mtime_ns/ctime_ns, including .git,node_modules,dist. Private env metadata-only if present; atime excluded as read effect. O_NOATIME hashing. Full lists preserved losslessly gzip.'}
write(out/'source-integrity.json',proof);assert proof['status']=='PASS',proof
allowed=['scripts/lib/coverage-gate.mjs','scripts/hiso-ci.mjs','scripts/hiso-reports.mjs','scripts/hiso-snapshot-types.mjs','tests/hiso-snapshot-membership-own.test.js']
oldinputs=read(raw/'before-native-inputs.json');newinputs=read(raw/'after-native-inputs.json');old={r['path']:r for r in oldinputs};new={r['path']:r for r in newinputs};assert old.keys()==new.keys()
changed=sorted(p for p in old if old[p]!=new[p]);assert changed==sorted(allowed)
changes=[];patch=''
for p in allowed:
 beforebytes=(src/p).read_bytes();afterbytes=(dst/p).read_bytes()
 assert sha(afterbytes)==new[p]['sha256']
 changes.append({'path':p,'beforeSha256':sha(beforebytes),'afterSha256':sha(afterbytes),'beforeSize':len(beforebytes),'afterSize':len(afterbytes)})
 patch+=''.join(difflib.unified_diff(beforebytes.decode().splitlines(keepends=True),afterbytes.decode().splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p))
(out/'changes.patch').write_text(patch)
baseline=read(src/'scripts/hiso-baseline-inventory.json');orig_mismatches=[];new_changes=[]
for r in baseline['tests']:
 beforebytes=(src/r['path']).read_bytes();afterbytes=(dst/r['path']).read_bytes()
 if beforebytes!=afterbytes or sha(beforebytes)!=r['sha256'] or len(beforebytes)!=r['size']:orig_mismatches.append(r['path'])
for r in baseline['newTests']:
 p=r if isinstance(r,str) else r['path']
 if (src/p).read_bytes()!=(dst/p).read_bytes():new_changes.append(p)
assert len(baseline['tests'])==371 and not orig_mismatches
assert len(baseline['newTests'])==43 and new_changes==[allowed[-1]]
oldpaths=sorted(p for p in old if re.search(r'\.test\.(ts|tsx|js)$',p));newpaths=sorted(p for p in new if re.search(r'\.test\.(ts|tsx|js)$',p));assert oldpaths==newpaths
approved=set(r['path'] for r in baseline['tests'])|set(r if isinstance(r,str) else r['path'] for r in baseline['newTests'])
runtimepaths=sorted(p for p in old if p.split('/')[0] in ['tests','packages','legacy','apps','products'] and re.search(r'\.(test|spec)\.(ts|tsx|js)$',p))
assert set(runtimepaths)==approved and len(runtimepaths)==414
prefix=(src/allowed[-1]).read_bytes();current=(dst/allowed[-1]).read_bytes();assert current.startswith(prefix)
schema=lambda root:(root/'scripts/hiso-snapshot-types.mjs').read_text().split('function coverageSemantics(report) {')[0]
run_scope=lambda root:(root/'scripts/hiso-ci.mjs').read_text().split('export function runScope(')[1]
assert schema(src)==schema(dst) and run_scope(src)==run_scope(dst)
protected=['scripts/hiso-baseline-inventory.json','scripts/hiso-ci-scopes.json','scripts/critical-coverage-manifest.json','scripts/ci-bar-contract.mjs','scripts/hiso-contract.mjs','scripts/hiso-variant.mjs','scripts/hiso-postgres-version.mjs','package.json','package-lock.json','vitest.config.mts','packages/agent-evals/src/eval-thresholds.json']
for p in protected:assert (src/p).read_bytes()==(dst/p).read_bytes(),p
preservation={'original371':{'count':371,'exactSourceAndManifest':True,'mismatches':[]},'approvedNew43':{'count':43,'changedOnlyExistingOwnPath':new_changes,'other42ExactSource':True},'totalTestPaths':{'approvedBefore':414,'approvedAfter':414,'runtimePrefixTestOrSpecPaths':len(runtimepaths),'allNativeTestSuffixPathsBefore':len(oldpaths),'allNativeTestSuffixPathsAfter':len(newpaths),'unchanged':True,'definition':'Approved371+43 include7 E2E spec paths. Native filesystem test suffix count430 also includes23 opaque historical doc/evidence copies. No copied historical test executed.'},'prefix113':{'byteExact':True,'bytes':len(prefix),'sha256':sha(prefix),'appendedBytes':len(current)-len(prefix)},'publicSnapshotSchemaDefinitions':{'byteExact':True,'sha256':sha(schema(src).encode())},'runScopeSelectionAndDownstreamChecks':{'byteExact':True,'sha256':sha(run_scope(src).encode())},'protected':[{'path':p,'sha256':sha((src/p).read_bytes())} for p in protected]}
write(out/'preservation.json',preservation)
def membership(phase):
 report=read(raw/f'{phase}-vitest.json');collection=read(raw/f'{phase}-collected.json');rows=[];seen=Counter();colrows=[];colseen=Counter()
 for f in report['testResults']:
  file=str(Path(f['name']).relative_to(dst))
  for t in f['assertionResults']:
   name=' > '.join(t['ancestorTitles']+[t['title']]);seen[file,name]+=1;rows.append({'file':file,'name':name,'occurrence':seen[file,name],'status':t['status']})
 for t in collection:
  file=str(Path(t['file']).relative_to(dst));name=t['name'];colseen[file,name]+=1;colrows.append({'file':file,'name':name,'occurrence':colseen[file,name]})
 assert all(r['status']=='passed' for r in rows) and report['success']
 assert Counter((r['file'],r['name'],r['occurrence']) for r in rows)==Counter((r['file'],r['name'],r['occurrence']) for r in colrows)
 write(raw/f'{phase}-membership-titles-multiplicity-status.json',{'executed':rows,'collected':colrows,'equalMembership':True,'collectionExecutedTests':0})
 return rows
oldrows=membership('before');newrows=membership('after');key=lambda r:(r['file'],r['name'],r['occurrence']);oldkeys=set(map(key,oldrows));newkeys=set(map(key,newrows));assert oldkeys<=newkeys and len(oldrows)==345 and len(newrows)==378
appended=[r for r in newrows if key(r) not in oldkeys];assert len(appended)==33 and all(r['file']==allowed[-1] for r in appended)
cases={'oldCases':345,'oldAllPassedUnchangedIdentityMultiplicityAndStatus':True,'oldOwnCases':113,'currentOwnCases':146,'appendedCases':appended,'totalCurrent':378,'failed':0,'pending':0,'todo':0,'separatelyCollected':{'before':345,'after':378,'collectionCountsAsExecuted':0,'equalsExecutionMembership':True},'perFile':[{'file':p,'before':sum(r['file']==p for r in oldrows),'after':sum(r['file']==p for r in newrows)} for p in sorted(set(r['file'] for r in oldrows))],'PgMock':{'cases':12,'guardInExactOriginalPrefix':True,'ESMClientIdentityBeforeProducerImport':True,'realPgExecuted':0}}
write(out/'case-preservation.json',cases)
probesbefore=read(raw/'before-semantic-probes.json');probesafter=read(raw/'after-semantic-probes.json');assert len(probesbefore['rows'])==48 and len(probesafter['rows'])==48 and all(r['conforms'] for r in probesafter['rows'])
network=raw/'network-attempts.jsonl';assert not network.exists() or not network.read_text()
checks=[]
for name in ['before-probes','before-tests','before-collection','after-probes','after-tests','after-collection','typecheck','lint','format-write','format-check','input-definitions','input-definitions-current','patch-check','format-governed-write']:
 r=read(raw/f'{name}.execution.json');assert r['exitCode']==0;checks.append({'check':name,'status':'PASS','exitCode':0,'execution':f'raw/{name}.execution.json'})
manifest={'schemaVersion':1,'task':'CI_RAW_CRITICAL_UNIT_MEMBERSHIP_R9','status':'IMPLEMENTED_NOT_ACCEPTED','source':str(src),'privateCandidate':str(dst),'output':str(out),'authority':'Already-claimed short T2 under SPEC0180/BUILD; Root task ci-raw-critical-unit-membership-r9-t2.md read-only; no Root writes','changes':changes,'patch':{'path':'changes.patch','sha256':sha((out/'changes.patch').read_bytes())},'behavior':['Critical producer verdict compares raw aggregate branch covered/total ratio with95, retaining rounded display and report shape.','Snapshot semantics independently checks raw group sums before native reconstruction; schemas/thresholds/critical manifest unchanged.','Unit pre-snapshot producer admission shares exact collected file/name/occurrence/id multiplicity with snapshot verifier for the supplied scope; existing unit skipPolicy remains effective.','Frozen PostgreSQL/chaos selectors/pass-only checks, expected scoped ids, exact executed status projection and runScope downstream checks preserved.'],'verification':checks,'tests':{'before':345,'after':378,'oldPreserved':345,'appended':33,'ownPrefix':113,'ownAfter':146,'passed':378,'failed':0,'pending':0,'todo':0,'collectionIndependent':True},'probes':{'beforeObservations':48,'beforeNonconforming':sum(not r['conforms'] for r in probesbefore['rows']),'afterObservations':48,'afterConforming':48,'rawBeforeFailuresRetained':'raw/before-semantic-probes.json','after':'raw/after-semantic-probes.json','nativeJsonReports':'raw/before-probes/ and raw/after-probes/'},'preservation':'preservation.json','caseEvidence':'case-preservation.json','sourceIntegrity':proof,'sourceInputs':read(raw/'input-count-definitions.json'),'nativeCandidateAfter':{'count':probesafter['nativeInputCount'],'sha256':probesafter['nativeInputHash']},'changedNativeInputsExactly':changed,'physicalCopy':'copy-integrity.json (node_modules/dist retained, .bin links not flattened, no hardlinks/shared inodes)','network':{'guard':'network-guard.cjs','attempts':0,'description':'Inherited Node builtin DNS/socket/TLS/HTTP/HTTPS/fetch deny guard; no kernel syscall isolation proof claimed.'},'assemblyRecovery':'raw/output-assembly-failures.json; only own finished-test tmp cleaned, Source sentinels losslessly gzip; candidate/deps/dist/other agent data preserved.','notRun':['full unit suite','real PostgreSQL','full chaos/eval suites','E2E','V8 coverage','remote CI','certify','SBOM','licenses','provider','Docker'],'limitations':['Implementation only; Lead integration and fresh independent review pending. No release or acceptance.','No Root/Main writes, fixture/config/lock/schema/bar/original371/prefix113 edits; no commit/push/production.','Supplied historical generic7811 frozen path list was not provided; it remains explicitly historical, not a remeasured native or sparse-Git certification count. Source native8400 exactly remeasured; separate certification collector1808 observation retained.'],'nextAction':'Lead checks five before hashes and integrates exact candidate bytes/patch, then requests fresh independent review.'}
write(out/'build-manifest.json',manifest)
write(out/'runtime-state.json',{'task':manifest['task'],'status':'IMPLEMENTED_NOT_ACCEPTED','last_completed_action':'Bounded private fixes with378 native focused tests,48/48 after probes, types/lint/format and preservation checks PASS.','next_action':manifest['nextAction']})
(out/'execution-log.jsonl').open('a').write(json.dumps({'task':manifest['task'],'status':manifest['status'],'beforeTests':345,'afterTests':378,'appendedCases':33,'checks':'PASS','RootWrites':0,'acceptance':'PENDING_FRESH_REVIEW','assemblyRecovery':manifest['assemblyRecovery']})+'\n')
write(out/'backlog.json',{'task':manifest['task'],'implementation':'DONE_PRIVATE','integration':'PENDING_LEAD','review':'PENDING_FRESH_INDEPENDENT','fullSuitePgE2E':'NOT_RUN','production':'NOT_AUTHORIZED'})
(out/'README.md').write_text('CI_RAW_CRITICAL_UNIT_MEMBERSHIP_R9 — IMPLEMENTED_NOT_ACCEPTED\n\nPrivate candidate: '+str(dst)+'\nFive exact changed paths in build-manifest.json. changes.patch checked read-only against Source. 345 old +33 appended=378 PASS; original371/prefix113 and approved43 paths preserved.\n\nBefore native failures retained; after48/48 conform. Native Source8400 remeasured unchanged. Supplied generic7811 is a distinct historical frozen snapshot observation (path list not supplied); sparse-Git certification1808 is a third observed definition. No forced equality.\n\nLead integrates exact manifested bytes and obtains fresh independent review. Full suite/realPG/E2E/V8/remote/certify NOT_RUN. Source full metadata/hash sentinel PASS; Root/Main writes/network attempts/commits/push=0. Disk-space/evidence assembly failures and recovery retained.\n')
print(json.dumps({'status':manifest['status'],'changed':changed,'tests':378,'appendedCases':33,'sourceIntegrity':'PASS','manifestSha256':sha((out/'build-manifest.json').read_bytes())}))
