import fs from 'node:fs'
import path from 'node:path'
import {
  canonical,
  exact,
  dispatch,
  requireThat,
  safePath,
  VERSION
} from './hiso-contract.mjs'
import { caseOccurrences } from './hiso-inventory.mjs'
import { snapshotTypes } from './hiso-snapshot-types.mjs'
import {
  validateRem21010ProofReport,
  REM21_010_CONTRACT
} from './rem21-010-postgres-proof-contract.mjs'
import {
  validateRem21011ProofReport,
  REM21_011_CONTRACT
} from './rem21-011-observability-proof-contract.mjs'
import {
  validateRem21014BrowserProofReport,
  REM21_014_CONTRACT
} from './rem21-014-browser-proof-contract.mjs'
import {
  validateRuntimeImageManifest,
  RUNTIME_IMAGE_CONTRACT
} from './runtime-image-contract.mjs'
import {
  validateE2eReportPair,
  parseE2eEvidenceLog
} from './lib/e2e-report-binding.mjs'

export function envelope(value, label) {
  requireThat(
    value &&
      typeof value === 'object' &&
      !Array.isArray(value) &&
      value.schemaVersion === 1,
    `schema_version:${label}`
  )
  if (Object.hasOwn(value, 'contract')) {
    dispatch(value.contract)
    requireThat(value.contract === VERSION, `envelope_contract:${label}`)
  }
  return value
}

// Native producers retain their own schemas. Metadata is optional for native
// Vitest/coverage/Playwright, but an explicit version or contract is never ignored.
export function snapshotSchema(report, gateId, outputPath = '') {
  requireThat(
    report && typeof report === 'object' && !Array.isArray(report),
    `snapshot_type:${gateId}`
  )
  const version =
    gateId === 'mutation' || gateId === 'licenses'
      ? 2
      : gateId === 'certify' && outputPath.endsWith('/candidate-manifest.json')
        ? 'aaa-candidate-v1'
        : 1
  if (Object.hasOwn(report, 'schemaVersion'))
    requireThat(report.schemaVersion === version, `schema_version:${gateId}`)
  if (Object.hasOwn(report, 'contract')) {
    const nativeContract = {
      mutation: 'rem21-013-v1',
      'postgres-proof': REM21_010_CONTRACT,
      'observability-proof': REM21_011_CONTRACT,
      'browser-proof': REM21_014_CONTRACT,
      image: RUNTIME_IMAGE_CONTRACT
    }[gateId]
    if (nativeContract)
      requireThat(
        report.contract === nativeContract,
        `snapshot_contract:${gateId}`
      )
    else {
      dispatch(report.contract)
      requireThat(report.contract === VERSION, `snapshot_contract:${gateId}`)
    }
  }
  snapshotTypes(report, gateId, outputPath)
  return report
}

export function canonicalReportPath(input, known) {
  requireThat(typeof input === 'string' && !input.includes('\\'), 'report_path')
  const matches = known.filter((p) => input === p || input.endsWith('/' + p))
  requireThat(matches.length === 1, `report_source_unknown:${input}`)
  return safePath(matches[0])
}

export function testReport(report, known, skipPolicy = 'none') {
  snapshotSchema(report, 'unit')
  requireThat(
    report.success === true &&
      Array.isArray(report.testResults) &&
      report.testResults.length > 0,
    'test_report_not_executed'
  )
  requireThat(
    !['FAIL', 'NOT_RUN', 'SKIP'].includes(report.status) &&
      !['FAIL', 'NOT_RUN'].includes(report.verdict),
    'test_report_not_pass'
  )
  const suiteFiles = report.testResults.map((f) =>
    canonicalReportPath(f.name, known)
  )
  exact(suiteFiles, known, 'test_report_suite_inventory')
  let skipped = 0
  const rows = report.testResults.flatMap((f) => {
    requireThat(
      f.status === 'passed' &&
        Array.isArray(f.assertionResults) &&
        f.assertionResults.length > 0,
      'test_suite_not_pass'
    )
    return f.assertionResults.map((t) => {
      requireThat(
        ['passed', 'pending', 'skipped', 'todo'].includes(t.status),
        'assertion_failed'
      )
      if (t.status !== 'passed') skipped++
      requireThat(
        Array.isArray(t.ancestorTitles) &&
          t.ancestorTitles.every((x) => typeof x === 'string') &&
          typeof t.title === 'string',
        'test_title'
      )
      return {
        file: canonicalReportPath(f.name, known),
        name: [...t.ancestorTitles, t.title].join(' > '),
        status: t.status
      }
    })
  })
  requireThat(
    rows.some((t) => t.status === 'passed'),
    'test_report_empty_execution'
  )
  requireThat(
    report.numFailedTests === 0 &&
      report.numFailedTestSuites === 0 &&
      report.numTotalTests === rows.length &&
      report.numPassedTests ===
        rows.filter((t) => t.status === 'passed').length,
    'test_report_counts'
  )
  const counts = {
    numPendingTests: rows.filter((t) =>
      ['pending', 'skipped'].includes(t.status)
    ).length,
    numTodoTests: rows.filter((t) => t.status === 'todo').length
  }
  for (const [key, count] of Object.entries(counts))
    if (Object.hasOwn(report, key))
      requireThat(
        Number.isSafeInteger(report[key]) && report[key] === count,
        `test_report_counts:${key}`
      )
  // Vitest counts file suites AND nested describes, including empty/duplicate
  // describes that the flattened JSON cannot reconstruct. Validate the additive
  // counters and observable lower bound, rather than equating suites with files.
  const visible = report.testResults.length
  for (const key of [
    'numTotalTestSuites',
    'numPassedTestSuites',
    'numPendingTestSuites'
  ])
    if (Object.hasOwn(report, key))
      requireThat(
        Number.isSafeInteger(report[key]) && report[key] >= 0,
        `test_report_counts:${key}`
      )
  if (
    Object.hasOwn(report, 'numTotalTestSuites') ||
    Object.hasOwn(report, 'numPassedTestSuites')
  ) {
    requireThat(
      report.numTotalTestSuites >= visible &&
        report.numTotalTestSuites ===
          report.numPassedTestSuites +
            report.numFailedTestSuites +
            (report.numPendingTestSuites ?? 0),
      'test_report_suite_counts'
    )
  }
  if (Object.hasOwn(report, 'numPendingTestSuites'))
    requireThat(report.numPendingTestSuites === 0, 'test_report_pending_suites')
  if (skipPolicy === 'none') requireThat(skipped === 0, 'required_skip')
  return caseOccurrences(rows).sort((a, b) =>
    JSON.stringify(a).localeCompare(JSON.stringify(b))
  )
}

export function coverageReport(report, known) {
  snapshotSchema(report, 'coverage')
  requireThat(
    report &&
      typeof report === 'object' &&
      report.total &&
      !report.status &&
      !report.verdict,
    'coverage_report_not_executed'
  )
  const entries = Object.entries(report).filter(
    ([p]) => !['total', 'schemaVersion', 'contract'].includes(p)
  )
  const result = {}
  for (const [p, v] of entries) {
    const name = canonicalReportPath(p, known)
    requireThat(!result[name], 'coverage_duplicate_source')
    result[name] = v
  }
  for (const metric of ['statements', 'branches', 'functions', 'lines']) {
    const sums = Object.values(result).reduce(
      (a, v) => ({
        total: a.total + v[metric]?.total,
        covered: a.covered + v[metric]?.covered,
        skipped: a.skipped + v[metric]?.skipped
      }),
      { total: 0, covered: 0, skipped: 0 }
    )
    for (const k of ['total', 'covered', 'skipped'])
      requireThat(
        report.total[metric]?.[k] === sums[k],
        `coverage_report_total:${metric}:${k}`
      )
  }
  return result
}

// Selectors are read from the frozen producer package, never inferred from a
// passing report. This parser accepts only the two approved Vitest invocations;
// an additional option, shell expression or selector needs an explicit review.
const producerScripts = JSON.parse(
  fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8')
).scripts
export function gateTestInventory(
  gateId,
  inventory,
  scripts = producerScripts
) {
  requireThat(['postgres', 'chaos'].includes(gateId), 'test_selector_gate')
  const command = scripts[`test:${gateId}`]
  requireThat(typeof command === 'string', 'test_selector_script')
  requireThat(
    command === producerScripts[`test:${gateId}`],
    'test_selector_frozen_command'
  )
  const tokens = command.trim().split(/\s+/)
  requireThat(
    tokens.shift() === 'vitest' && tokens.shift() === 'run',
    'test_selector_command'
  )
  const flags =
    gateId === 'postgres'
      ? ['--testTimeout=60000', '--no-file-parallelism']
      : ['--no-file-parallelism', '--maxWorkers=2']
  exact(
    tokens.filter((t) => t.startsWith('--')),
    flags,
    'test_selector_options'
  )
  const selectors = tokens.filter((t) => !t.startsWith('--'))
  selectors.forEach(safePath)
  if (gateId === 'postgres') {
    requireThat(
      selectors.length === 35 &&
        selectors.every((p) =>
          /^(packages|apps|legacy)\/.+\.test\.ts$/.test(p)
        ),
      'test_selector_postgres'
    )
    exact(selectors, [...new Set(selectors)], 'test_selector_duplicates')
    requireThat(
      selectors.every((p) => inventory.some((t) => t.file === p)),
      'test_selector_missing_collection'
    )
  } else exact(selectors, ['packages/chaos'], 'test_selector_chaos')
  const required = inventory.filter((t) =>
    gateId === 'postgres'
      ? selectors.includes(t.file)
      : t.file.startsWith('packages/chaos/')
  )
  requireThat(required.length > 0, 'test_selector_empty')
  return required
}
// Unit callers supply the complete scope-selected collection; other gates use
// the frozen command selectors. Producer and snapshot admission share membership.
export function gateTestReport(report, gate, inventory) {
  requireThat(Array.isArray(inventory), 'required_test_inventory')
  const required =
    gate.id === 'unit' ? inventory : gateTestInventory(gate.id, inventory)
  requireThat(required.length > 0, 'required_test_inventory')
  const rows = testReport(
    report,
    [...new Set(required.map((t) => t.file))],
    gate.skipPolicy
  )
  exact(
    rows.map((t) => t.id),
    required.map((t) => t.id),
    `required_case_inventory_snapshot:${gate.id}`
  )
  const identity = ({ file, name, occurrence }) =>
    canonical({ file, name, occurrence })
  exact(
    rows.map(identity),
    required.map(identity),
    `required_case_inventory_snapshot:${gate.id}`
  )
  if (gate.id !== 'unit')
    requireThat(
      rows.every((t) => t.status === 'passed'),
      `required_case_status:${gate.id}`
    )
  return rows
}
const ordered = (rows) =>
  [...rows].sort((a, b) => canonical(a).localeCompare(canonical(b)))

// Always consume the snapshot bytes after the verifier checks their content seal.
// Native REM21 report schemas keep their original validators; HISO envelopes use v1.
export function verifySnapshots({
  gate,
  entry,
  directory,
  manifest,
  expected
}) {
  const reports = new Map()
  for (const output of entry.outputs) {
    if (!output.path.endsWith('.json')) continue
    const report = JSON.parse(
      fs.readFileSync(path.join(directory, output.path), 'utf8')
    )
    snapshotSchema(report, gate.id, output.path)
    requireThat(
      !['FAIL', 'NOT_RUN', 'SKIP'].includes(report.status) &&
        !['FAIL', 'NOT_RUN'].includes(report.verdict),
      `snapshot_not_pass:${gate.id}`
    )
    reports.set(output.path, report)
  }
  const first = reports.values().next().value
  const binding = { runId: manifest.runId, candidateId: manifest.candidateId }
  if (['unit', 'postgres', 'chaos'].includes(gate.id)) {
    const unit = gate.id === 'unit'
    if (!unit)
      return { tests: gateTestReport(first, gate, manifest.testInventory) }
    const required = expected.requiredTestIds?.length
      ? manifest.testInventory.filter((t) =>
          expected.requiredTestIds.includes(t.id)
        )
      : manifest.executedTestInventory
    requireThat(
      Array.isArray(required) && required.length > 0,
      unit ? 'unit_execution_inventory_snapshot' : 'required_test_inventory'
    )
    const rows = gateTestReport(first, gate, required)
    if (unit) {
      requireThat(
        canonical(ordered(rows)) ===
          canonical(ordered(manifest.executedTestInventory)),
        'unit_execution_inventory_snapshot'
      )
      if (expected.requiredTestIds?.length)
        exact(
          rows.map((t) => t.id),
          expected.requiredTestIds,
          'unit_required_case_inventory_snapshot'
        )
      return { tests: rows }
    }
  }
  if (gate.id === 'coverage') {
    const coverage = coverageReport(first, expected.coveragePaths)
    requireThat(
      canonical(coverage) === canonical(manifest.coverage),
      'coverage_snapshot_projection'
    )
    return { coverage }
  }
  if (gate.id === 'postgres-proof') validateRem21010ProofReport(first, binding)
  if (gate.id === 'observability-proof')
    validateRem21011ProofReport(first, binding)
  if (gate.id === 'browser-proof')
    validateRem21014BrowserProofReport(first, binding)
  if (
    gate.id === 'image' &&
    reports.has('gate-outputs/image/certification/runtime-image.json')
  )
    validateRuntimeImageManifest(first, binding)
  if (['coverage-critical', 'mutation', 'skip', 'evals'].includes(gate.id))
    requireThat(first?.verdict === 'PASS', 'report_verdict')
  if (
    [
      'public-smoke',
      'd009-consumer',
      'image-smoke',
      'postgres-version',
      'inventory'
    ].includes(gate.id)
  ) {
    envelope(first, gate.id)
    if (gate.id !== 'inventory')
      requireThat(first.status === 'PASS', `report_not_pass:${gate.id}`)
    if (gate.id === 'postgres-version')
      requireThat(
        Number.isSafeInteger(first.version) &&
          first.version >= 160000 &&
          first.version < 170000 &&
          first.runId === binding.runId &&
          first.candidateId === binding.candidateId,
        'postgres_version_binding'
      )
    if (['public-smoke', 'd009-consumer'].includes(gate.id))
      requireThat(
        first.sourceFree === true &&
          first.declarations === true &&
          first.clinicalCalls === 0 &&
          first.unknownCalls === 0 &&
          first.budgetDenied === true &&
          first.normalizer === true,
        'public_closure_evidence'
      )
  }
  if (gate.id === 'e2e') {
    const content = (name) =>
      fs.readFileSync(path.join(directory, `gate-outputs/e2e/${name}`))
    const pair = validateE2eReportPair({
      jsonContent: content('certification/e2e-test-report.json'),
      xmlContent: content('playwright-results.xml'),
      expectedRunId: binding.runId,
      expectedCandidateId: binding.candidateId
    })
    const proof = parseE2eEvidenceLog({
      logContent: fs.readFileSync(path.join(directory, 'gates/e2e.log')),
      expectedRunId: binding.runId,
      expectedCandidateId: binding.candidateId,
      expectedTestCount: pair.testCount
    })
    requireThat(pair.executionId === proof.executionId, 'e2e_execution_binding')
  }
  return {}
}
