#!/usr/bin/env node
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import {
  contract,
  contractHash,
  digest,
  files,
  requireThat,
  scopeContract,
  sha,
  sourceFiles,
  validateContract,
  VERSION
} from './hiso-contract.mjs'
import {
  declarationInventory,
  approvedCoverageInventory,
  coverageInventory,
  collectTestInventory,
  caseOccurrences
} from './hiso-inventory.mjs'
import {
  ownerMapping,
  prepareVariant,
  rules,
  rulesHash
} from './hiso-variant.mjs'
import { aggregate, sealFor } from './hiso-verifier.mjs'
import { envelope, snapshotSchema, gateTestReport } from './hiso-reports.mjs'
import { collectRemoteTrust } from './hiso-remote-trust.mjs'
import { validateRem21010ProofReport } from './rem21-010-postgres-proof-contract.mjs'
import { validateRem21011ProofReport } from './rem21-011-observability-proof-contract.mjs'
import { validateRem21014BrowserProofReport } from './rem21-014-browser-proof-contract.mjs'
import { validateRuntimeImageManifest } from './runtime-image-contract.mjs'
import {
  validateE2eReportPair,
  parseE2eEvidenceLog
} from './lib/e2e-report-binding.mjs'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const args = process.argv.slice(2)
const option = (name, fallback) => {
  const i = args.indexOf(`--${name}`)
  return i < 0 ? fallback : args[i + 1]
}
const write = (p, v) => {
  fs.mkdirSync(path.dirname(p), { recursive: true })
  fs.writeFileSync(p, JSON.stringify(v, null, 2) + '\n')
}
const read = (p) => JSON.parse(fs.readFileSync(p, 'utf8'))
export function sanitizedEnv(env, tmp, cache) {
  const result = {}
  for (const [k, v] of Object.entries(env))
    if (
      !k.startsWith('SHIFT_') &&
      !/^(OPENAI_API_KEY|ANTHROPIC_API_KEY|WAHA_API_KEY|EVOLUTION_API_KEY|GITHUB_OUTPUT|GITHUB_ENV|GITHUB_TOKEN|GH_TOKEN)$/.test(
        k
      )
    )
      result[k] = v
  delete result.GITHUB_ACTIONS
  return {
    ...result,
    TMPDIR: tmp,
    npm_config_cache: cache,
    NPM_CONFIG_AUDIT: 'false',
    NPM_CONFIG_FUND: 'false'
  }
}
export function snapshotOutputs(working, out, gate) {
  return (gate.artifacts ?? []).map((p) => {
    const input = path.join(working, p)
    requireThat(
      fs.existsSync(input) &&
        fs.lstatSync(input).isFile() &&
        !fs.lstatSync(input).isSymbolicLink(),
      `missing_output:${p}`
    )
    const relative = `gate-outputs/${gate.id}/${p}`,
      target = path.join(out, relative)
    fs.mkdirSync(path.dirname(target), { recursive: true })
    fs.copyFileSync(input, target)
    const b = fs.readFileSync(target)
    return { path: relative, sha256: sha(b), size: b.length }
  })
}
export function validateReport(
  gate,
  working,
  binding,
  log = '',
  inventory = []
) {
  let skipped = 0
  for (const p of gate.artifacts ?? [])
    if (p.endsWith('.json')) {
      const report = read(path.join(working, p))
      snapshotSchema(report, gate.id, p)
      if (
        [
          'public-smoke',
          'd009-consumer',
          'postgres-version',
          'image-smoke'
        ].includes(gate.id)
      )
        envelope(report, gate.id)
      if (['public-smoke', 'd009-consumer'].includes(gate.id))
        requireThat(
          report.status === 'PASS' &&
            report.sourceFree === true &&
            report.declarations === true &&
            report.clinicalCalls === 0 &&
            report.unknownCalls === 0 &&
            report.normalizer === true &&
            report.budgetDenied === true,
          'public_closure_evidence'
        )
      for (const f of report.testResults ?? [])
        for (const a of f.assertionResults ?? []) {
          if (['skipped', 'pending', 'todo'].includes(a.status)) skipped++
          requireThat(
            !['failed', 'failure'].includes(a.status),
            'assertion_failed'
          )
        }
      if (['unit', 'postgres', 'chaos'].includes(gate.id))
        gateTestReport(report, gate, inventory)
      if (gate.id === 'postgres-proof')
        validateRem21010ProofReport(report, binding)
      if (gate.id === 'observability-proof')
        validateRem21011ProofReport(report, binding)
      if (gate.id === 'browser-proof')
        validateRem21014BrowserProofReport(report, binding)
      if (gate.id === 'postgres-version')
        requireThat(
          report.status === 'PASS' &&
            Number.isSafeInteger(report.version) &&
            report.version >= 160000 &&
            report.version < 170000 &&
            report.runId === binding.runId &&
            report.candidateId === binding.candidateId,
          'postgres_version_binding'
        )
      if (gate.id === 'image' && p === 'certification/runtime-image.json')
        validateRuntimeImageManifest(report, binding)
      if (['coverage-critical', 'mutation', 'skip', 'evals'].includes(gate.id))
        requireThat(report.verdict === 'PASS', 'report_verdict')
    }
  if (gate.id === 'e2e') {
    const pair = validateE2eReportPair({
      jsonContent: fs.readFileSync(
        path.join(working, 'certification/e2e-test-report.json')
      ),
      xmlContent: fs.readFileSync(path.join(working, 'playwright-results.xml')),
      expectedRunId: binding.runId,
      expectedCandidateId: binding.candidateId
    })
    const proof = parseE2eEvidenceLog({
      logContent: log,
      expectedRunId: binding.runId,
      expectedCandidateId: binding.candidateId,
      expectedTestCount: pair.testCount
    })
    requireThat(proof.executionId === pair.executionId, 'e2e_execution_binding')
  }
  if (gate.skipPolicy === 'none') requireThat(skipped === 0, 'required_skip')
  return skipped
}
export function runScope({
  source = root,
  output,
  scope,
  mode = 'local',
  bounded = true,
  runId = `local-${Date.now()}`,
  attempt = '1'
}) {
  validateContract(source)
  requireThat(mode === 'local' || mode === 'ci', 'mode')
  if (mode === 'ci')
    requireThat(
      process.env.GITHUB_ACTIONS === 'true' &&
        /^[0-9]+$/.test(process.env.GITHUB_RUN_ID ?? '') &&
        runId ===
          `run-${process.env.GITHUB_RUN_ID}-${process.env.GITHUB_RUN_ATTEMPT}`,
      'remote_runner_required'
    )
  if (mode === 'ci')
    requireThat(
      process.env.HISO_INPUT_JOB_RESULT === 'success' &&
        process.env.HISO_SETUP_RESULT === 'success',
      'frozen_inputs_or_setup_not_pass'
    )
  const s = scopeContract(scope)
  output = path.resolve(output)
  requireThat(
    !output.startsWith(path.resolve(source) + path.sep),
    'outputs_inside_source'
  )
  requireThat(!fs.existsSync(output), 'output_must_be_fresh')
  fs.mkdirSync(output, { recursive: true })
  const tmp = path.join(output, 'private-tmp'),
    cache = path.join(output, 'private-npm-cache')
  fs.mkdirSync(tmp)
  fs.mkdirSync(cache)
  // Operational artifacts have their own namespace; caches are outside it.
  const artifacts = path.join(output, 'artifacts')
  fs.mkdirSync(artifacts)
  const before = sourceFiles(source)
  approvedCoverageInventory(source, before)
  const candidateId = digest(before),
    mapping = ownerMapping(before)
  const declarations = declarationInventory(source, before)
  write(path.join(artifacts, 'candidate-inputs.json'), before)
  write(path.join(artifacts, 'owner-mapping.json'), mapping)
  write(path.join(artifacts, 'test-declarations.json'), declarations)
  let inventory = [],
    discoveryError = null
  try {
    inventory = collectTestInventory(
      source,
      artifacts,
      sanitizedEnv(process.env, tmp, cache)
    )
  } catch (e) {
    discoveryError = e.message
  }
  const variant = prepareVariant(source, path.join(output, 'variant'), scope)
  const working = path.join(output, 'variant')
  const env = sanitizedEnv(process.env, tmp, cache)
  const gitCommand = ['git', ['init', '--quiet', working]]
  const git = spawnSync(gitCommand[0], gitCommand[1], {
    env,
    encoding: 'utf8',
    timeout: 10000
  })
  write(path.join(artifacts, 'private-git-context.json'), {
    command: gitCommand,
    exitCode: git.status,
    cause: git.error?.code ?? null,
    purpose:
      'Empty private Git metadata supports unchanged legacy source inventory tests; no history or source cache copied.'
  })
  fs.writeFileSync(
    path.join(artifacts, 'private-git-context.log'),
    (git.stdout ?? '') + (git.stderr ?? '')
  )
  fs.mkdirSync(path.join(working, 'certification'), { recursive: true })
  const npm =
    spawnSync('npm', ['--version'], { env, encoding: 'utf8' }).stdout?.trim() ??
    'UNKNOWN'
  const m = {
    schemaVersion: 1,
    contract: VERSION,
    contractHash,
    scope,
    owner: s.owner,
    candidateId,
    sourceSha256: candidateId,
    runId,
    attempt,
    derivedVariantId: variant.derivedVariantId,
    derivedMappingHash: variant.derivedMappingHash,
    ownerMappingHash: digest(mapping),
    rulesHash,
    mode: mode === 'ci' ? 'GITHUB_JOB_OUTPUT_BOUND' : 'LOCAL_CONTENT_HASHES',
    workflow: mode === 'ci' ? process.env.GITHUB_WORKFLOW_REF : null,
    job: mode === 'ci' ? process.env.GITHUB_JOB : null,
    startedAt: new Date().toISOString(),
    versions: {
      node: process.versions.node,
      npm,
      os: os.platform(),
      arch: os.arch()
    },
    environment: {
      postgres: env.TEST_DATABASE_URL
        ? 'CONFIGURED_NOT_YET_VERIFIED'
        : 'ABSENT',
      browsers: 'NOT_RUN',
      provider: 'NO_REAL_PROVIDER',
      synthetic: true
    },
    lockSha256: variant.lockAfter,
    originalLockSha256: variant.lockBefore,
    testInventory: inventory,
    testInventoryHash: digest(inventory),
    testInventoryStatus: discoveryError ? 'NOT_RUN' : 'COLLECTED_NOT_EXECUTED',
    testInventoryCause: discoveryError,
    executedTestInventory: [],
    executedTestInventoryHash: digest([]),
    coverage: null,
    image: null,
    gates: [],
    seals: [],
    status: 'NOT_RUN'
  }
  write(path.join(artifacts, 'test-declarations.json'), declarations)
  write(path.join(artifacts, 'candidate-inputs.json'), before)
  write(path.join(artifacts, 'variant.json'), variant)
  write(path.join(artifacts, 'owner-mapping.json'), mapping)
  const allowed = new Set([
    'runtime',
    'install',
    'public-build',
    'harness-build',
    'public-smoke',
    'd009-consumer',
    'typecheck',
    'inventory'
  ])
  for (const gate of s.gates) {
    const start = Date.now()
    const entry = {
      schemaVersion: 1,
      id: gate.id,
      command: gate.command,
      status: 'NOT_RUN',
      exitCode: null,
      cause: 'LOCAL_BOUNDED_LANE_LEAD_FULL_VALIDATION_REQUIRED',
      scope,
      runId,
      candidateId,
      startedAt: new Date().toISOString(),
      finishedAt: null,
      skipped: null,
      outputs: [],
      logSha256: null
    }
    let raw = ''
    try {
      const execute = !bounded || allowed.has(gate.id)
      if (execute) {
        if (gate.id === 'runtime') {
          entry.exitCode = /^22\./.test(process.versions.node) ? 0 : 1
          raw = `node=${process.versions.node}\nnpm=${npm}\n`
          entry.skipped = 0
        } else if (gate.id === 'inventory') {
          requireThat(!discoveryError, discoveryError?.replace(/^hiso:/, ''))
          write(path.join(working, 'inventory.json'), {
            schemaVersion: 1,
            kind: 'SOURCE_INVENTORY_NOT_EXECUTED',
            declarations,
            inventory,
            mapping,
            coveragePaths: coverageInventory(source, before),
            transitionOnly: rules.transitionOnly
          })
          entry.exitCode = 0
          entry.skipped = 0
          raw =
            'Source spans and owner mapping captured; execution inventory is separate.\n'
        } else if (
          ['certify', 'certification-verify', 'artifacts'].includes(gate.id)
        ) {
          entry.cause =
            'TRANSITION_REQUIRES_UNCHANGED_REM21_WORKFLOW_AND_HISO_IMPORT'
        } else if (
          [
            'postgres',
            'postgres-version',
            'postgres-proof',
            'observability-proof',
            'phase4a',
            'chaos',
            'worker-startup'
          ].includes(gate.id) &&
          !env.TEST_DATABASE_URL
        ) {
          entry.cause = 'PG16_REQUIRED_NOT_CONFIGURED'
        } else {
          const [bin, argv] = gate.command ?? []
          requireThat(bin, 'command_required')
          const legacyContext = path.join(output, 'proof-context')
          fs.mkdirSync(legacyContext, { recursive: true })
          write(path.join(legacyContext, 'ci-bar-state.json'), {
            runId,
            candidateId
          })
          const result = spawnSync(bin, argv, {
            cwd: working,
            env: {
              ...env,
              CI_RUN_ID: runId,
              CI_CANDIDATE_ID: candidateId,
              CI_ARTIFACT_DIR: legacyContext
            },
            encoding: 'utf8',
            timeout: bounded ? 180000 : 3600000,
            maxBuffer: 128 * 1024 * 1024
          })
          raw =
            (result.stdout ?? '') +
            (result.stderr ?? '') +
            (result.error ? String(result.error) : '')
          entry.exitCode = result.status ?? 1
          entry.skipped = 0
        }
        if (entry.exitCode !== null) {
          entry.status = entry.exitCode === 0 ? 'PASS' : 'FAIL'
          entry.cause = entry.exitCode === 0 ? null : 'COMMAND_FAILED'
          if (entry.exitCode === 0) {
            entry.skipped = validateReport(
              gate,
              working,
              { runId, candidateId },
              raw,
              gate.id === 'unit'
                ? inventory.filter(
                    (t) =>
                      scope === 'transition-regression' ||
                      mapping.find((f) => f.path === t.file)?.owner === scope
                  )
                : inventory
            )
            entry.outputs = snapshotOutputs(working, artifacts, gate)
            if (gate.id === 'postgres-version')
              m.environment.postgres = read(
                path.join(working, 'postgres-version.json')
              )
            if (gate.id === 'image')
              m.image = read(
                path.join(
                  working,
                  scope === 'shift-product'
                    ? 'image.json'
                    : 'certification/runtime-image.json'
                )
              )
            if (gate.id === 'image-smoke')
              m.image = {
                ...m.image,
                smoke: read(path.join(working, 'image-smoke.json'))
              }
            if (gate.id === 'coverage') {
              const report = read(
                path.join(working, 'coverage/coverage-summary.json')
              )
              m.coverage = Object.fromEntries(
                Object.entries(report)
                  .filter(([p]) => p !== 'total')
                  .map(([p, v]) => [
                    path.relative(working, p).split(path.sep).join('/'),
                    v
                  ])
              )
            }
            if (gate.id === 'unit') {
              const p = (gate.artifacts ?? []).find((p) => p.endsWith('.json'))
              const report = read(path.join(working, p))
              m.executedTestInventory = caseOccurrences(
                report.testResults.flatMap((f) =>
                  f.assertionResults.map((t) => ({
                    file: path
                      .relative(working, f.name)
                      .split(path.sep)
                      .join('/'),
                    name: [...t.ancestorTitles, t.title].join(' > '),
                    status: t.status
                  }))
                )
              ).sort((a, b) =>
                JSON.stringify(a).localeCompare(JSON.stringify(b))
              )
              m.executedTestInventoryHash = digest(m.executedTestInventory)
              const required = inventory.filter(
                (t) =>
                  scope === 'transition-regression' ||
                  mapping.find((f) => f.path === t.file)?.owner === scope
              )
              requireThat(
                digest(
                  m.executedTestInventory
                    .map(({ file, name, occurrence }) => ({
                      file,
                      name,
                      occurrence
                    }))
                    .sort((a, b) =>
                      JSON.stringify(a).localeCompare(JSON.stringify(b))
                    )
                ) ===
                  digest(
                    required
                      .map(({ file, name, occurrence }) => ({
                        file,
                        name,
                        occurrence
                      }))
                      .sort((a, b) =>
                        JSON.stringify(a).localeCompare(JSON.stringify(b))
                      )
                  ),
                'unit_execution_inventory_mismatch'
              )
            }
          }
        }
      }
    } catch (e) {
      entry.status = 'FAIL'
      entry.exitCode = 1
      entry.cause = e.message
      raw += '\n' + e.stack + '\n'
    }
    entry.finishedAt = new Date().toISOString()
    entry.durationMs = Date.now() - start
    const log = `command=${JSON.stringify(entry.command)}\nscope=${scope}\nrun=${runId}\ncandidate=${candidateId}\nstatus=${entry.status}\nexit=${entry.exitCode}\ncause=${entry.cause}\n${raw}`
    const p = path.join(artifacts, 'gates', gate.id + '.log')
    fs.mkdirSync(path.dirname(p), { recursive: true })
    fs.writeFileSync(p, log)
    entry.logSha256 = sha(log)
    m.gates.push(entry)
    m.seals.push(sealFor(m, entry))
    write(path.join(artifacts, 'state.json'), m)
    process.stdout.write(
      JSON.stringify({
        scope,
        id: entry.id,
        status: entry.status,
        cause: entry.cause
      }) + '\n'
    )
  }
  const after = sourceFiles(source)
  m.sourceAfterSha256 = digest(after)
  m.sourceMatch = m.sourceAfterSha256 === candidateId
  const generatedOutputs = new Set(s.gates.flatMap((g) => g.artifacts ?? []))
  const variantAfter = sourceFiles(working).filter(
    (f) => !generatedOutputs.has(f.path)
  )
  m.variantSourceAfterSha256 = digest(variantAfter)
  m.variantSourceMatch = m.variantSourceAfterSha256 === variant.derivedVariantId
  m.finishedAt = new Date().toISOString()
  m.status =
    m.sourceMatch &&
    m.variantSourceMatch &&
    m.gates.every((g) => g.status === 'PASS')
      ? 'PASS'
      : 'FAIL'
  m.constraints = [
    'REMOTE_CI_NOT_RUN_UNLESS_REAL_RUNNER',
    'INDEPENDENT_ATTESTATION_REQUIRED',
    'PRODUCT_0179_INTEGRATION_OWNED_BY_SHIFT_PRODUCT',
    'LEAD_FULL_PG_E2E_COVERAGE_CERTIFY_IMAGES_REQUIRED'
  ]
  write(path.join(artifacts, 'state.json'), m)
  m.outputs = files(artifacts)
  write(path.join(artifacts, 'manifest.json'), m)
  const expected = Object.fromEntries(
    [
      'schemaVersion',
      'contract',
      'contractHash',
      'scope',
      'candidateId',
      'sourceSha256',
      'runId',
      'attempt',
      'derivedVariantId',
      'derivedMappingHash',
      'ownerMappingHash',
      'testInventoryHash',
      'lockSha256'
    ].map((k) => [k, m[k]])
  )
  write(path.join(output, 'expected-local.json'), {
    ...expected,
    trust: 'BUILDER_SELF_OBSERVATION_NOT_INDEPENDENT_APPROVAL'
  })
  if (mode === 'ci' && process.env.GITHUB_OUTPUT)
    fs.appendFileSync(
      process.env.GITHUB_OUTPUT,
      `manifest_sha256=${sha(fs.readFileSync(path.join(artifacts, 'manifest.json')))}\nseal_set_sha256=${digest(m.seals)}\ncandidate_id=${candidateId}\n`
    )
  return m
}

if (
  process.argv[1] &&
  path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)
) {
  try {
    if (args[0] === 'run') {
      const m = runScope({
        scope: option('scope'),
        output: option('output'),
        mode: option('mode', 'local'),
        bounded: !args.includes('--full'),
        runId: option('run-id', `local-${Date.now()}`),
        attempt: option('attempt', '1')
      })
      process.exitCode = m.status === 'PASS' ? 0 : 1
    } else if (args[0] === 'preflight') {
      const out = path.resolve(option('output'))
      fs.mkdirSync(out, { recursive: true })
      const pass =
        process.env.HISO_INPUT_JOB_RESULT === 'success' &&
        process.env.HISO_SETUP_RESULT === 'success'
      write(path.join(out, 'preflight.json'), {
        schemaVersion: 1,
        status: pass ? 'PASS' : 'NOT_RUN',
        cause: pass ? null : 'FROZEN_INPUTS_OR_SETUP_NOT_PASS',
        inputJobResult: process.env.HISO_INPUT_JOB_RESULT ?? null,
        setupResult: process.env.HISO_SETUP_RESULT ?? null,
        runId: process.env.CI_RUN_ID ?? null,
        command: ['node', ['scripts/hiso-ci.mjs', 'preflight']],
        versions: { node: process.versions.node }
      })
      requireThat(pass, 'frozen_inputs_or_setup_not_pass')
    } else if (args[0] === 'inventory') {
      const inputs = sourceFiles(root)
      write(path.join(root, 'inventory.json'), {
        schemaVersion: 1,
        kind: 'SOURCE_DECLARATIONS_NOT_EXECUTED',
        declarations: declarationInventory(root, inputs),
        mapping: ownerMapping(inputs),
        coveragePaths: coverageInventory(root, inputs)
      })
    } else if (args[0] === 'contract')
      console.log(JSON.stringify(validateContract()))
    else if (args[0] === 'aggregate') {
      const base = path.resolve(option('input')),
        expected = read(option('expected'))
      const scopes = contract.scopes.map((s) => {
        const directory = path.join(base, s.id, 'artifacts')
        return {
          directory,
          manifest: read(path.join(directory, 'manifest.json'))
        }
      })
      const mode = option('mode', 'local')
      const security = read(option('security')),
        provenance = read(option('provenance')),
        producerResults = read(option('producers'))
      const trust =
        mode === 'remote'
          ? await collectRemoteTrust({
              scopes,
              expected,
              security,
              provenance,
              producerResults,
              expectedFile: option('expected'),
              output: option('trust-output')
            })
          : undefined
      const result = aggregate({
        scopes,
        expected,
        security,
        provenance,
        producerResults,
        mode,
        trust
      })
      write(option('output'), result)
      process.exitCode = result.status === 'PASS' ? 0 : 1
    } else
      throw new Error(
        'usage: hiso-ci.mjs contract | run --scope ID --output FRESH [--full] [--mode ci] | aggregate --input DIR --expected FILE --security FILE --provenance FILE --producers FILE --output FILE'
      )
  } catch (e) {
    if (
      args[0] === 'run' &&
      option('output') &&
      !fs.existsSync(
        path.join(path.resolve(option('output')), 'artifacts/manifest.json')
      )
    ) {
      const directory = path.join(path.resolve(option('output')), 'artifacts')
      fs.mkdirSync(directory, { recursive: true })
      fs.writeFileSync(
        path.join(directory, 'bootstrap-failure.log'),
        e.stack + '\n'
      )
      let gates = []
      try {
        gates = scopeContract(option('scope')).gates.map((g) => ({
          schemaVersion: 1,
          id: g.id,
          command: g.command,
          status: 'NOT_RUN',
          exitCode: null,
          cause: 'BOOTSTRAP_FAILED',
          scope: option('scope')
        }))
      } catch {}
      write(path.join(directory, 'manifest.json'), {
        schemaVersion: 1,
        contract: VERSION,
        contractHash,
        scope: option('scope'),
        status: 'FAIL',
        cause: e.message,
        mode: 'LOCAL_CONTENT_HASHES',
        versions: { node: process.versions.node },
        candidateId: fs.existsSync(
          path.join(directory, 'candidate-inputs.json')
        )
          ? digest(read(path.join(directory, 'candidate-inputs.json')))
          : null,
        sourceSha256: fs.existsSync(
          path.join(directory, 'candidate-inputs.json')
        )
          ? digest(read(path.join(directory, 'candidate-inputs.json')))
          : null,
        gates,
        outputs: files(directory).filter((f) => f.path !== 'manifest.json'),
        runId: option('run-id', null),
        remoteCiPass: false
      })
    }
    if (args[0] === 'aggregate' && option('output'))
      write(option('output'), {
        schemaVersion: 1,
        contract: VERSION,
        contractHash,
        status: 'FAIL',
        failures: [e.message],
        mode: option('mode', 'local'),
        remoteCiPass: false,
        externalGates: 'NOT_RUN'
      })
    console.error(e.stack)
    process.exitCode = 1
  }
}
