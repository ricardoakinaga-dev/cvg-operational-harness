import fs from 'node:fs'
import { createRequire } from 'node:module'
import { z } from 'zod'
import { CORE_EVAL_DATASET } from '../packages/agent-evals/src/datasets/core.ts'
import { computeMetrics } from '../packages/agent-evals/src/metrics.ts'
import { canonical, exact, requireThat } from './hiso-contract.mjs'
import {
  CandidateRecordSchema,
  CertificationManifestSchema,
  Phase10ResultSchema
} from './lib/certification-rules.mjs'

import {
  buildCoverageReport,
  GLOBAL_COVERAGE_THRESHOLDS,
  CRITICAL_BRANCH_THRESHOLD
} from './lib/coverage-gate.mjs'

const criticalManifest = JSON.parse(
  fs.readFileSync(
    new URL('./critical-coverage-manifest.json', import.meta.url),
    'utf8'
  )
)
const evalThresholds = JSON.parse(
  fs.readFileSync(
    new URL(
      '../packages/agent-evals/src/eval-thresholds.json',
      import.meta.url
    ),
    'utf8'
  )
)
const dimensions = ['statements', 'branches', 'functions', 'lines']
const roundedPct = (v) =>
  v.total === 0 ? null : Number(((v.covered / v.total) * 100).toFixed(2))
const count = z.number().int().nonnegative()
const positive = z.number().int().positive()
const amount = z.number().nonnegative()
const hash = z.string().regex(/^[a-f0-9]{64}$/)
const text = z.string().min(1)
const date = z.string().datetime()
const pass = z.literal('PASS')
const record = z.record(z.string(), z.unknown())
const numbers = z.record(z.string(), z.number())
const binding = { runId: text, candidateId: hash }
const metric = z
  .object({ total: count, covered: count, pct: z.number().min(0).max(100) })
  .refine((v) => v.total > 0 && v.covered <= v.total && v.pct === roundedPct(v))
const metrics = z.object(
  Object.fromEntries(
    ['statements', 'branches', 'functions', 'lines'].map((k) => [k, metric])
  )
)
const result = z.object({
  pass: z.literal(true),
  failures: z.array(z.string()).length(0)
})
const schemas = {
  inventory: z.object({
    schemaVersion: z.literal(1),
    declarations: z.array(record),
    mapping: z.array(record)
  }),
  'coverage-critical': z.object({
    schemaVersion: z.literal(1),
    kind: z.literal('aud20-coverage-report'),
    verdict: pass,
    failures: z.array(z.string()).length(0),
    global: result.extend({ thresholds: numbers, metrics }),
    critical: result.extend({
      threshold: amount,
      groups: z
        .array(
          z.object({
            id: text,
            paths: z.array(text).min(1),
            missing: z.array(text).length(0),
            files: z
              .array(
                z.object({
                  path: text,
                  manifestPath: text,
                  metrics: z.object(
                    Object.fromEntries(
                      dimensions.map((k) => [
                        k,
                        z
                          .object({
                            total: count,
                            covered: count,
                            pct: z.number().min(0).max(100).nullable()
                          })
                          .refine(
                            (v) =>
                              v.covered <= v.total && v.pct === roundedPct(v)
                          )
                      ])
                    )
                  )
                })
              )
              .min(1),
            metrics
          })
        )
        .min(1)
    })
  }),
  mutation: z
    .object({
      schemaVersion: z.literal(2),
      kind: z.literal('aud21-risk-mutation-guard'),
      contract: z.literal('rem21-013-v1'),
      ...binding,
      verdict: pass,
      selected: positive,
      killed: positive,
      survived: z.literal(0),
      timedOut: z.literal(0),
      errors: z.literal(0),
      domains: z.array(text),
      mutations: z.array(
        z.object({
          id: text,
          status: z.literal('KILLED'),
          exitCode: z.number().int(),
          durationMs: amount
        })
      )
    })
    .refine(
      (v) => v.selected === v.killed && v.selected === v.mutations.length
    ),
  skip: z
    .object({
      schemaVersion: z.literal(1),
      kind: z.literal('aud20-skip-inventory'),
      ...binding,
      verdict: pass,
      totals: z.object({
        skippedTests: count,
        skippedFiles: count,
        failures: z.literal(0)
      }),
      skips: z.array(record),
      failures: z.array(z.string()).length(0),
      reports: z.array(record),
      reportCountByGate: numbers,
      skippedTestsByGate: numbers
    })
    .refine((v) => v.skips.length === v.totals.skippedTests),
  evals: z.object({
    suiteId: text,
    agentId: text,
    startedAt: date,
    finishedAt: date,
    verdict: pass,
    metrics: numbers,
    thresholds: numbers,
    failures: z.array(
      z.object({ scenarioId: text, reasons: z.array(text).min(1) })
    )
  }),
  load: z
    .object({
      schemaVersion: z.literal(1),
      kind: z.literal('phase10-load-report'),
      events: positive,
      processed: positive,
      loss: z.literal(0),
      duplicates: z.literal(0),
      workers: positive,
      enqueueMs: amount,
      drainMs: amount,
      totalMs: amount,
      throughputPerSecond: amount,
      latencyMs: z.object({
        p50: amount,
        p95: amount,
        p99: amount,
        max: amount
      })
    })
    .refine((v) => v.processed === v.events),
  restore: z.object({
    schemaVersion: z.literal(1),
    kind: z.literal('phase10-restore-report'),
    snapshotFormatVersion: positive,
    snapshotDigestPrefix: text,
    snapshotSha256: hash,
    captureMs: amount,
    restoreMs: amount,
    integrity: z.object({
      digestMatches: z.literal(true),
      outboxPreserved: z.literal(true),
      tenantIsolation: z.literal(true),
      restoredEvents: count
    }),
    rpoMeasured: z.literal(false),
    rtoMeasuredSec: amount,
    rpoRtoVerdict: z.literal('NOT_VALIDATED_ON_PRODUCTION_INFRASTRUCTURE')
  }),
  sbom: z.object({
    bomFormat: z.literal('CycloneDX'),
    specVersion: z.literal('1.5'),
    version: positive,
    serialNumber: text,
    metadata: record,
    components: z.array(z.object({ name: text, version: text, type: text }))
  }),
  licenses: z
    .object({
      schemaVersion: z.literal(2),
      total: count,
      internalCount: count,
      deniedCount: z.literal(0),
      unknownCount: count,
      unclassifiedCount: z.literal(0),
      invalidExceptions: z.array(z.unknown()).length(0),
      denied: z.array(z.unknown()).length(0),
      unknown: z.array(text),
      unclassified: z.array(z.unknown()).length(0)
    })
    .refine(
      (v) =>
        v.unknown.length === v.unknownCount &&
        v.internalCount + v.unknownCount <= v.total
    ),
  'image-smoke': z.object({
    schemaVersion: z.literal(1),
    status: pass,
    ...binding,
    imageId: z.string().regex(/^sha256:[a-f0-9]{64}$/),
    health: z.literal(200),
    modelCalls: z.literal(0),
    uid: z.literal(10001),
    sends: positive,
    network: z.literal('none'),
    readOnly: z.literal(true),
    syntheticDataTmpfs: z.literal(true),
    probeSha256: hash
  }),
  'product-image': z.object({
    schemaVersion: z.literal(1),
    status: pass,
    ...binding,
    imageId: z.string().regex(/^sha256:[a-f0-9]{64}$/),
    baseRef: text,
    config: record,
    dockerfileSha256: hash
  })
}

// Rebuild the native coverage producer's PASS from the authoritative manifest
// and the per-file counts. The producer permits erased-file zero denominators;
// global and aggregated critical dimensions must have real denominators.
function coverageSemantics(report) {
  requireThat(
    criticalManifest.branchThreshold === CRITICAL_BRANCH_THRESHOLD &&
      report.critical.threshold === CRITICAL_BRANCH_THRESHOLD,
    'critical_coverage_threshold'
  )
  requireThat(
    canonical(report.global.thresholds) ===
      canonical(GLOBAL_COVERAGE_THRESHOLDS),
    'global_coverage_thresholds'
  )
  exact(
    report.critical.groups.map((g) => g.id),
    criticalManifest.groups.map((g) => g.id),
    'critical_coverage_groups'
  )
  const summary = { total: report.global.metrics }
  const normalized = report.critical.groups
    .map((g) => {
      const approved = criticalManifest.groups.find((a) => a.id === g.id)
      exact(g.paths, approved.paths, `critical_coverage_paths:${g.id}`)
      exact(
        g.files.map((f) => f.manifestPath),
        approved.paths,
        `critical_coverage_files:${g.id}`
      )
      const files = g.files.map((f) => {
        requireThat(
          f.path.replaceAll('\\', '/') === f.manifestPath ||
            f.path.replaceAll('\\', '/').endsWith('/' + f.manifestPath),
          'critical_coverage_file_path'
        )
        // A repeated file in multiple groups must retain identical metrics.
        if (summary[f.manifestPath])
          requireThat(
            canonical(summary[f.manifestPath]) === canonical(f.metrics),
            'critical_coverage_file_conflict'
          )
        summary[f.manifestPath] = f.metrics
        return { ...f, path: f.manifestPath }
      })
      // Independently enforce the raw group ratio before producer projection;
      // rounded display percentages cannot establish the critical threshold.
      const branches = files.reduce(
        (sum, f) => ({
          total: sum.total + f.metrics.branches.total,
          covered: sum.covered + f.metrics.branches.covered
        }),
        { total: 0, covered: 0 }
      )
      requireThat(
        branches.total > 0 &&
          (branches.covered / branches.total) * 100 >=
            CRITICAL_BRANCH_THRESHOLD,
        `critical_coverage_raw_threshold:${g.id}`
      )
      return {
        ...g,
        paths: [...g.paths].sort(),
        files: files.sort((a, b) =>
          a.manifestPath.localeCompare(b.manifestPath)
        )
      }
    })
    .sort((a, b) => a.id.localeCompare(b.id))
  const rebuilt = buildCoverageReport(summary, criticalManifest)
  requireThat(rebuilt.verdict === 'PASS', 'coverage_critical_producer_not_pass')
  const groups = rebuilt.critical.groups
    .map((g) => ({
      ...g,
      paths: [...g.paths].sort(),
      files: [...g.files].sort((a, b) =>
        a.manifestPath.localeCompare(b.manifestPath)
      )
    }))
    .sort((a, b) => a.id.localeCompare(b.id))
  // Native global/file metrics may additionally carry Istanbul skipped counts.
  // Preserve those fields while comparing against the same producer function.
  requireThat(
    canonical(report.global) === canonical(rebuilt.global) &&
      canonical(normalized) === canonical(groups),
    'coverage_critical_producer_projection'
  )
}

// Legacy native receipts use the old core dataset. Read only inert literal
// IDs/group flags from its relocated source; never import consumer/evaluator code.
function legacyEvalMembers() {
  const file = new URL(
    '../legacy/packages/secretary-evals/src/secretary-eval-dataset.ts',
    import.meta.url
  )
  if (!fs.existsSync(file)) return []
  const ts = createRequire(import.meta.url)('typescript')
  const ast = ts.createSourceFile(
    file.pathname,
    fs.readFileSync(file, 'utf8'),
    ts.ScriptTarget.Latest,
    true
  )
  let dataset
  const visit = (node) => {
    if (
      ts.isVariableDeclaration(node) &&
      node.name.getText(ast) === 'SECRETARY_EVAL_DATASET'
    ) {
      requireThat(
        !dataset && ts.isArrayLiteralExpression(node.initializer),
        'eval_legacy_dataset'
      )
      dataset = node.initializer
    }
    ts.forEachChild(node, visit)
  }
  visit(ast)
  requireThat(dataset, 'eval_legacy_dataset')
  return dataset.elements.map((node) => {
    requireThat(ts.isObjectLiteralExpression(node), 'eval_legacy_member')
    const property = (name) =>
      node.properties.find(
        (p) => ts.isPropertyAssignment(p) && p.name.getText(ast) === name
      )?.initializer
    const id = property('id'),
      group = property('adversarial')
    requireThat(
      id &&
        ts.isStringLiteral(id) &&
        (!group ||
          [ts.SyntaxKind.TrueKeyword, ts.SyntaxKind.FalseKeyword].includes(
            group.kind
          )),
      'eval_legacy_member'
    )
    return {
      id: id.text,
      adversarial: group?.kind === ts.SyntaxKind.TrueKeyword
    }
  })
}
const legacyMembers = legacyEvalMembers()

function evalSemantics(report) {
  requireThat(
    canonical(report.thresholds) === canonical(evalThresholds),
    'eval_producer_thresholds'
  )
  const m = report.metrics
  requireThat(
    Number.isSafeInteger(m.scenarios) && m.scenarios > 0,
    'eval_scenarios'
  )
  for (const k of [
    'taskSuccessRate',
    'policyViolationRate',
    'unsafeActionRate',
    'hallucinationRate',
    'toolSelectionAccuracy',
    'humanEscalationAccuracy',
    'schemaFailureRate',
    'refusalAccuracy',
    'adversarialPassRate'
  ])
    requireThat(
      Number.isFinite(m[k]) && m[k] >= 0 && m[k] <= 1,
      `eval_metric:${k}`
    )
  for (const k of ['avgLatencyMs', 'p95LatencyMs', 'totalCostUsd'])
    requireThat(Number.isFinite(m[k]) && m[k] >= 0, `eval_metric:${k}`)
  exact(
    report.failures.map((f) => f.scenarioId),
    [...new Set(report.failures.map((f) => f.scenarioId))],
    'eval_duplicate_failures'
  )
  requireThat(
    report.failures.length <= m.scenarios &&
      m.taskSuccessRate ===
        (m.scenarios - report.failures.length) / m.scenarios,
    'eval_failure_metrics'
  )
  const failuresWith = (predicate) =>
    report.failures.filter((f) => f.reasons.some(predicate)).length
  const unsafe = failuresWith((reason) =>
    reason.startsWith('forbidden_capability')
  )
  // These exact reason comparisons intentionally mirror computeMetrics, whose
  // producer does not use a prefix comparison for escalation/refusal/tooling.
  const escalation = failuresWith((reason) => reason === 'escalation_mismatch')
  const refusal = failuresWith((reason) =>
    ['refusal_missing', 'unexpected_refusal'].includes(reason)
  )
  const tool = failuresWith((reason) => reason === 'missing_capability')
  requireThat(
    m.unsafeActionRate === unsafe / m.scenarios &&
      m.policyViolationRate >= unsafe / m.scenarios &&
      m.policyViolationRate <= (unsafe + escalation) / m.scenarios &&
      m.humanEscalationAccuracy === (m.scenarios - escalation) / m.scenarios &&
      m.refusalAccuracy === (m.scenarios - refusal) / m.scenarios &&
      m.toolSelectionAccuracy === (m.scenarios - 0.5 * tool) / m.scenarios &&
      m.hallucinationRate === m.schemaFailureRate,
    'eval_failure_projection'
  )

  // Reports omit successful outcomes. Reconstruct only the count projection:
  // hidden outcome fields must still admit integral native numerators, while
  // the core corpus binds adversarial membership independently of the report.
  const numerator = (metric, denominator, maximum = denominator) => {
    const value = Math.round(metric * denominator)
    requireThat(
      Number.isSafeInteger(value) &&
        value >= 0 &&
        value <= maximum &&
        metric === value / denominator,
      'eval_integral_numerator'
    )
    return value
  }
  const hallucinations = numerator(m.hallucinationRate, m.scenarios)
  const policy = numerator(
    m.policyViolationRate,
    m.scenarios,
    unsafe + escalation
  )
  const core =
    report.suiteId === 'phase10-core-v1'
      ? m.scenarios === CORE_EVAL_DATASET.length
        ? CORE_EVAL_DATASET
        : m.scenarios === legacyMembers.length
          ? legacyMembers
          : null
      : null
  const failures = new Map(
    report.failures.map((f) => [f.scenarioId, f.reasons])
  )
  let members
  if (core) {
    requireThat(
      report.failures.every((f) => core.some((t) => t.id === f.scenarioId)),
      'eval_failure_membership'
    )
    members = core.map((t) => ({
      id: t.id,
      adversarial: t.adversarial === true
    }))
  } else {
    // Generic native reports retain their public shape and legitimate 1/100
    // tolerable failures. An omitted group must have a possible integral native
    // partition; it cannot contradict success/failure membership.
    let partition = m.adversarialPassRate === 1 ? { total: 0, failed: 0 } : null
    for (let total = 1; !partition && total <= m.scenarios; total++) {
      const failed = Math.round((1 - m.adversarialPassRate) * total)
      if (
        failed <= failures.size &&
        total - failed <= m.scenarios - failures.size &&
        m.adversarialPassRate === (total - failed) / total
      )
        partition = { total, failed }
    }
    requireThat(partition, 'eval_adversarial_membership')
    members = [
      ...report.failures.map((f, i) => ({
        id: f.scenarioId,
        adversarial: i < partition.failed
      })),
      ...Array.from({ length: m.scenarios - failures.size }, (_, i) => ({
        id: null,
        adversarial: i < partition.total - partition.failed
      }))
    ]
  }
  let policyExtra = policy - unsafe
  const projected = computeMetrics(
    members.map((t, i) => {
      const reasons = failures.get(t.id) ?? []
      const extra = reasons.includes('escalation_mismatch') && policyExtra > 0
      if (extra) policyExtra--
      return {
        success: reasons.length === 0,
        adversarial: t.adversarial,
        failures: reasons,
        outcome: {
          structuredValid: i >= hallucinations,
          escalation: extra ? 'none' : 'handoff',
          proposedCapabilities: extra ? ['synthetic'] : [],
          latencyMs: 0,
          costUsd: 0
        }
      }
    })
  )
  requireThat(policyExtra === 0, 'eval_policy_projection')
  for (const k of Object.keys(projected).filter(
    (k) => !['avgLatencyMs', 'p95LatencyMs', 'totalCostUsd'].includes(k)
  ))
    requireThat(m[k] === projected[k], `eval_native_projection:${k}`)

  // Match runEvalSuite's six comparisons, including escalationAccuracy's
  // differently named metric. A native PASS may retain tolerable case failures.
  const comparisons = [
    ['taskSuccessRate', 'taskSuccessRate', 'min'],
    ['policyViolationRate', 'policyViolationRate', 'max'],
    ['unsafeActionRate', 'unsafeActionRate', 'max'],
    ['schemaFailureRate', 'schemaFailureRate', 'max'],
    ['adversarialPassRate', 'adversarialPassRate', 'min'],
    ['humanEscalationAccuracy', 'escalationAccuracy', 'min']
  ]
  requireThat(
    comparisons.every(([metric, threshold, direction]) =>
      direction === 'min'
        ? m[metric] >= evalThresholds[threshold]
        : m[metric] <= evalThresholds[threshold]
    ),
    'eval_producer_not_pass'
  )
}

export function snapshotTypes(report, gateId, outputPath) {
  if (gateId === 'postgres-version')
    requireThat(
      Number.isSafeInteger(report.version) &&
        report.version >= 160000 &&
        report.version < 170000,
      'postgres_version_binding'
    )
  let schema = schemas[gateId]
  if (gateId === 'image')
    schema = outputPath.endsWith('/image.json')
      ? schemas['product-image']
      : undefined
  if (gateId === 'certify')
    schema = outputPath.endsWith('/candidate-manifest.json')
      ? CandidateRecordSchema
      : outputPath.endsWith('/phase10-result.json')
        ? Phase10ResultSchema
        : CertificationManifestSchema
  if (schema)
    requireThat(schema.safeParse(report).success, `snapshot_types:${gateId}`)
  if (gateId === 'coverage-critical') coverageSemantics(report)
  if (gateId === 'evals') evalSemantics(report)
}
