import os,sys,json,subprocess,time
from pathlib import Path
out=Path(__file__).parent
cwd=out.parent/'ci-raw-critical-r9-candidate'
label=sys.argv[1]; cmd=sys.argv[2:]
for d in ['raw','tmp','npm-cache','cache']: (out/d).mkdir(exist_ok=True)
env={k:v for k,v in os.environ.items() if k in ['LANG','LC_ALL','TZ','USER','LOGNAME','HOME']}
env.update(PATH='/home/ricardo/.nvm/versions/node/v22.23.2/bin:/usr/bin:/bin',TMPDIR=str(out/'tmp'),npm_config_cache=str(out/'npm-cache'),XDG_CACHE_HOME=str(out/'cache'),NODE_OPTIONS='--require='+str(out/'network-guard.cjs'),CI_R9_NETWORK_LOG=str(out/'raw'),CI='true')
started=time.time()
with (out/'raw'/f'{label}.stdout.log').open('w') as stdout,(out/'raw'/f'{label}.stderr.log').open('w') as stderr:
 r=subprocess.run(cmd,cwd=cwd,env=env,stdout=stdout,stderr=stderr)
record={'command':cmd,'cwd':str(cwd),'node':'/home/ricardo/.nvm/versions/node/v22.23.2/bin/node','exitCode':r.returncode,'elapsedSeconds':round(time.time()-started,3),'environment':'allowlisted; no provider/PG values; private TMPDIR/npm/cache; network deny preload','stdout':f'raw/{label}.stdout.log','stderr':f'raw/{label}.stderr.log'}
(out/'raw'/f'{label}.execution.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record));sys.exit(r.returncode)
