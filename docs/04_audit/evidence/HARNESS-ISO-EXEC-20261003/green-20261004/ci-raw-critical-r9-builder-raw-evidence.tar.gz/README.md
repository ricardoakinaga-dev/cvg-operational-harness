CI_RAW_CRITICAL_UNIT_MEMBERSHIP_R9 — IMPLEMENTED_NOT_ACCEPTED

Private candidate: /home/ricardo/.cache/cvg-harness-green-20261004/ci-raw-critical-r9-candidate
Five exact changed paths in build-manifest.json. changes.patch checked read-only against Source. 345 old +33 appended=378 PASS; original371/prefix113 and approved43 paths preserved.

Before native failures retained; after48/48 conform. Native Source8400 remeasured unchanged. Supplied generic7811 is a distinct historical frozen snapshot observation (path list not supplied); sparse-Git certification1808 is a third observed definition. No forced equality.

Lead integrates exact manifested bytes and obtains fresh independent review. Full suite/realPG/E2E/V8/remote/certify NOT_RUN. Source full metadata/hash sentinel PASS; Root/Main writes/network attempts/commits/push=0. Disk-space/evidence assembly failures and recovery retained.
