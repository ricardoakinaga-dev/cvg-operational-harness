import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
const candidate = path.resolve(import.meta.dirname, '../ci-raw-critical-r9-candidate')
const source = path.resolve(import.meta.dirname, '../candidate')
const { collectCandidateFiles, computeCandidateId, sha256Bytes } = await import(pathToFileURL(path.join(candidate, 'scripts/lib/certification-rules.mjs')))
const { sourceFiles, digest } = await import(pathToFileURL(path.join(candidate, 'scripts/hiso-contract.mjs')))
const native = sourceFiles(source)
const generic = collectCandidateFiles(source)
const projected = generic.map((r) => {
 const bytes = fs.readFileSync(path.join(candidate, r.path))
 return {...r,sha256:sha256Bytes(bytes),size:bytes.length}
})
const out=path.join(import.meta.dirname,'raw')
for(const [name,rows] of [['source-current-native-inputs',native],['source-current-generic-inputs',generic],['candidate-projected-generic-inputs',projected]]) fs.writeFileSync(path.join(out,name+'.json'),JSON.stringify(rows,null,2)+'\n')
const result={
 native:{count:native.length,sha256:digest(native),definition:'scripts/hiso-contract.mjs sourceFiles: filesystem inventory excludes root generated outputs and exact compiler-derived output leaves; includes opaque docs, nested helpers, evidence and generic-ignored source inputs'},
 certificationGitCollector:{count:generic.length,sha256:computeCandidateId(generic),definition:'scripts/lib/certification-rules.mjs collectCandidateFiles: git tracked plus non-ignored untracked regular files; CANDIDATE_EXCLUDED_PREFIXES/FILES exclude evidence/ledgers/state/generated outputs; tracked flag participates in hash'},
 candidateCertificationGitProjection:{count:projected.length,sha256:computeCandidateId(projected),definition:'Same read-only Source git path/tracked list; contents rehashed in private candidate. Private .git intentionally absent; this is a projection, not a git collection inside private copy.'},
 suppliedHistoricalGenericSnapshot:{count:7811,provenance:'User-supplied generic frozen Source snapshot observation; preserved as historical, not remeasured. Frozen path list was not supplied.',definition:'Generic frozen Source snapshot input list, distinct from native HISO sourceFiles and certification Git collection.',recomputed:false},
 nativeGenericDifference:'Native HISO8400 and supplied historical generic snapshot7811 are distinct definitions. Certification sparse-Git collector1808 is a third observation, not a replacement for7811. No forced equality or bar change.'
}
fs.writeFileSync(path.join(out,'input-count-definitions.json'),JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify(result))
