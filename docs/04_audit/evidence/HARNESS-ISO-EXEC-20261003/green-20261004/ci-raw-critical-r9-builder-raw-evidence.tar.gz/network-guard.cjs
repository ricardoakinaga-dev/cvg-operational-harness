const fs = require('node:fs')
const path = require('node:path')
const { syncBuiltinESMExports } = require('node:module')
const deny = (api) => (...args) => {
  const dir = process.env.CI_R9_NETWORK_LOG
  if (dir) fs.appendFileSync(path.join(dir, 'network-attempts.jsonl'), JSON.stringify({ api, pid: process.pid }) + '\n')
  throw new Error('CI_R9_NETWORK_FORBIDDEN:' + api)
}
for (const mod of ['node:dns','node:dns/promises']) {
 const value = require(mod)
 for (const name of Object.keys(value)) if (/^(lookup|resolve|reverse)/.test(name) && typeof value[name] === 'function') value[name] = deny(mod + ':' + name)
 if (value.Resolver) for (const name of Object.getOwnPropertyNames(value.Resolver.prototype)) if (/^(resolve|reverse)/.test(name)) value.Resolver.prototype[name] = deny(mod + ':Resolver.' + name)
}
const net = require('node:net')
net.connect = deny('net.connect')
net.createConnection = deny('net.createConnection')
net.Socket.prototype.connect = deny('net.Socket.connect')
require('node:tls').connect = deny('tls.connect')
for (const mod of ['node:http', 'node:https']) {
 const value = require(mod)
 value.request = deny(mod + '.request')
 value.get = deny(mod + '.get')
}
globalThis.fetch = deny('fetch')
syncBuiltinESMExports()
