
// R9 additions preserve the complete original 113-case prefix, including the
// native Pg ESM identity guard. These reports are pure synthetic JSON only.
describe('R9 raw critical branch threshold', () => {
  const rawCoverage = (covered, total) => {
    const paths = [...new Set(critical.groups.flatMap((g) => g.paths))]
    const summary = Object.fromEntries(
      paths.map((p) => [p, metrics(total, covered)])
    )
    summary.total = metrics(total * paths.length, covered * paths.length)
    return buildCoverageReport(summary, critical)
  }
  it.each([
    [94999, 100000],
    [949994, 1000000],
    [949995, 1000000],
    [949996, 1000000]
  ])('rejects raw %s/%s despite displayed 95', (covered, total) => {
    const report = rawCoverage(covered, total)
    expect(report.critical.groups.every((g) => g.metrics.branches.pct === 95))
      .toBe(true)
    expect(report.global.pass).toBe(true)
    expect(report.verdict).toBe('FAIL')
    expect(report.critical.failures).toEqual(
      critical.groups.map((g) => `critical_coverage_below_threshold:${g.id}`)
    )
    expect(() => snapshotSchema(report, 'coverage-critical')).toThrow()
    expect(() => verify('coverage-critical', report)).toThrow()
  })
  it.each([
    [94999, 100000],
    [949995, 1000000]
  ])('rejects a claimed rounded PASS for raw %s/%s', (covered, total) => {
    const report = rawCoverage(covered, total)
    report.verdict = 'PASS'
    report.failures = []
    report.critical.pass = true
    report.critical.failures = []
    expect(() => snapshotSchema(report, 'coverage-critical')).toThrow()
    expect(() => verify('coverage-critical', report)).toThrow()
  })
  it.each([
    [95000, 100000],
    [950000, 1000000],
    [95001, 100000],
    [100000, 100000]
  ])('admits raw boundary or above %s/%s', (covered, total) => {
    const report = rawCoverage(covered, total)
    expect(report.verdict).toBe('PASS')
    expect(report.critical.failures).toEqual([])
    expect(() => snapshotSchema(report, 'coverage-critical')).not.toThrow()
    expect(() => verify('coverage-critical', report)).not.toThrow()
  })
  it('uses the weighted group ratio, retaining the rounded projection', () => {
    const manifest = {
      branchThreshold: 95,
      groups: [{ id: 'weighted', paths: ['a.ts', 'b.ts'] }]
    }
    const report = buildCoverageReport(
      { total: metrics(1000, 950), 'a.ts': metrics(10, 0), 'b.ts': metrics(990, 950) },
      manifest
    )
    expect(report.verdict).toBe('PASS')
    expect(report.critical.groups[0].metrics.branches).toEqual({
      total: 1000, covered: 950, pct: 95
    })
    expect(report.critical.groups[0].files[0].metrics.branches.pct).toBe(0)
  })
  it('rejects aggregated zero denominators', () => {
    const report = rawCoverage(0, 0)
    expect(report.verdict).toBe('FAIL')
    expect(report.critical.failures).toEqual(
      critical.groups.map((g) => `critical_coverage_invalid:${g.id}:branches`)
    )
    expect(() => snapshotSchema(report, 'coverage-critical')).toThrow()
  })
})

describe('R9 unit collected membership before snapshot', () => {
  const selected = [
    row('tests/r9-a.test.js', 'same'),
    row('tests/r9-a.test.js', 'same'),
    row('tests/r9-a.test.js', 'different'),
    row('tests/r9-b.test.js', 'other file')
  ]
  const collected = inventory(selected)
  const unitGate = (skipPolicy = 'none') => ({
    id: 'unit', skipPolicy, artifacts: ['unit-report.json']
  })
  const producerAdmission = async (report, required = collected, policy = 'none') => {
    const { validateReport, snapshotOutputs } = await import('../scripts/hiso-ci.mjs')
    const working = temp(), output = temp()
    fs.writeFileSync(path.join(working, 'unit-report.json'), JSON.stringify(report))
    let error, skipped
    try {
      skipped = validateReport(unitGate(policy), working, {}, '', required)
      snapshotOutputs(working, output, unitGate(policy))
    } catch (caught) { error = caught }
    return { error, skipped, emitted: fs.existsSync(path.join(output, 'gate-outputs/unit/unit-report.json')) }
  }
  const snapshotAdmission = (report, required = collected, policy = 'none', more = {}) => {
    const d = temp(), p = 'gate-outputs/unit/unit-report.json'
    fs.mkdirSync(path.dirname(path.join(d, p)), { recursive: true })
    fs.writeFileSync(path.join(d, p), JSON.stringify(report))
    // Report-consistent executed projection must never replace collected scope.
    const executed = testReport(report, [...new Set(required.map((t) => t.file))], policy)
    return verifySnapshots({
      gate: unitGate(policy), entry: { outputs: [{ path: p }] }, directory: d,
      manifest: { testInventory: required, executedTestInventory: executed, ...more.manifest },
      expected: { requiredTestIds: required.map((t) => t.id), ...more.expected }
    })
  }
  it.each(['missing', 'renamed', 'extra', 'ancestor', 'moved file', 'missing suite', 'extra suite'])(
    'rejects %s before emitting any snapshot and downstream', async (kind) => {
      let chosen = [...selected]
      if (kind === 'missing') chosen.splice(0, 1)
      if (kind === 'renamed') chosen[2] = row(selected[2].file, 'renamed')
      if (kind === 'extra') chosen.push(selected[0])
      if (kind === 'moved file') chosen[2] = row(selected[3].file, selected[2].name)
      if (kind === 'missing suite') chosen.pop()
      if (kind === 'extra suite') chosen.push(row('tests/r9-outside.test.js'))
      const report = native(chosen)
      if (kind === 'ancestor') report.testResults[0].assertionResults[2].ancestorTitles = ['new parent']
      const observed = await producerAdmission(report)
      expect(observed.error).toBeInstanceOf(Error)
      expect(observed.emitted).toBe(false)
      expect(() => snapshotAdmission(report)).toThrow()
    }
  )
  it('accepts complete reversed membership with same-name duplicates', async () => {
    const report = native([...selected].reverse())
    const observed = await producerAdmission(report)
    expect(observed.error).toBeUndefined()
    expect(observed.skipped).toBe(0)
    expect(observed.emitted).toBe(true)
    expect(reports.gateTestReport(report, unitGate(), collected)).toEqual(
      snapshotAdmission(report).tests
    )
  })
  it('accepts duplicate titles distinguished by ancestor hierarchy', async () => {
    const cases = [row(selected[0].file, 'first > same'), row(selected[0].file, 'second > same')]
    const required = inventory(cases)
    const report = native(cases)
    report.testResults[0].assertionResults.forEach((t, i) => {
      t.ancestorTitles = [i === 0 ? 'first' : 'second']; t.title = 'same'
    })
    expect((await producerAdmission(report, required)).emitted).toBe(true)
    expect(() => snapshotAdmission(report, required)).not.toThrow()
  })
  it('binds only the supplied collected scope while requiring all its cases', async () => {
    const required = inventory(selected.slice(0, 3)), report = native(selected.slice(0, 3))
    expect((await producerAdmission(report, required)).emitted).toBe(true)
    expect(() => snapshotAdmission(report, required)).not.toThrow()
    expect((await producerAdmission(report, collected)).emitted).toBe(false)
    expect(() => snapshotAdmission(report, collected)).toThrow()
  })
  it('keeps an outside required id mandatory even with a matching execution projection', () => {
    const report = native(selected)
    const outside = inventory([row('tests/r9-outside.test.js')])[0]
    expect(() => snapshotAdmission(report, collected, 'none', {
      expected: { requiredTestIds: [...collected.map((t) => t.id), outside.id] }
    })).toThrow()
  })
  it('retains the exact executed status projection downstream', () => {
    const report = native(selected)
    const executed = testReport(report, [...new Set(selected.map((t) => t.file))])
    executed[0].status = 'pending'
    expect(() => snapshotAdmission(report, collected, 'none', {
      manifest: { executedTestInventory: executed }
    })).toThrow()
  })
  it.each(['pending', 'skipped', 'todo'])(
    'preserves catalog policy for %s without weakening no-skip gates', async (status) => {
      const report = native(selected)
      report.testResults[0].assertionResults[2].status = status
      report.numPassedTests--
      report.numPendingTests = status === 'todo' ? 0 : 1
      report.numTodoTests = status === 'todo' ? 1 : 0
      const allowed = await producerAdmission(report, collected, 'catalog')
      expect(allowed.error).toBeUndefined()
      expect(allowed.skipped).toBe(1)
      expect(allowed.emitted).toBe(true)
      expect(() => snapshotAdmission(report, collected, 'catalog')).not.toThrow()
      const denied = await producerAdmission(report)
      expect(denied.error).toBeInstanceOf(Error)
      expect(denied.emitted).toBe(false)
      expect(() => snapshotAdmission(report)).toThrow()
    }
  )
  it.each(['empty', 'failed', 'counter mismatch'])(
    'rejects %s without snapshot emission', async (kind) => {
      const report = native(selected)
      if (kind === 'empty') report.testResults[0].assertionResults = []
      if (kind === 'failed') report.testResults[0].assertionResults[0].status = 'failed'
      if (kind === 'counter mismatch') report.numPassedTests--
      const observed = await producerAdmission(report)
      expect(observed.error).toBeInstanceOf(Error)
      expect(observed.emitted).toBe(false)
      expect(() => snapshotAdmission(report)).toThrow()
    }
  )
})
