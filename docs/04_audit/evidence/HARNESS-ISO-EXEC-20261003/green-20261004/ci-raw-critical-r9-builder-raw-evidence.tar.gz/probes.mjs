import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
const root = path.resolve(import.meta.dirname, '../ci-raw-critical-r9-candidate')
const mod = (p) => import(pathToFileURL(path.join(root, p)))
const { buildCoverageReport } = await mod('scripts/lib/coverage-gate.mjs')
const { snapshotSchema, testReport, verifySnapshots } = await mod('scripts/hiso-reports.mjs')
const { validateReport, snapshotOutputs } = await mod('scripts/hiso-ci.mjs')
const { caseOccurrences } = await mod('scripts/hiso-inventory.mjs')
const { sourceFiles, digest } = await mod('scripts/hiso-contract.mjs')
const critical = JSON.parse(fs.readFileSync(path.join(root, 'scripts/critical-coverage-manifest.json')))
const phase = process.argv[2]
const dir = path.join(import.meta.dirname, 'raw', phase + '-probes')
fs.mkdirSync(dir, { recursive: true })
const rows = []
const observe = (label, expected, fn, extra = {}) => {
 let actual = 'ACCEPT', error
 try { fn() } catch (e) { actual = 'REJECT'; error = e.message }
 rows.push({ label, expected, actual, conforms: actual === expected, ...extra, ...(error ? { error } : {}) })
}
const dimension = (total, covered) => ({ total, covered, skipped: 0, pct: Number((covered/total*100).toFixed(2)) })
const metrics = (total,covered) => Object.fromEntries(['statements','lines','functions','branches'].map(k=>[k,dimension(total,covered)]))
const verify = (id,report,inventory = [], policy = 'none', required = inventory) => {
 const p = `gate-outputs/${id}/report.json`
 fs.mkdirSync(path.dirname(path.join(dir,p)),{recursive:true})
 fs.writeFileSync(path.join(dir,p),JSON.stringify(report,null,2)+'\n')
 const manifest = { testInventory: inventory }
 if(id==='unit') manifest.executedTestInventory = testReport(report,[...new Set(required.map(t=>t.file))],policy)
 return verifySnapshots({gate:{id,skipPolicy:policy},entry:{outputs:[{path:p}]},directory:dir,manifest,expected:{requiredTestIds:required.map(t=>t.id)}})
}
for(const [covered,total] of [[94999,100000],[949994,1000000],[949995,1000000],[949996,1000000],[95000,100000],[95001,100000],[0,0]]) {
 const summary = Object.fromEntries([...new Set(critical.groups.flatMap(g=>g.paths))].map(p=>[p,metrics(total,covered)]))
 summary.total = metrics(total * Object.keys(summary).length, covered * Object.keys(summary).length)
 const report = buildCoverageReport(summary,critical)
 const expectPass = total>0 && covered/total*100 >=95
 rows.push({label:`critical raw ${covered}/${total}`,expected:expectPass?'PASS':'FAIL',actual:report.verdict,conforms:report.verdict===(expectPass?'PASS':'FAIL'),displayPct:report.critical.groups[0].metrics.branches.pct,rawPct:total>0?covered/total*100:null})
 fs.writeFileSync(path.join(dir,`coverage-${covered}-${total}.json`),JSON.stringify(report,null,2)+'\n')
 observe(`critical schema ${covered}/${total}`,expectPass?'ACCEPT':'REJECT',()=>snapshotSchema(report,'coverage-critical'))
 observe(`critical verifier ${covered}/${total}`,expectPass?'ACCEPT':'REJECT',()=>verify('coverage-critical',report))
 // A stale rounded PASS envelope must fail reconstruction even when counters and displayed projection are unchanged.
 const claimed = structuredClone(report)
 claimed.verdict='PASS'; claimed.failures=[]; claimed.critical.pass=true; claimed.critical.failures=[]
 observe(`critical claimed PASS ${covered}/${total}`,expectPass?'ACCEPT':'REJECT',()=>snapshotSchema(claimed,'coverage-critical'))
}
const file='tests/scoped-r9.test.js', other='tests/other-r9.test.js'
const collected=caseOccurrences([{file,name:'same'},{file,name:'same'},{file,name:'other'}])
const native=(cases,policyStatus='passed')=>({success:true,numTotalTests:cases.length,numPassedTests:cases.filter(t=>(t.status??policyStatus)==='passed').length,numFailedTests:0,numFailedTestSuites:0,numPendingTests:cases.filter(t=>['pending','skipped'].includes(t.status??policyStatus)).length,numTodoTests:cases.filter(t=>(t.status??policyStatus)==='todo').length,testResults:[...new Set(cases.map(t=>t.file))].map(file=>({name:'/synthetic/'+file,status:'passed',assertionResults:cases.filter(t=>t.file===file).map(t=>({ancestorTitles:[],title:t.name,status:t.status??policyStatus}))}))})
for(const [label,cases,policy,required,expected] of [
 ['complete reversed', [...collected].reverse(),'none',collected,'ACCEPT'],
 ['missing occurrence',collected.slice(1),'none',collected,'REJECT'],
 ['renamed',collected.map((t,i)=>i===2?{...t,name:'replacement'}:t),'none',collected,'REJECT'],
 ['extra occurrence',[...collected,collected[0]],'none',collected,'REJECT'],
 ['wrong file',collected.map(t=>({...t,file:other})),'none',collected,'REJECT'],
 ['scoped subset complete',collected,'none',collected,'ACCEPT'],
 ['scope requires other suite',collected,'none',caseOccurrences([...collected,{file:other,name:'outside'}]),'REJECT'],
 ['scope leaks other suite',[...collected,{file:other,name:'outside'}],'none',collected,'REJECT'],
 ['catalog skip',collected.map((t,i)=>i===2?{...t,status:'pending'}:t),'catalog',collected,'ACCEPT'],
 ['forbidden skip',collected.map((t,i)=>i===2?{...t,status:'pending'}:t),'none',collected,'REJECT']
]) {
 const report=native(cases); const working=path.join(dir,label.replaceAll(' ','-'))
 fs.mkdirSync(working,{recursive:true});fs.writeFileSync(path.join(working,'unit.json'),JSON.stringify(report,null,2)+'\n')
 const gate={id:'unit',skipPolicy:policy,artifacts:['unit.json']}
 const target=path.join(working,'snapshot')
 observe(`unit admission ${label}`,expected,()=>{validateReport(gate,working,{},'',required);snapshotOutputs(working,target,gate)},{completeSnapshotEmitted:false})
 rows.at(-1).completeSnapshotEmitted=fs.existsSync(path.join(target,'gate-outputs/unit/unit.json'))
 observe(`unit verifier ${label}`,expected,()=>verify('unit',report,required,policy))
}
const inputs=sourceFiles(root)
fs.writeFileSync(path.join(import.meta.dirname,'raw',phase+'-native-inputs.json'),JSON.stringify(inputs,null,2)+'\n')
fs.writeFileSync(path.join(import.meta.dirname,'raw',phase+'-semantic-probes.json'),JSON.stringify({kind:'NATIVE_PURE_JSON_NO_EVALUATOR',phase,rows,nativeInputCount:inputs.length,nativeInputHash:digest(inputs)},null,2)+'\n')
console.log(JSON.stringify({phase,observations:rows.length,nonconforming:rows.filter(r=>!r.conforms),nativeInputCount:inputs.length,nativeInputHash:digest(inputs)}))
