from pathlib import Path
b=Path('/home/ricardo/.cache/cvg-harness-green-20261004');c=b/'c1-context-dependency-syntax-r12-candidate'
p=c/'scripts/boundary-manifests.mjs';s=p.read_text();s=s.replace('  const cache = new Map()','  const cache = new Map()\n  const censused = new Set()');old='''        if (/^(file|link):/.test(version.trim()))
          read(localPackage(filename, version), { requireName: true })''';new='''        if (/^(file|link):/.test(version.trim())) {
          const target = localPackage(filename, version)
          read(target, { requireName: true })
          census(path.dirname(target))
        }''';assert old in s;s=s.replace(old,new)
old='''    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {''';new='''    if (censused.has(directory)) return result
    censused.add(directory)
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {''';assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
p=c/'scripts/check-product-boundary.mjs';s=p.read_text();old='''    const targetOwner = owner(target)
    if (targetOwner && inside(productRoot, targetOwner.workspace))
      edge(file, workspaceNode(targetOwner))''';new='''    const targetOwner = owner(target)
    if (targetOwner) edge(file, workspaceNode(targetOwner))
    // A source reference makes its physical Node package context an actor.
    // Documentary trees remain opaque unless an implementation edge enters.
    let context = path.dirname(target)
    while (inside(root, context)) {
      const pkgFile = path.join(context, 'package.json')
      if (fs.existsSync(pkgFile)) {
        metadata.read(pkgFile)
        edge(file, pkgFile)
        // Context dependencies are metadata edges even for non-workspace actors.
        for (const [field, values] of Object.entries(metadata.cache.get(pkgFile))) {
          if (!manifestDependencyFields.includes(field)) continue
          for (const [name, version] of Object.entries(values)) {
            let dependency
            const specifier = version.trim()
            if (/^(file|link):/.test(specifier)) {
              const resolved = path.dirname(metadata.localPackage(pkgFile, version))
              dependency = [...workspaces.values()].find(item => item.workspace === resolved)
              if (!dependency) reportDiagnostic(pkgFile, {file: path.relative(root,pkgFile),specifier:name,reason:'UNVERIFIED_LOCAL_DEPENDENCY'})
            } else {
              let targetName = name
              if (specifier.startsWith('npm:')) {
                const alias = specifier.slice(4), separator = alias.lastIndexOf('@')
                targetName = separator > 0 ? alias.slice(0,separator) : alias
              }
              dependency = workspaces.get(targetName)
            }
            if (dependency) edge(pkgFile,workspaceNode(dependency))
          }
        }
        break
      }
      if (context === root) break
      context = path.dirname(context)
    }''';assert old in s;s=s.replace(old,new)
old='''          const target = path.resolve(
            item.workspace,
            specifier.slice(specifier.indexOf(':') + 1)
          )
          let resolved
          if (inside(root, target) && fs.existsSync(target))
            resolved = fs.realpathSync(target)''';new='''          const resolved = path.dirname(
            metadata.localPackage(workspaceNode(item), version)
          )''';assert old in s;s=s.replace(old,new)
# Trusted Node --check parses literal physical files; it never evaluates fixture text.
old='''    if (source.parseDiagnostics.length)
      reportDiagnostic(file, {''';new='''    const nativeJs = ['.js', '.mjs', '.cjs'].includes(path.extname(file))
      ? spawnSync(process.execPath, ['--check', file], {encoding:'utf8', timeout:10000,maxBuffer:1024*1024})
      : undefined
    if (source.parseDiagnostics.length || (nativeJs && nativeJs.status !== 0))
      reportDiagnostic(file, {''';assert old in s;s=s.replace(old,new);p.write_text(s)
print('R12 code implemented: workspace/context/local identity/native parse')
