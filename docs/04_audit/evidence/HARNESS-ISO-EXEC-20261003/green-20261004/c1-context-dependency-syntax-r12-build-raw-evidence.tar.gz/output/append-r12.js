
// R12: inert metadata, imports and grammar labels; fixtures never executed.
describe('R12 reached contexts, workspace dependencies and JS grammar', () => {
  function fixture(id, change) {
    const root = path.join(output, 'r12-inert', id)
    const put = (rel, value) => {
      const p = path.join(root, rel)
      fs.mkdirSync(path.dirname(p), { recursive: true })
      fs.writeFileSync(p, typeof value === 'string' ? value : JSON.stringify(value))
    }
    for (const p of ['packages/core/src','apps','legacy','products/consumer/src']) fs.mkdirSync(path.join(root,p),{recursive:true})
    const v={root:{private:true,type:'module',workspaces:['packages/*','products/*']},core:{name:'@synthetic/core',type:'module'},consumer:{name:'@synthetic/consumer',type:'module'}}
    put('packages/core/src/index.mts','export const label="neutral";')
    put('products/consumer/src/index.mts','export const label="synthetic-product";')
    put('tsconfig.base.json',{compilerOptions:{module:'NodeNext',moduleResolution:'NodeNext',target:'ESNext',allowJs:true}})
    change(v,put)
    put('package.json',v.root);put('packages/core/package.json',v.core);put('products/consumer/package.json',v.consumer)
    return root
  }
  const fields=['dependencies','devDependencies','optionalDependencies','peerDependencies']
  it.each(['legacy','tools','scripts','examples','config'].flatMap(actor=>fields.map(field=>[actor,field])))('relative %s/%s retains owner dependency closure',(actor,field)=>{
    const root=fixture(actor+'-'+field,(v,put)=>{
      v.root.workspaces.push(actor+'/*')
      put(actor+'/bridge/package.json',{name:'@synthetic/bridge',type:'module',[field]:{'@synthetic/consumer':'1.0.0'}})
      put(actor+'/bridge/src/index.mts','export const label="bridge";')
      put('packages/core/src/index.mts','import "../../../'+actor+'/bridge/src/index.mts";')
    })
    expect(auditProductBoundary(root).status).toBe('FAIL')
  })
  it.each(['legacy','tools','config'])('relative %s retains the owner unknown frontier',(actor)=>{
    const root=fixture('unknown-'+actor,(v,put)=>{
      v.root.workspaces.push(actor+'/*')
      put(actor+'/bridge/package.json',{name:'@synthetic/bridge',type:'module'})
      put(actor+'/bridge/src/index.mts','export const label="bridge";')
      put(actor+'/bridge/src/unverified.mts','import(label);')
      put('packages/core/src/index.mts','import "../../../'+actor+'/bridge/src/index.mts";')
    })
    expect(auditProductBoundary(root).status).toBe('INCOMPLETE')
  })
  it.each([
    ['shape',[]],['name',{name:23}],['type',{type:'not-a-format'}],['dep-map',{dependencies:[]}],
    ['alias',{dependencies:{neutral:'npm:neutral@file:bad'}}],['local',{dependencies:{neutral:'file:missing'}}]
  ])('reached source package context %s is governed metadata',(id,value)=>{
    const root=fixture('ctx-'+id,(v,put)=>{
      put('auxiliary/bridge/package.json',value)
      put('auxiliary/bridge/src/index.mts','export const label="bridge";')
      put('packages/core/src/index.mts','import "../../../auxiliary/bridge/src/index.mts";')
    })
    expect(()=>auditProductBoundary(root)).toThrow()
  })
  it.each(['root','core'])('local reference from %s extends nested actor census',(holder)=>{
    const root=fixture('local-census-'+holder,(v,put)=>{
      v[holder].dependencies={neutral:'file:'+(holder==='core'?'../../':'')+'auxiliary/bridge'}
      put('auxiliary/bridge/package.json',{name:'@synthetic/bridge'})
      put('auxiliary/bridge/dist/nested/package.json',[])
    })
    expect(()=>auditProductBoundary(root)).toThrow()
  })
  it.each(fields.flatMap(field=>[['neutral',field,'PASS'],['product',field,'FAIL']]))('encoded %s local identity through %s is shared',(kind,field,status)=>{
    const root=fixture('encoded-'+kind+'-'+field,(v,put)=>{
      if(kind==='neutral'){
        v.root.workspaces.push('auxiliary/*')
        put('auxiliary/bridge/package.json',{name:'@synthetic/bridge',type:'module'})
        put('auxiliary/bridge/src/index.mts','export const label="bridge";')
      }
      v.core[field]={neutral:'file:../../'+(kind==='neutral'?'auxiliary/%62ridge':'products/%63onsumer')}
    })
    expect(auditProductBoundary(root).status).toBe(status)
  })
  const invalidJS=['export interface Label {}','export type Label = string;','const label: string="x";','const label="x" as string;','function f(label?:string){}','declare const label:string;']
  it.each(['js','mjs','cjs'].flatMap(ext=>invalidJS.map((text,n)=>[ext,n,text])))('%s rejects TS-only inert label %s',(ext,n,text)=>{
    const result=inspect('r12-invalid-'+ext+'-'+n,text,ext)
    expect(result.status).toBe('INCOMPLETE')
    expect(result.diagnostics.some(d=>d.reason==='SOURCE_PARSE_ERROR')).toBe(true)
  })
  it.each(['js','mjs','cjs'])('%s preserves valid JavaScript labels',ext=>{
    expect(inspect('r12-valid-js-'+ext,ext==='cjs'?'const label="neutral";':'export const label="neutral";',ext).status).toBe('PASS')
  })
})
