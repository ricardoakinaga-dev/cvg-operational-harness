CI_PRODUCER_FRESH_REVIEW_R7 — AUDIT local em packet único.

Autoridade/freeze/inventário/AGENTS lidos. Hash+metadata completos before/after sem diferenças. Cópias físicas próprias. Vitest fornecido 315 PASS; build e smoke reais autorizados PASS; mock Pg validado 4 PASS/1 FAIL; 16 decisões JSON simétricas. Projeção neutral 250, full 281 preservado. Veredito REJECT, R7-CI-PG-001 P2.

Falhas de setup e cinco tentativas DNS indevidas no mock inicial preservadas; execuçãoProtocolFullyValid=false. Não contam como falhas candidatas. FullPG/E2E/coverage/remoteCI/certification NOT_RUN. Nenhuma correção, commit ou escrita de ledger externo. Next action: lead integra e remedia.
