import pathlib,shutil,os,json,stat
P=pathlib.Path(__file__).resolve().parent.parent; S=P/'source'; R=P/'output/runtime'
def physical(src,dst):
 fd=os.open(src,os.O_RDONLY|getattr(os,'O_NOATIME',0))
 with os.fdopen(fd,'rb') as f,open(dst,'wb') as g:shutil.copyfileobj(f,g,1024*1024)
 shutil.copystat(src,dst,follow_symlinks=False)
 return dst
shutil.copytree(S,R,symlinks=True,copy_function=physical)
external=[]; shared=[]; hard=[]; count=0
for dp,dns,fns in os.walk(R):
 for n in dns+fns:
  p=pathlib.Path(dp)/n; rel=p.relative_to(R); a=p.lstat(); b=(S/rel).lstat()
  if p.is_symlink():
   if not p.resolve().is_relative_to(R):external.append(str(rel))
  elif p.is_file():
   count+=1
   if a.st_nlink!=1:hard.append(str(rel))
   if (a.st_ino,a.st_dev)==(b.st_ino,b.st_dev):shared.append(str(rel))
r={'regularFiles':count,'externalSymlinks':external,'hardlinks':hard,'sourceSharedInodes':shared,'physical':not(external or hard or shared)}
(P/'output/proofs/runtime-copy.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
