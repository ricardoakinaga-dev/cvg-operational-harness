import fs from 'node:fs';import path from 'node:path';
import {prepareVariant,rulesHash} from './runtime/scripts/hiso-variant.mjs';
import {sourceFiles,sha,digest} from './runtime/scripts/hiso-contract.mjs';
import {approvedCoverageInventory} from './runtime/scripts/hiso-inventory.mjs';
const out=import.meta.dirname,root=path.join(out,'runtime'),target=path.join(out,'neutral');
const variant=prepareVariant(root,target,'harness-neutral');
fs.mkdirSync(path.join(target,'node_modules'),{recursive:true});
fs.cpSync(path.join(root,'node_modules/typescript'),path.join(target,'node_modules/typescript'),{recursive:true});
const inputs=sourceFiles(target),coverage=approvedCoverageInventory(target,inputs);
const configPaths=['package.json','package-lock.json','tsconfig.json','tsconfig.typecheck.json','vitest.config.mts','config/workspace-dependency-policy.json','docs/doc-link-policy.json'];
const binding=Object.fromEntries(configPaths.map(p=>[p,sha(fs.readFileSync(path.join(target,p)))]));
const config=path.join(target,'docs/doc-link-policy.json'),bytes=fs.readFileSync(config);const json=JSON.parse(bytes);json.inertReviewProbe=true;fs.writeFileSync(config,JSON.stringify(json));
let driftError=null;try{approvedCoverageInventory(target)}catch(e){driftError=e.message}finally{fs.writeFileSync(config,bytes)}
const result={mode:'PREPARE_VARIANT_AND_PURE_DENOMINATOR_ONLY',rulesHash,originalInputHash:variant.originalCandidateId,neutralInputHash:digest(inputs),neutralInputCount:inputs.length,removedProductInputs:variant.removed.length,productPhysicallyAbsent:!fs.existsSync(path.join(target,'products')),retainedFullCoverage:281,neutralCoverage:coverage.length,sevenConfigHashes:binding,configDriftFailsClosed:driftError==='hiso:approved_coverage_source_inventory',driftError,sourceMatchAfterProbe:digest(sourceFiles(root))===variant.originalCandidateId,neutralRestoredAfterProbe:digest(sourceFiles(target))===digest(inputs),runtimeDeps:'physical TypeScript copy, no shared inode or external symlink',executedPg:0,executedE2e:0,remoteCiPass:false};
fs.writeFileSync(path.join(out,'proofs/neutral-projection.json'),JSON.stringify(result,null,2));fs.writeFileSync(path.join(out,'proofs/neutral-variant-manifest.json'),JSON.stringify(variant,null,2));console.log(JSON.stringify(result));
