import {defineConfig} from './runtime/node_modules/vitest/dist/config.js';
export default defineConfig({resolve:{alias:{vitest:new URL('./runtime/node_modules/vitest/dist/index.js',import.meta.url).pathname}},test:{environment:'node',include:['pg-version-mock.test.mjs'],fileParallelism:false,maxWorkers:1}});
