import os,json,hashlib,stat,pathlib,sys
P=pathlib.Path(__file__).resolve().parent.parent; O=P/'output'; S=P/'source'
def digest(p):
 fd=os.open(p,os.O_RDONLY|getattr(os,'O_NOATIME',0)); h=hashlib.sha256()
 with os.fdopen(fd,'rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def snapshot(root):
 rows={}
 def visit(p):
  s=p.lstat(); k=p.relative_to(root).as_posix(); row={'mode':s.st_mode,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'uid':s.st_uid,'gid':s.st_gid,'inode':s.st_ino,'device':s.st_dev,'nlink':s.st_nlink}
  if stat.S_ISLNK(s.st_mode):row.update(kind='link',target=os.readlink(p))
  elif stat.S_ISREG(s.st_mode):row.update(kind='file',sha256=digest(p))
  elif stat.S_ISDIR(s.st_mode):row.update(kind='directory')
  else:row.update(kind='other')
  rows[k]=row
  if row['kind']=='directory':
   for q in sorted(p.iterdir()):visit(q)
 visit(root);return rows
phase=sys.argv[1]; rows=snapshot(S)
controls={n:{'sha256':digest(P/n),'mtime_ns':(P/n).stat().st_mtime_ns,'ctime_ns':(P/n).stat().st_ctime_ns,'mode':(P/n).stat().st_mode} for n in ['authority.json','freeze.json','frozen-inventory.json']}
inv=json.loads((P/'frozen-inventory.json').read_bytes()); diffs=[]
for k,v in inv.items():
 r=rows.get(k)
 if r is None or r['kind']!=v['kind'] or (v['kind']=='file' and (r['sha256']!=v['sha256'] or r['size']!=v['bytes'])) or (v['kind']=='link' and r['target']!=v['target']):diffs.append(k)
extras=[k for k,v in rows.items() if v['kind']!='directory' and k not in inv]
external=[k for k,v in rows.items() if v['kind']=='link' and not (S/k).resolve().is_relative_to(S)]
result={'phase':phase,'sourceEntries':len(rows),'regularFiles':sum(r['kind']=='file' for r in rows.values()),'links':sum(r['kind']=='link' for r in rows.values()),'directories':sum(r['kind']=='directory' for r in rows.values()),'inventorySha256':controls['frozen-inventory.json']['sha256'],'freezeValid':controls['frozen-inventory.json']['sha256']=='e7a3ac27d19ac0d90f8d052242f9044e2a8924053b423d2cbb415b917bdfb1a6','inventoryDifferences':diffs,'extraNonDirectories':extras,'externalSourceLinks':external,'metadataFields':'mode,size,mtime_ns,ctime_ns,uid,gid,inode,device,nlink; atime excluded because read access is not a write'}
(O/f'proofs/integrity-{phase}-full.json').write_text(json.dumps({'source':rows,'controls':controls},sort_keys=True))
if phase=='after':
 before=json.loads((O/'proofs/integrity-before-full.json').read_text());result['sourceBeforeAfterDifferences']=[k for k in sorted(rows.keys()|before['source'].keys()) if rows.get(k)!=before['source'].get(k)];result['controlBeforeAfterDifferences']=[k for k in controls if controls[k]!=before['controls'][k]]
(O/f'proofs/integrity-{phase}.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
