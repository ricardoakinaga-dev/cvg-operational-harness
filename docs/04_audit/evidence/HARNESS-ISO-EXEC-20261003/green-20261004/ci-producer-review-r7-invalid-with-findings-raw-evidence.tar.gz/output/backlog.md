CI_PRODUCER_FRESH_REVIEW_R7 — backlog local para integração pelo lead.

- R7-CI-PG-001 — P2, requisito bloqueante nesta revisão: safeinteger Pg16 no produtor antes de emitir. Prova do módulo real preservada em logs/pg-mock-vitest.json; não corrigido.
- OBS-IMPORTER — acompanhamento estático: nova admissão de snapshots não ocorre antes da emissão PASS do adapter; receipt genuíno e CLI NOT_RUN. Não afirmar bypass sem prova.
- REVIEW-MOCK-SETUP-001 — repetir futura prova só após confirmar mock/isolamento; houve cinco tentativas DNS na configuração inicial, reportadas. Fonte íntegra.
- FullPG/E2E/coverage/remoteCI/certification seguem NOT_RUN; nenhuma aprovação concedida por esta rodada.
