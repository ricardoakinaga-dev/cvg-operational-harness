import fs from 'node:fs';
import path from 'node:path';
import {it,expect,vi} from 'vitest';
const mock=vi.hoisted(()=>({value:'160000',queries:[],ends:0,connects:0}));
vi.mock('./runtime/node_modules/pg/esm/index.mjs',()=>({Client:class {
 async connect(){mock.connects++}
 async query(sql){mock.queries.push(sql);return {rows:[{server_version_num:mock.value}]}}
 async end(){mock.ends++}
}}));
for(const value of ['160000','169999','160000.5','159999','170000']) {
 it(`actual Pg CLI pure mock rejects non-Pg16-safeinteger ${value}`,async()=>{
  vi.resetModules();const admittedMock=await import('./runtime/node_modules/pg/esm/index.mjs');expect(admittedMock.Client.name).toBe('Client');const checkpoint=new admittedMock.Client();expect(checkpoint.connect.toString()).toContain('mock.connects');mock.value=value;mock.queries=[];mock.ends=0;mock.connects=0;
  const file=path.join(import.meta.dirname,'proofs',`pg-cli-${value}.json`);
  process.env.TEST_DATABASE_URL='mock-only-never-connect';process.env.CI_CANDIDATE_ID='a'.repeat(64);process.env.CI_RUN_ID='CI_PRODUCER_FRESH_REVIEW_R7';process.env.HISO_PG_VERSION_OUTPUT=file;
  let error=null;
  try{await import('./runtime/scripts/hiso-postgres-version.mjs')}catch(e){error=e.message}
  const emitted=fs.existsSync(file)?JSON.parse(fs.readFileSync(file)):null;
  fs.writeFileSync(path.join(import.meta.dirname,'proofs',`pg-mock-${value}.json`),JSON.stringify({rawDatabaseValue:value,converted:Number(value),connects:mock.connects,queries:mock.queries,ends:mock.ends,error,emitted,realPostgres:'NOT_RUN'},null,2));
  expect(mock.connects).toBe(1);expect(mock.queries).toEqual(['SHOW server_version_num']);expect(mock.ends).toBe(1);
  const valid=Number.isSafeInteger(Number(value))&&Number(value)>=160000&&Number(value)<170000;
  if(valid){expect(error).toBeNull();expect(emitted?.status).toBe('PASS')}
  else {expect(emitted, 'invalid version must be rejected before emission').toBeNull();expect(error).not.toBeNull()}
 });
}
