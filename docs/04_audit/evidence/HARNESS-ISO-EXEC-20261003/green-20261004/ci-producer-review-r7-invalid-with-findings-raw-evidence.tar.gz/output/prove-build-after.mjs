import fs from 'node:fs';import path from 'node:path';
import {sourceFiles,digest} from './runtime/scripts/hiso-contract.mjs';
const out=import.meta.dirname;
const before=JSON.parse(fs.readFileSync(path.join(out,'proofs/native-inputs-before.json'))),after=sourceFiles(path.join(out,'runtime'));
const b=new Map(before.map(f=>[f.path,f])),a=new Map(after.map(f=>[f.path,f]));
const differences=[...new Set([...b.keys(),...a.keys()])].filter(p=>JSON.stringify(b.get(p))!==JSON.stringify(a.get(p)));
const result={buildExitCode:Number(fs.readFileSync(path.join(out,'logs/public-build.exit'),'utf8')),beforeCount:before.length,afterCount:after.length,beforeInputHash:digest(before),afterInputHash:digest(after),stable:digest(before)===digest(after),differences,realPublicBuild:true};
fs.writeFileSync(path.join(out,'proofs/native-inputs-after-build.json'),JSON.stringify(after,null,2));fs.writeFileSync(path.join(out,'proofs/public-build-stability.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));
