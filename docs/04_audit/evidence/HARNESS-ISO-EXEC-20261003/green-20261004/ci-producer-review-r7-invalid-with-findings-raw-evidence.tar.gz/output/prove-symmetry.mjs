import fs from 'node:fs';import path from 'node:path';
import {validateReport} from './runtime/scripts/hiso-ci.mjs';
import {verifySnapshots} from './runtime/scripts/hiso-reports.mjs';
import {caseOccurrences} from './runtime/scripts/hiso-inventory.mjs';
import {computeMetrics} from './runtime/packages/agent-evals/src/metrics.ts';
import {buildCoverageReport} from './runtime/scripts/lib/coverage-gate.mjs';
const out=import.meta.dirname,root=path.join(out,'runtime'),cases=path.join(out,'schema-cases');fs.mkdirSync(cases,{recursive:true});
const binding={runId:'CI_PRODUCER_FRESH_REVIEW_R7',candidateId:'a'.repeat(64)};
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json')));
const results=[];
function check(label,id,report,inventory=[],desired='ACCEPT') {
 const dir=path.join(cases,label),rel='certification/report.json';fs.mkdirSync(path.dirname(path.join(dir,rel)),{recursive:true});fs.writeFileSync(path.join(dir,rel),JSON.stringify(report,null,2));
 const gate={id,skipPolicy:'none',artifacts:[rel]};
 const attempt=f=>{try{f();return {accepted:true,error:null}}catch(e){return {accepted:false,error:e.message}}};
 const producer=attempt(()=>validateReport(gate,dir,binding,'',inventory));
 const verifier=attempt(()=>verifySnapshots({gate,entry:{outputs:[{path:rel}]},directory:dir,manifest:{...binding,testInventory:inventory},expected:{}}));
 results.push({label,gate:id,expected:desired,producer,verifier,symmetric:producer.accepted===verifier.accepted,meetsExpected:producer.accepted===(desired==='ACCEPT')&&verifier.accepted===(desired==='ACCEPT'),proof:path.relative(out,path.join(dir,rel))});
}
function native(rows){return {success:true,numTotalTests:rows.length,numPassedTests:rows.length,numFailedTests:0,numFailedTestSuites:0,numPendingTests:0,numTodoTests:0,testResults:[...new Set(rows.map(r=>r.file))].map(file=>({name:file,status:'passed',assertionResults:rows.filter(r=>r.file===file).map(r=>({ancestorTitles:[],title:r.name,status:'passed'}))}))}}
const pgFiles=pkg.scripts['test:postgres'].split(/\s+/).filter(p=>p.endsWith('.test.ts'));
const chaosFiles=fs.readdirSync(path.join(root,'packages/chaos/src/__tests__')).filter(p=>p.endsWith('.test.ts')).map(p=>'packages/chaos/src/__tests__/'+p);
for(const [id,files] of [['postgres',pgFiles],['chaos',chaosFiles]]){
 const rows=files.map(file=>({file,name:'inert collected identity',kind:'INERT_COLLECTION_PROJECTION_NOT_EXECUTED'}));rows.push({...rows[0]});const inventory=caseOccurrences(rows);
 check(id+'-complete-duplicate-titles',id,native(rows),inventory);
 const missing=rows.slice(0,-1);check(id+'-missing-one-occurrence',id,native(missing),inventory,'REJECT');
 const renamed=structuredClone(rows);renamed[0].name='unknown identity';check(id+'-renamed',id,native(renamed),inventory,'REJECT');
 const wrong=native(rows);wrong.testResults[0].assertionResults[0].status='todo';wrong.numPassedTests--;wrong.numTodoTests++;check(id+'-status',id,wrong,inventory,'REJECT');
}
check('pg-fractional-emitted-report','postgres-version',JSON.parse(fs.readFileSync(path.join(out,'proofs/pg-cli-160000.5.json'))),[],'REJECT');
check('pg-safe-emitted-report','postgres-version',JSON.parse(fs.readFileSync(path.join(out,'proofs/pg-cli-160000.json'))));
const thresholds=JSON.parse(fs.readFileSync(path.join(root,'packages/agent-evals/src/eval-thresholds.json')));
function evalReport({failures=[],adversarial=0}={}) {
 const rows=Array.from({length:100},(_,i)=>({success:!failures.some(f=>f.index===i),adversarial:i<adversarial,failures:failures.find(f=>f.index===i)?.reasons??[],outcome:{structuredValid:true,escalation:'handoff',proposedCapabilities:[],latencyMs:1,costUsd:0}}));
 return {suiteId:'inert-generic-native-projection',agentId:'inert-not-instantiated',startedAt:'2026-10-05T00:00:00.000Z',finishedAt:'2026-10-05T00:00:01.000Z',verdict:'PASS',thresholds,metrics:computeMetrics(rows),failures:failures.map(f=>({scenarioId:'inert-'+f.index,reasons:f.reasons}))};
}
const ordinary=evalReport({failures:[{index:90,reasons:['intent_mismatch:inert']}],adversarial:20});check('eval-tolerable-ordinary-failure','evals',ordinary);
const group=evalReport({failures:[{index:0,reasons:['intent_mismatch:inert']}],adversarial:20});check('eval-tolerable-adversarial-failure','evals',group);
const half=evalReport();half.metrics.hallucinationRate=half.metrics.schemaFailureRate=0.001;check('eval-nonintegral-numerator','evals',half,[],'REJECT');
const falseGroup=evalReport();falseGroup.metrics.adversarialPassRate=.95;check('eval-impossible-failure-group','evals',falseGroup,[],'REJECT');
const critical=JSON.parse(fs.readFileSync(path.join(root,'scripts/critical-coverage-manifest.json')));
const metric=n=>Object.fromEntries(['statements','lines','functions','branches'].map(k=>[k,{total:n,covered:n,skipped:0,pct:n?100:null}]));
const summary=Object.fromEntries([...new Set(critical.groups.flatMap(g=>g.paths))].map(p=>[p,metric(20)]));summary.total=metric(10000);
const erasable=Object.keys(summary).find(p=>p!=='total'&&critical.groups.filter(g=>g.paths.includes(p)).every(g=>g.paths.length>1));
summary[erasable]=metric(0);const coverage=buildCoverageReport(summary,critical);check('critical-native-erased-file','coverage-critical',coverage);
const omitted=structuredClone(coverage);omitted.critical.groups.pop();check('critical-omitted-group','coverage-critical',omitted,[],'REJECT');
const report={mode:'PURE_NATIVE_COMPUTE_AND_INERT_JSON_PROJECTIONS_NO_EVALUATOR_OR_AGENT',checks:results.length,allExpected:results.every(r=>r.meetsExpected),allSymmetric:results.every(r=>r.symmetric),pgSelectedFiles:pgFiles.length,chaosSelectedFiles:chaosFiles.length,erasedCoveragePath:erasable,results,collectionWasExecuted:false,fullPg:'NOT_RUN',fullCoverage:'NOT_RUN'};
fs.writeFileSync(path.join(out,'proofs/admission-symmetry.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report));
