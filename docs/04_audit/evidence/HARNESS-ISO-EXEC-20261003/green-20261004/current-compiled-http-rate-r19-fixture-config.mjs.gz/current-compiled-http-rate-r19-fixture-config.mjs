export const config = {
  persona: { name: 'Controlled Agent', role: 'assistant', tone: 'calm' },
  greeting: 'Resposta controlada.',
  promptBlocks: [],
  responseTemplates: { unknown: 'Vou encaminhar.' },
  model: {
    provider: 'fake',
    model: 'deterministic-v1',
    temperature: 0,
    maxTokens: 128,
    timeoutMs: 1000,
    retries: 0,
    secretRef: 'secret://controlled/fake'
  },
  policies: {
    version: 'policy-v1',
    minConfidence: 0.7,
    lowConfidence: 'handoff',
    maxClarifications: 2,
    enabledActions: ['respond'],
    approvalActions: [],
    blockedActions: []
  },
  plugins: [],
  knowledge: [],
  handoff: {
    lowConfidenceDestination: 'controlled-reception',
    destinations: ['controlled-reception'],
    maxClarifications: 2
  }
}
