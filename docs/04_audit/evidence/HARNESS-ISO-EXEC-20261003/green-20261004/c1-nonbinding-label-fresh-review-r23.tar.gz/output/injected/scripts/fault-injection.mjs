import {createBoundaryLexical as base} from '../../source/scripts/boundary-lexical.mjs';
export function createBoundaryLexical(ts,source,commonJs,report) {
 const facade={...ts,createProgram(...args){
  const checker=ts.createProgram(...args).getTypeChecker();
  return {getTypeChecker:()=>new Proxy(checker,{get(target,name){
   if(name==='getSymbolAtLocation')return node=>{
    if(node.text==='forceBinding')throw new RangeError('Maximum call stack size exceeded');
    return target.getSymbolAtLocation(node);
   };
   return target[name];
  }})};
 }};
 return base(facade,source,commonJs,report);
}
