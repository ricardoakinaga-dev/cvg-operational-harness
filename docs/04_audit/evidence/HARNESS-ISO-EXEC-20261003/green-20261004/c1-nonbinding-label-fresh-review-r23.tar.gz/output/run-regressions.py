import subprocess,pathlib,json,os,re
out=pathlib.Path(__file__).resolve().parent
node='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node'
results=[]
for phase,rel in [('before','before/tests/regression32.test.js'),('after','source/tests/product-boundary-binding-query.test.js')]:
 command=[node,'--test','--import',str(out/'register-loader.mjs'),str(out/rel)]
 p=subprocess.run(command,cwd=out,env={**os.environ,'TMPDIR':str(out/'tmp')},capture_output=True,text=True,timeout=120)
 (out/f'regression32-{phase}.tap').write_text(p.stdout+p.stderr)
 item=dict(phase=phase,command=command,exit=p.returncode,counts={k:int(re.search(r'^# '+k+r' (\d+)$',p.stdout,re.M).group(1)) for k in ['tests','pass','fail','skipped'] if re.search(r'^# '+k+r' (\d+)$',p.stdout,re.M)})
 results.append(item);print(json.dumps(item),flush=True)
(out/'regression32-results.json').write_text(json.dumps(results,indent=2)+'\n')
