**ACCEPT — reparo C1 Source**, limitado aos cinco módulos e às 32 regressões. Não adjudica o perfil instalado ou release.

| Evidência executada em Node 22.23.2 | Resultado |
| --- | --- |
| Mesmas 32 regressões, módulos anteriores R20 | 26 PASS / 6 FAIL / 0 SKIP |
| Mesmas 32 regressões, Source reparado | 32 PASS / 0 FAIL / 0 SKIP |
| Probes independentes de AST e scanner | 45 PASS / 0 FAIL |
| Callback integrado e dois mutantes próprios | 3 PASS / 0 FAIL |
| Integridade dos inputs rastreados | 72/72 MATCH hash, bytes, mode, mtime |
| Freeze do packet | 6/6 MATCH |

TypeScript físico: 6.0.3, 9.144.216 bytes, SHA-256 `569177652966bd528c319171c7dd22860dbf72bde116cbc4f644f1d02bb12e39`; semver 7.7.4. Cópia inicial de aproximadamente 9,6 MB, sem clone de dependências de 650 MB. Todas as execuções usaram `/home/ricardo/.nvm/versions/node/v22.23.2/bin/node`.

No arquivo TypeScript real copiado do Source, o Identifier `length` no offset **4023392**, em `length: length2`, provoca RangeError no R19 e identidade unavailable no R20. O reparo devolve undefined para o label, sem diagnóstico, preservando o binding real `length2`. Instrumentação independente confirma zero queries para os labels e nomes de PropertyAccess/MetaProperty. O novo guard usa identidade exata `Identifier == BindingElement.propertyName`, portanto não apaga nomes ligados nem filhos de chave computada. Evidência: [contraprova antes/depois](length-counterexample.json).

As identidades de aliases, shorthand, default parameters, CJS var/const, computed, nested e exports passam. Quatro operações necessárias (`getSymbolAtLocation`, `getShorthandAssignmentValueSymbol`, `getExportSpecifierLocalTargetSymbol`, `resolveName`) conservam unavailable separado de globals; ausência de callback lança erro com a causa original, e erros não relacionados propagam. Injeção própria na fronteira real lexical→checker prova diagnóstico `UNAVAILABLE_LEXICAL_BINDING_ANALYSIS`, `INCOMPLETE` e `passed=false`. [Probes próprios](own-probes.json), [integração e mutantes](integration-faults.json).

Os 21 negativos do scanner mantêm produto em chave computada como FAIL; eval/Function e loaders/factories recuperados por destructuring/globalThis/module, com aquisição não resolvida, continuam INCOMPLETE ou FAIL. Assignments, exports, defaults, sombras e mutações de metadata/origem permanecem recusados. Os sete positivos de integração passam. A fila de manifesto passa a visitar o runtime físico: o negativo próprio muda de INCOMPLETE sem testemunha para FAIL com `packages/core/package.json → node_modules/own-vendor/index.js → products/shift/marker.js`. Nenhum payload foi executado. [Fila antes/depois](own-fixtures/manifest-queue/before-after.json).

O prefixo R20 de **10.456 bytes**, contendo 22 casos, é byte exato; seguem dez novos casos. As asserts originais permanecem intactas. As três suítes de controle existentes no R19 também são byte idênticas. O adapter próprio executa as 32 asserts através de Node native tests e assert estrito, somente com os matchers utilizados. [Comparação](comparisons.json), [TAP antes](regression32-before.tap), [TAP depois](regression32-after.tap).

Inspeção real integral dos cinco módulos: lexical e checker contêm o reparo; execution, manifests e path grammar são byte idênticos ao R19. Computed expressions continuam na AST completa, propagação de capabilities conserva nós originais e joins, e controles de proveniência física, containment, symlink e erro não são reduzidos. Nenhum bloqueador encontrado no escopo.

A comparação ampla apenas das árvores scripts/tests observou seis deltas perante R19: os três paths do reparo e, fora desta revisão, `scripts/hiso-baseline-inventory.json`, `tests/hiso-ci-scopes.test.js` e o novo `tests/product-boundary-manifest-runtime.test.js`. Assim, o aceite não afirma que o candidato inteiro tenha apenas três deltas. [Inventário observado](scripts-tests-deltas.json).

Limites finitos: perfil instalado de 48 links **NOT_RUN**, full installed CLI **NOT_RUN**, scanner instalado amplo **NOT_RUN**, aproximadamente 9000 unknowns e release **NOT_ADJUDICATED**. O produtor informou 1255 PASS/5 files/0 SKIP, typecheck/lint PASS e 7818 inputs MATCH; são informação recebida do usuário, não execuções desta lane. Não se exige barra adicional de versão/wholeJS/CLI para este aceite.

Raw failures preservadas, incluindo as seis falhas do baseline, a stack real e falhas de bootstrap do harness próprio; estas últimas foram corrigidas somente em output e não contam como defeitos do Source. O R20 foi composto com seus dois módulos congelados e os três supporting modules comprovadamente iguais ao R19. A injeção integrada foi feita apenas em cópia própria; a contraprova TypeScript real não foi injetada. Integridade independente cobre 72 inputs, não reexecuta o census de 7818 arquivos. [Fingerprints finais](inputs-final.json), [freeze](freeze-check.json), [manifest de artefatos](artifact-manifest.json).

Source permaneceu somente leitura. Nenhum Root ledger/coord/prior judgment, .env/key, provider/rede/PG/install/subagent foi usado. Os relatórios ficam exclusivamente no output autorizado. Próximo passo: utilizar este aceite apenas para o reparo; qualificação instalada permanece com a outra lane.
