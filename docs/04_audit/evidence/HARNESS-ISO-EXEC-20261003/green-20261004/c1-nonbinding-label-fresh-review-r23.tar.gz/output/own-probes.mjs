import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import ts from 'typescript';
import {fileURLToPath} from 'node:url';
import {createBoundaryLexical as repaired} from './source/scripts/boundary-lexical.mjs';
import {createBoundaryLexical as before} from './before/scripts/boundary-lexical.mjs';
import {createBoundaryLexical as original} from './original/scripts/boundary-lexical.mjs';
import {auditProductBoundary as audit} from './source/scripts/check-product-boundary.mjs';
import {auditProductBoundary as oldAudit} from './original/scripts/check-product-boundary.mjs';
const out=path.dirname(fileURLToPath(import.meta.url));
const results=[];
function run(id,fn){try{const evidence=fn();results.push({id,status:'PASS',evidence});console.log('PASS',id)}catch(e){results.push({id,status:'FAIL',error:{name:e.name,message:e.message,stack:e.stack}});console.log('FAIL',id,e.stack)}fs.writeFileSync(path.join(out,'own-probes.json'),JSON.stringify({node:process.version,typescript:ts.version,fixturesExecuted:false,results},null,2)+'\n')}
function parse(text,file='/inert/own.mts'){const source=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true);assert.deepEqual(source.parseDiagnostics,[]);return source}
function nodes(source,select){const found=[];function walk(n){if(select(n))found.push(n);ts.forEachChild(n,walk)}walk(source);return found}
function facade(method, callback) {
  return {
    ...ts,
    createProgram(...args) {
      const checker = ts.createProgram(...args).getTypeChecker();
      return {
        getTypeChecker: () => new Proxy(checker, {
          get(target, name) {
            if (name === method) return (...params) => callback(target, ...params);
            return target[name];
          }
        })
      };
    }
  };
}
run('installed-length-label-before-after',()=>{
 const file=ts.sys.getExecutingFilePath(),text=fs.readFileSync(file,'utf8');
 const trace={file,bytes:Buffer.byteLength(text),offset:4023392,observations:[]};
 for(const [id,create] of [['originalR19',original],['beforeR20',before],['repairedR22',repaired]]){
  const source=parse(text,file);const label=nodes(source,n=>ts.isIdentifier(n)&&n.getStart(source)===4023392)[0];assert.equal(label.text,'length');assert.equal(label.parent.getText(source),'length: length2');
  const unavailable=[];const lex=create(ts,source,true,d=>unavailable.push(d));let value,err;try{value=lex.identity(label)}catch(e){err=e}
  const row={id,label:label.getText(source),parent:label.parent.getText(source),undefinedIdentity:value===undefined,unavailable,error:err&&{name:err.name,message:err.message,stack:err.stack}};
  trace.observations.push(row);fs.writeFileSync(path.join(out,'length-counterexample.json'),JSON.stringify(trace,null,2)+'\n');
  if(id==='repairedR22'){assert.equal(err,undefined);assert.equal(value,undefined);assert.deepEqual(unavailable,[]);const binding=label.parent.name;assert.equal(binding.text,'length2');const key=lex.identity(binding);assert.ok(key.declarations.includes(binding.parent));assert.notEqual(key,lex.global('length2'));row.actualLength2Bound=true}
  else if(id==='beforeR20'){assert.equal(unavailable.length,1);assert.equal(value?.unavailable.reason,'UNAVAILABLE_LEXICAL_BINDING_ANALYSIS')}
  else assert.ok(err instanceof RangeError);
 }
 fs.writeFileSync(path.join(out,'length-counterexample.json'),JSON.stringify(trace,null,2)+'\n');return trace;
});
run('no-checker-query-for-labels-members-meta',()=>{
 const source=parse('const {length:length2,require:load}=data; const a=subject.eval; const b=import.meta.url; length2; load;');
 const skip=nodes(source,n=>ts.isIdentifier(n)&&((ts.isBindingElement(n.parent)&&n.parent.propertyName===n)||((ts.isPropertyAccessExpression(n.parent)||ts.isMetaProperty(n.parent))&&n.parent.name===n)));
 let count=0;const api=facade('getSymbolAtLocation',(checker,n)=>{count++;return checker.getSymbolAtLocation(n)});const lex=repaired(api,source);
 for(const n of skip)assert.equal(lex.identity(n),undefined);assert.equal(count,0);
 for(const name of ['length2','load']){const [decl,ref]=nodes(source,n=>ts.isIdentifier(n)&&n.text===name);assert.equal(lex.identity(decl),lex.identity(ref));assert.notEqual(lex.identity(ref),lex.global(name))}
 return {skipped:skip.map(n=>({name:n.text,pos:n.getStart(source)})),valueQueries:count};
});
for(const [id,text,name,commonJs,expectGlobal] of [
 ['renamed','const {eval:run}=data;run','run',false,false],
 ['shorthand','const {require}=data;require','require',false,false],
 ['nested','const {data:{length:require}}=input;require','require',false,false],
 ['computed','const key="length";const {[key]:value}=input;key;value','key',false,false],
 ['CJS-var','var {length:require}=input;require','require',true,true],
 ['CJS-const','const {length:require}=input;require','require',true,false],
 ['export-alias','const {length:value}=input;export {value as length};','value',false,false],
 ['default-parameter','const require=outer;function f({length:value=require}={}){function require(){} return value}','require',false,false]
])run('identity-'+id,()=>{const source=parse(text,commonJs?'/inert/own.cjs':'/inert/own.mts');const lex=repaired(ts,source,commonJs);const selected=nodes(source,n=>ts.isIdentifier(n)&&n.text===name);const first=lex.identity(selected[0]);const ref=id==='default-parameter'?selected[1]:selected.at(-1);assert.equal(lex.identity(ref),first);assert.equal(first===lex.global(name),expectGlobal);return {text,name,commonJs,expectGlobal}});
const necessary=[
 ['getSymbolAtLocation','const handle=unknown;handle;',n=>ts.isExpressionStatement(n.parent)],
 ['getShorthandAssignmentValueSymbol','const handle=unknown;const data={handle}',n=>ts.isShorthandPropertyAssignment(n.parent)],
 ['getExportSpecifierLocalTargetSymbol','const handle=unknown;export {handle as value}',n=>ts.isExportSpecifier(n.parent)&&n.parent.propertyName===n],
 ['resolveName','const handle=unknown;function f(value=handle){function handle(){}return value}',n=>ts.isParameter(n.parent)&&n.parent.initializer===n]
];
for(const [operation,text,select] of necessary)run('necessary-stack-'+operation,()=>{const source=parse(text);const n=nodes(source,n=>ts.isIdentifier(n)&&n.text==='handle'&&select(n))[0];assert.ok(n);const error=new RangeError('Maximum call stack size exceeded');const api=facade(operation,()=>{throw error});const reports=[];const lex=repaired(api,source,false,d=>reports.push(d));const key=lex.identity(n);assert.equal(lex.identity(n),key);assert.equal(key.unavailable.reason,'UNAVAILABLE_LEXICAL_BINDING_ANALYSIS');assert.notEqual(key,lex.global('handle'));assert.equal(key.declarations,undefined);assert.equal(reports.length,1);assert.equal(reports[0].operation,operation);assert.throws(()=>repaired(api,source).identity(n),e=>e.cause===error&&e.message.startsWith('boundary_lexical_analysis_incomplete:'));return {reports,callbackRequired:true,originalCauseRetained:true}});
for(const error of [new TypeError('own unrelated defect'),new RangeError('own unrelated range')])run('unrelated-'+error.name,()=>{const source=parse('const handle=unknown;handle');const n=nodes(source,n=>ts.isIdentifier(n)&&n.text==='handle'&&ts.isExpressionStatement(n.parent))[0];const reports=[];assert.throws(()=>repaired(facade('getSymbolAtLocation',()=>{throw error}),source,false,d=>reports.push(d)).identity(n),e=>e===error);assert.deepEqual(reports,[]);return {sameError:true,reports}});
function fixture(id,text,ext='mts',extra={}){const root=path.join(out,'own-fixtures',id);const write=(relative,content)=>{const file=path.join(root,relative);fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,content)};
 for(const dir of ['packages/core/src','apps','legacy','products'])fs.mkdirSync(path.join(root,dir),{recursive:true});
 write('package.json',JSON.stringify({private:true,type:'module',workspaces:['packages/*']}));write('packages/core/package.json',JSON.stringify({name:'@own/core',version:'1.0.0',type:ext==='cjs'?'commonjs':'module'}));
 write('tsconfig.base.json',JSON.stringify({compilerOptions:{module:'NodeNext',moduleResolution:'NodeNext',target:'ESNext',allowJs:true}}));write('packages/core/src/neutral.ts','export const neutral="synthetic";');
 write('products/shift/marker.js','throw new Error("OWN_INERT_NEVER_EXECUTE");');write(`packages/core/src/entry.${ext}`,text);
 for(const [file,contents]of Object.entries(extra))write(file,contents);parse(text,path.join(root,`packages/core/src/entry.${ext}`));return root;
}
const negativeCases=[
 ['computed-product','const {[require("../../../products/shift/marker.js")]:v}=data;export {v};','FAIL','CORE_DEPENDS_ON_PRODUCT'],
 ['eval-destructuring','const {eval:run}=globalThis;run("OWN_INERT")','INCOMPLETE'],
 ['Function-destructuring','const {Function:Build}=globalThis;new Build("OWN_INERT")','INCOMPLETE'],
 ['eval-nested','const {globalThis:{eval:run}}=globalThis;run("OWN_INERT")','INCOMPLETE'],
 ['global-require-unknown','const {require:load}=globalThis;load(unknown)','INCOMPLETE'],
 ['module-require-unknown','const {require:load}=module;load(unknown)','INCOMPLETE'],
 ['module-createRequire-unknown','import * as mod from "node:module";const {createRequire:make}=mod;const load=make(unknown);load(unknown)','INCOMPLETE'],
 ['computed-eval','const key=unknown;const {[key]:run}=globalThis;run("OWN_INERT")','INCOMPLETE'],
 ['fallback-evaluator','const {eval:run=Function}=data;run("OWN_INERT")','INCOMPLETE'],
 ['shorthand-export','const data={require};export {data}','INCOMPLETE'],
 ['loader-export','import {createRequire as make} from "node:module";export {make as length}','INCOMPLETE'],
 ['nested-module-loader','const {require:load}=module;load("../../../products/shift/marker.js")','FAIL','CORE_DEPENDS_ON_PRODUCT'],
 ['global-require-product','const {require:load}=globalThis;load("../../../products/shift/marker.js")','FAIL','CORE_DEPENDS_ON_PRODUCT'],
 ['factory-alias-product','import * as mod from "node:module";const {createRequire:make}=mod;const load=make(import.meta.url);load("../../../products/shift/marker.js")','FAIL','CORE_DEPENDS_ON_PRODUCT'],
 ['evaluator-assignment','let run=()=>0;({eval:run}=globalThis);run("OWN_INERT")','INCOMPLETE'],
 ['loader-assignment','let load=()=>0;({require:load}=module);load(unknown)','INCOMPLETE'],
 ['default-shadow-body','function f(value=require){function require(){}return value};export {f}','INCOMPLETE'],
 ['metadata-mutation','const run=eval;run.length=Function;export const value=run.length','INCOMPLETE'],
 ['CJS-filename-mutation','const {createRequire:make}=require("node:module");__filename=unknown;const load=make(__filename);load("node:path")','INCOMPLETE',undefined,'cjs'],
 ['factory-symbol-shadow','import {createRequire as make} from "node:module";function f(__filename){const load=make(__filename);load("node:path")}export {f}','INCOMPLETE'],
 ['label-cannot-suppress-global-eval','const {eval:label}=data;eval("OWN_INERT")','INCOMPLETE']
];
const positives=[
 ['neutral-labels','const {require:r,eval:e,Function:f,length:length2}=data;export {r,e,f,length2};'],
 ['neutral-local-shadow','function f(eval=()=>"inert",Function=()=>"inert"){return eval()+Function()}export {f};'],
 ['neutral-CJS-shadow','const require=()=>"inert";const {length:eval}=data;require("inert");export const value=eval;'],
 ['neutral-computed','const key="length";const {[key]:value}=data;export {value};'],
 ['factory-known-builtin','import * as mod from "node:module";const {createRequire:make}=mod;const load=make(import.meta.url);load("node:path");'],
 ['metadata-scalar','export const value=Function.length;'],
 ['nested-neutral','const {data:{length:value}}=input;export {value};']
];
for(const [id,text,status,reason,ext]of negativeCases)run('scanner-'+id,()=>{const root=fixture(id,text,ext);const result=audit(root);fs.writeFileSync(path.join(root,'audit.json'),JSON.stringify(result,null,2)+'\n');assert.equal(result.passed,false);assert.equal(result.status,status);if(reason)assert.ok(result.violations.some(v=>v.reason===reason));return {text,...result}});
for(const [id,text]of positives)run('scanner-'+id,()=>{const root=fixture(id,text);const result=audit(root);fs.writeFileSync(path.join(root,'audit.json'),JSON.stringify(result,null,2)+'\n');assert.equal(result.status,'PASS');assert.deepEqual(result.diagnostics,[]);assert.deepEqual(result.violations,[]);return {text,...result}});
run('manifest-runtime-queue-before-after',()=>{const root=fixture('manifest-queue','export const neutral=1','mts',{
 'packages/core/package.json':JSON.stringify({name:'@own/core',version:'1.0.0',type:'module',dependencies:{'own-vendor':'1.0.0'}}),
 'node_modules/own-vendor/package.json':JSON.stringify({name:'own-vendor',version:'1.0.0',type:'module',main:'index.js'}),
 'node_modules/own-vendor/index.js':'import "../../products/shift/marker.js";throw new Error("NEVER_EXECUTE_VENDOR")'
 });const old=oldAudit(root),now=audit(root);assert.equal(old.violations.length,0);assert.equal(now.status,'FAIL');assert.ok(now.violations.some(v=>v.reason==='CORE_DEPENDS_ON_PRODUCT'));assert.ok(now.sourceFiles>old.sourceFiles);fs.writeFileSync(path.join(root,'before-after.json'),JSON.stringify({old,now},null,2));return {old,now}});
fs.writeFileSync(path.join(out,'own-summary.json'),JSON.stringify({pass:results.filter(x=>x.status==='PASS').length,fail:results.filter(x=>x.status==='FAIL').length,total:results.length},null,2)+'\n');
process.exitCode=results.some(x=>x.status==='FAIL')?1:0;
