import assert from 'node:assert/strict';
import {describe as suite,it as test,after as afterAll} from 'node:test';
import {format} from 'node:util';
export {afterAll};
export const describe=suite;
export const it = Object.assign(test, {
  each(cases) {
    return (name, fn) => {
      for (const entry of cases) {
        const args = Array.isArray(entry) ? entry : [entry];
        test(format(name, ...args), () => fn(...args));
      }
    };
  }
});
export function expect(actual,message){
 const make=(neg=false)=>{const check=(fn)=>{if(!neg)return fn();assert.throws(fn,assert.AssertionError,message);};return {
 get not(){return make(!neg)},
 toBe(value){check(()=>assert.strictEqual(actual,value,message))},
 toEqual(value){check(()=>assert.deepStrictEqual(actual,value,message))},
 toBeUndefined(){check(()=>assert.strictEqual(actual,undefined,message))},
 toBeGreaterThanOrEqual(value){check(()=>assert.ok(actual>=value,message))},
 toContain(value){check(()=>assert.ok(actual.includes(value),message))},
 toThrow(value){check(()=>{assert.equal(typeof actual,'function');let err;try{actual()}catch(e){err=e}assert.ok(err,'expected exception');if(value instanceof Error)assert.strictEqual(err,value);else if(typeof value==='string')assert.ok(err.message.includes(value));else if(value instanceof RegExp)assert.match(err.message,value);});}
 }};return make();
}
