from pathlib import Path
import json,hashlib,stat,datetime,re
out=Path(__file__).resolve().parent;packet=out.parent
load=lambda name:json.loads((out/name).read_text())
checks=load('inputs-final.json');freeze=load('freeze-check.json');regressions=load('regression32-results.json');own=load('own-probes.json');faults=load('integration-faults.json');comp=load('comparisons.json');controls=load('original-controls.json');deltas=load('scripts-tests-deltas.json')
assert all(x['match'] for x in checks+freeze)
assert regressions[0]['counts']=={'tests':32,'pass':26,'fail':6,'skipped':0}
assert regressions[1]['counts']=={'tests':32,'pass':32,'fail':0,'skipped':0}
assert all(x['status']=='PASS' for x in own['results']+faults['results'])
assert comp[-1]['prefixExact']
artifact=[]
for p in sorted(out.rglob('*')):
 if p.is_file() and p.name not in ['report.json','report.md','artifact-manifest.json']:
  s=p.stat();artifact.append({'path':str(p.relative_to(out)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'mtimeNs':str(s.st_mtime_ns)})
(out/'artifact-manifest.json').write_text(json.dumps(artifact,indent=2)+'\n')
criteria=[
 {'id':'C1-QUEUE','status':'PASS','evidence':['check-product-boundary.mjs.original.diff','own-fixtures/manifest-queue/before-after.json'],'observation':'Resolved manifest-only physical runtime entry now enters the parsed source queue; bounded negative changes INCOMPLETE/no product witness to FAIL with manifest -> vendor index.js -> product marker witness. Existing uncertainty diagnostic is retained.'},
 {'id':'C1-LABEL','status':'PASS','evidence':['length-counterexample.json','own-probes.json','regression32-after.tap'],'observation':'Actual TS length label at 4023392: R19 RangeError, R20 unavailable binding, repaired undefined identity with zero unavailable reports. Actual length2 BindingElement declaration remains bound. Instrumented member/MetaProperty/BindingElement labels produce zero symbol queries.'},
 {'id':'C1-SEMANTICS','status':'PASS','evidence':['own-probes.json','regression32-after.tap'],'observation':'Renamed/shorthand/computed/nested/export/default-parameter binding identities and CJS wrapper var versus const controls retained.'},
 {'id':'C1-FAIL-CLOSED','status':'PASS','evidence':['own-probes.json','integration-faults.json'],'observation':'Four necessary checker operations report exact stack RangeError once per cached identifier, retain unavailable identity distinct from globals, and require callback or throw with original cause. Unrelated TypeError/RangeError propagate. Own injected real checker callback yields INCOMPLETE/passed=false.'},
 {'id':'C1-NEGATIVES','status':'PASS','evidence':['own-probes.json'],'observation':'21 scanner negatives include computed product import, evaluator/loader/factory recovery, assignments, shadows, exports, fallback evaluators and metadata/filename mutations. Product edges FAIL; unsupported acquisition/evaluation remains INCOMPLETE, never PASS. Seven independent scanner positives retain PASS.'},
 {'id':'C1-REGRESSIONS','status':'PASS','evidence':['comparisons.json','original-controls.json','regression32-before.tap','regression32-after.tap'],'observation':'Same 15190-byte regression file executed unchanged on owned before/after modules using Node native tests plus finite strict-assert matcher adapter; 22 R20 cases preserved as exact 10456-byte prefix plus ten R22 cases. Before 26/6, after 32/0, zero skips. Three existing original control files byte identical.'},
 {'id':'C1-MUTANTS','status':'PASS','evidence':['integration-faults.json','regression32-before.tap'],'observation':'Exact omission of new guard fails six existing assertions; overbroad BindingElement skip defeats binding identity; false global recovery defeats unavailable separation.'},
 {'id':'C1-INTEGRITY','status':'PASS','evidence':['inputs-initial.json','inputs-final.json','freeze-check.json','artifact-manifest.json'],'observation':f'{len(checks)}/{len(checks)} tracked read-only input hash/size/mode/mtime records unchanged; packet freeze 6/6 MATCH. Owned copies include physical TypeScript/semver, no 650MB dependency clone.'}
]
report={
 'task':'C1_NONBINDING_LABEL_FRESH_REVIEW_R23','verdict':'ACCEPT','scope':'Source repair only: five modules and 32 binding regressions, with bounded independent AST/integration probes. No release or installed-closure adjudication.',
 'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'authority':json.loads((packet/'authority.json').read_text()),
 'runtime':{'node':'v22.23.2','nodePath':'/home/ricardo/.nvm/versions/node/v22.23.2/bin/node','typescript':'6.0.3','semver':'7.7.4','typescriptPhysicalBytes':9144216,'typescriptSha256':'569177652966bd528c319171c7dd22860dbf72bde116cbc4f644f1d02bb12e39','labelOffset':4023392,'tooling':'Physical copies in output/node_modules; no installed CLI required or run'},
 'execution':{'regression32':regressions,'independentOwn':load('own-summary.json'),'integrationAndMutationControls':{'pass':3,'fail':0},'fixturesExecuted':False,'fixturesPolicy':'AST and resolution only. Trusted Node resolver script and --check parse files; fixture payloads never imported or evaluated. No provider/network/PG/install/subagents.'},
 'criteria':criteria,'blockingFindings':[],
 'moduleReview':[
  {'module':'boundary-lexical.mjs','review':'Full source and diff inspected. Early identity guard skips only member/meta names and Identifier === BindingElement.propertyName. ComputedPropertyName children, shorthand names and BindingElement.name remain queried; assignedValues keeps original nodes, selections and defaults. Necessary stack exception handling remains explicit.'},
  {'module':'check-product-boundary.mjs','review':'Full source inspected, runtime/manifest source queue and real callback reviewed. localTarget both adds graph edge and schedules physical source for parsing, with containment/format/actor controls retained. Runtime AST remains traversed independently and scoped diagnostics retain core provenance.'},
  {'module':'boundary-code-execution.mjs','review':'Full source inspected; byte identical R19. Uses complete accesses and original lexical identities, joins destructured/assigned capabilities, preserves scalar proof mutation controls and evaluator uncertainty.'},
  {'module':'boundary-manifests.mjs','review':'Full source inspected; byte identical R19. Physical installed provenance, metadata closure failure propagation, lexical local paths, symlink/containment checks and registry lookup remain unchanged.'},
  {'module':'tsconfig-path-grammar.mjs','review':'Full source inspected; byte identical R19. Nonempty single-wildcard path grammar remains unchanged.'}
 ],
 'sourceDeltaQualification':{'repairPaths':['scripts/boundary-lexical.mjs','scripts/check-product-boundary.mjs','tests/product-boundary-binding-query.test.js'],'observedScriptsTestsDeltas':deltas,'note':'Comparison of entire scripts/tests trees with R19 observes six deltas, not a global three-path identity. Additional hiso inventory, CI scope test and manifest-runtime regression deltas are outside the five-module/32-case repair review. They are explicitly recorded; no claim of whole candidate equality or release is made.'},
 'producerEvidence':{'status':'USER_REPORTED_NOT_INDEPENDENTLY_RERUN','statement':'User reports final 1255 PASS / 5 files / 0 SKIP, typecheck PASS, lint PASS and 7818 generic input MATCH. Not used to replace own probes or claimed as own execution.'},
 'installed48Links':{'status':'NOT_RUN','owner':'other lane'},'installedFullCLI':{'status':'NOT_RUN'},'release':{'status':'NOT_ADJUDICATED'},
 'limits':[
  'Finite grammar review; does not prove arbitrary whole-JavaScript semantic completeness or adjudicate roughly 9000 installed unknowns.',
  '48-link installed profile, installed full CLI, broad installed scanner and full producer 1255/typecheck/lint were not rerun in this lane.',
  'Necessary integrated stack failure was injected in an owned wrapper. Actual installed TS counterexample uses real checker and exact Source bytes.',
  '32 exact assertions run through own Node native test adapter supporting only the matchers they use; this is not a claim of Vitest runner equivalence beyond these assertions.',
  'Before R20 frozen source provides lexical/checker modules; unchanged three supporting modules are supplied from Source and independently matched to R19.',
  'Integrity covers 72 tracked inputs plus the six packet-frozen records, not an independently repeated full 7818-file census.',
  'Original controls compared byte-for-byte were not broadly rerun here; own bounded controls execute the relevant behavior.'
 ],
 'rawFailuresPreserved':['regression32-before.tap','length-counterexample.json','harness-bootstrap-error-before.tap','harness-bootstrap-error-after.tap','harness-bootstrap-error2-before.tap','harness-bootstrap-error2-after.tap','harness-baseline-missing-support.tap','own-harness-bootstrap-error.log','integration-harness-missing-mutants.log'],
 'harnessCorrections':'Owned test adapter/probe bootstrap syntax errors and absent R20 supporting modules were corrected only in output; raw attempts retained. Copied checker was read-only by preserved mode, so the separate injected copy alone was chmodded before mutation. No original assertion or Source byte was changed.',
 'artifacts':'artifact-manifest.json','ownedArtifactBytes':sum(x['bytes'] for x in artifact),
 'nextAction':'Use this ACCEPT only for the scoped source repair; other lane retains installed-profile qualification. No requested review work remains.'
}
(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
md=f'''**ACCEPT — reparo C1 Source**, limitado aos cinco módulos e às 32 regressões. Não adjudica o perfil instalado ou release.

| Evidência executada em Node 22.23.2 | Resultado |
| --- | --- |
| Mesmas 32 regressões, módulos anteriores R20 | 26 PASS / 6 FAIL / 0 SKIP |
| Mesmas 32 regressões, Source reparado | 32 PASS / 0 FAIL / 0 SKIP |
| Probes independentes de AST e scanner | 45 PASS / 0 FAIL |
| Callback integrado e dois mutantes próprios | 3 PASS / 0 FAIL |
| Integridade dos inputs rastreados | 72/72 MATCH hash, bytes, mode, mtime |
| Freeze do packet | 6/6 MATCH |

TypeScript físico: 6.0.3, 9.144.216 bytes, SHA-256 `569177652966bd528c319171c7dd22860dbf72bde116cbc4f644f1d02bb12e39`; semver 7.7.4. Cópia inicial de aproximadamente 9,6 MB, sem clone de dependências de 650 MB. Todas as execuções usaram `/home/ricardo/.nvm/versions/node/v22.23.2/bin/node`.

No arquivo TypeScript real copiado do Source, o Identifier `length` no offset **4023392**, em `length: length2`, provoca RangeError no R19 e identidade unavailable no R20. O reparo devolve undefined para o label, sem diagnóstico, preservando o binding real `length2`. Instrumentação independente confirma zero queries para os labels e nomes de PropertyAccess/MetaProperty. O novo guard usa identidade exata `Identifier == BindingElement.propertyName`, portanto não apaga nomes ligados nem filhos de chave computada. Evidência: [contraprova antes/depois](length-counterexample.json).

As identidades de aliases, shorthand, default parameters, CJS var/const, computed, nested e exports passam. Quatro operações necessárias (`getSymbolAtLocation`, `getShorthandAssignmentValueSymbol`, `getExportSpecifierLocalTargetSymbol`, `resolveName`) conservam unavailable separado de globals; ausência de callback lança erro com a causa original, e erros não relacionados propagam. Injeção própria na fronteira real lexical→checker prova diagnóstico `UNAVAILABLE_LEXICAL_BINDING_ANALYSIS`, `INCOMPLETE` e `passed=false`. [Probes próprios](own-probes.json), [integração e mutantes](integration-faults.json).

Os 21 negativos do scanner mantêm produto em chave computada como FAIL; eval/Function e loaders/factories recuperados por destructuring/globalThis/module, com aquisição não resolvida, continuam INCOMPLETE ou FAIL. Assignments, exports, defaults, sombras e mutações de metadata/origem permanecem recusados. Os sete positivos de integração passam. A fila de manifesto passa a visitar o runtime físico: o negativo próprio muda de INCOMPLETE sem testemunha para FAIL com `packages/core/package.json → node_modules/own-vendor/index.js → products/shift/marker.js`. Nenhum payload foi executado. [Fila antes/depois](own-fixtures/manifest-queue/before-after.json).

O prefixo R20 de **10.456 bytes**, contendo 22 casos, é byte exato; seguem dez novos casos. As asserts originais permanecem intactas. As três suítes de controle existentes no R19 também são byte idênticas. O adapter próprio executa as 32 asserts através de Node native tests e assert estrito, somente com os matchers utilizados. [Comparação](comparisons.json), [TAP antes](regression32-before.tap), [TAP depois](regression32-after.tap).

Inspeção real integral dos cinco módulos: lexical e checker contêm o reparo; execution, manifests e path grammar são byte idênticos ao R19. Computed expressions continuam na AST completa, propagação de capabilities conserva nós originais e joins, e controles de proveniência física, containment, symlink e erro não são reduzidos. Nenhum bloqueador encontrado no escopo.

A comparação ampla apenas das árvores scripts/tests observou seis deltas perante R19: os três paths do reparo e, fora desta revisão, `scripts/hiso-baseline-inventory.json`, `tests/hiso-ci-scopes.test.js` e o novo `tests/product-boundary-manifest-runtime.test.js`. Assim, o aceite não afirma que o candidato inteiro tenha apenas três deltas. [Inventário observado](scripts-tests-deltas.json).

Limites finitos: perfil instalado de 48 links **NOT_RUN**, full installed CLI **NOT_RUN**, scanner instalado amplo **NOT_RUN**, aproximadamente 9000 unknowns e release **NOT_ADJUDICATED**. O produtor informou 1255 PASS/5 files/0 SKIP, typecheck/lint PASS e 7818 inputs MATCH; são informação recebida do usuário, não execuções desta lane. Não se exige barra adicional de versão/wholeJS/CLI para este aceite.

Raw failures preservadas, incluindo as seis falhas do baseline, a stack real e falhas de bootstrap do harness próprio; estas últimas foram corrigidas somente em output e não contam como defeitos do Source. O R20 foi composto com seus dois módulos congelados e os três supporting modules comprovadamente iguais ao R19. A injeção integrada foi feita apenas em cópia própria; a contraprova TypeScript real não foi injetada. Integridade independente cobre 72 inputs, não reexecuta o census de 7818 arquivos. [Fingerprints finais](inputs-final.json), [freeze](freeze-check.json), [manifest de artefatos](artifact-manifest.json).

Source permaneceu somente leitura. Nenhum Root ledger/coord/prior judgment, .env/key, provider/rede/PG/install/subagent foi usado. Os relatórios ficam exclusivamente no output autorizado. Próximo passo: utilizar este aceite apenas para o reparo; qualificação instalada permanece com a outra lane.
'''
(out/'report.md').write_text(md)
print(json.dumps({'verdict':report['verdict'],'independentPass':48,'regressionAfter':32,'readonlyMatches':len(checks),'artifactBytes':report['ownedArtifactBytes'],'report':str(out/'report.json')},ensure_ascii=False))
