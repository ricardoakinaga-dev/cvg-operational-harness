import {register} from 'node:module';register('./native-loader.mjs',import.meta.url);
