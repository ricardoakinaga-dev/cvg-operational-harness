import {auditProductBoundary} from './runtime/scripts/check-product-boundary.mjs';
try { console.log(JSON.stringify(auditProductBoundary(new URL('../source/',import.meta.url).pathname),null,2)); } catch(error) { console.error(error.stack); process.exitCode=2; }
