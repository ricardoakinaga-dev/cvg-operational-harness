import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {createRequire} from 'node:module';import {auditProductBoundary} from './runtime/scripts/check-product-boundary.mjs';
const output=path.dirname(new URL(import.meta.url).pathname),results=[];
for(const field of ['dependencies','devDependencies','optionalDependencies','peerDependencies'])for(const kind of ['jsonless-nested-product','jsonless-nested-invalid','local-file-cycle-product','unresolved-alias-product','alias-to-builtin-physical-product','import-proves-workspace-alias-product','workspace-shadow-root-product','nonroot-ancestry-nested-product']){
 const id=field+'--'+kind;const root=path.join(output,'probes-extra',id);const put=(rel,value)=>{const f=path.join(root,rel);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,typeof value==='string'?value:JSON.stringify(value));};
 for(const d of ['apps','legacy','packages/core/src','packages/neutral/src','products/consumer/src'])fs.mkdirSync(path.join(root,d),{recursive:true});
 put('package.json',{private:true,type:'module',workspaces:['packages/*','products/*']});put('packages/core/package.json',{name:'@synthetic/core',type:'module',[field]:{next:'1.0.0'}});put('packages/neutral/package.json',{name:'@synthetic/neutral',type:'module'});put('products/consumer/package.json',{name:'@synthetic/consumer',type:'module'});
 put('tsconfig.base.json',{compilerOptions:{module:'NodeNext',moduleResolution:'NodeNext',target:'ESNext',allowJs:true}});
 for(const actor of ['packages/core','packages/neutral','products/consumer'])put(actor+'/src/index.mts','export const label="inert";');let expected='FAIL';
 if(kind.startsWith('jsonless')){
  put('node_modules/next/index.mts','export const label="jsonless";');
  put('node_modules/next/dist/package.json',kind.endsWith('invalid')?[]:{[field]:{'@synthetic/consumer':'*'}});if(kind.endsWith('invalid'))expected='ERROR';
 }
 if(kind==='local-file-cycle-product'){
  put('node_modules/next/package.json',{name:'external',type:'module',[field]:{back:'file:../../auxiliary/back'}});
  put('auxiliary/back/package.json',{name:'back',type:'module',[field]:{next:'file:../../node_modules/next','@synthetic/consumer':'*'}});
 }
 if(kind==='unresolved-alias-product')put('packages/core/package.json',{name:'@synthetic/core',type:'module',[field]:{next:'npm:@synthetic/consumer@1.0.0'}});
 if(kind==='alias-to-builtin-physical-product'){
  put('packages/core/package.json',{name:'@synthetic/core',type:'module',[field]:{next:'npm:fs@1.0.0'}});put('node_modules/next/package.json',{name:'fs',type:'module',[field]:{'@synthetic/consumer':'*'}});
 }
 if(kind==='import-proves-workspace-alias-product'){
  put('packages/core/package.json',{name:'@synthetic/core',type:'module',[field]:{next:'npm:@synthetic/neutral@1.0.0'}});put('node_modules/next/package.json',{name:'@synthetic/neutral',type:'module',main:'index.mjs',[field]:{'@synthetic/consumer':'*'}});put('node_modules/next/index.mjs','export const label="registry";');put('packages/core/src/index.mts','import "next";');
 }
 if(kind==='workspace-shadow-root-product'){
  put('packages/core/package.json',{name:'@synthetic/core',type:'module',[field]:{'@synthetic/neutral':'*'}});put('node_modules/@synthetic/neutral/package.json',{name:'@synthetic/neutral',type:'module'});put('packages/core/node_modules/@synthetic/neutral/package.json',{name:'@synthetic/neutral',type:'module',[field]:{'@synthetic/consumer':'*'}});
 }
 if(kind==='nonroot-ancestry-nested-product'){
  put('packages/core/package.json',{name:'@synthetic/core',type:'module'});put('packages/core/src/index.mts','import "../../../auxiliary/bridge/inner/src/index.mts";');put('auxiliary/bridge/package.json',{name:'bridge',type:'module',[field]:{'@synthetic/consumer':'*'}});put('auxiliary/bridge/inner/package.json',{name:'inner',type:'module'});put('auxiliary/bridge/inner/src/index.mts','export const label="nested";');
 }
 let audit,error;try{audit=auditProductBoundary(root);}catch(e){error={name:e.name,message:e.message,stack:e.stack};}const actual=error?'ERROR':audit.status;let assertion;try{assert.equal(actual,expected,id);}catch(e){assertion=e.message;}
 const entry={id,field,root,expected,actual,assertionPassed:!assertion,assertion,audit,error,fixtureExecution:false};results.push(entry);console.log(JSON.stringify(entry));fs.writeFileSync(output+'/additional-results.json',JSON.stringify(results,null,2));
}
const failed=results.filter(r=>!r.assertionPassed).length;console.log(JSON.stringify({total:results.length,passed:results.length-failed,failed}));process.exitCode=failed?1:0;
