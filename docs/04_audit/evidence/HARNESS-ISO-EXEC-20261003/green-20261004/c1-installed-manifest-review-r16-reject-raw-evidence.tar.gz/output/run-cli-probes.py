import os,subprocess,json,time
p='/home/ricardo/.cache/cvg-harness-green-20261004/c1-installed-manifest-review-r16';o=p+'/output';r=o+'/runtime';node='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node';env={'PATH':os.path.dirname(node)+':/usr/bin:/bin','HOME':r,'TMPDIR':r+'/tmp','XDG_CACHE_HOME':r+'/cache','LANG':'C.UTF-8','CI':'1'}
os.makedirs(o+'/cli',exist_ok=True);results=[]
wanted=['workspace-name-physical-successor','workspace-target-alias-physical-successor','workspace-target-alias-unknown-frontier','workspace-target-alias-outside-identity','workspace-missing-physical-known-product','registry-product','jsonless-identity','ordinary-registry-absent','absent-actual-import-blocks']
for probe in json.load(open(o+'/independent-results.json')):
 if not any(probe['id'].endswith('--'+s) for s in wanted):continue
 name=probe['id'];dest=o+'/cli/'+name;cmd=[node,r+'/scripts/check-product-boundary.mjs',probe['root']];start=time.time()
 with open(dest+'.stdout','w') as out,open(dest+'.stderr','w') as err:
  result=subprocess.run(['/usr/bin/strace','-f','-qq','-e','trace=%network,%process,%file','-o',dest+'.trace','/usr/bin/python3',o+'/no-network.py',*cmd],cwd=r,env=env,stdout=out,stderr=err)
 raw=open(dest+'.stdout').read();actual=json.loads(raw)['status'] if raw else 'ERROR';expectedExit={'PASS':0,'FAIL':1,'INCOMPLETE':1,'ERROR':2}[probe['expected']]
 record={'id':name,'command':cmd,'exitCode':result.returncode,'expectedExitCode':expectedExit,'expected':probe['expected'],'actual':actual,'assertionPassed':result.returncode==expectedExit and actual==probe['expected'],'durationSeconds':time.time()-start,'artifacts':{k:'cli/'+name+'.'+k for k in ['stdout','stderr','trace']}}
 results.append(record);json.dump(results,open(o+'/cli-results.json','w'),indent=2);print(json.dumps(record),flush=True)
