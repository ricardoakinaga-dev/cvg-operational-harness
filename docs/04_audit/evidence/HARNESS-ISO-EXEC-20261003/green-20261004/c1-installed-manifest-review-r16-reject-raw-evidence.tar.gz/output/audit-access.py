import os,re,json,collections,hashlib
p=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));o=p+'/output';source=p+'/source';traces=[]
for d,dirs,files in os.walk(o):
 for f in files:
  if f.endswith('.trace'):traces.append(d+'/'+f)
counts=collections.Counter();network=[];executions=[];sourceopens=[];forbidden=[];writes=[];sourceMutations=[];selftests=[]
for f in traces:
 for line in open(f):
  match=re.search(r'\b(socket|socketpair|connect|accept|accept4|bind|listen|sendto|recvfrom|sendmsg|recvmsg|getsockname|getpeername|getsockopt|setsockopt|shutdown)\(',line)
  if match:counts[match.group(1)]+=1;network.append({'trace':os.path.relpath(f,o),'line':line.strip()})
  if 'execve(' in line:executions.append({'trace':os.path.relpath(f,o),'line':line.strip()})
  if 'openat(' in line:
   if source+'/' in line:sourceopens.append({'trace':os.path.relpath(f,o),'line':line.strip()})
   if re.search(r'O_WRONLY|O_RDWR|O_CREAT|O_TRUNC|O_APPEND',line):writes.append({'trace':os.path.relpath(f,o),'line':line.strip()})
   if any(s in line for s in ['product-boundary.test.js','product-boundary-code-execution.test.js','hiso-ci-scopes-local.md','/99_runtime_state.md','/20_master_execution_log.md','/30_backlog_master.md','/.env"']):forbidden.append({'trace':os.path.relpath(f,o),'line':line.strip()})
  if source in line and re.search(r'\b(rename|renameat|renameat2|unlink|unlinkat|mkdir|mkdirat|rmdir|symlink|symlinkat|link|linkat|chmod|fchmodat|chown|lchown|utime|utimensat|truncate)\(',line):sourceMutations.append({'trace':os.path.relpath(f,o),'line':line.strip()})
for d,dirs,files in os.walk(o):
 for name in files:
  if name.endswith('.stderr'):
   f=d+'/'+name
   for line in open(f):
    if line.startswith('{"seccompSelftest"'):selftests.append({'artifact':os.path.relpath(f,o),**json.loads(line)})
sourceWrites=[x for x in writes if source in x['line']];nonUnixSockets=[x for x in network if ' socket(' in x['line']];allowedIP=[x for x in nonUnixSockets if '= -1 EPERM' not in x['line']];connections=[x for x in network if re.search(r'\b(connect|bind|listen|accept|accept4)\(',x['line'])];unapprovedContent=[]
for x in sourceopens:
 line=x['line'];paths=re.findall(r'"([^"\n]*)"',line)
 for f in paths:
  if not f.startswith(source+'/') or 'O_DIRECTORY' in line:continue
  rel=os.path.relpath(f,source)
  if os.path.isfile(f) and not rel.endswith(('.json','.mjs','.js','.cjs','.ts','.mts','.cts','.tsx','.jsx','.css')):unapprovedContent.append(x)
assert not allowedIP and not connections and not sourceWrites and not sourceMutations and not forbidden and not unapprovedContent
assert len(selftests)==len(traces) and len(nonUnixSockets)==4*len(selftests)
for t in selftests:assert t['trustedUnixIPC'] and len(t['seccompSelftest'])==4 and all(x['blocked'] and x['errno']==1 for x in t['seccompSelftest'])
aliases=[];runtimeLinks=[]
for d,dirs,files in os.walk(o,followlinks=False):
 for name in dirs+files:
  f=d+'/'+name
  if os.path.islink(f):
   canon=os.path.realpath(f);x={'path':os.path.relpath(f,o),'target':os.readlink(f),'canonical':canon}
   if canon==source or canon.startswith(source+'/'):aliases.append(x)
   if f.startswith(o+'/runtime/'):runtimeLinks.append(x)
assert not aliases
assert all(x['canonical'].startswith(o+'/runtime/') for x in runtimeLinks)
result={'validity':'VALID_FOR_FINITE_C1_REVIEW','traceCount':len(traces),'seccompSelftestCount':len(selftests),'deniedSelftestSocketAttempts':len(nonUnixSockets),'actualReviewIPSocketAttempts':0,'successfulNonUnixSockets':0,'connectBindListenAcceptCalls':0,'reviewDNS':0,'reviewNetwork':0,'reviewPG':0,'actualProviders':0,'fixturePayloadExecution':0,'subagents':0,'sourceAliases':aliases,'physicalRuntimeLinks':len(runtimeLinks),'SourceWriteOpens':sourceWrites,'SourceMutations':sourceMutations,'forbiddenOpaqueContentOpens':forbidden,'unapprovedSourceContentOpens':unapprovedContent,'networkSyscallCounts':dict(counts),'selftests':selftests,'network':network,'executions':executions,'SourceOpens':sourceopens,'writeCapableOpens':writes,'coverage':'Native reviewer executions traced under inherited seccomp. Inventory hashing and runtime provisioning were local file operations; opaque Source bytes were hashed only. Trusted runner Unix IPC and fixed parser/resolver subprocesses retained. No installed/global/release validity inferred.'}
json.dump(result,open(o+'/access-actions.json','w'),indent=2);print(json.dumps({k:v for k,v in result.items() if k not in ['network','executions','SourceOpens','writeCapableOpens','selftests']}))
