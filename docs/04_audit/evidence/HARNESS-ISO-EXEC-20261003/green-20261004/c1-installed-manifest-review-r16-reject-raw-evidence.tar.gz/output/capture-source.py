import os,json,hashlib,stat,collections
p=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));root=p+'/source';out=p+'/output';meta={};actual={}
def inspect(f,r):
 s=os.lstat(f);m={k:getattr(s,'st_'+k) for k in ['mode','size','mtime_ns','ctime_ns','dev','ino','nlink']}
 if stat.S_ISLNK(s.st_mode):
  t=os.readlink(f);m.update(kind='link',target=t);actual[r]={'kind':'link','target':t}
 elif stat.S_ISDIR(s.st_mode):m['kind']='dir'
 elif stat.S_ISREG(s.st_mode):
  h=hashlib.sha256(open(f,'rb').read()).hexdigest();m.update(kind='file',sha256=h);actual[r]={'bytes':s.st_size,'kind':'file','sha256':h}
 else:m['kind']='special'
 meta[r]=m
 if m['kind']=='dir':
  for e in sorted(os.scandir(f),key=lambda e:e.name):inspect(e.path,os.path.relpath(e.path,root))
inspect(root,'.');json.dump(meta,open(out+'/source-post.json','w'),sort_keys=True,indent=2)
pre=json.load(open(out+'/source-pre.json'));inventory=json.load(open(p+'/frozen-inventory.json'));diff=[{'path':k,'pre':pre.get(k),'post':meta.get(k)} for k in sorted(set(pre)|set(meta)) if pre.get(k)!=meta.get(k)]
invDiff=[k for k in set(actual)|set(inventory) if actual.get(k)!=inventory.get(k)]
result={'invariant':not diff and not invDiff,'fields':['sha256','mode','size','mtime_ns','ctime_ns','dev','ino','nlink','link_target','entry_kind'],'atimeExcludedByContract':True,'metadataEntries':len(meta),'inventoryEntries':len(actual),'entryCounts':dict(collections.Counter(v['kind'] for v in meta.values())),'literalMetadataChanges':diff,'frozenInventoryChanges':invDiff,'preSha256':hashlib.sha256(open(out+'/source-pre.json','rb').read()).hexdigest(),'postSha256':hashlib.sha256(open(out+'/source-post.json','rb').read()).hexdigest(),'freezeInventorySha256':hashlib.sha256(open(p+'/frozen-inventory.json','rb').read()).hexdigest(),'coverage':'entire physical Source recursively, including every dependency/dist/opaque document and Source root directory; no exclusions'}
json.dump(result,open(out+'/source-invariance.json','w'),indent=2);print(json.dumps(result))
