import ctypes,ctypes.util,errno,os,socket,sys,json
lib=ctypes.CDLL(ctypes.util.find_library('seccomp'),use_errno=True)
class Arg(ctypes.Structure):
 _fields_=[('arg',ctypes.c_uint),('op',ctypes.c_uint),('datum_a',ctypes.c_uint64),('datum_b',ctypes.c_uint64)]
lib.seccomp_init.argtypes=[ctypes.c_uint32];lib.seccomp_init.restype=ctypes.c_void_p
lib.seccomp_syscall_resolve_name.argtypes=[ctypes.c_char_p];lib.seccomp_syscall_resolve_name.restype=ctypes.c_int
lib.seccomp_rule_add_array.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_int,ctypes.c_uint,ctypes.POINTER(Arg)]
lib.seccomp_load.argtypes=[ctypes.c_void_p]
lib.seccomp_release.argtypes=[ctypes.c_void_p]
ctx=lib.seccomp_init(0x7fff0000);deny=0x50000|errno.EPERM
for name in ['socket','socketpair']:
 arg=Arg(0,1,socket.AF_UNIX,0)
 assert lib.seccomp_rule_add_array(ctx,deny,lib.seccomp_syscall_resolve_name(name.encode()),1,ctypes.pointer(arg))==0
for name in ['io_uring_setup','io_uring_enter','io_uring_register']:
 nr=lib.seccomp_syscall_resolve_name(name.encode())
 if nr>=0:assert lib.seccomp_rule_add_array(ctx,deny,nr,0,None)==0
assert lib.seccomp_load(ctx)==0
lib.seccomp_release(ctx)
proof=[]
for family in [socket.AF_INET,socket.AF_INET6,socket.AF_NETLINK,socket.AF_PACKET]:
 try:
  s=socket.socket(family,socket.SOCK_STREAM);s.close();raise AssertionError('network selftest allowed')
 except OSError as e:
  assert e.errno==errno.EPERM;proof.append({'family':int(family),'errno':e.errno,'blocked':True})
a,b=socket.socketpair();a.send(b'ipc');assert b.recv(3)==b'ipc';a.close();b.close()
print(json.dumps({'seccompSelftest':proof,'trustedUnixIPC':True,'pid':os.getpid(),'command':sys.argv[1:]}),file=sys.stderr,flush=True)
os.execv(sys.argv[1],sys.argv[1:])
