import os,subprocess,json,time
p='/home/ricardo/.cache/cvg-harness-green-20261004/c1-installed-manifest-review-r16';o=p+'/output';r=o+'/runtime';node='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node'
env={'PATH':os.path.dirname(node)+':/usr/bin:/bin','HOME':r,'TMPDIR':r+'/tmp','XDG_CACHE_HOME':r+'/cache','LANG':'C.UTF-8','CI':'1'}
cases=[('seccomp-selftest',[node,'--version']),('installed-cli',[node,r+'/scripts/check-product-boundary.mjs',p+'/source']),('supplied658',[node,r+'/node_modules/vitest/vitest.mjs','run','--config',r+'/vitest.config.mjs','--reporter=json','--outputFile='+o+'/supplied658.json']),('independent-api',[node,o+'/independent-probes.mjs'])]
for name,cmd in cases:
 if name=='independent-api' and not os.path.exists(o+'/independent-probes.mjs'):continue
 start=time.time()
 with open(o+'/'+name+'.stdout','w') as out,open(o+'/'+name+'.stderr','w') as err:
  result=subprocess.run(['/usr/bin/strace','-f','-qq','-e','trace=%network,%process,%file','-o',o+'/'+name+'.trace','/usr/bin/python3',o+'/no-network.py',*cmd],cwd=r,env=env,stdout=out,stderr=err)
 record={'name':name,'command':cmd,'exitCode':result.returncode,'durationSeconds':time.time()-start,'env':env}
 json.dump(record,open(o+'/'+name+'.command.json','w'),indent=2);print(json.dumps(record),flush=True)
