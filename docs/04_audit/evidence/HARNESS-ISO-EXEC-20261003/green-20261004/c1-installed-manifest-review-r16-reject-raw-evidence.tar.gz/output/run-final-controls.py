import os,subprocess,json,time
p='/home/ricardo/.cache/cvg-harness-green-20261004/c1-installed-manifest-review-r16';o=p+'/output';r=o+'/runtime';node='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node';env={'PATH':os.path.dirname(node)+':/usr/bin:/bin','HOME':r,'TMPDIR':r+'/tmp','XDG_CACHE_HOME':r+'/cache','LANG':'C.UTF-8','CI':'1'}
os.makedirs(o+'/final-controls',exist_ok=True);results=[]
cases=[{'id':'installed-api','command':[node,o+'/installed-api.mjs'],'expected':'ERROR','expectedExitCode':2},{'id':'installed-cli-full-trace','command':[node,r+'/scripts/check-product-boundary.mjs',p+'/source'],'expected':'ERROR','expectedExitCode':2}]
for probe in json.load(open(o+'/additional-results.json')):
 if not any(probe['id'].endswith('--'+s) for s in ['jsonless-nested-product','jsonless-nested-invalid','workspace-shadow-root-product','import-proves-workspace-alias-product']):continue
 cases.append({'id':probe['id'],'command':[node,r+'/scripts/check-product-boundary.mjs',probe['root']],'expected':probe['expected'],'expectedExitCode':{'PASS':0,'FAIL':1,'INCOMPLETE':1,'ERROR':2}[probe['expected']]})
for case in cases:
 name=case['id'];dest=o+'/final-controls/'+name;cmd=case['command'];start=time.time()
 with open(dest+'.stdout','w') as out,open(dest+'.stderr','w') as err:
  result=subprocess.run(['/usr/bin/strace','-f','-qq','-s','65535','-e','trace=%network,%process,%file','-o',dest+'.trace','/usr/bin/python3',o+'/no-network.py',*cmd],cwd=r,env=env,stdout=out,stderr=err)
 raw=open(dest+'.stdout').read();actual=json.loads(raw)['status'] if raw else 'ERROR';record={**case,'exitCode':result.returncode,'actual':actual,'assertionPassed':result.returncode==case['expectedExitCode'] and actual==case['expected'],'durationSeconds':time.time()-start,'artifacts':{k:'final-controls/'+name+'.'+k for k in ['stdout','stderr','trace']}}
 results.append(record);json.dump(results,open(o+'/final-control-results.json','w'),indent=2)
print(json.dumps({'count':len(results),'passed':sum(r['assertionPassed'] for r in results),'failed':sum(not r['assertionPassed'] for r in results)}))
