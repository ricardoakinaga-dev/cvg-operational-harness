import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {auditProductBoundary} from './runtime/scripts/check-product-boundary.mjs';
import {createBoundaryManifestReader} from './runtime/scripts/boundary-manifests.mjs';
const output=path.dirname(new URL(import.meta.url).pathname);
const results=[];
const fields=['dependencies','devDependencies','optionalDependencies','peerDependencies'];
function fixture(id){
 const root=path.join(output,'probes',id);fs.mkdirSync(root,{recursive:true});
 const put=(rel,value)=>{const f=path.join(root,rel);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,typeof value==='string'?value:JSON.stringify(value));};
 const link=(rel,target)=>{fs.mkdirSync(path.dirname(path.join(root,rel)),{recursive:true});fs.symlinkSync(target,path.join(root,rel));};
 for(const d of ['apps','legacy','products/consumer/src','packages/core/src','packages/neutral/src'])fs.mkdirSync(path.join(root,d),{recursive:true});
 put('package.json',{private:true,type:'module',workspaces:['packages/*','products/*']});
 put('packages/core/package.json',{name:'@synthetic/core',type:'module'});
 put('packages/neutral/package.json',{name:'@synthetic/neutral',type:'module'});
 put('products/consumer/package.json',{name:'@synthetic/consumer',type:'module'});
 put('packages/core/src/index.mts','export const label="core";');
 put('packages/neutral/src/index.mts','export const label="neutral";');
 put('products/consumer/src/index.mts','export const label="product";');
 put('tsconfig.base.json',{compilerOptions:{module:'NodeNext',moduleResolution:'NodeNext',target:'ESNext',allowJs:true}});
 return {root,put,link,core: (field,deps)=>put('packages/core/package.json',{name:'@synthetic/core',type:'module',[field]:deps}),installed:(rel,field,deps={})=>{put(rel+'/package.json',{name:'external',type:'module',[field]:deps});put(rel+'/index.mts','export const label="external";');}};
}
function run(id,expected,setup,field){
 const f=fixture(id);setup(f,field);
 const lookups=[];
 for(const manifest of ['packages/core/package.json','packages/core/node_modules/next/package.json','node_modules/next/package.json']) {
  const file=path.join(f.root,manifest);if(!fs.existsSync(file))continue;
  const value=JSON.parse(fs.readFileSync(file,'utf8'));
  for(const k of fields)for(const [name,spec] of Object.entries(value[k]??{}))lookups.push({manifest,field:k,name,spec,paths:createRequire(file).resolve.paths(name),physicalCandidates:(createRequire(file).resolve.paths(name)??[]).filter(p=>p===f.root||p.startsWith(f.root+'/')).map(p=>path.join(p,name)).filter(p=>fs.existsSync(p)).map(p=>({lexical:p,canonical:fs.realpathSync(p)}))});
 }
 let audit,error;try{audit=auditProductBoundary(f.root);}catch(e){error={name:e.name,message:e.message,stack:e.stack};}
 const actual=error?'ERROR':audit.status;let assertion;
 try{assert.equal(actual,expected,id);if(expected==='FAIL')assert(audit.violations.length>0,id+' requires witness');}catch(e){assertion=e.message;}
 const result={id,field,expected,actual,assertionPassed:!assertion,assertion,root:f.root,fixtureExecution:false,lookups,audit,error};results.push(result);
 fs.writeFileSync(path.join(output,'independent-results.json'),JSON.stringify(results,null,2));
 console.log(JSON.stringify({id,expected,actual,assertionPassed:!assertion,violations:audit?.violations,diagnostics:audit?.diagnostics,error}));
}
const variants=[
 ['registry-product','FAIL',(f,k)=>{f.core(k,{next:'1.0.0'});f.installed('node_modules/next',k,{'@synthetic/consumer':'*'});} ],
 ['registry-alias-product','FAIL',(f,k)=>{f.core(k,{next:'npm:external@1.0.0'});f.installed('node_modules/next',k,{'@synthetic/consumer':'*'});} ],
 ['nested-nearest-product','FAIL',(f,k)=>{f.core(k,{next:'1.0.0'});f.installed('node_modules/next',k);f.installed('packages/core/node_modules/next',k,{'@synthetic/consumer':'*'});} ],
 ['nearest-neutral-shadows-product','INCOMPLETE',(f,k)=>{f.core(k,{next:'1.0.0'});f.installed('node_modules/next',k,{'@synthetic/consumer':'*'});f.installed('packages/core/node_modules/next',k);} ],
 ['symlink-product-canonical','FAIL',(f,k)=>{f.core(k,{next:'1.0.0'});f.link('node_modules/next','../products/consumer');} ],
 ['symlink-internal-nested-product','FAIL',(f,k)=>{f.core(k,{next:'1.0.0'});f.installed('auxiliary/external',k,{'@synthetic/consumer':'*'});f.link('node_modules/next','../auxiliary/external');} ],
 ['symlink-escape','ERROR',(f,k)=>{f.core(k,{next:'1.0.0'});f.link('node_modules/next','/tmp');} ],
 ['installed-file','ERROR',(f,k)=>{f.core(k,{next:'1.0.0'});f.put('node_modules/next','inert label');} ],
 ['jsonless-identity','INCOMPLETE',(f,k)=>{f.core(k,{next:'1.0.0'});f.put('node_modules/next/index.mts','export const label="no JSON";');} ],
 ['installed-cycle-unknown','INCOMPLETE',(f,k)=>{f.core(k,{next:'1.0.0'});f.installed('node_modules/next',k,{back:'1.0.0'});f.installed('node_modules/back',k,{next:'1.0.0'});} ],
 ['installed-cycle-product','FAIL',(f,k)=>{f.core(k,{next:'1.0.0'});f.installed('node_modules/next',k,{back:'1.0.0'});f.installed('node_modules/back',k,{next:'1.0.0','@synthetic/consumer':'*'});} ],
 ['installed-dist-metadata-product','FAIL',(f,k)=>{f.core(k,{next:'1.0.0'});f.installed('node_modules/next',k);f.put('node_modules/next/dist/deep/package.json',{[k]:{'@synthetic/consumer':'*'}});} ],
 ['installed-nested-package-lookup','FAIL',(f,k)=>{f.core(k,{next:'1.0.0'});f.installed('node_modules/next',k,{back:'1.0.0'});f.installed('node_modules/next/node_modules/back',k,{'@synthetic/consumer':'*'});} ],
 ['missing-explicit-workspace','INCOMPLETE',(f,k)=>{f.core(k,{missing:'workspace:*'});} ],
 ['ordinary-registry-absent','PASS',(f,k)=>{f.core(k,{missing:'1.0.0'});} ],
 ['registry-alias-absent','PASS',(f,k)=>{f.core(k,{missing:'npm:external@1.0.0'});} ],
 ['absent-actual-import-blocks','INCOMPLETE',(f,k)=>{f.core(k,{missing:'1.0.0'});f.put('packages/core/src/index.mts','import "missing";');} ],
 ['opaque-installed-product-provenance','PASS',(f,k)=>{f.installed('auxiliary/bridge',k,{next:'1.0.0'});f.installed('node_modules/next',k,{'@synthetic/consumer':'*'});} ],
 ['workspace-name-physical-successor','FAIL',(f,k)=>{f.core(k,{'@synthetic/neutral':'1.0.0'});f.installed('node_modules/@synthetic/neutral',k,{'@synthetic/consumer':'*'});} ],
 ['workspace-target-alias-physical-successor','FAIL',(f,k)=>{f.core(k,{next:'npm:@synthetic/neutral@1.0.0'});f.installed('node_modules/next',k,{'@synthetic/consumer':'*'});} ],
 ['workspace-target-alias-unknown-frontier','INCOMPLETE',(f,k)=>{f.core(k,{next:'npm:@synthetic/neutral@1.0.0'});f.installed('node_modules/next',k);} ],
 ['workspace-target-alias-outside-identity','ERROR',(f,k)=>{f.core(k,{next:'npm:@synthetic/neutral@1.0.0'});f.link('node_modules/next','/tmp');} ],
 ['workspace-missing-physical-known-product','FAIL',(f,k)=>{f.core(k,{next:'workspace:*'});f.link('node_modules/next','../products/consumer');} ],
 ['builtin-name-node-lookup-null','PASS',(f,k)=>{f.core(k,{fs:'1.0.0'});f.installed('node_modules/fs',k,{'@synthetic/consumer':'*'});assert.equal(createRequire(path.join(f.root,'packages/core/package.json')).resolve.paths('fs'),null);} ],
 ['builtin-alias-known-product','FAIL',(f,k)=>{f.core(k,{fs:'npm:@synthetic/consumer@1.0.0'});} ],
 ['root-ancestry-product-preserved','FAIL',(f,k)=>{f.put('package.json',{private:true,type:'module',workspaces:['packages/*','products/*'],[k]:{'@synthetic/consumer':'*'}});f.put('scripts/bridge.mts','export const label="root";');f.put('packages/core/src/index.mts','import "../../../scripts/bridge.mts";');} ],
 ['root-documentary-opaque','PASS',(f,k)=>{f.put('docs/archive/package.json',{[k]:{'@synthetic/consumer':'*'}});f.put('scripts/bridge.mts','export const label="root";');f.put('packages/core/src/index.mts','import "../../../scripts/bridge.mts";');} ],
 ['malformed-installed-json','ERROR',(f,k)=>{f.core(k,{next:'1.0.0'});f.put('node_modules/next/package.json',[]);} ],
 ['npm-invalid-workspace-alias','ERROR',(f,k)=>{f.core(k,{next:'npm:missing@workspace:*'});} ],
 ['cross-field-cache-product','FAIL',(f,k)=>{f.core(k,{next:'1.0.0',again:'1.0.0'});f.installed('node_modules/next',k,{again:'1.0.0'});const other=fields[(fields.indexOf(k)+1)%4];f.installed('node_modules/again',other,{'@synthetic/consumer':'*'});} ],
];
for(const field of fields)for(const [id,expected,setup] of variants)run(field+'--'+id,expected,setup,field);
// Private-reader cache must recheck stronger name/workspace requirements.
for(const stronger of ['requireName','rootManifest']){
 const f=fixture('cache-'+stronger);f.put('auxiliary/package.json',{});const reader=createBoundaryManifestReader(f.root);const file=path.join(f.root,'auxiliary/package.json');reader.read(file);let error;try{reader.read(file,{[stronger]:true});}catch(e){error=e.message;}
 assert(error,'cached shape cannot erase stronger validation');results.push({id:'cache-'+stronger,assertionPassed:true,actual:'ERROR',expected:'ERROR',error,root:f.root,fixtureExecution:false});
}
fs.writeFileSync(path.join(output,'independent-results.json'),JSON.stringify(results,null,2));
const failures=results.filter(r=>!r.assertionPassed);console.log(JSON.stringify({total:results.length,passed:results.length-failures.length,failed:failures.length}));process.exitCode=failures.length?1:0;
