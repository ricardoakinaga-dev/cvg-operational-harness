# INSTALLED_FRONTIER_PLAN_R22 — diagnóstico e proposta finita

**Resultado: INCOMPLETE; proposta possível em T2, sem implementação ou aceite.** O diagnóstico próprio contém **2.809 ocorrências**, em **13 causas**, **516 arquivos físicos** e **2.305 linhas JSON distintas**. Existem 504 ocorrências adicionais que repetem uma linha JSON; não foram descartadas da contagem bruta. Não apareceu caminho explícito CORE_DEPENDS_ON_PRODUCT. Essa ausência não resolve as referências indeterminadas.

Fonte somente leitura: candidate-final-r19. Autoridade: authority.json do packet R22. Nenhuma governança, ledger, coordenação ou parecer anterior foi consultado. As únicas alterações são instrumentos de diagnóstico e seus resultados em output. Não houve implementação do remédio, instalação, rede, PostgreSQL, provider, leitura de ambiente privado, execução de fixtures ou descendentes do diagnóstico.

## Método e limite das contagens

Os números vêm de [diagnostic.json](diagnostic.json), produzido nesta rodada. **Não são apresentados como execução exata do CLI original.** O original chama spawnSync para resolver módulos e para node --check; a proibição de descendentes impediu essa execução.

[diagnose.mjs](diagnose.mjs) executou o algoritmo do checker com duas substituições somente no processo de diagnóstico: resolução síncrona pelas mesmas APIs Node 22 createRequire.resolve/import.meta.resolve, sem avaliar o texto do helper; parsing JavaScript por Acorn em lugar do subprocesso --check. Um hook adicionou observação do grafo ao retorno em memória. Os bytes do checker instalado permaneceram intactos. Portanto, estas são contagens exatas deste procedimento identificado, sem alegação de equivalência integral de Acorn com o parser Node ou de exit code do CLI original.

Ambiente efetivo da análise: Node **22.23.2**, TypeScript **6.0.3**, Acorn **8.16.0**, env -i com apenas PATH, TZ e LC_ALL; Node Permission Model permitiu leitura da Source e escrita de output, sem permissão de processos filhos ou workers. Foram substituídos **10 lotes de resolução** e **1.288 checks sintáticos**, com **zero erros sintáticos Acorn**. A consulta inicial da versão ambiente identificou Node 24; ela foi apenas descoberta do executável, e todos os procedimentos AST/JSON usaram o caminho explícito de Node 22. Isso fica registrado como desvio da instrução literal “Node22 only”, sem esconder a consulta.

Inventário observado pelo algoritmo: **3.085 fontes**, **593 fontes core**, **26 workspaces**, **18.025 arestas**. Referências de tipos e runtime foram mantidas separadas na evidência; declarações não substituíram JavaScript físico. Os resultados não comprovam execução de aplicação, bundle, imagem ou release.

## Contagens por causa

| Causa emitida | Ocorrências |
| --- | ---: |
| UNVERIFIED_INSTALLED_DEPENDENCY | 1.196 |
| UNVERIFIED_DYNAMIC_CODE_EXECUTION | 1.382 |
| UNVERIFIED_MODULE_LOADER_ESCAPE | 141 |
| UNVERIFIED_MODULE_LOADER_PROPERTY | 54 |
| UNVERIFIED_PROCESS_CAPABILITY_PROPERTY | 23 |
| NON_LITERAL_MODULE_REFERENCE | 3 |
| UNVERIFIED_MODULE_LOADER_PRIMITIVE | 3 |
| UNRESOLVED_MODULE_REFERENCE | 2 |
| UNVERIFIED_LOCAL_DEPENDENCY | 1 |
| UNRESOLVED_INSTALLED_LOCAL_DEPENDENCY | 1 |
| UNVERIFIED_WORKSPACE_DEPENDENCY | 1 |
| UNVERIFIED_MODULE_LOADER_BINDING | 1 |
| UNVERIFIED_MODULE_LOADER_BASE | 1 |
| **Total** | **2.809** |

UNVERIFIED_INSTALLED_DEPENDENCY é emitido em check-product-boundary.mjs quando o destino instalado não coincide com um workspace, antes de existir julgamento completo da implementação. Encontrar e validar seu package.json não basta para encerrá-lo. Já UNVERIFIED_DYNAMIC_CODE_EXECUTION combina usos efetivos de compiladores/execução com leituras conservadoramente classificadas como executores. Esses dois conjuntos precisam de tratamentos distintos.

As causas restantes incluem transferência de namespaces inteiros, propriedades sem gramática suportada, aliases e binding de capabilities, bases de createRequire indeterminadas, imports não literais e duas referências ausentes concretas. Seus nomes não demonstram, isoladamente, que houve execução ou importação do produto.

## Closure e proveniência

[production-closure-corrected.json](production-closure-corrected.json) segue referências runtime literais dos entrypoints de fonte dos três hosts e seus sucessores físicos atuais. As closures têm **755 arquivos para API**, **407 para worker** e **169 para web**; a união contém **925 arquivos**, sem somar duplicados entre hosts. Usa todos os ramos encontrados, não reachability de execução. Para web, as condições são Node, não a resolução de um bundle Vite. Os manifests de produção, seguindo dependencies/optionalDependencies/peerDependencies e preservando a seleção física instalada, formam **110 nós**.

| Contexto da ocorrência, na classificação disjunta | Ocorrências |
| --- | ---: |
| Arquivo na closure runtime literal dos hosts | 944 |
| Manifest na closure de disponibilidade de produção, fora da categoria acima | 389 |
| Outro código/metadado de pacote disponível em produção | 68 |
| Validação/tooling/outra fonte governada fora dessas categorias | 1.408 |
| **Total** | **2.809** |

Das 1.382 marcações de execução dinâmica, **882** estão na closure literal dos hosts, **61** em outros arquivos de pacotes disponíveis em produção e **439** na última categoria. Logo, retirar tooling não resolveria o frontier. A última categoria também contém fontes reutilizáveis fora dos três entrypoints escolhidos: ela não prova que todos os seus arquivos sejam apenas testes.

Há uma lacuna adicional concreta no traversal atual: o ramo de runtime de dependências de manifesto adiciona a aresta física, mas não enfileira o JavaScript como localTarget faz para imports de fonte. No grafo core alcançado, **1.466 referências de manifesto** chegam a **240 destinos JavaScript distintos não analisados pela fila original**. [unscanned-manifest-frontier.json](unscanned-manifest-frontier.json) lista cada testemunha. Portanto, apagar as 1.196 marcações genéricas seria prematuro.

Uma inspeção suplementar, exclusivamente AST e resolução literal, está em [frontier-inspection.json](frontier-inspection.json). Partiu desses destinos e do entrypoint compilado da API, leu **3.384 módulos antes não analisados**, registrou **9.989 referências literais** e **62 referências não resolvidas/não literais ou erros de resolução**. Esse resultado não foi misturado às 2.809 ocorrências do checker. A inspeção não propaga aliases nem julga geradores de código; seus 217 candidatos por forma sintática não são novos veredictos de executor. A closure literal suplementar da API compilada contém **755 arquivos**, sem caminho explícito ao produto; a ausência de novos erros nesse subgrafo não elimina o pg-native já registrado na análise principal. Essa inspeção delimita inputs físicos para a correção futura, sem reivindicar graph completeness.

## Dez exemplos representativos

Hashes completos, offsets AST das expressões e trails estão em [examples.json](examples.json). Contagens de arquivo nesta tabela não são somadas: os arquivos são amostras das causas anteriores.

| Exemplo físico e contexto | Causa e observação | Remédio delimitado / prova faltante |
| --- | --- | --- |
| packages/shared/package.json → zod → node_modules/zod/package.json | Marca installed por não ser workspace; o manifest declara zod runtime e Vitest dev. O destino zod existe e tem identidade física. | Separar descoberta de julgamento; percorrer runtime e tipos antes de liquidar a aresta. Não usar “pacote conhecido” como aprovação. |
| node_modules/eslint/package.json: dev eslint=file:. e eslint-config-eslint=file:packages/eslint-config-eslint | Um self-edge produz UNVERIFIED_LOCAL_DEPENDENCY; um diretório ausente produz UNRESOLVED_INSTALLED_LOCAL_DEPENDENCY. O installedActor foi inicialmente registrado por ms/dev eslint 4.18.2, mas o pacote físico é ESLint 10.2.1. | Liquidar o self-cycle por closure física. A referência dev ausente admite recibo específico de distribuição instalada, com declaração, lookup e prova de ausência. Não afirmar satisfação da range nem estender a exceção a manifests de source. |
| node_modules/@vitejs/plugin-react/package.json: dev @vitejs/react-common=workspace:* | Um UNVERIFIED_WORKSPACE_DEPENDENCY; a distribuição inclui dist/types e conserva metadata de build upstream. Entrou pela raiz/tooling. | Inventariar essa referência exata e comprovar ausência e não uso na implementação instalada; se um import efetivo a pedir, permanece indeterminada. Não excluir todas as dependências dev. |
| node_modules/@types/node/process.d.ts:71 | node:quic é referenciado em tipos; Node 22 não o reconheceu/resolviu neste procedimento. A raiz usa @types/node 25.6.0. | Resolver a closure de tipos sob perfil Node22; eventual alinhamento de versão é manutenção de dependência com claim próprio. Alternativa documental exige adjudicação dessa declaração exata, sem fingir disponibilidade runtime do builtin. |
| node_modules/pg/lib/native/client.js:7 | require('pg-native') ausente. O grafo chega pelo getter native e pelo ramo NODE_PG_FORCE_NATIVE de pg/lib/index.js. | Preservar como frontier opcional ausente, com lookup completo e binding de ambiente/config/caller; a opção native não pode reaparecer sem revalidação. Não presumir que a presença de pg prove pg-native. |
| packages/harness/src/capability-boundary.ts:595–600,628–629 | Sete ocorrências; outros sete no dist. Object.getOwnPropertyDescriptor alimenta inspeção de descriptor e serialização; Object.getPrototypeOf alimenta comparação com Object.prototype/null. A origem de fonte é core; o dist chega pelo worker→operational-harness-worker→harness. | Resumo estreito de operação e uso do resultado, ou revisão hash-bound desses corpos e callers. Não transformar Object/Reflect em APIs sempre neutras: obtenção de constructor e invocação continuam recusadas. |
| apps/web/src/auth/session.ts:77–82 | Uma escape e quatro property diagnostics: alias de globalThis para ler/chamar o bootstrap token provider e ler/apagar token. Está na closure web. | Adjudicar as duas chaves exatas e a composição confiável do callback; uma assinatura TypeScript ou o prefixo __CVG_ não prova ausência de loader. Origem de callback desconhecida continua aberta. |
| node_modules/zod/v4/core/doc.cjs:36 | Uma execução dinâmica real: new F(...args, lines.join(...)), F=Function. A closure worker chega por zod/classic→core. util.cjs também contém new F('') e leituras de constructor, dentro de suas 16 ocorrências. | Adjudicação do gerador, de seus produtores e bindings no candidato, com AST do código gerado ou prova da gramática emitida. Não declarar Zod neutro por dependência nominal; jitless sozinho não remove arquivos nem todas as capabilities. |
| node_modules/fast-json-stringify/index.js:239,1310 | Duas marcações de executor real: new Function e Function.apply. API→Fastify→schema controller→compiler; schemas e opções alimentam a geração. Há variantes físicas do stack, que não podem compartilhar recibo apenas por nome. | Vincular gerador, todos os schemas/configs atuais, params/bindings e assembly/escaping. Código gerado indeterminado ou novo schema invalida o julgamento. Não trocar serializer/validator em T2 para fabricar verde. |
| node_modules/pino/lib/transport.js:273 | O arquivo tem oito ocorrências, incluindo base indeterminada e resolve(origin) não literal. Entrou pela dependência pino e pelo stack Fastify. O host usa logger:false, mas a função/export ainda está na closure física. | Revisar caller/target/config do transporte e worker, ou provar a não seleção naquele contexto congelado. “logger:false” isolado não aprova a API genérica exportada. Target configurável ou novo caller sem prova permanece aberto. |

Vite também aparece por Vitest, não por uma dependência direta do domínio do assistente: module-runner.js tem import(filepath), import.meta.resolve com specifier composto e AsyncFunction. Esse é um executor/loader real de validação, a ser vinculado ao inventário de testes/configs efetivamente autorizado, sem retirar suítes ou declarar toda a biblioteca neutra.

## Base do contrato e distinção T2/T3

SPEC0178, “Fronteira e arquivos” e “Gramática verificável”, exige manifests inclusive dev/optional/peer, closure local/types/runtime, identidade física, revisão/inventário para resolução não literal e recusa de unknown. Afirma também que o gate de referências não substitui sandbox de JavaScript arbitrário. SPEC0180, HISO-014, chama expressão dinâmica não resolvida de INCOMPLETE a adjudicar; “Prova de consumo público” exige perfis/versionamento próprios e preservação hash-bound. ADR010 proíbe domínio/env/processo do produto nos hosts e não concede aceite por separação.

**T2 possível:** reparar o traversal e seus estados, melhorar proveniência dos diagnósticos, reconhecer operações estreitas comprovadas e inventariar/adjudicar casos finitos no candidato sob a gramática existente. Sem mudar APIs, comportamento de aplicação, denominadores ou suites. A instalação não será fechada apenas por shape de metadata.

**Mudança de contrato:** excluir dev/tipos/node_modules, declarar generadores ou callbacks arbitrários sempre seguros, permitir imports core→produto, reduzir testes, alterar os scopes/aceites de CI de D010, ou transformar configuração dinâmica desconhecida em PASS. Isso excede esta correção T2. A SPEC0180 lida ainda contém gate humano para D009–D012; esta lane não aprova seus deltas T3 nem modifica seus critérios.

## Menor sequência coerente proposta

1. **Fechar uma fila física e liquidar estados após o fixed point.** Enfileirar todo destino runtime de manifesto, preservando tipos, actor/declaring manifest e mode/conditions; resolver self-edges e SCCs sem declarar visiting/provisional como completo. Substituir a marcação “installed e não workspace” por estado da closure efetivamente analisada: completos encerram a obrigação de descoberta, incompletos retêm a causa concreta. A fila dos 240 destinos já identificados e suas referências é um conjunto finito; seus resultados entram no novo inventário. Não apenas apagar diagnostics.
2. **Reduzir conservadorismo onde existe prova estreita.** Distinguir a operação de reflexão de seu resultado; comparação/metadado/data inspection sem invocação ou escape de capability pode ter resumo verificado. Manter constructor executável, reflection recovery, eval/Function/vm/worker/process e loader exports desconhecidos. Para namespaces passados a funções locais, um resumo de callee é suficiente apenas se todos os acessos/transferências relevantes estiverem inventariados; uma assinatura de tipo não basta. Começar pelas fontes próprias e seus dist, evitando uma engine geral de whole-JS.
3. **Adjudicar o resíduo congelado por referência/contexto.** Tratar separadamente self/metadata upstream ausente, optional runtime ausente, incompatibilidade de tipos, geradores reais, transports e executor de testes. Cada julgamento precisa de evidência positiva suficiente; os casos sem evidência continuam INCOMPLETE, com a prova faltante nomeada. Uma única captura atual e uma revisão da lista completa substituem rodadas de microbarras hipotéticas. Não há promessa de zero diagnostics antes dessa revisão.

Essa sequência é proposta, não implementada. Se um caso exigir alteração de comportamento ou ampliação da gramática aprovada, ele recebe decisão de contrato separada; não bloqueia a possibilidade dos reparos T2 anteriores.

## Estratégia de adjudicação por hash

[proposal.json](proposal.json) contém o binding atual e o esquema proposto; não é recibo aprovado. O candidato deve vincular inventário path/bytes/mode, manifests/lock/configs, bytes dos três contratos, checker/lexical/analyzer, versão Node22, conditions e perfil de resolução. mtime fica na evidência de preservação. O registro de caso precisa de path físico e package context, declaração/campo/specifier/version, hashes do manifest e módulo, offset/kind/hash do AST, trail de entrada, modos types/runtime e condições, decisão e evidência/revisor responsável. Linha ou nome de pacote isolados não são identidade suficiente.

Decisões possíveis precisam demonstrar: closure física resolvida; operação de dados/metadados sem transferência de loader; metadata upstream não presente na distribuição e não solicitada por import efetivo; ou executor limitado à composição congelada. DENY/UNRESOLVED não permitem fechamento. Recibo ausente, stale, wildcard, novo caller/target/schema, dist diferente de declaration, mudança em condições/config ou hash divergente mantém INCOMPLETE.

Para geração real de código, o recibo deve cobrir **gerador e produtores atuais**, entradas que compõem texto, escaping/assembly, bindings das funções geradas e referências de módulo/capabilities no AST emitido ou na gramática demonstrada. Não basta buscar palavras no texto, testar uma string inocente ou aprovar a versão npm. Caso a enumeração de schemas/targets atuais ainda não esteja demonstrada, essa é a prova que falta; não se afirma impossibilidade global. Para Vite/Vitest, vincular roots/arquivos/config/transformações da invocação atual e conservar os testes do consumidor no scope autorizado; uma API de import arbitrário continua não adjudicada fora dessa composição.

## Controles e critério de término da correção futura

[ast-controls.json](ast-controls.json) registra **10 negativos sinalizados**, **9 controles neutros sem flag dinâmica** e **3 caracterizações**, sem mismatch no escopo estreito do analisador. Os textos foram apenas AST inputs; nenhum payload foi executado. As caracterizações confirmam a flag conservadora para descriptor/prototype e a flag legítima para Function com corpo vazio. Esses resultados não validam o checker completo ou o remédio.

Na verificação futura, preservar os controles existentes e acrescentar pares capazes de rejeitar o remédio:

- Aresta instalada neutra inteiramente resolvida deve encerrar descoberta; mesma instalação com main/runtime apontando ao produto e declaration neutra deve falhar. Exercitar require/import e destino nested diferente, inclusive alvo só alcançado pelo manifesto.
- Self-edge instalado neutro deve liquidar; ciclo que chega ao produto/unknown deve continuar falhando/incompleto. Dev e tipos que chegam ao produto continuam negativos.
- Metadata upstream ausente só pode encerrar com recibo exato; diretório materializado com import proibido, symlink, path fora da Source, metadata source própria faltante ou import efetivo da referência devem invalidá-lo.
- Descriptor/prototype usados somente no caso revisado podem ser neutros; recuperar constructor.value, usar Reflect.construct, exportar executor, alias mutável ou acessar propriedade computada indeterminada continuam negativos. Shadowing/rebinding não deve herdar resumo de intrinsic.
- Gerador com corpo e binding revisados pode encerrar aquele caso; inserir require/import ao produto, alterar assembly/escaping/schema/config ou fornecer texto desconhecido invalida o recibo. Body apenas “return 1” é controle, não prova do gerador inteiro.
- Transporte/test runner com target finito revisado tem controle positivo; target de produto em caller core, nova base/caller/condição ou filename não limitado permanece negativo/INCOMPLETE. Não executar esses payloads nesta lane.
- Remover recibo, trocar um hash de módulo/manifest/lock/config/contrato, ou usar o mesmo nome com outro destino físico deve impedir fechamento. Não aceitar contagem reduzida como critério.

O término é uma closure física completa no candidato corrigido, com cada obrigação resolvida ou adjudicada positivamente por evidência vigente, nenhum import core→produto e controles negativos preservados. Falta de prova fica no caso específico. A execução exata do checker corrigido e seus gates de integração pertence a lane autorizada futura; nesta lane permanece NOT_RUN.

## Preservação e entrega

[final-inputs.json](final-inputs.json) e [preservation.json](preservation.json) registram SHA-256, modos, tamanho e mtime dos inputs relevantes; drift de bytes/mode/mtime observado: **zero**. As leituras de Source não concedem aprovação aos hashes calculados. Arquivos de resultado intermediário são mantidos como evidência; a classificação usada neste relatório é a versão “corrected”.

**Próximo passo proposto:** registrar a fatia T2 de fila/estados e inventário de adjudicação, em candidato isolado e somente após autorização de implementação. Esta entrega conclui o diagnóstico solicitado; não implementa, não fecha installed e não reivindica aceite ou release.
