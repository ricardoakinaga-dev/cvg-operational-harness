import fs from 'node:fs'
import path from 'node:path'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
import {createHash} from 'node:crypto'
import {createBoundaryLexical} from '../../candidate-final-r19/scripts/boundary-lexical.mjs'
import {auditDynamicCodeExecution} from '../../candidate-final-r19/scripts/boundary-code-execution.mjs'
const root='/home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r19'
const out=path.dirname(fileURLToPath(import.meta.url))
if(!process.version.startsWith('v22.'))throw Error('Node22 required')
const ts=createRequire(path.join(root,'scripts/check-product-boundary.mjs'))('typescript')
const tests=[
 ['eval literal product payload','negative','eval("require(\"products/shift-assistant/src/main.ts\")")'],
 ['Function literal product payload','negative','Function("return import(\"products/shift-assistant/src/main.ts\")")()'],
 ['executor local assignment','negative','let execute; execute=Function;execute("return 1")()'],
 ['executor bind','negative','const execute=Function.bind(null);execute("return 1")()'],
 ['constructor invoke','negative','const f=()=>{}; f.constructor("return 1")()'],
 ['reflect descriptor constructor','negative','const get=Object.getOwnPropertyDescriptor;get(()=>{},"constructor")'],
 ['worker alias','negative','const {Worker:Start}=require("node:worker_threads");new Start("products/shift-assistant/src/main.ts")'],
 ['child_process alias','negative','const {execFileSync:run}=require("node:child_process");run("node",["products/shift-assistant/src/main.ts"])'],
 ['vm import execution','negative','import {runInThisContext as run} from "node:vm";run("1")'],
 ['executor exported','negative','export const compile=Function'],
 ['neutral class constructor','positive','export class Neutral {constructor(){this.value=1}}'],
 ['neutral domain require method','positive','const domain={require(){return 1}};export const value=domain.require()'],
 ['scalar constructor property','positive','const data={constructor:"label"};export const value=data.constructor'],
 ['executor name metadata','positive','export const value=Function.name'],
 ['executor length metadata','positive','const F=Function;export const value=F.length'],
 ['type-only worker import','positive','import type {Worker} from "node:worker_threads";export type Type=Worker'],
 ['type-only Function','positive','export type Type=typeof Function;export const value=1'],
 ['inert worker metadata','positive','import {isMainThread} from "node:worker_threads";export const value=isMainThread'],
 ['Object keys neutral','positive','export const value=Object.keys({synthetic:1})'],
 ['descriptor data inspection current conservative flag','characterization','function inspect(value,key){const p=Object.getOwnPropertyDescriptor(value,key);return !!p&&("value" in p)}'],
 ['prototype equality current conservative flag','characterization','function plain(value){return Object.getPrototypeOf(value)===Object.prototype}'],
 ['empty Function compiler actual execution capability','characterization','const F=Function;new F("")']
]
const result=[]
for(const [name,expectation,text]of tests){
 const source=ts.createSourceFile('synthetic-controls.mts',text,ts.ScriptTarget.Latest,true)
 const lexical=createBoundaryLexical(ts,source,true),all=[]
 const collect=n=>{all.push(n);ts.forEachChild(n,collect)};collect(source)
 const runtimeNodes=all.filter(n=>!lexical.erased(n))
 const unwrap=node=>{while(node&&(ts.isParenthesizedExpression(node)||ts.isAsExpression(node)||ts.isTypeAssertionExpression(node)||ts.isSatisfiesExpression(node)||ts.isNonNullExpression(node)))node=node.expression;return node}
 const literal=node=>{node=unwrap(node);return node&&ts.isStringLiteralLike(node)?node.text:undefined}
 const property=node=>ts.isPropertyAccessExpression(node)?node.name.text:ts.isElementAccessExpression(node)?literal(node.argumentExpression):undefined
 const isGlobal=node=>{node=unwrap(node);return !!node&&ts.isIdentifier(node)&&[lexical.global('globalThis'),lexical.global('global')].includes(lexical.identity(node))}
 const isProcess=node=>{node=unwrap(node);return !!node&&ts.isIdentifier(node)&&lexical.identity(node)===lexical.global('process')}
 const isBuiltinGetter=node=>!!node&&property(node)==='getBuiltinModule'&&isProcess(node.expression)
 const isLoader=node=>{node=unwrap(node);return !!node&&((ts.isIdentifier(node)&&lexical.identity(node)===lexical.global('require'))||(property(node)==='require'&&node.expression&&ts.isIdentifier(node.expression)&&lexical.identity(node.expression)===lexical.global('module')))}
 const diagnostics=[]
 auditDynamicCodeExecution({ts,source,lexical,runtimeNodes,typeOnly:lexical.erased,literal,isLoader,isBuiltinGetter,isGlobal,isDeclarationName:lexical.isDeclarationName,loaderDiagnostic:(node,reason)=>diagnostics.push({reason,start:node.getStart(source),end:node.getEnd(),kind:ts.SyntaxKind[node.kind],text:node.getText(source)})})
 const observed=diagnostics.length>0?'FLAGGED':'NO_DYNAMIC_EXECUTION_FLAG'
 const met=expectation==='negative'?diagnostics.length>0:expectation==='positive'?diagnostics.length===0:null
 result.push({name,expectation,text,sha256:createHash('sha256').update(text).digest('hex'),parseErrors:source.parseDiagnostics.length,observed,met,diagnostics})
}
const report={scope:'Original dynamic-code-execution analyzer only, real lexical binder, reduced loader predicates sufficient for these simple cases. These strings were AST inputs only; no fixture source, eval, vm, worker or process payload was executed. This does not validate full installed checker or proposed remedy.',node:process.version,tests:result,negativeCount:result.filter(r=>r.expectation==='negative').length,positiveCount:result.filter(r=>r.expectation==='positive').length,characterizationCount:result.filter(r=>r.expectation==='characterization').length,expectationMismatches:result.filter(r=>r.met===false).map(r=>r.name),payloadsExecuted:0}
fs.writeFileSync(path.join(out,'ast-controls.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({negativeCount:report.negativeCount,positiveCount:report.positiveCount,characterizationCount:report.characterizationCount,expectationMismatches:report.expectationMismatches,observations:result.map(r=>({name:r.name,expectation:r.expectation,observed:r.observed,diagnostics:r.diagnostics.length})),payloadsExecuted:0},null,2))
