import fs from 'node:fs'
import path from 'node:path'
import {createHash} from 'node:crypto'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
const root='/home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r19'
const out=path.dirname(fileURLToPath(import.meta.url))
if(!process.version.startsWith('v22.'))throw Error('Node22 required')
const own=name=>JSON.parse(fs.readFileSync(path.join(out,name)))
const write=(name,value)=>fs.writeFileSync(path.join(out,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'})
const sha=b=>createHash('sha256').update(b).digest('hex')
const before=own('final-inputs.json'),rows=new Map(before.files.map(row=>[row.path,row]))
const endOnly=[]
for(const rel of ['scripts/boundary-code-execution.mjs','scripts/boundary-lexical.mjs','scripts/boundary-manifests.mjs','scripts/tsconfig-path-grammar.mjs']){
 const file=path.join(root,rel),bytes=fs.readFileSync(file),st=fs.lstatSync(file,{bigint:true})
 if(!rows.has(rel)){rows.set(rel,{path:rel,sha256:sha(bytes),mode:Number(st.mode&0o7777n).toString(8),size:String(st.size),mtimeNs:String(st.mtimeNs),symlink:st.isSymbolicLink()});endOnly.push(rel)}
}
const inputs=[...rows.values()].sort((a,b)=>a.path.localeCompare(b.path)),drift=[]
for(const row of inputs){const file=path.join(root,row.path),bytes=fs.readFileSync(file),st=fs.lstatSync(file,{bigint:true});const fields=[];if(sha(bytes)!==row.sha256)fields.push('bytes');if(String(st.mtimeNs)!==row.mtimeNs)fields.push('mtime');if(Number(st.mode&0o7777n).toString(8)!==row.mode)fields.push('mode');if(String(st.size)!==row.size)fields.push('size');if(fields.length)drift.push({path:row.path,fields})}
const preservation={node:process.version,source:root,baselineInventory:'final-inputs.json',sourceInputFiles:inputs.length,baselineComparedFiles:before.files.length,finalFingerprintOnly:endOnly,files:inputs,inventorySha256:sha(JSON.stringify(inputs)),drift,sourceWrites:0,claimLimit:'Before/after comparisons apply to recorded first-read baselines. ESM helper files first fingerprinted at finalization are explicitly finalFingerprintOnly. Source reads/writes were additionally constrained by Node Permission Model; no source chmod/utime/restoration performed.'}
write('preservation.json',preservation)
const ts=createRequire(path.join(root,'scripts/check-product-boundary.mjs'))('typescript')
const c=own('closure.json'),p=own('production-closure-corrected.json'),d=own('diagnostic.json')
const selections=[
 ['E01','packages/shared/package.json',[], 'Declared runtime zod and dev Vitest; physical installed successors, not workspaces.'],
 ['E02','node_modules/eslint/package.json',[], 'Self file:. and missing dev file:packages/eslint-config-eslint; incoming actor witness originates at ms/dev eslint range, not exact installed version.'],
 ['E03','node_modules/@vitejs/plugin-react/package.json',[], 'Missing upstream workspace:* dev actor @vitejs/react-common in installed distribution.'],
 ['E04','node_modules/@types/node/process.d.ts',[71], 'Type import node:quic under Node22 resolution; types package major 25.'],
 ['E05','node_modules/pg/lib/native/client.js',[7,27], 'Missing optional native module and host namespace property.'],
 ['E06','packages/harness/src/capability-boundary.ts',[595,596,600,628,629], 'Descriptor inspection/serialization and prototype equality; compiled sibling has separate bytes/hash.'],
 ['E07','apps/web/src/auth/session.ts',[77,78,79,81,82], 'globalThis alias and custom bootstrap token data/callback properties.'],
 ['E08','node_modules/zod/v4/core/doc.cjs',[31,36], 'Aliased global Function compiles assembled code and parameter names; real executor capability.'],
 ['E09','node_modules/fast-json-stringify/index.js',[239,1310], 'Function and Function.apply compile serializers; requires generator+schema+binding proof.'],
 ['E10','node_modules/pino/lib/transport.js',[273], 'createRequire at caller-derived context and resolve at nonliteral origin.']
]
const examples=[]
for(const [id,file,lines,cause]of selections){const text=fs.readFileSync(path.join(root,file),'utf8'),source=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true),ast=[];const visit=node=>{const start=node.getStart(source),line=source.getLineAndCharacterOfPosition(start).line+1;if(lines.includes(line)&&(ts.isCallExpression(node)||ts.isNewExpression(node)||ts.isPropertyAccessExpression(node)||ts.isElementAccessExpression(node)||ts.isImportTypeNode(node)||ts.isVariableDeclaration(node))){const expression=node.getText(source);ast.push({line,startUtf16:start,endUtf16:node.getEnd(),kind:ts.SyntaxKind[node.kind],expression,expressionSha256:sha(Buffer.from(expression))})}ts.forEachChild(node,visit)};visit(source);examples.push({id,file,input:rows.get(file),cause,boundaryTrail:c.trail[file]??null,hostRuntimeTrail:p.hostClosure.trails[file]??null,diagnostics:d.diagnostics.filter(r=>r.file.replace(/:\d+$/,'')===file),ast})}
write('examples.json',{verdict:'DIAGNOSTIC_ONLY_NOT_ADJUDICATED',examples})
const digest=rel=>rows.get(rel)?.sha256
write('proposal.json',{
 status:'PROPOSED_NOT_IMPLEMENTED_NOT_APPROVED',contractChangeAuthorized:false,source:root,node:'v22.23.2',
 candidateBinding:{inventory: 'preservation.json',inventorySha256:preservation.inventorySha256,baselineObservedInventorySha256:before.inventorySha256,lockSha256:digest('package-lock.json'),spec0178Sha256:digest('docs/02_spec/0178_harness_consumer_extraction.md'),spec0180Sha256:digest('docs/02_spec/0180_shared_transport_ci_security.md'),adr010Sha256:digest('docs/architecture/adrs/ADR-010-harness-product-isolation.md'),checkerSha256:digest('scripts/check-product-boundary.mjs'),dynamicAnalyzerSha256:digest('scripts/boundary-code-execution.mjs'),lexicalSha256:digest('scripts/boundary-lexical.mjs'),manifestReaderSha256:digest('scripts/boundary-manifests.mjs'),compilerConfigSha256:digest('tsconfig.base.json'),conditions:['node','import or require as recorded','default'],typescript:ts.version},
 orderedT2Proposal:[
  'Enqueue every physical manifest runtime destination; preserve independent type/runtime edges and physical actor provenance; settle implementation/metadata states after closure/SCC fixed point, never merely because a registry actor is not a workspace.',
  'Add only proved narrow summaries for data-only descriptor/prototype/namespace uses, retaining capability recovery/call/export/unknown cases. Or review exact contextual occurrences instead of implementing an unrestricted JS analysis.',
  'Freeze the resulting finite installed frontier and perform per-reference/per-context adjudication under SPEC0178 inventory/review and SPEC0180 HISO014, preserving raw diagnostics and declining cases without positive proof.'
 ],
 receiptTemplate:{approved:false,candidateInventorySha256:null,contractDigests:null,checkerAndParserDigests:null,physicalModule:{realPath:null,mode:null,moduleSha256:null,packageContext:null,packageManifestSha256:null},declaredEdge:{declaringManifest:null,declaringManifestSha256:null,dependencyField:null,specifier:null,declaredVersion:null,selectedPhysicalVersion:null,lookupWitness:null},occurrence:{startUtf16:null,endUtf16:null,syntaxKind:null,astSha256:null,reason:null,mode:null},context:{incomingTrail:null,callerHashes:null,configHashes:null,conditionProfile:null,schemasOrTargetsInventorySha256:null,generatedAstOrGrammarProofSha256:null,bindingsProofSha256:null},decision:null,evidence:null,reviewerAndAuthority:null},
 permittedPositiveProofKinds:['RESOLVED_PHYSICAL_CLOSURE','PROVED_INERT_DATA_OPERATION','PROVED_ABSENT_DISTRIBUTION_ONLY_METADATA','PROVED_CONTEXT_BOUND_EXECUTOR'],blockingProofKinds:['DENY','UNRESOLVED','MISSING_RECEIPT','STALE_OR_MISMATCHED_RECEIPT'],
 remainingProofs:['Complete implementation traversal for manifest successors, including the already recorded 240 targets.','Contextual judgments of concrete metadata absences/type mismatch/optional pg-native.','Generator producers, schema/config text formation, escaping, generated AST/grammar and bindings for real compilers.','Actual caller/target selection for transports and test runner; proof for injected namespace/callback data contexts.','Fresh exact checker and intact positive/negative regressions on the future corrected candidate in an authorized lane.'],
 exclusionsFromT2:['No blanket node_modules/dev/types exemption.','No arbitrary dynamic code treated as safe or unknown waived.','No new public runtime behavior, API, CI D010 contract, test exclusions, or reduced thresholds.','No Source mutation or implementation in this lane.']
})
const a=own('analysis-corrected.json'),controls=own('ast-controls.json'),frontier=own('frontier-inspection.json')
if(Object.values(a.counts).reduce((sum,n)=>sum+n,0)!==2809||Object.values(a.byScope).reduce((sum,n)=>sum+n,0)!==2809||examples.length!==10||controls.expectationMismatches.length||drift.length)throw Error('packet consistency failed')
const files=fs.readdirSync(out).filter(name=>fs.statSync(path.join(out,name)).isFile()).sort().map(name=>{const bytes=fs.readFileSync(path.join(out,name));return {path:name,sha256:sha(bytes),bytes:bytes.length}})
write('packet-manifest.json',{task:'INSTALLED_FRONTIER_PLAN_R22',status:'READONLY_DIAGNOSIS_COMPLETED_INSTALLED_REMAINS_INCOMPLETE',implementation:false,acceptanceClaim:false,files,canonical:['REPORT.md','diagnostic.json','analysis-corrected.json','production-closure-corrected.json','examples.json','proposal.json','ast-controls.json','frontier-inspection.json','preservation.json'],intermediateSuperseded:['analysis.json','production-closure.json','analysis-inputs.json'],counts:a.counts,total:a.total,sourceFiles:d.sourceFiles,coreFiles:d.coreFiles,workspaceCount:d.workspaceCount,edgeCount:d.edgeCount,explicitViolations:d.violations.length,examples:examples.length,controls:{negative:controls.negativeCount,positive:controls.positiveCount,characterization:controls.characterizationCount,mismatches:controls.expectationMismatches.length,payloadsExecuted:0},additionalLiteralFrontier:{parsedModules:frontier.parsedCount,references:frontier.literalReferences.length,unresolvedOrResolutionErrors:frontier.errors.length},inputFiles:inputs.length,baselineComparedFiles:before.files.length,sourceDrift:drift,exactCheckerCLI:'NOT_RUN_NO_DESCENDANTS',futureRemedyAndIntegration:'NOT_RUN_NOT_AUTHORIZED'})
console.log(JSON.stringify({report:'REPORT.md',total:a.total,examples:examples.length,inputFiles:inputs.length,baselineComparedFiles:before.files.length,finalFingerprintOnly:endOnly,drift,consistency:'MATCH',implementation:false,acceptance:false},null,2))
