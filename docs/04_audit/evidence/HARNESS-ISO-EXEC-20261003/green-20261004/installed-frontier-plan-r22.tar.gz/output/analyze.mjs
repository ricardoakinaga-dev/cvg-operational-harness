import fs from 'node:fs'
import path from 'node:path'
import {createRequire} from 'node:module'
import {fileURLToPath,pathToFileURL} from 'node:url'
import {createHash} from 'node:crypto'
const root='/home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r19'
const out=path.dirname(fileURLToPath(import.meta.url))
if(!process.version.startsWith('v22.')) throw Error('Node22 required')
const load=name=>JSON.parse(fs.readFileSync(path.join(out,name)))
const d=load('diagnostic.json'),c=load('closure.json')
const sha=b=>createHash('sha256').update(b).digest('hex')
const inputs=new Map(load('inputs.json').files.map(row=>[row.path,row]))
function read(rel){const file=path.join(root,rel),bytes=fs.readFileSync(file),st=fs.lstatSync(file,{bigint:true});if(!inputs.has(rel))inputs.set(rel,{path:rel,sha256:sha(bytes),mode:Number(st.mode&0o7777n).toString(8),size:String(st.size),mtimeNs:String(st.mtimeNs),symlink:st.isSymbolicLink()});return bytes.toString('utf8')}
const ts=createRequire(pathToFileURL(path.join(root,'scripts/check-product-boundary.mjs')))('typescript')
const manifests=new Map(c.manifests.map(p=>[p.file,p]))
const sourceManifest=JSON.parse(read('package.json'))
const config=JSON.parse(read('tsconfig.base.json')).compilerOptions
const decl=f=>/\.d\.[cm]?ts$/.test(f)
const matches=(candidate,typeTarget,mode)=>{
  const ext=path.extname(candidate),ss={'.js':['.ts','.tsx'],'.mjs':['.mts'],'.cjs':['.cts']}[ext]??[]
  const all=[candidate,...ss.map(s=>candidate.slice(0,-ext.length)+s)]
  if(!ext&&mode==='require')all.push(candidate+'.ts',candidate+'.tsx',path.join(candidate,'index.ts'),path.join(candidate,'index.tsx'))
  return all.some(f=>path.resolve(root,f)===path.resolve(root,typeTarget))
}
function sourceProjection(ref){
  if(!ref.typeTarget||decl(ref.typeTarget)||! /\.[cm]?tsx?$/.test(ref.typeTarget))return false
  if(ref.specifier.startsWith('.'))return matches(path.join(path.dirname(ref.file),ref.specifier),ref.typeTarget,ref.mode)
  for(const [pattern,values]of Object.entries(config.paths??{})){
    const [pre,suf]=pattern.split('*');const hit=suf===undefined?ref.specifier===pre:ref.specifier.startsWith(pre)&&ref.specifier.endsWith(suf)
    if(!hit)continue
    const wildcard=suf===undefined?'':ref.specifier.slice(pre.length,ref.specifier.length-suf.length)
    for(const value of values)if(matches(path.join(config.baseUrl??'.',value.replace('*',wildcard)),ref.typeTarget,ref.mode))return true
  }return false
}
const runtime=new Map(),unresolved=[]
for(const ref of c.resolutions){
  if(ref.manifestEdge)continue
  const target=ref.target??(sourceProjection(ref)?ref.typeTarget:null)
  if(target){if(!runtime.has(ref.file))runtime.set(ref.file,new Set());runtime.get(ref.file).add(target)}else unresolved.push(ref)
}
function closure(graph,starts){const seen=new Set(starts),queue=starts.map(file=>({file,trail:[file]})),trails={};for(let i=0;i<queue.length;i++){const row=queue[i];trails[row.file]=row.trail;for(const target of graph.get(row.file)??[])if(!seen.has(target)){seen.add(target);queue.push({file:target,trail:[...row.trail,target]})}}return {files:[...seen].sort(),trails}}
const hostEntries=['apps/api/src/main.ts','apps/worker/src/main.ts','apps/web/src/main.tsx'].filter(f=>fs.existsSync(path.join(root,f)))
const hostProfiles=Object.fromEntries(hostEntries.map(f=>[f,closure(runtime,[f])]))
const hostClosure=closure(runtime,hostEntries),hostSet=new Set(hostClosure.files)
const sourceEntries=['apps/api/src/main.ts','apps/worker/src/main.ts','apps/web/src/main.tsx']
const sourceProfiles=Object.fromEntries(sourceEntries.map(f=>[f,closure(runtime,[f])]))
const fullStarts=['package.json','apps/api/package.json','apps/worker/package.json','apps/web/package.json']
const prodManifestGraph=new Map(),manifestWitness=[]
const workspaces=new Map([...manifests.values()].filter(p=>!p.file.startsWith('node_modules/')).map(p=>[p.name,p.file]))
function physicalContext(file){const parts=file.split('/');for(let i=parts.length-2;i>=0;i--)if(parts[i]==='node_modules'){const n=parts[i+1].startsWith('@')?3:2;return parts.slice(0,i+n).join('/')}}
function add(from,to){if(!prodManifestGraph.has(from))prodManifestGraph.set(from,new Set());prodManifestGraph.get(from).add(to)}
for(const p of [sourceManifest,...manifests.values()]){
  const file=p.file??'package.json'
  for(const field of ['dependencies','optionalDependencies','peerDependencies'])for(const [name,version]of Object.entries(p[field]??{})){
    let targetName=name
    if(version.startsWith('npm:')){const a=version.slice(4),i=a.lastIndexOf('@');targetName=i>0?a.slice(0,i):a}
    const ws=workspaces.get(targetName);if(ws)add(file,ws)
    let target
    if(/^(file|link):/.test(version)){const local=path.resolve(root,path.dirname(file),version.slice(version.indexOf(':')+1),'package.json');if(fs.existsSync(local))target=path.relative(root,fs.realpathSync(local))}
    else for(const dir of createRequire(path.join(root,file)).resolve.paths(name)??[]){if(!dir.startsWith(root+'/'))continue;const candidate=path.join(dir,name);if(!fs.existsSync(candidate))continue;const real=fs.realpathSync(candidate);if(real.startsWith(root+'/'))target=path.relative(root,path.join(real,'package.json'));break}
    if(target)add(file,target)
    manifestWitness.push({file,field,name,version,workspace:ws,target:target??null})
  }
}
const productionManifests=closure(prodManifestGraph,fullStarts),productionManifestSet=new Set(productionManifests.files)
const availability=physicalContextFile=>productionManifestSet.has(physicalContextFile+'/package.json')
const keyFile=row=>row.file.replace(/:\d+$/,'')
const counts={},byFile={},byScope={},byReasonScope={}
for(const row of d.diagnostics){const file=keyFile(row);counts[row.reason]=(counts[row.reason]??0)+1;byFile[file]=(byFile[file]??0)+1
  const context=physicalContext(file)
  const scope=hostSet.has(file)?'HOST_RUNTIME_CODE':productionManifestSet.has(file)?'PRODUCTION_MANIFEST':context&&availability(context)?'PRODUCTION_AVAILABLE_OTHER_CODE_OR_METADATA':'VALIDATION_TOOLING_OR_OTHER_GOVERNED'
  byScope[scope]=(byScope[scope]??0)+1
  byReasonScope[row.reason]??={};byReasonScope[row.reason][scope]=(byReasonScope[row.reason][scope]??0)+1
}
const dyn=new Map();for(const row of d.diagnostics)if(row.reason==='UNVERIFIED_DYNAMIC_CODE_EXECUTION'){const f=keyFile(row);if(!dyn.has(f))dyn.set(f,[]);dyn.get(f).push(row)}
const dynamicGroups={};const perLine=[]
for(const [file,rows]of dyn){const src=ts.createSourceFile(file,read(file),ts.ScriptTarget.Latest,true),nodes=[];const visit=node=>{const line=src.getLineAndCharacterOfPosition(node.getStart(src)).line+1;const text=node.getText(src);if(ts.isPropertyAccessExpression(node)||ts.isElementAccessExpression(node)||ts.isCallExpression(node)||ts.isNewExpression(node)||ts.isIdentifier(node))nodes.push({line,kind:ts.SyntaxKind[node.kind],text:text.slice(0,180)});ts.forEachChild(node,visit)};visit(src)
  for(const [line,count]of Object.entries(rows.reduce((a,r)=>{const l=Number(r.file.split(':').at(-1));a[l]=(a[l]??0)+1;return a},{}))){const expressions=nodes.filter(n=>n.line===Number(line));let group=expressions.some(n=>/\b(?:Object|Reflect)\.(?:get|construct|getPrototypeOf|getOwnPropertyDescriptor|getOwnPropertyDescriptors)\b/.test(n.text))?'REFLECTION_SITE':expressions.some(n=>/\.constructor\b|\[['"]constructor['"]\]/.test(n.text))?'CONSTRUCTOR_SITE':expressions.some(n=>/\b(?:eval|Function)\b/.test(n.text))?'EVAL_FUNCTION_SITE':'EXECUTOR_ALIAS_OR_MODULE_SITE';dynamicGroups[group]=(dynamicGroups[group]??0)+count;perLine.push({file,line:Number(line),count,group,expressions})}
}
const repoOnly=d.diagnostics.filter(r=>!keyFile(r).startsWith('node_modules/'))
const result={counts,total:d.diagnostics.length,uniqueDiagnosticRows:new Set(d.diagnostics.map(r=>JSON.stringify(r))).size,distinctDiagnosticFiles:Object.keys(byFile).length,byScope,byReasonScope,physicalContexts:new Set(c.sourceFiles.map(physicalContext).filter(Boolean)).size,productionManifestCount:productionManifests.files.length,hostRuntimeFiles:hostClosure.files.length,hostRuntimeUnresolved:unresolved.filter(r=>hostSet.has(r.file)),hostRuntimeDiagnostics:d.diagnostics.filter(r=>hostSet.has(keyFile(r))),repoOnlyDiagnostics:repoOnly,heuristicDynamicGroups:dynamicGroups,byFile:Object.fromEntries(Object.entries(byFile).sort((a,b)=>b[1]-a[1]))}
const write=(name,value)=>fs.writeFileSync(path.join(out,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'})
write('analysis-corrected.json',result)
write('production-closure-corrected.json',{profileLimitation:'Logical source compositions and current physical Node22 literal successors; all parsed branches; web uses Node conditions, not a Vite artifact. Existing apps/api/dist/main.js was not analyzed by checker, so is not a complete artifact closure. No runtime execution/bundle/image claim.',hostEntries,hostProfiles,sourceProfiles,hostClosure,productionManifests,productionManifestWitness:manifestWitness.filter(r=>productionManifestSet.has(r.file)),unresolved})
const rows=[...inputs.values()].sort((a,b)=>a.path.localeCompare(b.path)),drift=[]
for(const before of rows){const file=path.join(root,before.path),bytes=fs.readFileSync(file),st=fs.lstatSync(file,{bigint:true});if(sha(bytes)!==before.sha256||String(st.mtimeNs)!==before.mtimeNs||Number(st.mode&0o7777n).toString(8)!==before.mode||String(st.size)!==before.size)drift.push(before.path)}
write('analysis-inputs-corrected.json',{source:root,files:rows,inventorySha256:sha(JSON.stringify(rows)),drift})
console.log(JSON.stringify({total:result.total,uniqueDiagnosticRows:result.uniqueDiagnosticRows,distinctDiagnosticFiles:result.distinctDiagnosticFiles,byScope,byReasonScope,hostEntries,hostRuntimeFiles:hostClosure.files.length,productionManifestCount:result.productionManifestCount,hostRuntimeUnresolved:result.hostRuntimeUnresolved,heuristicDynamicGroups:dynamicGroups,drift},null,2))
