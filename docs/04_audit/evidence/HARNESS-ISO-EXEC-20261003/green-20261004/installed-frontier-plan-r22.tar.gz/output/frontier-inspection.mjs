import fs from 'node:fs'
import path from 'node:path'
import {createRequire,isBuiltin} from 'node:module'
import {fileURLToPath,pathToFileURL} from 'node:url'
import {createHash} from 'node:crypto'
const root='/home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r19'
const out=path.dirname(fileURLToPath(import.meta.url))
if(!process.version.startsWith('v22.'))throw Error('Node22 required')
const ts=createRequire(path.join(root,'scripts/check-product-boundary.mjs'))('typescript')
const own=name=>JSON.parse(fs.readFileSync(path.join(out,name)))
const c=own('closure.json'),f=own('unscanned-manifest-frontier.json')
const inputs=new Map(own('analysis-inputs-corrected.json').files.map(row=>[row.path,row]))
const hash=b=>createHash('sha256').update(b).digest('hex')
function read(rel){const bytes=fs.readFileSync(path.join(root,rel)),st=fs.lstatSync(path.join(root,rel),{bigint:true});if(!inputs.has(rel))inputs.set(rel,{path:rel,sha256:hash(bytes),mode:Number(st.mode&0o7777n).toString(8),size:String(st.size),mtimeNs:String(st.mtimeNs),symlink:st.isSymbolicLink()});return bytes.toString('utf8')}
const config=ts.parseJsonConfigFileContent(ts.readConfigFile(path.join(root,'tsconfig.base.json'),ts.sys.readFile).config,ts.sys,root).options
const graph=new Map(c.resolutions.filter(r=>!r.manifestEdge&&r.target).map(r=>[r.file,new Set()]))
for(const r of c.resolutions)if(!r.manifestEdge&&r.target)graph.get(r.file).add(r.target)
const sources=new Set(c.sourceFiles),parsed=[],references=[],dynamicCandidates=[],errors=[]
const starts=[...new Set(f.rows.map(r=>r.target)), 'apps/api/dist/main.js']
const queue=[...starts],seen=new Set(queue)
for(let i=0;i<queue.length;i++){
 const file=queue[i]
 if(!/\.(?:[cm]?js|jsx|[cm]?ts|tsx)$/.test(file))continue
 if(sources.has(file)&&file!=='apps/api/dist/main.js'){
  for(const to of graph.get(file)??[])if(!seen.has(to)){seen.add(to);queue.push(to)}
  continue
 }
 const source=ts.createSourceFile(file,read(file),ts.ScriptTarget.Latest,true)
 const mode=ts.getImpliedNodeFormatForFile(path.join(root,file),undefined,ts.sys,config)===ts.ModuleKind.CommonJS?'require':'import'
 parsed.push({file,bytes:Buffer.byteLength(source.text),parseErrors:source.parseDiagnostics.length})
 if(source.parseDiagnostics.length)errors.push({file,reason:'SOURCE_PARSE_ERROR'})
 const literal=n=>n&&ts.isStringLiteralLike(n)?n.text:undefined
 const resolve=(node,specifier,kind)=>{
  const location={file,start:node.getStart(source),line:source.getLineAndCharacterOfPosition(node.getStart(source)).line+1,specifier,mode:kind}
  if(!specifier){errors.push({...location,reason:'NON_LITERAL_DIRECT_REFERENCE'});return}
  if(isBuiltin(specifier))return
  let target
  try {target=kind==='require'?createRequire(path.join(root,file)).resolve(specifier):fileURLToPath(import.meta.resolve(specifier,pathToFileURL(path.join(root,file)).href));target=fs.realpathSync(target);if(!target.startsWith(root+'/'))throw Error('MODULE_OUTSIDE_REPOSITORY');if(!fs.statSync(target).isFile())throw Error('NON_FILE');target=path.relative(root,target)}catch(error){errors.push({...location,reason:error.code??error.message});return}
  references.push({...location,target})
  if(!graph.has(file))graph.set(file,new Set());graph.get(file).add(target)
  if(!seen.has(target)){seen.add(target);queue.push(target)}
 }
 const visit=node=>{
  if((ts.isImportDeclaration(node)||ts.isExportDeclaration(node))&&node.moduleSpecifier&&!node.isTypeOnly&&!node.importClause?.isTypeOnly)resolve(node,literal(node.moduleSpecifier),mode)
  if(ts.isCallExpression(node)&&(node.expression.kind===ts.SyntaxKind.ImportKeyword||(ts.isIdentifier(node.expression)&&node.expression.text==='require')))resolve(node,literal(node.arguments[0]),node.expression.kind===ts.SyntaxKind.ImportKeyword?'import':'require')
  if((ts.isCallExpression(node)||ts.isNewExpression(node))&&/\b(?:eval|Function|AsyncFunction|Worker|execFile|spawn|runIn|compileFunction)\b/.test(node.expression.getText(source)))dynamicCandidates.push({file,start:node.getStart(source),line:source.getLineAndCharacterOfPosition(node.getStart(source)).line+1,expression:node.expression.getText(source),text:node.getText(source).slice(0,250)})
  ts.forEachChild(node,visit)
 };visit(source)
}
const apiSeen=new Set(['apps/api/dist/main.js']),apiQueue=[...apiSeen],apiTrail={}
for(let i=0;i<apiQueue.length;i++){const file=apiQueue[i];for(const to of graph.get(file)??[])if(!apiSeen.has(to)){apiSeen.add(to);apiQueue.push(to);apiTrail[to]=file}}
for(const rel of ['scripts/build-runtime.mjs','scripts/runtime-image-contract.mjs','Dockerfile','vitest.config.mts','vite.config.mts','apps/api/src/server.ts','node_modules/fastify/lib/schema-controller.js','node_modules/@fastify/fast-json-stringify-compiler/index.js','node_modules/@fastify/ajv-compiler/index.js','node_modules/pino/pino.js','node_modules/zod/v4/core/schemas.cjs','node_modules/zod/v4/core/parse.cjs','node_modules/zod/v4/core/doc.cjs','node_modules/fast-json-stringify/index.js','scripts/tsconfig-path-grammar.mjs'])read(rel)
const rows=[...inputs.values()].sort((a,b)=>a.path.localeCompare(b.path)),drift=[]
for(const before of rows){const file=path.join(root,before.path),bytes=fs.readFileSync(file),st=fs.lstatSync(file,{bigint:true});if(hash(bytes)!==before.sha256||String(st.mtimeNs)!==before.mtimeNs||Number(st.mode&0o7777n).toString(8)!==before.mode||String(st.size)!==before.size)drift.push(before.path)}
const result={method:'Supplementary AST literal import/export/require closure only for previously unscanned physical manifest targets and compiled API entry. No alias, code-generation or general JS completeness claim; candidate expressions are classification aids, not confirmed dynamic-executor diagnostics. Existing analyzed modules use own Node22 resolver references.',node:process.version,starts,previouslyUnscannedCoreReachableTargets:f.targets,parsed,parsedCount:parsed.length,literalReferences:references,errors,dynamicCandidates,api:{entry:'apps/api/dist/main.js',files:[...apiSeen].sort(),predecessors:apiTrail,literalErrors:errors.filter(r=>apiSeen.has(r.file)),productFiles:[...apiSeen].filter(file=>file.startsWith('products/'))}}
fs.writeFileSync(path.join(out,'frontier-inspection.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'})
fs.writeFileSync(path.join(out,'final-inputs.json'),JSON.stringify({source:root,files:rows,inventorySha256:hash(JSON.stringify(rows)),drift},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({parsed:parsed.length,literalReferences:references.length,errors:errors.length,dynamicCandidates:dynamicCandidates.length,apiFiles:apiSeen.size,apiErrors:result.api.literalErrors.length,apiProductFiles:result.api.productFiles.length,inputFiles:rows.length,drift},null,2))
