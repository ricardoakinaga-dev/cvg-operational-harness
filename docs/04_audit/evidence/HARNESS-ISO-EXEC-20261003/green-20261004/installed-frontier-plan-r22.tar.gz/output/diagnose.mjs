import fs from 'node:fs'
import path from 'node:path'
import {createHash} from 'node:crypto'
import {createRequire, registerHooks, syncBuiltinESMExports} from 'node:module'
import {pathToFileURL, fileURLToPath} from 'node:url'
import childProcess from 'node:child_process'

const root = '/home/ricardo/.cache/cvg-harness-green-20261004/candidate-final-r19'
const output = path.dirname(fileURLToPath(import.meta.url))
if (!process.version.startsWith('v22.')) throw new Error('Node22 required')
const checker = path.join(root, 'scripts/check-product-boundary.mjs')
const rawRead = fs.readFileSync.bind(fs)
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
const inputs = new Map()
function observe(filename, bytes) {
  if (filename instanceof URL) filename = fileURLToPath(filename)
  if (typeof filename !== 'string') return
  filename = path.resolve(filename)
  if (!filename.startsWith(root + '/')) return
  if (inputs.has(filename)) return
  const stat = fs.lstatSync(filename, {bigint:true})
  inputs.set(filename, {path:path.relative(root,filename), sha256:sha(bytes), mode:Number(stat.mode & 0o7777n).toString(8), size:String(stat.size), mtimeNs:String(stat.mtimeNs), symlink:stat.isSymbolicLink()})
}
fs.readFileSync = (filename, options) => {
  const bytes = rawRead(filename)
  observe(filename, bytes)
  const encoding = typeof options === 'string' ? options : options?.encoding
  return encoding ? bytes.toString(encoding) : bytes
}
syncBuiltinESMExports()
for (const name of ['package.json','package-lock.json','tsconfig.base.json','docs/02_spec/0178_harness_consumer_extraction.md','docs/02_spec/0180_shared_transport_ci_security.md','docs/architecture/adrs/ADR-010-harness-product-isolation.md']) fs.readFileSync(path.join(root,name))
const require = createRequire(pathToFileURL(checker))
const ts = require('typescript')
const acorn = require('acorn')
const parsedConfig = ts.readConfigFile(path.join(root,'tsconfig.base.json'),ts.sys.readFile)
const compilerOptions = ts.parseJsonConfigFileContent(parsedConfig.config,ts.sys,root).options
const syntax = []
const resolutions = []
const calls = {resolverBatches:0, nativeSyntaxSubstitutions:0, rejectedProcessRequests:0}
const originalCheckerBytes = fs.readFileSync(checker)
const hook = registerHooks({load(url,context,nextLoad) {
  if (url !== pathToFileURL(checker).href) return nextLoad(url,context)
  const text = originalCheckerBytes.toString('utf8')
  const needle = 'return {\n    sourceFiles: sourceFiles.length,'
  if (text.split(needle).length !== 2) throw new Error('unexpected checker return')
  return {format:'module',shortCircuit:true,source:text.replace(needle,`return {\n    _graph: [...graph].map(([from, to]) => [from, [...to]]),\n    _sources: sourceFiles,\n    _seen: [...seen],\n    _manifests: [...metadata.cache.keys()],\n    _closureStates: [...metadata.closureStates].map(([file,state]) => [file,state.status]),\n    _trails: queue.map(({file,trail}) => [file,trail]),\n    sourceFiles: sourceFiles.length,`)}
}})
// No descendant is created. Only these two statically inspected checker requests
// are substituted; source module/fixture payloads are never imported or executed.
childProcess.spawnSync = (executable,args,options) => {
  if (executable !== process.execPath) throw new Error('unapproved executable')
  if (args.length === 2 && args[0] === '--check') {
    calls.nativeSyntaxSubstitutions++
    const file = args[1], text = fs.readFileSync(file,'utf8')
    const module = ts.getImpliedNodeFormatForFile(file,undefined,ts.sys,compilerOptions) === ts.ModuleKind.ESNext
    try {
      acorn.parse(text,{ecmaVersion:'latest',sourceType:module?'module':'script',allowHashBang:true,allowReturnOutsideFunction:!module})
      return {status:0,stdout:'',stderr:''}
    } catch(error) {
      syntax.push({file:path.relative(root,file),module,error:error.message})
      return {status:1,stdout:'',stderr:error.message}
    }
  }
  if (args.length === 4 && args[0] === '--experimental-import-meta-resolve' && args[1] === '--input-type=module' && args[2] === '--eval' && typeof options?.input === 'string') {
    // Match the fixed, reviewed resolver helper. Do not evaluate its code string.
    if (!args[3].includes("createRequire(file).resolve(specifier)") || !args[3].includes('import.meta.resolve(specifier,pathToFileURL(file).href)')) throw new Error('unexpected resolver helper')
    calls.resolverBatches++
    const refs = JSON.parse(options.input)
    const targets = refs.map(ref => {
      let target = null, error
      try {
        const resolved = ref.mode === 'require' ? createRequire(ref.file).resolve(ref.specifier) : fileURLToPath(import.meta.resolve(ref.specifier,pathToFileURL(ref.file).href))
        if (fs.statSync(resolved).isFile()) target = resolved
      } catch(e) {error=e.code??e.message}
      resolutions.push({...ref,target,error})
      return target
    })
    return {status:0,stdout:JSON.stringify(targets),stderr:''}
  }
  calls.rejectedProcessRequests++
  throw new Error('unapproved process request')
}
syncBuiltinESMExports()
const {auditProductBoundary} = await import(pathToFileURL(checker))
const result = auditProductBoundary(root)
hook.deregister()
const graph = result._graph.map(([from,targets]) => [path.relative(root,from), targets.map(file => path.relative(root,file))])
const trail = Object.fromEntries(result._trails.map(([file,files]) => [path.relative(root,file),files.map(file=>path.relative(root,file))]))
const manifestFiles = result._manifests
const manifests = manifestFiles.map(file=>({file:path.relative(root,file),...JSON.parse(fs.readFileSync(file,'utf8'))}))
const sourceFiles = result._sources.map(file=>path.relative(root,file))
const seen = result._seen.map(file=>path.relative(root,file))
const closureStates = result._closureStates.map(([file,status])=>[path.relative(root,file),status])
for (const key of ['_graph','_sources','_seen','_manifests','_closureStates','_trails']) delete result[key]
const write = (name,data) => fs.writeFileSync(path.join(output,name),JSON.stringify(data,null,2)+'\n',{flag:'wx'})
write('diagnostic.json',result)
write('closure.json',{graph,trail,sourceFiles,seen,manifests,closureStates,resolutions:resolutions.map(ref=>({...ref,file:path.relative(root,ref.file),target:ref.target?path.relative(root,ref.target):null,typeTarget:ref.typeTarget?path.relative(root,ref.typeTarget):undefined}))})
const rows = [...inputs.values()].sort((a,b)=>a.path.localeCompare(b.path))
const drift = []
for (const before of rows) {
  const file = path.join(root,before.path), bytes = rawRead(file), stat=fs.lstatSync(file,{bigint:true})
  if (sha(bytes)!==before.sha256 || String(stat.mtimeNs)!==before.mtimeNs || Number(stat.mode&0o7777n).toString(8)!==before.mode || String(stat.size)!==before.size) drift.push(before.path)
}
write('inputs.json',{source:root,files:rows,inventorySha256:sha(JSON.stringify(rows)),drift})
write('method.json',{node:process.version,execPath:process.execPath,exactCheckerExecution:false,method:'checker algorithm with read-only in-process Node22 resolution and Acorn syntax AST substitutes, plus graph observation only; checker bytes on disk unchanged',checkerSha256:sha(originalCheckerBytes),tsVersion:ts.version,acornVersion:acorn.version,environmentKeys:Object.keys(process.env).sort(),calls,syntaxErrors:syntax,actualDescendants:0,sourcePayloadsExecuted:0,preservation:{files:rows.length,drift}})
const byReason={}
for (const row of result.diagnostics) byReason[row.reason]=(byReason[row.reason]??0)+1
console.log(JSON.stringify({status:result.status,sourceFiles:result.sourceFiles,coreFiles:result.coreFiles,workspaceCount:result.workspaceCount,edgeCount:result.edgeCount,violations:result.violations.length,diagnostics:result.diagnostics.length,byReason,preservationFiles:rows.length,drift,method:calls,syntaxErrors:syntax.length},null,2))
