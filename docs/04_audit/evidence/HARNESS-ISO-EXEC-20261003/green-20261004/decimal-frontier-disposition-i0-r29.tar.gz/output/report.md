# I0 decimal frontier proposed dispositions

PROPOSED_DISPOSITIONS_ONLY_NOT_FRONTIER_ACCEPTANCE. No frontier acceptance is issued.

Exactly **1,072 observations** are retained (536 per physical variant), including 384 duplicate file/line observations. There are 688 exact file/line bindings. Node v22.23.2, built-in Acorn 8.16.0, offline AST only; no target execution, imports, payloads, network, installation or source mutation.

## Physical sources

- node_modules/decimal.js/decimal.js: SHA-256 `6e99821f8204c5f611b56077e3fce056a1562d22bc341a1f4af01afe7e527d83`; 536 rows, 344 lines, 15473 AST nodes, 166 new expressions, 49 constructor members.
- node_modules/decimal.js/decimal.mjs: SHA-256 `45e6ecc0a500fee6439acdf67ee2e9322aab57e6ea0409ef52993dedbba8cf19`; 536 rows, 344 lines, 15353 AST nodes, 166 new expressions, 49 constructor members.

Authority designates the immutable R22 candidate. Both current files have nlink 1; historical original48link lineage needs its authority-owned digest manifest. The read-set records before/after bytes and metadata.

## Proposed observation-line classifications

| Classification | Rows |
| --- | ---: |
| UNRESOLVED_CONSTRUCTOR_IDENTITY_AT_INVOCATION_LINE | 268 |
| PROPOSED_EXPRESSION_DATA_USE | 732 |
| UNRESOLVED_CONSTRUCTOR_TRANSFER_LINE | 56 |
| PROPOSED_OWN_CONSTRUCTOR_DATA_REFERENCE | 6 |
| PROPOSED_OWN_NUMERIC_CONSTRUCTOR_ROUTE | 6 |
| PROPOSED_OWN_NUMERIC_CONSTRUCTOR_ASSIGNMENT | 4 |

These are **whole-line proposals**, with set-valued AST candidates retained for every duplicate. The source observations contain no column, token identity or scanner traversal trace. A mixed line can contain both numeric data and an unresolved constructor capability; duplicate order is not claimed as token order. Each row links a line hash, exact AST candidate spans, containing function, assignments, caller edges and finite proof groups.

## Producer and caller evidence

- **F_OWN_PRODUCER (STATIC_PRODUCER_IDENTITY)**: Both physical files define Decimal(v) inside clone(obj), assign each x.constructor to the inner lexical Decimal, attach P as prototype, and return that constructor. The body represents numeric values as s/e/d and routes primitive strings to local decimal/base parsers, not an evaluator or loader.
- **F_OWN_PARSE_ROUTE (STATIC_LOCAL_CALLER_CLOSURE)**: parseOther has exactly one lexical caller, the inner Decimal primitive-string branch. parseDecimal callers are inner Decimal and parseOther. Their constructor uses can be bound to the own assignment before parser entry; parseOther transfers that own Ctor to intPow. No universal sandbox obligation is used.
- **F_RECEIVER_TRANSFER (UNRESOLVED_CAPABILITY_IDENTITY)**: Public P methods invoke receiver.constructor or Ctor read from it; exported static methods invoke new this. Prototype/static assignments establish normal own numeric routes but do not restrict their receivers. Internal helper arguments from those routes retain unresolved constructor identity.
- **F_DATA (STATIC_EXPRESSION_ROLE_ONLY)**: Many diagnostics concern numeric settings, arithmetic, comparison, indexes, or formatting. Those expressions are not evaluator or loader invocation AST nodes. Reclassifying a data expression does not clear a separate constructor invocation/transfer on a mixed line or prove an arbitrary property receiver has trusted origin.
- **F_ENTRIES (STATIC_PHYSICAL_ENTRY_DIFFERENCE)**: UMD: AMD define callback precedes CJS module.exports and global/noConflict fallback. ESM: named Decimal = P.constructor = clone(DEFAULTS), then default export, with direct Symbol inspection assignments. External AMD define identity and actual host branch selection are not established.
- **F_ROWS (EXACT_LINE_BINDING_TOKEN_IDENTITY_UNRESOLVED)**: All 1072 rows retain original diagnosticIndex and observation fields, with canonical row hashes. All 688 unique file/line observations have exact physical hash/span, raw AST candidates and containing-function graph. The 384 extra duplicate observations are retained; no scanner-token identity is invented from their ordinal.
- **F_LINEAGE (AUTHORITY_DESIGNATED_PHYSICAL_SOURCE_HASHED)**: Runtime bytes are taken only from authority.sourceReadonly and hashed. Current physical files have nlink 1. Historical original48link lineage is not independently certified without its trusted digest manifest.

The own numeric constructor claim is about this local producer and its primitive-string parsing route. It does not assert callback-free behavior for tag-compatible objects: isDecimalInstance accepts obj.toStringTag === tag, and the copy path calls v.d.slice(). Public receiver.constructor reads and new this sites remain unresolved until their specific producer/caller chain is known.

## Reviewable evidence

- [proposed-dispositions.json](proposed-dispositions.json): all 1072 exact original rows and duplicate ordinals.
- [line-bindings.json](line-bindings.json): exact source line spans/hashes plus candidate AST/token identities.
- [shared-proofs.json](shared-proofs.json), [evidence-nodes.json](evidence-nodes.json): finite proof groups and exact snippets, UTF-16/byte offsets, physical hashes.
- [function-caller-assignment-graphs.json](function-caller-assignment-graphs.json): every local function, assignment, actual invocation and conditional member route.
- [constructor-sites.json](constructor-sites.json), [entry-exports.json](entry-exports.json): both physical variants, all new expressions and constructor members, export branches.
- umd/esm.raw-ast.json, .ast-index.json, .tokens-comments.json: complete parsed source evidence.
- [read-set-integrity.json](read-set-integrity.json): bounded read-set hashes, metadata and drift checks.
- [missing-evidence.json](missing-evidence.json): finite missing evidence; no arbitrary-JavaScript sandbox obligation.

## Concrete missing evidence

- **M_ROW_TOKEN**: Original observations have only file:line and reason; no columns, AST offsets, token identities, scanner rule, or scanner traversal trace. Next: Reviewer can compare the retained same-line candidate spans with original scanner offsets/trace if those are supplied. No duplicate-to-token ordinal is asserted.
- **M_PUBLIC_RECEIVER**: At these actual exported entry points, the two-file AST does not bind every possible invocation receiver to clone-returned Decimal or preserve its constructor field. Public method assignments and new this / this.constructor contain no identity check. Next: For a concrete consumer route, provide its caller AST and receiver/constructor assignment chain, or a specific constructor identity guard. No general JavaScript sandbox proof is required.
- **M_HELPER_ARGUMENT**: A closed local caller graph exists, but one or more incoming paths carry constructor values obtained from unvalidated public this / x.constructor. The local parameter name Ctor is not itself identity evidence. Next: Resolve the specific incoming public receiver binding or retain that constructor-transfer edge as unresolved.
- **M_AMD_DEFINE**: typeof define === function and define.amd do not identify the actual external define implementation; its AST is outside the two-file scope. Next: Review the actual selected AMD define binding and loader implementation if this branch is used. The callback body itself returns the local Decimal.
- **M_HOST_ROUTING**: The files expose conditional UMD branches and ESM exports, but no host branch-selection/caller evidence is supplied inside this scope. Next: Select only the physical entry and branch used by a concrete consumer when adjudicating host capability.
- **M_INPUT_METHOD**: isDecimalInstance accepts obj.toStringTag === tag; the object-copy constructor path calls v.d.slice(). That supplied method implementation is not established by the two-file AST. Next: Restrict the claim to the own numeric constructor producer, or supply the particular input-object producer and slice binding when claiming callback-free behavior.
- **M_HISTORICAL_LINK**: Authority designates R22 candidate as the immutable source; observed runtime file nlink is 1, not 48. No independently trusted original48link file-digest manifest is supplied in this packet. Next: Compare the recorded physical source SHA-256 values to the authority-owned original48link manifest. Do not infer historical lineage from a pathname or current nlink.

Next action: Independent adjudicator reviews these proposed row/line classifications against supplied scanner token evidence and any concrete receiver/AMD caller bindings; unresolved capabilities remain unresolved.
