'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const acorn = require('internal/deps/acorn/acorn/dist/acorn');
if (process.versions.node.split('.')[0] !== '22') throw Error('Node22 required');
const packet = '/home/ricardo/.cache/cvg-harness-green-20261004/decimal-frontier-disposition-r29';
const out = path.join(packet, 'output');
const sha = v => crypto.createHash('sha256').update(v).digest('hex');
const reads = [];
function read(p, role) {
  const buf = fs.readFileSync(p), s = fs.statSync(p);
  reads.push({path:p, realpath:fs.realpathSync(p), role, bytes:buf.length, sha256:sha(buf), device:s.dev, inode:s.ino, hardlinks:s.nlink, mode:s.mode, mtimeMs:s.mtimeMs});
  return buf;
}
function write(p,v) { fs.writeFileSync(path.join(out,p), JSON.stringify(v,null,2)+'\n'); }
const authority = JSON.parse(read(path.join(packet,'authority.json'),'authority'));
const observations = JSON.parse(read(path.join(packet,'observations.json'),'original observations'));
if (authority.write !== out || observations.length !== 1072) throw Error('authority/row cardinality mismatch');
read(__filename,'analysis implementation');
read(path.join(out,'scope-plan.json'),'frozen scope');
read(process.execPath,'generic Node22 executable containing bundled Acorn');
for(const p of ['/home/ricardo/.agents/skills/engineering-framework/SKILL.md','/home/ricardo/.agents/skills/engineering-framework/references/13-audit-evolution.md','/home/ricardo/.agents/skills/engineering-framework/references/09-verification-quality.md'])read(p,'generic bootstrap skill (hash baseline starts at analysis, not earlier discovery read)');
const files = ['node_modules/decimal.js/decimal.js','node_modules/decimal.js/decimal.mjs'];
const models = [];
for (const rel of files) {
  const buf=read(path.join(authority.sourceReadonly,rel),'runtime source as data only'), src=buf.toString('utf8'), hash=sha(buf);
  const comments=[], tokens=[];
  const ast=acorn.parse(src,{ecmaVersion:'latest',sourceType:rel.endsWith('.mjs')?'module':'script',locations:true,ranges:true,onComment:comments,onToken:tokens});
  const nodes=[], parent=new Map(), owner=new Map(), functions=[], calls=[], assignments=[], returns=[], ctorMembers=[], exports=[];
  function walk(n,p,fn) {
    if (!n || typeof n.type!=='string') return;
    parent.set(n,p);
    if (/^(FunctionDeclaration|FunctionExpression|ArrowFunctionExpression)$/.test(n.type)) {functions.push(n); fn=n;}
    owner.set(n,fn);nodes.push(n);
    if (n.type==='CallExpression' || n.type==='NewExpression') calls.push(n);
    if (n.type==='AssignmentExpression'||n.type==='VariableDeclarator') assignments.push(n);
    if (n.type==='ReturnStatement') returns.push(n);
    if(n.type==='MemberExpression' && ((!n.computed && n.property.name==='constructor')||(n.computed && n.property.value==='constructor'))) ctorMembers.push(n);
    if(n.type.startsWith('Export')||n.type.startsWith('Import')) exports.push(n);
    for (const [k,v] of Object.entries(n)) {
      if(['loc','range','start','end'].includes(k))continue;
      if(Array.isArray(v))v.forEach(c=>walk(c,n,fn)); else if(v && typeof v.type==='string')walk(v,n,fn);
    }
  }
  walk(ast,null,null);
  const prefix=rel.endsWith('.mjs')?'esm':'umd';
  const id=n=>n?`${prefix}:${n.type}:${n.start}:${n.end}`:null;
  const text=n=>n?src.slice(n.start,n.end):null;
  function desc(n,includeSnippet=true) {
    if(!n)return null;
    return {id:id(n),file:rel,fileSha256:hash,type:n.type,start:n.start,end:n.end,byteStart:Buffer.byteLength(src.slice(0,n.start)),byteEnd:Buffer.byteLength(src.slice(0,n.end)),loc:n.loc,snippetSha256:sha(text(n)),...(includeSnippet?{snippet:text(n)}:{})};
  }
  function functionNames(f) {
    const names=[];
    if(f.id)names.push(f.id.name);
    let n=f,p=parent.get(n);
    while(p?.type==='AssignmentExpression' && p.right===n){names.push(text(p.left));n=p;p=parent.get(n);}
    if(p?.type==='VariableDeclarator' && p.init===n)names.push(text(p.id));
    if(!names.length && f===functions[0] && prefix==='umd') names.push('<UMD IIFE>');
    if(!names.length)names.push(`<anonymous@${f.loc.start.line}>`);
    return names;
  }
  const fnRecords=functions.map(f=>({ ...desc(f,false),names:functionNames(f),params:f.params.map(text),parentFunction:id(owner.get(parent.get(f))),assignments:assignments.filter(n=>owner.get(n)===f).map(n=>({...desc(n),target:text(n.left||n.id),value:text(n.right||n.init)})),returns:returns.filter(n=>owner.get(n)===f).map(n=>desc(n))}));
  const callRecords=calls.map(c=>({...desc(c),callee:desc(c.callee),arguments:c.arguments.map(n=>desc(n)),ownerFunction:id(owner.get(c))}));
  const assignmentRecords=assignments.map(n=>({...desc(n),target:text(n.left||n.id),value:text(n.right||n.init),ownerFunction:id(owner.get(n))}));
  const ctorRecords=ctorMembers.map(n=>({...desc(n),parent:desc(parent.get(n)),ownerFunction:id(owner.get(n))}));
  write(prefix+'.raw-ast.json',ast);
  write(prefix+'.tokens-comments.json',{file:rel,fileSha256:hash,tokens:tokens.map(t=>({type:t.type.label,value:t.value,start:t.start,end:t.end,loc:t.loc})),comments});
  write(prefix+'.ast-index.json',{file:rel,fileSha256:hash,nodeCount:nodes.length,functions:fnRecords,calls:callRecords,assignments:assignmentRecords,constructorMembers:ctorRecords,exports:exports.map(n=>desc(n))});
  models.push({rel,prefix,buf,src,hash,ast,nodes,parent,owner,functions,calls,assignments,returns,ctorMembers,exports,id,text,desc,functionNames,fnRecords,callRecords,assignmentRecords,ctorRecords});
}
// All subsequent operations analyze parsed nodes and source slices, never target execution.
const evidence=[], proofs=[], functionGraphs=[], constructorSites=[], exportPaths=[], lineBindings=[], dispositions=[], defUseGraphs=[];
const graphByFile=new Map();
const missingEvidence=[
  {id:'M_ROW_TOKEN',scope:'all observations',missing:'Original observations have only file:line and reason; no columns, AST offsets, token identities, scanner rule, or scanner traversal trace.',next:'Reviewer can compare the retained same-line candidate spans with original scanner offsets/trace if those are supplied. No duplicate-to-token ordinal is asserted.'},
  {id:'M_PUBLIC_RECEIVER',scope:'public prototype and static constructor receivers',missing:'At these actual exported entry points, the two-file AST does not bind every possible invocation receiver to clone-returned Decimal or preserve its constructor field. Public method assignments and new this / this.constructor contain no identity check.',next:'For a concrete consumer route, provide its caller AST and receiver/constructor assignment chain, or a specific constructor identity guard. No general JavaScript sandbox proof is required.'},
  {id:'M_HELPER_ARGUMENT',scope:'helper arguments sourced from public receiver constructor',missing:'A closed local caller graph exists, but one or more incoming paths carry constructor values obtained from unvalidated public this / x.constructor. The local parameter name Ctor is not itself identity evidence.',next:'Resolve the specific incoming public receiver binding or retain that constructor-transfer edge as unresolved.'},
  {id:'M_AMD_DEFINE',scope:'decimal.js AMD branch only',missing:'typeof define === function and define.amd do not identify the actual external define implementation; its AST is outside the two-file scope.',next:'Review the actual selected AMD define binding and loader implementation if this branch is used. The callback body itself returns the local Decimal.'},
  {id:'M_HOST_ROUTING',scope:'entry selection',missing:'The files expose conditional UMD branches and ESM exports, but no host branch-selection/caller evidence is supplied inside this scope.',next:'Select only the physical entry and branch used by a concrete consumer when adjudicating host capability.'},
  {id:'M_INPUT_METHOD',scope:'tag-compatible object copy path',missing:'isDecimalInstance accepts obj.toStringTag === tag; the object-copy constructor path calls v.d.slice(). That supplied method implementation is not established by the two-file AST.',next:'Restrict the claim to the own numeric constructor producer, or supply the particular input-object producer and slice binding when claiming callback-free behavior.'},
  {id:'M_HISTORICAL_LINK',scope:'original48link provenance',missing:'Authority designates R22 candidate as the immutable source; observed runtime file nlink is 1, not 48. No independently trusted original48link file-digest manifest is supplied in this packet.',next:'Compare the recorded physical source SHA-256 values to the authority-owned original48link manifest. Do not infer historical lineage from a pathname or current nlink.'}
];
for(const m of models){
  const {nodes,parent,owner,functions,calls,assignments,ctorMembers,exports,id,text,desc,functionNames}=m;
  const evMap=new Map();
  function ev(n) {if(!n)return null;const k=id(n);if(!evMap.has(k)){const r=desc(n);evMap.set(k,r);evidence.push(r);}return k;}
  const enclosing=f=>owner.get(parent.get(f))||null;
  const fnById=new Map(functions.map(f=>[id(f),f]));
  const nameScopes=new Map();
  const declVarScopes=new Map();
  function mapFor(map,s){if(!map.has(s))map.set(s,new Map());return map.get(s);}
  for(const f of functions)if(f.id)mapFor(nameScopes,enclosing(f)).set(f.id.name,f);
  for(const a of assignments)if(a.type==='VariableDeclarator'&&a.id.type==='Identifier')mapFor(declVarScopes,owner.get(a)||null).set(a.id.name,a);
  function lookup(map,scope,name){let s=scope;while(true){const v=map.get(s)?.get(name);if(v)return v;if(!s)return null;s=enclosing(s);}}
  const aliases=new Map();
  for(const f of functions)for(const n of functionNames(f))if(n!==f.id?.name)aliases.set(n,f);
  // Resolve the actual divide = (function(){... return function(...) {...};})() assignment.
  for(const a of assignments){const r=a.right||a.init,t=a.left||a.id;
    if(r?.type==='CallExpression'&&r.callee.type==='FunctionExpression'){
      const returned=m.returns.filter(n=>owner.get(n)===r.callee&&n.argument?.type==='FunctionExpression');
      if(returned.length===1)aliases.set(text(t),returned[0].argument);
    }
  }
  function resolveIdentifier(name,fn){return lookup(nameScopes,fn,name)||aliases.get(name)||null;}
  const staticBindings=assignments.filter(a=>a.type==='AssignmentExpression'&&a.left.type==='MemberExpression'&&text(a.left.object)==='Decimal'&&a.right.type==='Identifier').map(a=>({assignment:ev(a),method:a.left.computed?String(a.left.property.value):a.left.property.name,target:resolveIdentifier(a.right.name,owner.get(a)),targetName:a.right.name}));
  const pMethods=new Map();
  for(const f of functions)for(const name of functionNames(f))if(name.startsWith('P.'))pMethods.set(name.slice(2),f);
  const edges=[];
  for(const c of calls){const cal=text(c.callee),fn=owner.get(c)||null;let target=null,status='DYNAMIC_OR_HOST_MEMBER';
    if(c.callee.type==='Identifier'){target=resolveIdentifier(c.callee.name,fn);if(target)status='LEXICAL_LOCAL_FUNCTION';else status='UNBOUND_OR_DATA_IDENTIFIER';}
    else if(c.callee.type==='FunctionExpression'){target=c.callee;status='LOCAL_IIFE';}
    else if(c.callee.type==='MemberExpression'){
      const prop=c.callee.computed?c.callee.property.value:c.callee.property.name,obj=text(c.callee.object);
      if(prop==='call'||prop==='apply'){
        const base=c.callee.object;
        if(base.type==='Identifier'){target=resolveIdentifier(base.name,fn);if(target)status='LOCAL_FUNCTION_EXPLICIT_RECEIVER';}
      }
      if(!target&&obj==='Decimal') {target=staticBindings.find(b=>b.method===prop)?.target||null;if(target)status='EXPORTED_STATIC_PROPERTY_ROUTE_CONDITIONAL';}
      if(!target&&pMethods.has(prop)){target=pMethods.get(prop);status='PROTOTYPE_MEMBER_NAME_ROUTE_CONDITIONAL';}
    }
    edges.push({id:ev(c),callerFunction:id(fn),callee:ev(c.callee),calleeText:cal,arguments:c.arguments.map(ev),targetFunction:id(target),resolution:status,assumption:status.includes('CONDITIONAL')?'Property name matches an installed method; this does not prove the runtime receiver or unmodified property identity.':null});
  }
  // Scope-resolved constructor sources, with the actual argument edges retained.
  function ctorSource(callee,fn,seen=new Set()){
    if(!callee)return {kind:'UNKNOWN',missing:['M_PUBLIC_RECEIVER']};
    if(callee.type==='ThisExpression')return {kind:'EXPORTED_STATIC_THIS',missing:['M_PUBLIC_RECEIVER']};
    if(callee.type==='MemberExpression'&&((!callee.computed&&callee.property.name==='constructor')||(callee.computed&&callee.property.value==='constructor'))){
      const obj=callee.object;
      let producer=null;
      if(obj.type==='Identifier')producer=lookup(declVarScopes,fn,obj.name);
      return {kind:'RECEIVER_CONSTRUCTOR_MEMBER',member:ev(callee),receiver:ev(obj),receiverDeclaration:ev(producer),receiverInitializer:producer?.init?text(producer.init):null,missing:['M_PUBLIC_RECEIVER']};
    }
    if(callee.type==='Identifier'){
      const name=callee.name,key=id(fn)+':'+name;if(seen.has(key))return {kind:'CYCLE',missing:['M_HELPER_ARGUMENT']};seen.add(key);
      const resolved=resolveIdentifier(name,fn);
      if(name==='Decimal'&&resolved&&enclosing(resolved)&&functionNames(enclosing(resolved)).includes('clone'))return {kind:'OWN_LEXICAL_DECIMAL',producer:ev(resolved),missing:[]};
      const declaration=lookup(declVarScopes,fn,name);
      if(declaration?.init){
        let init=declaration.init;while(init?.type==='AssignmentExpression')init=init.right;
        if(name==='Decimal'&&init.type==='CallExpression'&&init.callee.name==='clone')return {kind:'OWN_CLONE_RESULT',producer:ev(declaration),cloneCall:ev(init),missing:[]};
        const rhs=declaration.init;
        if(rhs.type==='MemberExpression'&&text(rhs).endsWith('.constructor'))return {...ctorSource(rhs,owner.get(declaration),seen),aliasDeclaration:ev(declaration)};
      }
      // Outer Decimal is initialized by the concrete clone(DEFAULTS) assignment (UMD var has no init).
      if(name==='Decimal'){
        const init=assignments.find(a=>a.type==='AssignmentExpression'&&text(a.left)==='Decimal'&&a.right.type==='CallExpression'&&a.right.callee.name==='clone');
        if(init)return {kind:'OWN_CLONE_RESULT',producer:ev(init),missing:[]};
      }
      if(fn?.params.some(p=>p.type==='Identifier'&&p.name===name))return {kind:'TRANSFERRED_PARAMETER',parameter:ev(fn.params.find(p=>p.name===name)),incomingCalls:edges.filter(e=>e.targetFunction===id(fn)).map(e=>e.id),missing:['M_HELPER_ARGUMENT']};
      const writes=assignments.filter(a=>owner.get(a)===fn&&a.type==='AssignmentExpression'&&text(a.left)===name&&a.right.type==='MemberExpression'&&text(a.right).endsWith('.constructor'));
      if(writes.length)return {...ctorSource(writes[0].right,fn,seen),aliasAssignments:writes.map(ev)};
    }
    return {kind:'UNRESOLVED_CALLEE',callee:ev(callee),missing:['M_PUBLIC_RECEIVER']};
  }
  const clone=functions.find(f=>f.id?.name==='clone'), decimal=functions.find(f=>f.id?.name==='Decimal'&&enclosing(f)===clone);
  const parseOther=functions.find(f=>f.id?.name==='parseOther'), parseDecimal=functions.find(f=>f.id?.name==='parseDecimal');
  const ownCtorAssign=assignments.find(a=>owner.get(a)===decimal&&text(a.left)==='x.constructor'&&text(a.right)==='Decimal');
  const ownParseOtherEdges=edges.filter(e=>e.targetFunction===id(parseOther));
  if(ownParseOtherEdges.length!==1 || ownParseOtherEdges[0].callerFunction!==id(decimal))throw Error('parseOther own caller proof changed');
  const ownParseDecimalEdges=edges.filter(e=>e.targetFunction===id(parseDecimal));
  if(ownParseDecimalEdges.some(e=>![id(decimal),id(parseOther)].includes(e.callerFunction)))throw Error('parseDecimal caller closure changed');
  const ctorWrites=assignments.filter(a=>a.type==='AssignmentExpression'&&a.left.type==='MemberExpression'&&((!a.left.computed&&a.left.property.name==='constructor')||(a.left.computed&&a.left.property.value==='constructor')));
  const initAssignments=assignments.filter(a=>a.type==='AssignmentExpression'&&(/^(Decimal(?:\.prototype(?:\.constructor)?|\['default'\]|\.Decimal)?|P\.constructor|LN10|PI)$/.test(text(a.left))));
  const groupOwn=`${m.prefix}:G_OWN_NUMERIC_PRODUCER`,groupReceiver=`${m.prefix}:G_PUBLIC_RECEIVER_UNKNOWN`,groupData=`${m.prefix}:G_DATA_USE`,groupParse=`${m.prefix}:G_OWN_PARSE_ROUTE`,groupExport=`${m.prefix}:G_ENTRY_EXPORTS`;
  const config=functions.find(f=>f.id?.name==='config'), instance=functions.find(f=>f.id?.name==='isDecimalInstance');
  proofs.push({id:groupOwn,classification:'PROPOSED_OWN_NUMERIC_CONSTRUCTOR_PRODUCER',file:m.rel,fileSha256:m.hash,producerFunction:ev(decimal),factoryFunction:ev(clone),producerReturns:m.returns.filter(n=>owner.get(n)===clone).map(ev),ownConstructorAssignment:ev(ownCtorAssign),prototypeAssignments:assignments.filter(a=>text(a.left)==='Decimal.prototype').map(ev),initializationAssignments:initAssignments.map(ev),configurationFunction:ev(config),instanceRecognition:ev(instance),constructorBodyCalls:edges.filter(e=>e.callerFunction===id(decimal)),claims:['clone declares a fresh lexical function Decimal(v) and returns that function; no argument-supplied function is returned as the constructor.', 'The local body constructs numeric s/e/d representations or throws. Strings take parseDecimal/parseOther; they are not evaluated or loaded as code.', 'The instance constructor field is explicitly assigned that inner Decimal before parsing.', 'This is producer identity evidence, not a guarantee that all receivers, object-copy callbacks, or host implementations are that producer.'],limitations:['M_INPUT_METHOD']});
  proofs.push({id:groupParse,classification:'PROPOSED_OWN_NUMERIC_INTERNAL_ROUTE',file:m.rel,fileSha256:m.hash,producerGroup:groupOwn,parseOther:ev(parseOther),parseDecimal:ev(parseDecimal),incomingParseOther:ownParseOtherEdges,incomingParseDecimal:ownParseDecimalEdges,constructorAssignment:ev(ownCtorAssign),parseOtherConstructorReadAssignments:assignments.filter(a=>owner.get(a)===parseOther&&text(a.left||a.id)==='Ctor').map(ev),claims:['The only lexical parseOther caller is the inner Decimal, passing its x after x.constructor = Decimal, on the primitive-string branch.', 'parseDecimal has only inner Decimal and parseOther lexical callers; both carry the newly constructed local x.', 'No constructor write occurs in either parser before their constructor reads; their call sites are retained in the graph.', 'The primitive-string branch parses numbers/base notation, never passes the numeric string to a known evaluator or loader.'],assumptions:['Ordinary language and intrinsic string/regex operations; no claim about universally hostile redefinition of JavaScript intrinsics.'],missing:[]});
  proofs.push({id:groupReceiver,classification:'UNRESOLVED_PUBLIC_RECEIVER_CONSTRUCTOR_IDENTITY',file:m.rel,fileSha256:m.hash,producerGroup:groupOwn,exportGroup:groupExport,ownFieldWrites:ctorWrites.map(ev),publicPrototypeMethods:[...pMethods.entries()].map(([name,f])=>({name,function:ev(f)})),staticBindings:staticBindings.map(b=>({...b,target:id(b.target)})),claims:['The normal receiver route can use the own constructor set by Decimal; the AST also exports its prototype and methods.', 'Public prototype methods read this.constructor (often via x = this / arg = this); static methods construct new this. These actual call sites do not validate constructor identity.', 'Ctor passed into helpers preserves the incoming function capability; naming it Ctor does not convert an arbitrary supplied function into the own producer.'],missing:['M_PUBLIC_RECEIVER','M_HELPER_ARGUMENT']});
  proofs.push({id:groupData,classification:'PROPOSED_DATA_OR_CONFIG_USE_AT_EXPRESSION',file:m.rel,fileSha256:m.hash,claims:['Precision, rounding, exponent, digit-index, scalar arithmetic, formatting and comparisons are data/configuration uses when the exact AST node is not in callee position or a constructor-transfer argument.', 'A .constructor/.precision read or assignment is not syntactically an evaluator invocation. This does not clear separate new Ctor / new this.constructor sinks.', 'config restricts its copied keys to named numeric settings and boolean crypto; it does not accept constructor/evaluator/loader code as a configuration value.'],config:ev(config),missing:['M_ROW_TOKEN'],limitations:['For mutable external receivers, data/property origin is not established merely from an arithmetic-use AST; this group makes only expression-role claims.']});
  const exportNodes=[...exports,...assignments.filter(a=>a.type==='AssignmentExpression'&&(/^(module\.exports|globalScope\.Decimal|Decimal(?:\.noConflict|\.Decimal|\['default'\])|P\.constructor|Decimal\.prototype\.constructor)$/.test(text(a.left)))),...calls.filter(c=>text(c.callee)==='define')];
  const branchNodes=nodes.filter(n=>n.type==='IfStatement'&&((text(n.test).includes('define')&&text(n.test).includes('amd'))||text(n.test).includes('module.exports')||text(n.test).includes('globalScope')));
  const ep={id:groupExport,file:m.rel,fileSha256:m.hash,entryType:m.prefix==='umd'?'UMD script: IIFE called with outer this; AMD precedes CJS precedes global fallback':'ESM module: named Decimal and default Decimal; no UMD branch',nodes:exportNodes.map(ev),conditions:branchNodes.map(ev),loaderCalls:calls.filter(c=>text(c.callee)==='define'||/^(eval|Function|require|import)$/.test(text(c.callee))).map(ev),importDeclarations:exports.filter(n=>n.type==='ImportDeclaration'||n.type==='ImportExpression').map(ev),claims:m.prefix==='umd'?['AMD: typeof define == function && define.amd; define receives a locally declared callback returning Decimal. External define implementation unresolved.', 'CJS: typeof module != undefined && module.exports; module.exports receives clone-produced Decimal, with Decimal.default / Decimal.Decimal self aliases.', 'Global fallback: choose self or window only if globalScope falsy; save old globalScope.Decimal, install own Decimal, and noConflict restores old value without invoking it.']:['Named export var Decimal = P.constructor = clone(DEFAULTS); default export Decimal.', 'This physical variant directly uses Symbol.for and Symbol.toStringTag; UMD guards Symbol before its custom inspection assignment.', 'No syntactic import/require/eval/Function constructor appears in this module.'],missing:m.prefix==='umd'?['M_AMD_DEFINE','M_HOST_ROUTING']:['M_HOST_ROUTING']};
  proofs.push({...ep,classification:'PROPOSED_ENTRY_EXPORT_AND_HOST_BOUNDARY'});exportPaths.push(ep);
  const graphs=[];
  const programGraph={id:`${m.prefix}:FG:PROGRAM`,function:ev(m.ast),names:['<physical entry program>'],params:[],enclosingFunction:null,localAssignments:assignments.filter(a=>!owner.get(a)).map(ev),constructorOrigins:[],thisAliases:[],incomingCallEdges:[],outgoingCallEdges:edges.filter(e=>!e.callerFunction),exportedBindings:exportNodes.map(ev),exportGroup:groupExport,producerGroup:groupOwn,publicReceiverGroup:groupReceiver,externalEntry:true,incomingLimit:'Physical script/module entry; selected host loader/caller is outside scope.'};
  graphs.push(programGraph);functionGraphs.push(programGraph);
  for(const f of functions){
    const fid=id(f),locals=assignments.filter(a=>owner.get(a)===f),incoming=edges.filter(e=>e.targetFunction===fid),ownNames=functionNames(f);
    const bindings=assignments.filter(a=>a.type==='AssignmentExpression'&&a.left.type==='MemberExpression'&&(a.right===f||a.right.type==='Identifier'&&resolveIdentifier(a.right.name,owner.get(a))===f));
    const ctorOrigins=locals.filter(a=>text(a.left||a.id)==='Ctor'||(a.right||a.init)?.type==='MemberExpression'&&text(a.right||a.init).endsWith('.constructor'));
    const thisAliases=locals.filter(a=>text(a.right||a.init)==='this');
    const g={id:`${m.prefix}:FG:${f.start}`,function:ev(f),names:ownNames,params:f.params.map(ev),enclosingFunction:id(enclosing(f)),localAssignments:locals.map(ev),constructorOrigins:ctorOrigins.map(ev),thisAliases:thisAliases.map(ev),incomingCallEdges:incoming,outgoingCallEdges:edges.filter(e=>e.callerFunction===fid),exportedBindings:bindings.map(ev),exportGroup:groupExport,producerGroup:groupOwn,publicReceiverGroup:groupReceiver,publicPrototypeMethod:ownNames.some(n=>n.startsWith('P.')),exportedStaticMethod:staticBindings.some(b=>b.target===f),externalEntry:m.prefix==='umd'&&f===functions[0],incomingLimit:'Lexical identifier callers are resolved in local function scope. Member routes are conditional name matches; exported methods can also have out-of-scope callers.'};
    graphs.push(g);functionGraphs.push(g);
  }
  // Exact lexical def/use inventory. It is a binding graph, not path-sensitive execution.
  function bindingFor(name,fn){
    let s=fn;
    while(true){
      const param=s?.params.find(p=>p.type==='Identifier'&&p.name===name);
      if(param)return {kind:'PARAMETER',node:ev(param),scopeFunction:id(s),scope:s};
      const v=declVarScopes.get(s)?.get(name);if(v)return {kind:'VARIABLE_DECLARATION',node:ev(v),scopeFunction:id(s),scope:s};
      const f=nameScopes.get(s)?.get(name);if(f)return {kind:'FUNCTION_DECLARATION',node:ev(f),scopeFunction:id(s),scope:s};
      if(!s)break;s=enclosing(s);
    }
    return {kind:'HOST_OR_UNRESOLVED_FREE_BINDING',node:null,scopeFunction:null,scope:null};
  }
  const identifiers=nodes.filter(n=>n.type==='Identifier').map(n=>{
    const p=parent.get(n),fn=owner.get(n),isProperty=p?.type==='MemberExpression'&&p.property===n&&!p.computed;
    const b=isProperty?{kind:'PROPERTY_KEY_NOT_LEXICAL_BINDING',node:null,scopeFunction:null,scope:null}:bindingFor(n.name,fn);
    const writes=isProperty?[]:assignments.filter(a=>a.type==='AssignmentExpression'&&a.left.type==='Identifier'&&a.left.name===n.name&&bindingFor(n.name,owner.get(a)).node===b.node);
    return {node:ev(n),name:n.name,ownerFunction:id(fn),functionGraph:graphs.find(g=>g.function===id(fn))?.id||programGraph.id,parent:ev(p),binding:{kind:b.kind,node:b.node,scopeFunction:b.scopeFunction},assignmentDefinitions:writes.map(ev),role:isProperty?'PROPERTY_KEY':p?.type==='VariableDeclarator'&&p.id===n?'DECLARATION':p?.type==='AssignmentExpression'&&p.left===n?'ASSIGNMENT_TARGET':p?.type==='NewExpression'&&p.callee===n?'CONSTRUCTOR_CALLEE':p?.type==='CallExpression'&&p.callee===n?'CALL_CALLEE':'VALUE_OR_ARGUMENT_USE',limitation:'Syntactic lexical binding and all local definitions only; no assumed scanner taint label or execution dominance.'};
  });
  defUseGraphs.push({file:m.rel,fileSha256:m.hash,identifiers});
  graphByFile.set(m.rel,{graphs,edges,evMap,groups:{groupOwn,groupReceiver,groupData,groupParse,groupExport},ctorSource,parseOther,parseDecimal,ev});
  for(const c of calls.filter(n=>n.type==='NewExpression')){
    const fn=owner.get(c),source=ctorSource(c.callee,fn);
    if(fn===parseOther&&text(c.callee)==='Ctor')Object.assign(source,{kind:'OWN_CONSTRUCTOR_THROUGH_PARSE_OTHER',ownRoute:groupParse,missing:[]});
    constructorSites.push({file:m.rel,fileSha256:m.hash,node:ev(c),callee:ev(c.callee),functionGraph:graphs.find(g=>g.function===id(fn))?.id||programGraph.id,producer:source,proposed:source.kind.startsWith('OWN_')?'OWN_NUMERIC_CONSTRUCTOR':text(c.callee)==='Uint32Array'?'HOST_TYPED_DATA_CONSTRUCTOR':'UNRESOLVED_CONSTRUCTOR_CAPABILITY',proofGroups:source.kind.startsWith('OWN_')?[groupOwn,...(source.ownRoute?[groupParse]:[])]:[groupReceiver]});
  }
  for(const r of ctorMembers){
    const p=parent.get(r),fn=owner.get(r);
    constructorSites.push({file:m.rel,fileSha256:m.hash,node:ev(r),parent:ev(p),functionGraph:graphs.find(g=>g.function===id(fn))?.id||null,role:p?.type==='AssignmentExpression'&&p.left===r?'CONSTRUCTOR_FIELD_WRITE':p?.type==='NewExpression'&&p.callee===r?'CONSTRUCTOR_CALLEE_READ':'CONSTRUCTOR_REFERENCE_READ',ownRoute:[parseOther,parseDecimal].includes(fn)?groupParse:null});
  }
  // Exhaustive line bindings preserve duplicates; never pretend line-only rows specify a token.
  const rows=observations.filter(r=>r.observation.file.startsWith(m.rel+':'));
  const byLine=new Map();for(const r of rows){const l=Number(r.observation.file.split(':').at(-1));if(!byLine.has(l))byLine.set(l,[]);byLine.get(l).push(r);}
  const lineStarts=[0];for(let p=0;(p=m.src.indexOf('\n',p))!==-1;p++)lineStarts.push(p+1);
  for(const [line,rs]of byLine){
    const start=lineStarts[line-1],end=lineStarts[line]??m.src.length;
    const begins=nodes.filter(n=>n.loc.start.line===line&&n.type!=='Program');
    const semantic=begins.filter(n=>!['Identifier','Literal','ThisExpression'].includes(n.type));
    const atom=begins.filter(n=>n.type==='Identifier'||n.type==='ThisExpression');
    const lineText=m.src.slice(start,end),contentStart=start+(lineText.match(/^\s*/)?.[0].length||0),contentEnd=start+lineText.trimEnd().length;
    const relevant=nodes.filter(n=>n.start<=contentStart&&n.end>=contentEnd&&n.type.endsWith('Statement')&&n.type!=='BlockStatement').sort((a,b)=>(a.end-a.start)-(b.end-b.start)).slice(0,1);
    if(!begins.length&&!relevant.length)throw Error('No AST evidence for observation '+line);
    const fn=owner.get(begins[0]||relevant[0]),fg=graphs.find(g=>g.function===id(fn))||programGraph;
    const ctorNew=calls.filter(n=>n.type==='NewExpression'&&n.callee.loc.start.line===line);
    const ctorRefs=ctorMembers.filter(n=>n.loc.start.line===line);
    const transfer=calls.filter(c=>c.loc.start.line===line&&c.arguments.some(a=>a.type==='Identifier'&&a.name==='Ctor'));
    const fieldWrite=ctorRefs.filter(n=>parent.get(n)?.type==='AssignmentExpression'&&parent.get(n).left===n);
    const ownPath=[parseOther,parseDecimal].includes(fn)||fieldWrite.some(n=>text(parent.get(n).right)==='Decimal');
    let kind,classification,missing=['M_ROW_TOKEN'],groupIds=[groupData,fg?.id,groupExport].filter(Boolean);
    if(fieldWrite.length){kind='OWN_CONSTRUCTOR_FIELD_ASSIGNMENT';classification='PROPOSED_OWN_NUMERIC_CONSTRUCTOR_ASSIGNMENT';groupIds.push(groupOwn);}
    else if(ctorNew.length){
      const sources=ctorNew.map(c=>{const s=ctorSource(c.callee,fn);if(fn===parseOther&&text(c.callee)==='Ctor')Object.assign(s,{kind:'OWN_CONSTRUCTOR_THROUGH_PARSE_OTHER',ownRoute:groupParse,missing:[]});return s;});
      if(sources.every(s=>s.kind.startsWith('OWN_'))){kind='OWN_NUMERIC_CONSTRUCTION';classification='PROPOSED_OWN_NUMERIC_CONSTRUCTOR_ROUTE';groupIds.push(groupOwn,groupParse);}
      else{kind='RECEIVER_OR_ALIAS_CONSTRUCTOR_INVOCATION';classification='UNRESOLVED_CONSTRUCTOR_IDENTITY_AT_INVOCATION_LINE';groupIds.push(groupReceiver);missing.push('M_PUBLIC_RECEIVER');}
    }
    else if(transfer.length){kind='CONSTRUCTOR_TRANSFER_ARGUMENT';classification=ownPath?'PROPOSED_OWN_NUMERIC_CONSTRUCTOR_TRANSFER':'UNRESOLVED_CONSTRUCTOR_TRANSFER_LINE';groupIds.push(ownPath?groupParse:groupReceiver);if(!ownPath)missing.push('M_HELPER_ARGUMENT');}
    else if(ctorRefs.length){kind='CONSTRUCTOR_REFERENCE_DATA_OR_ALIAS';classification=ownPath?'PROPOSED_OWN_CONSTRUCTOR_DATA_REFERENCE':'PROPOSED_CONSTRUCTOR_REFERENCE_WITH_UNKNOWN_ORIGIN';groupIds.push(ownPath?groupParse:groupReceiver);if(!ownPath)missing.push('M_PUBLIC_RECEIVER');}
    else{kind='DATA_CONFIG_ARITHMETIC_OR_FORMATTING';classification='PROPOSED_EXPRESSION_DATA_USE';}
    const lid=`${m.prefix}:L:${line}`;
    const lineEvidence={id:lid,file:m.rel,fileSha256:m.hash,line,start,end,byteStart:Buffer.byteLength(m.src.slice(0,start)),byteEnd:Buffer.byteLength(m.src.slice(0,end)),snippet:m.src.slice(start,end),snippetSha256:sha(m.src.slice(start,end)),diagnosticIndices:rs.map(r=>r.diagnosticIndex),multiplicity:rs.length,exactAstNodesBeginningOnLine:semantic.map(ev),tokenCandidates:atom.map(ev),identifierDefUse:identifiers.filter(n=>atom.some(a=>id(a)===n.node)),minimalCoveringStatement:relevant.map(ev),ownerFunction:ev(fn),functionGraph:fg.id,constructorInvocations:ctorNew.map(ev),constructorReferences:ctorRefs.map(ev),constructorTransferCalls:transfer.map(ev),fieldWrites:fieldWrite.map(ev),proposedLineKind:kind,proposedClassification:classification,proofGroups:[...new Set(groupIds)],missingEvidence:[...new Set(missing)],rowTokenCorrespondence:'SET_VALUED_ONLY: exact original file/line; all same-line AST/token candidates retained. Duplicate ordinal is observation identity, not an asserted AST traversal ordinal.'};
    lineBindings.push(lineEvidence);
    rs.forEach((r,ordinal)=>dispositions.push({diagnosticIndex:r.diagnosticIndex,originalRow:r,originalRowCanonicalSha256:sha(JSON.stringify(r)),file:m.rel,fileSha256:m.hash,line,duplicateOrdinal:ordinal,duplicateCount:rs.length,lineEvidence:lid,exactAstCandidateIds:[...new Set([...lineEvidence.exactAstNodesBeginningOnLine,...lineEvidence.tokenCandidates,...lineEvidence.minimalCoveringStatement])],functionGraph:fg?.id||null,proofGroups:lineEvidence.proofGroups,proposedClassification:classification,proposedLineKind:kind,missingEvidence:lineEvidence.missingEvidence,evidenceStatus:'STATIC_AST_PROPOSAL_I0',frontierAccepted:false,qualification:'Classification describes the whole exact observed line and retained candidate expressions; a token-specific classification remains unresolved without scanner offsets. Constructor and data candidates on a mixed line are not collapsed into one alleged token.'}));
  }
}
dispositions.sort((a,b)=>observations.findIndex(r=>r.diagnosticIndex===a.diagnosticIndex)-observations.findIndex(r=>r.diagnosticIndex===b.diagnosticIndex));
if(new Set(dispositions.map(r=>r.diagnosticIndex)).size!==1072 || dispositions.length!==1072)throw Error('Rows dropped/duplicated');
write('evidence-nodes.json',evidence);
write('shared-proofs.json',proofs);
write('function-caller-assignment-graphs.json',functionGraphs);
write('identifier-def-use.json',defUseGraphs);
write('constructor-sites.json',constructorSites);
write('entry-exports.json',exportPaths);
write('line-bindings.json',lineBindings);
write('proposed-dispositions.json',dispositions);
write('missing-evidence.json',missingEvidence);
const summary={node:process.version,acorn:acorn.version,rows:observations.length,files:[]};
for(const m of models){
  const rows=observations.filter(r=>r.observation.file.startsWith(m.rel+':'));
  const lines=[...new Set(rows.map(r=>Number(r.observation.file.split(':').at(-1))))];
  const perLine=lines.map(line=>({line,duplicates:rows.filter(r=>r.observation.file===m.rel+':'+line).length,source:m.src.split('\n')[line-1],calls:m.calls.filter(n=>n.loc.start.line===line).map(n=>({type:n.type,callee:m.text(n.callee),start:n.start,end:n.end})),constructorMembers:m.ctorMembers.filter(n=>n.loc.start.line===line).map(n=>({source:m.text(n),start:n.start,end:n.end}))}));
  write(m.prefix+'.diagnostic-line-inventory.json',perLine);
  summary.files.push({file:m.rel,sha256:m.hash,rows:rows.length,uniqueLines:lines.length,nodeCount:m.nodes.length,calls:m.calls.length,newExpressions:m.calls.filter(n=>n.type==='NewExpression').length,constructorMembers:m.ctorMembers.length,functions:m.functions.length,linesWithoutCallOrConstructor:perLine.filter(l=>!l.calls.length&&!l.constructorMembers.length),diagnosticCallCallees:[...new Set(perLine.flatMap(l=>l.calls.map(c=>c.callee)))],examples:perLine.slice(0,20)});
}
write('initial-summary.json',summary);
const tally=(xs,key)=>xs.reduce((a,x)=>(a[x[key]]=(a[x[key]]||0)+1,a),{});
const report={
  task:authority.task,role:'I0 bounded producer',verdict:'PROPOSED_DISPOSITIONS_ONLY_NOT_FRONTIER_ACCEPTANCE',frontierAccepted:false,createdAt:new Date().toISOString(),
  scope:{packet,sourceReadonly:authority.sourceReadonly,write:out,files,originalRows:1072,uniqueLineBindings:lineBindings.length,sourceExecution:false,network:false,sourceChanges:false,subagents:false},
  procedure:{runtime:process.version,node:process.execPath,acorn:acorn.version,command:'/home/ricardo/.nvm/versions/node/v22.23.2/bin/node --expose-internals output/analyze.cjs',method:'Parse source bytes as ESTree; index all functions, calls/new expressions, constructor members, assignments/returns, exports and exact diagnostic lines. Resolve local lexical callers and separately label conditional member-name routes. No decimal import/require/evaluation; no payloads.'},
  coverage:summary.files.map(f=>({file:f.file,sha256:f.sha256,rows:f.rows,uniqueLines:f.uniqueLines,nodeCount:f.nodeCount,callsIncludingNew:f.calls,newExpressions:f.newExpressions,constructorMembers:f.constructorMembers,functions:f.functions,linesWithoutCallOrConstructor:f.linesWithoutCallOrConstructor.length})),
  proposedRowClassifications:tally(dispositions,'proposedClassification'),lineKinds:tally(lineBindings,'proposedLineKind'),constructorSiteProposals:tally(constructorSites.filter(s=>s.proposed),'proposed'),
  findings:[
    {id:'F_OWN_PRODUCER',status:'STATIC_PRODUCER_IDENTITY',text:'Both physical files define Decimal(v) inside clone(obj), assign each x.constructor to the inner lexical Decimal, attach P as prototype, and return that constructor. The body represents numeric values as s/e/d and routes primitive strings to local decimal/base parsers, not an evaluator or loader.',proofs:['umd:G_OWN_NUMERIC_PRODUCER','esm:G_OWN_NUMERIC_PRODUCER']},
    {id:'F_OWN_PARSE_ROUTE',status:'STATIC_LOCAL_CALLER_CLOSURE',text:'parseOther has exactly one lexical caller, the inner Decimal primitive-string branch. parseDecimal callers are inner Decimal and parseOther. Their constructor uses can be bound to the own assignment before parser entry; parseOther transfers that own Ctor to intPow. No universal sandbox obligation is used.',proofs:['umd:G_OWN_PARSE_ROUTE','esm:G_OWN_PARSE_ROUTE']},
    {id:'F_RECEIVER_TRANSFER',status:'UNRESOLVED_CAPABILITY_IDENTITY',text:'Public P methods invoke receiver.constructor or Ctor read from it; exported static methods invoke new this. Prototype/static assignments establish normal own numeric routes but do not restrict their receivers. Internal helper arguments from those routes retain unresolved constructor identity.',proofs:['umd:G_PUBLIC_RECEIVER_UNKNOWN','esm:G_PUBLIC_RECEIVER_UNKNOWN'],missing:['M_PUBLIC_RECEIVER','M_HELPER_ARGUMENT']},
    {id:'F_DATA',status:'STATIC_EXPRESSION_ROLE_ONLY',text:'Many diagnostics concern numeric settings, arithmetic, comparison, indexes, or formatting. Those expressions are not evaluator or loader invocation AST nodes. Reclassifying a data expression does not clear a separate constructor invocation/transfer on a mixed line or prove an arbitrary property receiver has trusted origin.',proofs:['umd:G_DATA_USE','esm:G_DATA_USE']},
    {id:'F_ENTRIES',status:'STATIC_PHYSICAL_ENTRY_DIFFERENCE',text:'UMD: AMD define callback precedes CJS module.exports and global/noConflict fallback. ESM: named Decimal = P.constructor = clone(DEFAULTS), then default export, with direct Symbol inspection assignments. External AMD define identity and actual host branch selection are not established.',proofs:['umd:G_ENTRY_EXPORTS','esm:G_ENTRY_EXPORTS'],missing:['M_AMD_DEFINE','M_HOST_ROUTING']},
    {id:'F_ROWS',status:'EXACT_LINE_BINDING_TOKEN_IDENTITY_UNRESOLVED',text:'All 1072 rows retain original diagnosticIndex and observation fields, with canonical row hashes. All 688 unique file/line observations have exact physical hash/span, raw AST candidates and containing-function graph. The 384 extra duplicate observations are retained; no scanner-token identity is invented from their ordinal.',missing:['M_ROW_TOKEN']},
    {id:'F_LINEAGE',status:'AUTHORITY_DESIGNATED_PHYSICAL_SOURCE_HASHED',text:'Runtime bytes are taken only from authority.sourceReadonly and hashed. Current physical files have nlink 1. Historical original48link lineage is not independently certified without its trusted digest manifest.',missing:['M_HISTORICAL_LINK']}
  ],
  finiteMissingEvidence:missingEvidence,
  exclusions:['No blanket vendor/npm-name exemption','No frontier PASS, acceptance or production release','No scanner runtime rebuild or token correspondence assertion','No actual target or synthetic payload execution','No private env/keys, network/provider/PG/install, other source files, prior critics, shared Root governance or mutation'],
  nextAction:'Independent adjudicator reviews these proposed row/line classifications against supplied scanner token evidence and any concrete receiver/AMD caller bindings; unresolved capabilities remain unresolved.',
  artifacts:['proposed-dispositions.json','line-bindings.json','shared-proofs.json','evidence-nodes.json','function-caller-assignment-graphs.json','identifier-def-use.json','constructor-sites.json','entry-exports.json','missing-evidence.json','umd.raw-ast.json','esm.raw-ast.json','umd.ast-index.json','esm.ast-index.json','umd.tokens-comments.json','esm.tokens-comments.json','read-set-integrity.json','verification.json']
};
write('report.json',report);
fs.writeFileSync(path.join(out,'report.md'),`# I0 decimal frontier proposed dispositions\n\n${report.verdict}. No frontier acceptance is issued.\n\nExactly **1,072 observations** are retained (536 per physical variant), including 384 duplicate file/line observations. There are 688 exact file/line bindings. Node ${process.version}, built-in Acorn ${acorn.version}, offline AST only; no target execution, imports, payloads, network, installation or source mutation.\n\n## Physical sources\n\n${report.coverage.map(f=>`- ${f.file}: SHA-256 \`${f.sha256}\`; ${f.rows} rows, ${f.uniqueLines} lines, ${f.nodeCount} AST nodes, ${f.newExpressions} new expressions, ${f.constructorMembers} constructor members.`).join('\n')}\n\nAuthority designates the immutable R22 candidate. Both current files have nlink 1; historical original48link lineage needs its authority-owned digest manifest. The read-set records before/after bytes and metadata.\n\n## Proposed observation-line classifications\n\n| Classification | Rows |\n| --- | ---: |\n${Object.entries(report.proposedRowClassifications).map(([k,v])=>`| ${k} | ${v} |`).join('\n')}\n\nThese are **whole-line proposals**, with set-valued AST candidates retained for every duplicate. The source observations contain no column, token identity or scanner traversal trace. A mixed line can contain both numeric data and an unresolved constructor capability; duplicate order is not claimed as token order. Each row links a line hash, exact AST candidate spans, containing function, assignments, caller edges and finite proof groups.\n\n## Producer and caller evidence\n\n${report.findings.map(f=>`- **${f.id} (${f.status})**: ${f.text}`).join('\n')}\n\nThe own numeric constructor claim is about this local producer and its primitive-string parsing route. It does not assert callback-free behavior for tag-compatible objects: isDecimalInstance accepts obj.toStringTag === tag, and the copy path calls v.d.slice(). Public receiver.constructor reads and new this sites remain unresolved until their specific producer/caller chain is known.\n\n## Reviewable evidence\n\n- [proposed-dispositions.json](proposed-dispositions.json): all 1072 exact original rows and duplicate ordinals.\n- [line-bindings.json](line-bindings.json): exact source line spans/hashes plus candidate AST/token identities.\n- [shared-proofs.json](shared-proofs.json), [evidence-nodes.json](evidence-nodes.json): finite proof groups and exact snippets, UTF-16/byte offsets, physical hashes.\n- [function-caller-assignment-graphs.json](function-caller-assignment-graphs.json): every local function, assignment, actual invocation and conditional member route.\n- [constructor-sites.json](constructor-sites.json), [entry-exports.json](entry-exports.json): both physical variants, all new expressions and constructor members, export branches.\n- umd/esm.raw-ast.json, .ast-index.json, .tokens-comments.json: complete parsed source evidence.\n- [read-set-integrity.json](read-set-integrity.json): bounded read-set hashes, metadata and drift checks.\n- [missing-evidence.json](missing-evidence.json): finite missing evidence; no arbitrary-JavaScript sandbox obligation.\n\n## Concrete missing evidence\n\n${missingEvidence.map(x=>`- **${x.id}**: ${x.missing} Next: ${x.next}`).join('\n')}\n\nNext action: ${report.nextAction}\n`);
const integrity=reads.map(r=>{const b=fs.readFileSync(r.path),s=fs.statSync(r.path);return {...r,afterSha256:sha(b),afterBytes:b.length,afterMtimeMs:s.mtimeMs,afterHardlinks:s.nlink,contentUnchanged:sha(b)===r.sha256,metadataUnchanged:s.mtimeMs===r.mtimeMs&&s.ino===r.inode&&s.nlink===r.hardlinks};});
if(integrity.some(r=>!r.contentUnchanged||!r.metadataUnchanged))throw Error('Read-set drift; no stable evidence claim');
write('read-set-integrity.json',{node:process.version,acorn:acorn.version,nodeExecutable:process.execPath,parser:'Node22 built-in internal/deps/acorn/acorn/dist/acorn (no source vendor parser execution)',readSet:integrity,allContentUnchanged:integrity.every(r=>r.contentUnchanged),sourceFilesOnly:files,sourceNotExecuted:true,note:'SHA-256 before and after detects content drift during this procedure; does not independently attest original48link historical manifest. Hardlink metadata is recorded as observed.'});
console.log(JSON.stringify({node:process.version,acorn:acorn.version,rows:dispositions.length,lineBindings:lineBindings.length,classifications:report.proposedRowClassifications,constructorSites:report.constructorSiteProposals,readSetUnchanged:integrity.every(r=>r.contentUnchanged)},null,2));
