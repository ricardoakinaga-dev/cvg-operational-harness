'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
if(process.versions.node.split('.')[0]!=='22')throw Error('Node22 required');
const packet='/home/ricardo/.cache/cvg-harness-green-20261004/decimal-frontier-disposition-r29',out=path.join(packet,'output');
const sha=v=>crypto.createHash('sha256').update(v).digest('hex');
const readSet=[];
function bytes(p){const b=fs.readFileSync(p);readSet.push({path:p,sha256:sha(b),bytes:b.length});return b;}
const json=p=>JSON.parse(bytes(path.join(out,p)).toString('utf8'));
const a=JSON.parse(bytes(path.join(packet,'authority.json'))),o=JSON.parse(bytes(path.join(packet,'observations.json')));
const r=json('report.json'),rows=json('proposed-dispositions.json'),lines=json('line-bindings.json'),ev=json('evidence-nodes.json'),proofs=json('shared-proofs.json'),fg=json('function-caller-assignment-graphs.json'),cs=json('constructor-sites.json'),ex=json('entry-exports.json'),du=json('identifier-def-use.json'),missing=json('missing-evidence.json'),integrity=json('read-set-integrity.json');
const assert=(v,s)=>{if(!v)throw Error(s);};
const checks=[];
function check(name,fn){fn();checks.push({name,result:'CONSISTENT'});}
const eMap=new Map(ev.map(n=>[n.id,n])),gMap=new Map(fg.map(n=>[n.id,n])),pMap=new Map(proofs.map(n=>[n.id,n])),lMap=new Map(lines.map(n=>[n.id,n]));
const sources=new Map();
for(const rel of r.scope.files){const b=bytes(path.join(a.sourceReadonly,rel));sources.set(rel,{bytes:b,src:b.toString('utf8'),sha256:sha(b)});}
check('Exactly 1072 rows, order and original observations preserved, including all duplicates',()=>{
 assert(rows.length===1072&&o.length===1072,'cardinality');assert(new Set(rows.map(x=>x.diagnosticIndex)).size===1072,'diagnostic identity');
 rows.forEach((x,i)=>{assert(JSON.stringify(x.originalRow)===JSON.stringify(o[i]),'original observation mismatch '+i);assert(x.originalRowCanonicalSha256===sha(JSON.stringify(o[i])),'row digest');assert(x.diagnosticIndex===o[i].diagnosticIndex,'row identity');assert(x.frontierAccepted===false,'acceptance leakage');});
 const seen=new Map();for(const x of rows){const n=seen.get(x.originalRow.observation.file)||0;assert(x.duplicateOrdinal===n,'duplicate ordinal');seen.set(x.originalRow.observation.file,n+1);}for(const x of rows)assert(x.duplicateCount===seen.get(x.originalRow.observation.file),'duplicate multiplicity');
 assert(lines.length===688,'line cardinality');assert(rows.length-lines.length===384,'retained duplicate excess');
});
check('Every evidence node has exact source/hash/UTF16/byte offsets/snippet binding',()=>{
 assert(eMap.size===ev.length,'evidence ID collision');
 for(const n of ev){const s=sources.get(n.file);assert(s,'source scope');assert(n.fileSha256===s.sha256,'physical hash');assert(s.src.slice(n.start,n.end)===n.snippet,'node snippet '+n.id);assert(sha(n.snippet)===n.snippetSha256,'snippet hash');assert(Buffer.byteLength(s.src.slice(0,n.start))===n.byteStart&&Buffer.byteLength(s.src.slice(0,n.end))===n.byteEnd,'byte offsets');}
});
check('Every diagnostic links exact line spans, function/caller/assignment graph and finite proofs',()=>{
 for(const l of lines){const s=sources.get(l.file);assert(s.src.slice(l.start,l.end)===l.snippet&&sha(l.snippet)===l.snippetSha256,'line snippet');assert(l.fileSha256===s.sha256,'line physical hash');assert(gMap.has(l.functionGraph),'line caller graph '+l.id);for(const k of [...l.exactAstNodesBeginningOnLine,...l.tokenCandidates,...l.minimalCoveringStatement])assert(eMap.has(k),'line node missing');}
 for(const x of rows){const l=lMap.get(x.lineEvidence);assert(l&&l.diagnosticIndices.includes(x.diagnosticIndex),'line observation link');assert(x.fileSha256===sources.get(x.file).sha256,'row source hash');assert(x.exactAstCandidateIds.length>0,'row AST empty');for(const k of x.exactAstCandidateIds)assert(eMap.has(k),'row AST absent');assert(gMap.has(x.functionGraph),'row graph absent');for(const k of x.proofGroups)assert(pMap.has(k)||gMap.has(k),'proof absent');for(const k of x.missingEvidence)assert(missing.some(m=>m.id===k),'missing evidence absent');}
});
check('Complete AST construction, assignment, function and constructor member inventories for both physical entries',()=>{
 for(const [rel,s]of sources){const prefix=rel.endsWith('.mjs')?'esm':'umd',ast=json(prefix+'.raw-ast.json'),idx=json(prefix+'.ast-index.json');const nodes=[];function walk(n){if(!n||typeof n.type!=='string')return;nodes.push(n);for(const [k,v]of Object.entries(n)){if(['loc','range'].includes(k))continue;if(Array.isArray(v))v.forEach(walk);else if(v&&typeof v.type==='string')walk(v);}}walk(ast);
 assert(ast.end===s.src.length&&idx.fileSha256===s.sha256,'AST physical binding');assert(nodes.length===idx.nodeCount,'node inventory');
 const newNodes=nodes.filter(n=>n.type==='NewExpression'),ctorNodes=nodes.filter(n=>n.type==='MemberExpression'&&((!n.computed&&n.property.name==='constructor')||(n.computed&&n.property.value==='constructor')));
 assert(newNodes.length===166&&ctorNodes.length===49,'constructor inventories changed');assert(cs.filter(n=>n.file===rel&&n.proposed).length===newNodes.length,'new site omission');assert(cs.filter(n=>n.file===rel&&n.role).length===ctorNodes.length,'constructor member omission');assert(fg.filter(n=>eMap.get(n.function)?.file===rel).length===idx.functions.length+1,'functions/program omission');
 assert(idx.assignments.length===nodes.filter(n=>['AssignmentExpression','VariableDeclarator'].includes(n.type)).length,'assignment omission');assert(idx.calls.length===nodes.filter(n=>['CallExpression','NewExpression'].includes(n.type)).length,'call omission');
 assert(du.find(x=>x.file===rel).identifiers.length===nodes.filter(n=>n.type==='Identifier').length,'identifier def/use omission');
 const hazards=nodes.filter(n=>n.type==='ImportDeclaration'||n.type==='ImportExpression'||['CallExpression','NewExpression'].includes(n.type)&&n.callee.type==='Identifier'&&['eval','Function','require'].includes(n.callee.name));assert(hazards.length===0,'known evaluator/import/require found');
 }
});
check('Own constructor parser proof closes actual local callers, without admitting public receiver sinks',()=>{
 for(const prefix of ['umd','esm']){const p=pMap.get(prefix+':G_OWN_PARSE_ROUTE');assert(p.incomingParseOther.length===1,'parseOther caller count');const producer=eMap.get(pMap.get(prefix+':G_OWN_NUMERIC_PRODUCER').producerFunction);assert(p.incomingParseOther[0].callerFunction===producer.id,'parseOther producer caller');const pe=eMap.get(p.parseOther);assert(p.incomingParseDecimal.every(c=>[producer.id,pe.id].includes(c.callerFunction)),'parseDecimal caller closure');assert(eMap.get(p.constructorAssignment).snippet==='x.constructor = Decimal','own constructor assignment');}
 assert(rows.filter(x=>x.proposedClassification==='UNRESOLVED_CONSTRUCTOR_IDENTITY_AT_INVOCATION_LINE').length===268,'receiver invocation row count');assert(rows.filter(x=>x.proposedClassification==='UNRESOLVED_CONSTRUCTOR_TRANSFER_LINE').length===56,'transfer row count');
});
check('Separate physical entry semantics and unresolved AMD loader boundary retained',()=>{
 const umd=ex.find(x=>x.file.endsWith('.js')),esm=ex.find(x=>x.file.endsWith('.mjs'));assert(umd.loaderCalls.length===1&&esm.loaderCalls.length===0,'AMD/ESM loader identity');assert(umd.missing.includes('M_AMD_DEFINE'),'AMD unknown lost');assert(eMap.get(umd.loaderCalls[0]).snippet.startsWith('define(function'),'AMD callback AST');assert(esm.nodes.some(k=>eMap.get(k).type==='ExportDefaultDeclaration'),'default export omitted');assert(esm.nodes.some(k=>eMap.get(k).type==='ExportNamedDeclaration'),'named export omitted');
});
check('Read-set bytes unchanged and acceptance not asserted',()=>{
 assert(integrity.allContentUnchanged,'analysis drift');for(const q of integrity.readSet)assert(sha(bytes(q.path))===q.sha256,'post-analysis read drift '+q.path);assert(r.frontierAccepted===false&&r.verdict==='PROPOSED_DISPOSITIONS_ONLY_NOT_FRONTIER_ACCEPTANCE','verdict boundary');assert(r.scope.sourceExecution===false,'source executed');
});
const artifactNames=fs.readdirSync(out).filter(n=>fs.statSync(path.join(out,n)).isFile()&&!['verification.json','artifact-manifest.json'].includes(n)).sort();
const manifest=artifactNames.map(n=>({file:n,bytes:fs.statSync(path.join(out,n)).size,sha256:sha(bytes(path.join(out,n)))}));
fs.writeFileSync(path.join(out,'artifact-manifest.json'),JSON.stringify({purpose:'I0 artifact integrity only; not acceptance',artifacts:manifest},null,2)+'\n');
const drift=readSet.map(q=>({...q,afterSha256:sha(fs.readFileSync(q.path)),unchanged:sha(fs.readFileSync(q.path))===q.sha256}));assert(drift.every(q=>q.unchanged),'verification read drift');
const result={role:'I0 artifact self-check, temporally separate from generation; not independent review',status:'ARTIFACT_CONSISTENCY_CHECKS_COMPLETED',frontierAccepted:false,node:process.version,checkedAt:new Date().toISOString(),procedure:'Node22 offline artifact and raw AST verification; target files read only as data',checks,rows:rows.length,uniqueLines:lines.length,duplicatesRetained:rows.length-lines.length,readSet:drift,limitations:['No scanner token offsets supplied; every row remains a set-valued line binding.', 'No runtime evaluation of decimal or payloads.', 'Historical original48link manifest and specific external public receiver/AMD loader bindings are not available within this scope.']};
fs.writeFileSync(path.join(out,'verification.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({status:result.status,checks:checks.length,rows:rows.length,uniqueLines:lines.length,readSetUnchanged:drift.every(q=>q.unchanged),frontierAccepted:false},null,2));
