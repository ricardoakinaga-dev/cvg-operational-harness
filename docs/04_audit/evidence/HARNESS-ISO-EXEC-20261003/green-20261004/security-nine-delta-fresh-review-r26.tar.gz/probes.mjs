import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { pathToFileURL } from 'node:url'
import { performance } from 'node:perf_hooks'
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'
import { parseVitestSummary, verifyGateEvidence } from './source/scripts/lib/certification-rules.mjs'
import { createBoundaryLexical } from './source/scripts/boundary-lexical.mjs'
import { auditProductBoundary } from './source/scripts/check-product-boundary.mjs'
const owned = path.dirname(new URL(import.meta.url).pathname)
const require = createRequire(path.join(owned, 'source/scripts/check-product-boundary.mjs'))
const ts = require('typescript')
const checks = []
const fixtures = path.join(owned, 'fixtures')
fs.mkdirSync(fixtures, { recursive: true })
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex')
const save = () => fs.writeFileSync(path.join(owned, 'probe-results.json'), JSON.stringify({ node:process.version, execPath:process.execPath, typescript:ts.version, fixturePayloadsExecuted:false, checks, totals:{ passed:checks.filter(c=>c.status==='PASS').length, failed:checks.filter(c=>c.status==='FAIL').length } }, null, 2)+'\n')
async function check(id, run) {
  const start=performance.now()
  try {const observation=await run(); checks.push({id,status:'PASS',elapsed_ms:performance.now()-start,observation}); console.log(`PASS ${id}`)}
  catch(error){checks.push({id,status:'FAIL',elapsed_ms:performance.now()-start,error:error.stack});console.log(`FAIL ${id}: ${error.message}`)}
  save()
}
function put(root, relative, value) {
  const file=path.join(root,relative);fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,typeof value==='string'?value:JSON.stringify(value));return file
}
function fixture(id, text='export const neutral=1', ext='mts', dependencyField) {
 const root=path.join(fixtures,id);fs.mkdirSync(root,{recursive:true})
 put(root,'package.json',{type:'module',workspaces:['packages/*','products/*']})
 put(root,'tsconfig.base.json',{compilerOptions:{module:'NodeNext',moduleResolution:'NodeNext',target:'ESNext',allowJs:true}})
 put(root,'packages/core/package.json',{name:'@synthetic/core',type:'module',...(dependencyField?{[dependencyField]:{bridge:'*'}}:{})})
 put(root,`packages/core/src/entry.${ext}`,text)
 put(root,'products/shift/package.json',{name:'@synthetic/product'})
 put(root,'products/shift/payload.js','throw new Error("FIXTURE_PAYLOAD_MUST_NEVER_EXECUTE")')
 return root
}
function installed(root, name='bridge', entry='entry.cjs', metadata={}) {
 put(root,`node_modules/${name}/package.json`,{name:name.split('/node_modules/').at(-1),main:entry,...metadata})
 put(root,`node_modules/${name}/${entry}`,'throw new Error("INSTALLED_PAYLOAD_MUST_NEVER_EXECUTE");module.exports=1')
}
function audit(root){return auditProductBoundary(root)}
function unknown(a, reason){assert.equal(a.passed,false);assert.notEqual(a.status,'PASS');assert(a.diagnostics.some(d=>d.reason===reason),JSON.stringify(a))}
function forbidden(a, entry){assert.equal(a.status,'FAIL');assert.equal(a.passed,false);assert(a.violations.some(v=>v.reason==='CORE_DEPENDS_ON_PRODUCT'&&(!entry||v.trail.includes(entry))),JSON.stringify(a))}
function source(text){const s=ts.createSourceFile(path.join(fixtures,'lexical-probe.mts'),text,ts.ScriptTarget.Latest,true);assert.equal(s.parseDiagnostics.length,0);return s}
function nodes(s,predicate){const result=[];function visit(n){if(predicate(n))result.push(n);ts.forEachChild(n,visit)}visit(s);return result}
const product='../../../products/shift/payload.js'
// Only trusted parser/checker implementation is run; all JavaScript payloads below remain text.
for(const [id,decoration] of [
 ['plain',''],['CSI','\x1b[1;31m'],['OSC-ESC-BEL','\x1b]0;title with spaces\x07'],['OSC-ESC-ST','\x1b]8;;https://example.invalid/title with spaces\x1b\\'],['OSC-C1-ST','\x9d0;title with spaces\x9c'],['OSC-C1-BEL','\x9d0;title with spaces\x07']
]) await check(`summary-first-failure-${id}`,()=>{
 const log=`${decoration}Tests 2 passed | 1 failed | 3 skipped (6)\nTests 999 passed (999)`
 const actual=parseVitestSummary(log,'Tests');assert.deepEqual(actual,{passed:2,failed:1,skipped:3,total:6});return actual
})
for(const prefix of ['\x1b]0;','\x9d0;'])await check(`unterminated-OSC-${prefix.charCodeAt(0)}`,()=>{
 const actual=parseVitestSummary(`Tests 1 passed (1)\n${prefix}unfinished\nTests 999 passed (999)`,'Tests');assert.equal(actual,null);return {actual}
})
await check('OSC-does-not-admit-embedded-fake-summary',()=>{
 const actual=parseVitestSummary('\x1b]0;Tests 999 passed (999)\n\x07Tests 1 failed (1)','Tests');assert.equal(actual.failed,1);return actual
})
await check('OSC-normalization-resource-scaling',()=>{
 const rows=[]
 for(const count of [65536,262144,1048576])for(const form of ['incomplete','complete']){
 const log=form==='incomplete'?'\x1b]0;'.repeat(count)+'\nTests 999 passed (999)':'\x1b]0;t\x07'.repeat(count)+'Tests 1 failed (1)\nTests 999 passed (999)'
 const start=performance.now();const actual=parseVitestSummary(log,'Tests');const elapsed_ms=performance.now()-start
 assert.equal(form==='incomplete'?actual:actual.failed,form==='incomplete'?null:1);assert(elapsed_ms<5000);rows.push({count,form,bytes:Buffer.byteLength(log),elapsed_ms})
 }return rows
})
function gateProof(body, exitCode=0, declared={filesPassed:1,filesFailed:0,filesSkipped:0,testsPassed:1,testsFailed:0,testsSkipped:0}){
 const runId='synthetic-r26-offline',candidateId='c'.repeat(64)
 const bytes=Buffer.from(`# runId=${runId} candidateId=${candidateId} gate=postgres exitCode=${exitCode}\n${body}\n`)
 const report=Buffer.from('{}');const rows=[['certification/logs/postgres.log',bytes,'log'],['certification/postgres-test-report.json',report,'result']]
 const evidence=rows.map(([p,b,kind])=>({path:p,kind,sha256:sha(b),size:b.length}))
 const result={runId,candidate:{candidateId},gates:[{id:'postgres',status:'PASS',exitCode,metrics:declared,evidence}]}
 const manifest={runId,candidateId,artifacts:evidence.map(e=>({...e,gateId:'postgres'}))}
 return verifyGateEvidence({result,manifest,artifactReader:p=>rows.find(r=>r[0]===p)?.[1]})
}
await check('certification-caller-normalized-pass-control',()=>{const failures=gateProof('\x1b[32mTest Files 1 passed (1)\x1b[0m\n\x1b]0;synthetic title with spaces\x07Tests 1 passed (1)');assert.deepEqual(failures,[]);return {failures,syntheticGate:'postgres',databaseExecuted:false}})
await check('certification-caller-normalized-failure-denied',()=>{const failures=gateProof('Test Files 1 passed (1)\n\x1b]0;synthetic title with spaces\x07Tests 1 failed (1)\nTests 1 passed (1)');assert(failures.includes('gate_raw_failure:postgres'));assert(failures.includes('gate_status_mismatch:postgres'));return failures})
await check('certification-caller-unfinished-OSC-denied',()=>{const failures=gateProof('Test Files 1 passed (1)\n\x1b]0;unfinished\nTests 1 passed (1)');assert(failures.includes('gate_inventory_unparsable:postgres'));assert(failures.includes('gate_status_mismatch:postgres'));return failures})
await check('certification-caller-exit-status-still-required',()=>{const failures=gateProof('Test Files 1 passed (1)\nTests 1 passed (1)',1);assert(failures.includes('gate_status_mismatch:postgres'));return failures})
for(const text of [
 'const require="label"; subject.require;',
 'const process="label"; subject.process;',
 'const eval="label"; subject.eval;',
 'const Function="label"; subject.Function;',
 'const createRequire="label"; subject.createRequire;',
 'const {require:load,process:proc}=subject;load;proc;',
 'const key="require";const {[key]:load}=subject;key;load;',
 'const {data:{length:require}}=subject;require;',
 'const {require}=subject;require;',
 'const eval=subject;const record={eval};export {eval as callable};',
 'const label=subject; import.meta.url;'
])await check(`lexical-property-binding-${checks.length}`,()=>{
 const s=source(text),lex=createBoundaryLexical(ts,s),labels=nodes(s,n=>ts.isIdentifier(n)&&((ts.isPropertyAccessExpression(n.parent)||ts.isMetaProperty(n.parent))&&n.parent.name===n||ts.isBindingElement(n.parent)&&n.parent.propertyName===n))
 for(const label of labels)assert.equal(lex.identity(label),undefined)
 for(const name of ['load','proc','require','key','eval']){
 const bindings=nodes(s,n=>ts.isIdentifier(n)&&n.text===name&&!labels.includes(n))
 if(bindings.length>1){const ids=bindings.map(n=>lex.identity(n));assert(ids.every(i=>i===ids[0]));assert.notEqual(ids[0],lex.global(name))}
 }
 return {text,labelCount:labels.length}
})
await check('actual-installed-TS-property-and-label-query',()=>{
 const filename=require.resolve('typescript'),text=fs.readFileSync(filename,'utf8');const s=ts.createSourceFile(filename,text,ts.ScriptTarget.Latest,true);assert.equal(s.parseDiagnostics.length,0)
 const fragment='const moduleType = type.flags & 403701760',position=text.indexOf(fragment)+fragment.indexOf('flags');assert(text.includes(fragment))
 const flags=nodes(s,n=>ts.isIdentifier(n)&&n.getStart(s)===position)[0];assert.equal(flags.text,'flags')
 const labels=nodes(s,n=>ts.isIdentifier(n)&&ts.isBindingElement(n.parent)&&n.parent.propertyName===n&&n.text==='length'&&n.parent.name?.text==='length2');assert(labels.length>0)
 const diagnostics=[],lex=createBoundaryLexical(ts,s,true,d=>diagnostics.push(d));assert.equal(lex.identity(flags),undefined);const receiver=lex.identity(flags.parent.expression);assert(receiver.declarations.some(n=>ts.isVariableDeclaration(n)&&n.name.getText(s)==='type'))
 for(const label of labels)assert.equal(lex.identity(label),undefined);assert.deepEqual(diagnostics,[])
 return {filename,source_sha256:sha(Buffer.from(text)),flagsPosition:position,labelPositions:labels.map(n=>n.getStart(s)),receiverDeclarationKinds:receiver.declarations.map(n=>ts.SyntaxKind[n.kind]),diagnostics}
})
const failuresByOperation=[
 ['getSymbolAtLocation','const handle=subject;handle;',n=>ts.isExpressionStatement(n.parent)],
 ['getShorthandAssignmentValueSymbol','const handle=subject;const x={handle};',n=>ts.isShorthandPropertyAssignment(n.parent)],
 ['getExportSpecifierLocalTargetSymbol','const handle=subject;export {handle as publicHandle};',n=>ts.isExportSpecifier(n.parent)&&n.parent.propertyName===n],
 ['resolveName','const handle=subject;function f(x=handle){function handle(){}return x}',n=>ts.isParameter(n.parent)&&n.parent.initializer===n]
]
function facade(operation,error){return {...ts,createProgram(...args){const p=ts.createProgram(...args);const c=p.getTypeChecker();return {getTypeChecker:()=>new Proxy(c,{get(target,key){if(key===operation)return ()=>{throw error};return target[key]}})}}}}
for(const [operation,text,select] of failuresByOperation)await check(`lexical-query-exhaustion-${operation}`,()=>{
 const s=source(text),n=nodes(s,n=>ts.isIdentifier(n)&&n.text==='handle'&&select(n))[0];assert(n)
 const diagnostics=[],error=new RangeError('Maximum call stack size exceeded'),lex=createBoundaryLexical(facade(operation,error),s,false,d=>diagnostics.push(d)),id=lex.identity(n)
 assert.equal(id.unavailable.reason,'UNAVAILABLE_LEXICAL_BINDING_ANALYSIS');assert.notEqual(id,lex.global('handle'));assert.equal(id.global,undefined);assert.equal(id.declarations,undefined);assert.equal(lex.identity(n),id);assert.equal(diagnostics.length,1);assert.equal(diagnostics[0].operation,operation)
 const noReporter=createBoundaryLexical(facade(operation,error),s);assert.throws(()=>noReporter.identity(n),e=>e.cause===error&&e.message.startsWith('boundary_lexical_analysis_incomplete:'));return diagnostics
})
for(const error of [new TypeError('synthetic checker defect'),new RangeError('synthetic unrelated range failure')])await check(`lexical-unrelated-error-${error.name}`,()=>{
 const s=source('const handle=subject;handle'),n=nodes(s,n=>ts.isIdentifier(n)&&ts.isExpressionStatement(n.parent))[0],diagnostics=[],lex=createBoundaryLexical(facade('getSymbolAtLocation',error),s,false,d=>diagnostics.push(d));assert.throws(()=>lex.identity(n),e=>e===error);assert.deepEqual(diagnostics,[]);return {propagated:error.message}
})
for(const [operation,text] of failuresByOperation)await check(`integrated-caller-exhaustion-${operation}`,async()=>{
 const root=fixture(`query-fault-${operation}`,text);const moduleId=require.resolve('typescript');const actual=require.cache[moduleId].exports;require.cache[moduleId].exports=facade(operation,new RangeError('Maximum call stack size exceeded'))
 try{const imported=await import(pathToFileURL(path.join(owned,'source/scripts/check-product-boundary.mjs')).href+`?operation=${operation}`);const a=imported.auditProductBoundary(root);assert.equal(a.status,'INCOMPLETE');unknown(a,'UNAVAILABLE_LEXICAL_BINDING_ANALYSIS');return a}finally{require.cache[moduleId].exports=actual}
})
const directCases=[
 ['ordinary-property-pass','const data={require:"label",process:"label",eval:"label",Function:"label"};export const x=data.require+data.process+data.eval+data.Function','PASS'],
 ['loader-member',`module.require(${JSON.stringify(product)})`,'FAIL'],
 ['global-computed-loader',`globalThis["require"](${JSON.stringify(product)})`,'FAIL'],
 ['destructured-loader',`const {require:load}=module;load(${JSON.stringify(product)})`,'FAIL'],
 ['computed-key-product',`const {[require(${JSON.stringify(product)})]:value}=data;export {value}`,'FAIL'],
 ['meta-resolver',`import.meta.resolve(${JSON.stringify(product)})`,'FAIL'],
 ['factory-destructuring',`const {createRequire:make}=process.getBuiltinModule("node:module");const load=make(import.meta.url);load(${JSON.stringify(product)})`,'FAIL'],
 ['dynamic-literal-import',`import(${JSON.stringify(product)})`,'FAIL'],
 ['static-product-import',`import ${JSON.stringify(product)}`,'FAIL'],
 ['nonliteral-import','import(target)','INCOMPLETE','NON_LITERAL_MODULE_REFERENCE'],
 ['nonliteral-loader','require(target)','INCOMPLETE','NON_LITERAL_MODULE_REFERENCE'],
 ['eval-alias','const execute=eval;execute("synthetic")','INCOMPLETE','UNVERIFIED_DYNAMIC_CODE_EXECUTION'],
 ['Function-property','globalThis.Function("synthetic")','INCOMPLETE','UNVERIFIED_DYNAMIC_CODE_EXECUTION'],
 ['eval-shorthand-escape','const box={eval};export {box}','INCOMPLETE','UNVERIFIED_DYNAMIC_CODE_EXECUTION'],
 ['vm-destructuring','const {runInNewContext:execute}=require("node:vm");execute("synthetic")','INCOMPLETE','UNVERIFIED_DYNAMIC_CODE_EXECUTION'],
 ['worker-import','import {Worker} from "node:worker_threads";new Worker("synthetic")','INCOMPLETE','UNVERIFIED_DYNAMIC_CODE_EXECUTION'],
 ['child-import','import {spawn as launch} from "node:child_process";launch("synthetic")','INCOMPLETE','UNVERIFIED_DYNAMIC_CODE_EXECUTION'],
 ['parser-error','export const =','INCOMPLETE','SOURCE_PARSE_ERROR']
]
for(const [id,text,expected,reason]of directCases)await check(`module-contract-${id}`,()=>{const root=fixture(id,text);const a=audit(root);assert.equal(a.status,expected);if(expected==='FAIL')forbidden(a);if(reason)unknown(a,reason);return a})
for(const shape of ['direct','transitive','nested'])for(const mode of ['require','import'])for(const kind of ['neutral','product','eval','missing-import'])await check(`manifest-runtime-${shape}-${mode}-${kind}`,()=>{
 const root=fixture(`${shape}-${mode}-${kind}`,undefined,'mts','dependencies');const entry=mode==='import'?'entry.mjs':'entry.cjs'
 installed(root,'bridge',entry,shape==='direct'?{}:{dependencies:{successor:'*'}})
 const actor=shape==='direct'?'bridge':shape==='transitive'?'successor':'bridge/node_modules/successor'
 if(shape!=='direct')installed(root,actor,entry)
 const relative=`node_modules/${actor}/${entry}`;const target=path.relative(path.dirname(path.join(root,relative)),path.join(root,'products/shift/payload.js')).replaceAll(path.sep,'/')
 const payload=kind==='neutral'?(mode==='import'?'export const neutral=1':'module.exports=1'):kind==='product'?(mode==='import'?`import ${JSON.stringify(target)}`:`require(${JSON.stringify(target)})`):kind==='eval'?'eval("synthetic")':mode==='import'?'import "./missing.mjs"':'require("./missing.cjs")'
 put(root,relative,'throw new Error("RUNTIME_PAYLOAD_MUST_NOT_EXECUTE");\n'+payload)
 const a=audit(root);unknown(a,'UNVERIFIED_INSTALLED_DEPENDENCY');if(kind==='product')forbidden(a,relative);else assert.equal(a.status,'INCOMPLETE')
 if(kind==='eval')unknown(a,'UNVERIFIED_DYNAMIC_CODE_EXECUTION');if(kind==='missing-import')unknown(a,'UNRESOLVED_MODULE_REFERENCE')
 assert(a.sourceFiles<=5);return a
})
for(const field of ['devDependencies','optionalDependencies','peerDependencies'])await check(`manifest-runtime-field-${field}`,()=>{
 const root=fixture(field,undefined,'mts',field);installed(root);put(root,'node_modules/bridge/entry.cjs','throw new Error("NEVER_EXECUTE");require("../../products/shift/payload.js")');const a=audit(root);forbidden(a,'node_modules/bridge/entry.cjs');return a
})
await check('manifest-require-import-conditions-both-retained',()=>{
 const root=fixture('runtime-conditions',undefined,'mts','dependencies');installed(root,'bridge','entry.cjs',{exports:{require:'./entry.cjs',import:'./import.mjs'}});put(root,'node_modules/bridge/import.mjs','throw new Error("NEVER_EXECUTE");import "../../products/shift/payload.js"');const a=audit(root);forbidden(a,'node_modules/bridge/import.mjs');assert.equal(a.sourceFiles,4);return a
})
await check('manifest-cycle-resource-deduplication',()=>{
 const root=fixture('runtime-cycle',undefined,'mts','dependencies');installed(root,'bridge','entry.cjs',{dependencies:{successor:'*'}});installed(root,'successor','entry.cjs',{dependencies:{bridge:'*'}});put(root,'node_modules/successor/entry.cjs','throw new Error("NEVER_EXECUTE");eval("synthetic")');const start=performance.now(),a=audit(root);unknown(a,'UNVERIFIED_INSTALLED_DEPENDENCY');unknown(a,'UNVERIFIED_DYNAMIC_CODE_EXECUTION');assert.equal(a.sourceFiles,4);assert.equal(a.diagnostics.filter(d=>d.reason==='UNVERIFIED_DYNAMIC_CODE_EXECUTION').length,1);assert(performance.now()-start<5000);return a
})
await check('manifest-long-cycle-remains-finite',()=>{
 const root=fixture('long-cycle',undefined,'mts','dependencies');const count=32;for(let i=0;i<count;i++)installed(root,i===0?'bridge':`successor${i}`,'entry.cjs',{dependencies:{[i===count-1?'bridge':`successor${i+1}`]:'*'}})
 const start=performance.now(),a=audit(root),elapsed_ms=performance.now()-start;assert.equal(a.status,'INCOMPLETE');assert.equal(a.sourceFiles,count+2);assert.equal(a.violations.length,0);assert(elapsed_ms<15000);return {...a,count,elapsed_ms}
})
await check('manifest-missing-entry-remains-unknown',()=>{
 const root=fixture('missing-entry',undefined,'mts','dependencies');installed(root);fs.unlinkSync(path.join(root,'node_modules/bridge/entry.cjs'));const a=audit(root);assert.equal(a.status,'INCOMPLETE');unknown(a,'UNVERIFIED_INSTALLED_DEPENDENCY');return a
})
await check('manifest-native-parse-error-denied',()=>{
 const root=fixture('native-parse-error',undefined,'mts','dependencies');installed(root);put(root,'node_modules/bridge/entry.cjs','const =');const a=audit(root);unknown(a,'SOURCE_PARSE_ERROR');return a
})
for(const kind of ['entry','manifest','nested-actor'])await check(`manifest-symlink-${kind}`,()=>{
 const root=fixture(`symlink-${kind}`,undefined,'mts','dependencies');installed(root);let relative=kind==='entry'?'node_modules/bridge/entry.cjs':kind==='manifest'?'node_modules/bridge/package.json':'node_modules/bridge/inner'
 if(kind==='nested-actor')put(root,relative+'/package.json',{name:'inner'})
 const original=path.join(root,relative);fs.renameSync(original,original+'.physical');fs.symlinkSync(original+'.physical',original)
 let failure;try{audit(root)}catch(error){failure=error.message}assert(failure?.includes('physical_file_required'),failure);return {thrown:failure,fixtureSymlinkTargetWithinOwnedOutput:true}
})
await check('runtime-successor-nested-actor-provenance',()=>{
 const root=fixture('nested-actor-provenance',undefined,'mts','dependencies');installed(root);put(root,'node_modules/bridge/entry.cjs','require("./inner/entry.cjs")');put(root,'node_modules/bridge/inner/package.json',{name:'inner',dependencies:{absent:'file:absent'}});put(root,'node_modules/bridge/inner/entry.cjs','throw new Error("NEVER_EXECUTE")');const a=audit(root);assert.equal(a.status,'INCOMPLETE');assert(a.diagnostics.some(d=>d.file==='node_modules/bridge/inner/package.json'&&d.reason==='UNRESOLVED_INSTALLED_LOCAL_DEPENDENCY'));return a
})
for(const variant of ['types-neutral-runtime-product','types-product-runtime-neutral'])await check(`independent-type-runtime-frontiers-${variant}`,()=>{
 const root=fixture(variant,'import type {Data} from "bridge";export type X=Data','mts','dependencies');installed(root,'bridge','entry.cjs',{types:'index.d.ts'});put(root,'node_modules/bridge/index.d.ts',variant.startsWith('types-neutral')?'export interface Data { value:number }':'export type {Data} from "../../products/shift/type.d.ts"');put(root,'products/shift/type.d.ts','export interface Data { value:number }')
 if(variant.startsWith('types-neutral'))put(root,'node_modules/bridge/entry.cjs','require("../../products/shift/payload.js")')
 const a=audit(root);forbidden(a);assert(a.violations.some(v=>v.trail.includes(variant.startsWith('types-neutral')?'node_modules/bridge/entry.cjs':'node_modules/bridge/index.d.ts')));return a
})
for(const [id,text,exit]of [['cli-pass','export const neutral=1',0],['cli-incomplete','import(target)',1],['cli-fail',`import ${JSON.stringify(product)}`,1]])await check(id,()=>{
 const root=fixture(id,text);const args=[path.join(owned,'source/scripts/check-product-boundary.mjs'),root];const child=spawnSync(process.execPath,args,{cwd:owned,env:process.env,timeout:15000,encoding:'utf8',maxBuffer:1024*1024});assert.equal(child.status,exit,child.stderr);const result=JSON.parse(child.stdout);assert.equal(result.passed,exit===0);return {argv:[process.execPath,...args],exit_status:child.status,stdout:child.stdout,stderr:child.stderr}
})
await check('cli-error-exit-2',()=>{
 const root=fixture('cli-error');put(root,'package.json',{workspaces:'malformed'});const args=[path.join(owned,'source/scripts/check-product-boundary.mjs'),root];const child=spawnSync(process.execPath,args,{cwd:owned,env:process.env,timeout:15000,encoding:'utf8',maxBuffer:1024*1024});assert.equal(child.status,2);assert(child.stderr.includes('invalid_boundary_manifest'));return {argv:[process.execPath,...args],exit_status:child.status,stdout:child.stdout,stderr:child.stderr}
})
save();console.log(JSON.stringify({passed:checks.filter(c=>c.status==='PASS').length,failed:checks.filter(c=>c.status==='FAIL').length}));process.exitCode=checks.some(c=>c.status==='FAIL')?1:0
