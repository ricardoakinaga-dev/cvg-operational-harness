**ACCEPT — exact nine-path security delta, R25 versus R19.**

Independent offline review under `authority.json`; observed 2026-10-05T18:08:01.354067+00:00. No blocking finding was observed in this finite scope. This verdict grants no whole-source, history, CodeQL, production or release approval.

Executed Node v22.23.2 at `/home/ricardo/.nvm/versions/node/v22.23.2/bin/node` with owned physical copies. **96 independent probes, 9 R19 comparison controls and 8 injected resource-failure checks passed.** Seven JavaScript files passed Node 22 syntax checks; two JSON files parsed. Raw commands, stdout/stderr, actual audits, fixture inputs and limitations are retained in this output directory.

**Exact source hashes** (all manifest matches and before/after preservation checks passed):

| Path | Bytes | R25 SHA-256 |
| --- | ---: | --- |
| `scripts/lib/certification-rules.mjs` | 51250 | `355be7b735a5f2735edff79574857a3f0be43176b3720e00882cd25679b51cb1` |
| `tests/certification-summary-ansi-own.test.js` | 3956 | `696d9b8ab6e8e781a91db832f645c1e1f0de8cae85a13434f7fa90ba7a343e4e` |
| `scripts/skip-catalog.json` | 16147 | `7f727bd9407a418bf7fb58679ad59976c26d07cd5c09809d1d493ff7fd42740e` |
| `scripts/hiso-baseline-inventory.json` | 88239 | `59ee0a8b39423b2ad642d522568e9d9b4c2064253892b9bfa6a531d9223e2bb5` |
| `tests/hiso-ci-scopes.test.js` | 69196 | `b33b84065ebade07071fa13fea70f7424d2573d507b59e0b5ee471f2cc0c3097` |
| `scripts/boundary-lexical.mjs` | 19412 | `6aed88995d5509aa7b2bd8814f66363f42e287bc5081d75b4c27dbf9ac9e71e9` |
| `scripts/check-product-boundary.mjs` | 57089 | `8527e3b1c520ef96de60c71d8adf932c08ac4db2d736ee4c05d83266cb24083a` |
| `tests/product-boundary-binding-query.test.js` | 15190 | `5f37e8f0420516d537eedbddc1365cfbea4ee386316fb313fe5a0a88f2171b45` |
| `tests/product-boundary-manifest-runtime.test.js` | 13052 | `3bb6440a1314227b7e5bdd08e43e52a2fce63705a9754076dc7c2d9eba782a9f` |

R19 comparison hashes, physical-file identity, owned/scanner-copy matches and final preservation are recorded in [hashes-after.json](hashes-after.json); the complete finite diffs are under `diffs/`. Three added test paths were absent in R19, as explicitly recorded.

**Strict scanner evidence.** Fresh Gitleaks 8.28.0 scans used explicit [strict-gitleaks.toml](strict-gitleaks.toml), default rules, an empty ignore file, no baseline, no custom allowlist, no file-size limit and `--ignore-gitleaks-allow`. Raw and depth-2 decoded scans both exited 0 with `[]`; each reported exactly 333,531 source bytes and no globally skipped input paths. The synthetic GitHub-token control exited 1 with one `github-pat` finding. Exact argv, environment, config and tool hashes are in [gitleaks-verification.json](gitleaks-verification.json).

The producer directory has **no command/config metadata**: argv, effective config/config hash, scanner version/binary hash, environment overrides, ignore/baseline provenance and numeric exit status are missing. Its `[]` and no-leaks log do not authenticate strictness. Independent explicit-config reruns replace that evidence for this delta; they do not reconstruct or authenticate the original producer invocation. Built-in scanner rule/allowlist behavior remains a limitation.

**Observed behavior.** Property and destructuring labels avoid semantic queries while receiver, renamed, shorthand, export and computed-key bindings remain intact. All four necessary lexical query failures create distinct cached unavailable identities, make the real core caller `INCOMPLETE`, and preserve an error cause when no reporter exists. Unrelated errors still propagate. Actual installed TypeScript property/label sites were independently selected and queried on an owned copy.

Manifest-resolved direct, transitive and nested runtime files, all four dependency fields, and both require/import conditions are inspected. Product edges produce `FAIL` with source trails; eval, worker, vm, child-process, nonliteral imports and unresolved imports preserve blocking uncertainty. Installed neutral dependencies remain `INCOMPLETE`. Missing entrypoints, syntax failures, symlink provenance and nested actor metadata fail closed. R19 controls demonstrate that these probes detect the previously uninspected runtime successors.

Resolver child limits are 30 seconds/16 MiB; native syntax child limits are 10 seconds/1 MiB, with no shell. Injected nonzero, timeout, buffer-budget, malformed/partial/wrong-type resolver output and syntax-worker timeout results all stayed `INCOMPLETE`. A measured 32-actor cycle terminated with 34 source files; each frontier was deduplicated. These are finite observations and fault injections, not arbitrary-input availability guarantees.

OSC/CSI normalization preserves the first failing summary and refuses incomplete OSC. The actual certification evidence caller rejects normalized failure, missing summary and nonzero exit, and accepts a synthetic well-bound decorated passing control without any database execution. OSC samples reached 1,048,576 strings/prefixes and 6,291,497 bytes. All 35 skip entries and policies are unchanged; four hash corrections match unchanged R19 source. Only three concrete test paths were added to the inventory (46 → 49); the 371-test original baseline is unchanged.

**Raw checks and reproduction artifacts:**

- [Independent probe results](probe-results.json), [command](probes-command.json), [stdout](probes.stdout.log), [trusted probe program](probes.mjs).
- [R19 comparison controls](comparison-results.json), [command](comparison-command.json), [trusted comparison program](comparison-probes.mjs).
- [Resource-failure injections](resource-failure-results.json), [command](resource-failure-command.json), [trusted fault-injection program](resource-failure-probes.mjs).
- [Syntax checks](syntax-checks.json), [catalog/inventory checks](catalog-inventory-check.json), [fixture manifest](fixture-manifest.json), [full machine-readable report](report.json).

An initial scanner CLI mistake scanned the broader owned output directory and found the synthetic control. Its raw records are preserved as `gitleaks-invalid-*` and are excluded from the verdict. Corrected isolated-target runs supply the accepted evidence.

**Limitations and boundaries:**

- Verdict applies only to the exact nine R25 source deltas versus R19, under authority.json; it is not whole-source, historical, CodeQL, deployment, production or release approval.
- R25 supplies input-manifest.json, gitleaks.json=[] and a no-leaks log with matching byte count, but no producer argv, effective config or config hash, tool version/binary hash, environment overrides, ignore/baseline provenance, or numeric exit status. Original strict configuration cannot be reconstructed from those files. Fresh independent explicit-config scan supplies security-delta evidence without attributing that configuration to the producer.
- Gitleaks default rules and their built-in allowlists remain upstream behavior. No custom rules/allowlists, repository config, baseline, enabled-rule restriction or gitleaks:allow suppression was used. No exact-nine path was skipped. A source scanner and positive control do not establish absence of all possible secrets or dependency vulnerabilities.
- Copied TypeScript 6.0.3, semver 7.7.4 and zod 4.3.6 from readonly R19 were used as trusted installed tooling. No dependency installation, advisory lookup or supply-chain approval was performed.
- The three added Vitest files and the one changed HISO test were inspected and syntax checked; the original Vitest/native certification/full HISO suites were not run. Independently authored probes ran against owned physical copies of the actual changed modules and their unchanged R19 direct helpers.
- Checker-exhaustion and resolver/syntax-worker timeout, output-budget and malformed-output cases were injected faults, not induced production hangs or real OS resource exhaustion. OSC timings and the 32-actor cycle are measured finite samples, not guarantees for arbitrary repository/AST/log sizes.
- Scope is the existing module-reference/dynamic-acquisition contract. The checker is a static gate, not a general hostile-JavaScript sandbox or proof over every possible JavaScript runtime behavior.
- Fixture payloads remained inert text; only trusted analyzer/parser code, Node resolution and Node --check ran. No default Root governance, prior critic judgments, private env/key content, network/provider/PG, installs, subagents, source writes or R25-chain process control were used. The R25 chain and its descendants were not inspected or operated.
- Existing immutable-baseline scanner observations are outside this delta and were not adjudicated. Readonly helpers and the four catalog-referenced R19 files were inspected only to connect changed behavior and validate exact finite hash corrections.

All outputs were written exclusively here. The nine R25 files, their R19 baselines/recorded absence, authority and supplied scanner files remained unchanged. No remediation is required for this scoped delta; downstream gates retain their own authority and unresolved evidence.
