import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import {createRequire,syncBuiltinESMExports} from 'node:module'
import {auditProductBoundary} from './source/scripts/check-product-boundary.mjs'
const out=path.dirname(new URL(import.meta.url).pathname),require=createRequire(import.meta.url),cp=require('node:child_process'),actual=cp.spawnSync,rows=[]
for(const [id,result]of [
 ['resolver-nonzero',{status:1,stdout:'',stderr:'synthetic resolver error'}],
 ['resolver-timeout',{status:null,signal:'SIGTERM',error:Object.assign(new Error('synthetic timeout'),{code:'ETIMEDOUT'}),stdout:''}],
 ['resolver-output-budget',{status:null,signal:'SIGTERM',error:Object.assign(new Error('synthetic budget exceeded'),{code:'ENOBUFS'}),stdout:''}],
 ['resolver-bad-json',{status:0,stdout:'{incomplete'}],
 ['resolver-wrong-shape',{status:0,stdout:'{}'}],
 ['resolver-partial-frontier',{status:0,stdout:'[]'}],
 ['resolver-invalid-types',{status:0,stdout:'[123,false]'}]
]){
 let calls=0
 cp.spawnSync=(exe,args,opts)=>{
 if(args.includes('--check'))return actual(exe,args,opts)
 calls++;assert.equal(exe,process.execPath);assert.equal(opts.timeout,30000);assert.equal(opts.maxBuffer,16*1024*1024);assert(!opts.shell);assert(args.includes('--experimental-import-meta-resolve'));return result
 };syncBuiltinESMExports()
 try{
 const a=auditProductBoundary(path.join(out,'fixtures/direct-require-neutral'))
 assert.equal(a.status,'INCOMPLETE');assert.equal(a.passed,false);assert(a.diagnostics.some(d=>d.reason==='UNVERIFIED_INSTALLED_RUNTIME_RESOLUTION'));assert(calls>0)
 rows.push({id,status:'PASS',resolverCalls:calls,simulated_result:{...result,error:result.error?{code:result.error.code,message:result.error.message}:undefined},audit:a})
 }finally{cp.spawnSync=actual;syncBuiltinESMExports()}
}
let syntaxCalls=0
cp.spawnSync=(exe,args,opts)=>{
 if(!args.includes('--check'))return actual(exe,args,opts)
 syntaxCalls++;assert.equal(opts.timeout,10000);assert.equal(opts.maxBuffer,1024*1024);assert(!opts.shell);return {status:null,error:Object.assign(new Error('synthetic syntax timeout'),{code:'ETIMEDOUT'}),stdout:'',stderr:''}
};syncBuiltinESMExports()
try{
 const a=auditProductBoundary(path.join(out,'fixtures/direct-require-neutral'));assert.equal(a.status,'INCOMPLETE');assert.equal(a.passed,false);assert(a.diagnostics.some(d=>d.reason==='SOURCE_PARSE_ERROR'));assert(syntaxCalls>0);rows.push({id:'syntax-worker-timeout',status:'PASS',syntaxCalls,audit:a})
}finally{cp.spawnSync=actual;syncBuiltinESMExports()}
fs.writeFileSync(path.join(out,'resource-failure-results.json'),JSON.stringify({node:process.version,fixturePayloadsExecuted:false,simulation:true,checks:rows},null,2)+'\n');console.log(JSON.stringify({passed:rows.length,failed:0,simulation:true}))
