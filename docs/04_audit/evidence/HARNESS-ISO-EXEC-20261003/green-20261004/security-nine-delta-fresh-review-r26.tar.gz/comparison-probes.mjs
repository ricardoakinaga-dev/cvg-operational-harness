import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {createRequire} from 'node:module'
import {auditProductBoundary as currentAudit} from './source/scripts/check-product-boundary.mjs'
import {auditProductBoundary as priorAudit} from './source/r19/scripts/check-product-boundary.mjs'
import {parseVitestSummary as currentParse} from './source/scripts/lib/certification-rules.mjs'
import {parseVitestSummary as priorParse} from './source/r19/scripts/lib/certification-rules.mjs'
import {createBoundaryLexical as currentLexical} from './source/scripts/boundary-lexical.mjs'
import {createBoundaryLexical as priorLexical} from './source/r19/scripts/boundary-lexical.mjs'
const out=path.dirname(new URL(import.meta.url).pathname),require=createRequire(path.join(out,'source/scripts/check-product-boundary.mjs')),ts=require('typescript'),rows=[]
for(const id of ['direct-require-product','transitive-import-product','nested-require-product','runtime-conditions','direct-require-eval','direct-require-missing-import']){
 const root=path.join(out,'fixtures',id),before=priorAudit(root),after=currentAudit(root)
 const expected=id.includes('product')||id==='runtime-conditions'?'CORE_DEPENDS_ON_PRODUCT':id.endsWith('eval')?'UNVERIFIED_DYNAMIC_CODE_EXECUTION':'UNRESOLVED_MODULE_REFERENCE'
 const reasons=a=>[...a.violations,...a.diagnostics].map(r=>r.reason)
 assert(!reasons(before).includes(expected));assert(reasons(after).includes(expected));assert.notEqual(before.status,'PASS');assert.notEqual(after.status,'PASS');rows.push({id,expected,before,after})
}
for(const [id,log]of [['first-OSC-failure','\x1b]0;title with spaces\x07Tests 1 failed (1)\nTests 999 passed (999)'],['unfinished-OSC','\x1b]0;unterminated\nTests 999 passed (999)']]){
 const before=priorParse(log,'Tests'),after=currentParse(log,'Tests');assert.equal(before.passed,999);if(id==='unfinished-OSC')assert.equal(after,null);else assert.equal(after.failed,1);rows.push({id,before,after})
}
const s=ts.createSourceFile('/owned/inert.mts','const handle=unknown;handle',ts.ScriptTarget.Latest,true)
let ref;const visit=n=>{if(ts.isIdentifier(n)&&ts.isExpressionStatement(n.parent))ref=n;ts.forEachChild(n,visit)};visit(s)
const error=new RangeError('Maximum call stack size exceeded'),facade={...ts,createProgram(...args){const checker=ts.createProgram(...args).getTypeChecker();return {getTypeChecker:()=>new Proxy(checker,{get(t,k){return k==='getSymbolAtLocation'?()=>{throw error}:t[k]}})}}}
const diagnostics=[];let before;try{priorLexical(facade,s,false,d=>diagnostics.push(d)).identity(ref)}catch(e){before={name:e.name,message:e.message}}assert.equal(before.name,'RangeError');assert.equal(diagnostics.length,0)
const after=currentLexical(facade,s,false,d=>diagnostics.push(d)).identity(ref);assert.equal(after.unavailable.reason,'UNAVAILABLE_LEXICAL_BINDING_ANALYSIS');assert.equal(diagnostics.length,1);rows.push({id:'necessary-query-exhaustion',before,after,diagnostics})
fs.writeFileSync(path.join(out,'comparison-results.json'),JSON.stringify({node:process.version,fixturePayloadsExecuted:false,knownBadControls:rows.length,rows},null,2)+'\n');console.log(JSON.stringify({knownBadControls:rows.length,allPassed:true}))
