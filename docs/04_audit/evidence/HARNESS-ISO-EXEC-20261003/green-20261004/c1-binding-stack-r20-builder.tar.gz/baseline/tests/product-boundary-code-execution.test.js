// @vitest-environment node
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { pathToFileURL } from 'node:url'
import { spawnSync } from 'node:child_process'
import { afterEach, describe, expect, it } from 'vitest'
import { auditProductBoundary } from '../scripts/check-product-boundary.mjs'
const roots = []
function fixture(source, extension = 'cjs') {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'cvg-code-frontier-'))
  roots.push(root)
  const write = (rel, text) => {
    const p = path.join(root, rel)
    fs.mkdirSync(path.dirname(p), { recursive: true })
    fs.writeFileSync(p, text)
  }
  write(
    'package.json',
    JSON.stringify({ workspaces: ['packages/*', 'products/*'] })
  )
  write('packages/core/package.json', '{"name":"@neutral/core"}')
  write('products/shift/package.json', '{"name":"@private/shift"}')
  const target = path.join(root, 'products/shift/src/marker.cjs')
  write(
    'products/shift/src/marker.cjs',
    'console.log("SYNTHETIC_PRODUCT_LOADED");module.exports=1;\n'
  )
  const file = 'packages/core/src/index.' + extension
  write(file, source(target))
  return { root, core: path.join(root, file), target }
}
afterEach(() => {
  for (const root of roots.splice(0))
    fs.rmSync(root, { recursive: true, force: true })
})
const j = JSON.stringify
const nativeCases = [
  ['eval', (target) => `eval(${j('require(' + j(target) + ')')});`],
  [
    'Function',
    (target) =>
      `Function(${j('return import(' + j(pathToFileURL(target).href) + ')')})();`
  ],
  [
    'childProcess',
    (target) =>
      `require('node:child_process').execFileSync(process.execPath,[${j(target)}],{stdio:'inherit'});`
  ],
  [
    'Worker',
    (target) => `new(require('node:worker_threads').Worker)(${j(target)});`
  ],
  [
    'vm',
    (target) =>
      `const vm=require('node:vm');vm.runInThisContext(${j('import(' + j(pathToFileURL(target).href) + ')')},{importModuleDynamically:vm.constants.USE_MAIN_CONTEXT_DEFAULT_LOADER});`
  ]
]
describe('unknown code execution cannot certify the product frontier', () => {
  it.each(nativeCases)(
    'refuses %s while Node demonstrably loads the synthetic product',
    (name, source) => {
      const f = fixture(source),
        audit = auditProductBoundary(f.root)
      const native = spawnSync(process.execPath, [f.core], {
        cwd: f.root,
        env: {
          PATH: path.dirname(process.execPath) + ':/usr/bin:/bin',
          HOME: process.env.HOME
        },
        encoding: 'utf8',
        timeout: 10000
      })
      expect(native.status).toBe(0)
      expect(native.stdout).toContain('SYNTHETIC_PRODUCT_LOADED')
      expect(audit.passed).toBe(false)
      expect(
        audit.diagnostics.some(
          (e) => e.reason === 'UNVERIFIED_DYNAMIC_CODE_EXECUTION'
        )
      ).toBe(true)
    }
  )
  it.each([
    'const execute=eval;execute("1")',
    'let execute;execute=Function;execute("return 1")()',
    'const execute=Function.bind(null);execute("return 1")()',
    'const {execFileSync:run}=require("node:child_process");run("node",[])',
    'const {Worker:Start}=require("node:worker_threads");new Start("unknown")',
    'const {compileFunction:compile}=require("node:vm");compile("return 1")',
    'const {constructor:Compile}=()=>{};Compile("return 1")()',
    'const Compile=Object.getPrototypeOf(()=>{}).constructor;Compile("return 1")()',
    'const read=Reflect.get;const Compile=read(()=>{},"constructor");Compile("return 1")()',
    'const read=Object.getOwnPropertyDescriptor;read(()=>{},"constructor")',
    'const f=()=>{};f.constructor("return 1")()',
    '(()=>{})["con"+"structor"]("return 1")()',
    'const p=require("node:child_process");exported=p.execFileSync;exported("unknown",[])',
    'export {execFileSync as run} from "node:child_process"',
    'export * from "node:vm"',
    'import * as p from "node:worker_threads";export const start=p.Worker',
    'import {runInThisContext as run} from "node:vm";run("1")',
    'export const compile=Function',
    'export const host=require("node:vm")'
  ])('keeps alias, reflection and export unknown: %s', (source) => {
    const f = fixture(() => source, 'mts')
    expect(auditProductBoundary(f.root).passed).toBe(false)
  })
  it.each([
    'const data={eval:"label",Function:"label"};export const label=data.eval',
    'export class Neutral {constructor(){this.value=1}}',
    'import type {Worker} from "node:worker_threads";export type Type=Worker',
    'export type Type=typeof Function;export const neutral=1',
    'import {isMainThread} from "node:worker_threads";export const value=isMainThread',
    'export {isMainThread} from "node:worker_threads"',
    'export const value=Object.keys({synthetic:1})',
    'const x={synthetic:1};export const value=Object.freeze(x)'
  ])('retains a neutral or erased positive: %s', (source) => {
    const f = fixture(() => source, 'mts')
    expect(auditProductBoundary(f.root).passed).toBe(true)
  })
})
