import { afterEach, describe, expect, it } from 'vitest'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { auditProductBoundary } from '../scripts/check-product-boundary.mjs'

const roots = []
const checker = path.resolve('scripts/check-product-boundary.mjs')
function cli(root) {
  const result = spawnSync(process.execPath, [checker, root], {
    encoding: 'utf8',
    timeout: 30000
  })
  expect(result.stderr).toBe('')
  return { status: result.status, audit: JSON.parse(result.stdout) }
}
function fixture() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'cvg-product-boundary-'))
  roots.push(root)
  const write = (file, value) => {
    fs.mkdirSync(path.dirname(path.join(root, file)), { recursive: true })
    fs.writeFileSync(path.join(root, file), value)
  }
  write(
    'package.json',
    JSON.stringify({
      workspaces: ['packages/*', 'products/*', 'legacy/packages/*']
    })
  )
  write(
    'tsconfig.base.json',
    JSON.stringify({
      compilerOptions: {
        module: 'NodeNext',
        moduleResolution: 'NodeNext',
        baseUrl: '.',
        paths: {
          '@private/product': ['products/shift/src/index.ts'],
          '@neutral/core': ['packages/core/src/index.ts']
        }
      }
    })
  )
  write('packages/core/package.json', JSON.stringify({ name: '@neutral/core' }))
  write('packages/core/src/index.ts', 'export const run = () => 1\n')
  write(
    'products/shift/package.json',
    JSON.stringify({ name: '@private/product' })
  )
  write(
    'products/shift/src/index.ts',
    "import { run } from '@neutral/core'\nexport const use = run\n"
  )
  return { root, write }
}
afterEach(() => {
  for (const root of roots.splice(0))
    fs.rmSync(root, { recursive: true, force: true })
})

describe('harness product boundary', () => {
  it.each([
    [
      'mjs',
      "import {createRequire} from 'node:module';import.meta.url=new URL('../../../tools/anchor.cjs',import.meta.url).href;createRequire(import.meta.url)('./marker.cjs')"
    ],
    [
      'mjs',
      "import {createRequire} from 'node:module';const meta=import.meta;meta['url']=new URL('../../../tools/anchor.cjs',meta.url).href;createRequire(import.meta.url)('./marker.cjs')"
    ],
    [
      'mjs',
      "import {createRequire} from 'node:module';const __filename=new URL('../../../tools/anchor.cjs',import.meta.url).pathname;createRequire(__filename)('./marker.cjs')"
    ],
    [
      'cjs',
      "(function(__filename){require('node:module').createRequire(__filename)('./marker.cjs')})(require('node:path').join(__dirname,'../../../tools/anchor.cjs'))"
    ]
  ])(
    'refuses rebinding of the actual Node loader anchor (%s): %s',
    (kind, source) => {
      const { root, write } = fixture()
      write(
        'products/shift/src/marker.cjs',
        "console.log('SYNTHETIC_PRODUCT_EXECUTED')"
      )
      write('packages/core/src/marker.cjs', 'module.exports=1')
      write('tools/anchor.cjs', 'module.exports=1')
      write('tools/marker.cjs', "require('../products/shift/src/marker.cjs')")
      const entry = `packages/core/src/entry.${kind}`
      write(entry, source)
      const oracle = spawnSync(process.execPath, [path.join(root, entry)], {
        encoding: 'utf8'
      })
      expect(oracle.status).toBe(0)
      expect(oracle.stdout.trim()).toBe('SYNTHETIC_PRODUCT_EXECUTED')
      const audit = auditProductBoundary(root)
      expect(audit.status).toBe('INCOMPLETE')
      expect(
        audit.diagnostics.some(
          (issue) => issue.reason === 'UNVERIFIED_MODULE_LOADER_BASE'
        )
      ).toBe(true)
      expect(cli(root).status).toBe(1)
    }
  )
  it.each([
    ["require(('./neutral.cjs'))", 'cjs'],
    ["await import(('./neutral.cjs'))", 'mjs'],
    ["require.resolve(('./neutral.cjs'))", 'cjs']
  ])(
    'resolves parenthesized literals without losing positive or negative controls: %s',
    (source, kind) => {
      const { root, write } = fixture()
      write('packages/core/src/neutral.cjs', 'module.exports=1')
      const entry = `packages/core/src/entry.${kind}`
      write(entry, source)
      expect(auditProductBoundary(root).status).toBe('PASS')
      expect(cli(root).status).toBe(0)
      write(
        entry,
        source.replace('./neutral.cjs', '../../../products/shift/src/index.ts')
      )
      expect(auditProductBoundary(root).status).toBe('FAIL')
      expect(cli(root).status).toBe(1)
    }
  )
  it.each([
    "globalThis.console.log('synthetic')",
    'globalThis.setTimeout(()=>{}, 1)',
    'globalThis.crypto.randomUUID()',
    'const transport=globalThis.fetch',
    "function require(value){return value};require('./neutral.cjs')"
  ])(
    'accepts a known ordinary Node global without a loader escape: %s',
    (source) => {
      const { root, write } = fixture()
      write('packages/core/src/entry.cjs', source)
      expect(auditProductBoundary(root).status).toBe('PASS')
      expect(cli(root).status).toBe(0)
    }
  )
  it.each([
    "const {process:{getBuiltinModule:get}}=globalThis;get('module').createRequire(__filename)(TARGET)",
    "const host=globalThis;const {process:{getBuiltinModule:get}}=host;const api=get('node:module');const make=api.createRequire;make(__filename)(TARGET)",
    "const {'process':{'getBuiltinModule':get}}=globalThis;const api=get('module');api.createRequire(__filename)(TARGET)",
    "const {['process']:{['getBuiltinModule']:get}}=globalThis;get('module').createRequire(__filename)(TARGET)"
  ])('propagates nested bindings for neutral and product paths: %s', (body) => {
    const { root, write } = fixture()
    write(
      'products/shift/src/marker.cjs',
      'module.exports="SYNTHETIC_PRODUCT_EXECUTED"'
    )
    const target = '../../../products/shift/src/marker.cjs'
    write('packages/core/src/entry.cjs', body.replace('TARGET', "'node:fs'"))
    const neutral = auditProductBoundary(root)
    expect(neutral.status).toBe('PASS')
    expect(cli(root).audit).toEqual(neutral)
    // Exercise the original statements without changing their bindings.
    const executable = body.replace('TARGET', JSON.stringify(target))
    const last = executable.lastIndexOf(';')
    write(
      'packages/core/src/entry.cjs',
      `${executable.slice(0, last + 1)}console.log(${executable.slice(last + 1)})`
    )
    const oracle = spawnSync(
      process.execPath,
      [path.join(root, 'packages/core/src/entry.cjs')],
      { encoding: 'utf8' }
    )
    expect(oracle.status).toBe(0)
    expect(oracle.stdout.trim()).toBe('SYNTHETIC_PRODUCT_EXECUTED')
    const rejected = auditProductBoundary(root)
    expect(rejected.status).toBe('FAIL')
    expect(cli(root).audit).toEqual(rejected)
  })
  it.each([
    "const {process:{getBuiltinModule:get}}=globalThis;get('module').createRequire(__filename)(target)",
    "const {process:{mainModule:host}}=globalThis;host.require('node:fs')",
    'const {process:{mainModule:{require:load}}}=globalThis;load(target)',
    "const {process:{getBuiltinModule:get=unknown}}=globalThis;get('module').createRequire(__filename)('node:fs')",
    "const {process:{...host}}=globalThis;host.getBuiltinModule('module')",
    "const key='getBuiltinModule';const {process:{[key]:get}}=globalThis;get('module')",
    'const {process:[first]}=globalThis;first(target)',
    'const {process:{binding:get}}=globalThis;get(target)',
    "const {process:{getBuiltinModule:{call:invoke}}}=globalThis;invoke(process,'module').createRequire(__filename)(target)",
    "const {process:{getBuiltinModule:{bind:bindGetter}}}=globalThis;bindGetter(process)('module').createRequire(__filename)(target)"
  ])('refuses unknown nested capability semantics: %s', (source) => {
    const { root, write } = fixture()
    write('packages/core/src/entry.cjs', source)
    const audit = auditProductBoundary(root)
    expect(audit.status).toBe('INCOMPLETE')
    expect(audit.diagnostics.length).toBeGreaterThan(0)
    expect(cli(root).audit).toEqual(audit)
  })
  it('visits a nested capability inside a physical npm dependency', () => {
    const { root, write } = fixture()
    write(
      'node_modules/bridge/package.json',
      JSON.stringify({
        name: 'bridge',
        main: 'index.cjs',
        types: 'index.d.cts'
      })
    )
    write(
      'node_modules/bridge/index.d.cts',
      'export declare const value: unknown'
    )
    write(
      'node_modules/bridge/index.cjs',
      "const {process:{getBuiltinModule:get}}=globalThis;get('module').createRequire(__filename)('../../products/shift/src/marker.cjs')"
    )
    write('products/shift/src/marker.cjs', 'module.exports=1')
    write('packages/core/src/entry.cjs', "require('bridge')")
    const audit = auditProductBoundary(root)
    expect(audit.status).toBe('FAIL')
    expect(
      audit.violations.some((issue) =>
        issue.trail.includes('node_modules/bridge/index.cjs')
      )
    ).toBe(true)
    expect(cli(root).audit).toEqual(audit)
  })
  it.each(['import', 'require'])(
    'visits transitive physical npm runtime and types with %s conditions',
    (mode) => {
      const { root, write } = fixture()
      write(
        'node_modules/bridge/package.json',
        JSON.stringify({
          name: 'bridge',
          type: 'module',
          exports: {
            '.': {
              types: './index.d.mts',
              import: './index.mjs',
              require: './index.cjs'
            }
          }
        })
      )
      write(
        'node_modules/bridge/index.d.mts',
        'export declare const value:number'
      )
      write('node_modules/bridge/index.mjs', "import 'leaf'")
      write('node_modules/bridge/index.cjs', "require('leaf')")
      write(
        'node_modules/leaf/package.json',
        JSON.stringify({ name: 'leaf', main: 'index.cjs' })
      )
      write('node_modules/leaf/index.cjs', 'module.exports=1')
      write(
        'packages/core/src/entry.mjs',
        mode === 'import'
          ? "import 'bridge'"
          : "import {createRequire} from 'node:module';createRequire(import.meta.url)('bridge')"
      )
      let audit = auditProductBoundary(root)
      expect(audit.status).toBe('PASS')
      expect(cli(root).audit).toEqual(audit)
      write(
        'node_modules/leaf/index.cjs',
        "require('../../products/shift/src/index.ts')"
      )
      audit = auditProductBoundary(root)
      expect(audit.status).toBe('FAIL')
      expect(
        audit.violations.some(
          (issue) =>
            issue.trail.includes('node_modules/leaf/index.cjs') &&
            issue.trail.includes(
              `node_modules/bridge/index.${mode === 'import' ? 'mjs' : 'cjs'}`
            )
        )
      ).toBe(true)
      expect(cli(root).audit).toEqual(audit)
      // Neutral runtime must not hide a product reference in physical types.
      write('node_modules/leaf/index.cjs', 'module.exports=1')
      write(
        'node_modules/bridge/index.d.mts',
        "export * from '../../products/shift/src/index.ts'"
      )
      audit = auditProductBoundary(root)
      expect(
        audit.violations.some((issue) =>
          issue.trail.includes('node_modules/bridge/index.d.mts')
        )
      ).toBe(true)
      expect(cli(root).audit).toEqual(audit)
    }
  )
  it('walks transitive physical type-only npm closure without loading its runtime', () => {
    const { root, write } = fixture()
    write(
      'node_modules/bridge/package.json',
      JSON.stringify({
        name: 'bridge',
        types: 'index.d.ts',
        main: 'missing.cjs'
      })
    )
    write('node_modules/bridge/index.d.ts', "export type {Value} from 'leaf'")
    write(
      'node_modules/leaf/package.json',
      JSON.stringify({ name: 'leaf', types: 'index.d.ts' })
    )
    write('node_modules/leaf/index.d.ts', 'export interface Value {id:string}')
    write('packages/core/src/entry.ts', "import type {Value} from 'bridge'")
    expect(auditProductBoundary(root).status).toBe('PASS')
    write(
      'node_modules/leaf/index.d.ts',
      "export type {Value} from '../../products/shift/src/types.d.ts'"
    )
    write('products/shift/src/types.d.ts', 'export interface Value {id:string}')
    const audit = auditProductBoundary(root)
    expect(
      audit.violations.some(
        (issue) =>
          issue.trail.includes('node_modules/bridge/index.d.ts') &&
          issue.trail.includes('node_modules/leaf/index.d.ts')
      )
    ).toBe(true)
    expect(cli(root).audit).toEqual(audit)
  })
  it.each([
    ['require(target)', 'NON_LITERAL_MODULE_REFERENCE'],
    ["require('./missing.cjs')", 'UNRESOLVED_MODULE_REFERENCE'],
    ["require('./native.node')", 'UNVERIFIED_MODULE_FORMAT'],
    [
      "const api=process.getBuiltinModule('module');api.registerHooks({})",
      'UNVERIFIED_MODULE_LOADER_PRIMITIVE'
    ]
  ])('refuses unknown physical npm closures: %s', (source, reason) => {
    const { root, write } = fixture()
    write(
      'node_modules/bridge/package.json',
      JSON.stringify({
        name: 'bridge',
        main: 'index.cjs',
        types: 'index.d.cts'
      })
    )
    write(
      'node_modules/bridge/index.d.cts',
      'export declare const value:number'
    )
    write('node_modules/bridge/index.cjs', source)
    write(
      'node_modules/bridge/native.node',
      'synthetic native module; never executed'
    )
    write('packages/core/src/entry.cjs', "require('bridge')")
    const audit = auditProductBoundary(root)
    expect(audit.status).toBe('INCOMPLETE')
    expect(
      audit.diagnostics.some(
        (issue) =>
          issue.reason === reason &&
          issue.file.startsWith('node_modules/bridge/')
      )
    ).toBe(true)
    expect(cli(root).audit).toEqual(audit)
  })
  it('deduplicates cycles in physical npm closure and still finds a product witness', () => {
    const { root, write } = fixture()
    write(
      'node_modules/bridge/package.json',
      JSON.stringify({ name: 'bridge', main: 'index.cjs' })
    )
    write('node_modules/bridge/index.cjs', "require('./cycle.cjs')")
    write('node_modules/bridge/cycle.cjs', "require('./index.cjs')")
    write('packages/core/src/entry.cjs', "require('bridge')")
    expect(auditProductBoundary(root).status).toBe('PASS')
    write(
      'node_modules/bridge/cycle.cjs',
      "require('./index.cjs');require('../../products/shift/src/index.ts')"
    )
    const audit = auditProductBoundary(root)
    expect(audit.status).toBe('FAIL')
    expect(
      audit.violations.some((issue) =>
        issue.trail.includes('node_modules/bridge/cycle.cjs')
      )
    ).toBe(true)
    expect(cli(root).audit).toEqual(audit)
  })
  it.each([
    "const api=process.getBuiltinModule('module'); const make=api.createRequire; const load=make(__filename);const again=load;again(TARGET)",
    "const p=process;const get=p.getBuiltinModule;const api=get('module');const {createRequire:make}=api;make(__filename)(TARGET)",
    "const {getBuiltinModule:get}=process; const api=get('module');const load=api['createRequire'](__filename);const {resolve:find}=load;find(TARGET)",
    "const p=globalThis.process;const api=p['getBuiltinModule']('module');const load=api.createRequire(__filename);const find=load.resolve;find(TARGET)",
    "const p=process.getBuiltinModule('process');const api=p.getBuiltinModule('module');api.createRequire(__filename)(TARGET)",
    "const g=globalThis;const p=g.process;const api=p.getBuiltinModule('module');api.createRequire(__filename)(TARGET)",
    "const {process:p}=globalThis;const api=p.getBuiltinModule('module');api.createRequire(__filename)(TARGET)",
    "const p=require('node:process');const api=p.getBuiltinModule('module');api.createRequire(__filename)(TARGET)",
    "const {'getBuiltinModule':get}=process;const {'createRequire':make}=get('module');make(__filename)(TARGET)",
    "import p from 'node:process';const api=p.getBuiltinModule('module');api.createRequire(import.meta.url)(TARGET)",
    "import {getBuiltinModule as get} from 'node:process';get('module').createRequire(import.meta.url).resolve(TARGET)",
    "import * as p from 'node:process';const {createRequire:make}=p.getBuiltinModule('module');make(import.meta.url)(TARGET)",
    "import * as p from 'node:process';p.default.getBuiltinModule('module').createRequire(import.meta.url)(TARGET)",
    "import {default as p} from 'node:process';p.getBuiltinModule('module').createRequire(import.meta.url)(TARGET)",
    "import * as p from 'node:process';const {default:{getBuiltinModule:get}}=p;get('module').createRequire(import.meta.url)(TARGET)",
    "import * as p from 'node:process';const {['default']:host}=p;host.getBuiltinModule('module').createRequire(import.meta.url)(TARGET)",
    "import * as m from 'node:module';m.default.createRequire(import.meta.url)(TARGET)",
    "import {default as m} from 'node:module';m.createRequire(import.meta.url)(TARGET)",
    'const {require:load}=module;load(TARGET)',
    'const {resolve:find}=require;find(TARGET)',
    'import.meta.resolve(TARGET)',
    'const find=import.meta.resolve;const alias=find;alias(TARGET)',
    'const meta=import.meta;const find=meta.resolve;find(TARGET)',
    'const {resolve:find}=import.meta;find(TARGET)',
    'const meta=import.meta;const {resolve:find}=meta;find(TARGET)'
  ])(
    'propagates Node22 capabilities and preserves neutral targets: %s',
    (source) => {
      const { root, write } = fixture()
      const entry =
        source.includes('import ') || source.includes('import.meta')
          ? 'entry.mjs'
          : 'entry.cjs'
      write('packages/core/src/data.cjs', 'module.exports=1')
      write(
        `packages/core/src/${entry}`,
        source.replace('TARGET', "'./data.cjs'")
      )
      expect(auditProductBoundary(root).status).toBe('PASS')
      expect(cli(root).status).toBe(0)
      write(
        `packages/core/src/${entry}`,
        source.replace('TARGET', "'../../../products/shift/src/index.ts'")
      )
      const audit = auditProductBoundary(root)
      expect(audit.status).toBe('FAIL')
      expect(audit.violations.length).toBeGreaterThan(0)
      expect(cli(root).audit).toEqual(audit)
    }
  )
  it.each([
    'const get=process.getBuiltinModule;get(name)',
    "import * as p from 'node:process';p.default.getBuiltinModule(name)",
    "import {default as p} from 'node:process';p.getBuiltinModule('module').createRequire(base)('node:fs')",
    "const p=await import('node:process');p.default.getBuiltinModule('module').createRequire(import.meta.url)('node:fs')",
    "const p=process;p[key]('module')",
    "const api=process.getBuiltinModule('module');const key=getProperty();api[key](base)",
    "const api=process.getBuiltinModule('module');api.register('bridge',import.meta.url)",
    "const api=process.getBuiltinModule('module');api._load('bridge')",
    "const api=process.getBuiltinModule('module');const {createRequire:make}=api;const load=make(base);load('node:fs')",
    "const api=process.getBuiltinModule('module');const load=api.createRequire(import.meta.url);load(target)",
    'const get=process.getBuiltinModule;forward(get)',
    "const api=process.getBuiltinModule('module');export {api}",
    "export {getBuiltinModule as get} from 'node:process'",
    "export * from 'node:process'",
    "export * as capabilities from 'node:process'",
    "forward(require('node:process'))",
    'const p=process;forward(p)',
    'process.dlopen(module, target)',
    "const {binding:load}=process;load('module_wrap')",
    "const {['mainModule']:entry}=process;entry.require('node:fs')",
    "const api=process.getBuiltinModule('module');const load=api.createRequire(import.meta.url);forward(load.resolve)",
    "process.mainModule.require('node:fs')",
    "const {mainModule:entry}=process;const {require:load}=entry;load('node:fs')",
    "import {mainModule as entry} from 'node:process';entry.require('node:fs')",
    "module.parent.require('node:fs')",
    "const {...unknown}=process;unknown.getBuiltinModule('module')",
    'const find=import.meta.resolve;find(target)',
    "import.meta.resolve('node:fs',anotherParent)",
    'const find=import.meta.resolve;forward(find)',
    'forward(import.meta)',
    'const meta=import.meta;meta[property](target)',
    'const g=globalThis;g[property](target)',
    "forward(process.getBuiltinModule('process'))"
  ])('returns INCOMPLETE for unsupported Node22 capabilities: %s', (source) => {
    const { root, write } = fixture()
    write('packages/core/src/entry.mjs', source)
    const audit = auditProductBoundary(root)
    expect(audit.status).toBe('INCOMPLETE')
    expect(audit.diagnostics.length).toBeGreaterThan(0)
    expect(cli(root).audit).toEqual(audit)
  })
  it('checks a real Node22 getBuiltinModule load without executing packages during audit', () => {
    const { root, write } = fixture()
    write(
      'node_modules/bridge/package.json',
      JSON.stringify({ name: 'bridge', main: 'index.cjs' })
    )
    write(
      'node_modules/bridge/index.cjs',
      "throw new Error('AUDIT_MUST_NOT_EXECUTE')"
    )
    write(
      'packages/core/src/entry.cjs',
      "const api=process.getBuiltinModule('module');const load=api.createRequire(__filename);console.log(load.resolve('bridge'))"
    )
    expect(auditProductBoundary(root).status).toBe('PASS')
    const run = spawnSync(
      process.execPath,
      [path.join(root, 'packages/core/src/entry.cjs')],
      { encoding: 'utf8' }
    )
    expect(run.status).toBe(0)
    expect(run.stdout.trim()).toBe(
      path.join(root, 'node_modules/bridge/index.cjs')
    )
    expect(cli(root).status).toBe(0)
  })
  it.each([
    "const delegate=require; const api=delegate('node:module'); const fetch=api.createRequire(__filename); fetch('../../../products/shift/src/index.ts')",
    "const {createRequire: make}=module.require('module'); const fetch=make(__filename); fetch('../../../products/shift/src/index.ts')",
    "const current=module; current.require('../../../products/shift/src/index.ts')",
    "const property='require'; module[property]('../../../products/shift/src/index.ts')",
    "const lookup=require.resolve; const lookupAgain=lookup; lookupAgain('../../../products/shift/src/index.ts')"
  ])(
    'rejects loader capability chains through the API and CLI: %s',
    (source) => {
      const { root, write } = fixture()
      write('packages/core/src/entry.cjs', source)
      const audit = auditProductBoundary(root)
      expect(audit.passed).toBe(false)
      expect(
        audit.violations.length + audit.diagnostics.length
      ).toBeGreaterThan(0)
      const result = cli(root)
      expect(result.status).toBe(1)
      expect(result.audit).toEqual(audit)
    }
  )
  it.each([
    [
      "import p from '../products/shift/src/index.ts'; export const value=p",
      'CORE_DEPENDS_ON_PRODUCT'
    ],
    ['export const value=process.env.SHIFT_PORT', 'CONSUMER_ENV_IN_CORE']
  ])('visits runtime hidden by neutral declarations: %s', (runtime, reason) => {
    const { root, write } = fixture()
    write(
      'packages/core/src/entry.mjs',
      "export {value} from '../../../tools/transport.mjs'"
    )
    write('tools/transport.d.mts', 'export declare const value: string')
    write('tools/transport.mjs', runtime)
    const audit = auditProductBoundary(root)
    expect(audit.passed).toBe(false)
    expect(
      [...audit.violations, ...audit.diagnostics].some(
        (issue) => issue.reason === reason
      )
    ).toBe(true)
    expect(cli(root).status).toBe(1)
  })
  it.each(['mjs', 'cjs', 'js'])(
    'walks both type and physical runtime closures for .%s',
    (extension) => {
      const { root, write } = fixture()
      const declaration = { mjs: 'd.mts', cjs: 'd.cts', js: 'd.ts' }[extension]
      write(
        'packages/core/src/entry.cjs',
        `require('../../../tools/adapter.${extension}')`
      )
      write(
        `tools/adapter.${declaration}`,
        'export declare const value: string'
      )
      write(`tools/adapter.${extension}`, "require('../scripts/nested.cjs')")
      write('scripts/nested.cjs', "require('../products/shift/src/index.ts')")
      const audit = auditProductBoundary(root)
      expect(
        audit.violations.some((issue) =>
          issue.trail.includes(`tools/adapter.${extension}`)
        )
      ).toBe(true)
      expect(cli(root).status).toBe(1)
    }
  )
  it('retains the type closure when the runtime is neutral', () => {
    const { root, write } = fixture()
    write('packages/core/src/entry.mjs', "import '../../../tools/schema.mjs'")
    write('tools/schema.mjs', 'export const value=1')
    write(
      'tools/schema.d.mts',
      "export * from '../products/shift/src/index.ts'"
    )
    expect(
      auditProductBoundary(root).violations.some((issue) =>
        issue.trail.includes('tools/schema.d.mts')
      )
    ).toBe(true)
    expect(cli(root).status).toBe(1)
  })
  it.each([
    "const dispatch=require; const api=dispatch('module'); const make=api['createRequire']; const fetch=make(__filename); const again=fetch; again('node:fs')",
    "const {createRequire: make}=module.require('node:module'); make(__filename)('node:fs')",
    "const current=module; const next=current; next['require']('node:fs')",
    "const lookup=require.resolve; const next=lookup; next('node:fs')",
    "const dispatch=require; dispatch('./data.cjs')"
  ])('preserves neutral loader aliases: %s', (source) => {
    const { root, write } = fixture()
    write('packages/core/src/entry.cjs', source)
    write('packages/core/src/data.cjs', 'module.exports=1')
    expect(auditProductBoundary(root).passed).toBe(true)
    expect(cli(root).status).toBe(0)
  })
  it('preserves neutral runtime plus declarations and type-only exports', () => {
    const { root, write } = fixture()
    write('packages/core/src/entry.mjs', "import '../../../tools/schema.mjs'")
    write('tools/schema.mjs', 'export const value=1')
    write('tools/schema.d.mts', 'export declare const value:number')
    write(
      'packages/core/src/type-only.ts',
      "export type {Value} from '../../../tools/types.d.ts'; import type {Module} from 'node:module'; export type {Module} from 'node:module'"
    )
    write('tools/types.d.ts', 'export interface Value {id:string}')
    expect(auditProductBoundary(root).passed).toBe(true)
    expect(cli(root).status).toBe(0)
  })
  it.each([
    "const current=module; const property=getProperty(); current[property]('node:fs')",
    'const lookup=require.resolve; forward(lookup)',
    'const lookup=require.resolve; lookup(target)',
    "const lookup=require.resolve; lookup('some-package',{paths:['/other']})",
    "const delegate=require; const api=delegate('node:module'); const property=getProperty(); api[property](__filename)",
    "const delegate=require; const api=delegate('node:module'); const make=api.createRequire; const fetch=make(base); fetch('node:fs')",
    'const current=module; export {current}'
  ])('fails closed on uncertain capability/anchor/resolution: %s', (source) => {
    const { root, write } = fixture()
    write('packages/core/src/entry.cjs', source)
    const audit = auditProductBoundary(root)
    expect(audit.passed).toBe(false)
    expect(audit.status).toBe('INCOMPLETE')
    expect(audit.diagnostics.length).toBeGreaterThan(0)
    expect(cli(root).status).toBe(1)
  })
  it('rejects declaration-only evidence for a missing runtime', () => {
    const { root, write } = fixture()
    write('packages/core/src/entry.mjs', "import '../../../tools/missing.mjs'")
    write('tools/missing.d.mts', 'export declare const value:number')
    const audit = auditProductBoundary(root)
    expect(audit.passed).toBe(false)
    expect(
      audit.diagnostics.some(
        (issue) => issue.reason === 'UNRESOLVED_RUNTIME_MODULE_REFERENCE'
      )
    ).toBe(true)
    expect(cli(root).status).toBe(1)
  })
  it.each(['import', 'require'])(
    'uses Node %s conditions alongside types for package exports',
    (mode) => {
      const { root, write } = fixture()
      write(
        'tools/utility/package.json',
        JSON.stringify({
          name: 'utility',
          type: 'module',
          exports: {
            '.': {
              types: './types.d.ts',
              import: './esm.mjs',
              require: './common.cjs'
            }
          }
        })
      )
      write('tools/utility/types.d.ts', 'export declare const value:number')
      write(
        'tools/utility/esm.mjs',
        mode === 'import'
          ? "import '../../scripts/bridge.mjs'"
          : 'export const value=1'
      )
      write(
        'tools/utility/common.cjs',
        mode === 'require'
          ? "require('../../scripts/bridge.mjs')"
          : 'module.exports=1'
      )
      fs.mkdirSync(path.join(root, 'node_modules'))
      fs.symlinkSync(
        path.join(root, 'tools/utility'),
        path.join(root, 'node_modules/utility'),
        'dir'
      )
      write('scripts/bridge.mjs', "import '../products/shift/src/index.ts'")
      write(
        'packages/core/src/entry.mjs',
        mode === 'import'
          ? "import 'utility'"
          : "import {createRequire} from 'node:module'; const fetch=createRequire(import.meta.url); fetch('utility')"
      )
      const audit = auditProductBoundary(root)
      expect(
        audit.violations.some((issue) =>
          issue.trail.includes(
            `tools/utility/${mode === 'import' ? 'esm.mjs' : 'common.cjs'}`
          )
        )
      ).toBe(true)
      expect(cli(root).status).toBe(1)
      // The unused Node condition stays outside the resolved closure.
      write(
        'packages/core/src/entry.mjs',
        mode === 'import'
          ? "import {createRequire} from 'node:module'; const fetch=createRequire(import.meta.url); fetch('utility')"
          : "import 'utility'"
      )
      expect(auditProductBoundary(root).passed).toBe(true)
      expect(cli(root).status).toBe(0)
    }
  )
  it('does not substitute a package types implementation for unknown runtime conditions', () => {
    const { root, write } = fixture()
    write(
      'tools/utility/package.json',
      JSON.stringify({
        name: 'utility',
        exports: {
          types: './types.ts',
          import: './missing.mjs',
          require: './missing.cjs'
        }
      })
    )
    write('tools/utility/types.ts', 'export const value=1')
    fs.mkdirSync(path.join(root, 'node_modules'))
    fs.symlinkSync(
      path.join(root, 'tools/utility'),
      path.join(root, 'node_modules/utility'),
      'dir'
    )
    write('packages/core/src/entry.mjs', "import 'utility'")
    let audit = auditProductBoundary(root)
    expect(audit.passed).toBe(false)
    expect(
      audit.diagnostics.some(
        (issue) => issue.reason === 'UNRESOLVED_RUNTIME_MODULE_REFERENCE'
      )
    ).toBe(true)
    expect(cli(root).status).toBe(1)
    write(
      'packages/core/src/entry.mjs',
      "import {createRequire} from 'node:module'; const fetch=createRequire(import.meta.url); fetch('utility')"
    )
    audit = auditProductBoundary(root)
    expect(audit.passed).toBe(false)
    expect(
      audit.diagnostics.some(
        (issue) => issue.reason === 'UNRESOLVED_RUNTIME_MODULE_REFERENCE'
      )
    ).toBe(true)
    expect(cli(root).status).toBe(1)
  })
  it('uses type-only Node import and require conditions without visiting runtime', () => {
    const { root, write } = fixture()
    write(
      'tools/utility/package.json',
      JSON.stringify({
        name: 'utility',
        type: 'module',
        exports: {
          import: { types: './neutral.d.mts', default: './runtime.mjs' },
          require: { types: './restricted.d.cts', default: './runtime.cjs' }
        }
      })
    )
    write('tools/utility/neutral.d.mts', 'export interface Value {id:string}')
    write(
      'tools/utility/restricted.d.cts',
      "export * from '../../products/shift/src/index.ts'"
    )
    write(
      'tools/utility/runtime.mjs',
      "import '../../products/shift/src/index.ts'"
    )
    write('tools/utility/runtime.cjs', 'module.exports=1')
    fs.mkdirSync(path.join(root, 'node_modules'))
    fs.symlinkSync(
      path.join(root, 'tools/utility'),
      path.join(root, 'node_modules/utility'),
      'dir'
    )
    write(
      'packages/core/src/type-only.mts',
      "export type {Value} from 'utility'"
    )
    expect(auditProductBoundary(root).passed).toBe(true)
    expect(cli(root).status).toBe(0)
    fs.unlinkSync(path.join(root, 'packages/core/src/type-only.mts'))
    write(
      'packages/core/src/type-only.cts',
      "export type {Value} from 'utility'"
    )
    expect(
      auditProductBoundary(root).violations.some((issue) =>
        issue.trail.includes('tools/utility/restricted.d.cts')
      )
    ).toBe(true)
    expect(cli(root).status).toBe(1)
  })
  it('keeps explicit TypeScript extension substitution for unbuilt neutral sources', () => {
    const { root, write } = fixture()
    write(
      'packages/core/src/entry.mts',
      "import '../../../tools/implementation.mjs'"
    )
    write('tools/implementation.mts', 'export const value=1')
    write(
      'packages/core/src/typed.ts',
      "import {type Module, createRequire} from 'node:module'; const fetch=createRequire(import.meta.url); fetch('node:fs')"
    )
    expect(auditProductBoundary(root).passed).toBe(true)
    expect(cli(root).status).toBe(0)
  })
  it('resolves stylesheet assets and still rejects product assets', () => {
    const { root, write } = fixture()
    write('packages/core/src/styles.css', 'body { color: black }')
    write('packages/core/src/index.ts', "import './styles.css'")
    expect(auditProductBoundary(root).passed).toBe(true)
    write('products/shift/src/styles.css', 'body { color: black }')
    write(
      'packages/core/src/index.ts',
      "import '../../../products/shift/src/styles.css'"
    )
    expect(auditProductBoundary(root).violations.length).toBeGreaterThan(0)
    write('packages/core/src/index.ts', "import './missing.css'")
    expect(
      auditProductBoundary(root).diagnostics.some(
        (issue) => issue.reason === 'UNRESOLVED_MODULE_REFERENCE'
      )
    ).toBe(true)
  })
  it('allows a product to consume neutral public contracts', () => {
    const { root } = fixture()
    expect(auditProductBoundary(root).passed).toBe(true)
  })
  it.each([
    "import { use } from '../../../products/shift/src/index.ts'",
    "import { use } from '@private/product'",
    "export { use } from '@private/product'",
    "const load = () => import('@private/product')",
    "const load = () => require('@private/product')",
    "type Value = import('@private/product').Value"
  ])('rejects forbidden source reference %s', (source) => {
    const { root, write } = fixture()
    write('packages/core/src/index.ts', source)
    expect(auditProductBoundary(root).violations.length).toBeGreaterThan(0)
  })
  it('rejects a transitive relative reference through legacy code', () => {
    const { root, write } = fixture()
    write(
      'packages/core/src/index.ts',
      "export * from '../../../legacy/packages/bridge/src/index.ts'"
    )
    write(
      'legacy/packages/bridge/src/index.ts',
      "export * from '../../../../products/shift/src/index.ts'"
    )
    const result = auditProductBoundary(root)
    expect(result.violations.some((issue) => issue.trail.length >= 3)).toBe(
      true
    )
  })
  it.each(['scripts/bridge.ts', 'scripts/bridge.d.ts', 'tools/bridge.mjs'])(
    'walks local intermediates outside workspace roots: %s',
    (bridge) => {
      const { root, write } = fixture()
      write('packages/core/src/index.ts', `export * from '../../../${bridge}'`)
      write(bridge, "export * from '../products/shift/src/index.ts'")
      const result = auditProductBoundary(root)
      expect(result.passed).toBe(false)
      expect(
        result.violations.some((issue) => issue.trail.includes(bridge))
      ).toBe(true)
    }
  )
  it('walks declaration reference directives', () => {
    const { root, write } = fixture()
    write(
      'packages/core/src/types.d.ts',
      '/// <reference path="../../../products/shift/src/index.ts" />'
    )
    expect(auditProductBoundary(root).passed).toBe(false)
  })
  it('walks declaration type reference directives', () => {
    const { root, write } = fixture()
    write(
      'products/shift/src/types.d.ts',
      'export interface Patient {id:string}'
    )
    write(
      'packages/core/src/types.d.ts',
      '/// <reference types="../../../products/shift/src/types.d.ts" />'
    )
    expect(auditProductBoundary(root).passed).toBe(false)
  })
  it('rejects consumer environment read through a local script bridge', () => {
    const { root, write } = fixture()
    write(
      'packages/core/src/index.ts',
      "export * from '../../../scripts/config.ts'"
    )
    write('scripts/config.ts', 'export const port=process.env.SHIFT_PORT')
    expect(
      auditProductBoundary(root).diagnostics.some(
        (issue) => issue.reason === 'CONSUMER_ENV_IN_CORE'
      )
    ).toBe(true)
  })
  it.each([
    "import { createRequire } from 'node:module'; const load=createRequire(import.meta.url); load('@private/product')",
    "import { createRequire as cr } from 'module'; const load=cr(import.meta.url); load('@private/product')",
    "import * as moduleApi from 'node:module'; const load=moduleApi.createRequire(import.meta.url); load('@private/product')",
    "import moduleApi from 'node:module'; const load=moduleApi['createRequire'](import.meta.url); load('@private/product')",
    "const {createRequire: cr}=require('node:module'); const load=cr(__filename); load('@private/product')",
    "import { createRequire as cr } from 'node:module'; const make=cr; const load=make(import.meta.url); const alias=load; alias('@private/product')",
    "import { createRequire } from 'node:module'; let load; load=createRequire(import.meta.url); load('@private/product')",
    "import { createRequire } from 'node:module'; createRequire(import.meta.url)('@private/product')",
    "import { createRequire } from 'node:module'; const load=createRequire(import.meta.url); load.resolve('@private/product')",
    "module.require('@private/product')"
  ])('rejects supported module loader references: %s', (source) => {
    const { root, write } = fixture()
    write('packages/core/src/index.ts', source)
    const result = auditProductBoundary(root)
    expect(result.passed).toBe(false)
    expect(result.violations.length).toBeGreaterThan(0)
  })
  it.each([
    "import { createRequire } from 'node:module'; const load=createRequire(import.meta.url); const target='@private/product'; load(target)",
    "import { createRequire } from 'node:module'; const load=createRequire(import.meta.url); load.resolve(target)",
    "import { createRequire } from 'node:module'; const load=createRequire(base); load('node:fs')",
    "import { createRequire } from 'node:module'; const load=createRequire(import.meta.url); invoke(load)",
    "import { createRequire } from 'node:module'; const load=createRequire(import.meta.url); export {load}",
    "import { createRequire } from 'node:module'; export const make=createRequire",
    "import { createRequire } from 'node:module'; export const load=createRequire(import.meta.url)",
    "export {createRequire as make} from 'node:module'",
    "export * from 'node:module'",
    "import {register} from 'node:module'; register('@private/product',import.meta.url)",
    "import * as mod from 'node:module'; mod.register('@private/product',import.meta.url)",
    "import {createRequire} from 'node:module'; function factory(){return createRequire(import.meta.url)}; factory()(target)",
    "const {createRequire}=await import('node:module'); const load=createRequire(import.meta.url); load('@private/product')",
    "function factory(){return require('node:module')}; factory().createRequire(base)(target)",
    "const {register}=require('node:module'); register(target,base)",
    "import * as moduleApi from 'node:module'; const key='createRequire'; const load=moduleApi[key](import.meta.url); load('node:fs')"
  ])('fails closed on unknown/escaping loader capabilities: %s', (source) => {
    const { root, write } = fixture()
    write('packages/core/src/index.ts', source)
    const result = auditProductBoundary(root)
    expect(result.passed).toBe(false)
    expect(result.diagnostics.length).toBeGreaterThan(0)
  })
  it('allows a local anchored loader of neutral modules and builtins', () => {
    const { root, write } = fixture()
    write(
      'packages/core/src/index.ts',
      "import {createRequire as cr} from 'node:module'; const load=cr(import.meta.url); load('node:fs'); load('@neutral/core')"
    )
    expect(auditProductBoundary(root).passed).toBe(true)
  })
  it('distinguishes a policy method named require from a module loader', () => {
    const { root, write } = fixture()
    write(
      'packages/core/src/index.ts',
      'interface Policy {require(action: string): void}; const policy: Policy={require(action){}}; policy.require(action)'
    )
    expect(auditProductBoundary(root).passed).toBe(true)
  })
  it('allows declaration-only domain methods without omitting declarations', () => {
    const { root, write } = fixture()
    write(
      'packages/core/src/types.d.ts',
      'export declare class Policy { private require; }'
    )
    expect(auditProductBoundary(root).passed).toBe(true)
  })
  it('rejects an unused development dependency on the consumer', () => {
    const { root, write } = fixture()
    write(
      'packages/core/package.json',
      JSON.stringify({
        name: '@neutral/core',
        devDependencies: { '@private/product': '1.0.0' }
      })
    )
    expect(auditProductBoundary(root).passed).toBe(false)
  })
  it('rejects a manifest dependency even when unused by sources', () => {
    const { root, write } = fixture()
    write(
      'packages/core/package.json',
      JSON.stringify({
        name: '@neutral/core',
        dependencies: { '@private/product': '1.0.0' }
      })
    )
    expect(auditProductBoundary(root).violations.length).toBeGreaterThan(0)
  })
  it('fails closed on an unknowable dynamic reference', () => {
    const { root, write } = fixture()
    write(
      'packages/core/src/index.ts',
      'export const load = (name: string) => import(name)'
    )
    expect(
      auditProductBoundary(root).diagnostics.some(
        (issue) => issue.reason === 'NON_LITERAL_MODULE_REFERENCE'
      )
    ).toBe(true)
  })
  it('rejects consumer environment keys in core', () => {
    const { root, write } = fixture()
    write(
      'packages/core/src/index.ts',
      'export const port = process.env.SHIFT_PORT'
    )
    expect(
      auditProductBoundary(root).diagnostics.some(
        (issue) => issue.reason === 'CONSUMER_ENV_IN_CORE'
      )
    ).toBe(true)
  })
})

describe('assignment-pattern and iteration loader anchors', () => {
  it.each([
    [
      'mjs',
      "import {createRequire} from 'node:module';({url:import.meta.url}={url:new URL('../../../tools/anchor.cjs',import.meta.url).href});createRequire(import.meta.url)('./marker.cjs');"
    ],
    [
      'mjs',
      "import {createRequire} from 'node:module';[import.meta.url]=[new URL('../../../tools/anchor.cjs',import.meta.url).href];createRequire(import.meta.url)('./marker.cjs');"
    ],
    [
      'mjs',
      "import {createRequire} from 'node:module';for(import.meta.url of [new URL('../../../tools/anchor.cjs',import.meta.url).href]){};createRequire(import.meta.url)('./marker.cjs');"
    ],
    [
      'mjs',
      "import {createRequire} from 'node:module';const m=import.meta;({url:m.url}={url:new URL('../../../tools/anchor.cjs',import.meta.url).href});createRequire(import.meta.url)('./marker.cjs');"
    ],
    [
      'cjs',
      "const {createRequire}=require('node:module');({file:__filename}={file:require('node:path').join(__dirname,'../../../tools/anchor.cjs')});createRequire(__filename)('./marker.cjs');"
    ],
    [
      'cjs',
      "const {createRequire}=require('node:module');[__filename]=[require('node:path').join(__dirname,'../../../tools/anchor.cjs')];createRequire(__filename)('./marker.cjs');"
    ],
    [
      'cjs',
      "const {createRequire}=require('node:module');for(__filename of [require('node:path').join(__dirname,'../../../tools/anchor.cjs')]){};createRequire(__filename)('./marker.cjs');"
    ],
    [
      'mjs',
      "import {createRequire} from 'node:module';for(import.meta.url in {[new URL('../../../tools/anchor.cjs',import.meta.url).href]:0}){};createRequire(import.meta.url)('./marker.cjs')"
    ],
    [
      'cjs',
      "const {createRequire}=require('node:module');for(__filename in {[require('node:path').join(__dirname,'../../../tools/anchor.cjs')]:0}){};createRequire(__filename)('./marker.cjs')"
    ],
    [
      'mjs',
      "import {createRequire} from 'node:module';({nested:[import.meta.url]}={nested:[new URL('../../../tools/anchor.cjs',import.meta.url).href]});createRequire(import.meta.url)('./marker.cjs')"
    ],
    [
      'cjs',
      "const {createRequire}=require('node:module');({nested:[__filename]}={nested:[require('node:path').join(__dirname,'../../../tools/anchor.cjs')]});createRequire(__filename)('./marker.cjs')"
    ],
    [
      'cjs',
      "const {createRequire}=require('node:module');{const {file:__filename}={file:require('node:path').join(__dirname,'../../../tools/anchor.cjs')};createRequire(__filename)('./marker.cjs')}"
    ]
  ])('refuses mutable anchor %s: %s', (kind, source) => {
    const { root, write } = fixture()
    write(
      'products/shift/src/marker.cjs',
      "console.log('SYNTHETIC_PRODUCT_EXECUTED')"
    )
    write('packages/core/src/marker.cjs', 'module.exports=1')
    write('tools/anchor.cjs', 'module.exports=1')
    write('tools/marker.cjs', "require('../products/shift/src/marker.cjs')")
    const entry = `packages/core/src/entry.${kind}`
    write(entry, source)
    const oracle = spawnSync(process.execPath, [path.join(root, entry)], {
      encoding: 'utf8'
    })
    expect(oracle.status).toBe(0)
    expect(oracle.stdout.trim()).toBe('SYNTHETIC_PRODUCT_EXECUTED')
    const audit = auditProductBoundary(root)
    expect(audit.status).toBe('INCOMPLETE')
    expect(
      audit.diagnostics.some(
        (i) => i.reason === 'UNVERIFIED_MODULE_LOADER_BASE'
      )
    ).toBe(true)
    expect(cli(root).status).toBe(1)
  })
})

describe('physical discovery and TypeScript anchor bindings', () => {
  it('refuses an import-equals binding named __filename', () => {
    const { root, write } = fixture()
    write(
      'packages/core/src/index.ts',
      "import __filename = require('node:path');import {createRequire} from 'node:module';createRequire(__filename)('node:fs')"
    )
    const result = auditProductBoundary(root)
    expect(result.status).toBe('INCOMPLETE')
    expect(
      result.diagnostics.some(
        (i) => i.reason === 'UNVERIFIED_MODULE_LOADER_BASE'
      )
    ).toBe(true)
    expect(cli(root).status).toBe(1)
  })
  it.each(['packages', 'apps', 'legacy', 'products'])(
    'refuses an indirect initial source root: %s',
    (name) => {
      const { root } = fixture()
      const original = path.join(root, name),
        physical = path.join(root, name + '-physical')
      if (fs.existsSync(original)) fs.renameSync(original, physical)
      else fs.mkdirSync(physical)
      fs.symlinkSync(physical, original, 'dir')
      expect(() => auditProductBoundary(root)).toThrow(/unverified_/)
      const result = spawnSync(process.execPath, [checker, root], {
        encoding: 'utf8'
      })
      expect(result.status).toBe(2)
      expect(result.stderr).toMatch(/unverified_/)
    }
  )
  it('refuses an indirect parent used only for workspace discovery', () => {
    const { root, write } = fixture()
    write('package.json', JSON.stringify({ workspaces: ['indirect/*'] }))
    fs.mkdirSync(path.join(root, 'physical-workspaces'))
    fs.symlinkSync(
      path.join(root, 'physical-workspaces'),
      path.join(root, 'indirect'),
      'dir'
    )
    expect(() => auditProductBoundary(root)).toThrow(
      /unverified_discovery_identity/
    )
  })
  it('refuses a workspace parent outside the audited repository', () => {
    const { root, write } = fixture()
    write('package.json', JSON.stringify({ workspaces: ['../outside/*'] }))
    expect(() => auditProductBoundary(root)).toThrow(
      /discovery_outside_repository/
    )
  })
})

describe('Node 22 prefix-only builtin authority', () => {
  it.each(['node:sea', 'node:sqlite', 'node:test', 'node:test/reporters'])(
    'accepts actual prefixed builtin %s across literal loaders',
    (specifier) => {
      for (const source of [
        `import '${specifier}'`,
        `require('${specifier}')`,
        `import('${specifier}')`,
        `import {createRequire} from 'node:module'; const load=createRequire(import.meta.url); load('${specifier}')`
      ]) {
        const { root, write } = fixture()
        write('packages/core/src/index.ts', source)
        expect(auditProductBoundary(root).passed).toBe(true)
      }
    }
  )
  it.each(['node:sea', 'node:sqlite', 'node:test', 'node:test/reporters'])(
    'accepts process native getter for %s',
    (specifier) => {
      const { root, write } = fixture()
      write(
        'packages/core/src/index.ts',
        `process.getBuiltinModule('${specifier}')`
      )
      expect(auditProductBoundary(root).passed).toBe(true)
    }
  )
  it.each(['sea', 'sqlite', 'test', 'node:quic', 'node:does-not-exist'])(
    'refuses to relabel unresolved %s as native',
    (specifier) => {
      for (const source of [
        `import '${specifier}'`,
        `require('${specifier}')`,
        `process.getBuiltinModule('${specifier}')`
      ]) {
        const { root, write } = fixture()
        write('packages/core/src/index.ts', source)
        expect(auditProductBoundary(root).passed).toBe(false)
      }
    }
  )
})

describe('empty core inventory', () => {
  it('does not certify a repository manifest with no audited sources', () => {
    const { root } = fixture()
    fs.rmSync(path.join(root, 'packages'), { recursive: true })
    fs.rmSync(path.join(root, 'products'), { recursive: true })
    const result = auditProductBoundary(root)
    expect(result.sourceFiles).toBe(0)
    expect(result.coreFiles).toBe(0)
    expect(result.passed).toBe(false)
    expect(result.status).toBe('INCOMPLETE')
    expect(
      result.diagnostics.some((d) => d.reason === 'EMPTY_CORE_SOURCE_INVENTORY')
    ).toBe(true)
  })
  it('does not certify consumer sources without the promised harness core', () => {
    const { root } = fixture()
    fs.rmSync(path.join(root, 'packages'), { recursive: true })
    const result = auditProductBoundary(root)
    expect(result.sourceFiles).toBeGreaterThan(0)
    expect(result.coreFiles).toBe(0)
    expect(result.passed).toBe(false)
    expect(
      result.diagnostics.some((d) => d.reason === 'EMPTY_CORE_SOURCE_INVENTORY')
    ).toBe(true)
  })
})

describe('type syntax keeps dependency authority without runtime capability escapes', () => {
  it.each([
    ['ts', 'type Process = typeof process; export const neutral=1'],
    ['ts', 'type Global = typeof globalThis; export const neutral=1'],
    [
      'ts',
      'type Global = typeof globalThis extends {onmessage: unknown} ? {} : unknown; export const neutral=1'
    ],
    [
      'ts',
      'type Module = typeof import("node:module"); export const neutral=1'
    ],
    [
      'd.ts',
      'export type Global = typeof globalThis; export declare const neutral: number'
    ],
    [
      'd.ts',
      'type Global = typeof globalThis extends {onmessage: unknown} ? {} : unknown; export declare const neutral: Global'
    ],
    ['d.ts', 'export type Loader = typeof import("node:module").createRequire']
  ])(
    'accepts type-only host queries in %s without exempting a file: %s',
    (extension, source) => {
      const { root, write } = fixture()
      write('packages/core/src/query.' + extension, source)
      expect(auditProductBoundary(root).passed).toBe(true)
    }
  )
  it.each([
    ['ts', 'type Global = typeof globalThis; export const carrier=globalThis'],
    [
      'd.ts',
      'type Global = typeof globalThis; export const carrier=globalThis'
    ],
    [
      'ts',
      'type Loader = typeof import("node:module").createRequire; import {createRequire} from "node:module"; const load=createRequire(import.meta.url); load("@private/product")'
    ],
    [
      'd.ts',
      'export type Global = typeof globalThis; import "../../../products/shift/src/index.ts"'
    ],
    [
      'ts',
      'type Global = typeof globalThis; export const actual=typeof globalThis'
    ],
    [
      'ts',
      'type Global = typeof globalThis; export const carrier=globalThis as Global'
    ]
  ])(
    'still refuses executable escapes and product edges in %s: %s',
    (extension, source) => {
      const { root, write } = fixture()
      write('packages/core/src/query.' + extension, source)
      expect(auditProductBoundary(root).passed).toBe(false)
    }
  )
})

describe('runtime class heritage retains capability checks', () => {
  it.each([
    'type Global = typeof globalThis; class Core extends globalThis.Carrier {}; export const neutral=1',
    'type Global = typeof globalThis; const Base=globalThis; class Core extends Base {}; export const neutral=1'
  ])(
    'refuses an executable extends expression despite erased annotations: %s',
    (source) => {
      const { root, write } = fixture()
      write('packages/core/src/heritage.ts', source)
      expect(auditProductBoundary(root).passed).toBe(false)
    }
  )
})
