import fs from 'node:fs'
import ts from '../candidate/node_modules/typescript/lib/typescript.js'
import { createBoundaryLexical } from '../candidate/scripts/boundary-lexical.mjs'
Error.stackTraceLimit = 100
const context = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'))
const text = fs.readFileSync(context.file, 'utf8')
const source = ts.createSourceFile(context.file, text, ts.ScriptTarget.Latest, true)
let target
const visit = node => {
  if (node.pos === context.pos && node.end === context.end && ts.SyntaxKind[node.kind] === context.kind) target = node
  ts.forEachChild(node, visit)
}
visit(source)
if (!target || target.getText(source) !== context.text) throw new Error('exact_query_context_mismatch')
const commonJs = ts.getImpliedNodeFormatForFile(context.file, undefined, ts.sys, { module: ts.ModuleKind.NodeNext }) === ts.ModuleKind.CommonJS
console.log(JSON.stringify({file: context.file, operation:context.operation, pos:target.pos,end:target.end,text:target.getText(source),parent:target.parent.getText(source),commonJs,parseErrors:source.parseDiagnostics.length}))
const lexical = createBoundaryLexical(ts, source, commonJs)
const key = lexical.identity(target)
console.log(JSON.stringify({result:key === undefined ? 'NON_LEXICAL' : key.global ? 'GLOBAL:'+key.global : 'BOUND_SYMBOL',declarations:key?.declarations?.map(d => ({kind:ts.SyntaxKind[d.kind],pos:d.pos,end:d.end}))}))
