const load=require;load("./absent.js");
