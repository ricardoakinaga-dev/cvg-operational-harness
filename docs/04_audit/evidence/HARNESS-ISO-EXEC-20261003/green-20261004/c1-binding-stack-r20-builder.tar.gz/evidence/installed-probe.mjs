import { auditProductBoundary } from '../candidate/scripts/check-product-boundary.mjs'
Error.stackTraceLimit = 100
const result = auditProductBoundary(process.cwd())
console.log(JSON.stringify(result, null, 2))
process.exitCode = result.passed ? 0 : 1
