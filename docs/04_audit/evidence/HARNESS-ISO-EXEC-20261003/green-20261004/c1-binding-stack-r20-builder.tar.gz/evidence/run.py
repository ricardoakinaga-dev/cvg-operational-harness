import subprocess,os,json,time,pathlib,sys
root=pathlib.Path(__file__).resolve().parent.parent
label=sys.argv[1]; args=sys.argv[2:]; out=root/'output'/'attempts'/label
out.mkdir(parents=True,exist_ok=False)
env={'PATH':str(root/'output/toolchain')+':/usr/bin:/bin','HOME':str(root/'output/home'),'TMPDIR':str(root/'output/tmp'),'TMP':str(root/'output/tmp'),'TEMP':str(root/'output/tmp'),'XDG_CACHE_HOME':str(root/'output/cache'),'npm_config_cache':str(root/'output/cache/npm'),'LANG':'C.UTF-8','TZ':'UTC','CVG_BINDING_QUERY_ERROR':str(out/'query-error.json'),'CVG_MANIFEST_RUNTIME_PROOF_DIR':str(out/'manifest-fixtures')}
start=time.time()
with (out/'stdout.log').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
 try:
  p=subprocess.run(args,cwd=root/'candidate',env=env,stdout=stdout,stderr=stderr)
  status=p.returncode
 except OSError as error:
  status=None
  stderr.write(repr(error)+'\n')
receipt={'label':label,'argv':args,'cwd':str(root/'candidate'),'environment':env,'exit_status':status,'elapsed_seconds':time.time()-start}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
