import { auditProductBoundary } from './fallback-scanner-instrument.mjs'
import assert from 'node:assert/strict'
const result = auditProductBoundary(new URL('./fallback-fixture', import.meta.url).pathname)
console.log(JSON.stringify({injectedFailure: true, sourceExecuted: false, result}, null, 2))
assert.equal(result.status, 'INCOMPLETE')
assert.equal(result.passed, false)
assert.deepEqual(result.violations, [])
assert.deepEqual(result.diagnostics, [{reason: 'UNAVAILABLE_LEXICAL_BINDING_ANALYSIS', file: 'packages/core/src/entry.mts', operation: 'getSymbolAtLocation', identifier: 'require', position: 11, error: 'Maximum call stack size exceeded'}])
