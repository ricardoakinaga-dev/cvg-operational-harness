// Diagnostic only: replay binding queries on one owned installed physical file.
import fs from 'node:fs'
import ts from '../candidate/node_modules/typescript/lib/typescript.js'
import { createBoundaryLexical } from '../candidate/scripts/boundary-lexical.mjs'
Error.stackTraceLimit = 100
const file = process.argv[2]
const source = ts.createSourceFile(file, fs.readFileSync(file, 'utf8'), ts.ScriptTarget.Latest, true)
const lexical = createBoundaryLexical(ts, source, file.endsWith('.js'))
let count=0
const visit=node=>{
  if(ts.isIdentifier(node)) {
    const context={file,operation:'getSymbolAtLocation',kind:ts.SyntaxKind[node.kind],pos:node.pos,start:node.getStart(source),end:node.end,text:node.getText(source),location:source.getLineAndCharacterOfPosition(node.getStart(source)),parent:{kind:ts.SyntaxKind[node.parent.kind],text:node.parent.getText(source).slice(0,2000)}}
    fs.writeFileSync(process.env.CVG_BINDING_QUERY_ERROR.replace('query-error','current-query'),JSON.stringify(context,null,2)+'\n')
    lexical.identity(node);count++
  }
  ts.forEachChild(node,visit)
}
visit(source)
console.log(JSON.stringify({file,identifiers:count,parseErrors:source.parseDiagnostics.length}))
