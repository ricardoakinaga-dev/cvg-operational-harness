import fs from 'node:fs'
import ts from '../candidate/node_modules/typescript/lib/typescript.js'
Error.stackTraceLimit = 100
const file=process.argv[2], source=ts.createSourceFile(file,fs.readFileSync(file,'utf8'),ts.ScriptTarget.Latest,true)
const options={noResolve:true,noLib:true,noEmit:true,allowJs:true}
const host={getSourceFile:name=>name===source.fileName?source:undefined,getDefaultLibFileName:()=>'',writeFile:()=>{},getCurrentDirectory:()=>'',getDirectories:()=>[],fileExists:name=>name===source.fileName,readFile:()=>undefined,getCanonicalFileName:name=>name,useCaseSensitiveFileNames:()=>true,getNewLine:()=> '\n'}
const checker=ts.createProgram([source.fileName],options,host).getTypeChecker()
let count=0
const visit=node=>{
 if(ts.isIdentifier(node)){
  const parent=node.parent
  const operation=ts.isShorthandPropertyAssignment(parent)&&parent.name===node?'getShorthandAssignmentValueSymbol':ts.isExportSpecifier(parent)&&!parent.parent.parent.moduleSpecifier?'getExportSpecifierLocalTargetSymbol':'getSymbolAtLocation'
  const context={file,operation,kind:ts.SyntaxKind[node.kind],pos:node.pos,start:node.getStart(source),end:node.end,text:node.getText(source),location:source.getLineAndCharacterOfPosition(node.getStart(source)),parent:{kind:ts.SyntaxKind[parent.kind],text:parent.getText(source)}}
  fs.writeFileSync(process.env.CVG_BINDING_QUERY_ERROR.replace('query-error','current-query'),JSON.stringify(context,null,2)+'\n')
  try{
   if(operation==='getShorthandAssignmentValueSymbol')checker.getShorthandAssignmentValueSymbol(parent)
   else if(operation==='getExportSpecifierLocalTargetSymbol')checker.getExportSpecifierLocalTargetSymbol(parent)
   else checker.getSymbolAtLocation(node)
  }catch(error){fs.writeFileSync(process.env.CVG_BINDING_QUERY_ERROR,JSON.stringify({...context,stack:error.stack},null,2)+'\n');throw error}
  count++
 }
 ts.forEachChild(node,visit)
}
visit(source)
console.log(JSON.stringify({file,identifiers:count,parseErrors:source.parseDiagnostics.length}))
