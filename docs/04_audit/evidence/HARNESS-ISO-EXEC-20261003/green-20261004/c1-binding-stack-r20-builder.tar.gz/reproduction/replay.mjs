// Frozen before/after replay: parse the captured installed source, never load it.
import fs from 'node:fs'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import ts from '/home/ricardo/.cache/cvg-harness-green-20261004/c1-binding-stack-r20/candidate/node_modules/typescript/lib/typescript.js'
Error.stackTraceLimit = 100
const mode = process.argv[2]
assert.ok(['before', 'after'].includes(mode))
const context = JSON.parse(fs.readFileSync(new URL('./query-context.json', import.meta.url), 'utf8'))
const bytes = fs.readFileSync(new URL('./typescript.js', import.meta.url))
assert.equal(createHash('sha256').update(bytes).digest('hex'), context.physicalSourceSha256)
assert.equal(createHash('sha256').update(fs.readFileSync(context.file)).digest('hex'), context.physicalSourceSha256)
const source = ts.createSourceFile(context.file, bytes.toString('utf8'), ts.ScriptTarget.Latest, true)
let target
const visit = node => {
  if (node.pos === context.pos && node.end === context.end && ts.isIdentifier(node)) target = node
  ts.forEachChild(node, visit)
}
visit(source)
assert.equal(source.parseDiagnostics.length, 0)
assert.equal(target.getText(source), 'flags')
assert.equal(target.parent.getText(source), 'type.flags')
const { createBoundaryLexical } = await import(mode === 'before' ? '../baseline/scripts/boundary-lexical.mjs' : '../source/scripts/boundary-lexical.mjs')
console.log(JSON.stringify({mode, physicalFile:context.file,operation:context.operation,pos:context.pos,end:context.end,line:context.oneBasedLine,identifier:'flags',parent:'type.flags',sourceExecuted:false}))
try {
  const identity = createBoundaryLexical(ts, source, true).identity(target)
  assert.equal(mode, 'after', 'baseline unexpectedly completed')
  assert.equal(identity, undefined)
  console.log('NON_LEXICAL')
} catch(error) {
  if (mode !== 'before' || !(error instanceof RangeError) || error.message !== 'Maximum call stack size exceeded') throw error
  console.error(error.stack)
  process.exitCode=1
}
