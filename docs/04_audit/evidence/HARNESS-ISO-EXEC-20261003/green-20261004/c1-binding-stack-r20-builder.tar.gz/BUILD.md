C1_BINDING_STACK_R20 — frozen BUILD handoff, no self acceptance.

The binding-only helper now excludes property/member spellings before asking the TypeScript checker for their semantic symbol. Necessary lexical, shorthand, local export and parameter-environment queries remain. Stack exhaustion in one of those necessary operations emits a file/operation/identifier/position diagnostic and an indeterminate identity; other errors propagate. The scanner retains its existing INCOMPLETE aggregation and installed-dependency unknowns.

Actual reproduction: `/home/ricardo/.cache/cvg-harness-green-20261004/c1-binding-stack-r20/candidate/node_modules/typescript/lib/typescript.js`, line 54388, offset 2725992, Identifier `flags` in `type.flags`, operation `getSymbolAtLocation`. Exact-file before receipt records a RangeError; the same input after is NON_LEXICAL. Raw stacks, AST parents/ancestry and source hash are in reproduction and evidence.

Final five-file run: 1245/1245 PASS (1185 original + 38 inherited + 22 new), no skips or failures. The four original test files match R19 byte for byte. Types, full lint, final-path lint and formatting checks succeeded. New tests are solely in `tests/product-boundary-binding-query.test.js`; Lead owns the corresponding baseline metadata merge.

Profile scope: R20 own materialized clone, zero links, copy-time 28319 files. This does not qualify original/native/R25 or the separate original-link reviewer profile. Raw copy inventory and Lead-reported link count are preserved separately in evidence/installed-profile.json.

Actual installed CLI completed exit 1, structured status INCOMPLETE, 9032 diagnostics, 0 violations, zero stderr bytes. UNVERIFIED_INSTALLED_DEPENDENCY remains. This is no claim of frontier completeness or release.

All attempt receipts are indexed in evidence/attempts-index.json. Prior appended-test runs, setup errors, timeout, denied tracing and the exit143 interruption remain historical; final scope is focused-final-02. Source diff is BUILD.patch, final source hashes are in build-proof.json, and the complete packet is sealed by MANIFEST.json / MANIFEST.sha256.

Next: fresh Lead I1 review. Full native chain, SBOM and licenses were not run in this lane.

Replay (owned Node22, no source execution): `../toolchain/node reproduction/replay.mjs before` from this frozen packet exits 1 with the raw RangeError; `../toolchain/node reproduction/replay.mjs after` exits 0 with NON_LEXICAL.
