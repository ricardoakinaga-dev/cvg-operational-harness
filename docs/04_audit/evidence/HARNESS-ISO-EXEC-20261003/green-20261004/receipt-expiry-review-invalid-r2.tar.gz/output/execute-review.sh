#!/bin/bash
set -eu
cd -- "$(dirname -- "$0")"
export TMPDIR="$PWD/tmp" XDG_CACHE_HOME="$PWD/cache" npm_config_cache="$PWD/cache/npm"
export PATH="/home/ricardo/.nvm/versions/node/v22.23.2/bin:$PATH"
node -e 'if(process.versions.node.split(".")[0]!=="22") throw new Error("Node22 required")'
node runtime/node_modules/vitest/vitest.mjs run --config review.config.mts > vitest.log 2>&1
