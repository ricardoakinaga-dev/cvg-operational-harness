import { defineConfig } from './runtime/node_modules/vitest/dist/config.js';
export default defineConfig({cacheDir:'./cache/vite',test:{include:['own-review.test.ts'],environment:'node',testTimeout:15000,hookTimeout:15000,fileParallelism:false,maxWorkers:1,reporters:['default','json'],outputFile:{json:'./test-results.json'}}});
