import os,stat,hashlib,json,time
from pathlib import Path
out=Path.cwd();packet=out.parent
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def inventory(roots,base):
 result={}
 for root in roots:
  for b,ds,fs in os.walk(base/root,followlinks=False):
   for n in ds+fs:
    p=Path(b)/n;s=p.lstat();e={'kind':'link' if p.is_symlink() else 'directory' if p.is_dir() else 'file','mode':stat.S_IMODE(s.st_mode),'mtimeNs':s.st_mtime_ns}
    if e['kind']=='link':e['target']=os.readlink(p)
    if e['kind']=='file':e.update(bytes=s.st_size,sha256=H(p))
    result[str(p.relative_to(base))]=e
 return result
before=json.loads((out/'before.json').read_text());after=inventory(['source','original'],packet)
(out/'after.json').write_text(json.dumps(after,sort_keys=True))
roots={n:{'mode':stat.S_IMODE((packet/n).stat().st_mode),'mtimeNs':(packet/n).stat().st_mtime_ns} for n in ['source','original']}
(out/'root-after.json').write_text(json.dumps(roots,sort_keys=True))
deltas=[k for k in set(before)|set(after) if before.get(k)!=after.get(k)]
rootEqual=roots==json.loads((out/'root-before.json').read_text())
frozen=json.loads((packet/'frozen-inventory.json').read_text());normalized={k:({'kind':'symlink','target':v['target']} if v['kind']=='link' else v) for k,v in after.items()}
assert not deltas and rootEqual and normalized==frozen
assert H(packet/'frozen-inventory.json')=='f732c9fdfb9742d6b55727fa1001ccbf9f00e94f303951537006c03ccb696317'
files=0;physical=0;tests=[];runtimeChanges=[]
for k,e in before.items():
 rel=Path(k);target=out/('runtime' if rel.parts[0]=='source' else 'original-copy')/Path(*rel.parts[1:]);src=packet/k
 if e['kind']=='file':
  files+=1
  assert (target.stat().st_dev,target.stat().st_ino)!=(src.stat().st_dev,src.stat().st_ino)
  physical+=1
  changed=H(target)!=e['sha256'] or target.stat().st_size!=e['bytes']
  if changed:runtimeChanges.append(k)
  if '/__tests__/' in k and k.endswith(('.ts','.json','.wav','.txt','.md')):tests.append({'source':k,'sha256':e['sha256'],'runtimeSha256':H(target),'unchanged':not changed})
assert not runtimeChanges
links=[]
for b,ds,fs in os.walk(out/'runtime',followlinks=False):
 for n in ds+fs:
  p=Path(b)/n
  if p.is_symlink():
   assert p.resolve().is_relative_to(out/'runtime')
   links.append({'path':str(p.relative_to(out)),'target':os.readlink(p),'internal':True})
verification={'freezeMatches':True,'sourceOriginalEntries':len(after),'entryDeltas':deltas,'rootsModesMtimeUnchanged':rootEqual,'symlinkModesMtimeComparedBeyondFrozenSchema':True,'physicalDistinctInodes':physical,'copiedRegularFiles':files,'copiedExistingFileByteChanges':runtimeChanges,'runtimeInternalLinks':len(links),'existingTestAssetsChecked':len(tests),'sourceOriginalFileModesMtimeDirsLinksUnchanged':True}
(out/'immutability.json').write_text(json.dumps(verification,indent=2))
(out/'existing-test-byte-comparison.json').write_text(json.dumps(tests,indent=2))
(out/'runtime-links-after.json').write_text(json.dumps(links,indent=2))
results=json.loads((out/'test-results.json').read_text());assert results['numPassedTests']==14 and results['numFailedTests']==0
traces=[json.loads(x) for x in (out/'finite-trace.jsonl').read_text().splitlines()]
perf=[x for x in traces if x['kind']=='performance'];assert len(perf)==7
(out/'procedure.json').write_text(json.dumps({'finalNode':'22.23.2','finalCwd':str(out),'config':str(out/'review.config.mts'),'tmpdir':str(out/'tmp'),'cache':str(out/'cache'),'testTimeoutMs':15000,'fixtureCount':1000,'p1BudgetMs':1300,'ownPerformanceTests':7,'ownAdversarialTests':7,'proposedExistingTestsExecuted':False,'untrustedFixturePayloadProgramsExecuted':False,'bootstrapDeviations':['Preliminary pwd/list/read commands used packet cwd/default shell environment before output environment initialization.','A schema mismatch for symlink entries stopped the first preparation helper; subsequent node --version executed Node24.20.0 before the physical runtime copy. No source module, Vitest, or product code was executed during that version query.'],'verdictBasis':'Strict first-command/pre-execution preparation and Node22 requirements prevent unconditional procedural acceptance. Final isolated test procedure corrected, but the prior bootstrap deviation remains evidence.'},indent=2))
report='''# I1 fresco TTL R9-R2 — INVALID

Freeze: `f732c9fdfb9742d6b55727fa1001ccbf9f00e94f303951537006c03ccb696317` (21.191 entradas).

**Veredito final: INVALID por procedimento.** A preparação inicial falhou por comparar o esquema de links como arquivos; o comando seguinte consultou `node --version` em Node 24.20.0 antes da cópia física. As primeiras consultas de diretório também antecederam a configuração de ambiente de output. Isso não satisfaz a exigência estrita de Node22/preparação desde o primeiro comando. Nenhum módulo do produto ou Vitest foi executado nessa consulta. A correção ficou somente no procedimento próprio de teste; não altera retroativamente essa evidência.

A execução corrigida usou Node 22.23.2, source/deps copiados fisicamente em `output/runtime`, 48 links internos, cwd/config/cache/TMPDIR em output. Foram aprovados 14 testes próprios: 7 de performance sintética e 7 adversariais. Nenhum teste proposto, programa de fixture, Root, ledger, histórico, review anterior, rede, PG, instalação, subagente ou push foi utilizado. Nenhum arquivo de produto foi editado. A configuração própria teve uma falha de resolução de import, preservada em `procedure-startup-error.log`, e foi corrigida apenas em output.

## Resultado técnico, separado do veredito procedimental

Não foi encontrado contraexemplo de semântica TTL no escopo exercitado. Os diffs dos dois originais mostram apenas o novo número derivado, sua inicialização, a guarda/recomputação da poda, a atualização em recepção e a cópia primitiva em Store validation. Schema, journal, append/fsync e formato/eventos não receberam alteração nessas comparações; os demais arquivos de suporte do original não foram fornecidos, portanto não se afirma um diff histórico deles.

Invariante: o bound é menor ou igual ao mínimo de `receivedAt + 86400000` de receipts finitos ainda não matched. Infinity é o valor inicial/sem mínimo finito. Cada inserção aplica min mesmo retrodatada. Matching pode deixar o bound antecipado, conservador. Uma poda percorre as entradas atuais uma vez, preserva matched, aplica literalmente `now - receivedAt > 86400000` e recalcula sobre sobreviventes. Se `now <= bound`, nenhuma entrada válida pode expirar. NaN no timestamp de execução não poda; NaN em receivedAt não satisfaz o predicado original e não gera bound. Esses probes diretos não ampliam o domínio público: schema do Store rejeita NaN.

No domínio Date, timestamps inteiros têm módulo <= 8.64e15; o bound somado permanece abaixo de 2^53 e é exato. Diferenças próximas do limiar TTL também são inteiros exatos. Os extremos positivo/negativo e TTL exato/+1 foram exercitados, incluindo replay. O máximo de Date não tem instante suportado posterior; foi testada retenção/replay nesse ponto.

Store validation copia o número por valor e mapas independentes; valores de receipt/história/identidade são substituídos, sem mutação compartilhada observada nesses caminhos. Replay começa em emptyVertical e valida/publica eventos para reconstruir o número; não existe serialização nova desse cache. Probes persistentes confirmaram rollback de poda e de inserção com expiry anterior, batch com eventos retrodatados, replay e ausência de publicação após falha de sync. No teste de sync falho, a linha completa já havia sido escrita; reabertura a reaplicou. Isso não comprova durabilidade sob perda de energia.

## Visitas e limites

P1: 1.000 receipts + 1.000 pulses: zero visitas TTL antes de expiry, retenção no TTL exato, 1.000 visitas em TTL+1. O tempo medido ficou abaixo de 1.300ms, com timeout de 15s. P2 comparou o módulo original compilado dos bytes copiados, com suporte da cópia: para N=64/256/1000 e 100 pulses, original visitou 6400/25600/100000 e candidato zero. P3 matched residual: uma passagem de 1000 e depois Infinity. P4: 1000 pulses pós-poda sem passagem extra. P5: expiry escalonado: 500.500 visitas em 1000 podas. P6: 1000 timestamps NaN em projeção direta, zero passagens. P7: 500 retrodatados/500 posteriores, duas podas com 1500 visitas totais.

A prova é O(1) para a guarda e O(N) por scan efetivamente necessário; o cenário de uma única fronteira tem visitas TTL totais O(N), independentes dos pulses anteriores. **Não há prova de custo total global linear**: P5 mostra custo quadrático acumulado com expiries escalonados. A admissão de 1000 receipts também visitou 499.500 keys pelo cap; contar apenas o iterador da poda não esconde esse custo. Store copia mapas na validação e mantém outros caminhos com scans. Não se concede full performance, cobertura global, SLO, produção, liberação clínica ou segurança geral.

A1 comparou 2.500 eventos mistos com o original e conferiu o invariante a cada etapa; incluiu retrodatação, NaN direto e matched injetado. A2 extremos/schema/replay; A3 cap 1000, TTL exato/+1 e dedup após expiry; A4 rollback/batch/replay; A5 sync falho; A6 20 linhas/eventos com hash chain/schema, 20 fsyncs nativos de append e idempotência; A7 autoridade de identidade started e receipt matched preservado versus unmatched expirado. A7 constrói o estado causal diretamente, sem afirmar cobertura de todo o pipeline de criação de outbox.

## Preservação e evidência finita

`before.json`/`after.json` conferem bytes SHA256, modes, mtimeNs, diretórios e targets/modos/mtime de links; `root-before.json`/`root-after.json` cobrem os dois diretórios raiz. O inventário congelado omite modes/mtime de links, por isso a comparação adicional os preserva. Zero diferenças nos originais/source e nenhum byte de arquivo existente da cópia modificado; inodes distintos provam cópia física sem hardlinks ao source. Os assets dos testes existentes também são comparados individualmente. O runtime pode receber caches/config temporária, exclusivamente dentro de output.

`finite-trace.jsonl` registra observações reais finitas de testes/visitas e chamadas fsync nativas concluídas. `sync-injection` identifica a falha antes da chamada nativa. Esses registros **não são syscall tracing** e não demonstram ausência universal de acessos de outros processos; snapshots antes/depois não excluem alteração transitória revertida. A tentativa inicial está preservada separadamente e seu registro de sync era tentativa, não necessariamente chamada nativa. A segunda execução corrigiu somente essa precisão de trace.

`finite-manifest.json` sela os arquivos/diretórios/links enumerados em output, exceto ele próprio e `seal.json`; `seal.json` contém o SHA256 do manifesto e deste relatório. Nenhuma inferência de aceite foi herdada. O resultado técnico positivo não substitui o veredito procedimental INVALID.
'''
(out/'report.md').write_text(report)
(out/'verdict.json').write_text(json.dumps({'verdict':'INVALID','scope':'TTL semantics / per-prune linear visit proof only','technicalTestsPassed':14,'ownPerformanceTests':7,'ownAdversarialTests':7,'sourceOriginalUnchanged':True,'reason':'Bootstrap Node24 --version before physical runtime copy and initial output-environment preparation not present from first command','fullPerformance':False,'globalLinearComplexity':False,'productionRelease':False},indent=2))
manifest={}
for b,ds,fs in os.walk(out,followlinks=False):
 for n in ds+fs:
  p=Path(b)/n;rel=str(p.relative_to(out))
  if rel in ['finite-manifest.json','seal.json']:continue
  s=p.lstat();e={'kind':'link' if p.is_symlink() else 'directory' if p.is_dir() else 'file','mode':stat.S_IMODE(s.st_mode),'mtimeNs':s.st_mtime_ns}
  if e['kind']=='file':e.update(bytes=s.st_size,sha256=H(p))
  elif e['kind']=='link':e['target']=os.readlink(p)
  manifest[rel]=e
(out/'finite-manifest.json').write_text(json.dumps({'scope':'finite output inventory; excludes own manifest/seal and output root metadata','entries':manifest},sort_keys=True))
seal={'verdict':'INVALID','manifestSha256':H(out/'finite-manifest.json'),'reportSha256':H(out/'report.md'),'freezeSha256':H(packet/'frozen-inventory.json'),'entries':len(manifest),'sealedAtUTC':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'selfExclusions':['finite-manifest.json','seal.json'],'limitations':'finite observations, not syscall tracing or production certification'}
(out/'seal.json').write_text(json.dumps(seal,indent=2));print(json.dumps({'verification':verification,'seal':seal,'performance':perf},indent=2))
