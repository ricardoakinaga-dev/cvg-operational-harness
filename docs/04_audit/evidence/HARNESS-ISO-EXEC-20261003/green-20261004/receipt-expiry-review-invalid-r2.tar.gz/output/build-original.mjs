import {build} from './runtime/node_modules/esbuild/lib/main.js';
import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
await build({stdin:{contents:readFileSync('./original-copy/products/shift-assistant/src/vertical-state.ts','utf8'),resolveDir:resolve('./runtime/products/shift-assistant/src'),sourcefile:'original-vertical.ts',loader:'ts'},outfile:'original-vertical.mjs',bundle:true,platform:'node',format:'esm',target:'node22',legalComments:'none'});
