# I1 fresco TTL R9-R2 — INVALID

Freeze: `f732c9fdfb9742d6b55727fa1001ccbf9f00e94f303951537006c03ccb696317` (21.191 entradas).

**Veredito final: INVALID por procedimento.** A preparação inicial falhou por comparar o esquema de links como arquivos; o comando seguinte consultou `node --version` em Node 24.20.0 antes da cópia física. As primeiras consultas de diretório também antecederam a configuração de ambiente de output. Isso não satisfaz a exigência estrita de Node22/preparação desde o primeiro comando. Nenhum módulo do produto ou Vitest foi executado nessa consulta. A correção ficou somente no procedimento próprio de teste; não altera retroativamente essa evidência.

A execução corrigida usou Node 22.23.2, source/deps copiados fisicamente em `output/runtime`, 48 links internos, cwd/config/cache/TMPDIR em output. Foram aprovados 14 testes próprios: 7 de performance sintética e 7 adversariais. Nenhum teste proposto, programa de fixture, Root, ledger, histórico, review anterior, rede, PG, instalação, subagente ou push foi utilizado. Nenhum arquivo de produto foi editado. A configuração própria teve uma falha de resolução de import, preservada em `procedure-startup-error.log`, e foi corrigida apenas em output.

## Resultado técnico, separado do veredito procedimental

Não foi encontrado contraexemplo de semântica TTL no escopo exercitado. Os diffs dos dois originais mostram apenas o novo número derivado, sua inicialização, a guarda/recomputação da poda, a atualização em recepção e a cópia primitiva em Store validation. Schema, journal, append/fsync e formato/eventos não receberam alteração nessas comparações; os demais arquivos de suporte do original não foram fornecidos, portanto não se afirma um diff histórico deles.

Invariante: o bound é menor ou igual ao mínimo de `receivedAt + 86400000` de receipts finitos ainda não matched. Infinity é o valor inicial/sem mínimo finito. Cada inserção aplica min mesmo retrodatada. Matching pode deixar o bound antecipado, conservador. Uma poda percorre as entradas atuais uma vez, preserva matched, aplica literalmente `now - receivedAt > 86400000` e recalcula sobre sobreviventes. Se `now <= bound`, nenhuma entrada válida pode expirar. NaN no timestamp de execução não poda; NaN em receivedAt não satisfaz o predicado original e não gera bound. Esses probes diretos não ampliam o domínio público: schema do Store rejeita NaN.

No domínio Date, timestamps inteiros têm módulo <= 8.64e15; o bound somado permanece abaixo de 2^53 e é exato. Diferenças próximas do limiar TTL também são inteiros exatos. Os extremos positivo/negativo e TTL exato/+1 foram exercitados, incluindo replay. O máximo de Date não tem instante suportado posterior; foi testada retenção/replay nesse ponto.

Store validation copia o número por valor e mapas independentes; valores de receipt/história/identidade são substituídos, sem mutação compartilhada observada nesses caminhos. Replay começa em emptyVertical e valida/publica eventos para reconstruir o número; não existe serialização nova desse cache. Probes persistentes confirmaram rollback de poda e de inserção com expiry anterior, batch com eventos retrodatados, replay e ausência de publicação após falha de sync. No teste de sync falho, a linha completa já havia sido escrita; reabertura a reaplicou. Isso não comprova durabilidade sob perda de energia.

## Visitas e limites

P1: 1.000 receipts + 1.000 pulses: zero visitas TTL antes de expiry, retenção no TTL exato, 1.000 visitas em TTL+1. O tempo medido ficou abaixo de 1.300ms, com timeout de 15s. P2 comparou o módulo original compilado dos bytes copiados, com suporte da cópia: para N=64/256/1000 e 100 pulses, original visitou 6400/25600/100000 e candidato zero. P3 matched residual: uma passagem de 1000 e depois Infinity. P4: 1000 pulses pós-poda sem passagem extra. P5: expiry escalonado: 500.500 visitas em 1000 podas. P6: 1000 timestamps NaN em projeção direta, zero passagens. P7: 500 retrodatados/500 posteriores, duas podas com 1500 visitas totais.

A prova é O(1) para a guarda e O(N) por scan efetivamente necessário; o cenário de uma única fronteira tem visitas TTL totais O(N), independentes dos pulses anteriores. **Não há prova de custo total global linear**: P5 mostra custo quadrático acumulado com expiries escalonados. A admissão de 1000 receipts também visitou 499.500 keys pelo cap; contar apenas o iterador da poda não esconde esse custo. Store copia mapas na validação e mantém outros caminhos com scans. Não se concede full performance, cobertura global, SLO, produção, liberação clínica ou segurança geral.

A1 comparou 2.500 eventos mistos com o original e conferiu o invariante a cada etapa; incluiu retrodatação, NaN direto e matched injetado. A2 extremos/schema/replay; A3 cap 1000, TTL exato/+1 e dedup após expiry; A4 rollback/batch/replay; A5 sync falho; A6 20 linhas/eventos com hash chain/schema, 20 fsyncs nativos de append e idempotência; A7 autoridade de identidade started e receipt matched preservado versus unmatched expirado. A7 constrói o estado causal diretamente, sem afirmar cobertura de todo o pipeline de criação de outbox.

## Preservação e evidência finita

`before.json`/`after.json` conferem bytes SHA256, modes, mtimeNs, diretórios e targets/modos/mtime de links; `root-before.json`/`root-after.json` cobrem os dois diretórios raiz. O inventário congelado omite modes/mtime de links, por isso a comparação adicional os preserva. Zero diferenças nos originais/source e nenhum byte de arquivo existente da cópia modificado; inodes distintos provam cópia física sem hardlinks ao source. Os assets dos testes existentes também são comparados individualmente. O runtime pode receber caches/config temporária, exclusivamente dentro de output.

`finite-trace.jsonl` registra observações reais finitas de testes/visitas e chamadas fsync nativas concluídas. `sync-injection` identifica a falha antes da chamada nativa. Esses registros **não são syscall tracing** e não demonstram ausência universal de acessos de outros processos; snapshots antes/depois não excluem alteração transitória revertida. A tentativa inicial está preservada separadamente e seu registro de sync era tentativa, não necessariamente chamada nativa. A segunda execução corrigiu somente essa precisão de trace.

`finite-manifest.json` sela os arquivos/diretórios/links enumerados em output, exceto ele próprio e `seal.json`; `seal.json` contém o SHA256 do manifesto e deste relatório. Nenhuma inferência de aceite foi herdada. O resultado técnico positivo não substitui o veredito procedimental INVALID.
