import json, hashlib, os, stat
from pathlib import Path

E = Path(__file__).resolve().parent.parent
O = E / 'critic-r1'
C = E.parent / 'candidate-receipt-performance-r9'
S = E.parent / 'candidate-c1-r17-integrated'
def digest(b): return hashlib.sha256(b).hexdigest()
def read(name): return json.loads((E / (name + '.json')).read_bytes())
def aggregate(entries): return digest(json.dumps(entries, sort_keys=True, separators=(',', ':')).encode())
seal = read('review-seal')
assert digest((E / 'review-seal.json').read_bytes()) == '0c12c0c44e3d9d76e05ba5c4b2e8976a7df73f02e9f45237c64ad0b0903a1c7d'
inputs = []
for row in seal['inputs']:
    # Explicitly excluded narrative input; do not open/hash it.
    if row['path'] == 'short-spec.md': continue
    assert digest((E / row['path']).read_bytes()) == row['sha256'], row['path']
    inputs.append(row)
packet = []
for row in seal['criticPacket']:
    p = E / 'critic-packet' / row['path']
    assert p.is_file() and not p.is_symlink()
    assert digest(p.read_bytes()) == row['sha256']
    side, rel = row['path'].split('/', 1)
    live = (C if side == 'candidate' else S) / rel
    assert digest(live.read_bytes()) == row['sha256']
    assert p.stat().st_ino != live.stat().st_ino
    packet.append(row)
pre, post = read('native-pre'), read('native-post')
dm = lambda rows: {r['path']: r for r in rows}
a,b = dm(pre),dm(post)
changes = sorted(k for k in a.keys() | b.keys() if a.get(k) != b.get(k))
assert changes == sorted(seal['native']['allowedChanges'])
assert len(pre) == 8966 and len(post) == 8967
assert aggregate(pre) == seal['native']['preAggregateSha256']
assert aggregate(post) == seal['native']['postAggregateSha256']
assert read('source-pre') == read('source-post') == read('copy-pre')
assert read('deps-pre') == read('deps-post')
assert read('copy-post') == read('critic-artifact-pre')
allpost = read('critic-artifact-pre')
assert aggregate(allpost) == seal['candidateFingerprint']
assert len(allpost) == 26500 and len(read('deps-post')) == 17533
assert [r for r in allpost if 'node_modules' not in Path(r['path']).parts] == post
assert [r for r in allpost if 'node_modules' in Path(r['path']).parts] == read('deps-post')
gauntlet = [k for k in a if k.startswith('.gauntlet/')]
assert all(a[k] == b[k] for k in gauntlet)

def actual_check(root, rows):
    errors, checked, links, exclusions = [], 0, 0, []
    physical = []
    for row in rows:
        rel = row['path']; p = root / rel
        # No forbidden history/state or environment content is accessed.
        if rel.startswith('.gauntlet/') or any(x.startswith('.env') for x in Path(rel).parts):
            exclusions.append(rel); continue
        try:
            st = p.lstat()
            if row['kind'] == 'file':
                assert stat.S_ISREG(st.st_mode) and st.st_size == row['size']
                assert digest(p.read_bytes()) == row['sha256']
                assert oct(stat.S_IMODE(st.st_mode)) == row['mode']
                assert st.st_nlink == 1
                if root == C:
                    q = S / rel
                    if q.is_file() and not q.is_symlink():
                        assert (st.st_dev,st.st_ino) != (q.stat().st_dev,q.stat().st_ino)
                        physical.append(rel)
            else:
                assert stat.S_ISLNK(st.st_mode)
                target = os.readlink(p)
                assert target == row['target'], (target,row)
                assert p.resolve().is_relative_to(root)
                links += 1
            checked += 1
        except Exception as ex: errors.append({'path':rel,'error':str(ex)})
    return {'checked':checked,'symlinks':links,'physicallySeparateFiles':len(physical),
            'excludedWithoutContentRead':exclusions,'errors':errors}

candidate = actual_check(C, allpost)
source = actual_check(S, read('source-post'))
result = {'sealSha256':digest((E/'review-seal.json').read_bytes()),
    'candidateAggregateSha256':aggregate(allpost),'nativeEntries':len(post),'depsEntries':len(read('deps-post')),
    'verifiedSealedInputs':inputs,'packet':packet,'changes':changes,
    'gauntletManifestEntriesUnchanged':len(gauntlet),'gauntletContentRead':False,
    'candidateActual':candidate,'sourceActual':source,
    'rootDrift':read('pre-post-summary')['rootDifferences']}
(O/'provenance.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['verifiedSealedInputs','packet','rootDrift','candidateActual','sourceActual']},indent=2))
print('candidate',candidate['checked'],'checked',len(candidate['errors']),'errors')
print('source',source['checked'],'checked',len(source['errors']),'errors')
assert not candidate['errors'] and not source['errors'], (candidate['errors'],source['errors'])
