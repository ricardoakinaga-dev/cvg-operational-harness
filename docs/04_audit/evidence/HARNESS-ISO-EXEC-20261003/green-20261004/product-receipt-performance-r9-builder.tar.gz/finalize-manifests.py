from pathlib import Path
import json,hashlib,difflib
from importlib.machinery import SourceFileLoader
out=Path(__file__).parent
m=SourceFileLoader('r9_manifest',str(out/'manifest-copy.py')).load_module()
source=m.source; candidate=m.dest
currentSource=m.manifest(source); currentCandidate=m.manifest(candidate)
m.write('source-post.json',currentSource); m.write('copy-post.json',currentCandidate)
deps=[e for e in currentCandidate if 'node_modules' in Path(e['path']).parts]
m.write('deps-post.json',deps)
a=json.loads((out/'source-pre.json').read_text()); b=json.loads((out/'copy-pre.json').read_text())
def differences(first,last):
 d={e['path']:e for e in first}; f={e['path']:e for e in last}
 return [{'path':p,'before':d.get(p),'after':f.get(p)} for p in sorted(d.keys()|f.keys()) if d.get(p)!=f.get(p)]
sourceDiff=differences(a,currentSource); copyDiff=differences(b,currentCandidate)
allowed=['products/shift-assistant/src/vertical-state.ts','products/shift-assistant/src/store.ts','products/shift-assistant/src/__tests__/receipt-performance-r9-own.test.ts']
root=Path('/home/ricardo/Área de trabalho/cvg-operational-harness')
rootPre=json.loads((out/'protected-root-pre.json').read_text())
rootPost=[{'path':e['path'],'sha256':hashlib.sha256((root/e['path']).read_bytes()).hexdigest()} for e in rootPre]
m.write('protected-root-post.json',rootPost)
allDepPre=json.loads((out/'deps-pre.json').read_text()); depsDiff=differences(allDepPre,deps)
summary={'sourceMatches':not sourceDiff,'sourceDifferences':sourceDiff,'dependencyDifferences':depsDiff,'rootProtectedMatches':rootPre==rootPost,'rootDifferences':differences(rootPre,rootPost),'candidateDifferences':copyDiff,'onlyAllowedSourceChanges':all(d['path'] in allowed for d in copyDiff),'sourceRegularEntries':len(a),'candidateRegularEntries':len(currentCandidate),'gauntletPreserved':differences([e for e in a if e['path'].startswith('.gauntlet/')],[e for e in currentCandidate if e['path'].startswith('.gauntlet/')])==[],'allCandidateSymlinksInternal':all(e.get('internal',True) for e in currentCandidate),'existingTestsUnchanged':not any(d['path'].endswith('.test.ts') and d['path']!=allowed[2] for d in copyDiff),'journalSchemasFsyncEligibilityConfigsLockUnchanged':not any(d['path'] not in allowed for d in copyDiff)}
m.write('pre-post-summary.json',summary)
patch=''
for p in allowed:
 before=(source/p).read_text().splitlines(keepends=True) if (source/p).exists() else []
 after=(candidate/p).read_text().splitlines(keepends=True)
 patch+=''.join(difflib.unified_diff(before,after,fromfile='a/'+p if before else '/dev/null',tofile='b/'+p))
(out/'receipt-performance-r9.patch').write_text(patch)
print(json.dumps({k:v for k,v in summary.items() if 'Differences' not in k}))
print('candidate changed paths:',[d['path'] for d in copyDiff])
