// @vitest-environment node
import { mkdtempSync, readFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, expect, it } from 'vitest'
import { ShiftStore, type CommitExpected } from '../store.ts'
import { canonical, sha256 } from '../journal.ts'
import { applyVertical, emptyVertical, inputDigest } from '../vertical-state.ts'
import type { DeliveryReceipt, V2Event } from '../domain-v2.ts'

const PHONE = '5511900000001'
const actor = { kind: 'member' as const, memberPhone: PHONE }
const EPOCH = Date.parse('2026-10-04T12:00:00Z')
const TTL = 86400000
const at = (ms: number) => new Date(ms).toISOString()
const cleanup: Array<() => void> = []
afterEach(() => {
  for (const close of cleanup.splice(0).reverse()) close()
})

function receipt(id: string, receivedAt: number): V2Event {
  const payload = {
    provider: 'waha' as const,
    accountRef: 'r9-synthetic-account',
    providerMessageId: id,
    recipient: PHONE,
    deliveryStatus: 'delivery_confirmed' as const,
    simulation: true as const
  }
  const raw = canonical(payload)
  const eventIdentity = sha256(
    JSON.stringify([
      payload.provider,
      payload.accountRef,
      payload.providerMessageId,
      payload.recipient,
      payload.deliveryStatus
    ])
  )
  return {
    v: 2,
    type: 'delivery_receipt_recorded',
    at: at(receivedAt),
    actor,
    receipt: {
      ...payload,
      eventIdentity,
      receivedAt: at(receivedAt),
      committedAt: at(receivedAt),
      raw,
      rawSha256: sha256(raw),
      rawReceiptRef: 'journal:delivery:' + eventIdentity,
      eligibility: null,
      commitVerified: false
    }
  }
}
function pulse(id: string, ms: number): V2Event {
  const inbox = {
    key: JSON.stringify(['waha', 'r9-synthetic-account', id]),
    provider: 'waha' as const,
    session: 'r9-synthetic-account',
    messageId: id,
    memberPhone: PHONE,
    kind: 'text' as const,
    text: 'synthetic',
    receivedAt: at(ms),
    digest: '',
    state: 'received' as const,
    stage: 'command' as const,
    attempt: 0
  }
  inbox.digest = inputDigest(inbox)
  return { v: 2, type: 'inbound_recorded', at: at(ms), actor, inbox }
}
function fixture() {
  const dir = mkdtempSync(join(tmpdir(), 'receipt-perf-r9-'))
  cleanup.push(() => rmSync(dir, { recursive: true, force: true }))
  let store = new ShiftStore(dir)
  cleanup.push(() => store.close())
  let serial = 0
  const commit = (...changes: V2Event[]) => {
    const expected: CommitExpected = {}
    for (const event of changes)
      for (const [entity, key] of store.references(event))
        (expected[entity] ??= {})[String(key)] = store.revision(entity, key)
    return store.commit({
      transitionId: 'r9:' + ++serial,
      expected,
      changes
    })
  }
  const bytes = () => {
    const manifest = JSON.parse(
      readFileSync(join(dir, 'journal/manifest.json'), 'utf8')
    ) as { segments: Array<{ path: string }> }
    return readFileSync(join(dir, manifest.segments.at(-1)!.path))
  }
  return {
    get store() {
      return store
    },
    commit,
    bytes,
    reopen() {
      const before = bytes()
      store.close()
      store = new ShiftStore(dir)
      expect(store.storageAvailable).toBe(true)
      expect(bytes()).toEqual(before)
    }
  }
}

// Observe actual projection traversal without replacing receipt values, clocks,
// filesystem, timers or guards. Capacity checks use keys, not this iterator.
class ObservedDeliveries extends Map<string, DeliveryReceipt> {
  visits = 0;
  override [Symbol.iterator](): MapIterator<[string, DeliveryReceipt]> {
    const iterator = super[Symbol.iterator]()
    const next = iterator.next.bind(iterator)
    iterator.next = () => {
      const result = next()
      if (!result.done) this.visits++
      return result
    }
    return iterator
  }
}
it('bounds TTL traversal for 1000 receipts and 1000 pre-expiry events, then prunes at strict TTL + 1', () => {
  const state = emptyVertical()
  const deliveries = new ObservedDeliveries()
  state.deliveries = deliveries
  for (let i = 0; i < 1000; i++)
    applyVertical(state, receipt('pending-' + i, EPOCH), 0, false)
  for (let i = 0; i < 1000; i++)
    applyVertical(state, pulse('pulse-' + i, EPOCH + i), 0, false)
  applyVertical(state, pulse('exact-ttl', EPOCH + TTL), 0, false)
  expect(deliveries.size).toBe(1000)
  expect(deliveries.visits).toBeLessThanOrEqual(1000)
  const beforeExpiry = deliveries.visits
  applyVertical(state, pulse('past-ttl', EPOCH + TTL + 1), 0, false)
  expect(deliveries.size).toBe(0)
  expect(deliveries.visits - beforeExpiry).toBe(1000)
  console.info('R9_TTL_WORK', {
    receipts: 1000,
    preExpiryEvents: 1001,
    preExpiryVisits: beforeExpiry,
    expiryVisits: deliveries.visits - beforeExpiry
  })
})

it('agrees with the original expiry predicate across deterministic mixed temporal order', () => {
  const state = emptyVertical()
  const expected = new Map<string, number>()
  let seed = 0x9abc1234
  const next = () => {
    seed ^= seed << 13
    seed ^= seed >>> 17
    seed ^= seed << 5
    return seed >>> 0
  }
  for (let i = 0; i < 500; i++) {
    const ms = EPOCH + (next() % (4 * TTL)) - 2 * TTL
    const event =
      i % 3 === 0 ? pulse('mixed-' + i, ms) : receipt('mixed-' + i, ms)
    // Prior scan is an independent reference for observable receipt retention.
    for (const [key, receivedAt] of expected)
      if (ms - receivedAt > TTL) expected.delete(key)
    if (event.type === 'delivery_receipt_recorded')
      expected.set(event.receipt.eventIdentity, ms)
    applyVertical(state, event, 0, false)
    expect([...state.deliveries.keys()].sort()).toEqual(
      [...expected.keys()].sort()
    )
  }
})

it.each([-8640000000000000, 8640000000000000 - TTL - 1])(
  'preserves strict TTL at supported Date boundary %s through durable replay',
  (ms) => {
    const f = fixture()
    f.commit(receipt('boundary', ms))
    f.commit(pulse('exact-boundary', ms + TTL))
    f.reopen()
    expect(f.store.deliveries()).toHaveLength(1)
    f.commit(pulse('past-boundary', ms + TTL + 1))
    f.reopen()
    expect(f.store.deliveries()).toHaveLength(0)
  }
)

it('rebuilds strict expiry through replay with earlier receptions after later events and after pruning', () => {
  const f = fixture()
  f.commit(receipt('future', EPOCH + 1000))
  f.commit(receipt('earlier', EPOCH - 1000))
  f.reopen()
  f.commit(pulse('exact-earlier', EPOCH - 1000 + TTL))
  expect(
    f.store
      .deliveries()
      .map((d) => d.providerMessageId)
      .sort()
  ).toEqual(['earlier', 'future'])
  f.commit(pulse('expire-earlier', EPOCH - 1000 + TTL + 1))
  expect(f.store.deliveries().map((d) => d.providerMessageId)).toEqual([
    'future'
  ])
  // Reception order is allowed to move backward even after a successful prune.
  f.commit(receipt('older-after-prune', EPOCH - 2000))
  f.reopen()
  f.commit(pulse('expire-new-older', EPOCH - 2000 + TTL + 1))
  expect(f.store.deliveries().map((d) => d.providerMessageId)).toEqual([
    'future'
  ])
  f.commit(pulse('exact-future', EPOCH + 1000 + TTL))
  expect(f.store.deliveries()).toHaveLength(1)
  f.commit(pulse('expire-future', EPOCH + 1000 + TTL + 1))
  f.reopen()
  expect(f.store.deliveries()).toHaveLength(0)
  const before = f.bytes(),
    seq = f.store.sequence
  expect(() => f.commit(receipt('earlier', EPOCH + 2 * TTL))).toThrow(
    'STATE_CONFLICT'
  )
  expect(f.store.sequence).toBe(seq)
  expect(f.bytes()).toEqual(before)
})

it('does not leak pruning or a recomputed expiry from failed batch validation', () => {
  const f = fixture()
  f.commit(receipt('pending', EPOCH))
  const before = f.bytes(),
    seq = f.store.sequence
  expect(() =>
    f.commit(pulse('rolled-back-prune', EPOCH + TTL + 1), {
      v: 2,
      type: 'outbox_result',
      at: at(EPOCH + TTL + 1),
      actor,
      outboxId: 'missing',
      state: 'uncertain',
      error: 'synthetic'
    })
  ).toThrow('STATE_CONFLICT')
  expect(f.store.sequence).toBe(seq)
  expect(f.bytes()).toEqual(before)
  expect(f.store.deliveries()).toHaveLength(1)
  f.commit(pulse('live-prune', EPOCH + TTL + 1))
  expect(f.store.deliveries()).toHaveLength(0)
  f.reopen()
  expect(f.store.deliveries()).toHaveLength(0)
})

it('rolls back admission of an earlier expiry and replays successful unordered batches', () => {
  const f = fixture()
  f.commit(receipt('later', EPOCH + 1000))
  const before = f.bytes(),
    seq = f.store.sequence
  expect(() =>
    f.commit(receipt('rolled-back-earlier', EPOCH - 1000), {
      v: 2,
      type: 'outbox_result',
      at: at(EPOCH),
      actor,
      outboxId: 'missing',
      state: 'uncertain',
      error: 'synthetic'
    })
  ).toThrow('STATE_CONFLICT')
  expect(f.store.sequence).toBe(seq)
  expect(f.bytes()).toEqual(before)
  expect(f.store.deliveries().map((d) => d.providerMessageId)).toEqual([
    'later'
  ])
  f.commit(
    receipt('rolled-back-earlier', EPOCH - 1000),
    pulse('batch-prune', EPOCH - 1000 + TTL + 1)
  )
  expect(f.store.deliveries().map((d) => d.providerMessageId)).toEqual([
    'later'
  ])
  f.reopen()
  f.commit(pulse('last-prune', EPOCH + 1000 + TTL + 1))
  expect(f.store.deliveries()).toHaveLength(0)
})
