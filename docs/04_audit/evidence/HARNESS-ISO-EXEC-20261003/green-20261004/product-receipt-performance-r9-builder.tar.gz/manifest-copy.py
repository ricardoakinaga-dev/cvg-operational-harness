from pathlib import Path
import os, hashlib, json, shutil, datetime
base=Path('/home/ricardo/.cache/cvg-harness-green-20261004')
source=base/'candidate-c1-r17-integrated'; dest=base/'candidate-receipt-performance-r9'; out=base/'product-receipt-performance-r9'
exclusions=[]
def excluded(rel):
 parts=rel.parts
 return '.git' in parts or any(n=='.env' or n.startswith('.env.') for n in parts) or bool(parts and parts[0] in ('coverage','generatedrootcoverage'))
def manifest(root):
 entries=[]
 for d,dirs,files in os.walk(root,followlinks=False):
  dirs.sort(); files.sort()
  kept=[]
  for n in dirs:
   p=Path(d)/n; r=p.relative_to(root)
   if excluded(r):
    if root==source: exclusions.append(str(r))
   elif p.is_symlink():
    entries.append({'path':str(r),'kind':'symlink','target':os.readlink(p),'internal':p.resolve().is_relative_to(root)})
   else: kept.append(n)
  dirs[:]=kept
  for n in files:
   p=Path(d)/n; r=p.relative_to(root)
   if excluded(r):
    if root==source: exclusions.append(str(r))
    continue
   if p.is_symlink(): entries.append({'path':str(r),'kind':'symlink','target':os.readlink(p),'internal':p.resolve().is_relative_to(root)})
   else:
    h=hashlib.sha256()
    with p.open('rb') as f:
     for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    entries.append({'path':str(r),'kind':'file','size':p.stat().st_size,'sha256':h.hexdigest(),'mode':oct(p.stat().st_mode&0o777)})
 return sorted(entries,key=lambda x:x['path'])
def write(name,data): (out/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
if __name__=='__main__':
 docs=['AGENTS.md','docs/07_agents/AGENTS.md','docs/99_runtime_state.md','docs/20_master_execution_log.md','docs/30_backlog_master.md','docs/08_runtime/agent_coordination.md','docs/03_build/0300_build_engineer_master.md','docs/03_build/0301_roadmap.md','docs/03_build/0302_backlog_master.md','docs/02_spec/0179_shift_consumer_reliability.md','docs/02_spec/0180_shared_transport_ci_security.md']
 root=Path('/home/ricardo/Área de trabalho/cvg-operational-harness')
 write('protected-root-pre.json',[{'path':r,'sha256':hashlib.sha256((root/r).read_bytes()).hexdigest()} for r in docs if (root/r).is_file()])
 for r in docs:
  if (source/r).is_file(): (source/r).read_text()
 before=manifest(source); write('source-pre.json',before)
 def ignore(d,names):
  return [n for n in names if excluded((Path(d)/n).relative_to(source))]
 shutil.copytree(source,dest,symlinks=True,ignore=ignore,copy_function=shutil.copy2)
 copied=manifest(dest); write('copy-pre.json',copied)
 deps=[x for x in copied if 'node_modules' in Path(x['path']).parts]; write('deps-pre.json',deps)
 same=before==copied
 files=[x for x in copied if x['kind']=='file']
 separated=all((source/x['path']).stat().st_ino!=(dest/x['path']).stat().st_ino for x in files)
 write('copy-coverage.json',{'source':str(source),'candidate':str(dest),'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'copyMatches':same,'regularFiles':len(files),'symlinks':len(copied)-len(files),'dependencyEntries':len(deps),'physicalFileSeparation':separated,'allSymlinksInternal':all(x.get('internal',True) for x in copied),'exclusions':sorted(set(exclusions)),'gauntletHistoryPreserved':(source/'.gauntlet/history.jsonl').read_bytes()==(dest/'.gauntlet/history.jsonl').read_bytes(),'noHardlinks':separated})
 assert same and separated and all(x.get('internal',True) for x in copied)
 print('COPY PASS',len(copied),'entries,',len(deps),'dependency entries, all files physically private, links internal')
