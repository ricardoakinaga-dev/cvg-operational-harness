from pathlib import Path
import subprocess, json, time, datetime, hashlib, sys
out=Path(__file__).parent
candidate=out.parent/'candidate-receipt-performance-r9'
node='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node'
(out/'tmp').mkdir(exist_ok=True)
env={'PATH':str(Path(node).parent)+':/usr/bin:/bin','HOME':'/home/ricardo','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'America/Sao_Paulo','CI':'true','TMPDIR':str(out/'tmp')}
name=sys.argv[1]; kind=sys.argv[2]; args=sys.argv[3:]
if kind=='vitest':
 cmd=[node,'node_modules/vitest/vitest.mjs','run',*args,'--no-cache','--no-file-parallelism','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(out/(name+'.vitest.json'))]
else: cmd=[node,*args]
start=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.monotonic()
log=out/(name+'.log')
with log.open('w') as f:
 p=subprocess.run(cmd,cwd=candidate,env=env,stdout=f,stderr=subprocess.STDOUT)
r={'name':name,'command':cmd,'cwd':str(candidate),'node':subprocess.check_output([node,'--version'],text=True).strip(),'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wallSeconds':time.monotonic()-t,'exitCode':p.returncode,'logSha256':hashlib.sha256(log.read_bytes()).hexdigest(),'scope':'synthetic private copy, scoped execution, original 15000ms timeout/global coverage include/thresholds preserved; no inherited app/PG/provider environment','environmentKeys':sorted(env)}
j=out/(name+'.vitest.json')
if j.is_file():
 v=json.loads(j.read_text()); r['counts']={k:v.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTotalTestSuites','success']}
 r['testTimings']=[{'file':Path(s['name']).name,'name':a['fullName'],'status':a['status'],'durationMs':a.get('duration'),'failureMessages':a.get('failureMessages',[])} for s in v['testResults'] for a in s['assertionResults'] if a['status']!='pending']
(out/(name+'.result.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:r[k] for k in ['name','node','wallSeconds','exitCode']},ensure_ascii=False),flush=True)
if 'counts' in r: print(json.dumps(r['counts']),flush=True)
print('\n'.join(log.read_text().splitlines()[-8:]),flush=True)
