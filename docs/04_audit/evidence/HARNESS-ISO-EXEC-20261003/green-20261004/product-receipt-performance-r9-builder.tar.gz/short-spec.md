# RECEIPT-PERFORMANCE-R9 — short SPEC before BUILD

Task authorized explicitly by the user for synthetic BUILD under approved SPEC0179/0180. Source readonly; isolated physical dependencies, internal symlinks. State/log/backlog in this evidence directory only per explicit no Root/Main updates.

Problem: prunePendingDeliveries scans up to 1000 unmatched receipts on every V2 event, repeatedly parsing timestamps even when no receipt can expire. Historical profile is readonly diagnostic evidence, not baseline acceptance.

Design: add a numeric nextPendingDeliveryExpiry to VerticalState, initialized to Infinity. It is a conservative lower bound on the minimum receivedAt + 86400000 of unmatched receipts, never greater than the true minimum. Admission lowers the bound with Math.min for arbitrary temporal event order. Matching may leave the bound conservatively stale (earlier); pruning recomputes it from remaining unmatched receipts only. Return early only when Date.parse(at) <= bound (strict expiry > TTL preserved). Ignore invalid receipt timestamp in the bound because original comparison cannot expire NaN. A nonfinite event timestamp must still have equivalent behavior. Derived primitive is copied into the validation state and rebuilt by normal journal replay, never stored in journal nor kept in shared/external mutable indexes. Failed validation/batch/append must not change live derivation. No schema change.

Frozen acceptance:
- A1 private copy manifest of source/dependencies pre/post, equal original code/tests/config/lock/gauntlet history, physically separate regular files and internal symlinks; source and Root untouched.
- A2 baseline local on Node22 before fix: existing operations saturation/receipt invariants with original 1000 fixture/15000ms timeout and original <1300ms job bar. Preserve raw failures and timings.
- A3 conservative derived lower-bound eliminates repeated scans before earliest expiry; strict TTL edge, unordered timestamps including rollback to earlier reception after prune, matched durable retention, expired unmatched only.
- A4 failed multi-event validation after lowering and after pruning cannot leak state; validate through real durable store and replay, journal unchanged on failure. Dedup/overflow/causal/eligibility inherited tests unchanged.
- A5 focused existing operations/receipt suites plus own new regression on real Node22; V8 focus retains global include/thresholds and records expected global coverage failure as scoped evidence, never global PASS. No timers mocks, fsync bypass or assertion weakening.
- A6 fresh read-only critic without inherited context/descendants, pre/post candidate fingerprint; finite report and patch. No integration, production/release/certification claim.

Plan: manifest/copy -> baseline -> implement two files and new own tests -> focus/V8 + product regression/types/lint -> fresh critique -> address valid bounded findings -> finite report and handoff.

Limitations: disk fsync and assertion equality costs remain. Full Root/PG/E2E/provider/network gates explicitly out of scope. Existing failing fsync timings remain visible; an improvement is not a global certification.
