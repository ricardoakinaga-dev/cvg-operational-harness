from pathlib import Path
import json,hashlib,datetime
from importlib.machinery import SourceFileLoader
out=Path(__file__).parent
m=SourceFileLoader('r9_manifest',str(out/'manifest-copy.py')).load_module()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def aggregate(entries):return hashlib.sha256(json.dumps(entries,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
pre=json.loads((out/'copy-pre.json').read_text()); now=m.manifest(m.dest)
native=[e for e in now if 'node_modules' not in Path(e['path']).parts]
nativePre=[e for e in pre if 'node_modules' not in Path(e['path']).parts]
deps=[e for e in now if 'node_modules' in Path(e['path']).parts]
write(out/'native-pre.json',nativePre); write(out/'native-post.json',native)
write(out/'critic-artifact-pre.json',now)
allowed=['products/shift-assistant/src/vertical-state.ts','products/shift-assistant/src/store.ts','products/shift-assistant/src/__tests__/receipt-performance-r9-own.test.ts']
beforeNative={e['path']:e for e in nativePre}; afterNative={e['path']:e for e in native}
nativeDiff=[p for p in sorted(beforeNative.keys()|afterNative.keys()) if beforeNative.get(p)!=afterNative.get(p)]
copyProof=json.loads((out/'copy-coverage.json').read_text())
assert set(nativeDiff)==set(allowed), nativeDiff
assert all(e.get('internal',True) for e in now)
packet=out/'critic-packet'; packet.mkdir(exist_ok=True)
for p in allowed:
 target=packet/'candidate'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((m.dest/p).read_bytes())
 if (m.source/p).is_file():
  target=packet/'original'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((m.source/p).read_bytes())
inputs=['short-spec.md','claim.json','receipt-performance-r9.patch','copy-coverage.json','pre-post-summary.json','source-pre.json','source-post.json','deps-pre.json','deps-post.json','native-pre.json','native-post.json','critic-artifact-pre.json','baseline-receipts.log','baseline-receipts.result.json','baseline-own.log','baseline-own.result.json','baseline-saturation-r3.log','baseline-saturation-r3.result.json','post-receipts.log','post-receipts.result.json','post-saturation-r3.log','post-saturation-r3.result.json','post-v8-profile.log','post-v8-profile.result.json','post-v8-scoped.log','post-v8-scoped.result.json','post-journal-regression.log','post-journal-regression.result.json','final-typecheck.log','final-typecheck.result.json','final-lint.log','final-lint.result.json','format.log','format.result.json','post-profile-summary.json','coverage-scoped/coverage-summary.json']
seal={'task':'RECEIPT-PERFORMANCE-R9','sealedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceReadonly':str(m.source),'candidate':str(m.dest),'node':'v22.23.2','scope':'bounded private synthetic optimization; not full acceptance','nativeDefinition':'All copied inputs outside every node_modules directory (including unchanged source .gauntlet/history). This is a superset copy inventory, not the historical 7814/8474 narrowed inventory.','source':{'preSha256':sha(out/'source-pre.json'),'postSha256':sha(out/'source-post.json'),'entries':len(json.loads((out/'source-post.json').read_text())),'equal':json.loads((out/'source-pre.json').read_text())==json.loads((out/'source-post.json').read_text())},'dependencies':{'preSha256':sha(out/'deps-pre.json'),'postSha256':sha(out/'deps-post.json'),'entries':len(deps),'equal':json.loads((out/'deps-pre.json').read_text())==json.loads((out/'deps-post.json').read_text()),'physicalPrivateFiles':copyProof['physicalFileSeparation'],'allSymlinksInternal':all(e.get('internal',True) for e in now)},'native':{'preAggregateSha256':aggregate(nativePre),'postAggregateSha256':aggregate(native),'preEntries':len(nativePre),'postEntries':len(native),'allowedChanges':allowed,'originalInputsUnchangedExceptTwoOwnedCodeFiles':all(p in allowed[:2] for p in nativeDiff if p in beforeNative),'existingTestsConfigLockJournalUnchanged':set(nativeDiff)==set(allowed),'gauntletHistoryUnchanged':beforeNative['.gauntlet/history.jsonl']==afterNative['.gauntlet/history.jsonl']},'candidateFingerprint':aggregate(now),'candidateEntryCount':len(now),'inputs':[{'path':p,'sha256':sha(out/p)} for p in inputs],'criticPacket':[{'path':str(p.relative_to(packet)),'sha256':sha(p)} for p in sorted(packet.rglob('*')) if p.is_file()],'rootLedgerSentinel':'Concurrent Lead checkpoint44 changed four shared docs; untouched by Builder and not restored. Drift recorded in pre-post-summary.json. Root is not candidate/source and no Root files were written by this task.','nonExecuted':['full','PG','E2E','network/provider','original <1300ms socket job test (no-network scope)'],'noGlobalGreen':True}
write(out/'review-seal.json',seal)
print('seal',sha(out/'review-seal.json'),'fingerprint',seal['candidateFingerprint'],'native',len(native),'deps',len(deps))
