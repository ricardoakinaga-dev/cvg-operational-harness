import json,collections
from pathlib import Path
out=Path(__file__).parent
profiles=[]
for p in sorted((out/'post-cpu').glob('*.cpuprofile')):
 j=json.loads(p.read_text()); nodes={n['id']:n for n in j['nodes']}; costs=collections.Counter()
 for nid,delta in zip(j.get('samples',[]),j.get('timeDeltas',[])):
  cf=nodes[nid]['callFrame']; costs[(cf.get('functionName',''),cf.get('url',''),cf.get('lineNumber',-1)+1)]+=delta/1000
 profiles.append({'profile':p.name,'totalSampledMs':sum(costs.values()),'top':[{'function':k[0],'url':k[1],'line':k[2],'sampledMs':v} for k,v in costs.most_common(20)],'ttlPruneSelfSampledMs':sum(v for k,v in costs.items() if k[0]=='prunePendingDeliveries'),'fsyncSelfSampledMs':sum(v for k,v in costs.items() if k[0]=='fsync')})
r={'scope':'post-fix scoped receipts/own tests with V8 and CPU profiling; workload differs from readonly historical filtered profile; samples include profiler overhead, not global acceptance or wallclock speedup','profiles':profiles,'historicalReadonlyReference':'../product-timing-profile-r1/profile-summary.json'}
(out/'post-profile-summary.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps([{'profile':p['profile'],'ttlPruneSelfSampledMs':p['ttlPruneSelfSampledMs'],'fsyncSelfSampledMs':p['fsyncSelfSampledMs']} for p in profiles]))
