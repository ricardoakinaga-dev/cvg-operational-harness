
// R13: entering a physical package context governs its nested metadata.
describe('R13 reached package recursive actor census', () => {
  function fixture(id, extension, reached, nested) {
    const root=path.join(output,'r13-inert',id)
    const put=(rel,value)=>{const p=path.join(root,rel);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof value==='string'?value:JSON.stringify(value))}
    for(const dir of ['packages/core/src','apps','legacy','products','auxiliary/bridge/dist'])fs.mkdirSync(path.join(root,dir),{recursive:true})
    put('package.json',{private:true,type:'module',workspaces:['packages/*']})
    put('packages/core/package.json',{name:'@synthetic/core',type:'module'})
    put('tsconfig.base.json',{compilerOptions:{module:'NodeNext',moduleResolution:'NodeNext',target:'ESNext',allowJs:true}})
    put('packages/core/src/index.mts',reached?'import "../../../auxiliary/bridge/src/index.'+extension+'";':'export const label="neutral";')
    put('auxiliary/bridge/package.json',{name:'@synthetic/bridge',type:'module'})
    put('auxiliary/bridge/src/index.'+extension,'export const label="bridge";')
    if(nested==='symlink'){
      put('auxiliary/bridge/dist/target.json',{type:'module'})
      fs.symlinkSync('target.json',path.join(root,'auxiliary/bridge/dist/package.json'))
    }else put('auxiliary/bridge/dist/package.json',nested)
    return root
  }
  const cases=[['array',[]],['dependency',{dependencies:[]}],['type',{type:'invalid'}],['local',{dependencies:{neutral:'file:missing'}}],['symlink','symlink']]
  it.each(['mts','mjs'].flatMap(ext=>cases.map(([id,value])=>[ext,id,value])))('%s/%s reached nested metadata fails closed',(ext,id,value)=>{
    expect(()=>auditProductBoundary(fixture('reached-'+ext+'-'+id,ext,true,value))).toThrow()
  })
  it.each(['mts','mjs'].flatMap(ext=>cases.map(([id,value])=>[ext,id,value])))('%s/%s opaque unreferenced actor remains separate',(ext,id,value)=>{
    expect(auditProductBoundary(fixture('opaque-'+ext+'-'+id,ext,false,value)).status).toBe('PASS')
  })
  it.each(['mts','mjs'])('%s valid reached nested context stays valid',(ext)=>{
    expect(auditProductBoundary(fixture('valid-'+ext,ext,true,{type:'module',dependencies:{neutral:'1.0.0'}})).status).toBe('PASS')
  })
})
