import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { createRequire, stripTypeScriptTypes } from 'node:module'
import { pathToFileURL } from 'node:url'
const out = path.dirname(new URL(import.meta.url).pathname)
assert.match(process.version, /^v22\./)
const root = path.join(out, 'runtime')
const hash = x => createHash('sha256').update(x).digest('hex')
const src = fs.readFileSync(path.join(root, 'apps/api/src/rate-limit.ts'), 'utf8')
const moduleFile = path.join(root, 'rate-limit.mjs')
fs.writeFileSync(moduleFile, stripTypeScriptTypes(src, {mode:'transform'}))
const {PostgresRateLimiter,InMemoryRateLimiter,createControlledRateLimitKeyRing,createConfiguredRateLimitKeyRing} = await import(pathToFileURL(moduleFile))
const report = {node:process.version,nodeExecutable:process.execPath,sourceHash:hash(src),checks:[],limitations:['No Fastify/Vitest/TypeScript dependency available in authorized frozen inputs. Direct source-exact registration and limiter probes; full HTTP pipeline inspected statically.','Deterministic queryable adapter is not PostgreSQL; no SQL locking/concurrency/restart proof.','Fixture eval/Function builders execute; auditProductBoundary cannot execute without TypeScript. Negative gate assertions inspected statically.']}
const check = (name,details={}) => report.checks.push({name,status:'PASS',...details})
const server = fs.readFileSync(path.join(root, 'apps/api/src/server.ts'), 'utf8')
const a=server.indexOf('  const rateLimiter: RateLimiterPort ='),b=server.indexOf('  // REM21-003',a)
assert(a>=0 && b>a)
const registration=server.slice(a,b)
assert(a<server.indexOf("'/v1/admin/agents/:agentId/versions/:versionId/publish'"))
assert(b<server.indexOf("app.post('/v1/admin/agents/:agentId/rollback'"))
function capture(limiter) {
  const events=[],app={addHook:(name,fn)=>events.push({name,fn})}
  vm.runInNewContext(stripTypeScriptTypes(registration,{mode:'transform'}),{app,options:{rateLimiter:limiter},InMemoryRateLimiter,healthRoute:'/health',liveRoute:'/health/live',readyRoute:'/health/ready',createCorrelationId:()=> 'independent-synthetic-correlation',fail:(code,message,correlationId)=>({success:false,error:{code,message},correlationId})})
  assert.equal(events.length,1);assert.equal(events[0].name,'onRequest');return events[0].fn
}
check('original global registration precedes both flagged routes',{registrationHash:hash(registration),startLine:server.slice(0,a).split('\n').length,endLine:server.slice(0,b).split('\n').length-1})
function reply(){return {statusCode:200,headers:{},sent:false,body:undefined,code(c){this.statusCode=c;return this},header(k,v){this.headers[k]=v;return this},send(body){this.sent=true;this.body=body;return this}}}
const routes=['/v1/admin/agents/agent_00000000-0000-0000-0000-000000000001/versions/version_00000000-0000-0000-0000-000000000002/publish','/v1/admin/agents/agent_00000000-0000-0000-0000-000000000001/rollback']
for(const url of routes){
  for(const mode of ['sync_throw','async_reject','deny']){
    let calls=0;const sentinel=new Error('synthetic outage detail must not escape')
    const limiter={check:(key,policy)=>{calls++;assert.equal(key,'ip:192.0.2.1');assert.equal(policy.max,300);assert.equal(policy.windowMs,60000);if(mode==='sync_throw')throw sentinel;if(mode==='async_reject')return Promise.reject(sentinel);return {allowed:false,retryAfterSeconds:17}}}
    const fn=capture(limiter),r=reply();await fn({url,ip:'192.0.2.1'},r)
    assert.equal(calls,1);assert(r.sent);assert.equal(r.statusCode,429);assert.equal(r.body.error.code,'rate_limited');assert.equal(r.headers['cache-control'],'no-store');assert.equal(r.headers['retry-after'],mode==='deny'?'17':'60');assert(!JSON.stringify(r.body).includes(sentinel.message))
    check('flagged route hook denies '+mode,{route:url.split('/').at(-1),replySent:true,statusCode:429})
  }
  let release;const waiting=new Promise(r=>release=r);let settled=false
  const fn=capture({check:async()=>{await waiting;return {allowed:false,retryAfterSeconds:4}}}),r=reply()
  const run=fn({url,ip:'192.0.2.1'},r).then(()=>settled=true)
  await Promise.resolve();assert(!settled);assert(!r.sent);release();await run;assert.equal(r.statusCode,429)
  check('flagged route awaits limiter before denial',{route:url.split('/').at(-1)})
  const ok=reply();await capture({check:()=>({allowed:true,retryAfterSeconds:0})})({url,ip:'192.0.2.1'},ok);assert(!ok.sent)
  check('allowed control leaves hook unsent',{route:url.split('/').at(-1)})
  const failStore=new PostgresRateLimiter({query:async()=>{throw new Error('synthetic store unavailable')}},{keyRing:createControlledRateLimitKeyRing()})
  const denied=reply();await capture(failStore)({url,ip:'192.0.2.1'},denied);assert.equal(denied.statusCode,429);assert(denied.sent)
  check('actual persistent class failure reaches exact hook denial',{route:url.split('/').at(-1)})
}
let storeCalls=0;const exempt=capture({check:()=>{storeCalls++;throw new Error('synthetic unavailable')}})
for(const url of ['/health','/health/live','/health/ready','/health/metrics']){const r=reply();await exempt({url,ip:'192.0.2.1'},r);assert(!r.sent)}
assert.equal(storeCalls,0);check('infrastructure exemption limited to exact four paths')
const notExempt=reply();await exempt({url:routes[0]+'?probe=/health',ip:'192.0.2.1'},notExempt);assert.equal(notExempt.statusCode,429);check('query parameter cannot exempt publish')
let budgetCalls=0;const memory=new InMemoryRateLimiter(()=>1000),tracked={check:(k,p)=>{budgetCalls++;return memory.check(k,p)}},mh=capture(tracked)
for(let i=0;i<300;i++){const r=reply();await mh({url:routes[0],ip:'192.0.2.1',headers:{'x-forwarded-for':'198.51.100.'+(i%200)}},r);assert(!r.sent)}
const blocked=reply();await mh({url:routes[1],ip:'192.0.2.1'},blocked);assert.equal(blocked.statusCode,429);assert.equal(budgetCalls,301)
check('actual 300-request IP budget crosses publish and rollback',{checks:301,forgedHeadersIgnoredByHook:true})
const records=new Map();let sqlSeen='',params=[]
const db={query:async(text,values=[])=>{sqlSeen=text;params=values;if(!text.includes('INSERT INTO rate_limit_buckets'))return {rows:[]};const [key,version,digest,cap,ms]=values;const prev=records.get(key);if(!prev&&records.size>=cap)return {rows:[]};const row={count:(prev?.count??0)+1,reset_at:new Date(Date.now()+Number(ms))};records.set(key,row);return {rows:[row]}}}
const kr=createControlledRateLimitKeyRing(),first=new PostgresRateLimiter(db,{keyRing:kr}),second=new PostgresRateLimiter(db,{keyRing:kr})
assert((await first.check('synthetic-client',{max:2,windowMs:60000})).allowed)
assert((await second.check('synthetic-client',{max:2,windowMs:60000})).allowed)
assert(!(await second.check('synthetic-client',{max:2,windowMs:60000})).allowed)
assert.match(sqlSeen,/pg_advisory_xact_lock/);assert.match(sqlSeen,/ON CONFLICT \(budget_key\) DO UPDATE/);assert.match(params[0],/^[a-f0-9]{64}$/);assert.match(params[2],/^[a-f0-9]{64}$/);assert(!params.includes('synthetic-client'))
check('actual persistent class shares queryable budget with bound HMAC keys',{rows:records.size})
const full=new PostgresRateLimiter({query:async()=>({rows:[]})},{keyRing:kr}),fr=reply();await capture(full)({url:routes[0],ip:'192.0.2.1'},fr);assert.equal(fr.statusCode,429);check('persistent capacity exception denies original hook')
assert.equal(createConfiguredRateLimitKeyRing({NODE_ENV:'production'}),undefined);assert(createConfiguredRateLimitKeyRing({NODE_ENV:'test'}));check('synthetic fallback only in test mode')
const fixture=fs.readFileSync(path.join(root,'tests/product-boundary-code-execution.test.js'),'utf8')
const ca=fixture.indexOf('const j = JSON.stringify'),cb=fixture.indexOf("describe('unknown code execution",ca)
const box={pathToFileURL,process,path};vm.runInNewContext(fixture.slice(ca,cb)+'\nglobalThis.cases=nativeCases',box)
const marker=path.join(root,'synthetic-marker.cjs');fs.writeFileSync(marker,'globalThis.__INDEPENDENT_SYNTHETIC_MARKER=(globalThis.__INDEPENDENT_SYNTHETIC_MARKER||0)+1;module.exports=1;\n')
const require=createRequire(import.meta.url),evalSource=box.cases[0][1](marker),functionSource=box.cases[1][1](marker)
new Function('require',evalSource)(require);assert.equal(globalThis.__INDEPENDENT_SYNTHETIC_MARKER,1)
await eval(functionSource);assert.equal(globalThis.__INDEPENDENT_SYNTHETIC_MARKER,1)
assert(fixture.includes('expect(audit.passed).toBe(false)'));assert(fixture.includes("e.reason === 'UNVERIFIED_DYNAMIC_CODE_EXECUTION'"));assert(fixture.includes("expect(native.stdout).toContain('SYNTHETIC_PRODUCT_LOADED')"))
check('original eval/Function fixture builders intentionally execute controlled product',{builderSourceHash:hash(fixture.slice(ca,cb)),negativeAuditAssertionPresent:true,actualBoundaryAuditorRun:false})
delete globalThis.__INDEPENDENT_SYNTHETIC_MARKER
fs.writeFileSync(path.join(out,'probe-results.json'),JSON.stringify({...report,result:'PASS'},null,2)+'\n')
console.log(JSON.stringify({node:process.version,checks:report.checks.length,result:'PASS',limitations:report.limitations.length}))
