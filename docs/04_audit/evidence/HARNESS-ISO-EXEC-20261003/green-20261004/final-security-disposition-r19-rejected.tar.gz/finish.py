import json,pathlib,re,collections,zipfile,datetime
from review_common import S,Q,O,sha,inventory
def write(name,obj):(O/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def ref(file,a,z):
 b=(S/file).read_bytes();ls=b.splitlines(keepends=True)
 return {'file':file,'startLine':a,'endLine':z,'hashsource':sha(b),'hashline':sha(ls[a-1]),'hashlines':[{'line':j+1,'sha256':sha(ls[j])} for j in range(a-1,z)]}
before_s=json.loads((O/'source-sentinel-before.json').read_text());before_q=json.loads((O/'scans-sentinel-before.json').read_text())
after_s=inventory(S);after_q=inventory(Q);write('source-sentinel-after.json',after_s);write('scans-sentinel-after.json',after_q)
assert before_s==after_s,'source drift';assert before_q==after_q,'scan drift'
source={x['path']:x['sha256'] for x in after_s if 'sha256' in x}
mapping=json.loads((Q/'source-mapping.json').read_text())
assert all(source.get(x['path'])==x['sha256'] for x in mapping)
private_env=[p for p in source if re.search(r'(^|/)\.env($|\.)',p) and not p.endswith('.env.example')]
assert not private_env
manifest=json.loads((Q/'manifest.json').read_text())
for x in manifest['files']:
 if x['kind']=='file':assert sha((Q/x['path']).read_bytes())==x['sha256'],x['path']
listed={x['path'] for x in manifest['files']}
unlisted=sorted(x['path'] for x in after_q if 'sha256' in x and x['path'] not in listed and x['path'] not in ['manifest.json','manifest.sha256'])
archive={};archive_non_native=[]
with zipfile.ZipFile(Q/'codeql-db/src.zip') as z:
 names=z.namelist();prefix=str(S).lstrip('/')+'/'
 for n in names:
  if n.startswith(prefix) and n[len(prefix):] in source:
   rel=n[len(prefix):];h=sha(z.read(n));archive[rel]=h;assert h==source[rel],rel
  else:archive_non_native.append(n)
ext={'.cjs','.cts','.htm','.html','.js','.jsx','.mjs','.mts','.ts','.tsx','.vue'}
expected=sorted(p for p in source if pathlib.Path(p).suffix in ext and not p.startswith('docs/04_audit/evidence/'))
absent=sorted(set(expected)-set(archive))
absent_categories=collections.Counter('nested_dependency' if '/node_modules/' in p else 'declaration' if p.endswith('.d.ts') else 'dist_directory' if '/dist/' in p else 'other' for p in absent)
bqrs=json.loads((Q/'codeql-executed-query-results.json').read_text())
assert all(sha((Q/x['path']).read_bytes())==x['sha256'] for x in bqrs)
sarif=json.loads((Q/'raw/codeql.sarif').read_text());runs=sarif['runs'];results=[x for r in runs for x in r.get('results',[])];assert len(results)==3
raw=json.loads((Q/'raw/gitleaks.json').read_text());assert len(raw)==6575 and all(x['Secret']==x['Match']=='REDACTED' for x in raw)
coverage={'measuredNativeFiles':len(source),'sourceMappingRows':len(mapping),'allSourceMappingSHA256Match':True,'sourceAndScansBytesMetadataUnchanged':True,'privateEnvPresent':private_env,'gitleaks':{'findings':len(raw),'allSecretMatchFieldsRedacted':True,'mode':'dir; no Git history','configSHA256':sha((Q/'tools/strict-default.toml').read_bytes()),'strictDefaultContent':(Q/'tools/strict-default.toml').read_text(),'ignoreFileBytes':(Q/'tools/empty.gitleaksignore').stat().st_size,'allowCommentsIgnored':'--ignore-gitleaks-allow' in json.loads((Q/'commands/gitleaks.json').read_text())['argv'],'limitations':['No Git history, private env, live credentials or external services examined.','Enumeration/command do not prove every binary/archive/nested encoding decoded; scanner not rerun.','Only current reported findings dispositioned; not proof all possible secrets absent.']},'codeql':{'archiveEntries':len(names),'archiveNativeFiles':len(archive),'archiveNativeSHA256Match':True,'archiveNonNativeCount':len(archive_non_native),'expectedCodeOutsideConfiguredExclusion':len(expected),'absentCount':len(absent),'absentCategories':dict(absent_categories),'absentPaths':absent,'resolvedQueryPaths':len(json.loads((Q/'raw/codeql-resolved-queries.json').read_text())),'queryManifestEntries':len(json.loads((Q/'codeql-query-manifest.json').read_text())),'bqrsResults':len(bqrs),'bqrsResultHashesVerified':True,'sarifRules':len(runs[0]['tool']['driver']['rules']),'config':'.github/codeql/active-source.yml','configSHA256':source['.github/codeql/active-source.yml'],'limitations':['252 expected paths absent from extraction archive; dependency/declaration/dist coverage not certified.','Archive inclusion is not proof every file semantically analyzed by every query.','JS/TS suite does not cover other languages.','89 frozen BQRS hashes verified; external query-pack source not opened/rerun.']},'scanManifest':{'recordedFilesVerified':len(manifest['files']),'sha256':sha((Q/'manifest.json').read_bytes()),'unlistedFiles':unlisted}}
write('coverage.json',coverage)
f=json.loads((Q/'findings.json').read_text())[-3:];cq=[]
for i,item in enumerate(f):
 loc=item['locations'][0]['region'];a=loc['startLine'];z=loc.get('endLine',a);r={**item,'line':a,'endLine':z,**{k:v for k,v in ref(item['file'],a,z).items() if k in ['hashsource','hashline','hashlines']},'archiveSameBytesAsSource':archive.get(item['file'])==source[item['file']]}
 if i<2:
  r.update(disposition='PENDING',category='CONTROL_PRESENT_DYNAMIC_ROUTE_BINDING_UNVERIFIED',reason='Current source registers the same Fastify app global onRequest limiter before this route, awaits limiter.check(ip:request.ip,300/60000), and sends/returns 429 on exhaustion or store error. Exact original registration and actual persistent class failure passed own Node22 probes. Real Fastify request->hook->registered route short-circuit was not exercised: dependencies are absent from authorized inputs. A genuinely absent limiter is not demonstrated, but required real route-binding evidence remains unresolved.',evidence={'sameAppSourceReferences':[ref('apps/api/src/server.ts',333,334),ref('apps/api/src/server.ts',440,454),ref('apps/api/src/server.ts',547,590),ref('apps/api/src/server.ts',3192,3199),ref('apps/api/src/server.ts',3292,3298),ref('apps/api/src/server.ts',3804,3806)],'persistentWiring':[ref('apps/api/src/server.ts',5282,5293),ref('apps/api/src/server.ts',5366,5374),ref('apps/api/src/server.ts',5428,5447),ref('apps/api/src/rate-limit.ts',362,461)],'probeArtifact':'probe-results.json','probeSHA256':sha((O/'probe-results.json').read_bytes()),'actualHTTPRouteExecution':False,'actualPostgresExecution':False,'closureRequired':'Fresh isolated Fastify execution of both exact registered routes proving awaited persistent limiter denial and zero route/platform side effects, using authorized frozen dependencies.'})
 else:
  r.update(disposition='FALSE_POSITIVE',category='SYNTHETIC_NEGATIVE_EXECUTION_FIXTURE',reason='JSON.stringify encodes a generated test program with a fixture-owned target path; it is not claimed as a security sanitizer for untrusted runtime code. fixture() creates its synthetic product/core modules; native source intentionally loads the product, assertions require audit.passed=false plus UNVERIFIED_DYNAMIC_CODE_EXECUTION. The connected classifier registers eval/Function executors, emits loaderDiagnostic and only status PASS sets passed=true. Own Node22 probes executed original eval/Function builders on a local marker. Full TypeScript-backed gate inspected, not rerun.',evidence={'producerAndAssertions':[ref(item['file'],10,32),ref(item['file'],37,59),ref(item['file'],60,87)],'connectedGuard':[ref('scripts/check-product-boundary.mjs',1038,1067),ref('scripts/check-product-boundary.mjs',1574,1593),ref('scripts/boundary-code-execution.mjs',49,56),ref('scripts/boundary-code-execution.mjs',480,509)],'probeArtifact':'probe-results.json','probeSHA256':sha((O/'probe-results.json').read_bytes()),'nativeBuildersExecuted':['eval','Function'],'actualBoundaryGateExecuted':False})
 cq.append(r)
write('codeql-ledger.json',cq)
gl=json.loads((O/'gitleaks-ledger.json').read_text());assert len(gl)==6575 and all(r['disposition']=='FALSE_POSITIVE' for r in gl)
ledger=gl+cq
for r in ledger:assert r['rule'] and r['file'] and r['line'] and re.fullmatch('[0-9a-f]{64}',r['hashsource']) and re.fullmatch('[0-9a-f]{64}',r['hashline']) and len(r['reason'])>30
assert len({r['id'] for r in ledger})==6578
write('ledger.json',ledger)
with (O/'ledger.jsonl').open('w') as stream:
 for r in ledger:stream.write(json.dumps(r,ensure_ascii=False)+'\n')
cat=collections.Counter(r['category'] for r in gl);counts=collections.Counter(r['disposition'] for r in ledger)
proc={'id':'PROC-001','severity':'review-validity-blocker','status':'CONFIRMED','reason':'Bootstrap read workspace governance outside latest no-Root/packet authority. Coordination text exposed previous judgments before scoped review. No verdict was imported as disposition evidence; strict fresh-context independence cannot be certified.','readPaths':['docs/07_agents/AGENTS.md','docs/99_runtime_state.md','docs/20_master_execution_log.md','docs/30_backlog_master.md','docs/08_runtime/agent_coordination.md'],'writesOutsidePackage':False,'remedy':'Fresh reviewer receives only authority/frozen source/frozen scans; these dispositions are working evidence rather than inherited acceptance.'}
write('provenance.json',{'authoritySHA256':sha((O/'authority.json').read_bytes()),'genericSkill':'/home/ricardo/.agents/skills/engineering-framework/SKILL.md','forbiddenBootstrapRead':proc,'previousBaselineCompared':False,'previousVerdictsImported':False,'runtime':'physical copies of five source files; Node22 builtin TS transform; original inputs untouched','runtimeNodeExecutable':'/home/ricardo/.nvm/versions/node/v22.23.2/bin/node','runtimeNodeExecutableSHA256':sha(pathlib.Path('/home/ricardo/.nvm/versions/node/v22.23.2/bin/node').read_bytes()),'runtimeExecutions':1,'noNetworkPGProviderInstallAgentsProduction':True,'sourceExcerptHandling':'All exact finding excerpts read mechanically, values not included in ledgers; masked manual views. Some benign synthetic literals visible in bootstrap/early tool output before masking. No real secret identified.','lineHashDefinition':'SHA256 of raw UTF-8 source line INCLUDING original terminator; hashsource entire file bytes; each multiline alert has per-line hashlines. Gitleaks original byte columns retained; reason examines the full corresponding assignment/JSON object.'})
summary={'task':'FINAL_SECURITY_DISPOSITION_R19','status':'COMPLETED_FINITE_REVIEW','verdict':'REJECT','scope':'current 6575 Gitleaks + 3 CodeQL; no production acceptance','total':6578,'dispositions':dict(counts),'gitleaksCategories':dict(cat),'realFindingsConfirmed':0,'pendingFindings':[r['id'] for r in cq if r['disposition']=='PENDING'],'proceduralBlockers':['PROC-001'],'probes':{'checks':20,'status':'PASS','node':'v22.23.2','fullFastifyHTTP':False,'Postgres':False,'fullBoundaryGate':False},'inputIntegrity':'full source/scans SHA256+size/mtime/mode unchanged; source mapping and scan manifest verified','finiteStop':'6578 individual records complete. Two CodeQL records remain PENDING for real HTTP route binding; initial independence deviation preserved. No further test/scanner execution justified with supplied inputs.'}
write('summary.json',summary)
write('runtime-state.json',{'status':'COMPLETED_FINITE_REVIEW_REJECT','last_completed_action':'6578 records, 20 own Node22 checks, complete frozen-input/coverage verification','next_action':'Fresh finite reviewer plus frozen authorized dependencies only if closing PROC-001 and the two CodeQL PENDING is requested; no implicit continuation/production grant.'})
write('backlog.json',{'items':[{'id':r['id'],'status':'PENDING','reason':r['reason'],'closureRequired':r['evidence']['closureRequired']} for r in cq[:2]]+[proc]})
(O/'execution-log.jsonl').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'task':summary['task'],'verdict':'REJECT','verification':'summary.json','changes':'package only; source/scans unchanged','terminal':True})+'\n')
report=f'''# Revisão finita de segurança R19

**REJECT.** Ledger individual dos 6.578 achados atuais. Gitleaks: **6.575 FALSE_POSITIVE, 0 REAL, 0 PENDING**. CodeQL: **1 FALSE_POSITIVE e 2 PENDING**. Nenhum defeito genuíno ou segredo real confirmado; PENDING não significa vulnerabilidade demonstrada.

Os dois PENDING são R19-CODEQL-001 (server.ts:3194, publish) e R19-CODEQL-002 (server.ts:3292, rollback). O código liga o mesmo app Fastify ao hook global antes das rotas: IP efetivo, await, 300/60s, 429 retornado em erro/esgotamento, keyring exigido fora de teste e limiter persistente injetado no bootstrap. **20 probes próprios em Node 22.23.2 PASS**, em cópia física: registro/hook original, exceção/rejeição, espera, capacidade, esgotamento entre URLs e erro da classe persistente. Contudo, não há dependências Fastify/Vitest/TypeScript instaladas nos insumos autorizados: **não executei a requisição HTTP nas duas rotas reais**, nem PostgreSQL. Capture/adapter não substitui a ligação dinâmica exigida; mantive os dois PENDING. Não usei scanaudit0 ou suite 5639 para encerrá-los.

R19-CODEQL-003 (tests/product-boundary-code-execution.test.js:39) é fixture negativa: cria caminho/produto próprios, executa o produto propositalmente e exige audit.passed=false e UNVERIFIED_DYNAMIC_CODE_EXECUTION. Tracei o classificador ligado ao relatório e ao passed. Executei os builders originais eval/Function com marcador local em Node22. A execução integral do gate depende de TypeScript e não foi repetida. JSON.stringify constrói programa de teste, sem alegação de sanitizar código externo.

Gitleaks por conteúdo: {cat['HASH']} hashes/tokens de revisão, {cat['SYNTHETIC']} literais sintéticos com produtor/consumidor, {cat['NON_CREDENTIAL_IDENTIFIER']} identificadores de replay/deduplicação/aprovação, {cat['PROSE']} spans de prosa. Os 32 PENDING do draft foram resolvidos individualmente: valor de observação comparado por SHA256 ao produtor literal, assinatura local ligada ao consumidor, simulação ligada à composição controlada, e dois tokens de log recalculados dos campos da mesma nota. Sem aceite por nome/path/count somente. Hash histórico é classificado como digest, sem tratá-lo como prova de igualdade com candidato atual.

**PROC-001, falha de procedimento:** li governança no diretório de trabalho na preparação, contrariando o limite sem Root. A coordenação expôs julgamentos anteriores. Eles não foram usados como evidência, mas a independência estrita não pode ser certificada. Desvio comunicado e registrado como motivo adicional de REJECT. Alguns literais sintéticos benignos apareceram em saídas iniciais antes da máscara; nenhum segredo real identificado.

Cobertura medida: {len(source)} arquivos congelados; todos os hashes de source-mapping conferidos. Gitleaks dir/default, ignore vazio, allow comments ignorados e Secret/Match redatados; não cobre Git history nem prova decodificação de todos os binários/arquivos comprimidos. CodeQL: {len(names)} entradas no arquivo, {len(archive)} arquivos nativos com bytes exatos, {len(expected)} arquivos de código esperados fora da única exclusão; **{len(absent)} ausentes** ({dict(absent_categories)}). Conferidos {len(bqrs)} hashes BQRS, 89 consultas resolvidas/registradas e 87 regras SARIF. Captura não prova análise semântica de todo caminho; JS/TS não cobre outras linguagens. coverage.json lista individualmente as ausências e quaisquer arquivos fora do manifesto fornecido.

Source e scans intactos em bytes/tamanho/mtime/modo antes/depois; manifesto fornecido conferido por entrada. Sem rede, PG, provider, instalação, descendentes, source/scans/rules/suppressions modificados, commit/push ou produção. Escritas apenas neste pacote.

Artefatos: ledger.json/ledger.jsonl (6.578 registros com regra/file/line/hashsource/hashline/razão); ledgers separados; coverage.json; probe-results.json/probe.log/probe.mjs; provenance.json; sentinelas; summary.json; runtime-state/backlog/execution-log locais; manifest.json/manifest.sha256. hashline inclui o terminador original. Scripts reproduzem a leitura e disposição mecânica dos trechos atuais.

Rodada encerrada. ACCEPT independente futuro exige revisor fresco sem os documentos/juízos anteriores e dependências congeladas autorizadas para prova HTTP exata dos dois PENDING. **Nenhuma aprovação de produção.**
'''
(O/'REPORT.md').write_text(report)
print(json.dumps({'verdict':'REJECT','records':len(ledger),'counts':counts,'coverage':{'native':len(source),'archiveNative':len(archive),'absent':len(absent)},'sourceScansUnchanged':True}))
