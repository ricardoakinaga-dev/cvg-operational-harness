import pathlib,json,hashlib,os,collections,re
BASE=pathlib.Path('/home/ricardo/.cache/cvg-harness-green-20261004')
S=BASE/'security-final-source-r19'; Q=BASE/'security-final-scans-r19'; O=BASE/'security-final-disposition-r19'
def sha(b):return hashlib.sha256(b).hexdigest()
def inventory(root):
 out=[]
 for d,dirs,files in os.walk(root,followlinks=False):
  for name in dirs+files:
   p=pathlib.Path(d)/name;st=p.lstat();r={'path':str(p.relative_to(root)),'size':st.st_size,'mtime_ns':st.st_mtime_ns,'mode':st.st_mode}
   if p.is_symlink():r['link']=os.readlink(p)
   elif p.is_file():r['sha256']=sha(p.read_bytes())
   out.append(r)
 return sorted(out,key=lambda r:r['path'])
def span(raw,lines):
 a,b=raw['StartLine']-1,raw['EndLine']-1;c,d=raw['StartColumn']-1,raw['EndColumn']
 if a==b:return lines[a][c:d]
 return '\n'.join([lines[a][c:]]+lines[a+1:b]+[lines[b][:d]])
def mask(text):
 text=re.sub(r'[A-Fa-f0-9]{24,}', '<HEX_REDACTED>',text)
 text=re.sub(r'(?<=[\'\"])[^\'\"\n]{18,}(?=[\'\"])','<VALUE_REDACTED>',text)
 return text
if __name__=='__main__':
 if not (O/'claim.json').exists():
  (O/'claim.json').write_text(json.dumps({'task':'FINAL_SECURITY_DISPOSITION_R19','stage':'AUDIT','mode':'independent finite review','write':str(O),'read':[str(S),str(Q)],'noSourceChanges':True,'criteria':['individual content-based dispositions 6575+3','exact rule/file/line/source/line hashes','connected hook and persistent enforcement','negative execution fixture assertions','coverage and integrity','ACCEPT iff no REAL or PENDING'],'noPriorVerdicts':True},indent=2)+'\n')
  for root,name in [(S,'source'),(Q,'scans')]: (O/(name+'-sentinel-before.json')).write_text(json.dumps(inventory(root),indent=2)+'\n')
 raw=json.loads((Q/'raw/gitleaks.json').read_text());cache={};rows=[]
 for i,x in enumerate(raw):
  p=pathlib.Path(x['File']); rel=str(p.relative_to(S));b=cache.setdefault(rel,p.read_bytes());lines=b.decode().splitlines();v=span(x,lines)
  rows.append({'i':i,'file':rel,'line':x['StartLine'],'span':v,'context':'\n'.join(lines[max(0,x['StartLine']-3):x['EndLine']+2])})
 # Safe summary of matched syntax only: redact every token value before displaying.
 shapes=collections.Counter()
 for r in rows:
  t=r['span'];t=re.sub(r'(?<=[=:])\s*[\'\"]?[^\s,;\'\"}]+',' <REDACTED>',t);shapes[t[:110]]+=1
 print('span shapes',json.dumps(shapes.most_common(45)))
 print('nonhex findings',sum(not re.search(r'\b[0-9a-fA-F]{40,128}\b',r['span']) for r in rows))
 for r in rows:
  if not re.search(r'\b[0-9a-fA-F]{40,128}\b',r['span']):
   print('nonhex',r['i'],r['file'],r['line'],mask(r['context'].replace(r['span'],'<MATCH_REDACTED>'))[:520])
