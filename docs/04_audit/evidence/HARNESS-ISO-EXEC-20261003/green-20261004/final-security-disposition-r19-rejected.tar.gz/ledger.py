import pathlib,json,hashlib,re,collections
from review_common import S,Q,O,sha
raw=json.loads((Q/'raw/gitleaks.json').read_text());findings=json.loads((Q/'findings.json').read_text())
cache={};parse={};leaves={};object_props={};hashmap={p['path']:p['sha256'] for p in json.loads((O/'source-sentinel-before.json').read_text()) if 'sha256' in p}
def load(rel):
 if rel not in cache:
  b=(S/rel).read_bytes();cache[rel]=(b,b.splitlines(keepends=True),b.decode().splitlines())
 return cache[rel]
def parsed(rel):
 if rel in parse:return parse[rel]
 text=load(rel)[0].decode();objects=[]
 try:objects=[json.loads(text)]
 except (ValueError,TypeError):
  if rel.endswith('.jsonl'):
   for line in text.splitlines():
    try:objects.append(json.loads(line))
    except ValueError:pass
 parse[rel]=objects;leaves[rel]=[]
 def walk(obj,pointer):
  if isinstance(obj,dict):
   for k,v in obj.items():
    if isinstance(v,str):leaves[rel].append((k,v,pointer+'/'+k,obj))
    else:walk(v,pointer+'/'+k)
  elif isinstance(obj,list):
   for k,v in enumerate(obj):walk(v,pointer+'/'+str(k))
 for k,obj in enumerate(objects):walk(obj,'/'+str(k))
 return objects

def json_evidence(rel,key,val):
 parsed(rel)
 for k,v,pointer,obj in leaves[rel]:
  if k==key and v==val:
   if id(obj) not in object_props:
    string_values=[(a,b) for a,b in obj.items() if isinstance(b,str)]
    object_props[id(obj)]=(len(string_values)==len(obj) and len(obj)>1 and all(re.fullmatch('[a-fA-F0-9]{64}',b) for a,b in string_values) and sum('/' in a or re.search(r'\.[a-z0-9]{1,8}$',a) is not None for a,b in string_values)>=len(obj)*0.8)
   string_values=[]
   # Require a complete dictionary of filename -> 32-byte digest, with structural file references.
   filemap=object_props[id(obj)]
   explicit=('sha256' in key.lower() or any(w in pointer.lower() for w in ['hash','sha256','digest']))
   if filemap or explicit:
    return {'jsonPointer':pointer,'containerFields':len(obj),'allContainerValuesSHA256':filemap,'explicitDigestSemantics':explicit}
 return None

# Non-credential semantic ports are followed into consumers, not accepted because of fixture paths.
USES={
 'idempotencyKey':('packages/adapters/src/controlled-delivery.ts',47,130),
 'idempotency_key':('packages/persistence/src/postgres.ts',1,1),
 'operationKey':('packages/agent-core/src/approval-reconciliation.ts',98,132),
 'decisionCommandKey':('packages/agent-core/src/approval-reconciliation.ts',98,132),
}
rows=[];pending=[];stats=collections.Counter()
for i,x in enumerate(raw):
 f=findings[i];assert f['rawIndex']==i and f['rule']==x['RuleID'] and f['startLine']==x['StartLine']
 rel=str(pathlib.Path(x['File']).relative_to(S));assert rel==f['file'];b,bl,ls=load(rel);start=x['StartLine'];end=x['EndLine'];line=ls[start-1]
 # Gitleaks 8.28 reports byte columns displaced +1 relative to conventional 1-based columns.
 matched=bl[start-1][max(0,x['StartColumn']-2):x['EndColumn']-1].decode(errors='replace') if start==end else '\n'.join(ls[start-1:end])
 context='\n'.join(ls[max(0,start-4):min(len(ls),end+4)])
 row={'id':f['id'],'scanner':'gitleaks','rawIndex':i,'rule':f['rule'],'file':rel,'line':start,'endLine':end,'hashsource':sha(b),'hashline':sha(bl[start-1]),'hashlines':[{'line':j+1,'sha256':sha(bl[j])} for j in range(start-1,end)],'scanColumns':{'start':x['StartColumn'],'end':x['EndColumn']},'excerptRange':[max(1,start-3),min(len(ls),end+4)],'excerptHash':sha(b''.join(bl[max(0,start-4):min(len(bl),end+4)])),'disposition':'PENDING','category':'UNRESOLVED','reason':'No verified content/consumer justification yet.'}
 m=re.match(r'^\s*"([^"\n]+)"\s*:\s*"([a-fA-F0-9]{64})"',line)
 if m:
  key=json.loads('"'+m[1]+'"');value=m[2];je=json_evidence(rel,key,value)
  # Resolve only relative file references within frozen source, never old absolute roots.
  measured=hashmap.get(key);exact=measured==value
  if je or exact:
   row.update(disposition='FALSE_POSITIVE',category='HASH',reason='The flagged assignment is a 32-byte hex file/content digest, verified by '+('recomputing SHA-256 of the referenced frozen file.' if exact else 'parsed JSON digest semantics and the complete surrounding digest map; not an authentication credential. Historical digest equality is not asserted.'),evidence={'digestField':key,'currentReferencedSourceDigestMatches':exact,**(je or {}),'digestProducer':{'file':'docs/04_audit/evidence/HARNESS-ISO-EXEC-20261003/audit-actions/run-candidate-check.py','line':32,'operation':'hashlib.sha256(file.read_bytes()).hexdigest()'}})
 elif re.search(r'\btoken[\'\"]?\s*:',matched):
  parsed(rel);tokens=[(v,p,o) for k,v,p,o in leaves[rel] if k=='token' and ('token' in matched or 'token' in line)]
  # Recompute exact note revision tokens from their actual fields, including journal nested note objects.
  good=[]
  for val,pointer,obj in tokens:
   if all(k in obj for k in ['id','revision','rawTextSha256','organizedSha256']):
    expected=obj['id'][:12]+'-r'+str(obj['revision'])+'-'+obj['organizedSha256'][:12]
    if val in matched and val==expected:good.append(pointer)
  if good:row.update(disposition='FALSE_POSITIVE',category='HASH',reason='Exact token is recomputed from its sibling note fields using revisionToken; it identifies a revision rather than authenticating a service.',evidence={'jsonPointers':good,'producer':{'file':'products/shift-assistant/src/vertical-state.ts','line':802}})
 else:
  am=re.search(r'([A-Za-z_][\w]*)[\'\"]?\s*[:=]\s*[\'\"]([^\'\"]+)',matched)
  if am:
   field,value=am.groups()
   if field in USES:
    p,a,z=USES[field];row.update(disposition='FALSE_POSITIVE',category='NON_CREDENTIAL_IDENTIFIER',reason=f'The matched {field} is a replay/deduplication or approval operation identifier. The referenced consumer uses it for lookup/correlation, not authentication; the local excerpt constructs a literal request/event identifier.',evidence={'binding':field,'consumer':{'file':p,'startLine':a,'endLine':z,'hashsource':load(p)[0] and sha(load(p)[0])}})
   elif field=='key' and 'state.idempotency[0]' in context:
    row.update(disposition='FALSE_POSITIVE',category='NON_CREDENTIAL_IDENTIFIER',reason='This is an intentionally malformed state.idempotency entry in a restore rejection assertion, not a signing/API key.',evidence={'binding':'state.idempotency[0].key','assertionContext':True})
   elif field in ['secret','key','previousSecret','SYNTHETIC_SECRET','SYNTHETIC_PASSWORD','api_key','credential','privatekey','webhookSecret','SHIFT_DELIVERY_SIMULATION_SECRET','SECRET']:
    row['evidence']={'binding':field,'valueHash':sha(value.encode()),'literalLength':len(value),'localUses':[j+1 for j,l in enumerate(ls) if re.search(r'\b'+re.escape(field)+r'\b',l)][:40]}
    row['reason']='Requires manual verification of the literal producer and its connected local test/probe consumer; labels alone are insufficient.'
  # prose alerts: no literal assignment exists in selected exact span.
  if i in [14,6551,6552]:
   row.update(disposition='FALSE_POSITIVE',category='PROSE',reason='The exact scan span crosses natural-language status text. No quoted key/value or credential assignment is present; the trigger is a token/secret/authority-related word in a sentence.',evidence={'matchedSpanHash':sha(matched.encode()),'containsCredentialAssignment':False})
 rows.append(row);stats[row['category']]+=1
 if row['disposition']=='PENDING':pending.append({'index':i,'file':rel,'line':start,'evidence':row.get('evidence',{})})
(O/'gitleaks-ledger-draft.json').write_text(json.dumps(rows,indent=2)+'\n')
(O/'pending-mechanics.json').write_text(json.dumps(pending,indent=2)+'\n')
print(json.dumps({'categories':stats,'pending':len(pending),'pendingIndices':[r['index'] for r in pending]}))
