import pathlib,json,hashlib,datetime,collections
O=pathlib.Path('/home/ricardo/.cache/cvg-harness-green-20261004/security-final-disposition-r19')
S=O.parent/'security-final-source-r19';Q=O.parent/'security-final-scans-r19'
sha=lambda b:hashlib.sha256(b).hexdigest()
ledger=json.loads((O/'ledger.json').read_text());raw=json.loads((Q/'findings.json').read_text());assert len(ledger)==len(raw)==6578
cache={};verified=0
def checkref(r):
 global verified
 if isinstance(r,dict):
  if all(k in r for k in ['file','hashsource']):
   file=r['file']
   if file not in cache:
    b=(S/file).read_bytes();cache[file]=(sha(b),b.splitlines(keepends=True))
   h,ls=cache[file];assert h==r['hashsource'],file
   if 'hashline' in r:
    lineno=r.get('line',r.get('startLine'));assert sha(ls[lineno-1])==r['hashline'],(file,lineno)
   for ent in r.get('hashlines',[]):assert sha(ls[ent['line']-1])==ent['sha256'],(file,ent['line'])
   verified+=1
  for v in r.values():checkref(v)
 elif isinstance(r,list):
  for v in r:checkref(v)
for current,original in zip(ledger,raw):
 assert current['id']==original['id'] and current['rule']==original['rule'] and current['file']==original['file']
 assert current['line']==original.get('startLine',original.get('locations',[{}])[0].get('region',{}).get('startLine'))
 checkref(current)
for name in ['gitleaks-ledger.json','codeql-ledger.json']:
 expected=[r for r in ledger if r['scanner']==('gitleaks' if name.startswith('gitleaks') else 'codeql')]
 assert json.loads((O/name).read_text())==expected
assert [json.loads(l) for l in (O/'ledger.jsonl').read_text().splitlines()]==ledger
probe=json.loads((O/'probe-results.json').read_text());assert len(probe['checks'])==20 and all(x['status']=='PASS' for x in probe['checks'])
hash_rows=[r for r in ledger if r['scanner']=='gitleaks' and r['category']=='HASH']
current_digests=sum(r.get('evidence',{}).get('currentReferencedSourceDigestMatches',False) for r in hash_rows)
validation={'status':'PASS','totalUniqueCurrentFindings':6578,'individualSourceLineAndEvidenceBindingsVerified':verified,'uniqueSourceFilesReferenced':len(cache),'jsonJsonlAndSeparatedLedgersAgree':True,'falsePositive':6576,'pending':2,'real':0,'gitleaksHashesExactlyEqualReferencedCurrentSource':current_digests,'remainingHashReasons':'complete parsed digest-map semantics, explicitly named digest fields, or recomputed note revision tokens; not historical proof of current source equality','testExecutions':1,'testResult':'20 Node22 probes PASS; no additional tests executed','drafts':'gitleaks-ledger-draft.json, pending-mechanics.json preserved as intermediate artifacts; final current dispositions are ledger.json/jsonl'}
(O/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
(O/'REPORT.md').write_text((O/'REPORT.md').read_text().split('\nVerificação final de artefatos:')[0])
with (O/'REPORT.md').open('a') as f:f.write('\nVerificação final de artefatos: 6.578 IDs únicos, JSON/JSONL/ledgers separados idênticos, todos os hashes de source/line/referências reconferidos. '+str(current_digests)+' digests coincidem exatamente com o arquivo referenciado atual; os demais têm a razão semântica/dérivação registrada, sem alegação de correspondência histórica. Drafts preservados são intermediários; ledger.json/jsonl são o resultado vigente.\n')
files=[]
for p in sorted(O.rglob('*')):
 if p.is_symlink():raise AssertionError('output symlink')
 if p.is_file() and p.name not in ['manifest.json','manifest.sha256']:
  b=p.read_bytes();files.append({'path':str(p.relative_to(O)),'size':len(b),'sha256':sha(b)})
m={'schemaVersion':1,'task':'FINAL_SECURITY_DISPOSITION_R19','sealedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':'REJECT','scope':'6575 current Gitleaks and 3 current CodeQL dispositions only; no production acceptance','dispositions':{'FALSE_POSITIVE':6576,'PENDING':2,'REAL':0},'pending':['R19-CODEQL-001','R19-CODEQL-002'],'procedureBlocker':'PROC-001','authoritySHA256':sha((O/'authority.json').read_bytes()),'sourceInventorySHA256':sha((O/'source-sentinel-after.json').read_bytes()),'scansInventorySHA256':sha((O/'scans-sentinel-after.json').read_bytes()),'ledgerSHA256':sha((O/'ledger.json').read_bytes()),'files':files,'count':len(files),'excludesSelf':['manifest.json','manifest.sha256'],'terminal':True}
(O/'manifest.json').write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n')
digest=sha((O/'manifest.json').read_bytes());(O/'manifest.sha256').write_text(digest+'  manifest.json\n')
assert all(sha((O/x['path']).read_bytes())==x['sha256'] for x in files)
print(json.dumps({'verdict':'REJECT','records':6578,'sourceAndLineBindingsChecked':verified,'currentReferencedDigestsMatch':current_digests,'manifestFiles':len(files),'manifestSHA256':digest}))
