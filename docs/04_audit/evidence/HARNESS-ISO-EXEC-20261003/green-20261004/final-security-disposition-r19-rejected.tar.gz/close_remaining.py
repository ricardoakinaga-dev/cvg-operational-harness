import json,re,pathlib,collections
from review_common import S,Q,O,sha
rows=json.loads((O/'gitleaks-ledger-draft.json').read_text())
def ref(file,a,z=None):
 b=(S/file).read_bytes();ls=b.splitlines(keepends=True);z=z or a
 return {'file':file,'startLine':a,'endLine':z,'hashsource':sha(b),'hashlines':[{'line':j+1,'sha256':sha(ls[j])} for j in range(a-1,z)],'excerptHash':sha(b''.join(ls[a-1:z]))}
def own(i,a,z):return ref(rows[i]['file'],a,z)
def txt(i):return (S/rows[i]['file']).read_text()
def close(i,reason,refs,conditions,seed=None):
 r=rows[i];checks=[{'assertion':k,'satisfied':bool(v)} for k,v in conditions]
 if seed is not None:checks.append({'assertion':'exact literal matches independently extracted producer by SHA256','satisfied':sha(seed.encode())==r.get('evidence',{}).get('valueHash')})
 r.setdefault('evidence',{}).update({'producerConsumerReferences':refs,'verificationAssertions':checks,'priorVerdictsUsed':False})
 if all(c['satisfied'] for c in checks):r.update(disposition='FALSE_POSITIVE',category='SYNTHETIC',reason=reason)
 else:r['reason']='PENDING verification: '+reason
specs={
0:('Literal signs the locally constructed webhook via createWebhookSignature(secret,input); app.inject sends the request using a mocked session store, so it is a locally constructed test signing input.',[(48,57),(173,181),(190,196)],['createWebhookSignature(secret, input)','app.inject','vi.fn']),
3:('Literal generates local identity tokens and is also configured in the resolver with a Map-backed localSessionStore; tokens go through app.inject rather than a real identity provider.',[(23,40),(53,74)],['secret: key','localSessionStore()','createTrustedOperatorIdentityToken(']),
10:('PREVIOUS.secret is supplied to the local rotation-test keyring and consumed by createTrustedOperatorIdentityToken(IDENTITY, PREVIOUS, ...). The test constructs both signing and verifying sides of this input.',[(13,20),(42,62)],['createLocalIdentityKeyRing(','previous: [{ ...PREVIOUS','createTrustedOperatorIdentityToken(']),
11:('previousSecret is declared within the rotation test, installed in its local keyring and consumed by its signedToken helper to exercise resolver expiry.',[(341,362)],['secret: previousSecret','signedToken(','previousSecret']),
12:('Literal is inserted into SYNTHETIC_STARTUP_MESSAGE and passed as a deliberately constructed Error; the log assertion rejects the same literal. It is an error redaction sentinel.',[(11,26),(44,59)],['new Error(SYNTHETIC_STARTUP_MESSAGE)','expect(line).not.toContain(SYNTHETIC_SECRET)']),
13:('Literal is an error redaction sentinel in a deliberately constructed Error and an unreachable loopback port-1 database fixture; log assertions reject the same password.',[(11,26),(44,59),(97,108),(137,143)],['new Error(SYNTHETIC_STARTUP_MESSAGE)','expect(line).not.toContain(SYNTHETIC_PASSWORD)','127.0.0.1:1/cvg'])
}
for i,(reason,ranges,pats) in specs.items():close(i,reason,[own(i,a,z) for a,z in ranges],[(p,p in txt(i)) for p in pats])
e2e='tests/e2e/rem21-014-qualification.spec.ts';cfg='playwright.rem21-014.config.ts'
et=(S/e2e).read_text();ct=(S/cfg).read_text();es=re.search(r"secret: '([^']+)'",et)[1];cs=re.search(r"secret: '([^']+)'",ct)[1]
for i in [67,6568,6573]:
 close(i,'Exact seed is shared by the current E2E keyring and createTrustedOperatorIdentityToken consumer. Its launcher explicitly runs NODE_ENV=test against loopback, with reuse disabled. The browser error excerpt contains the identical test input, verified by value SHA256.',[ref(e2e,9,12),ref(e2e,35,43),ref(cfg,41,53)],[('E2E/launcher seeds equal',es==cs),('launcher test profile','NODE_ENV=test' in ct),('loopback and reuse disabled','http://127.0.0.1:' in ct and 'reuseExistingServer: false' in ct),('local token signing consumer','createTrustedOperatorIdentityToken(' in et and 'syntheticSigningKey' in et[et.index('function identity'):])],es)
probe='docs/04_audit/evidence/AUD0590-DEEP-20260928/probes.mts';pt=(S/probe).read_text();seed=re.search(r"setAttribute\('api_key','([^']+)'\)",pt)[1]
for i in [68,73,100]:
 if i==100:rows[i]['evidence']={'valueHash':sha(seed.encode()),'binding':'setAttribute api_key second argument','literalLength':len(seed)}
 close(i,'Exact output attribute equals the locally declared setAttribute input. The tracer and span are explicit local captured.push stubs: this is a redaction sentinel, not a credential acquired from an external SDK. Only this value provenance is assessed.',[ref(probe,31,38),own(i,rows[i]['line'],rows[i]['line'])],[('local capture stub','captured.push' in pt[pt.index('const captured:'):pt.index('const db=')]),('explicit attribute literal',"setAttribute('api_key'" in pt)],seed)
probe='docs/04_audit/evidence/AUD0591-REPOSITORY-20260930/aud0591-audit-redaction-probe.mts';pt=(S/probe).read_text();seed=re.search(r"const marker='([^']+)'",pt)[1]
for i in [137,138,139,140,144,145,146,147]:
 close(i,'Exact flagged output literal equals the locally declared marker. The source constructs api_key/credential/privatekey/nested.api_key from that marker, calls sanitizeAuditEvidencePayload(input) and serializes its observation. No old redaction/verdict claim is accepted.',[ref(probe,4,12),own(i,rows[i]['line'],rows[i]['line'])],[('explicit local marker input','input={api_key:marker,credential:marker,privatekey:marker,authorization:marker,nested:{api_key:marker}}' in pt),('constructed input consumed','sanitizeAuditEvidencePayload(input)' in pt),('observation serialized','JSON.stringify(result' in pt)],seed)
for i in [214,217]:
 t=txt(i);close(i,'Literal is explicitly injected into buildShiftServer in the pause/send probe. The actual server binds an ephemeral loopback port and requests address that server, with the controlled store/whatsapp passed from setup.',[own(i,109,124)],[('literal buildShiftServer consumer','webhookSecret:' in t.splitlines()[113]),('ephemeral loopback listener',"server.listen(0, '127.0.0.1'" in t),('local URL','127.0.0.1:' in t)])
for i in [252,254]:
 t=txt(i);close(i,'Locally declared secret is used on both sides of the probe webhook handshake: buildShiftServer(webhookSecret:secret) and the local say request header. WAHA uses an explicitly constructed loopback receiver and organizer is an injected deterministic stub.',[own(i,13,26)],[('same signing consumer','webhookSecret:secret' in t),('same header input',bool(re.search(r"headers:\{[^}]+:['\"]?secret",t))),('loopback receiver',"s.listen(0,'127.0.0.1'" in t and 'const receiver=createServer(' in t),('injected organizer','organizer:{async organize()' in t)])
for i in [257,334]:
 r=rows[i];ls=(S/r['file']).read_text().splitlines();obj={}
 for line in ls[r['line']-9:r['line']]:
  m=re.match(r'\s*"([^"\n]+)"\s*:\s*(.*?),?\s*$',line)
  if m:
   try:obj[m[1]]=json.loads(m[2].rstrip(','))
   except ValueError:pass
 expected=obj.get('id','')[:12]+'-r'+str(obj.get('revision'))+'-'+obj.get('organizedSha256','')[:12]
 if obj.get('token')==expected and re.fullmatch('[0-9a-f]{64}',obj.get('organizedSha256','')):
  r.update(disposition='FALSE_POSITIVE',category='HASH',reason='Exact token is recomputed from id, revision and organizedSha256 fields in the same reopened note object, using the actual revisionToken concatenation. The token identifies a note revision using digest prefixes; it does not authenticate a provider.',evidence={'tokenRecomputed':True,'valueHash':sha(obj['token'].encode()),'producerConsumerReferences':[ref('products/shift-assistant/src/vertical-state.ts',802,806),own(i,r['line']-8,r['line'])]})
for i in [6405,6406]:
 t=txt(i)
 if i==6405:
  checks=[('PREV keyring input','previous: [{ ...PREV' in t),('PREV local token producer','createTrustedOperatorIdentityToken(IDENTITY, PREV, now)' in t)];ranges=[(17,41),(96,105)];reason='PREV.secret is an explicitly constructed rotation-probe signing seed: the PREV object enters both the keyring and createTrustedOperatorIdentityToken(IDENTITY, PREV, now). It tests locally generated operator tokens, not acquired credentials.'
 else:
  checks=[('unreachable fixture DB','DATABASE_URL=postgres://fixture:fixture@127.0.0.1:1/fixture' in t),('synthetic provider seed','OPENAI_API_KEY=synthetic-provider-key-not-real' in t),('explicit keyring input',"CVG_OPERATOR_IDENTITY_KEYRING='" in t),('controlled startup run_case','run_case()' in t and 'apps/api/src/main.ts' in t)];ranges=[(8,25),(31,36)];reason='Literal is a constructed keyring input in the startup rejection probe. COMMON_ENV supplies an explicit synthetic provider seed and an unreachable loopback fixture DB, and run_case injects the keyring to exercise resolver admission. No historical outcome is imported.'
 close(i,reason,[own(i,a,z) for a,z in ranges],checks)
for i in [6569,6571]:
 t=txt(i);close(i,'Literal is supplied as SHIFT_DELIVERY_SIMULATION_SECRET in a locally constructed test configuration consumed by composeShiftApp with controlled dependencies. The configuration uses loopback services and temporary fixture storage; this is a simulation signing input.',[own(i,rows[i]['line']-5,rows[i]['line']+19),own(i,126 if i==6569 else 57,143 if i==6569 else 78)],[('explicit config input','SHIFT_DELIVERY_SIMULATION_SECRET:' in t),('composition consumes config','composeShiftApp(' in t),('loopback host',"SHIFT_HOST: '127.0.0.1'" in t),('temporary fixture','mkdtempSync' in t)])
for i in [6570,6572]:
 t=txt(i)
 checks=[('same SECRET webhook input','SHIFT_WEBHOOK_SECRET: SECRET' in t if i==6570 else 'webhookSecret: SECRET' in t),('own sandbox/fetch stub','startSandboxServices()' in t if i==6570 else 'function fakeWaha()' in t),('controlled local adapter',('services.waha' in t or 'services.urls' in t or 'services!.' in t or 'services.whisper' in t) if i==6570 else 'fetch: allowlistedFetch([WAHA], fetchImpl)' in t)]
 close(i,'SECRET is a locally declared webhook signing input supplied to the server configuration and request helper. External adapters are controlled sandbox services (E2E) or fakeWaha fetch stubs (unit test); the bytes are independently constructed testing credentials.',[own(i,rows[i]['line'],rows[i]['line']),own(i,40,83) if i==6570 else own(i,48,75),own(i,495,506) if i==6572 else own(i,70,78)],checks)
(O/'gitleaks-ledger.json').write_text(json.dumps(rows,indent=2)+'\n')
pend=[{'index':i,'file':r['file'],'line':r['line'],'checks':r.get('evidence',{}).get('verificationAssertions')} for i,r in enumerate(rows) if r['disposition']=='PENDING']
(O/'remaining-assessment.json').write_text(json.dumps(pend,indent=2)+'\n')
print(json.dumps({'dispositions':collections.Counter(r['disposition'] for r in rows),'categories':collections.Counter(r['category'] for r in rows),'remaining':pend}))
