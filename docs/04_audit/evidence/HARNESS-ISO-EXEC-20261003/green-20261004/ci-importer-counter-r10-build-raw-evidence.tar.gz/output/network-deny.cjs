const fs = require('node:fs');
const {syncBuiltinESMExports} = require('node:module');
const log = process.env.CVG_REVIEW_NETWORK_LOG;
function deny(api){ return function(...args){
 fs.appendFileSync(log,JSON.stringify({pid:process.pid,api,action:'DENIED'})+'\n');
 throw new Error('REVIEW_NETWORK_DENIED:'+api);
};}
for(const name of ['node:net','node:tls','node:http','node:https','node:http2','node:dgram']){
 const mod=require(name);
 for(const key of ['connect','createConnection','request','get','createSocket']) if(typeof mod[key]==='function')mod[key]=deny(name+'.'+key);
 if(mod.Socket)mod.Socket.prototype.connect=deny(name+'.Socket.connect');
 if(mod.Server)mod.Server.prototype.listen=deny(name+'.Server.listen');
}
for(const name of ['node:dns','node:dns/promises']){
 const mod=require(name);
 for(const key of Object.keys(mod))if(typeof mod[key]==='function' && /^(lookup|resolve|reverse)/.test(key))mod[key]=deny(name+'.'+key);
 if(mod.Resolver)for(const key of Object.getOwnPropertyNames(mod.Resolver.prototype))if(/^(resolve|reverse)/.test(key))mod.Resolver.prototype[key]=deny(name+'.Resolver.'+key);
}
globalThis.fetch=deny('fetch'); if(globalThis.WebSocket)globalThis.WebSocket=deny('WebSocket');
syncBuiltinESMExports();
