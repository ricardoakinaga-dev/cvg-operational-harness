import os,sys,json,subprocess,time,ctypes,errno
from pathlib import Path
p=Path(__file__).resolve().parent; node='/home/ricardo/.nvm/versions/node/v22.23.2/bin/node'
env={'PATH':str(Path(node).parent)+':/usr/bin:/bin','HOME':str(p/'home'),'TMPDIR':str(p/'tmp'),'XDG_CACHE_HOME':str(p/'cache'),'npm_config_cache':str(p/'cache'/'npm'),'NPM_CONFIG_AUDIT':'false','NPM_CONFIG_FUND':'false','CI':'true','TZ':'UTC','LANG':'C.UTF-8','NODE_OPTIONS':'--require='+str(p/'network-deny.cjs'),'CVG_REVIEW_NETWORK_LOG':str(p/'raw'/'network-attempts.jsonl')}
def deny_syscalls():
 lib=ctypes.CDLL('libseccomp.so.2'); lib.seccomp_init.argtypes=[ctypes.c_uint32]; lib.seccomp_init.restype=ctypes.c_void_p
 lib.seccomp_syscall_resolve_name.argtypes=[ctypes.c_char_p]; lib.seccomp_rule_add.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_int,ctypes.c_uint]; lib.seccomp_load.argtypes=[ctypes.c_void_p]
 ctx=lib.seccomp_init(0x7fff0000)
 if not ctx: raise RuntimeError('seccomp init failed')
 for name in ['socket','connect','bind','listen','accept','accept4','sendto','sendmsg','sendmmsg']:
  nr=lib.seccomp_syscall_resolve_name(name.encode())
  if nr>=0 and lib.seccomp_rule_add(ctx,0x00050000|errno.EPERM,nr,0)!=0: raise RuntimeError('seccomp rule failed')
 if lib.seccomp_load(ctx)!=0: raise RuntimeError('seccomp load failed')
label=sys.argv[1]; cmd=[node]+sys.argv[2:]; start=time.time()
traced=['/usr/bin/strace','-f','-qq','-e','trace=network','-o',str(p/'raw'/f'{label}.network.strace')]+cmd
with (p/'raw'/f'{label}.stdout.log').open('w') as stdout,(p/'raw'/f'{label}.stderr.log').open('w') as stderr:
 result=subprocess.run(traced,cwd=p.parent/'ci-importer-counter-r10-candidate',env=env,stdout=stdout,stderr=stderr,preexec_fn=deny_syscalls)
record={'command':cmd,'cwd':str(p.parent/'ci-importer-counter-r10-candidate'),'environment':env,'exitCode':result.returncode,'durationSeconds':time.time()-start,'syscallGuard':'seccomp default ALLOW; explicit network syscall ERRNO(EPERM) inherited by every child','traceCommand':traced}
(p/'raw'/f'{label}.execution.json').write_text(json.dumps(record,indent=2)+'\n'); print(json.dumps(record)); sys.exit(result.returncode)
