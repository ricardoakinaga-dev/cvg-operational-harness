// R10: finite JSON/text fixtures; processes invoke only trusted native CLIs.
import { spawnSync as r10Spawn } from 'node:child_process'
import {
  contract as r10Contract,
  contractHash as r10ContractHash,
  digest as r10Digest,
  files as r10Files,
  sha as r10Sha,
  sourceFiles as r10Sources,
  VERSION as r10Version
} from '../scripts/hiso-contract.mjs'
import { CI_BAR_GATES as r10Gates } from '../scripts/ci-bar-contract.mjs'
import {
  createGateSeal as r10CreateSeal,
  encodeGateSeal as r10EncodeSeal,
  gateStepId as r10Step,
  runnerIdentity as r10Runner,
  verifyGateSeals as r10CheckSeals
} from '../scripts/ci-bar-provenance.mjs'
import {
  sealFor as r10Seal,
  verifyScope as r10VerifyScope
} from '../scripts/hiso-verifier.mjs'
const r10Write = (p, value) => {
  fs.mkdirSync(path.dirname(p), { recursive: true })
  fs.writeFileSync(p, JSON.stringify(value) + '\n')
}
const r10Hash = 'a'.repeat(64)
let r10Candidate
function r10Import(report, required) {
  const d = temp(),
    original = path.join(d, 'original'),
    out = path.join(d, 'out')
  const env = {
    ...process.env,
    GITHUB_RUN_ID: '777',
    GITHUB_RUN_ATTEMPT: '1',
    GITHUB_SHA: 'f'.repeat(40),
    GITHUB_REPOSITORY: 'synthetic/fixture',
    GITHUB_WORKFLOW: 'Inert R10 fixture',
    CI_RUN_ID: 'run-777-1',
    GITHUB_OUTPUT: path.join(d, 'step-output.txt'),
    HISO_PG_VERSION_OUTPUT: path.join(d, 'pg.json')
  }
  const github = r10Runner(env)
  const state = {
    runId: 'run-777-1',
    candidateId: r10Hash,
    nodeVersion: process.versions.node,
    gates: []
  }
  fs.mkdirSync(original)
  fs.writeFileSync(path.join(original, 'runtime.txt'), 'inert fixture\n')
  for (const gate of r10Gates.filter((g) => g.id !== 'artifacts')) {
    const log = 'inert fixture; no gate execution: ' + gate.id + '\n'
    const lp = 'gates/' + gate.id + '.log'
    fs.mkdirSync(path.dirname(path.join(original, lp)), { recursive: true })
    fs.writeFileSync(path.join(original, lp), log)
    const entry = {
      id: gate.id,
      status: 'PASS',
      exitCode: 0,
      runId: state.runId,
      candidateId: r10Hash,
      nodeVersion: state.nodeVersion,
      outputFailures: [],
      log: lp,
      logSha256: r10Sha(log)
    }
    for (const p of gate.artifacts ?? [])
      r10Write(
        path.join(original, 'gate-outputs', gate.id, p),
        gate.id === 'unit' ? report : { inert: true }
      )
    if (gate.id === 'e2e')
      Object.assign(entry, {
        executionId: 'inert-execution',
        testCount: 1,
        testInventorySha256: r10Hash,
        artifactSha256: Object.fromEntries(
          gate.artifacts.map((p) => [
            p,
            r10Sha(
              fs.readFileSync(path.join(original, 'gate-outputs', gate.id, p))
            )
          ])
        )
      })
    state.gates.push(entry)
  }
  const steps = Object.fromEntries(
    r10Gates
      .filter((g) => g.id !== 'artifacts')
      .map((g) => [
        r10Step(g.id),
        {
          outcome: 'success',
          conclusion: 'success',
          outputs: {
            seal: r10EncodeSeal(
              r10CreateSeal({ id: g.id, state, artifactDir: original, github })
            )
          }
        }
      ])
  )
  expect(
    r10CheckSeals({ state, artifactDir: original, steps, github }).failures
  ).toEqual([])
  const candidate = (r10Candidate ??= r10Digest(r10Sources(root)))
  const expected = {
    schemaVersion: 1,
    contract: r10Version,
    contractHash: r10ContractHash,
    candidateId: candidate,
    sourceSha256: candidate,
    ownerMappingHash: r10Hash,
    runId: state.runId,
    attempt: '1',
    sha: env.GITHUB_SHA,
    startedAt: '2026-10-05T00:00:00.000Z',
    coveragePaths: [],
    coverageSources: [],
    testInventory: required,
    scopes: {}
  }
  for (const s of r10Contract.scopes)
    expected.scopes[s.id] = {
      ...expected,
      scopes: undefined,
      scope: s.id,
      derivedVariantId: candidate,
      derivedMappingHash: r10Hash,
      lockSha256: r10Hash,
      testInventoryHash: r10Digest(required),
      requiredTestIds: required.map((t) => t.id)
    }
  const legacy = {
    verdict: 'PASS',
    provenance: { mode: 'GITHUB_STEP_OUTPUT_SEALED' },
    runId: state.runId,
    candidateId: r10Hash,
    npmVersion: 'inert',
    startedAt: expected.startedAt,
    gates: [...state.gates, { id: 'artifacts', status: 'PASS' }]
  }
  r10Write(path.join(original, 'ci-bar-state.json'), state)
  r10Write(path.join(original, 'ci-bar-manifest.json'), legacy)
  r10Write(path.join(d, 'expected.json'), expected)
  r10Write(env.HISO_PG_VERSION_OUTPUT, {
    schemaVersion: 1,
    status: 'PASS',
    version: 160000,
    runId: state.runId,
    candidateId: r10Hash
  })
  env.CI_BAR_STEPS_JSON = JSON.stringify(steps)
  env.LEGACY_MANIFEST_SHA256 = r10Sha(
    fs.readFileSync(path.join(original, 'ci-bar-manifest.json'))
  )
  const cli = r10Spawn(
    process.execPath,
    [
      'scripts/hiso-import-legacy.mjs',
      original,
      path.join(d, 'expected.json'),
      out
    ],
    { cwd: root, env, encoding: 'utf8' }
  )
  expect(cli.error).toBeUndefined()
  const manifest = JSON.parse(fs.readFileSync(path.join(out, 'manifest.json')))
  return { cli, manifest, out, required }
}

describe('R10 native legacy importer shared admission', () => {
  const selected = [
    row('tests/r10-unit.test.js', 'same'),
    row('tests/r10-unit.test.js', 'same'),
    row('tests/r10-unit.test.js', 'other')
  ]
  it.each(['complete', 'reordered', 'pending', 'skipped', 'todo'])(
    'admits complete 3/3 %s using the existing governed policy',
    (kind) => {
      const rows = clone(selected)
      if (kind === 'reordered') rows.reverse()
      const report = native(rows)
      if (['pending', 'skipped', 'todo'].includes(kind)) {
        report.testResults[0].assertionResults[2].status = kind
        report.numPassedTests--
        report.numPendingTests = kind === 'todo' ? 0 : 1
        report.numTodoTests = kind === 'todo' ? 1 : 0
      }
      const observed = r10Import(report, inventory(selected))
      expect(observed.cli.status).toBe(0)
      expect(observed.manifest.status).toBe('PASS')
      expect(observed.manifest.executedTestInventory).toHaveLength(3)
      expect(observed.manifest.gates.find((g) => g.id === 'unit').skipped).toBe(
        ['pending', 'skipped', 'todo'].includes(kind) ? 1 : 0
      )
      const gate = r10Contract.scopes
        .find((s) => s.id === 'transition-regression')
        .gates.find((g) => g.id === 'unit')
      expect(
        verifySnapshots({
          gate,
          entry: observed.manifest.gates.find((g) => g.id === 'unit'),
          directory: observed.out,
          manifest: observed.manifest,
          expected: { requiredTestIds: observed.required.map((t) => t.id) }
        }).tests
      ).toEqual(observed.manifest.executedTestInventory)
    }
  )
  it.each([
    'missing occurrence',
    'extra occurrence',
    'renamed name',
    'renamed file',
    'forged id',
    'forged occurrence',
    'failed',
    'counts'
  ])('rejects %s before any unit PASS emission', (kind) => {
    const rows = clone(selected),
      required = inventory(selected)
    if (kind === 'missing occurrence') rows.splice(1, 1)
    if (kind === 'extra occurrence') rows.push(clone(rows[0]))
    if (kind === 'renamed name') rows[0].name = 'other name'
    if (kind === 'renamed file') rows[0].file = 'tests/other-r10.test.js'
    if (kind === 'forged id') required[0].id = 'b'.repeat(64)
    if (kind === 'forged occurrence') required[0].occurrence = 8
    const report = native(rows)
    if (kind === 'failed')
      report.testResults[0].assertionResults[0].status = 'failed'
    if (kind === 'counts') report.numPassedTests--
    const observed = r10Import(report, required)
    expect(observed.cli.status).toBe(1)
    expect(observed.manifest.status).toBe('FAIL')
    expect(observed.manifest.cause).toMatch(/hiso:/)
    expect(r10Files(observed.out).map((f) => f.path)).toEqual([
      'import-failure.log',
      'manifest.json'
    ])
    expect(fs.existsSync(path.join(observed.out, 'gate-outputs/unit'))).toBe(
      false
    )
    expect(fs.existsSync(path.join(observed.out, 'legacy'))).toBe(false)
  })
})

const r10Critical = json('scripts/critical-coverage-manifest.json')
const r10CoverageVectors = [
  ['raw-94.999', 100000, 94999, 'FAIL'],
  ['raw-95', 100000, 95000, 'PASS'],
  ['raw-95.001', 100000, 95001, 'PASS'],
  ['zero', 0, 0, 'FAIL'],
  ['covered exceeds total', 100, 101, 'FAIL'],
  ['fraction', 100.5, 100.5, 'FAIL'],
  ['unsafe integer', 9007199254740992, 9007199254740992, 'FAIL'],
  [
    'safe sum overflow',
    Number.MAX_SAFE_INTEGER,
    Number.MAX_SAFE_INTEGER,
    'FAIL'
  ]
]
describe('R10 native public critical coverage CLI', () => {
  it.each(r10CoverageVectors)(
    '%s preserves raw thresholds and denies invalid counters',
    (_id, total, covered, verdict) => {
      const d = temp()
      for (const p of [
        'scripts/critical-coverage.mjs',
        'scripts/lib/coverage-gate.mjs',
        'scripts/critical-coverage-manifest.json'
      ]) {
        fs.mkdirSync(path.dirname(path.join(d, p)), { recursive: true })
        fs.copyFileSync(path.join(root, p), path.join(d, p))
      }
      fs.mkdirSync(path.join(d, 'certification'))
      const summary = Object.fromEntries(
        [...new Set(r10Critical.groups.flatMap((g) => g.paths))].map((p) => [
          p,
          metrics(total, covered)
        ])
      )
      summary.total = metrics(total, covered)
      r10Write(path.join(d, 'coverage/coverage-summary.json'), summary)
      const cli = r10Spawn(
        process.execPath,
        ['scripts/critical-coverage.mjs'],
        { cwd: d, encoding: 'utf8' }
      )
      expect(cli.error).toBeUndefined()
      expect(cli.status).toBe(verdict === 'PASS' ? 0 : 1)
      const report = JSON.parse(
        fs.readFileSync(path.join(d, 'certification/critical-coverage.json'))
      )
      expect(report.verdict).toBe(verdict)
      expect(report.global).toEqual(
        buildCoverageReport(summary, r10Critical).global
      )
      expect(report.critical).toEqual(
        buildCoverageReport(summary, r10Critical).critical
      )
      if (verdict === 'PASS')
        expect(() => snapshotSchema(report, 'coverage-critical')).not.toThrow()
      else expect(() => snapshotSchema(report, 'coverage-critical')).toThrow()
      if (total === 100000)
        expect(report.critical.groups[0].metrics.branches.pct).toBe(95)
    }
  )
  it.each(['statements', 'lines', 'functions', 'branches'])(
    'does not silently filter an invalid critical %s member',
    (dimension) => {
      const group = r10Critical.groups.find((g) => g.paths.length > 1)
      const summary = Object.fromEntries(
        [...new Set(r10Critical.groups.flatMap((g) => g.paths))].map((p) => [
          p,
          metrics(100, 100)
        ])
      )
      summary.total = metrics(100, 100)
      summary[group.paths[0]][dimension].covered = 101
      const report = buildCoverageReport(summary, r10Critical)
      expect(report.global.pass).toBe(true)
      expect(report.verdict).toBe('FAIL')
      expect(report.critical.failures).toContain(
        `critical_coverage_invalid:${group.id}:${dimension}`
      )
      expect(
        report.critical.groups.find((g) => g.id === group.id).metrics[dimension]
      ).toEqual({ total: null, covered: null, pct: null })
      summary.total[dimension].covered = 101
      expect(
        buildCoverageReport(summary, r10Critical).global.failures
      ).toContain(`coverage_global_invalid:${dimension}`)
    }
  )
  it('preserves weighted sums and zero-count erased files in a valid group', () => {
    const group = r10Critical.groups.find((g) => g.paths.length > 1)
    const summary = Object.fromEntries(
      [...new Set(r10Critical.groups.flatMap((g) => g.paths))].map((p) => [
        p,
        metrics(100, 100)
      ])
    )
    summary.total = metrics(1000, 1000)
    summary[group.paths[0]] = metrics(10, 0)
    summary[group.paths[1]] = metrics(990, 950)
    for (const p of group.paths.slice(2)) summary[p] = metrics(0, 0)
    const report = buildCoverageReport(summary, r10Critical)
    expect(report.verdict).toBe('PASS')
    expect(
      report.critical.groups.find((g) => g.id === group.id).metrics.branches
    ).toEqual({ total: 1000, covered: 950, pct: 95 })
  })
})

// Complete content bindings reach the real verifyScope unit predicate. Later
// snapshots are deliberately invalid, and no complete scope PASS is asserted.
function r10BoundScope(status, scopeId = 'harness-neutral', skipCount) {
  const d = temp(),
    s = r10Contract.scopes.find((s) => s.id === scopeId)
  const selected = [
    row('tests/r10-bound.test.js', 'same'),
    row('tests/r10-bound.test.js', 'same'),
    row('tests/r10-bound.test.js', 'other')
  ]
  const required = inventory(selected),
    report = native(selected)
  if (status !== 'passed') {
    report.testResults[0].assertionResults[2].status = status
    report.numPassedTests--
    report.numPendingTests = status === 'todo' ? 0 : 1
    report.numTodoTests = status === 'todo' ? 1 : 0
  }
  const executed =
    status === 'failed'
      ? inventory(selected).map((t) => ({ ...t, status: 'failed' }))
      : testReport(report, [selected[0].file], 'governed')
  const manifest = {
    schemaVersion: 1,
    contract: r10Version,
    contractHash: r10ContractHash,
    scope: s.id,
    owner: s.owner,
    candidateId: r10Hash,
    sourceSha256: r10Hash,
    sourceMatch: true,
    sourceAfterSha256: r10Hash,
    variantSourceMatch: true,
    variantSourceAfterSha256: r10Hash,
    runId: 'inert-r10-bound',
    attempt: '1',
    derivedVariantId: r10Hash,
    derivedMappingHash: r10Hash,
    ownerMappingHash: r10Hash,
    lockSha256: r10Hash,
    mode: 'LOCAL_CONTENT_HASHES',
    startedAt: '2026-10-05T00:00:00.000Z',
    finishedAt: '2026-10-05T00:00:01.000Z',
    versions: { node: process.versions.node },
    testInventory: required,
    testInventoryHash: r10Digest(required),
    testInventoryStatus: 'COLLECTED_NOT_EXECUTED',
    executedTestInventory: executed,
    executedTestInventoryHash: r10Digest(executed),
    coverage: { 'inert.ts': metrics(10, 10) },
    gates: [],
    seals: [],
    status: 'PASS'
  }
  for (const gate of s.gates) {
    const log = 'inert binding ' + gate.id + '\n',
      lp = 'gates/' + gate.id + '.log'
    fs.mkdirSync(path.dirname(path.join(d, lp)), { recursive: true })
    fs.writeFileSync(path.join(d, lp), log)
    const outputs = []
    for (const p of gate.artifacts ?? []) {
      const op = `gate-outputs/${gate.id}/${p}`
      r10Write(path.join(d, op), gate.id === 'unit' ? report : { inert: true })
      const b = fs.readFileSync(path.join(d, op))
      outputs.push({ path: op, sha256: r10Sha(b), size: b.length })
    }
    const entry = {
      schemaVersion: 1,
      id: gate.id,
      command: gate.command,
      status: 'PASS',
      exitCode: 0,
      cause: null,
      scope: s.id,
      runId: manifest.runId,
      candidateId: r10Hash,
      startedAt: manifest.startedAt,
      finishedAt: manifest.finishedAt,
      skipped:
        gate.id === 'unit' ? (skipCount ?? (status === 'passed' ? 0 : 1)) : 0,
      outputs,
      logSha256: r10Sha(log)
    }
    manifest.gates.push(entry)
    manifest.seals.push(r10Seal(manifest, entry))
  }
  manifest.outputs = r10Files(d)
  r10Write(path.join(d, 'manifest.json'), manifest)
  return {
    manifest,
    directory: d,
    expected: { ...manifest, requiredTestIds: required.map((t) => t.id) }
  }
}
describe('R10 native verifier unit policy parity', () => {
  it.each(['passed', 'pending', 'skipped', 'todo'])(
    'admits unit %s to the same later independent snapshot boundary',
    (status) => {
      const input = r10BoundScope(status)
      expect(() => r10VerifyScope(input)).toThrow(
        'hiso:postgres_version_binding'
      )
    }
  )
  it('rejects failed execution before the unrelated snapshot', () => {
    expect(() => r10VerifyScope(r10BoundScope('failed'))).toThrow(
      'hiso:unit_execution_status'
    )
  })
  it.each(['pending', 'skipped', 'todo'])(
    'preserves none policy and skipped-count binding for %s',
    (status) => {
      expect(() =>
        r10VerifyScope(r10BoundScope(status, 'shift-product', 0))
      ).toThrow('hiso:unit_execution_status')
      expect(() =>
        r10VerifyScope(r10BoundScope(status, 'harness-neutral', 0))
      ).toThrow('hiso:unit_execution_skip_count')
    }
  )
  it('still requires the separate skip-governance snapshot to pass', () => {
    expect(() =>
      verify('skip', {
        schemaVersion: 1,
        kind: 'aud20-skip-inventory',
        verdict: 'FAIL',
        failures: ['unapproved skip']
      })
    ).toThrow()
  })
})
