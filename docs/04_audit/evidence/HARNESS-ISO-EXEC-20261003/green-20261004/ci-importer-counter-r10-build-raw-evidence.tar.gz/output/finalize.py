from pathlib import Path
import os,json,hashlib,stat,re,subprocess
B=Path('/home/ricardo/.cache/cvg-harness-green-20261004'); O=B/'ci-importer-counter-r10-builder'; C=B/'ci-importer-counter-r10-candidate'; P=B/'ci-raw-critical-review-r9'; S=P/'source'
WRITES=['scripts/hiso-import-legacy.mjs','scripts/lib/coverage-gate.mjs','scripts/hiso-verifier.mjs','tests/hiso-snapshot-membership-own.test.js']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v): (O/p).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def inventory(root):
 result={}
 for p in sorted(root.rglob('*')):
  s=p.lstat();r=p.relative_to(root).as_posix();d={'mode':s.st_mode,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'inode':s.st_ino,'device':s.st_dev,'nlink':s.st_nlink}
  if p.is_symlink():d['target']=os.readlink(p)
  elif p.is_file():d['sha256']=sha(p)
  result[r]=d
 return result
def differences(before,after):return {'added':sorted(after.keys()-before.keys()),'removed':sorted(before.keys()-after.keys()),'changed':{p:{k:{'before':before[p].get(k),'after':after[p].get(k)} for k in before[p].keys()|after[p].keys() if before[p].get(k)!=after[p].get(k)} for p in before.keys()&after.keys() if before[p]!=after[p]}}
# Evidence is retained before restoring only locally generated infrastructure cache.
initial=json.load(open(O/'candidate-before.json')); pre=inventory(C); write('candidate-after-native-before-cache-repair.json',pre)
cache_changes=[]
for r,v in initial.items():
 if r.startswith('node_modules/.vite') and pre[r]!=v:
  p=C/r;entry={'path':r,'beforeNative':v,'afterNative':pre[r],'classification':'private generated Vitest/Vite cache; no dependency or Source input'}
  if 'sha256' in v:
   archive=O/'raw'/'generated-cache-after-native'/r;archive.parent.mkdir(parents=True,exist_ok=True);archive.write_bytes(p.read_bytes())
   p.write_bytes((S/r).read_bytes());os.chmod(p,stat.S_IMODE(v['mode']))
  os.utime(p,ns=(p.stat().st_atime_ns,v['mtime_ns']))
  cache_changes.append(entry)
write('generated-cache-repair.json',{'events':cache_changes,'scope':'Own physical candidate only; restore initial generated-cache bytes/mtime after preserving actual native output. No Root/Main or frozen Source writes. Full final run used --cache=false.','dependencySourceWrites':0})
source_after=inventory(S);write('source-after.json',source_after);source_before=json.load(open(O/'source-before.json'));source_diff=differences(source_before,source_after)
assert not any(source_diff.values()),source_diff
frozen=json.load(open(P/'frozen-inventory.json'));frozen_errors=[]
for r,v in frozen.items():
 a=source_after[r]
 if v['kind']=='file' and (a.get('sha256')!=v['sha256'] or a['size']!=v['bytes']):frozen_errors.append(r)
 if v['kind']=='link' and a.get('target')!=v.get('target'):frozen_errors.append(r)
assert not frozen_errors,frozen_errors
candidate_after=inventory(C);write('candidate-after.json',candidate_after);cd=differences(initial,candidate_after)
content_changed=sorted(p for p,v in cd['changed'].items() if 'sha256' in v or 'target' in v)
assert content_changed==sorted(WRITES),content_changed
assert not cd['added'] and not cd['removed'],cd
unexpected_metadata={p:v for p,v in cd['changed'].items() if p not in WRITES and not any(w.startswith(p+'/') for w in WRITES)}
assert not unexpected_metadata,unexpected_metadata
prefix='tests/hiso-snapshot-membership-own.test.js';pb=(S/prefix).read_bytes();cb=(C/prefix).read_bytes();assert cb.startswith(pb)
write('prefix-proof.json',{'path':prefix,'originalCaseCount':146,'prefixBytes':len(pb),'originalSha256':sha(S/prefix),'candidatePrefixSha256':hashlib.sha256(cb[:len(pb)]).hexdigest(),'byteExact':True,'appendBytes':len(cb)-len(pb),'candidateSha256':sha(C/prefix)})
base=json.load(open(S/'scripts/hiso-baseline-inventory.json'));original=[]
for item in base['tests']:
 p=item['path']; ok=sha(S/p)==item['sha256']==sha(C/p);original.append({'path':p,'baselineSha256':item['sha256'],'sourceSha256':sha(S/p),'candidateSha256':sha(C/p),'match':ok})
assert len(original)==371 and all(x['match'] for x in original)
new=[]
for p in base['newTests']:
 new.append({'path':p,'sourceSha256':sha(S/p),'candidateSha256':sha(C/p),'fullByteExact':(S/p).read_bytes()==(C/p).read_bytes(),'appendOnly':p==prefix and cb.startswith(pb)})
assert len(new)==43 and all(x['fullByteExact'] or x['appendOnly'] for x in new)
write('original-tests-proof.json',{'originalTests':original,'newTestPaths':new,'originalTestsCount':371,'newTestPathCount':43,'preservation':'371 original tests byte-exact; 42 new paths byte-exact and one new path preserves its entire 146-case prefix with append only.'})
protected=sorted(p for p,v in initial.items() if 'sha256' in v and (p in ['scripts/ci-bar-contract.mjs','scripts/hiso-ci-scopes.json','scripts/hiso-baseline-inventory.json','scripts/critical-coverage-manifest.json','scripts/mutation-guard-manifest.json','package-lock.json','package.json','vitest.config.mts'] or 'schema' in p.lower() or p.startswith('docs/02_spec/') or 'mutation' in p.lower() and p.startswith('scripts/')))
protected_rows=[{'path':p,'sha256':initial[p]['sha256'],'candidateSha256':sha(C/p),'sourceSha256':sha(S/p)} for p in protected];assert all(x['sha256']==x['sourceSha256']==x['candidateSha256'] for x in protected_rows)
write('bar-schemas-manifests-proof.json',{'allUntouchedPathsByteExact':True,'protected':protected_rows,'protection':'No bar, official schema, catalog, manifest, baseline, config, lock or original test edited. Mutation metadata rebind belongs to Lead.'})
deps=[p for p in initial if p.startswith('node_modules/')];dist=[p for p in initial if '/dist/' in p or p.endswith('/dist') or p.endswith('.tsbuildinfo')]
assert all(initial[p]==candidate_after[p] for p in deps),[p for p in deps if initial[p]!=candidate_after[p]]
assert all(initial[p]==candidate_after[p] for p in dist),[p for p in dist if initial[p]!=candidate_after[p]]
write('integrity-proof.json',{'source':'MATCH','sourceCompleteHashMetadataDifferences':source_diff,'frozenInventorySha256':sha(P/'frozen-inventory.json'),'freezeInventoryHashMatches':sha(P/'frozen-inventory.json')==json.load(open(P/'freeze.json'))['inventorySha256'],'frozenEntries':len(frozen),'candidatePhysicalEntries':len(candidate_after),'candidateFinalDifferences':cd,'onlySourceWrites':content_changed,'dependencyEntries':len(deps),'allCandidateDependencyContentMetadataMatch':True,'distAndBuildMetadataEntries':len(dist),'allCandidateDistContentMetadataMatch':True,'sourceRegularFiles':sum('sha256' in v for v in source_after.values()),'sourceSymlinks':sum('target' in v for v in source_after.values()),'sourceDirectories':sum(stat.S_ISDIR(v['mode']) for v in source_after.values()),'metadataFields':['mode','size','mtime_ns','inode','device','nlink','symlink target'],'volatileReadAccessTimesExcluded':True})
shared=[];hard=[];escaping=[]
for r,v in candidate_after.items():
 if 'sha256' in v:
  if v['nlink']!=1:hard.append(r)
  if (v['device'],v['inode'])==(source_after[r]['device'],source_after[r]['inode']):shared.append(r)
 if 'target' in v and not (C/r).resolve().is_relative_to(C):escaping.append(r)
assert not shared and not hard and not escaping
write('isolation-proof.json',{'physicalCopy':True,'sharedSourceInodes':shared,'hardlinks':hard,'escapingSymlinks':escaping,'noCriticalRuntimeOrOutputsCopied':True,'privateEnvExclusions':json.load(open(O/'copy-proof.json'))['excludedPrivateEnv']})
def tests(p):
 j=json.load(open(O/p));return {'raw':p,'success':j['success'],'total':j['numTotalTests'],'passed':j['numPassedTests'],'failed':j['numFailedTests'],'pending':j['numPendingTests'],'todo':j['numTodoTests'],'files':[{'path':str(Path(f['name']).relative_to(C)),'assertions':len(f['assertionResults']),'statuses':{s:sum(t['status']==s for t in f['assertionResults']) for s in sorted({t['status'] for t in f['assertionResults']})}} for f in j['testResults']]}
before=tests('raw/before-focused.json');after=tests('raw/after-focused.json');appends=tests('raw/superseded-r1-r10-appends.json')
assert before['passed']==378 and after['passed']==413 and after['failed']==after['pending']==after['todo']==0
# Preserve original case identities/statuses and the exact first 146 native assertions.
jb=json.load(open(O/'raw/before-focused.json'));ja=json.load(open(O/'raw/after-focused.json'));afterfiles={f['name']:f for f in ja['testResults']};identity_matches=[]
for f in jb['testResults']:
 af=afterfiles[f['name']];limit=len(f['assertionResults']);old=[{k:t[k] for k in ['ancestorTitles','title','fullName','status']} for t in f['assertionResults']];now=[{k:t[k] for k in ['ancestorTitles','title','fullName','status']} for t in af['assertionResults'][:limit]]
 assert old==now,f['name'];identity_matches.append({'file':str(Path(f['name']).relative_to(C)),'originalAssertions':limit,'identitiesAndStatusesUnchanged':True})
pg=[{'title':t['title'],'status':t['status']} for f in ja['testResults'] for t in f['assertionResults'] if t['title'].startswith('native Pg CLI validates ')]
assert len(pg)==12 and all(t['status']=='passed' for t in pg)
write('native-tests-proof.json',{'before':before,'after':after,'initialAppendsDiagnosticRun':appends,'appendCases':35,'allPreviousNativeCaseIdentitiesPreserved':identity_matches,'nativePgIdentityGuardedMockCases':pg,'pgMockSafety':'Original byte-exact tests mock pg Client, verify the native ESM default Client identity before importing producer, and abort on ineffective mock. No DNS or PostgreSQL use.','focusedPatternSkips':'The initial append-only diagnostic run intentionally selected R10 and reported 146 pending original cases; its 35 PASS preceded a full-run failure and does not replace final execution evidence. Final six-file run reports 413 passed, zero pending/todo/failed.'})
network=[]
for p in sorted((O/'raw').glob('*.network.strace')):
 lines=p.read_text().splitlines();attempts=[s for s in lines if re.search(r'\b(socket|connect|bind|listen|accept|accept4|sendto|sendmsg|sendmmsg)\(',s)]
 network.append({'path':str(p.relative_to(O)),'sha256':sha(p),'networkAttempts':len(attempts),'inetCalls':sum(bool(re.search(r'AF_INET6?\b',s)) for s in lines),'localUnixSocketpairs':sum('socketpair(AF_UNIX' in s for s in lines),'attemptLines':attempts})
assert sum(s['networkAttempts'] for s in network)==sum(s['inetCalls'] for s in network)==0
assert not (O/'raw/network-attempts.jsonl').exists()
write('network-proof.json',{'networkAttempts':0,'inetCalls':0,'dnsOrJavascriptDenialEvents':0,'traces':network,'unixIPCReportedSeparately':sum(s['localUnixSocketpairs'] for s in network),'syscallGuard':'Inherited seccomp EPERM socket/connect/bind/listen/accept/accept4/sendto/sendmsg/sendmmsg, with Node AF_UNIX socketpair infrastructure allowed; JS network and DNS denial preload; sanitized allowlist environment.'})
source_native=json.load(open(O/'raw/source-native-inventory.json'));candidate_native=json.load(open(O/'raw/candidate-native-inventory.json'));assert source_native['nativeInventoryCount']==candidate_native['nativeInventoryCount']==8402
extras=['docs/04_audit/evidence/HARNESS-ISO-EXEC-20261003/green-20261004/production-bootstrap-user-approval.json','docs/04_audit/evidence/HARNESS-ISO-EXEC-20261003/green-20261004/authority.json']
write('counts-proof.json',{'declaredMainInputs':8400,'observedFrozenSourceInputs':8402,'observedCandidateInputs':8402,'sourceNativeSha256':source_native['nativeInventorySha256'],'candidateNativeSha256':candidate_native['nativeInventorySha256'],'extras':[{'path':p,'sha256':sha(S/p),'matchesFreeze':frozen[p]['sha256']==sha(S/p),'matchesCandidate':sha(S/p)==sha(C/p)} for p in extras],'reconciliation':'8402 observed frozen inputs = 8400 Main inputs declared by user/authority plus two pre-frozen bootstrap authority inputs. No separate Main inventory accessed; no independent Root/Main equality claimed.','originalTestPaths':371,'newTestPaths':43,'testSourcePaths':414,'coverageOriginalPaths':275,'coverageNewPaths':6,'coveragePaths':281,'baselineNativeCases':378,'newNativeCases':35,'finalNativeCases':413})
coverage_before=json.load(open(O/'raw/before-controls/results.json'));coverage_after=json.load(open(O/'raw/controls/results.json'));assert all(x['emittedVerdict']==x['expect'] and x['cliExitCode']==(0 if x['expect']=='PASS' else 1) for x in coverage_after['coverage'])
legacy_before=[json.load(open(O/f'raw/before-legacy-emission/{s}/observation.json')) for s in ['complete-unit','omitted-unit-case']];legacy_after=[json.load(open(O/f'raw/legacy-emission/{s}/observation.json')) for s in ['complete-unit','omitted-unit-case']]
assert legacy_before[1]['importedStatus']=='PASS' and legacy_after[0]['importedStatus']=='PASS' and legacy_after[1]['importedStatus']=='FAIL' and not legacy_after[1]['emittedUnitSnapshot']
write('native-controls-proof.json',{'before':'raw/before-controls/results.json','after':'raw/controls/results.json','coverageCases':len(coverage_after['coverage']),'coverageFalsePassCorrections':[{'id':a['id'],'before':b['emittedVerdict'],'after':a['emittedVerdict']} for b,a in zip(coverage_before['coverage'],coverage_after['coverage']) if b['emittedVerdict']!=a['emittedVerdict']],'legacyBefore':legacy_before,'legacyAfter':legacy_after,'scopeSkipParityBefore':coverage_before['scopeSkipParity'],'scopeSkipParityAfter':coverage_after['scopeSkipParity'],'scopeVerifierLimit':'Complete bound finite fixtures prove admission of governed unit statuses to the same later independent snapshot rejection. The subsequent snapshots are deliberately inert/invalid; this is not complete-scope PASS.','passOnlyNativeJsonCases':coverage_after['passOnly'],'notFormalCriticalReview':True,'previousR9FormalVerdict':'INVALID; raw technical controls are reproduction inputs only; no acceptance inferred.'})
commands={p.stem.replace('.execution',''):json.load(open(p)) for p in sorted((O/'raw').glob('*.execution.json'))}
assert commands['typecheck-final']['exitCode']==commands['lint-final']['exitCode']==commands['format-writeset-r2']['exitCode']==0
assert commands['format-check']['exitCode']==commands['format-baseline']['exitCode']==1
write('gates-proof.json',{'commands':commands,'typecheck':'PASS','lint':'PASS','formatWriteSet':'PASS','formatGlobal':'FAIL_PREEXISTING_OUTSIDE_WRITESET','formatBaselineReproduction':'FAIL byte-exact frozen scripts/hiso-ci-scopes.json; only file flagged by native full prettier check. Preserved by exclusive WriteSet.','fullCoveragePgDockerE2eProviderRelease':'NOT_RUN; forbidden or outside bounded Leaf scope; Main gates belong to Lead.'})
manifest={'task':'CI_IMPORTER_COUNTER_SKIP_PARITY_R10','verdict':'IMPLEMENTED_NOT_ACCEPTED','stage':'BUILD','tier':'T2','authority':'SPEC0180 and continuous user authorization; claim/task registration/persistence owned exclusively by Lead','candidate':str(C),'output':str(O),'source':str(S),'sourceFreezeSha256':sha(P/'freeze.json'),'sourceAuthoritySha256':sha(P/'authority.json'),'sourceNativeSha256':source_native['nativeInventorySha256'],'candidateNativeSha256':candidate_native['nativeInventorySha256'],'writeSet':[{'path':p,'sourceSha256':sha(S/p),'candidateSha256':sha(C/p),'sourceBytes':(S/p).stat().st_size,'candidateBytes':(C/p).stat().st_size,'mode':stat.S_IMODE((C/p).stat().st_mode)} for p in WRITES],'patch':{'path':'build.patch','sha256':sha(O/'build.patch'),'verification':'patch-proof.json'},'tests':{'before':before,'after':after,'newCases':35},'coverageHelperFinalSha256':sha(C/'scripts/lib/coverage-gate.mjs'),'nativeCounts':'counts-proof.json','integrity':'integrity-proof.json','gates':'gates-proof.json','implementation':['Legacy importer shares complete gateTestReport admission and existing transition unit governed policy before any PASS copying/emission; records actual skipped count.','Coverage validates safe nonnegative integer total/covered counters, covered<=total and safe sums; propagates invalid dimensions as FAIL without silently filtering; preserves valid raw/display/shape and erased file handling.','Unit verifier obeys existing governed policy, binds skipped count, and retains separate skip-governance gate; none and PostgreSQL/chaos pass-only behavior unchanged.'],'hisoReportsScriptUnchanged':True,'hisoReportsEditRequired':False,'constraints':{'rootMainAccessed':False,'rootMainModified':False,'commitOrPush':False,'networkDNSPGDockerProviderSecretsSubagents':False,'privateEnvRead':False,'barSchemaCatalogManifestBaselineLockOriginalTestEdits':False},'limitations':['Builder evidence is not independent critical acceptance. No whole CI/scope/remote/prod PASS or release asserted.','Full prettier check fails on inherited out-of-WriteSet scripts/hiso-ci-scopes.json; focused WriteSet format is PASS and baseline failure is reproduced.','Original source governance files were read under repository instructions; this Builder is not a fresh critic and cannot grant acceptance.','Native verifier controls deliberately reject later unrelated snapshots: they prove unit policy admission, not full-scope certification.','No separate current Main inventory was accessed; 8400 Main count is supplied authority, not a new independent equality proof.'],'nextAction':'Lead consumes hash-bound patch, performs its authorized mutation sourceHash-only rebind and current gates/persistence, then obtains a valid independent fresh critic. No integration/acceptance by this Leaf.'}
write('build-manifest.json',manifest)
write('runtime-state.json',{'task':manifest['task'],'status':'READY_FOR_LEAD_REVIEW','verdict':'IMPLEMENTED_NOT_ACCEPTED','last_completed_action':'Native 413/413 six-file regression, types/lint/writeSet format, finite before/after controls, complete Source/dependency/dist preservation and verifiable patch','next_action':manifest['nextAction'],'canonicalRootLedgers':'Lead only; no Leaf writes or updates','gateLimitation':'Inherited global format failure remains outside exclusive WriteSet.'})
write('execution-log.json',{'task':manifest['task'],'round':'R10','artifact':'build-manifest.json','actualNativeBaselineCases':378,'actualNativeAppendCases':35,'actualNativeFinalCases':413,'verdict':'IMPLEMENTED_NOT_ACCEPTED','commands':'gates-proof.json','persistenceOwner':'Lead'})
write('backlog-handoff.json',{'task':manifest['task'],'implementationStatus':'IMPLEMENTED_NOT_ACCEPTED','remaining':['Lead-only sourceHash mutation metadata rebind','Lead current gates/persistence','Valid fresh independent critical review','Inherited format failure outside Leaf WriteSet'],'rootFilesTouched':[]})
# Artifact inventory excludes itself, temporary native fixture directories and opaque patch-check cache.
rows=[]
for p in sorted(O.rglob('*')):
 if p.is_file() and not p.is_symlink() and p.name!='artifact-manifest.json':rows.append({'path':str(p.relative_to(O)),'sha256':sha(p),'bytes':p.stat().st_size})
write('artifact-manifest.json',{'task':manifest['task'],'verdict':'IMPLEMENTED_NOT_ACCEPTED','files':rows})
print(json.dumps({'verdict':manifest['verdict'],'tests':after,'helperSha256':manifest['coverageHelperFinalSha256'],'sourceIntegrity':'MATCH','dependencyIntegrity':'MATCH','distIntegrity':'MATCH','artifactFiles':len(rows),'formatGlobal':'FAIL_PREEXISTING_OUTSIDE_WRITESET'},indent=2))
