import fs from 'node:fs';import path from 'node:path';import{createRequire}from'node:module';import{createHash}from'node:crypto';
const out=import.meta.dirname,root=path.resolve(out,'../ci-native-admission-r11-candidate'),require=createRequire(path.join(root,'package.json')),parser=require('@babel/parser'),phase=process.argv[2],files=['tests/hiso-ci-scopes.test.js','tests/hiso-snapshot-membership-own.test.js'];
const omit=new Set(['loc','start','end','extra','leadingComments','trailingComments','innerComments','comments','tokens']);function clean(n){if(Array.isArray(n))return n.map(clean);if(n&&typeof n==='object')return Object.fromEntries(Object.keys(n).filter(k=>!omit.has(k)).sort().map(k=>[k,clean(n[k])]));return n;}
const rootName=n=>n?.type==='Identifier'?n.name:n?.type==='MemberExpression'||n?.type==='OptionalMemberExpression'?rootName(n.object):n?.type==='CallExpression'?rootName(n.callee):null;
const hash=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
const data=files.map(file=>{const bytes=fs.readFileSync(path.join(root,file)),ast=parser.parse(bytes.toString(),{sourceType:'module'});const assertions=[],registrations=[],counterAssignments=[];
function walk(n){if(!n||typeof n!=='object')return;if(Array.isArray(n)){n.forEach(walk);return;}
if(n.type==='CallExpression'){
 const name=rootName(n.callee);
 if(name==='expect')assertions.push(clean(n));
 if(['it','test','describe'].includes(name))registrations.push(clean(n));
}
if(n.type==='AssignmentExpression'&&n.left?.type==='MemberExpression'&& /^(num|selected|killed|survived|timedOut|errors|occurrence|skipped)/.test(n.left.property?.name??''))counterAssignments.push(clean(n));
for(const[k,v]of Object.entries(n))if(!omit.has(k))walk(v);
}walk(ast.program);
return{file,fileSha256:createHash('sha256').update(bytes).digest('hex'),assertionCallCount:assertions.length,registrationCallCount:registrations.length,assertionAstSha256:hash(assertions),registrationAstSha256:hash(registrations),counterAssignmentsSha256:hash(counterAssignments),assertions,registrations,counterAssignments};});
fs.writeFileSync(path.join(out,'proofs','fixture-ast-'+phase+'.json'),JSON.stringify(data,null,2));
if(phase==='after'){const before=JSON.parse(fs.readFileSync(path.join(out,'proofs/fixture-ast-before.json')));const comparisons=data.map((d,i)=>({file:d.file,assertionCallCount:d.assertionCallCount,registrationCallCount:d.registrationCallCount,assertionsExact:JSON.stringify(d.assertions)===JSON.stringify(before[i].assertions),registrationsNamesCasesAndNegativesExact:JSON.stringify(d.registrations)===JSON.stringify(before[i].registrations),counterAssignmentsExact:JSON.stringify(d.counterAssignments)===JSON.stringify(before[i].counterAssignments),beforeSha256:before[i].fileSha256,afterSha256:d.fileSha256}));fs.writeFileSync(path.join(out,'proofs/fixture-assertAST-comparison.json'),JSON.stringify(comparisons,null,2));console.log(JSON.stringify(comparisons,null,2));if(comparisons.some(d=>!d.assertionsExact||!d.registrationsNamesCasesAndNegativesExact||!d.counterAssignmentsExact))process.exitCode=1;}else console.log(JSON.stringify(data.map(({assertions,registrations,counterAssignments,...x})=>x),null,2));
