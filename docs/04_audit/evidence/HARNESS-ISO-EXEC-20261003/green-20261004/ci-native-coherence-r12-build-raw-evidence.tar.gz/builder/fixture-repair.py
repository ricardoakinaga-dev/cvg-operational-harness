from pathlib import Path
import json,hashlib
base=Path.cwd().parent;out=Path.cwd();root=base/'ci-native-admission-r11-candidate'
p=root/'tests/hiso-ci-scopes.test.js';s=p.read_text()
needle="  const scopes = [],\n    producerResults = {}\n";repl="  const mutationAuthority = JSON.parse(\n    fs.readFileSync(path.join(root, 'scripts/mutation-manifest.json'), 'utf8')\n  )\n"+needle
assert s.count(needle)==1;s=s.replace(needle,repl)
old="""            selected: 1,
            killed: 1,
            survived: 0,
            timedOut: 0,
            errors: 0,
            domains: ['synthetic'],
            mutations: [
              { id: 'synthetic', status: 'KILLED', exitCode: 1, durationMs: 0 }
            ],"""
new="""            manifestSha256: digest(mutationAuthority),
            selected: mutationAuthority.mutations.length,
            killed: mutationAuthority.mutations.length,
            survived: 0,
            timedOut: 0,
            errors: 0,
            domains: [...new Set(mutationAuthority.mutations.map((m) => m.domain))].sort(),
            mutations: mutationAuthority.mutations.map((m) => ({
              id: m.id,
              domain: m.domain,
              mode: m.mode,
              source: m.source,
              sourceSha256: m.sourceSha256,
              from: m.from,
              to: m.to,
              testFiles: m.testFiles ?? [],
              budgetMs: m.budgetMs,
              status: 'KILLED',
              exitCode: 1,
              durationMs: 0
            })),"""
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
p=root/'tests/hiso-snapshot-membership-own.test.js';s=p.read_text();start=s.index('function r10Import(report, required) {');end=s.index("describe('R10 native legacy importer shared admission'",start);part=s[start:end]
needle="  const d = temp(),\n";repl="""  const requiredReports = Object.fromEntries(
    ['postgres', 'chaos'].map((id) => [
      id,
      (id === 'postgres' ? postgres : chaos).map((file) =>
        row(file, 'synthetic required gate case')
      )
    ])
  )
  const collected = inventory([
    ...required.map(({ file, name }) => row(file, name)),
    ...[...new Set([...postgres, ...chaos])].map((file) =>
      row(file, 'synthetic required gate case')
    )
  ])
"""+needle
assert part.count(needle)==1;part=part.replace(needle,repl)
part=part.replace("gate.id === 'unit' ? report : { inert: true }", "gate.id === 'unit'\n          ? report\n          : requiredReports[gate.id]\n            ? native(requiredReports[gate.id])\n            : { inert: true }")
part=part.replace('testInventory: required,','testInventory: collected,').replace('testInventoryHash: r10Digest(required),','testInventoryHash: r10Digest(collected),')
s=s[:start]+part+s[end:];p.write_text(s)
p=root/'scripts/mutation-manifest.json';old=p.read_text();manifest=json.loads(old);count=0;sha=hashlib.sha256((root/'scripts/lib/coverage-gate.mjs').read_bytes()).hexdigest();assert sha=='f1e4851025fe38424183e1f1373637e2f9c0864782a7abe7a07cec2d9d57d957'
for m in manifest['mutations']:
 if m['source']=='scripts/lib/coverage-gate.mjs':
  assert m['sourceSha256']=='82bba40193b992b4b888d6ae3c784c5c8baf8c028dab0a596eff4711adf454db';m['sourceSha256']=sha;count+=1
assert count==3
# Preserve every byte except the three authorized hash strings.
assert old.count('82bba40193b992b4b888d6ae3c784c5c8baf8c028dab0a596eff4711adf454db')==3
p.write_text(old.replace('82bba40193b992b4b888d6ae3c784c5c8baf8c028dab0a596eff4711adf454db',sha))
canon=lambda v: '['+','.join(map(canon,v))+']' if isinstance(v,list) else '{'+','.join(json.dumps(k)+':'+canon(v[k]) for k in sorted(v))+'}' if isinstance(v,dict) else json.dumps(v,ensure_ascii=False,separators=(',',':'))
digest=hashlib.sha256(canon(manifest).encode()).hexdigest();(out/'proofs/approved-mutation-authority.json').write_text(json.dumps({'manifestDigest':digest,'coverageSourceSHA':sha,'authorizedRebinds':count},indent=2));print(digest)
p=root/'scripts/hiso-snapshot-types.mjs';s=p.read_text();s=s.replace('1d3210a3bc99a4d76910f38c715d2ae71a903e99157dd1ceb9dc1e086681e59c',digest)
block="""// The local BUILD changes this producer without changing frozen mutation rows.
// Bind its exact bytes separately; a receipt hash alone cannot authorize drift.
const coverageProducerSha256 =
  'f1e4851025fe38424183e1f1373637e2f9c0864782a7abe7a07cec2d9d57d957'
"""
assert s.count(block)==1;s=s.replace(block,'')
block="""sha(source) ===
        (approved.source === 'scripts/lib/coverage-gate.mjs'
          ? coverageProducerSha256
          : approved.sourceSha256)"""
assert s.count(block)==1;s=s.replace(block,'sha(source) === approved.sourceSha256');p.write_text(s)
