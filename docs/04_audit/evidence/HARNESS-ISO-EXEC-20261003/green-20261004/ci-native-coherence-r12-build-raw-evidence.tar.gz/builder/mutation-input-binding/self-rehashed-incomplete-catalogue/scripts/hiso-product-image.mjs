#!/usr/bin/env node
import fs from 'node:fs'
import { spawnSync } from 'node:child_process'
import { randomUUID } from 'node:crypto'
import { envelope } from './hiso-reports.mjs'
import { requireThat, sha } from './hiso-contract.mjs'

const image = envelope(
  JSON.parse(fs.readFileSync('image.json', 'utf8')),
  'image'
)
requireThat(
  image.candidateId === process.env.CI_CANDIDATE_ID &&
    image.runId === process.env.CI_RUN_ID,
  'product_image_binding'
)
const name = 'hiso-smoke-' + randomUUID()
// This code runs INSIDE the actual candidate container. Network none permits
// only its own loopback mocks; /data is an isolated, ephemeral synthetic tmpfs.
const code = `
import fs from 'node:fs';import assert from 'node:assert/strict';import {createServer} from 'node:http';import {spawn} from 'node:child_process';import {createHash} from 'node:crypto';
let sends=0,modelCalls=0;
const wa=createServer((req,res)=>{req.resume();sends++;res.setHeader('content-type','application/json');res.end(JSON.stringify({id:'synthetic-'+sends}))});
const model=createServer((req,res)=>{req.resume();modelCalls++;res.end('{}')});
const bind=s=>new Promise(r=>s.listen(0,'127.0.0.1',()=>r('http://127.0.0.1:'+s.address().port)));
const waUrl=await bind(wa),modelUrl=await bind(model);
const secret='hiso-synthetic-webhook-fixture-123456';
const child=spawn('/usr/local/bin/node',['/app/shift-assistant.mjs'],{env:{NODE_ENV:'production',SHIFT_PROVIDER:'waha',SHIFT_MEMBERS:'5511900000001=Gestor Ficticio*',SHIFT_WEBHOOK_SECRET:secret,SHIFT_DATA_DIR:'/data',SHIFT_PORT:'0',SHIFT_HOST:'127.0.0.1',WAHA_URL:waUrl,WAHA_API_KEY:'synthetic-only',WHISPER_URL:'http://127.0.0.1:1',LLM_BASE_URL:modelUrl,LLM_LOCATION:'local',LLM_MODEL:'synthetic'},stdio:['ignore','pipe','pipe']});
let text='',errors='';child.stderr.on('data',c=>{errors+=c});
const timer=setTimeout(()=>child.kill('SIGKILL'),15000);
try {
const port=await new Promise((resolve,reject)=>{child.on('error',reject);child.once('exit',()=>reject(new Error('product exited before ready')));child.stdout.on('data',c=>{text+=c;for(const line of text.split('\\n'))try{const v=JSON.parse(line);if(v.event==='shift.started')resolve(v.port)}catch{}})});
assert.equal((await fetch('http://127.0.0.1:'+port+'/health')).status,200);
const response=await fetch('http://127.0.0.1:'+port+'/webhooks/waha',{method:'POST',headers:{'content-type':'application/json','x-cvg-webhook-secret':secret},body:JSON.stringify({event:'message',payload:{id:'hiso-synthetic-help',from:'5511900000001@c.us',body:'/ajuda'}})});assert.equal(response.status,200);
await new Promise(r=>setTimeout(r,250));assert(sends>0);assert.equal(modelCalls,0);assert.equal(process.getuid(),10001);
console.log(JSON.stringify({status:'PASS',health:200,syntheticDemo:'help',sends,modelCalls,uid:process.getuid(),bundleSha256:createHash('sha256').update(fs.readFileSync('/app/shift-assistant.mjs')).digest('hex')}));
}finally{clearTimeout(timer);child.kill('SIGTERM');await new Promise(r=>{if(child.exitCode!==null)r();else{child.once('exit',r);setTimeout(()=>child.kill('SIGKILL'),1000).unref()}});wa.closeAllConnections();model.closeAllConnections();await Promise.all([new Promise(r=>wa.close(r)),new Promise(r=>model.close(r))]);}
`
try {
  const result = spawnSync(
    'docker',
    [
      'run',
      '--rm',
      '--name',
      name,
      '--network',
      'none',
      '--read-only',
      '--tmpfs',
      '/tmp',
      '--tmpfs',
      '/data:uid=10001,gid=10001,mode=0700',
      '--cap-drop=ALL',
      '--security-opt',
      'no-new-privileges',
      image.imageId,
      '/usr/local/bin/node',
      '--input-type=module',
      '-e',
      code
    ],
    { encoding: 'utf8', timeout: 60000, maxBuffer: 8 * 1024 * 1024 }
  )
  process.stdout.write(result.stdout ?? '')
  process.stderr.write(result.stderr ?? '')
  requireThat(result.status === 0, 'product_container_smoke_failed')
  const smoke = JSON.parse(result.stdout.trim().split('\n').at(-1))
  requireThat(
    smoke.status === 'PASS' && smoke.modelCalls === 0 && smoke.health === 200,
    'product_container_smoke_evidence'
  )
  fs.writeFileSync(
    'image-smoke.json',
    JSON.stringify(
      {
        schemaVersion: 1,
        ...smoke,
        imageId: image.imageId,
        runId: image.runId,
        candidateId: image.candidateId,
        probeSha256: sha(code),
        network: 'none',
        readOnly: true,
        syntheticDataTmpfs: true
      },
      null,
      2
    ) + '\n'
  )
} finally {
  spawnSync('docker', ['rm', '-f', name], { encoding: 'utf8', timeout: 10000 })
}
