import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import {
  ModelGateway,
  DeterministicModelProvider,
  PromptRegistry,
  InMemoryCostBudgetStore
} from '@cvg/model-gateway'
import { z } from 'zod'
import {
  createOperationalHarness,
  createCapabilityRegistry,
  InMemoryEffectJournal
} from '@cvg/harness'

for (const url of [
  import.meta.resolve('@cvg/model-gateway'),
  import.meta.resolve('@cvg/harness'),
  import.meta.resolve('@cvg/harness-contracts')
]) {
  const p = fileURLToPath(url)
  assert(
    p.includes(`${path.sep}dist${path.sep}`),
    `public dist required:${url}`
  )
  assert(!p.endsWith('.ts'))
  assert(fs.existsSync(p))
}
const tenantId = 'tenant_00000000-0000-4000-8000-000000000901'
let providerCalls = 0
const provider = new DeterministicModelProvider({
  respond: () => {
    providerCalls++
    return {
      text: '{"marker":"synthetic-inventory"}',
      usage: { inputTokens: 1, outputTokens: 1 },
      providerId: 'deterministic',
      model: 'deterministic-v1',
      externalCall: false
    }
  }
})
const prompts = new PromptRegistry()
prompts.register({
  promptId: 'hiso-public',
  version: '1.0.0',
  content: 'Return a synthetic inventory marker.',
  owner: 'synthetic-fixture',
  approvedBy: 'synthetic-test-only',
  status: 'approved',
  effectiveFrom: '2026-01-01T00:00:00.000Z',
  classification: 'INTERNAL',
  tenantId
})
const gateway = new ModelGateway({
  providers: [provider],
  profiles: {
    fast: {
      name: 'fast',
      providerId: 'deterministic',
      model: 'deterministic-v1',
      location: 'local',
      temperature: 0,
      maxTokens: 32,
      timeoutMs: 1000,
      maxCostUsd: 1,
      estimatedCostUsd: 0,
      maxRetries: 0,
      pricing: { inputPer1kUsd: 0, outputPer1kUsd: 0 }
    }
  },
  prompts
})
const response = await gateway.generate({
  requestId: 'req_hiso_public_0001',
  tenantId,
  correlationId: 'corr_hiso_public_0001',
  promptId: 'hiso-public',
  promptVersion: '1.0.0',
  modelProfile: 'fast',
  dataClassification: 'INTERNAL',
  input: {
    messages: [{ role: 'user', content: 'Count synthetic inventory boxes.' }]
  }
})
assert.equal(response.output.text, '{"marker":"synthetic-inventory"}')
assert.equal(providerCalls, 1)
let effects = 0
const id = 'hiso.synthetic.counter'
const capabilities = createCapabilityRegistry([
  {
    descriptor: {
      id,
      version: '1.0.0',
      description: 'Synthetic read fixture',
      inputSchema: { type: 'object' },
      outputSchema: { type: 'object' },
      risk: 'LOW',
      sideEffect: 'READ',
      idempotent: true,
      requiresApproval: false,
      origin: 'core',
      providerId: 'fixture',
      providerVersion: '1.0.0'
    },
    implementation: {
      validateInput: (x) => typeof x === 'object' && x !== null,
      validateOutput: (x) => typeof x === 'object' && x !== null,
      execute: async () => {
        effects++
        return { status: 'SUCCEEDED', output: { marker: 'synthetic-counter' } }
      }
    }
  }
])
const operational = createOperationalHarness({
  capabilities,
  effectJournal: new InMemoryEffectJournal(),
  orchestrator: {
    decideNextStep: async ({ runtime }) => ({
      action: 'CALL_TOOL',
      toolInvocation: runtime.requestedTool
    })
  },
  modelGateway: {
    complete: async () => {
      throw new Error('fixture forbids model calls')
    }
  },
  policy: {
    evaluate: async () => ({
      outcome: 'ALLOW',
      reason: 'synthetic-fixture',
      policyVersion: 'hiso-fixture-v1'
    })
  },
  approvals: {
    request: async () => {
      throw new Error('unexpected approval')
    }
  },
  audit: { append: async () => {} },
  telemetry: { record: () => {} }
})
const result = await operational.execute({
  agent: {
    id: 'agent.hiso',
    version: '1.0.0',
    objective: 'Count synthetic boxes',
    instructions: ['synthetic only'],
    skills: [],
    tools: [id],
    policies: []
  },
  tenantId,
  conversationId: 'conversation_hiso',
  sessionId: 'session_hiso',
  correlationId: 'correlation_hiso',
  traceId: 'trace_hiso',
  userMessage: 'Synthetic counter',
  context: {
    values: {},
    sourceIds: [],
    capturedAt: '2026-01-01T00:00:00.000Z'
  },
  state: { version: 1, values: {}, updatedAt: '2026-01-01T00:00:00.000Z' },
  budget: {
    maxSteps: 1,
    maxModelCalls: 0,
    maxToolCalls: 1,
    maxDurationMs: 10000,
    maxCostUsd: 1,
    maxTokens: 100
  },
  runtimeProfile: 'single_pass',
  requestedTool: {
    toolId: id,
    toolVersion: '1.0.0',
    operationKey: 'hiso-public-operation',
    input: { synthetic: true }
  }
})
assert.equal(result.stopReason, 'COMPLETED', JSON.stringify(result))
assert.equal(effects, 1)
assert.equal(result.toolResult.output.marker, 'synthetic-counter')
// Exercise actual wire values; omission must not downgrade an approved prompt.
const normalizeText = (text) =>
  text
    .trim()
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/\s*```$/, '')
const profile = {
  name: 'fast',
  providerId: 'fixture-d009',
  model: 'fixture-d009',
  location: 'local',
  temperature: 0,
  maxTokens: 32,
  timeoutMs: 1000,
  maxCostUsd: 1,
  estimatedCostUsd: 0.01,
  maxRetries: 0,
  pricing: { inputPer1kUsd: 0, outputPer1kUsd: 0 }
}
const makeFixture = (
  classification,
  limit = 1,
  text = '```json\n{"color":"blue"}\n```'
) => {
  let calls = 0,
    budgetIO = 0,
    normalizerCalls = 0
  const store = new InMemoryCostBudgetStore()
  const budgetStore = {
    consumed: (key) => {
      budgetIO++
      return store.consumed(key)
    },
    consume: (key, n) => {
      budgetIO++
      store.consume(key, n)
    }
  }
  const registry = new PromptRegistry()
  const record = registry.register({
    promptId: 'neutral-d009',
    version: '1',
    content: 'Count synthetic blue boxes.',
    owner: 'synthetic-fixture',
    approvedBy: 'synthetic-test-only',
    status: 'approved',
    effectiveFrom: '2026-01-01T00:00:00Z',
    classification,
    tenantId
  })
  const fixtureGateway = new ModelGateway({
    providers: [
      {
        id: 'fixture-d009',
        location: 'local',
        models: ['fixture-d009'],
        execute: async () => {
          calls++
          return {
            text,
            usage: { inputTokens: 1, outputTokens: 1 },
            providerId: 'fixture-d009',
            model: 'fixture-d009',
            externalCall: false
          }
        }
      }
    ],
    profiles: { fast: profile },
    prompts: registry,
    budget: { store: budgetStore, limits: { request: limit, day: limit } }
  })
  const request = {
    requestId: 'request_d009_0001',
    correlationId: 'correlation_d009_0001',
    tenantId,
    promptId: record.promptId,
    promptVersion: record.version,
    promptSha256: record.sha256,
    modelProfile: 'fast',
    dataClassification: classification,
    input: {
      messages: [{ role: 'user', content: 'Count synthetic blue boxes.' }]
    },
    structuredOutput: {
      schemaName: 'neutral-color',
      schema: z.object({ color: z.string() }),
      failClosed: true,
      normalizeText: (text) => {
        normalizerCalls++
        return normalizeText(text)
      }
    }
  }
  return {
    gateway: fixtureGateway,
    request,
    counts: () => ({ calls, budgetIO, normalizerCalls })
  }
}
const positive = makeFixture('INTERNAL')
const normalized = await positive.gateway.generate(positive.request)
assert.deepEqual(normalized.output.structured, { color: 'blue' })
assert.equal(normalized.output.text, '```json\n{"color":"blue"}\n```')
assert.equal(positive.counts().calls, 1)
assert.equal(positive.counts().normalizerCalls, 1)
assert(positive.counts().budgetIO > 0)
const exhausted = makeFixture('INTERNAL', 0.001)
await assert.rejects(
  exhausted.gateway.generate(exhausted.request),
  (e) => e.code === 'budget_exceeded'
)
assert.equal(exhausted.counts().calls, 0)
const invalid = makeFixture('INTERNAL', 1, 'not JSON')
await assert.rejects(
  invalid.gateway.generate(invalid.request),
  (e) => e.code === 'schema_invalid' && e.retryable === false
)
assert.equal(invalid.counts().calls, 1)
const classificationCases = []
for (const promptClass of ['CLINICAL', 'INTERNAL']) {
  for (const requestClass of ['CLINICAL', 'UNKNOWN', undefined, 'INTERNAL']) {
    const fixture = makeFixture(promptClass)
    if (requestClass === undefined) delete fixture.request.dataClassification
    else fixture.request.dataClassification = requestClass
    assert.equal(
      Object.hasOwn(fixture.request, 'dataClassification'),
      requestClass !== undefined
    )
    const expectedCode =
      requestClass === 'UNKNOWN'
        ? 'invalid_request'
        : promptClass === 'CLINICAL' || requestClass === 'CLINICAL'
          ? 'policy_denied'
          : undefined
    if (expectedCode) {
      await assert.rejects(
        fixture.gateway.generate(fixture.request),
        (e) => e.code === expectedCode && e.retryable === false
      )
      assert.deepEqual(fixture.counts(), {
        calls: 0,
        budgetIO: 0,
        normalizerCalls: 0
      })
    } else {
      const value = await fixture.gateway.generate(fixture.request)
      assert.deepEqual(value.output.structured, { color: 'blue' })
      assert.equal(value.output.text, '```json\n{"color":"blue"}\n```')
      assert.equal(value.promptSha256, fixture.request.promptSha256)
      assert.deepEqual(fixture.counts(), {
        calls: 1,
        budgetIO: 4,
        normalizerCalls: 1
      })
    }
    classificationCases.push({
      promptClass,
      requestClass: requestClass ?? 'OMITTED',
      hasClassificationField: Object.hasOwn(
        fixture.request,
        'dataClassification'
      ),
      code: expectedCode ?? 'SUCCEEDED',
      ...fixture.counts()
    })
  }
}
// Higher request classification remains outside the INTERNAL prompt approval.
for (const requestClass of ['CONFIDENTIAL', 'FINANCIAL', 'CREDENTIAL']) {
  const denied = makeFixture('INTERNAL')
  denied.request.dataClassification = requestClass
  await assert.rejects(
    denied.gateway.generate(denied.request),
    (e) => e.code === 'policy_denied'
  )
  assert.deepEqual(denied.counts(), {
    calls: 0,
    budgetIO: 0,
    normalizerCalls: 0
  })
}
console.log(
  JSON.stringify({
    schemaVersion: 1,
    status: 'PASS',
    publicExports: true,
    sourceAliases: false,
    provider: 'DETERMINISTIC_FIXTURE_ONLY',
    providerCalls,
    effects,
    clinicalCalls: classificationCases
      .filter((entry) => entry.promptClass === 'CLINICAL')
      .reduce((sum, entry) => sum + entry.calls, 0),
    unknownCalls: classificationCases
      .filter((entry) => entry.requestClass === 'UNKNOWN')
      .reduce((sum, entry) => sum + entry.calls, 0),
    budgetDenied: true,
    normalizer: true,
    product0179Integration: 'SEPARATE_SHIFT_OWNER',
    classificationCases
  })
)
