#!/usr/bin/env node
import fs from 'node:fs'
import path from 'node:path'
import {
  digest,
  exact,
  files,
  requireThat,
  scopeContract,
  sha,
  sourceFiles
} from './hiso-contract.mjs'
import { runnerIdentity, verifyGateSeals } from './ci-bar-provenance.mjs'
import { declarationInventory } from './hiso-inventory.mjs'
import { ownerMapping } from './hiso-variant.mjs'
import { sealFor } from './hiso-verifier.mjs'
import { envelope, gateTestReport } from './hiso-reports.mjs'
import { expectedShape } from './hiso-validation.mjs'
import { CI_BAR_GATES } from './ci-bar-contract.mjs'

// Adapter, not a replacement: verify the complete old executable/seal contract
// first, then retain its raw state, all snapshots, seals and outputs unchanged.
const original = path.resolve(process.argv[2]),
  expectedFile = path.resolve(process.argv[3]),
  out = path.resolve(process.argv[4])
let validatedExpected = false
try {
  const expected = JSON.parse(fs.readFileSync(expectedFile, 'utf8'))
  expectedShape(expected)
  const legacy = JSON.parse(
    fs.readFileSync(path.join(original, 'ci-bar-manifest.json'), 'utf8')
  )
  const state = JSON.parse(
    fs.readFileSync(path.join(original, 'ci-bar-state.json'), 'utf8')
  )
  const proof = verifyGateSeals({
    state,
    artifactDir: original,
    steps: JSON.parse(process.env.CI_BAR_STEPS_JSON ?? 'null'),
    github: runnerIdentity(process.env)
  })
  requireThat(
    proof.failures.length === 0 &&
      legacy.verdict === 'PASS' &&
      legacy.provenance.mode === 'GITHUB_STEP_OUTPUT_SEALED',
    'legacy_not_sealed_pass'
  )
  requireThat(
    sha(fs.readFileSync(path.join(original, 'ci-bar-manifest.json'))) ===
      process.env.LEGACY_MANIFEST_SHA256,
    'legacy_producer_output'
  )
  requireThat(
    digest(sourceFiles(process.cwd())) === expected.candidateId,
    'legacy_hiso_source_drift'
  )
  const pgBytes = fs.readFileSync(process.env.HISO_PG_VERSION_OUTPUT)
  const pg = JSON.parse(pgBytes)
  envelope(pg, 'postgres-version')
  requireThat(
    pg.status === 'PASS' &&
      Number.isSafeInteger(pg.version) &&
      pg.version >= 160000 &&
      pg.version < 170000 &&
      pg.runId === legacy.runId &&
      pg.candidateId === legacy.candidateId,
    'legacy_pg16_binding'
  )
  // Admit the complete collected unit inventory before copying any PASS output.
  // The legacy seal proves bytes/provenance, not file/case membership or policy.
  const unitGate = scopeContract('transition-regression').gates.find(
    (g) => g.id === 'unit'
  )
  const unitReport = JSON.parse(
    fs.readFileSync(
      path.join(
        original,
        'gate-outputs/unit/certification/unit-test-report.json'
      ),
      'utf8'
    )
  )
  const requiredUnitIds =
    expected.scopes['transition-regression'].requiredTestIds
  const requiredUnit = expected.testInventory.filter((t) =>
    requiredUnitIds.includes(t.id)
  )
  exact(
    requiredUnit.map((t) => t.id),
    requiredUnitIds,
    'legacy_unit_selection'
  )
  const executed = gateTestReport(unitReport, unitGate, requiredUnit)
  for (const id of ['postgres', 'chaos']) {
    const gate = scopeContract('transition-regression').gates.find(
      (g) => g.id === id
    )
    const report = JSON.parse(
      fs.readFileSync(
        path.join(original, 'gate-outputs', id, gate.artifacts[0]),
        'utf8'
      )
    )
    gateTestReport(report, gate, expected.testInventory)
  }
  validatedExpected = true
  fs.mkdirSync(out, { recursive: true })
  fs.cpSync(original, path.join(out, 'legacy'), { recursive: true })
  const binding = expected.scopes['transition-regression']
  const m = {
    schemaVersion: 1,
    ...binding,
    sourceMatch: true,
    sourceAfterSha256: expected.sourceSha256,
    variantSourceMatch: true,
    variantSourceAfterSha256: binding.derivedVariantId,
    owner: 'transition',
    versions: { node: process.versions.node, npm: legacy.npmVersion },
    mode: 'GITHUB_JOB_OUTPUT_BOUND',
    workflow: process.env.GITHUB_WORKFLOW_REF,
    job: process.env.GITHUB_JOB,
    environment: {
      postgres: 'VERIFIED_BY_REQUIRED_PG16_GATE',
      browsers: 'VERIFIED_BY_LEGACY_THREE_BROWSER_GATE',
      provider: 'NO_REAL_PROVIDER',
      synthetic: true
    },
    startedAt: legacy.startedAt,
    finishedAt: new Date().toISOString(),
    status: 'PASS',
    testInventory: expected.testInventory,
    testInventoryHash: digest(expected.testInventory),
    testInventoryStatus: 'COLLECTED_NOT_EXECUTED',
    executedTestInventory: [],
    executedTestInventoryHash: digest([]),
    coverage: null,
    image: null,
    gates: [],
    seals: [],
    legacy: {
      contract: legacy.contract,
      candidateId: legacy.candidateId,
      runId: legacy.runId,
      manifestSha256: sha(
        fs.readFileSync(path.join(original, 'ci-bar-manifest.json'))
      ),
      verifiedGateCount: proof.verifiedGateCount
    }
  }
  for (const gate of CI_BAR_GATES) {
    const observed = legacy.gates.find((g) => g.id === gate.id)
    requireThat(observed?.status === 'PASS', 'legacy_gate_not_pass')
    const log =
      gate.id === 'runtime'
        ? fs.readFileSync(path.join(original, 'runtime.txt'))
        : gate.id === 'artifacts'
          ? fs.readFileSync(path.join(original, 'ci-bar-manifest.json'))
          : fs.readFileSync(path.join(original, 'gates', gate.id + '.log'))
    fs.mkdirSync(path.join(out, 'gates'), { recursive: true })
    fs.writeFileSync(path.join(out, 'gates', gate.id + '.log'), log)
    const entry = {
      schemaVersion: 1,
      id: gate.id,
      command: gate.command,
      status: 'PASS',
      exitCode: 0,
      cause: null,
      scope: m.scope,
      runId: m.runId,
      candidateId: m.candidateId,
      startedAt: m.startedAt,
      finishedAt: m.finishedAt,
      skipped: 0,
      logSha256: sha(log),
      outputs: [],
      legacyEntrySha256: digest(observed)
    }
    for (const p of gate.artifacts ?? []) {
      const target = `gate-outputs/${gate.id}/${p}`
      fs.mkdirSync(path.dirname(path.join(out, target)), { recursive: true })
      fs.copyFileSync(
        path.join(original, 'gate-outputs', gate.id, p),
        path.join(out, target)
      )
      const b = fs.readFileSync(path.join(out, target))
      entry.outputs.push({ path: target, sha256: sha(b), size: b.length })
    }
    if (gate.id === 'unit') {
      m.executedTestInventory = executed
      m.executedTestInventoryHash = digest(m.executedTestInventory)
      entry.skipped = executed.filter((t) => t.status !== 'passed').length
    }
    if (gate.id === 'coverage') {
      const report = JSON.parse(
        fs.readFileSync(
          path.join(
            original,
            'gate-outputs/coverage/coverage/coverage-summary.json'
          ),
          'utf8'
        )
      )
      m.coverage = Object.fromEntries(
        Object.entries(report)
          .filter(([p]) => p !== 'total')
          .map(([p, v]) => [
            path.relative(process.cwd(), p).split(path.sep).join('/'),
            v
          ])
      )
    }
    m.gates.push(entry)
    m.seals.push(sealFor(m, entry))
  }
  const inv = {
    schemaVersion: 1,
    id: 'inventory',
    command: ['node', ['scripts/hiso-ci.mjs', 'inventory']],
    status: 'PASS',
    exitCode: 0,
    cause: null,
    scope: m.scope,
    runId: m.runId,
    candidateId: m.candidateId,
    startedAt: m.startedAt,
    finishedAt: m.finishedAt,
    skipped: 0,
    outputs: [],
    logSha256: sha('Verified original transition inventory\n')
  }
  fs.writeFileSync(
    path.join(out, 'gates/inventory.log'),
    'Verified original transition inventory\n'
  )
  fs.mkdirSync(path.join(out, 'gate-outputs/inventory'), { recursive: true })
  const bytes = Buffer.from(
    JSON.stringify({
      schemaVersion: 1,
      testInventory: m.testInventory,
      declarations: declarationInventory(process.cwd()),
      mapping: ownerMapping(sourceFiles(process.cwd()))
    }) + '\n'
  )
  fs.writeFileSync(
    path.join(out, 'gate-outputs/inventory/inventory.json'),
    bytes
  )
  inv.outputs = [
    {
      path: 'gate-outputs/inventory/inventory.json',
      sha256: sha(bytes),
      size: bytes.length
    }
  ]
  m.gates.push(inv)
  m.seals.push(sealFor(m, inv))
  const pgPath = 'gate-outputs/postgres-version/postgres-version.json'
  fs.mkdirSync(path.dirname(path.join(out, pgPath)), { recursive: true })
  fs.writeFileSync(path.join(out, pgPath), pgBytes)
  fs.writeFileSync(path.join(out, 'gates/postgres-version.log'), pgBytes)
  const pgEntry = {
    schemaVersion: 1,
    id: 'postgres-version',
    command: ['node', ['scripts/hiso-postgres-version.mjs']],
    status: 'PASS',
    exitCode: 0,
    cause: null,
    scope: m.scope,
    runId: m.runId,
    candidateId: m.candidateId,
    startedAt: m.startedAt,
    finishedAt: m.finishedAt,
    skipped: 0,
    outputs: [{ path: pgPath, sha256: sha(pgBytes), size: pgBytes.length }],
    logSha256: sha(pgBytes)
  }
  m.gates.push(pgEntry)
  m.seals.push(sealFor(m, pgEntry))
  m.outputs = files(out)
  fs.writeFileSync(
    path.join(out, 'manifest.json'),
    JSON.stringify(m, null, 2) + '\n'
  )
  fs.appendFileSync(
    process.env.GITHUB_OUTPUT,
    `manifest_sha256=${sha(fs.readFileSync(path.join(out, 'manifest.json')))}\nseal_set_sha256=${digest(m.seals)}\ncandidate_id=${m.candidateId}\n`
  )
} catch (e) {
  fs.mkdirSync(out, { recursive: true })
  if (
    validatedExpected &&
    fs.existsSync(original) &&
    !fs.existsSync(path.join(out, 'legacy'))
  )
    fs.cpSync(original, path.join(out, 'legacy'), { recursive: true })
  fs.writeFileSync(path.join(out, 'import-failure.log'), e.stack + '\n')
  fs.writeFileSync(
    path.join(out, 'manifest.json'),
    JSON.stringify(
      {
        status: 'FAIL',
        scope: 'transition-regression',
        cause: e.message,
        legacyContractPreserved: true,
        outputs: files(out).filter((f) => f.path !== 'manifest.json')
      },
      null,
      2
    ) + '\n'
  )
  console.error(e.message)
  process.exitCode = 1
}
