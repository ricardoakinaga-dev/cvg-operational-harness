import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { createRequire } from 'node:module'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { files, digest, requireThat } from './hiso-contract.mjs'

export function preparePublicClosure(source, target) {
  source = path.resolve(source)
  target = path.resolve(target)
  requireThat(
    !target.startsWith(source + path.sep) && !fs.existsSync(target),
    'public_closure_fresh_external_required'
  )
  fs.mkdirSync(target, { recursive: true })
  const workspace = new Map()
  for (const dir of fs.readdirSync(path.join(source, 'packages'))) {
    const p = path.join(source, 'packages', dir, 'package.json')
    if (fs.existsSync(p))
      workspace.set(JSON.parse(fs.readFileSync(p)).name, path.dirname(p))
  }
  const copied = new Set(),
    packages = []
  function copy(name, requester = source) {
    if (copied.has(name)) return
    copied.add(name)
    const internal = workspace.get(name)
    let origin = internal
    if (!origin) {
      const resolver = createRequire(path.join(requester, 'package.json'))
      origin = path.dirname(resolver.resolve(name + '/package.json'))
    }
    const manifest = JSON.parse(
      fs.readFileSync(path.join(origin, 'package.json'))
    )
    const destination = path.join(target, 'node_modules', name)
    fs.mkdirSync(destination, { recursive: true })
    if (internal) {
      requireThat(
        fs.existsSync(path.join(origin, 'dist/index.js')) &&
          fs.existsSync(path.join(origin, 'dist/index.d.ts')),
        `public_dist_missing:${name}`
      )
      fs.copyFileSync(
        path.join(origin, 'package.json'),
        path.join(destination, 'package.json')
      )
      fs.cpSync(path.join(origin, 'dist'), path.join(destination, 'dist'), {
        recursive: true,
        filter: (p) => !p.endsWith('.map') && !p.endsWith('.tsbuildinfo')
      })
    } else {
      fs.cpSync(origin, destination, {
        recursive: true,
        dereference: false,
        filter: (p) =>
          !['src', 'node_modules', '.git'].includes(path.basename(p))
      })
    }
    packages.push({
      name,
      version: manifest.version,
      internal: Boolean(internal)
    })
    for (const dependency of Object.keys(manifest.dependencies ?? {}))
      copy(dependency, origin)
  }
  for (const name of [
    '@cvg/model-gateway',
    '@cvg/harness',
    '@cvg/harness-contracts',
    'zod',
    'typescript',
    '@types/node'
  ])
    copy(name)
  fs.writeFileSync(
    path.join(target, 'package.json'),
    JSON.stringify({
      name: 'hiso-external-synthetic',
      private: true,
      type: 'module'
    }) + '\n'
  )
  fs.copyFileSync(
    path.join(source, 'scripts/hiso-public-fixture.mjs'),
    path.join(target, 'runtime.mjs')
  )
  fs.writeFileSync(
    path.join(target, 'consumer.ts'),
    `import { ModelGateway, PromptRegistry, InMemoryCostBudgetStore, type StructuredOutputContract } from '@cvg/model-gateway';
import { createOperationalHarness, createCapabilityRegistry, InMemoryEffectJournal } from '@cvg/harness';
import type { ModelGateway as NeutralPort } from '@cvg/harness-contracts';
import { z } from 'zod';
const structured: StructuredOutputContract<{color:string}> = {schemaName:'neutral',schema:z.object({color:z.string()}),normalizeText:(text:string)=>text.trim(),failClosed:true};
const port: NeutralPort['complete'] | undefined = undefined;
void [ModelGateway,PromptRegistry,InMemoryCostBudgetStore,createOperationalHarness,createCapabilityRegistry,InMemoryEffectJournal,structured,port];\n`
  )
  fs.writeFileSync(
    path.join(target, 'tsconfig.json'),
    JSON.stringify({
      compilerOptions: {
        target: 'ES2022',
        module: 'NodeNext',
        moduleResolution: 'NodeNext',
        strict: true,
        noEmit: true,
        skipLibCheck: false,
        types: ['node'],
        paths: {}
      },
      files: ['consumer.ts']
    }) + '\n'
  )
  fs.writeFileSync(
    path.join(target, 'loader.mjs'),
    `import fs from 'node:fs';import {fileURLToPath} from 'node:url';import path from 'node:path';
const root=path.dirname(fileURLToPath(import.meta.url))+path.sep;
export async function resolve(specifier,context,next){const result=await next(specifier,context);if(result.url.startsWith('file:')){const file=fileURLToPath(result.url);if(!file.startsWith(root)||file.split(path.sep).includes('src')||fs.realpathSync(file)!==file)throw new Error('public_runtime_closure_escape:'+file);fs.appendFileSync(root+'resolution.jsonl',JSON.stringify({specifier,url:result.url})+'\\n')}return result}\n`
  )
  const inventory = files(target)
  requireThat(
    inventory.every((f) => !f.path.split('/').includes('src')),
    'public_source_present'
  )
  return { packages, inventory, sha256: digest(inventory) }
}

export function publicSmoke({
  source = path.resolve(import.meta.dirname, '..'),
  output,
  report
} = {}) {
  requireThat(/^22\./.test(process.versions.node), 'public_node22')
  const closure =
    output ??
    path.join(
      fs.mkdtempSync(
        path.join(process.env.TMPDIR ?? os.tmpdir(), 'hiso-public-')
      ),
      'consumer'
    )
  const prepared = preparePublicClosure(source, closure)
  const env = {
    PATH: process.env.PATH,
    HOME: closure,
    TMPDIR: path.dirname(closure),
    NODE_ENV: 'production'
  }
  const run = (id, args) => {
    const result = spawnSync(process.execPath, args, {
      cwd: closure,
      env,
      encoding: 'utf8',
      timeout: 120000,
      maxBuffer: 16 * 1024 * 1024
    })
    fs.writeFileSync(
      path.join(closure, id + '.log'),
      (result.stdout ?? '') +
        (result.stderr ?? '') +
        (result.error ? String(result.error) : '')
    )
    requireThat(result.status === 0, `public_${id}_failed`)
    return result.stdout
  }
  const typeArgs = [
    'node_modules/typescript/bin/tsc',
    '-p',
    'tsconfig.json',
    '--pretty',
    'false',
    '--traceResolution'
  ]
  run('declarations', typeArgs)
  const resolutions = fs
    .readFileSync(path.join(closure, 'declarations.log'), 'utf8')
    .split('\n')
    .filter((l) => l.includes('was successfully resolved to'))
  requireThat(
    resolutions.length > 0 &&
      resolutions.every(
        (l) => !l.includes('/src/') && !l.includes(source + path.sep)
      ),
    'public_declaration_escape'
  )
  const runtimeArgs = ['--loader', './loader.mjs', 'runtime.mjs']
  const value = JSON.parse(
    run('runtime', runtimeArgs).trim().split('\n').at(-1)
  )
  const after = files(closure).filter((f) =>
    prepared.inventory.some((old) => old.path === f.path)
  )
  requireThat(digest(after) === prepared.sha256, 'public_closure_changed')
  const result = {
    ...value,
    sourceFree: true,
    declarations: true,
    node: process.versions.node,
    closure,
    closureSha256: prepared.sha256,
    packages: prepared.packages,
    commands: {
      typecheck: [process.execPath, typeArgs],
      runtime: [process.execPath, runtimeArgs]
    },
    runtimeResolutionSha256: digest(
      fs.readFileSync(path.join(closure, 'resolution.jsonl'), 'utf8')
    ),
    externalGates: 'NOT_RUN',
    remoteCiPass: false
  }
  fs.writeFileSync(
    path.join(closure, 'closure-report.json'),
    JSON.stringify(result, null, 2) + '\n'
  )
  if (report) fs.writeFileSync(report, JSON.stringify(result, null, 2) + '\n')
  return result
}
if (
  process.argv[1] &&
  path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)
) {
  try {
    console.log(
      JSON.stringify(
        publicSmoke({
          output: process.argv[2],
          report: process.argv[3] ?? 'public-smoke.json'
        })
      )
    )
  } catch (e) {
    console.error(e.stack)
    process.exitCode = 1
  }
}
