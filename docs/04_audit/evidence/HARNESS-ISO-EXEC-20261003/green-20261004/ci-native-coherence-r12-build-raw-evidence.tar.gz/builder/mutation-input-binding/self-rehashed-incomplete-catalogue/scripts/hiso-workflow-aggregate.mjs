#!/usr/bin/env node
import fs from 'node:fs'
import path from 'node:path'
import {
  contract,
  contractHash,
  requireThat,
  sha,
  VERSION
} from './hiso-contract.mjs'
import { aggregate } from './hiso-verifier.mjs'
import { envelope } from './hiso-reports.mjs'
import { collectRemoteTrust } from './hiso-remote-trust.mjs'

const input = process.argv[2],
  out = process.argv[3]
const failures = []
const read = (p) => JSON.parse(fs.readFileSync(path.join(input, p), 'utf8'))
let result
try {
  const needs = JSON.parse(process.env.HISO_NEEDS_JSON ?? 'null')
  requireThat(needs, 'job_results_missing')
  for (const id of [
    'harness-neutral',
    'consumer-contract',
    'shift-product',
    'transition-regression',
    'security-status',
    'attest',
    'provenance-verify',
    'provenance-policy'
  ])
    requireThat(needs[id]?.result === 'success', `job_not_success:${id}`)
  const expected = envelope(read('inputs/expected.json'), 'expected')
  expected.securityRunId = Number(
    needs['security-status'].outputs.security_run_id
  )
  expected.securityAttempt = Number(
    needs['security-status'].outputs.security_attempt
  )
  const scopes = contract.scopes.map((s) => {
    const directory = path.join(input, s.id)
    return {
      directory,
      manifest: JSON.parse(
        fs.readFileSync(path.join(directory, 'manifest.json'), 'utf8')
      )
    }
  })
  const producers = Object.fromEntries(
    contract.scopes.map((s) => [
      s.id,
      {
        schemaVersion: 1,
        result: needs[s.id].result,
        artifactId: needs[s.id].outputs.artifact_id,
        artifactDigest: needs[s.id].outputs.artifact_digest,
        manifestSha256: needs[s.id].outputs.manifest_sha256,
        sealSetSha256: needs[s.id].outputs.seal_set_sha256
      }
    ])
  )
  const provenance = read('provenance-verify/provenance.json'),
    policy = read('provenance-policy/policy.json')
  requireThat(
    policy.status === 'PASS' &&
      policy.sourceSha === expected.sha &&
      policy.runId === expected.runId &&
      policy.attempt === expected.attempt &&
      sha(
        fs.readFileSync(path.join(input, 'provenance-policy/policy.json'))
      ) === needs['provenance-policy'].outputs.policy_sha256,
    'provenance_policy_binding'
  )
  envelope(policy, 'policy')
  envelope(provenance, 'provenance')
  provenance.checks.push({
    id: 'provenance-policy',
    status: 'PASS',
    evidenceSha256: needs['provenance-policy'].outputs.policy_sha256
  })
  const security = read('security-status/security.json')
  const trust = await collectRemoteTrust({
    scopes,
    expected,
    security,
    provenance,
    producerResults: producers,
    expectedFile: path.join(input, 'inputs/expected.json'),
    output: path.join(out, 'remote-trust')
  })
  result = aggregate({
    scopes,
    expected,
    security,
    provenance,
    producerResults: producers,
    mode: 'remote',
    trust
  })
} catch (e) {
  failures.push(e.message)
  result = {
    schemaVersion: 1,
    remoteCiPass: false,
    contract: VERSION,
    contractHash,
    status: 'FAIL',
    failures,
    runId: process.env.GITHUB_RUN_ID ?? null,
    attempt: process.env.GITHUB_RUN_ATTEMPT ?? null,
    sha: process.env.GITHUB_SHA ?? null,
    cause:
      'Missing/failed jobs or unverified current-candidate evidence cannot pass.'
  }
}
fs.mkdirSync(out, { recursive: true })
fs.writeFileSync(
  path.join(out, 'aggregate.json'),
  JSON.stringify(result, null, 2) + '\n'
)
console.log(
  JSON.stringify({ status: result.status, failures: result.failures })
)
process.exitCode = result.status === 'PASS' ? 0 : 1
