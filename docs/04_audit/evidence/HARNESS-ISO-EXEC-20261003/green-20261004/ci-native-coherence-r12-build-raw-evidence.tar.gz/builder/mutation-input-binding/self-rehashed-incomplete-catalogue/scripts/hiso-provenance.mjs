#!/usr/bin/env node
import fs from 'node:fs'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import {
  contract,
  digest,
  files,
  requireThat,
  sha,
  sourceFiles
} from './hiso-contract.mjs'
import { preflightScopes } from './hiso-verifier.mjs'
const input = path.resolve(process.argv[2]),
  out = path.resolve(process.argv[3])
fs.mkdirSync(out, { recursive: true })
try {
  requireThat(
    process.env.GITHUB_ACTIONS === 'true' && process.env.GH_TOKEN,
    'independent_runner_auth_required'
  )
  const needs = JSON.parse(process.env.HISO_NEEDS_JSON ?? 'null')
  requireThat(needs?.attest?.result === 'success', 'attest_job_failed')
  const expectedFile = path.join(
    input,
    `hiso-inputs-${process.env.GITHUB_RUN_ID}-${process.env.GITHUB_RUN_ATTEMPT}`,
    'expected.json'
  )
  requireThat(
    needs?.inputs?.result === 'success' &&
      sha(fs.readFileSync(expectedFile)) ===
        needs.inputs.outputs.expected_sha256,
    'external_expected_input_binding'
  )
  const expected = JSON.parse(fs.readFileSync(expectedFile, 'utf8'))
  requireThat(
    expected.sha === process.env.GITHUB_SHA &&
      expected.runId ===
        `run-${process.env.GITHUB_RUN_ID}-${process.env.GITHUB_RUN_ATTEMPT}` &&
      expected.attempt === process.env.GITHUB_RUN_ATTEMPT &&
      digest(sourceFiles(path.resolve(import.meta.dirname, '..'))) ===
        expected.sourceSha256 &&
      expected.candidateId === expected.sourceSha256,
    'external_context_binding'
  )
  const scopes = contract.scopes.map((scope) => {
    const directory = path.join(
      input,
      `hiso-${scope.id}-${process.env.GITHUB_RUN_ID}-${process.env.GITHUB_RUN_ATTEMPT}`
    )
    return {
      directory,
      manifest: JSON.parse(
        fs.readFileSync(path.join(directory, 'manifest.json'), 'utf8')
      )
    }
  })
  const producerResults = Object.fromEntries(
    contract.scopes.map((s) => [
      s.id,
      {
        schemaVersion: 1,
        result: needs[s.id]?.result,
        artifactId: needs[s.id]?.outputs?.artifact_id,
        artifactDigest: needs[s.id]?.outputs?.artifact_digest,
        manifestSha256: needs[s.id]?.outputs?.manifest_sha256,
        sealSetSha256: needs[s.id]?.outputs?.seal_set_sha256
      }
    ])
  )
  // Validate every subject and sealed snapshot before verifying the first
  // signature. A later malformed scope must not cause an earlier gh invocation.
  preflightScopes({ scopes, expected, producerResults })
  for (const { directory, manifest: m } of scopes) {
    const scope = { id: m.scope },
      subject = path.join(directory, 'manifest.json')
    requireThat(
      needs[scope.id]?.result === 'success' &&
        sha(fs.readFileSync(subject)) ===
          needs[scope.id].outputs.manifest_sha256 &&
        digest(m.seals) === needs[scope.id].outputs.seal_set_sha256,
      'subject_producer_binding'
    )
    requireThat(
      m.status === 'PASS' &&
        JSON.stringify(
          files(directory).filter((f) => f.path !== 'manifest.json')
        ) === JSON.stringify(m.outputs),
      'subject_output_inventory'
    )
    const r = spawnSync(
      'gh',
      [
        'attestation',
        'verify',
        subject,
        '--repo',
        process.env.GITHUB_REPOSITORY,
        '--signer-workflow',
        `${process.env.GITHUB_REPOSITORY}/.github/workflows/harness-isolation.yml`,
        '--source-digest',
        process.env.GITHUB_SHA,
        '--deny-self-hosted-runners',
        '--format',
        'json'
      ],
      { encoding: 'utf8', timeout: 120000, maxBuffer: 16 * 1024 * 1024 }
    )
    fs.writeFileSync(path.join(out, scope.id + '.json'), r.stdout ?? '')
    fs.writeFileSync(path.join(out, scope.id + '.log'), r.stderr ?? '')
    requireThat(
      r.status === 0 && JSON.parse(r.stdout).length > 0,
      'independent_attestation_verification_failed'
    )
  }
  const evidence = digest(files(out))
  fs.writeFileSync(
    path.join(out, 'provenance.json'),
    JSON.stringify(
      {
        schemaVersion: 1,
        mode: 'INDEPENDENT_GITHUB_ATTESTATION_VERIFIED',
        sourceSha: process.env.GITHUB_SHA,
        runId: `run-${process.env.GITHUB_RUN_ID}-${process.env.GITHUB_RUN_ATTEMPT}`,
        attempt: process.env.GITHUB_RUN_ATTEMPT,
        checks: [
          { id: 'attest', status: 'PASS', evidenceSha256: evidence },
          { id: 'provenance-verify', status: 'PASS', evidenceSha256: evidence }
        ]
      },
      null,
      2
    ) + '\n'
  )
} catch (e) {
  fs.writeFileSync(
    path.join(out, 'provenance.json'),
    JSON.stringify(
      {
        schemaVersion: 1,
        status: /independent_runner_auth_required/.test(e.message)
          ? 'NOT_RUN'
          : 'FAIL',
        cause: e.message
      },
      null,
      2
    ) + '\n'
  )
  console.error(e.message)
  process.exitCode = 1
}
