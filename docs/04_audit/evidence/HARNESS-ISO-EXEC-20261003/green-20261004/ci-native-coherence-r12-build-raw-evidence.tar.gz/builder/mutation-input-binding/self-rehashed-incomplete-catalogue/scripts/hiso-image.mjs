#!/usr/bin/env node
import fs from 'node:fs'
import { spawnSync } from 'node:child_process'
import { requireThat, sha } from './hiso-contract.mjs'

const product = process.argv[2] === 'shift-product'
const runId = process.env.CI_RUN_ID,
  candidateId = process.env.CI_CANDIDATE_ID
requireThat(
  runId && /^[0-9a-f]{64}$/.test(candidateId ?? ''),
  'image_candidate_binding'
)
const dockerfile = product
  ? 'products/shift-assistant/deploy/Dockerfile'
  : 'Dockerfile'
const tag = `cvg-hiso-${product ? 'shift' : 'harness'}:${candidateId.slice(0, 20)}`
const command = (bin, args) => {
  const r = spawnSync(bin, args, {
    encoding: 'utf8',
    timeout: 3600000,
    maxBuffer: 128 * 1024 * 1024
  })
  if (r.stdout) process.stdout.write(r.stdout)
  if (r.stderr) process.stderr.write(r.stderr)
  requireThat(r.status === 0, `image_command_failed:${bin}:${r.status}`)
  return r.stdout
}
command('docker', [
  'build',
  '--target',
  'runtime',
  '-f',
  dockerfile,
  '--tag',
  tag,
  '.'
])
const inspection = JSON.parse(command('docker', ['image', 'inspect', tag]))[0]
const text = fs.readFileSync(dockerfile, 'utf8')
const baseRef = text.match(
  /^FROM (node:22\S+@sha256:[a-f0-9]{64}) AS build$/m
)?.[1]
requireThat(
  baseRef && /^sha256:[0-9a-f]{64}$/.test(inspection.Id),
  'image_id_or_base'
)
if (product) {
  requireThat(
    inspection.Config.User === '10001:10001' &&
      inspection.Config.Cmd?.join(' ') ===
        '/usr/local/bin/node shift-assistant.mjs',
    'product_entrypoint'
  )
  fs.writeFileSync(
    'image.json',
    JSON.stringify(
      {
        schemaVersion: 1,
        status: 'PASS',
        candidateId,
        runId,
        imageId: inspection.Id,
        tag,
        dockerfile,
        dockerfileSha256: sha(text),
        baseRef,
        config: inspection.Config,
        smoke: 'NOT_RUN_UNTIL_SEPARATE_GATE'
      },
      null,
      2
    ) + '\n'
  )
} else {
  command('docker', [
    'run',
    '--rm',
    '--network',
    'none',
    '--read-only',
    '--tmpfs',
    '/tmp',
    '--cap-drop=ALL',
    '--security-opt',
    'no-new-privileges',
    tag,
    'node',
    'scripts/runtime-image-smoke.mjs'
  ])
  command(process.execPath, [
    'scripts/runtime-image-record.mjs',
    '--tag',
    tag,
    '--run-id',
    runId,
    '--candidate-id',
    candidateId
  ])
}
