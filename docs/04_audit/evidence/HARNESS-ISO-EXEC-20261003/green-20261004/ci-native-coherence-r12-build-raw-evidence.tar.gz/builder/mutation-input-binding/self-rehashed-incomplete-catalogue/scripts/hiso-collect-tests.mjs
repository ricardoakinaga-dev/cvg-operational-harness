import fs from 'node:fs'
import { createVitest } from 'vitest/node'
// Public runtime collection API, deliberately without CLI list's skipped-test
// filter. Collect declarations/parameter expansions; never invoke ctx.start/run.
const ctx = await createVitest('test', {
  watch: false,
  run: true,
  maxWorkers: 2,
  includeTaskLocation: true
})
try {
  const { testModules, unhandledErrors } = await ctx.collect(
    process.argv.slice(3)
  )
  if (unhandledErrors.length)
    throw new Error(
      'collection_unhandled_errors:' + JSON.stringify(unhandledErrors)
    )
  const rows = []
  for (const module of testModules) {
    const errors = [
      ...module.errors(),
      ...[...module.children.allSuites()].flatMap((s) => s.errors())
    ]
    if (errors.length)
      throw new Error('collection_module_errors:' + JSON.stringify(errors))
    for (const test of module.children.allTests())
      rows.push({
        file: module.moduleId,
        name: test.fullName,
        collectionState: test.result().state,
        location: test.location ?? null,
        vitestTaskId: test.id
      })
  }
  fs.writeFileSync(process.argv[2], JSON.stringify(rows, null, 2) + '\n')
  console.log(
    JSON.stringify({
      mode: 'PUBLIC_API_COLLECTION_ONLY_NOT_EXECUTION',
      cases: rows.length,
      files: testModules.length,
      declaredSkippedCases: rows.filter((t) => t.collectionState === 'skipped')
        .length,
      executedTests: 0
    })
  )
} finally {
  await ctx.close()
}
