import fs from 'node:fs'
import path from 'node:path'
import { contract, files, requireThat } from './hiso-contract.mjs'
const source = path.resolve(process.argv[2]),
  target = path.resolve(process.argv[3])
fs.mkdirSync(target, { recursive: true })
const allowed = [
  'inputs',
  ...contract.scopes.map((s) => s.id),
  'security-status',
  'provenance-verify',
  'provenance-policy',
  'legacy-transition'
]
for (const name of fs.readdirSync(source)) {
  const suffix = `-${process.env.GITHUB_RUN_ID}-${process.env.GITHUB_RUN_ATTEMPT}`
  requireThat(
    name.startsWith('hiso-') && name.endsWith(suffix),
    'downloaded_artifact_run_binding'
  )
  const lane = name.slice(5, -suffix.length)
  requireThat(
    allowed.includes(lane) && !fs.existsSync(path.join(target, lane)),
    'unknown_or_duplicate_artifact_scope'
  )
  files(path.join(source, name)) // rejects all symlinks and non-files
  fs.cpSync(path.join(source, name), path.join(target, lane), {
    recursive: true
  })
}
