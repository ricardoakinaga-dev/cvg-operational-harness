import fs from 'node:fs'
import path from 'node:path'
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const digest = (value) => createHash('sha256').update(value).digest('hex')
const requireThat = (condition, message) => {
  if (!condition) throw new Error(`secret_guard:${message}`)
}
const hashPattern = /^[a-f0-9]{64}$/
const identity = (finding) =>
  JSON.stringify([
    finding.ruleId,
    finding.path,
    finding.startLine,
    finding.endLine,
    finding.startColumn,
    finding.endColumn
  ])
const safeFile = (root, relative) => {
  requireThat(
    typeof relative === 'string' &&
      relative !== '' &&
      !relative.includes('\\') &&
      !path.isAbsolute(relative),
    'unsafe_path'
  )
  requireThat(
    relative
      .split('/')
      .every((part) => part !== '' && part !== '.' && part !== '..'),
    'unsafe_path'
  )
  const file = path.join(root, relative)
  let current = root
  for (const part of relative.split('/')) {
    current = path.join(current, part)
    requireThat(!fs.lstatSync(current).isSymbolicLink(), 'source_symlink')
  }
  requireThat(fs.statSync(file).isFile(), 'not_a_source_file')
  return file
}

/** Validate every source binding before any individual fingerprint is usable. */
export function validateFingerprintInventory(root, inventory) {
  requireThat(
    inventory?.schemaVersion === 1 && Array.isArray(inventory.entries),
    'inventory_schema'
  )
  const records = new Map(),
    files = new Map()
  for (const entry of inventory.entries) {
    requireThat(
      entry.ruleId === 'generic-api-key' &&
        entry.disposition === 'SYNTHETIC_OR_DOCUMENTARY_I0',
      'unapproved_disposition'
    )
    requireThat(
      hashPattern.test(entry.sourceDigest) &&
        hashPattern.test(entry.spanDigest) &&
        hashPattern.test(entry.valueDigest),
      'invalid_digest'
    )
    requireThat(
      [
        entry.startLine,
        entry.endLine,
        entry.startColumn,
        entry.endColumn
      ].every((value) => Number.isSafeInteger(value) && value > 0) &&
        entry.endLine >= entry.startLine,
      'invalid_position'
    )
    requireThat(
      entry.fingerprint === `${entry.path}:${entry.ruleId}:${entry.startLine}`,
      'fingerprint_mismatch'
    )
    const key = identity(entry)
    requireThat(!records.has(key), 'duplicate_position')
    let source = files.get(entry.path)
    if (!source) {
      const bytes = fs.readFileSync(safeFile(root, entry.path))
      source = {
        digest: digest(bytes),
        lines: bytes
          .toString('utf8')
          .split('\n')
          .map((line) => (line.endsWith('\r') ? line.slice(0, -1) : line))
      }
      files.set(entry.path, source)
    }
    requireThat(source.digest === entry.sourceDigest, 'source_digest_changed')
    requireThat(entry.endLine <= source.lines.length, 'position_outside_source')
    const span = source.lines
      .slice(entry.startLine - 1, entry.endLine)
      .join('\n')
    requireThat(digest(span) === entry.spanDigest, 'source_span_changed')
    records.set(key, { ...entry, sourceSpan: span })
  }
  return { records, files: files.size }
}

/** Only the individually bound findings are disposed; every unknown blocks. */
export function adjudicateSourceFindings(root, inventory, rawFindings) {
  const { records, files } = validateFingerprintInventory(root, inventory)
  requireThat(Array.isArray(rawFindings), 'raw_report_schema')
  const unknown = [],
    observed = new Set()
  for (const raw of rawFindings) {
    const entry = {
      ruleId: raw.RuleID,
      path: raw.File,
      startLine: raw.StartLine,
      endLine: raw.EndLine,
      startColumn: raw.StartColumn,
      endColumn: raw.EndColumn
    }
    const key = identity(entry),
      known = records.get(key)
    requireThat(!observed.has(key), 'duplicate_raw_position')
    observed.add(key)
    let valueMatches = false
    if (
      known &&
      typeof raw.Match === 'string' &&
      raw.Match.split('REDACTED').length === 2
    ) {
      const [prefix, suffix] = raw.Match.split('REDACTED')
      const position = known.sourceSpan.indexOf(prefix)
      const start = position + prefix.length
      const end = suffix
        ? known.sourceSpan.indexOf(suffix, start)
        : known.sourceSpan.length
      if (position >= 0 && end >= start)
        valueMatches =
          digest(known.sourceSpan.slice(start, end)) === known.valueDigest
    }
    if (!known || raw.Fingerprint !== known.fingerprint || !valueMatches)
      unknown.push(entry)
  }
  // A changed/removed rule or scanner output must not silently make an inventory disappear.
  const missing = [...records.keys()].filter((key) => !observed.has(key))
  return {
    schemaVersion: 1,
    status:
      unknown.length || missing.length
        ? 'FAIL'
        : 'PASS_WITH_INDIVIDUAL_DISPOSITIONS',
    rawFindingCount: rawFindings.length,
    disposed: rawFindings.length - unknown.length,
    unknown,
    missingCount: missing.length,
    sourceFiles: files,
    rulesDisabled: false,
    broadPathAllowlist: false,
    independentReview: 'REQUIRED'
  }
}

export function runGuard({ root, inventoryPath, output, executable }) {
  root = fs.realpathSync(root)
  output = path.resolve(output)
  requireThat(
    output !== root && !output.startsWith(root + path.sep),
    'output_inside_source'
  )
  fs.mkdirSync(output, { recursive: true, mode: 0o700 })
  const inventory = JSON.parse(fs.readFileSync(inventoryPath, 'utf8'))
  validateFingerprintInventory(root, inventory)
  const config = path.join(output, 'strict-default.toml')
  fs.writeFileSync(config, '[extend]\nuseDefault = true\n', { mode: 0o600 })
  const ignore = path.join(output, '.gitleaksignore')
  fs.writeFileSync(ignore, '', { mode: 0o600 })
  requireThat(
    !fs.existsSync(path.join(root, '.env')),
    'public_source_snapshot_required'
  )
  // Gitleaks8.28 always loads source/.gitleaksignore, even with --ignore-path.
  // Preserve its content as a scanned metadata file in a private physical copy;
  // never alter the protected source or let this file filter the raw detector.
  const stage = path.join(output, 'public-source')
  requireThat(!fs.existsSync(stage), 'output_already_used')
  fs.cpSync(root, stage, {
    recursive: true,
    dereference: false,
    filter: (source) =>
      path.relative(root, source).split(path.sep)[0] !== '.git'
  })
  const metadata = '__cvg_original_ignore_metadata__.txt'
  requireThat(
    !fs.existsSync(path.join(root, metadata)),
    'reserved_metadata_name'
  )
  const originalIgnore = path.join(stage, '.gitleaksignore')
  if (fs.existsSync(originalIgnore))
    fs.renameSync(originalIgnore, path.join(stage, metadata))
  const report = path.join(output, 'raw-findings.json')
  const result = spawnSync(
    executable,
    [
      'dir',
      '.',
      '--config',
      config,
      '--gitleaks-ignore-path',
      ignore,
      '--ignore-gitleaks-allow',
      '--redact=100',
      '--report-format',
      'json',
      '--report-path',
      report,
      '--no-banner'
    ],
    { encoding: 'utf8', cwd: stage }
  )
  fs.writeFileSync(
    path.join(output, 'scanner.log'),
    (result.stdout ?? '') + (result.stderr ?? ''),
    { mode: 0o600 }
  )
  requireThat(
    !result.error && [0, 1].includes(result.status) && fs.existsSync(report),
    'scanner_failed'
  )
  const raw = JSON.parse(fs.readFileSync(report, 'utf8'))
  const mapped = raw.map((finding) =>
    finding.File === metadata
      ? {
          ...finding,
          File: '.gitleaksignore',
          Fingerprint: `.gitleaksignore:${finding.RuleID}:${finding.StartLine}`
        }
      : finding
  )
  const verdict = adjudicateSourceFindings(root, inventory, mapped)
  verdict.scanSourceMetadataMapping = { [metadata]: '.gitleaksignore' }
  verdict.rawIgnoreFingerprintsApplied = false
  verdict.scannerExitCode = result.status
  verdict.inventoryDigest = digest(fs.readFileSync(inventoryPath))
  verdict.rawReportDigest = digest(fs.readFileSync(report))
  fs.writeFileSync(
    path.join(output, 'verdict.json'),
    JSON.stringify(verdict, null, 2) + '\n'
  )
  return verdict
}

if (
  process.argv[1] &&
  fileURLToPath(import.meta.url) === path.resolve(process.argv[1])
) {
  try {
    const [root, inventoryPath, output, executable = 'gitleaks'] =
      process.argv.slice(2)
    requireThat(root && inventoryPath && output, 'arguments')
    const result = runGuard({ root, inventoryPath, output, executable })
    console.log(
      JSON.stringify({
        status: result.status,
        rawFindingCount: result.rawFindingCount,
        unknown: result.unknown.length,
        missing: result.missingCount
      })
    )
    process.exitCode =
      result.status === 'PASS_WITH_INDIVIDUAL_DISPOSITIONS' ? 0 : 1
  } catch {
    console.error('Secret fingerprint guard failed closed')
    process.exitCode = 1
  }
}
