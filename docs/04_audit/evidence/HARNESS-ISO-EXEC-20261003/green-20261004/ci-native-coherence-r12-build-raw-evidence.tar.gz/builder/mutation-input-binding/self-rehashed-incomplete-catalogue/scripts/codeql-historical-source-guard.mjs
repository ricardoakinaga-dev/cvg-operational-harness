import fs from 'node:fs'
import path from 'node:path'
import { createHash } from 'node:crypto'
import { fileURLToPath } from 'node:url'
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex')
const extensions = new Set([
  '.js',
  '.mjs',
  '.cjs',
  '.ts',
  '.tsx',
  '.mts',
  '.cts',
  '.py',
  '.sh',
  '.html',
  '.vue',
  '.svelte'
])
const requireThat = (value, reason) => {
  if (!value) throw new Error(`historical_source:${reason}`)
}
function file(root, relative) {
  requireThat(
    typeof relative === 'string' &&
      relative !== '' &&
      !path.isAbsolute(relative) &&
      !relative.includes('\\') &&
      relative.split('/').every((p) => p && p !== '.' && p !== '..'),
    'unsafe_path'
  )
  let current = root
  for (const part of relative.split('/')) {
    current = path.join(current, part)
    requireThat(!fs.lstatSync(current).isSymbolicLink(), 'symlink')
  }
  requireThat(fs.statSync(current).isFile(), 'not_file')
  return current
}
export function validateHistoricalSourceInventory(root, inventory) {
  root = fs.realpathSync(root)
  requireThat(
    inventory?.schemaVersion === 1 &&
      inventory.scope === 'docs/04_audit/evidence' &&
      Array.isArray(inventory.historicalFiles) &&
      Array.isArray(inventory.historicalFindings) &&
      Array.isArray(inventory.buildInputs),
    'schema'
  )
  const observed = []
  function walk(directory) {
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
      requireThat(!entry.isSymbolicLink(), 'historical_symlink')
      const full = path.join(directory, entry.name)
      if (entry.isDirectory()) walk(full)
      else if (entry.isFile() && extensions.has(path.extname(full)))
        observed.push(path.relative(root, full).split(path.sep).join('/'))
    }
  }
  walk(path.join(root, inventory.scope))
  const records = new Map()
  for (const entry of inventory.historicalFiles) {
    requireThat(
      entry.path.startsWith(inventory.scope + '/') &&
        extensions.has(path.extname(entry.path)) &&
        !records.has(entry.path),
      'historical_path'
    )
    requireThat(
      /^[a-f0-9]{64}$/.test(entry.sha256) &&
        sha(fs.readFileSync(file(root, entry.path))) === entry.sha256,
      'historical_bytes_changed'
    )
    records.set(entry.path, entry.sha256)
  }
  requireThat(
    observed.length === records.size && observed.every((p) => records.has(p)),
    'unregistered_historical_source'
  )
  const bindings = new Set()
  for (const entry of inventory.buildInputs) {
    requireThat(!bindings.has(entry.path), 'duplicate_build_input')
    bindings.add(entry.path)
    requireThat(
      /^[a-f0-9]{64}$/.test(entry.sha256) &&
        sha(fs.readFileSync(file(root, entry.path))) === entry.sha256,
      'build_input_changed'
    )
  }
  for (const required of [
    'package.json',
    'tsconfig.json',
    'tsconfig.typecheck.json',
    'tsconfig.base.json',
    'scripts/build-runtime.mjs',
    'scripts/build-public-workspace.mjs'
  ])
    requireThat(bindings.has(required), 'missing_build_input')
  const alerts = new Set()
  for (const alert of inventory.historicalFindings) {
    requireThat(
      records.get(alert.path) === alert.sha256 &&
        typeof alert.ruleId === 'string' &&
        alert.region?.startLine > 0,
      'unbound_historical_alert'
    )
    const identity = JSON.stringify([alert.path, alert.ruleId, alert.region])
    requireThat(!alerts.has(identity), 'duplicate_alert')
    alerts.add(identity)
  }
  requireThat(
    fs.readFileSync(
      path.join(root, '.github/codeql/active-source.yml'),
      'utf8'
    ) ===
      'name: cvg-active-source-synthetic\npaths-ignore:\n  - docs/04_audit/evidence/**\n',
    'active_scope_changed'
  )
  return {
    status: 'PASS_FINITE_HISTORICAL_INVENTORY',
    historicalFiles: records.size,
    historicalAlerts: alerts.size,
    uniqueAlertFiles: new Set(inventory.historicalFindings.map((a) => a.path))
      .size,
    buildInputCount: bindings.size,
    independentReview: 'REQUIRED',
    executionClosure: 'REQUIRES_COMPILED_ARTIFACT_PROOF',
    rulesDisabled: false
  }
}
if (
  process.argv[1] &&
  fileURLToPath(import.meta.url) === path.resolve(process.argv[1])
) {
  try {
    const [
      root = '.',
      manifest = 'config/codeql-historical-source-inventory.json'
    ] = process.argv.slice(2)
    console.log(
      JSON.stringify(
        validateHistoricalSourceInventory(
          root,
          JSON.parse(fs.readFileSync(manifest, 'utf8'))
        )
      )
    )
  } catch {
    console.error('Historical source guard failed closed')
    process.exitCode = 1
  }
}
