import fs from 'node:fs'
import { Client } from 'pg'
import { requireThat } from './hiso-contract.mjs'
requireThat(process.env.TEST_DATABASE_URL, 'pg16_required')
const client = new Client({
  connectionString: process.env.TEST_DATABASE_URL,
  connectionTimeoutMillis: 10000,
  query_timeout: 10000
})
try {
  await client.connect()
  const result = await client.query('SHOW server_version_num')
  const version = Number(result.rows[0].server_version_num)
  requireThat(
    Number.isSafeInteger(version) && version >= 160000 && version < 170000,
    'pg16_version_required'
  )
  const candidateId =
    process.env.CI_CANDIDATE_ID ??
    JSON.parse(
      fs.readFileSync(
        process.env.CI_ARTIFACT_DIR + '/ci-bar-state.json',
        'utf8'
      )
    ).candidateId
  const report = {
    schemaVersion: 1,
    status: 'PASS',
    version,
    runId: process.env.CI_RUN_ID,
    candidateId,
    synthetic: true,
    command: 'SHOW server_version_num'
  }
  fs.writeFileSync(
    process.env.HISO_PG_VERSION_OUTPUT ?? 'postgres-version.json',
    JSON.stringify(report, null, 2) + '\n'
  )
  console.log(JSON.stringify(report))
} finally {
  await client.end()
}
