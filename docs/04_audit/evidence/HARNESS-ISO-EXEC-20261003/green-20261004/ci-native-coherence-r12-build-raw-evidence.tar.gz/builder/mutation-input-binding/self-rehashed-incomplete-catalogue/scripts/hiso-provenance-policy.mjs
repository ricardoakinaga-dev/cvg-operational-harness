import fs from 'node:fs'
import path from 'node:path'
import { contract, requireThat, sha } from './hiso-contract.mjs'
const out = path.resolve(process.argv[2])
fs.mkdirSync(out, { recursive: true })
let report
try {
  requireThat(
    process.env.GITHUB_ACTIONS === 'true',
    'remote_policy_context_required'
  )
  const needs = JSON.parse(process.env.HISO_NEEDS_JSON ?? 'null')
  for (const id of [
    'attest',
    'provenance-verify',
    ...contract.scopes.map((s) => s.id)
  ])
    requireThat(
      needs?.[id]?.result === 'success',
      `trusted_follow_up_required_or_job_failed:${id}`
    )
  report = {
    schemaVersion: 1,
    id: 'provenance-policy',
    status: 'PASS',
    sourceSha: process.env.GITHUB_SHA,
    runId: `run-${process.env.GITHUB_RUN_ID}-${process.env.GITHUB_RUN_ATTEMPT}`,
    attempt: process.env.GITHUB_RUN_ATTEMPT,
    needs
  }
} catch (e) {
  report = {
    schemaVersion: 1,
    id: 'provenance-policy',
    status: 'FAIL',
    cause: e.message
  }
  process.exitCode = 1
}
const bytes = JSON.stringify(report, null, 2) + '\n'
fs.writeFileSync(path.join(out, 'policy.json'), bytes)
if (process.env.GITHUB_OUTPUT)
  fs.appendFileSync(process.env.GITHUB_OUTPUT, `policy_sha256=${sha(bytes)}\n`)
