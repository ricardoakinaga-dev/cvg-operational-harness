import { spawnSync } from 'node:child_process'
for (const target of ['packages/model-gateway', 'packages/harness']) {
  const r = spawnSync(
    process.execPath,
    ['scripts/build-public-workspace.mjs', target],
    { stdio: 'inherit' }
  )
  if (r.status !== 0) process.exit(r.status ?? 1)
}
