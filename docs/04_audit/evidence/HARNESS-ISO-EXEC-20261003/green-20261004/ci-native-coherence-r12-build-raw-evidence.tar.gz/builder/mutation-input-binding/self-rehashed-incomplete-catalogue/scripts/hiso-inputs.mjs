#!/usr/bin/env node
import fs from 'node:fs'
import path from 'node:path'
import {
  contract,
  contractHash,
  digest,
  sourceFiles,
  validateContract,
  VERSION,
  sha
} from './hiso-contract.mjs'
import {
  collectTestInventory,
  approvedCoverageInventory,
  coverageSourceInventory
} from './hiso-inventory.mjs'
import { ownerMapping, prepareVariant } from './hiso-variant.mjs'
import { sanitizedEnv } from './hiso-ci.mjs'

const source = process.cwd(),
  output = path.resolve(process.argv[2])
fs.mkdirSync(output, { recursive: true })
try {
  validateContract(source)
  const inputs = sourceFiles(source),
    candidateId = digest(inputs),
    mapping = ownerMapping(inputs)
  const inventory = collectTestInventory(
    source,
    output,
    sanitizedEnv(
      process.env,
      process.env.TMPDIR ?? output,
      process.env.npm_config_cache ?? path.join(output, 'npm-cache')
    )
  )
  const expected = {
    schemaVersion: 1,
    contract: VERSION,
    contractHash,
    candidateId,
    sourceSha256: candidateId,
    ownerMappingHash: digest(mapping),
    runId: `run-${process.env.GITHUB_RUN_ID}-${process.env.GITHUB_RUN_ATTEMPT}`,
    attempt: process.env.GITHUB_RUN_ATTEMPT ?? '1',
    sha: process.env.GITHUB_SHA ?? null,
    startedAt: new Date().toISOString(),
    coveragePaths: approvedCoverageInventory(source, inputs),
    coverageSources: coverageSourceInventory(source, inputs),
    scopes: {},
    testInventory: inventory,
    ownerMapping: mapping
  }
  for (const scope of contract.scopes) {
    const v = prepareVariant(source, path.join(output, scope.id), scope.id)
    const required = inventory.filter(
      (t) =>
        scope.id === 'transition-regression' ||
        mapping.find((f) => f.path === t.file)?.owner === scope.id
    )
    expected.scopes[scope.id] = {
      schemaVersion: 1,
      contract: VERSION,
      contractHash,
      scope: scope.id,
      candidateId,
      sourceSha256: candidateId,
      runId: expected.runId,
      attempt: expected.attempt,
      derivedVariantId: v.derivedVariantId,
      derivedMappingHash: v.derivedMappingHash,
      ownerMappingHash: expected.ownerMappingHash,
      testInventoryHash: digest(inventory),
      requiredTestIds: required.map((t) => t.id),
      lockSha256: v.lockAfter,
      coveragePaths: expected.coveragePaths,
      coverageSources: expected.coverageSources
    }
  }
  fs.writeFileSync(
    path.join(output, 'expected.json'),
    JSON.stringify(expected, null, 2) + '\n'
  )
  if (process.env.GITHUB_OUTPUT)
    fs.appendFileSync(
      process.env.GITHUB_OUTPUT,
      `expected_sha256=${sha(fs.readFileSync(path.join(output, 'expected.json')))}\n`
    )
  console.log(
    JSON.stringify({
      candidateId,
      ownerMappingHash: expected.ownerMappingHash,
      testCount: inventory.length
    })
  )
} catch (e) {
  fs.writeFileSync(path.join(output, 'freeze-failure.log'), e.stack + '\n')
  fs.writeFileSync(
    path.join(output, 'freeze-manifest.json'),
    JSON.stringify(
      {
        schemaVersion: 1,
        status: 'FAIL',
        contract: VERSION,
        contractHash,
        cause: e.message,
        versions: { node: process.versions.node },
        runId: process.env.GITHUB_RUN_ID ?? null,
        attempt: process.env.GITHUB_RUN_ATTEMPT ?? null,
        testInventoryStatus: 'NOT_RUN',
        remoteCiPass: false
      },
      null,
      2
    ) + '\n'
  )
  console.error(e.message)
  process.exitCode = 1
}
