import {
  contract,
  contractHash,
  dispatch,
  exact,
  requireThat,
  safePath,
  VERSION
} from './hiso-contract.mjs'
import { envelope } from './hiso-reports.mjs'
import { CI_BAR_VERSION } from './ci-bar-contract.mjs'

export const record = (v, label) =>
  requireThat(v && typeof v === 'object' && !Array.isArray(v), `type:${label}`)
const text = (v, label) =>
  requireThat(typeof v === 'string' && v.length > 0, `type:${label}`)
const hash = (v, label) =>
  requireThat(
    typeof v === 'string' && /^[a-f0-9]{64}$/.test(v),
    `type:${label}`
  )
const count = (v, label) =>
  requireThat(Number.isSafeInteger(v) && v >= 0, `type:${label}`)
const date = (v, label) =>
  requireThat(
    typeof v === 'string' && Number.isFinite(Date.parse(v)),
    `type:${label}`
  )
const list = (v, label) => requireThat(Array.isArray(v), `type:${label}`)
const scopeIds = contract.scopes.map((s) => s.id)

function binding(value, label) {
  envelope(value, label)
  dispatch(value.contract)
  requireThat(
    value.contract === VERSION && value.contractHash === contractHash,
    `contract_hash:${label}`
  )
  for (const key of ['candidateId', 'sourceSha256', 'ownerMappingHash'])
    hash(value[key], `${label}:${key}`)
  text(value.runId, `${label}:runId`)
  requireThat(
    typeof value.attempt === 'string' && /^[1-9][0-9]*$/.test(value.attempt),
    `type:${label}:attempt`
  )
}
function scopeBinding(value, label) {
  binding(value, label)
  requireThat(scopeIds.includes(value.scope), `unknown_scope:${value.scope}`)
  for (const key of [
    'derivedVariantId',
    'derivedMappingHash',
    'lockSha256',
    'testInventoryHash'
  ])
    hash(value[key], `${label}:${key}`)
}
function outputs(value, label) {
  list(value, label)
  for (const f of value) {
    record(f, label)
    safePath(f.path)
    hash(f.sha256, `${label}:sha256`)
    count(f.size, `${label}:size`)
  }
}
function inventory(value, label) {
  list(value, label)
  for (const t of value) {
    record(t, label)
    safePath(t.file)
    text(t.name, `${label}:name`)
    requireThat(
      Number.isSafeInteger(t.occurrence) && t.occurrence > 0,
      `type:${label}:occurrence`
    )
    hash(t.id, `${label}:id`)
    if (Object.hasOwn(t, 'status'))
      requireThat(
        ['passed', 'pending', 'skipped', 'todo'].includes(t.status),
        `type:${label}:status`
      )
  }
}
function coverageSources(value, label) {
  list(value.coveragePaths, `${label}:coveragePaths`)
  value.coveragePaths.forEach(safePath)
  list(value.coverageSources, `${label}:coverageSources`)
  for (const s of value.coverageSources) {
    record(s, `${label}:coverageSource`)
    safePath(s.path)
    hash(s.sha256, `${label}:coverageSource:sha256`)
    requireThat(
      typeof s.executable === 'boolean',
      `type:${label}:coverageSource:executable`
    )
  }
  exact(
    value.coverageSources.map((s) => s.path),
    value.coveragePaths,
    `${label}:coverage_sources`
  )
}
export function expectedShape(expected) {
  binding(expected, 'expected')
  requireThat(
    typeof expected.sha === 'string' && /^[a-f0-9]{40}$/.test(expected.sha),
    'type:expected:sha'
  )
  date(expected.startedAt, 'expected:startedAt')
  record(expected.scopes, 'expected:scopes')
  exact(Object.keys(expected.scopes), scopeIds, 'expected_scope_inventory')
  inventory(expected.testInventory, 'expected:testInventory')
  coverageSources(expected, 'expected')
  for (const id of scopeIds) {
    const s = expected.scopes[id]
    scopeBinding(s, 'expected-scope')
    requireThat(s.scope === id, 'expected_scope_binding')
    list(s.requiredTestIds, 'expected-scope:requiredTestIds')
    s.requiredTestIds.forEach((v) => hash(v, 'expected-scope:requiredTestId'))
    coverageSources(s, 'expected-scope')
  }
}
export function manifestShape(m) {
  scopeBinding(m, 'manifest')
  if (Object.hasOwn(m, 'legacy')) {
    record(m.legacy, 'manifest:legacy')
    dispatch(m.legacy.contract)
    requireThat(m.legacy.contract === CI_BAR_VERSION, 'legacy_contract')
    hash(m.legacy.manifestSha256, 'manifest:legacy:manifestSha256')
    hash(m.legacy.candidateId, 'manifest:legacy:candidateId')
    text(m.legacy.runId, 'manifest:legacy:runId')
    count(m.legacy.verifiedGateCount, 'manifest:legacy:verifiedGateCount')
  }
  for (const key of [
    'sourceAfterSha256',
    'variantSourceAfterSha256',
    'executedTestInventoryHash'
  ])
    hash(m[key], `manifest:${key}`)
  requireThat(
    m.sourceMatch === true && m.variantSourceMatch === true,
    'type:manifest:sourceMatch'
  )
  date(m.startedAt, 'manifest:startedAt')
  date(m.finishedAt, 'manifest:finishedAt')
  text(m.owner, 'manifest:owner')
  requireThat(
    m.status === 'PASS' &&
      ['LOCAL_CONTENT_HASHES', 'GITHUB_JOB_OUTPUT_BOUND'].includes(m.mode),
    'type:manifest:status_mode'
  )
  record(m.versions, 'manifest:versions')
  text(m.versions.node, 'manifest:versions:node')
  inventory(m.testInventory, 'manifest:testInventory')
  inventory(m.executedTestInventory, 'manifest:executedTestInventory')
  outputs(m.outputs, 'manifest:outputs')
  list(m.gates, 'manifest:gates')
  list(m.seals, 'manifest:seals')
  for (const g of m.gates) {
    envelope(g, 'gate')
    for (const key of ['id', 'scope', 'runId']) text(g[key], `gate:${key}`)
    hash(g.candidateId, 'gate:candidateId')
    hash(g.logSha256, 'gate:logSha256')
    date(g.startedAt, 'gate:startedAt')
    date(g.finishedAt, 'gate:finishedAt')
    count(g.skipped, 'gate:skipped')
    requireThat(
      g.exitCode === 0 && g.status === 'PASS' && g.cause === null,
      'type:gate:result'
    )
    if (g.command !== null) {
      requireThat(
        Array.isArray(g.command) &&
          g.command.length === 2 &&
          typeof g.command[0] === 'string' &&
          Array.isArray(g.command[1]) &&
          g.command[1].every((v) => typeof v === 'string'),
        'type:gate:command'
      )
    }
    outputs(g.outputs, 'gate:outputs')
  }
  for (const s of m.seals) {
    binding(s, 'seal')
    for (const key of ['derivedVariantId', 'derivedMappingHash', 'entrySha256'])
      hash(s[key], `seal:${key}`)
    requireThat(s.kind === 'hiso-gate-content-seal-v1', 'type:seal:kind')
    text(s.gateId, 'seal:gateId')
  }
}
export function producerShape(p) {
  envelope(p, 'producer')
  requireThat(p.result === 'success', 'type:producer:result')
  requireThat(
    (typeof p.artifactId === 'string' && /^[1-9][0-9]*$/.test(p.artifactId)) ||
      (Number.isSafeInteger(p.artifactId) && p.artifactId > 0),
    'type:producer:artifactId'
  )
  requireThat(
    typeof p.artifactDigest === 'string' &&
      /^(sha256:)?[a-f0-9]{64}$/.test(p.artifactDigest),
    'type:producer:artifactDigest'
  )
  hash(p.manifestSha256, 'producer:manifestSha256')
  hash(p.sealSetSha256, 'producer:sealSetSha256')
}
