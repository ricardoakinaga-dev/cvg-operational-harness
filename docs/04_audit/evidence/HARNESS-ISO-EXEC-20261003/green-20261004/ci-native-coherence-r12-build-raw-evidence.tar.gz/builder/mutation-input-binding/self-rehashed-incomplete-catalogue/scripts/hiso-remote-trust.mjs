import fs from 'node:fs'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import {
  contract,
  digest,
  exact,
  requireThat,
  sha,
  sourceFiles,
  canonical
} from './hiso-contract.mjs'
import { coverageSourceInventory } from './hiso-inventory.mjs'
import { envelope } from './hiso-reports.mjs'
import { collectSecurity } from './hiso-security.mjs'
import { preflightRemoteEvidence } from './hiso-verifier.mjs'

// The marker cannot be deserialized from a builder-supplied JSON trust claim.
const verified = new WeakSet()
export const isRemoteTrust = (value) => verified.has(value)
export function artifactDigest(value) {
  requireThat(
    typeof value === 'string' && /^(sha256:)?[a-f0-9]{64}$/.test(value),
    'immutable_artifact_digest_format'
  )
  return value.startsWith('sha256:') ? value : `sha256:${value}`
}
export function verifyImmutableArtifact(artifact, expected) {
  requireThat(
    artifact &&
      artifact.name === expected.name &&
      !artifact.expired &&
      Number.isSafeInteger(artifact.id) &&
      artifact.id > 0 &&
      String(artifact.id) === String(expected.id) &&
      /^sha256:[a-f0-9]{64}$/.test(artifact.digest) &&
      artifact.digest === artifactDigest(expected.digest) &&
      artifact.workflow_run?.head_sha === expected.sourceSha &&
      Date.parse(artifact.created_at) >= Date.parse(expected.startedAt),
    'external_immutable_artifact'
  )
  return true
}

export function verifyAttestationStatements(
  results,
  { subjectSha256, repository, sourceSha, runId, attempt }
) {
  requireThat(Array.isArray(results) && results.length > 0, 'attestation_empty')
  const invocation = `https://github.com/${repository}/actions/runs/${runId}/attempts/${attempt}`
  const signer = `https://github.com/${repository}/.github/workflows/harness-isolation.yml@`
  const statements = results.map((r) => r.verificationResult?.statement)
  requireThat(
    statements.every(Boolean),
    'attestation_verified_statement_required'
  )
  requireThat(
    statements.some(
      (s) =>
        s._type === 'https://in-toto.io/Statement/v1' &&
        s.predicateType === 'https://slsa.dev/provenance/v1' &&
        s.subject?.some(
          (v) =>
            v.name === 'manifest.json' && v.digest?.sha256 === subjectSha256
        ) &&
        s.predicate?.runDetails?.builder?.id?.startsWith(signer) &&
        s.predicate?.runDetails?.metadata?.invocationId === invocation &&
        s.predicate?.buildDefinition?.externalParameters?.workflow?.path ===
          '.github/workflows/harness-isolation.yml' &&
        s.predicate?.buildDefinition?.externalParameters?.workflow
          ?.repository === `https://github.com/${repository}` &&
        s.predicate?.buildDefinition?.resolvedDependencies?.some(
          (d) =>
            d.digest?.gitCommit === sourceSha &&
            d.uri?.startsWith(`git+https://github.com/${repository}@`)
        )
    ),
    'attestation_subject_signer_source_run'
  )
  return true
}

export async function collectRemoteTrust({
  scopes,
  expected,
  producerResults,
  security,
  provenance,
  expectedFile,
  output
}) {
  preflightRemoteEvidence({
    scopes,
    expected,
    producerResults,
    security,
    provenance
  })
  const env = process.env
  requireThat(
    env.GITHUB_ACTIONS === 'true' &&
      env.GH_TOKEN &&
      env.GITHUB_REPOSITORY &&
      env.GITHUB_JOB === 'aggregate',
    'external_auth_required'
  )
  requireThat(
    expected.sha === env.GITHUB_SHA &&
      expected.runId === `run-${env.GITHUB_RUN_ID}-${env.GITHUB_RUN_ATTEMPT}` &&
      expected.attempt === env.GITHUB_RUN_ATTEMPT,
    'external_context_binding'
  )
  exact(
    Object.keys(producerResults ?? {}),
    contract.scopes.map((s) => s.id),
    'producer_inventory'
  )
  const source = path.resolve(import.meta.dirname, '..')
  const inputs = sourceFiles(source)
  requireThat(
    digest(inputs) === expected.sourceSha256 &&
      expected.candidateId === expected.sourceSha256,
    'external_frozen_source'
  )
  requireThat(
    canonical(coverageSourceInventory(source, inputs)) ===
      canonical(expected.coverageSources),
    'external_canonical_coverage_sources'
  )
  const needs = JSON.parse(env.HISO_NEEDS_JSON ?? 'null')
  requireThat(
    needs?.inputs?.result === 'success' &&
      sha(fs.readFileSync(expectedFile)) ===
        needs.inputs.outputs.expected_sha256,
    'external_expected_input_binding'
  )
  fs.mkdirSync(output, { recursive: true })
  const api = async (fragment) => {
    const response = await fetch(
      `https://api.github.com/repos/${env.GITHUB_REPOSITORY}${fragment}`,
      {
        headers: {
          Authorization: `Bearer ${env.GH_TOKEN}`,
          Accept: 'application/vnd.github+json',
          'X-GitHub-Api-Version': '2022-11-28'
        },
        signal: AbortSignal.timeout(30000)
      }
    )
    requireThat(response.ok, `external_api_status:${response.status}`)
    return response.json()
  }
  const current = await api(
    `/actions/runs/${env.GITHUB_RUN_ID}/attempts/${env.GITHUB_RUN_ATTEMPT}`
  )
  requireThat(
    current.head_sha === expected.sha &&
      current.path === '.github/workflows/harness-isolation.yml' &&
      String(current.run_attempt) === expected.attempt,
    'external_workflow_source'
  )
  const jobs = await api(
    `/actions/runs/${env.GITHUB_RUN_ID}/attempts/${env.GITHUB_RUN_ATTEMPT}/jobs?per_page=100`
  )
  requireThat(jobs.total_count === jobs.jobs.length, 'external_jobs_pagination')
  for (const name of [
    'inputs',
    'attest',
    'provenance-verify',
    'provenance-policy',
    'security-status'
  ]) {
    const selected = jobs.jobs.filter((j) => j.name === name)
    requireThat(
      selected.length === 1 &&
        selected[0].status === 'completed' &&
        selected[0].conclusion === 'success',
      `external_global_job:${name}`
    )
  }
  const artifacts = await api(
    `/actions/runs/${env.GITHUB_RUN_ID}/artifacts?per_page=100`
  )
  requireThat(
    artifacts.total_count === artifacts.artifacts.length,
    'external_artifacts_pagination'
  )
  const inputArtifacts = artifacts.artifacts.filter(
    (a) =>
      a.name === `hiso-inputs-${env.GITHUB_RUN_ID}-${env.GITHUB_RUN_ATTEMPT}`
  )
  requireThat(
    inputArtifacts.length === 1 &&
      !inputArtifacts[0].expired &&
      Number.isSafeInteger(inputArtifacts[0].id) &&
      inputArtifacts[0].id > 0 &&
      String(inputArtifacts[0].id) ===
        String(needs.inputs.outputs.artifact_id) &&
      /^sha256:[a-f0-9]{64}$/.test(inputArtifacts[0].digest) &&
      inputArtifacts[0].digest ===
        artifactDigest(needs.inputs.outputs.artifact_digest) &&
      inputArtifacts[0].workflow_run?.head_sha === expected.sha,
    'external_immutable_inputs'
  )
  for (const scope of scopes) {
    const id = scope.manifest.scope,
      producer = envelope(producerResults[id], 'producer')
    const jobName =
      id === 'transition-regression'
        ? 'Full unchanged REM21 transition regression'
        : id
    const job = jobs.jobs.filter((j) => j.name === jobName)
    requireThat(
      job.length === 1 &&
        job[0].status === 'completed' &&
        job[0].conclusion === 'success',
      'external_producer_job'
    )
    const name = `hiso-${id}-${env.GITHUB_RUN_ID}-${env.GITHUB_RUN_ATTEMPT}`
    const artifact = artifacts.artifacts.filter((a) => a.name === name)
    requireThat(artifact.length === 1, 'external_immutable_artifact')
    verifyImmutableArtifact(artifact[0], {
      name,
      id: producer.artifactId,
      digest: producer.artifactDigest,
      sourceSha: expected.sha,
      startedAt: current.run_started_at
    })
    // Check the immutable archive itself, then compare it to the extracted namespace.
    const archive = await fetch(
      `https://api.github.com/repos/${env.GITHUB_REPOSITORY}/actions/artifacts/${artifact[0].id}/zip`,
      {
        headers: {
          Authorization: `Bearer ${env.GH_TOKEN}`,
          Accept: 'application/vnd.github+json'
        },
        signal: AbortSignal.timeout(30000)
      }
    )
    requireThat(archive.ok, 'external_archive_status')
    const bytes = Buffer.from(await archive.arrayBuffer())
    requireThat(
      `sha256:${sha(bytes)}` === artifact[0].digest,
      'external_archive_digest'
    )
    const archiveFile = path.join(output, id + '.zip')
    fs.writeFileSync(archiveFile, bytes)
    const listing = spawnSync('unzip', ['-Z1', archiveFile], {
      encoding: 'utf8',
      timeout: 30000
    })
    requireThat(listing.status === 0, 'external_archive_inventory')
    const archivePaths = listing.stdout
      .trim()
      .split('\n')
      .filter((p) => !p.endsWith('/'))
    const expectedFiles = [
      ...scope.manifest.outputs,
      { path: 'manifest.json', sha256: producer.manifestSha256 }
    ]
    exact(
      archivePaths,
      expectedFiles.map((f) => f.path),
      'external_archive_exact_files'
    )
    for (const f of expectedFiles) {
      const r = spawnSync('unzip', ['-p', archiveFile, f.path], {
        timeout: 30000,
        maxBuffer: 128 * 1024 * 1024
      })
      requireThat(
        r.status === 0 && sha(r.stdout) === f.sha256,
        'external_extracted_bytes'
      )
    }
    const subject = path.join(scope.directory, 'manifest.json')
    requireThat(
      sha(fs.readFileSync(subject)) === producer.manifestSha256 &&
        digest(scope.manifest.seals) === producer.sealSetSha256,
      'external_subject_binding'
    )
    const r = spawnSync(
      'gh',
      [
        'attestation',
        'verify',
        subject,
        '--repo',
        env.GITHUB_REPOSITORY,
        '--signer-workflow',
        `${env.GITHUB_REPOSITORY}/.github/workflows/harness-isolation.yml`,
        '--source-digest',
        expected.sha,
        '--deny-self-hosted-runners',
        '--format',
        'json'
      ],
      { encoding: 'utf8', timeout: 120000, maxBuffer: 16 * 1024 * 1024 }
    )
    fs.writeFileSync(
      path.join(output, id + '-attestation.json'),
      r.stdout ?? ''
    )
    fs.writeFileSync(path.join(output, id + '-attestation.log'), r.stderr ?? '')
    requireThat(r.status === 0, 'external_attestation_verification')
    verifyAttestationStatements(JSON.parse(r.stdout), {
      subjectSha256: producer.manifestSha256,
      repository: env.GITHUB_REPOSITORY,
      sourceSha: expected.sha,
      runId: env.GITHUB_RUN_ID,
      attempt: expected.attempt
    })
  }
  const freshSecurity = await collectSecurity({
    api,
    currentRun: env.GITHUB_RUN_ID,
    sha: expected.sha
  })
  const comparable = (r) => ({
    schemaVersion: r.schemaVersion,
    status: r.status,
    workflow: r.workflow,
    workflowId: r.workflowId,
    sha: r.sha,
    runId: r.runId,
    attempt: r.attempt,
    jobs: r.jobs,
    currentRun: r.currentRun
  })
  requireThat(
    digest(comparable(freshSecurity)) === digest(comparable(security)),
    'external_security_binding'
  )
  const trust = {
    producers: structuredClone(producerResults),
    security: structuredClone(security),
    provenance: structuredClone(provenance),
    sourceSha: expected.sha,
    runId: expected.runId,
    attempt: expected.attempt
  }
  const freeze = (value) => {
    if (value && typeof value === 'object') {
      Object.values(value).forEach(freeze)
      Object.freeze(value)
    }
  }
  freeze(trust)
  verified.add(trust)
  return trust
}
