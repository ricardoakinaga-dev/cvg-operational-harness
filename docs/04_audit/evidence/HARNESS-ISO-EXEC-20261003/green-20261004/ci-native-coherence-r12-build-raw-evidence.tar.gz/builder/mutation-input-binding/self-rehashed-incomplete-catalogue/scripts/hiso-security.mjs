#!/usr/bin/env node
import fs from 'node:fs'
import { contract, requireThat } from './hiso-contract.mjs'

// Called only by an authorized GitHub runner. Never synthesize scanner success
// from npm audit, local files or GITHUB_ACTIONS environment alone.
export async function collectSecurity({
  api,
  currentRun,
  sha,
  deadlineMs = contract.security.timeoutMs,
  delay = (ms) => new Promise((r) => setTimeout(r, ms))
}) {
  const started = Date.now()
  const current = await api(`/actions/runs/${currentRun}`)
  requireThat(current.head_sha === sha, 'security_source_context')
  const workflow = await api('/actions/workflows/security.yml')
  requireThat(
    workflow.path === contract.security.workflow,
    'security_workflow_identity'
  )
  const epoch = Date.parse(current.run_started_at)
  for (;;) {
    const runs = await api(
      `/actions/workflows/${workflow.id}/runs?head_sha=${sha}&per_page=100`
    )
    const matching = runs.workflow_runs.filter(
      (r) =>
        r.head_sha === sha &&
        r.workflow_id === workflow.id &&
        r.event === current.event &&
        r.head_branch === current.head_branch &&
        Date.parse(r.run_started_at) >= epoch - 5000
    )
    requireThat(matching.length <= 1, 'security_ambiguous_run')
    if (matching.length === 1 && matching[0].status === 'completed') {
      const run = matching[0]
      requireThat(run.conclusion === 'success', 'security_run_failed')
      const response = await api(
        `/actions/runs/${run.id}/attempts/${run.run_attempt}/jobs?per_page=100`
      )
      requireThat(
        response.total_count === response.jobs.length,
        'security_jobs_pagination_incomplete'
      )
      const jobs = response.jobs.map(({ id, name, status, conclusion }) => ({
        id,
        name,
        status,
        conclusion
      }))
      requireThat(
        jobs.length === contract.security.requiredJobs.length &&
          contract.security.requiredJobs.every(
            (name) =>
              jobs.filter(
                (j) =>
                  j.name === name &&
                  j.status === 'completed' &&
                  j.conclusion === 'success'
              ).length === 1
          ),
        'security_scanner_missing_or_failed'
      )
      return {
        schemaVersion: 1,
        status: 'PASS',
        workflow: workflow.path,
        workflowId: workflow.id,
        sha,
        runId: run.id,
        attempt: run.run_attempt,
        jobs,
        collectedAt: new Date().toISOString(),
        currentRun
      }
    }
    requireThat(Date.now() - started < deadlineMs, 'security_timeout')
    await delay(
      Math.min(10000, Math.max(1, deadlineMs - (Date.now() - started)))
    )
  }
}
if (process.argv[1]?.endsWith('/hiso-security.mjs')) {
  const output = process.argv[2]
  try {
    requireThat(
      process.env.GITHUB_ACTIONS === 'true' && process.env.GH_TOKEN && output,
      'remote_security_auth_required'
    )
    const api = async (fragment) => {
      const r = await fetch(
        `https://api.github.com/repos/${process.env.GITHUB_REPOSITORY}${fragment}`,
        {
          headers: {
            Authorization: `Bearer ${process.env.GH_TOKEN}`,
            Accept: 'application/vnd.github+json',
            'X-GitHub-Api-Version': '2022-11-28'
          },
          signal: AbortSignal.timeout(30000)
        }
      )
      requireThat(r.ok, `security_api_status:${r.status}`)
      return r.json()
    }
    const result = await collectSecurity({
      api,
      currentRun: process.env.GITHUB_RUN_ID,
      sha: process.env.GITHUB_SHA
    })
    fs.writeFileSync(output, JSON.stringify(result, null, 2) + '\n')
    if (process.env.GITHUB_OUTPUT)
      fs.appendFileSync(
        process.env.GITHUB_OUTPUT,
        `security_run_id=${result.runId}\nsecurity_attempt=${result.attempt}\n`
      )
  } catch (e) {
    if (output)
      fs.writeFileSync(
        output,
        JSON.stringify(
          {
            schemaVersion: 1,
            status:
              /security_run_failed|security_scanner_missing_or_failed/.test(
                e.message
              )
                ? 'FAIL'
                : 'NOT_RUN',
            cause: e.message,
            collectedAt: new Date().toISOString()
          },
          null,
          2
        ) + '\n'
      )
    console.error(e.message)
    process.exitCode = 1
  }
}
