from pathlib import Path
import os,json,hashlib,difflib,shutil,subprocess,re
base=Path('/home/ricardo/.cache/cvg-harness-green-20261004');out=base/'ci-native-coherence-r12-builder';candidate=base/'ci-native-admission-r11-candidate';source=base/'ci-importer-counter-review-r10/source';r11=base/'ci-native-admission-r11-builder';read=lambda p:json.loads((out/p).read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
# Save all real output first, then restore only own generated runtime artifacts to
# the immutable R11 state; source files and the original source are never restored.
assert (out/'proofs/mutation-native-receipt.json').exists()
originalReceipt=source/'certification/mutation-guard.json'
if originalReceipt.exists():shutil.copy2(originalReceipt,candidate/'certification/mutation-guard.json')
else:(candidate/'certification/mutation-guard.json').unlink(missing_ok=True)
for name in ['.r12-tmp','.vite','.vite-temp']:
 p=candidate/'node_modules'/name
 if p.exists():
  saved=out/('retained-'+name.strip('.'))
  if not saved.exists():shutil.move(str(p),str(saved))
  else:shutil.rmtree(p)
 if (source/'node_modules'/name).exists():shutil.copytree(source/'node_modules'/name,p,symlinks=True)
shutil.copystat(source/'node_modules',candidate/'node_modules')
def scan(root):
 rows={};metadata={};external=[];hard=[]
 for directory,dirs,files in os.walk(root,followlinks=False):
  for name in dirs+files:
   p=Path(directory)/name;rel=str(p.relative_to(root));s=p.lstat();kind='link' if p.is_symlink() else 'directory' if p.is_dir() else 'file';metadata[rel]={'kind':kind,'mode':s.st_mode,'size':s.st_size,'mtimeNs':s.st_mtime_ns}
   if kind=='file':
    rows[rel]={'kind':'file','bytes':s.st_size,'sha256':sha(p.read_bytes())}
    if s.st_nlink!=1:hard.append(rel)
   elif kind=='link':
    rows[rel]={'kind':'link','target':os.readlink(p)}
    if not p.resolve().is_relative_to(root):external.append(rel)
 return {'rows':dict(sorted(rows.items())),'metadata':dict(sorted(metadata.items())),'externalLinks':external,'hardlinks':hard}
s=scan(source);c=scan(candidate);s11=read('before/r11-source-after-full.json');c11=read('before/r11-candidate-after-full.json');assert s['rows']==s11['rows'] and s['metadata']==s11['metadata'];assert not c['externalLinks'] and not c['hardlinks']
freeze=json.loads((base/'ci-importer-counter-review-r10/frozen-inventory.json').read_text());assert s['rows']==freeze
cumulative=[p for p in sorted(set(s['rows'])|set(c['rows'])) if s['rows'].get(p)!=c['rows'].get(p)];incremental=[p for p in sorted(set(c11['rows'])|set(c['rows'])) if c11['rows'].get(p)!=c['rows'].get(p)]
expected={'scripts/hiso-import-legacy.mjs','scripts/hiso-snapshot-types.mjs','scripts/lib/coverage-gate.mjs','scripts/mutation-manifest.json','tests/hiso-ci-scopes.test.js','tests/hiso-snapshot-membership-own.test.js'};assert set(cumulative)==expected;assert set(incremental)==expected-{'scripts/lib/coverage-gate.mjs'}
rows=[{'path':p,'SourceSHA':s['rows'][p]['sha256'],'R11SHA':c11['rows'][p]['sha256'],'currentSHA':c['rows'][p]['sha256'],'SourceBytes':s['rows'][p]['bytes'],'currentBytes':c['rows'][p]['bytes']} for p in cumulative]
# Patch source is the original sealed Source, with a separate R11-relative patch.
patch=''.join(''.join(difflib.unified_diff((source/p).read_text().splitlines(True),(candidate/p).read_text().splitlines(True),fromfile='a/'+p,tofile='b/'+p)) for p in cumulative);(out/'build.patch').write_text(patch)
verify=out/'patch-source';verify.mkdir()
for p in cumulative:
 q=verify/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/p,q)
r=subprocess.run(['patch','--dry-run','-p1','-i',str(out/'build.patch')],cwd=verify,text=True,capture_output=True);(out/'logs/patch-source-dry-run.stdout.log').write_text(r.stdout);assert r.returncode==0
r=subprocess.run(['patch','-p1','-i',str(out/'before/r11-build.patch')],cwd=verify,text=True,capture_output=True);assert r.returncode==0
assert all(sha((verify/p).read_bytes())==c11['rows'][p]['sha256'] for p in cumulative)
inc=''.join(''.join(difflib.unified_diff((verify/p).read_text().splitlines(True),(candidate/p).read_text().splitlines(True),fromfile='a/'+p,tofile='b/'+p)) for p in incremental);(out/'build-r12.patch').write_text(inc)
r=subprocess.run(['patch','-p1','-i',str(out/'build-r12.patch')],cwd=verify,text=True,capture_output=True);(out/'logs/patch-r12-apply.stdout.log').write_text(r.stdout);assert r.returncode==0 and all(sha((verify/p).read_bytes())==c['rows'][p]['sha256'] for p in cumulative)
(out/'proofs/patch-application.json').write_text(json.dumps({'SourceDryRun':True,'R11ReconstructedExactly':True,'R12PatchAppliedAndAllCurrentSHAsMatch':True},indent=2))
# Recheck all prior evidence records without touching their bytes or metadata.
preserved=read('proofs/r11-evidence-before.json');differences=[]
for r in preserved:
 p=r11/r['path'];st=p.stat()
 if sha(p.read_bytes())!=r['sha256'] or st.st_size!=r['size'] or st.st_mtime_ns!=r['mtimeNs']:differences.append(r['path'])
assert not differences
integrity={'sourceFreezeSha256':sha((base/'ci-importer-counter-review-r10/frozen-inventory.json').read_bytes()),'SourceAndMetadataUnchanged':True,'R11FrozenBuilderEvidenceUnchanged':True,'R11CheckedArtifacts':len(preserved),'R11Differences':differences,'SourceCompleteCount':len(s['rows']),'candidateCompleteCount':len(c['rows']),'externalLinks':c['externalLinks'],'hardlinks':c['hardlinks'],'incrementalWriteSet':incremental,'cumulativeWriteSet':cumulative,'groups':{}}
for label,data in [('SourceBefore',s11),('SourceAfter',s),('R11CandidateBefore',c11),('R12CandidateAfter',c)]:
 integrity['groups'][label]={}
 for group in ['source','dependencies','dist']:
  rr={p:v for p,v in data['rows'].items() if ('dependencies' if p.startswith('node_modules/') else 'dist' if any(x in ('dist','dist-public','dist-runtime') for x in Path(p).parts) or p.endswith('.tsbuildinfo') else 'source')==group};integrity['groups'][label][group]={'count':len(rr),'sha256':sha(json.dumps(rr,sort_keys=True).encode())}
assert integrity['groups']['R12CandidateAfter']['dependencies']==integrity['groups']['R11CandidateBefore']['dependencies'];assert integrity['groups']['R12CandidateAfter']['dist']==integrity['groups']['R11CandidateBefore']['dist']
(out/'proofs/source-after-full.json').write_text(json.dumps(s,indent=2));(out/'proofs/candidate-after-full.json').write_text(json.dumps(c,indent=2));(out/'proofs/integrity-final.json').write_text(json.dumps(integrity,indent=2))
run=read('proofs/focused469.json');prior=read('before/r11-after469-current.json');beforecases=sorted((Path(f['name']).name,t['fullName']) for f in prior['testResults'] for t in f['assertionResults']);aftercases=sorted((Path(f['name']).name,t['fullName']) for f in run['testResults'] for t in f['assertionResults']);assert beforecases==aftercases and len(aftercases)==469 and run['numPassedTests']==469 and run['numFailedTests']==0 and run['numPendingTests']==0
comparison={'before':{'passed':prior['numPassedTests'],'failed':prior['numFailedTests'],'total':prior['numTotalTests']},'after':{'passed':run['numPassedTests'],'failed':run['numFailedTests'],'total':run['numTotalTests'],'pending':run['numPendingTests']},'namesAndCardinalitiesExact':True,'preserved55Discriminants':sum(n.startswith('R11 ') for _,n in aftercases),'caseRows':aftercases};assert comparison['preserved55Discriminants']==55;(out/'proofs/raw-case-names-counters-comparison.json').write_text(json.dumps(comparison,indent=2))
ast=read('proofs/fixture-assertAST-comparison.json');rebind=read('proofs/rebind-three-source-hashes.json');actual=read('proofs/actual-native-producer-admission.json');kills=read('proofs/mutation-real-child-kills.json');scope=read('proofs/native-scopes.json');guards=[json.loads(l) for l in (out/'proofs/guard-identities.jsonl').read_text().splitlines()];attempts=[json.loads(l) for l in (out/'proofs/network-attempts.jsonl').read_text().splitlines()]
# Explicitly record the authorized prefix deviation, not a false preservation.
prefix=source/'tests/hiso-snapshot-membership-own.test.js';prefixExact=(candidate/'tests/hiso-snapshot-membership-own.test.js').read_bytes().startswith(prefix.read_bytes());assert not prefixExact
status='IMPLEMENTED_NOT_ACCEPTED'
manifest={'schemaVersion':1,'task':'CI_NATIVE_FIXTURE_COHERENCE_R12','status':status,'role':'BUILD, not independent critic','Source':str(source),'candidate':str(candidate),'outputs':str(out),'SourceCandidateId':scope['source']['candidateId'],'R11CandidateId':read('before/r11-build-manifest.json')['currentCandidateId'],'currentCandidateId':scope['candidate']['candidateId'],'writeSet':rows,'incrementalWriteSet':incremental,'patches':{'SourceToCurrent':{'path':'build.patch','sha256':sha((out/'build.patch').read_bytes())},'R11ToCurrent':{'path':'build-r12.patch','sha256':sha((out/'build-r12.patch').read_bytes())}},'fixtureEdits':'Only fixture-generator input data in two already-newTests files; no assertion AST, names/case cardinalities, original negatives or status policy changes. Original unit rows are preserved verbatim, including negative occurrence/id discriminants.','prefix182BYTE_EXACT':{'preserved':False,'deviation':'Explicitly authorized input-only generator repair; assertion AST and original registrations/negatives/counters semantically exact. R11 before/failure records preserved.'},'unitImporterSelection':'Align unit preflight with authoritative transition scope requiredTestIds, as the existing snapshot verifier already does; exact membership check precedes every output. PG/chaos retain frozen-selector full membership and pass-only semantics.','mutationAuthorityRebind':rebind,'nativeCounts':{'Source':scope['source']['nativeCount'],'candidate':scope['candidate']['nativeCount'],'baseline':scope['baselineTestPaths'],'newTestPaths':scope['approvedNewTestPaths'],'coveragePaths':scope['candidate']['coveragePaths'],'addedInputPaths':scope['extra'],'removedInputPaths':scope['missing']},'tests':{'before':'459 PASS / 10 FAIL preserved','after':'469 PASS / 0 FAIL / 0 pending','preserved55NewDiscriminants':55,'types':'PASS','lint':'PASS','WriteSetFormat':'PASS'},'realNativeMutation':{'cli':'node scripts/mutation-guard.mjs','selected':actual['selected'],'killed':actual['killed'],'verdict':actual['verdict'],'survived':actual['survived'],'timedOut':actual['timedOut'],'errors':actual['errors'],'actualReceiptAdmission':True,'receipt':'proofs/mutation-native-receipt.json','proof':'proofs/actual-native-producer-admission.json','physicalDependencyMaterialization':'proofs/mutation-physical-dependencies.jsonl'},'limitations':['No independent acceptance, full/global/production acceptance or Lead-owned C1R13/Main/neutral PG work.','Unmutated mutation-test baseline: 93/94, with one live-loopback test blocked by no-network guard. SSRF mutant separately causes additional assertion failures; no validation/failure mocks or skips added.'],'proofs':['proofs/fixture-assertAST-comparison.json','proofs/raw-case-names-counters-comparison.json','proofs/original371-filehashes.json','proofs/rebind-three-source-hashes.json','proofs/mutation-input-binding.json','proofs/mutation-real-child-kills.json','proofs/integrity-final.json','proofs/patch-application.json'],'RootTouched':False,'subagents':0,'commits':0,'artifactInventory':'artifact-inventory.json'}
(out/'build-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
report={'schemaVersion':1,'status':status,'task':manifest['task'],'role':manifest['role'],'buildManifest':'build-manifest.json','changes':{'fixtures':manifest['fixtureEdits'],'unitSelection':manifest['unitImporterSelection'],'mutationAuthority':'Exactly three authorized sourceSha256 data-field rebinds, all other fields/IDs/operators/testFiles/budgets/domains unchanged. JSON formatting normalized without semantic changes. Hardcoded separate coverage hash exception removed; pinned complete approved authority digest and live source/selector checks retained.','integer95':'R11 BigInt producer and independent admission unchanged; original frozen inclusive selector text and actual mutator kill preserved.'},'beforeAfter':comparison,'fixtureAST':ast,'baseline371':'proofs/original371-filehashes.json','integrity':integrity,'nativeCounts':manifest['nativeCounts'],'realMutation':manifest['realNativeMutation'],'mutationBaselineLimitation':{k:v for k,v in kills.items() if k!='children'},'guard':{'records':len(guards),'allNode22':all(g['node']=='22.23.2' for g in guards),'allESMPgMockBeforeProducerImports':all(g['beforeProducerImport'] and g['pgIdentity']=='CI-R10-INERT-PG' for g in guards),'blockedAttempts':attempts,'nativeNetworkConnectionsExecuted':0},'setupDiagnostics':['Initial fixture repair recomputed original required rows and normalized a forged occurrence; raw 468/469 retained, generator corrected to preserve every original negative input row verbatim.','Native workspace copy into a subdirectory of candidate was refused before any mutant execution; setup receipt retained, native TMPDIR moved into own builder outputs.','Native symlink request for node_modules was physically materialized by a filesystem-only preload; original CLI/driver/test bodies, assertions, selectors and statuses unchanged. All deps remain owned, physical and version unchanged.'],'limitations':manifest['limitations']}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'report.md').write_text('''IMPLEMENTED_NOT_ACCEPTED — BUILD for CI_NATIVE_FIXTURE_COHERENCE_R12, not an independent critic.

**469/469 pass, zero pending**, including all **55 R11 discriminants**. Types, full lint and final WriteSet format pass. The R11 **459 PASS / 10 FAIL** raw result and every frozen evidence record remain unchanged. [Raw regression](proofs/focused469.json), [case names/counters](proofs/raw-case-names-counters-comparison.json).

Only generator input data changed in the two authorized `newTests` files: complete native PG/chaos reports and full ten-row mutation receipts. The original unit rows, including invalid occurrence/id inputs, remain verbatim. Assertion AST/call counts, case-registration AST/names/cardinalities, counters and negative/status policies are exact before/after. All **371 original file hashes** are unchanged. The former 182-case byte prefix is **explicitly not preserved** because its generator data was repaired; no assertion was edited. [AST comparison](proofs/fixture-assertAST-comparison.json), [371 hashes](proofs/original371-filehashes.json).

Unit importer preflight now uses the scope's authoritative `requiredTestIds`, matching the existing snapshot verifier, with exact membership checked before any output. Required PG/chaos validation remains complete, frozen-selector and pass-only.

Exactly **three coverage sourceSha256 fields** were rebound to the unchanged R11 producer `f1e485…`. All other catalogue fields/IDs/operators/testFiles/budgets/domains are unchanged. The schema pins the approved complete catalogue digest and validates all live source hashes/selectors; the separate coverage hash exception is gone. [Rebind proof](proofs/rebind-three-source-hashes.json).

Real **`node scripts/mutation-guard.mjs`**: **10 selected, 10 KILLED, 0 survived/timeouts/errors, PASS**. Its actual native receipt crossed schema and snapshot admission. The original inclusive coverage selector still kills its mutant. Changed source, stale R11 receipts, receipt-only hash changes and self-rehashed incomplete catalogues remain refused. [Actual producer/admission](proofs/actual-native-producer-admission.json), [raw receipt](proofs/mutation-native-receipt.json), [input controls](proofs/mutation-input-binding.json).

Limitation: the unmutated mutation-test baseline is **93/94** because the no-network guard blocks one existing live-loopback integration case. The SSRF mutant has separate additional assertion failures, so its kill is not attributed solely to that environment blocker. No validation/failure mocks or new skips were introduced. [Native child kill evidence](proofs/mutation-real-child-kills.json).

Measured native Source/candidate inputs remain **8402/8402**, test paths **371+43**, coverage paths **281**. Source content/metadata, frozen R11 records, dependency bytes/versions and dist are unchanged. Root/Main, C1R13, PG, provider, secrets, subagents and commits were not touched. [Integrity](proofs/integrity-final.json).

[Source-to-current patch](build.patch), [R11-to-current patch](build-r12.patch), [SHA manifest](build-manifest.json), [machine report](report.json). Both patches were checked against physical owned Source/R11 file copies. Fresh independent critic remains required; no full/global/production acceptance.
''')
# Inventory all reviewable evidence while runtime copies are covered by full seals.
excluded={'before/candidate','patch-source','mutation-tmp','retained-r12-tmp','retained-vite','retained-vite-temp','home','cache','npm-cache'};artifacts=[]
for directory,dirs,files in os.walk(out,followlinks=False):
 rel=str(Path(directory).relative_to(out))
 dirs[:]=[d for d in dirs if str((Path(directory)/d).relative_to(out)) not in excluded]
 for name in files:
  p=Path(directory)/name
  if p==out/'artifact-inventory.json' or p.is_symlink():continue
  b=p.read_bytes();artifacts.append({'path':str(p.relative_to(out)),'bytes':len(b),'sha256':sha(b)})
(out/'artifact-inventory.json').write_text(json.dumps({'runtimeTreesCoveredByFullSeals':sorted(excluded),'entries':sorted(artifacts,key=lambda r:r['path'])},indent=2)+'\n')
print(json.dumps({'status':status,'SourceCandidateId':manifest['SourceCandidateId'],'currentCandidateId':manifest['currentCandidateId'],'incrementalWriteSet':incremental,'cumulativeWriteSet':cumulative,'original371Unchanged':True,'regression':manifest['tests'],'realNativeMutation':manifest['realNativeMutation'],'SourceAndFrozenR11Unchanged':True,'artifactFiles':len(artifacts)},indent=2))
