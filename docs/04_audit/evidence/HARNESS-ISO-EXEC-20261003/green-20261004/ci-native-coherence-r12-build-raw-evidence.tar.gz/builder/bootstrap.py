from pathlib import Path
import shutil,json,hashlib,os
base=Path('/home/ricardo/.cache/cvg-harness-green-20261004');out=base/'ci-native-coherence-r12-builder';candidate=base/'ci-native-admission-r11-candidate';r11=base/'ci-native-admission-r11-builder';source=base/'ci-importer-counter-review-r10/source'
for p in ['proofs','logs','before','tools']: (out/p).mkdir()
for p in ['build-manifest.json','report.json','report.md','artifact-inventory.json','build.patch']:
 shutil.copy2(r11/p,out/'before'/('r11-'+p))
for p in ['after469-current.json','afterFocused-current.json','integrity-final.json','candidate-after-full.json','source-after-full.json']:
 shutil.copy2(r11/'proofs'/p,out/'before'/('r11-'+p))
paths=['tests/hiso-ci-scopes.test.js','tests/hiso-snapshot-membership-own.test.js','scripts/hiso-snapshot-types.mjs','scripts/mutation-manifest.json']
for p in paths:
 dest=out/'before/candidate'/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(candidate/p,dest)
for name in ['guard.mjs','run.mjs','native-scopes.mjs','discriminants.mjs','importer-discriminants.mjs','mutation-snapshot-discriminants.mjs','ratio-discriminants.mjs','ratio-cli.mjs','mutation-extra.mjs']:
 s=(r11/name).read_text().replace(str(r11),str(out)).replace("path.resolve('..')",'path.resolve('+json.dumps(str(out))+')').replace('.r11-tmp','.r12-tmp')
 if name=='run.mjs':s=s.replace('timeout:240000','timeout:600000')
 (out/name).write_text(s)
# Retain supplied receipts/commands and immutable R11 records with opaque hashes.
rows=[]
for root,dirs,files in os.walk(r11):
 if Path(root)==r11:dirs[:]=[d for d in dirs if d not in {'baseline-runtime','retained-initial-tmp','retained-final-tmp','home','cache','npm-cache'}]
 for n in files:
  p=Path(root)/n
  if p.is_symlink():continue
  b=p.read_bytes();rows.append({'path':str(p.relative_to(r11)),'sha256':hashlib.sha256(b).hexdigest(),'size':len(b),'mtimeNs':p.stat().st_mtime_ns})
(out/'proofs/r11-evidence-before.json').write_text(json.dumps(rows,indent=2))
print('R11 evidence sealed:',len(rows))
