import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const out=path.dirname(import.meta.filename), packet=path.dirname(out), source=path.join(packet,'source');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
function snapshot(root){
 const rows={};
 function walk(rel){
  const p=path.join(root,rel), s=fs.lstatSync(p,{bigint:true});
  const row={kind:s.isDirectory()?'dir':s.isSymbolicLink()?'symlink':'file',mtimeNs:s.mtimeNs.toString(),mode:s.mode.toString(),dev:s.dev.toString(),ino:s.ino.toString()};
  if(s.isDirectory()){rows[rel||'.']=row;for(const n of fs.readdirSync(p).sort())walk(path.join(rel,n));}
  else if(s.isSymbolicLink()){row.target=fs.readlinkSync(p);rows[rel]=row;}
  else{row.bytes=Number(s.size);row.sha256=hash(fs.readFileSync(p));rows[rel]=row;}
 }
 walk('');return rows;
}
const stage=process.argv[2];
const inventoryBytes=fs.readFileSync(path.join(packet,'frozen-inventory.json'));
const freeze=JSON.parse(fs.readFileSync(path.join(packet,'freeze.json')));
if(hash(inventoryBytes)!==freeze.inventorySha256||freeze.inventorySha256!=='f80af7eaa25f25a268f48bca0779cba9ab5f2a8fdd526820cadb9ad1beeb2e06')throw Error('freeze mismatch');
const actual=snapshot(source), frozen=JSON.parse(inventoryBytes), differences=[];
for(const [rel,want] of Object.entries(frozen)){
 const got=actual[rel];
 if(!got){differences.push({rel,want,got:null});continue;}
 for(const [key,value] of Object.entries(want))if((key==='kind'&&got[key]==='symlink'?'link':got[key])!==value)differences.push({rel,key,want:value,got:got[key]});
}
const added=Object.keys(actual).filter(rel=>actual[rel].kind!=='dir'&&!Object.hasOwn(frozen,rel));
fs.writeFileSync(path.join(out,`integrity-${stage}.json`),JSON.stringify({inventorySha256:hash(inventoryBytes),frozenEntries:Object.keys(frozen).length,entries:actual,differences,added},null,2)+'\n');
if(stage==='pre'){
 if(differences.length||added.length)throw Error('frozen source mismatch');
 const runtime=path.join(out,'runtime');fs.cpSync(source,runtime,{recursive:true,verbatimSymlinks:true,preserveTimestamps:true});
 const copy=snapshot(runtime);let files=0,links=0;
 for(const [rel,row]of Object.entries(actual)){
  const c=copy[rel];if(!c||c.kind!==row.kind||(row.kind==='file'&&c.sha256!==row.sha256)||(row.kind==='symlink'&&c.target!==row.target))throw Error(`copy mismatch ${rel}`);
  if(row.kind==='file'){files++;if(row.dev===c.dev&&row.ino===c.ino)throw Error('hardlink');}
  if(row.kind==='symlink'){links++;const target=fs.realpathSync(path.join(runtime,rel));if(!target.startsWith(runtime+'/'))throw Error(`external link ${rel}`);}
 }
 fs.writeFileSync(path.join(out,'physical-copy.json'),JSON.stringify({runtime,files,links,hardlinks:0,externalLinks:0,copyMatchesFrozen:true},null,2)+'\n');
 for(const n of ['home','tmp','cache'])fs.mkdirSync(path.join(out,n),{recursive:true});
 console.log(JSON.stringify({stage,frozenEntries:Object.keys(frozen).length,differences:differences.length,added:added.length,files,links}));
}else{
 const pre=JSON.parse(fs.readFileSync(path.join(out,'integrity-pre.json'))).entries;
 const changed=Object.keys({...pre,...actual}).filter(k=>JSON.stringify(pre[k])!==JSON.stringify(actual[k]));
 fs.writeFileSync(path.join(out,'integrity-summary.json'),JSON.stringify({inventorySha256:hash(inventoryBytes),freezeMatches:true,frozenEntries:Object.keys(frozen).length,fileCount:Object.values(actual).filter(r=>r.kind==='file').length,directoryCount:Object.values(actual).filter(r=>r.kind==='dir').length,symlinkCount:Object.values(actual).filter(r=>r.kind==='symlink').length,hashDifferences:differences,added,prePostChanges:changed,fullMtimesChecked:true,sourceUntouched:!changed.length&&!differences.length&&!added.length},null,2)+'\n');
 console.log(JSON.stringify({stage,differences:differences.length,added:added.length,prePostChanges:changed.length}));
}
