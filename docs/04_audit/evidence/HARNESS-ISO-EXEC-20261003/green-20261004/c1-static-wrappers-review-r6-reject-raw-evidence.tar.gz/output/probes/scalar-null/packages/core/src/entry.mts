const obj={constructor:"label"};obj!.constructor
