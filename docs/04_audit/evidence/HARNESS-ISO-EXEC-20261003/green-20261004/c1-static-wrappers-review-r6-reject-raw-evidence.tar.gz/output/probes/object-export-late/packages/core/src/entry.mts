const obj={constructor:"label"};export {obj};obj.constructor
