const seed="label";function f(token=seed){var token;function inner(token){read(token)}return token}
