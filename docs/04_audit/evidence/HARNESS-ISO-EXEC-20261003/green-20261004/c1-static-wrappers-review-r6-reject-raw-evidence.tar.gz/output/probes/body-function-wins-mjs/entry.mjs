const seed="label";function f(token=seed){function token(){}read(token);return token}
