const seed="label";const token=seed!;read(token)
