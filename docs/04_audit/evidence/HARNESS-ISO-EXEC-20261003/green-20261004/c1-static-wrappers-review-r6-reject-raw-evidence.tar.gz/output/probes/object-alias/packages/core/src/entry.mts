const obj={constructor:"label"};const alias=obj;obj.constructor
