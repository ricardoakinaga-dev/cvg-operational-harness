class C{static{var __dirname="label";read(__dirname)}}observe(__dirname)
