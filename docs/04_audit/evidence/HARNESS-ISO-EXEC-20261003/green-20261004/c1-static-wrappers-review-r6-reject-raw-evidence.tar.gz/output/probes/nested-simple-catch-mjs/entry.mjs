const seed="label";function f(token="initial"){try{}catch(token){try{}catch(other){var token=seed;read(token)}}return token}
