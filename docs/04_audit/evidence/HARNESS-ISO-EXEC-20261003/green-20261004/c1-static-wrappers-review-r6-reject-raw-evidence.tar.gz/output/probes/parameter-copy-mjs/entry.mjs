const seed="label";function f(token=seed,capture=()=>token){var token;read(token);return token}
