const seed="label";const token=<unknown>seed;read(token)
