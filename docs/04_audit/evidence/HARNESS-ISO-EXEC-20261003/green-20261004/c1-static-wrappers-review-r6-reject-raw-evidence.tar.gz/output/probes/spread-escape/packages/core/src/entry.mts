const obj={constructor:"label"};const copy={...obj};obj.constructor
