const seed="label";function f(token="initial",capture=()=>token){try{}catch(token){var token=seed;read(token)}return token}
