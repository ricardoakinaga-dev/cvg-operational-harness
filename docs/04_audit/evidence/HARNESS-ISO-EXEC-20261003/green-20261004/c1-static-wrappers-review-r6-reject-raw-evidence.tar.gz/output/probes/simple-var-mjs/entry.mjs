const seed="label";function f(token){var token=seed;read(token);return token}
