declare const replacement:unknown;const obj={constructor:"label"};(obj.constructor as any)=replacement;obj.constructor
