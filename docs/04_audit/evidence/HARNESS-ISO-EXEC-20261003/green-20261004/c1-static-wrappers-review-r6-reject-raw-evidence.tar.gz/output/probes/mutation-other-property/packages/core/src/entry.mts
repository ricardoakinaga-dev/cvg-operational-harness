declare const replacement:unknown;const obj={constructor:"label",tag:"plain"};obj.tag=replacement;obj.constructor
