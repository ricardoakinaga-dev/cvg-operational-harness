const seed="label";function f(token="initial"){try{}catch(token){var {token=seed}={};read(token)}return token}
