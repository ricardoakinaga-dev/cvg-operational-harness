const seed="label";function f(token="initial",capture=()=>token){var token=seed;read(token);return token}
