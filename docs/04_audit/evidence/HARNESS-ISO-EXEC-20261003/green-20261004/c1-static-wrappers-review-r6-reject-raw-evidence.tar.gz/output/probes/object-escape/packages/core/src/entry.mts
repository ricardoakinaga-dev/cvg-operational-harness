const obj={constructor:"label"};consume((<object>obj)!);obj.constructor
