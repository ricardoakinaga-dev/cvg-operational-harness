class C{static{var __filename="label";read(__filename)}}observe(__filename)
