const obj={constructor:"label"};const alias=(<object>obj)!;obj.constructor
