const seed="label";const alias=seed satisfies unknown;const token=((alias as unknown)!) satisfies unknown;read(token)
