const text="label";const alias=text satisfies unknown;const obj={constructor:alias};obj.constructor
