const seed="label";class C{static{var token=seed;read(token)}static{var token;observe(token)}}
