const seed="label";const {token=((seed satisfies unknown) as unknown)!}={};read(token)
