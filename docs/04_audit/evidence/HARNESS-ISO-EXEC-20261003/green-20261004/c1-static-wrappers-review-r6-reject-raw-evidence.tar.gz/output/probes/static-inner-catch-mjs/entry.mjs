const seed="label";function f(token="initial"){class C{static{try{}catch(token){var token=seed;read(token)}}}return token}
