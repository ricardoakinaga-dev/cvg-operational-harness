declare const replacement:unknown;const obj={constructor:"label"};(obj.constructor satisfies unknown)=replacement;obj.constructor
