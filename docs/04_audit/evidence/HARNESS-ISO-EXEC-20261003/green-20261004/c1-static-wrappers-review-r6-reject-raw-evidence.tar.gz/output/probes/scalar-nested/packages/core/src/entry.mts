const obj={constructor:"label"};(((<object>obj) satisfies object)!).constructor
