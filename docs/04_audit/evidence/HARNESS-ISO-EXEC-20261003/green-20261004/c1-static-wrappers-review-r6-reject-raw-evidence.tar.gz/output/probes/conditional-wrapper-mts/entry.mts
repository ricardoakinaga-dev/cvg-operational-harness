const seed="label";const token=true?(seed as unknown):"plain";read(token)
