const seed="label";const token=("plain",seed satisfies unknown);read(token)
