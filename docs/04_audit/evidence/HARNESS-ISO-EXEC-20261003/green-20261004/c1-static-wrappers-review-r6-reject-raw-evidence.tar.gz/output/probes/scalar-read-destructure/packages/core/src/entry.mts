const obj={constructor:"label"};const {constructor:label}=obj;label
