const seed="label";function f(token="initial"){try{}catch{var token=seed;read(token)}return token}
