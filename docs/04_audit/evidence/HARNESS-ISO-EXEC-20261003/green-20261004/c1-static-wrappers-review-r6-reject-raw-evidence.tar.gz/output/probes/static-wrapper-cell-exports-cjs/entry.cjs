class C{static{var exports="label";read(exports)}}observe(exports)
