const obj={constructor:"label"};(<object>obj).constructor
