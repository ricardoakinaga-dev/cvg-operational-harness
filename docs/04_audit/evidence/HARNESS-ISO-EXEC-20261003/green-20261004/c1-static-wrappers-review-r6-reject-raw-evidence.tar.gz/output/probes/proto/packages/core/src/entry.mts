const obj={__proto__:null,constructor:"label"};obj.constructor
