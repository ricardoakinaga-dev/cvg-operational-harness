const obj={constructor:"label"};export default (obj satisfies object);obj.constructor
