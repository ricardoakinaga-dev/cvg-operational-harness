class C{static{var module="label";read(module)}}
