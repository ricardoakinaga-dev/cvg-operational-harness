const seed="label";function f(token){try{}catch(token){var token=seed;read(token)}return token}
