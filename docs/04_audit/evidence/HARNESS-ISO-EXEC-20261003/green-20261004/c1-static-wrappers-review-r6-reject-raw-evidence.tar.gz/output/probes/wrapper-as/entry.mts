const seed="label";const token=seed as unknown;read(token)
