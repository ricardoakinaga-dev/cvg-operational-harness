const seed="label";const token=seed satisfies unknown;read(token)
