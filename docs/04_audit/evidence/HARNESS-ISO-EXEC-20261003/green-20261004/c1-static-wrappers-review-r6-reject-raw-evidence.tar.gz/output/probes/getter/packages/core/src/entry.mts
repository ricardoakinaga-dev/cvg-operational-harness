const obj={get constructor(){return "label"}};obj.constructor
