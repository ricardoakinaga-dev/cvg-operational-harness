const seed="label";function f(token=seed){var token;{let token="plain";read(token)}return token}
