const seed="label";const alias=<unknown>seed;const token=<unknown>alias;read(token)
