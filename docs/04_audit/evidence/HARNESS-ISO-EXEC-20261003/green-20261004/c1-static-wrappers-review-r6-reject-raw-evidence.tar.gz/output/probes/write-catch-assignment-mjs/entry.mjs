const seed="label";function f(token="initial"){try{}catch(token){token=seed;read(token)}return token}
