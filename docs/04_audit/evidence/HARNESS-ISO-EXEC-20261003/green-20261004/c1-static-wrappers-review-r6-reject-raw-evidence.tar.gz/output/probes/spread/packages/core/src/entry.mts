const other={label:"plain"};const obj={...other,constructor:"label"};obj.constructor
