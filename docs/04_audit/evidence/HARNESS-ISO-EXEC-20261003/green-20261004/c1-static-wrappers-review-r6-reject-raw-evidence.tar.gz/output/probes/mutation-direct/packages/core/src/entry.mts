declare const replacement:unknown;const obj={constructor:"label"};obj.constructor=replacement;obj.constructor
