declare const replacement:unknown;const obj={constructor:"label"};(<unknown>obj.constructor)=replacement;obj.constructor
