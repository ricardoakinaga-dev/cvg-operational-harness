const obj={constructor:"label"};(obj satisfies object).constructor
