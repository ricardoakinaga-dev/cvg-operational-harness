const seed="label";function f(token="initial"){try{}catch(token){class C{static{var [token=seed]=[];read(token)}}}return token}
