declare const replacement:unknown;const obj={constructor:"label"};(obj as any).constructor=replacement;obj.constructor
