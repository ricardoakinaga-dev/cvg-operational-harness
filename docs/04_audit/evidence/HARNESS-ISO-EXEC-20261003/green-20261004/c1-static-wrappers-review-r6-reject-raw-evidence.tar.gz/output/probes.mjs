import fs from 'node:fs';import path from 'node:path';
import ts from './runtime/node_modules/typescript/lib/typescript.js';
import {createBoundaryLexical,assignedValues,valueBranches} from './runtime/scripts/boundary-lexical.mjs';
import {auditDynamicCodeExecution} from './runtime/scripts/boundary-code-execution.mjs';
import {auditProductBoundary} from './runtime/scripts/check-product-boundary.mjs';
const out=path.dirname(import.meta.filename), results=[];
function parse(id,text,ext='mts',commonJs=false){
 const file=path.join(out,'probes',id,'entry.'+ext);fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,text+'\n');
 const source=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true), nodes=[];
 function visit(n){nodes.push(n);ts.forEachChild(n,visit);}visit(source);
 return {source,nodes,lexical:createBoundaryLexical(ts,source,commonJs)};
}
const literal=n=>n&&ts.isStringLiteralLike(n)?n.text:undefined;
const labelCases=[
 ['simple-var','const seed="label";function f(token){var token=seed;read(token);return token}',true,true],
 ['non-simple-var','const seed="label";function f(token="initial",capture=()=>token){var token=seed;read(token);return token}',true,true],
 ['simple-catch','const seed="label";function f(token){try{}catch(token){var token=seed;read(token)}return token}',true,false],
 ['non-simple-catch','const seed="label";function f(token="initial",capture=()=>token){try{}catch(token){var token=seed;read(token)}return token}',true,false],
 ['nested-simple-catch','const seed="label";function f(token="initial"){try{}catch(token){try{}catch(other){var token=seed;read(token)}}return token}',true,false],
 ['optional-catch','const seed="label";function f(token="initial"){try{}catch{var token=seed;read(token)}return token}',true,true],
 ['static-catch-boundary','const seed="label";function f(token="initial"){try{}catch(token){class C{static{var token=seed;read(token)}}}return token}',true,false],
 ['static-inner-catch','const seed="label";function f(token="initial"){class C{static{try{}catch(token){var token=seed;read(token)}}}return token}',true,false],
 ['two-static-blocks','const seed="label";class C{static{var token=seed;read(token)}static{var token;observe(token)}}',true,null],
 ['static-nested-function','const seed="label";function f(token="initial"){try{}catch(token){class C{static{function inner(){var token=seed;read(token)}}}}return token}',true,false],
 ['static-array-default','const seed="label";function f(token="initial"){try{}catch(token){class C{static{var [token=seed]=[];read(token)}}}return token}',true,false],
 ['static-object-default','const seed="label";function f(token="initial"){try{}catch(token){class C{static{var {token=seed}={};read(token)}}}return token}',true,false],
 ['catch-array-default','const seed="label";function f(token="initial"){try{}catch(token){var [token=seed]=[];read(token)}return token}',true,false],
 ['catch-object-default','const seed="label";function f(token="initial"){try{}catch(token){var {token=seed}={};read(token)}return token}',true,false],
 ['body-function-wins','const seed="label";function f(token=seed){function token(){}read(token);return token}',false,false],
 ['parameter-copy','const seed="label";function f(token=seed,capture=()=>token){var token;read(token);return token}',true,true],
 ['closure-shadow','const seed="label";function f(token=seed){var token;function inner(token){read(token)}return token}',false,true],
 ['block-shadow','const seed="label";function f(token=seed){var token;{let token="plain";read(token)}return token}',false,true],
 ['satisfies-chain','const seed="label";const alias=seed satisfies unknown;const token=((alias as unknown)!) satisfies unknown;read(token)',true,null],
 ['assertion-chain','const seed="label";const alias=<unknown>seed;const token=<unknown>alias;read(token)',true,null],
 ['default-wrapper','const seed="label";const {token=((seed satisfies unknown) as unknown)!}={};read(token)',true,null],
 ['comma-wrapper','const seed="label";const token=("plain",seed satisfies unknown);read(token)',true,null],
 ['conditional-wrapper','const seed="label";const token=true?(seed as unknown):"plain";read(token)',true,null],
 ['logical-wrapper','const seed="label";const token="plain"??(seed satisfies unknown);read(token)',true,null],
 ['write-catch-assignment','const seed="label";function f(token="initial"){try{}catch(token){token=seed;read(token)}return token}',true,false],
 ['write-static-assignment','const seed="label";function f(token="initial"){try{}catch(token){class C{static{var token;token=seed;read(token)}}}return token}',true,false]
];
for(const ext of ['mjs','mts'])for(const [id,text,wantRead,wantReturn]of labelCases){
 if(ext==='mjs'&&/(satisfies| as unknown|<unknown>|\)!)/.test(text))continue;
 const {source,nodes,lexical}=parse(id+'-'+ext,text,ext), seed=nodes.find(n=>ts.isVariableDeclaration(n)&&n.name.getText(source)==='seed').name;
 const labels=new Set([lexical.identity(seed)]);let changed=true;
 const match=n=>ts.isIdentifier(n)&&labels.has(lexical.identity(n));
 while(changed){changed=false;const bind=(key,value)=>{if(valueBranches(ts,value).some(match)&&!labels.has(key)){labels.add(key);changed=true;}};
  for(const [body,parameter]of lexical.initialTransfers)bind(lexical.identity(body),parameter);
  for(const n of nodes.filter(n=>!lexical.erased(n))){
   if((ts.isVariableDeclaration(n)||ts.isParameter(n))&&n.initializer)assignedValues(ts,n.name,n.initializer,literal,(name,value)=>bind(lexical.writeIdentity(name),value));
   if(ts.isBinaryExpression(n)&&n.operatorToken.kind>=ts.SyntaxKind.FirstAssignment&&n.operatorToken.kind<=ts.SyntaxKind.LastAssignment)assignedValues(ts,n.left,n.right,literal,(name,value)=>bind(lexical.identity(name),value));
  }
 }
 const diagnostics=[];
 auditDynamicCodeExecution({ts,source,lexical:{...lexical,global:name=>name==='Function'?lexical.identity(seed):lexical.global(name)},runtimeNodes:nodes.filter(n=>!lexical.erased(n)),typeOnly:lexical.erased,literal,isLoader:()=>false,isBuiltinGetter:()=>false,isGlobal:()=>false,isDeclarationName:lexical.isDeclarationName,loaderDiagnostic:(node,reason)=>diagnostics.push({start:node.getStart(source),reason})});
 const read=nodes.find(n=>ts.isIdentifier(n)&&n.text==='token'&&ts.isCallExpression(n.parent)&&n.parent.expression.getText(source)==='read');
 const ret=nodes.find(n=>ts.isIdentifier(n)&&n.text==='token'&&ts.isReturnStatement(n.parent));
 const gotRead=labels.has(lexical.identity(read)), gotReturn=ret?labels.has(lexical.identity(ret)):null;
 const dynamicRead=diagnostics.some(d=>d.start===read.getStart(source)),dynamicReturn=ret?diagnostics.some(d=>d.start===ret.getStart(source)):null;
 const cells=[],cell=n=>{const key=lexical.identity(n);if(!cells.includes(key))cells.push(key);return cells.indexOf(key);};
 const tokens=nodes.filter(n=>ts.isIdentifier(n)&&n.text==='token').map(n=>({start:n.getStart(source),parent:ts.SyntaxKind[n.parent.kind],readCell:cell(n),writeCell:(()=>{const k=lexical.writeIdentity(n);if(!cells.includes(k))cells.push(k);return cells.indexOf(k)})()}));
 const transfers=lexical.initialTransfers.map(([a,b])=>({target:cell(a),parameter:cell(b),selfEdge:lexical.identity(a)===lexical.identity(b)}));
 const row={id:id+'-'+ext,kind:'cross-consumer-symbolic',file:'probes/'+id+'-'+ext+'/entry.'+ext,text,fixturesExecuted:false,parseErrors:source.parseDiagnostics.length,expected:{read:wantRead,returned:wantReturn},generic:{read:gotRead,returned:gotReturn},dynamic:{read:dynamicRead,returned:dynamicReturn},tokens,transfers,diagnostics};
 if(id==='two-static-blocks'){const other=nodes.find(n=>ts.isIdentifier(n)&&n.text==='token'&&ts.isCallExpression(n.parent)&&n.parent.expression.getText(source)==='observe');row.otherBlockLabel=labels.has(lexical.identity(other));}
 row.pass=!row.parseErrors&&gotRead===wantRead&&(wantReturn===null||gotReturn===wantReturn)&&dynamicRead===wantRead&&(wantReturn===null||dynamicReturn===wantReturn)&&!transfers.some(t=>t.selfEdge)&&row.otherBlockLabel!==true;results.push(row);
}
const scalarCases=[
 ['scalar-direct','const obj={constructor:"label"};obj.constructor','PASS'],
 ['scalar-satisfies','const obj={constructor:"label"};(obj satisfies object).constructor','PASS'],
 ['scalar-assertion','const obj={constructor:"label"};(<object>obj).constructor','PASS'],
 ['scalar-null','const obj={constructor:"label"};obj!.constructor','PASS'],
 ['scalar-nested','const obj={constructor:"label"};(((<object>obj) satisfies object)!).constructor','PASS'],
 ['scalar-alias','const text="label";const alias=text satisfies unknown;const obj={constructor:alias};obj.constructor','PASS'],
 ['object-alias','const obj={constructor:"label"};const alias=obj;obj.constructor','INCOMPLETE'],
 ['object-wrapped-alias','const obj={constructor:"label"};const alias=(<object>obj)!;obj.constructor','INCOMPLETE'],
 ['object-escape','const obj={constructor:"label"};consume((<object>obj)!);obj.constructor','INCOMPLETE'],
 ['object-export-late','const obj={constructor:"label"};export {obj};obj.constructor','INCOMPLETE'],
 ['object-export-default','const obj={constructor:"label"};export default (obj satisfies object);obj.constructor','INCOMPLETE'],
 ['getter','const obj={get constructor(){return "label"}};obj.constructor','INCOMPLETE'],
 ['spread','const other={label:"plain"};const obj={...other,constructor:"label"};obj.constructor','INCOMPLETE'],
 ['proto','const obj={__proto__:null,constructor:"label"};obj.constructor','INCOMPLETE'],
 ['computed','const obj={["constructor"]:"label"};obj.constructor','INCOMPLETE'],
 ['mutation-direct','declare const replacement:unknown;const obj={constructor:"label"};obj.constructor=replacement;obj.constructor','INCOMPLETE'],
 ['mutation-base-wrapper','declare const replacement:unknown;const obj={constructor:"label"};(obj as any).constructor=replacement;obj.constructor','INCOMPLETE'],
 ['mutation-property-as','declare const replacement:unknown;const obj={constructor:"label"};(obj.constructor as any)=replacement;obj.constructor','INCOMPLETE'],
 ['mutation-property-satisfies','declare const replacement:unknown;const obj={constructor:"label"};(obj.constructor satisfies unknown)=replacement;obj.constructor','INCOMPLETE'],
 ['mutation-property-non-null','declare const replacement:unknown;const obj={constructor:"label"};(obj.constructor!)=replacement;obj.constructor','INCOMPLETE'],
 ['mutation-property-assertion','declare const replacement:unknown;const obj={constructor:"label"};(<unknown>obj.constructor)=replacement;obj.constructor','INCOMPLETE'],
 ['destructure-property-wrapper','declare const replacement:unknown;const obj={constructor:"label"};[(obj.constructor as any)]=[replacement];obj.constructor','INCOMPLETE'],
 ['mutation-other-property','declare const replacement:unknown;const obj={constructor:"label",tag:"plain"};obj.tag=replacement;obj.constructor','INCOMPLETE'],
 ['spread-escape','const obj={constructor:"label"};const copy={...obj};obj.constructor','INCOMPLETE'],
 ['scalar-read-destructure','const obj={constructor:"label"};const {constructor:label}=obj;label','PASS'],
 ['module-static-cjs','class C{static{var module="label";read(module)}}','PASS','cjs'],
 ['module-static-esm','class C{static{var module="label";read(module)}}','PASS','mjs']
];
for(const[id,text,expected,extension='mts']of scalarCases){
 const root=path.join(out,'probes',id);fs.mkdirSync(root,{recursive:true});
 for(const dir of ['packages/core/src','apps','legacy','products'])fs.mkdirSync(path.join(root,dir),{recursive:true});
 const write=(rel,data)=>fs.writeFileSync(path.join(root,rel),data);
 write('package.json',JSON.stringify({private:true,type:'module',workspaces:['packages/*']}));
 write('packages/core/package.json',JSON.stringify({name:'@synthetic/core',type:'module'}));
 write('tsconfig.base.json',JSON.stringify({compilerOptions:{module:'NodeNext',moduleResolution:'NodeNext',target:'ESNext',allowJs:true}}));
 const relative='packages/core/src/entry.'+extension;
 write(relative,text+'\n');
 const source=ts.createSourceFile(path.join(root,relative),text,ts.ScriptTarget.Latest,true);
 const mutationTargets=[];function inspect(n){if(ts.isBinaryExpression(n)&&n.operatorToken.kind===ts.SyntaxKind.EqualsToken){let target=n.left;const wrappers=[];while(ts.isParenthesizedExpression(target)||ts.isAsExpression(target)||ts.isSatisfiesExpression(target)||ts.isNonNullExpression(target)||ts.isTypeAssertionExpression(target)){wrappers.push(ts.SyntaxKind[target.kind]);target=target.expression;}mutationTargets.push({start:n.getStart(source),left:n.left.getText(source),target:target.getText(source),targetKind:ts.SyntaxKind[target.kind],wrappers,right:n.right.getText(source)});}ts.forEachChild(n,inspect);}inspect(source);
 const audit=auditProductBoundary(root);results.push({id,kind:'native-neutral-scalar',file:'probes/'+id+'/'+relative,text,fixturesExecuted:false,parseErrors:source.parseDiagnostics.length,expected,actual:audit.status,mutationTargets,audit,pass:!source.parseDiagnostics.length&&audit.status===expected});
}
// Inspect trusted consumer ASTs; interpret only wrapper predicate membership.
// This is an abstract consistency proof, not a native loader capability probe.
const pfile=path.join(out,'runtime/scripts/check-product-boundary.mjs'),ptext=fs.readFileSync(pfile,'utf8'),past=ts.createSourceFile(pfile,ptext,ts.ScriptTarget.Latest,true),predicates=[];
function collect(n){if(ts.isVariableDeclaration(n)&&n.name.getText(past)==='unwrap'){
 function checks(c){if(ts.isCallExpression(c)&&ts.isPropertyAccessExpression(c.expression)&&c.expression.expression.getText(past)==='ts')predicates.push(c.expression.name.text);ts.forEachChild(c,checks);}checks(n.initializer);
}ts.forEachChild(n,collect);}collect(past);
for(const [id,expression,predicate]of [['wrapper-as','seed as unknown','isAsExpression'],['wrapper-satisfies','seed satisfies unknown','isSatisfiesExpression'],['wrapper-null','seed!','isNonNullExpression'],['wrapper-assertion','<unknown>seed','isTypeAssertionExpression']]){
 const {source,nodes,lexical}=parse(id,'const seed="label";const token='+expression+';read(token)');const expr=nodes.find(n=>ts.isVariableDeclaration(n)&&n.name.getText(source)==='token').initializer;
 results.push({id,kind:'abstract-product-unwrap-consistency',file:'probes/'+id+'/entry.mts',fixturesExecuted:false,parseErrors:source.parseDiagnostics.length,expected:true,actual:predicates.includes(predicate),predicates,valueBranchesRetainsSeed:valueBranches(ts,expr).some(n=>ts.isIdentifier(n)&&n.text==='seed'),pass:predicates.includes(predicate)});
}
for(const name of ['__filename','__dirname','exports','module'])for(const commonJs of [false,true]){
 const id='static-wrapper-cell-'+name+'-'+(commonJs?'cjs':'esm'),text='class C{static{var '+name+'="label";read('+name+')}}observe('+name+')';
 const {source,nodes,lexical}=parse(id,text,commonJs?'cjs':'mjs',commonJs);
 const ids=nodes.filter(n=>ts.isIdentifier(n)&&n.text===name),decl=ids.find(n=>ts.isVariableDeclaration(n.parent)),inside=ids.find(n=>ts.isCallExpression(n.parent)&&n.parent.expression.getText(source)==='read'),outside=ids.find(n=>ts.isCallExpression(n.parent)&&n.parent.expression.getText(source)==='observe');
 const actual={declarationEqualsInside:lexical.identity(decl)===lexical.identity(inside),insideEqualsOutside:lexical.identity(inside)===lexical.identity(outside),insideEqualsWrapperGlobal:lexical.identity(inside)===lexical.global(name)};
 results.push({id,kind:'native-lexical-static-wrapper-boundary',file:'probes/'+id+'/entry.'+(commonJs?'cjs':'mjs'),text,fixturesExecuted:false,parseErrors:source.parseDiagnostics.length,commonJs,expected:{declarationEqualsInside:true,insideEqualsOutside:false,insideEqualsWrapperGlobal:false},actual,pass:actual.declarationEqualsInside&&!actual.insideEqualsOutside&&!actual.insideEqualsWrapperGlobal});
}
const summary={total:results.length,passed:results.filter(r=>r.pass).length,failed:results.filter(r=>!r.pass).length,fixturesExecuted:false,results};fs.writeFileSync(path.join(out,'own-probes.json'),JSON.stringify(summary,null,2)+'\n');console.log(JSON.stringify({total:summary.total,passed:summary.passed,failed:summary.failed,failures:results.filter(r=>!r.pass).map(r=>({id:r.id,expected:r.expected,actual:r.actual,generic:r.generic,dynamic:r.dynamic}))}));
