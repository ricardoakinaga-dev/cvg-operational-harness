# C1_STATIC_WRAPPERS_FRESH_REVIEW_R6 — REJECT scoped static

Revisão válida no packet congelado: Vitest nativo **232/232**; provas próprias **74/85** conformes, **11** divergências. Dois achados: **1 P1 e 1 P2**. Installed scanner unknown1706 permanece **INCOMPLETE**, segundo o lead, fora da aceitação deste escopo. Commit Root 50a92ef informado pelo usuário; não inspecionado. Não certifica installed/frontier/global/produção.

Autoridade: [authority](../authority.json), [freeze](../freeze.json), inventário SHA-256 `f80af7eaa25f25a268f48bca0779cba9ab5f2a8fdd526820cadb9ad1beeb2e06`. Claim local: [claim](claim.json). Node absoluto `/home/ricardo/.nvm/versions/node/v22.23.2/bin/node` (v22.23.2); Vitest 4.1.11, pool threads. Source, deps e dist originais somente leitura; cópia física própria em output.

## P1 — Escritas com wrappers preservam prova escalar inválida

[written](runtime/scripts/boundary-code-execution.mjs#L85) percorre parênteses/patterns, mas não as quatro expressões TS transparentes. [stableInitializer](runtime/scripts/boundary-code-execution.mjs#L174) depende desse predicado para invalidar o objeto literal.

Controle direto: [fixture](probes/mutation-direct/packages/core/src/entry.mts) resulta em INCOMPLETE. [Escrita com as](probes/mutation-property-as/packages/core/src/entry.mts), [satisfies](probes/mutation-property-satisfies/packages/core/src/entry.mts), [non-null](probes/mutation-property-non-null/packages/core/src/entry.mts), [type assertion](probes/mutation-property-assertion/packages/core/src/entry.mts) e [destructuring](probes/destructure-property-wrapper/packages/core/src/entry.mts) resultam em PASS, embora escrevam uma replacement desconhecida em constructor. ASTs e resultados nativos: [own-probes.json](own-probes.json).

O texto é neutro: valor inicial "label", replacement simbólica unknown, sem execução da fixture. A prova demonstra falso verde estático após mutação; não demonstra execução de capacidade real. Builder deve tornar a identificação de escrita transparente aos wrappers e rever as folhas de patterns. Nenhuma correção aplicada.

## P2 — var de bloco estático CJS recebe identidade externa

[wrapperVar](runtime/scripts/boundary-lexical.mjs#L217) testa função/module, mas omite ClassStaticBlockDeclaration na [fronteira](runtime/scripts/boundary-lexical.mjs#L234). As quatro provas neutras __filename/__dirname/exports/module em CJS identificam declaração local e read interno com a mesma célula do observe externo. Controles ESM mantêm as células distintas.

A [fixture CJS nativa](probes/module-static-cjs/packages/core/src/entry.cjs) com apenas var module="label" e read(module) resulta em INCOMPLETE; o [controle ESM](probes/module-static-esm/packages/core/src/entry.mjs) resulta em PASS. As relações de identidade e diagnósticos estão em [own-probes.json](own-probes.json). É erro de identidade e falso positivo estático. Não houve aquisição real de loader. Builder deve preservar a fronteira do bloco estático no tratamento das var do wrapper.

## Observação abstrata, sem gravidade atribuída

[unwrap do produto](runtime/scripts/check-product-boundary.mjs#L557) omite isTypeAssertionExpression; valueBranches e o consumidor dynamic preservam o label neutro. A prova wrapper-assertion verifica apenas predicados do AST. Não comprova omissão nativa de loader e não é contada como terceiro achado.

## Evidência e validade

- [Relatório real do Vitest](native-vitest.json), [log](native-vitest.log), suite fornecida inalterada: 232 pass, 0 fail, 0 pending, exit 0.
- [Provas próprias](own-probes.json), [driver](probes.mjs), [log](own-probes.log): 85 casos, 74 conformes, 11 divergências; 46 controles simbólicos, 27 audits nativos neutros, 4 inspeções de predicados e 8 controles de identidade. Driver é coletor de evidência, exit 0; não se apresenta como Vitest.
- [Cópia física](physical-copy.json), [verificação do runtime](runtime-integrity.json): arquivos confiáveis e suite iguais ao freeze, sem hardlinks/links externos.
- [Integridade completa pré](integrity-pre.json), [pós](integrity-post.json), [resumo](integrity-summary.json): 19334 arquivos, 48 links e 1970 diretórios; hashes e mtimes completos inalterados, inclusive deps/dist e diretório source.
- [Comandos brutos](commands.json), [provas R4 retidas](native-r4-neutral-proofs.json).

Os controles simbólicos usam o helper lexical real e o consumidor dynamic real com seed abstrato injetado; o propagador genérico espelha o fixed point inspecionado do produto. Não substituem testes nativos de capacidades. Os audits nativos próprios invocam auditProductBoundary sem alteração. O resolver original resolve literals sem importar fixtures; não houve stub ou resolução alternativa.

## Comandos executados

CWD: `/home/ricardo/.cache/cvg-harness-green-20261004/c1-static-wrappers-review-r6`
```sh
/usr/bin/env -i HOME=/home/ricardo/.cache/cvg-harness-green-20261004/c1-static-wrappers-review-r6/output TMPDIR=/home/ricardo/.cache/cvg-harness-green-20261004/c1-static-wrappers-review-r6/output XDG_CACHE_HOME=/home/ricardo/.cache/cvg-harness-green-20261004/c1-static-wrappers-review-r6/output /home/ricardo/.nvm/versions/node/v22.23.2/bin/node output/integrity.mjs pre
```

CWD: `/home/ricardo/.cache/cvg-harness-green-20261004/c1-static-wrappers-review-r6/output/runtime`
```sh
/usr/bin/env -i HOME=/home/ricardo/.cache/cvg-harness-green-20261004/c1-static-wrappers-review-r6/output/home TMPDIR=/home/ricardo/.cache/cvg-harness-green-20261004/c1-static-wrappers-review-r6/output/tmp XDG_CACHE_HOME=/home/ricardo/.cache/cvg-harness-green-20261004/c1-static-wrappers-review-r6/output/cache npm_config_cache=/home/ricardo/.cache/cvg-harness-green-20261004/c1-static-wrappers-review-r6/output/cache PATH=/home/ricardo/.nvm/versions/node/v22.23.2/bin:/usr/bin:/bin /home/ricardo/.nvm/versions/node/v22.23.2/bin/node node_modules/vitest/vitest.mjs run tests/product-boundary-lexical-static.test.js --pool=threads --no-file-parallelism --maxWorkers=1 --reporter=default --reporter=json --outputFile.json=../native-vitest.json > ../native-vitest.log 2>&1
```

CWD: `/home/ricardo/.cache/cvg-harness-green-20261004/c1-static-wrappers-review-r6/output`
```sh
/usr/bin/env -i HOME=/home/ricardo/.cache/cvg-harness-green-20261004/c1-static-wrappers-review-r6/output/home TMPDIR=/home/ricardo/.cache/cvg-harness-green-20261004/c1-static-wrappers-review-r6/output/tmp XDG_CACHE_HOME=/home/ricardo/.cache/cvg-harness-green-20261004/c1-static-wrappers-review-r6/output/cache PATH=/home/ricardo/.nvm/versions/node/v22.23.2/bin:/usr/bin:/bin /home/ricardo/.nvm/versions/node/v22.23.2/bin/node probes.mjs > own-probes.log 2>&1
```

CWD: `/home/ricardo/.cache/cvg-harness-green-20261004/c1-static-wrappers-review-r6`
```sh
/usr/bin/env -i HOME=/home/ricardo/.cache/cvg-harness-green-20261004/c1-static-wrappers-review-r6/output/home TMPDIR=/home/ricardo/.cache/cvg-harness-green-20261004/c1-static-wrappers-review-r6/output/tmp XDG_CACHE_HOME=/home/ricardo/.cache/cvg-harness-green-20261004/c1-static-wrappers-review-r6/output/cache PATH=/home/ricardo/.nvm/versions/node/v22.23.2/bin:/usr/bin:/bin /home/ricardo/.nvm/versions/node/v22.23.2/bin/node output/integrity.mjs post
```

CWD: `/home/ricardo/.cache/cvg-harness-green-20261004/c1-static-wrappers-review-r6/output`
```sh
/usr/bin/env -i HOME=/home/ricardo/.cache/cvg-harness-green-20261004/c1-static-wrappers-review-r6/output/home TMPDIR=/home/ricardo/.cache/cvg-harness-green-20261004/c1-static-wrappers-review-r6/output/tmp XDG_CACHE_HOME=/home/ricardo/.cache/cvg-harness-green-20261004/c1-static-wrappers-review-r6/output/cache PATH=/home/ricardo/.nvm/versions/node/v22.23.2/bin:/usr/bin:/bin /home/ricardo/.nvm/versions/node/v22.23.2/bin/node finalize.mjs
```

## Cleanup e limites

Temporários da suite removidos por afterAll. Prova R4 movida para arquivo de evidência; tmp final: []. Runtime, cache e fixtures inertes mantidos como evidência somente dentro de output. Arquivos próprios sofreram correções de oracle antes do resultado final: leitura por destructuring é escalar segura (PASS); o texto != foi substituído por non-null parenthesizado seguido de assignment. A primeira verificação de freeze normalizou apenas o nome link/symlink do formato de inventário. Nenhum source/helper/dependência/suite fornecida foi editado.

Os quatro documentos de ledger/coordenação não estão no snapshot; [estado](runtime-state.json), [log](execution-log.md) e [backlog local](backlog.md) persistem apenas em output. Não houve root/history/builder/skills, rede/provider/PG/Docker, subagentes, fixes, commit, push, release ou dados reais. Nenhuma rejeição de aprovação automática observada. Consequências nativas da observação sobre type assertion permanecem desconhecidas. Próxima ação: builder tratar P1/P2 e emitir novo freeze para fresh review.
