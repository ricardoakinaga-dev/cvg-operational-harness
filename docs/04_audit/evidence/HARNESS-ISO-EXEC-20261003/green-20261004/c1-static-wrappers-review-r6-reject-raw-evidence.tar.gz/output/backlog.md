# Local review backlog

- P1 C1-R6-P1-01: invalidate scalar proof for TS-wrapped property writes and pattern leaves; builder action required.
- P2 C1-R6-P2-01: preserve CJS static var scope boundary in wrapperVar; builder action required.
- OBS C1-R6-OBS-01: reconcile product unwrap type assertions; native consequences unknown.
- Keep static gate REJECT; request fresh frozen review after builder changes.
