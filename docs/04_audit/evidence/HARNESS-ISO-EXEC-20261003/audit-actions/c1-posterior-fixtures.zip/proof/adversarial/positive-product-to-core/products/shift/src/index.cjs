module.exports=require('../../../packages/core/src/neutral.cjs')
