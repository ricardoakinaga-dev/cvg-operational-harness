// @vitest-environment node
import * as fs from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { describe, expect, it } from 'vitest'
import { ShiftStore } from '../store.ts'
import { sha256, MAX_V2_LINE, MAX_V1_LINE, lines } from '../journal.ts'
import type { ShiftEvent, Note, Task } from '../domain.ts'

const AT = '2026-10-03T12:00:00.000Z'
const PHONE = '5511900000001'
const cache = fs.mkdtempSync(join(tmpdir(), 'cvg-piso004-migration-'))
fs.mkdirSync(cache, { recursive: true })
function volume(events: ShiftEvent[], tail = ''): string {
  const dir = fs.mkdtempSync(join(cache, 'migration-'))
  fs.mkdirSync(join(dir, 'media'))
  fs.writeFileSync(
    join(dir, 'events.jsonl'),
    events.map((e) => JSON.stringify(e) + '\n').join('') + tail
  )
  return dir
}
function note(id: string, confirmed = false): Note {
  return {
    id,
    messageId: id,
    authorPhone: PHONE,
    createdAt: AT,
    kind: 'text',
    rawText: 'texto original sintético',
    unverifiedNumbers: [],
    confirmed
  }
}
function task(
  number: number,
  noteId: string,
  status: Task['status'] = 'open'
): Task {
  return {
    number,
    noteId,
    ownerPhone: PHONE,
    description: 'tarefa original',
    dueAt: AT,
    createdAt: AT,
    status,
    remindedCount: 2
  }
}
function fixture(): ShiftEvent[] {
  return [
    {
      type: 'message_received',
      at: AT,
      message: {
        provider: 'waha',
        messageId: 'n1',
        fromPhone: PHONE,
        kind: 'text',
        text: 'fonte',
        receivedAt: AT
      }
    },
    {
      type: 'message_received',
      at: AT,
      message: {
        provider: 'waha',
        messageId: 'n2',
        fromPhone: PHONE,
        kind: 'text',
        text: 'fonte 2',
        receivedAt: AT
      }
    },
    {
      type: 'message_received',
      at: AT,
      message: {
        provider: 'waha',
        messageId: 'failed',
        fromPhone: PHONE,
        kind: 'text',
        text: 'entrada sem nota',
        receivedAt: AT
      }
    },
    { type: 'note_created', at: AT, note: note('n1') },
    { type: 'note_created', at: AT, note: note('n2', true) },
    { type: 'note_superseded', at: AT, noteId: 'n1', by: 'n2' },
    { type: 'task_created', at: AT, task: task(1, 'n1') },
    { type: 'task_created', at: AT, task: task(9, 'n2') },
    { type: 'task_created', at: AT, task: task(10, 'n2', 'done') },
    { type: 'task_created', at: AT, task: task(11, 'n2', 'cancelled') },
    {
      type: 'task_snoozed',
      at: AT,
      number: 1,
      dueAt: '2026-10-04T12:00:00.000Z'
    },
    { type: 'task_reminded', at: AT, number: 9 },
    { type: 'message_processed', at: AT, messageId: 'n2' },
    { type: 'message_processed', at: AT, messageId: 'failed' },
    { type: 'paused', at: AT, by: PHONE }
  ]
}

describe('V1 conservative migration via ShiftStore', () => {
  it('backs up unchanged originals, retains numbers/counters/status/pause, holds active tasks, and reopens twice idempotently', () => {
    const dir = volume(fixture())
    const original = fs.readFileSync(join(dir, 'events.jsonl'))
    let id: string | undefined
    let seq = 0
    for (let i = 0; i < 3; i++) {
      const store = new ShiftStore(dir, { legacySession: 'synthetic-session' })
      expect(store.storageAvailable, store.diagnostic).toBe(true)
      expect(store.operationalHold).toBe(true)
      expect(store.effectsAllowed).toBe(false)
      expect(store.openTasks()).toEqual([])
      expect(store.unprocessedMessages()).toEqual([])
      expect(store.paused).toBe(true)
      expect(store.note('n1')?.supersededBy).toBe('n2')
      expect(store.note('n2')?.confirmed).toBe(true)
      expect(store.task(1)?.dueAt).toBe('2026-10-04T12:00:00.000Z')
      expect(store.task(1)?.remindedCount).toBe(0)
      expect(store.task(9)?.remindedCount).toBe(3)
      expect(store.task(10)?.status).toBe('done')
      expect(store.task(11)?.status).toBe('cancelled')
      expect(store.taskProjectionState(1)).toBe('draft')
      expect(store.taskProjectionState(9)).toBe('legacy_review_required')
      expect(store.nextTaskNumber()).toBe(12)
      expect(store.knownPatients('Thor')).toEqual([])
      expect(
        store.migration?.messages.find((m) => m.messageId === 'n2')?.state
      ).toBe('uncertain_legacy')
      expect(
        store.migration?.messages.find((m) => m.messageId === 'failed')?.state
      ).toBe('review_required')
      expect(
        fs.readFileSync(join(dir, store.migration!.backupPath, 'events.jsonl'))
      ).toEqual(original)
      if (i === 0) {
        id = store.migration!.id
        seq = store.sequence
      } else {
        expect(store.migration!.id).toBe(id)
        expect(store.sequence).toBe(seq)
      }
      store.close()
      expect(fs.readFileSync(join(dir, 'events.jsonl'))).toEqual(original)
    }
  })

  it('requires configured session instead of inventing legacy identity', () => {
    const dir = volume(fixture())
    const store = new ShiftStore(dir)
    expect(store.storageAvailable).toBe(false)
    expect(fs.existsSync(join(dir, 'journal/manifest.json'))).toBe(false)
    store.close()
  })

  it('isolates legacy nondelimited JSON and keeps its full byte-identical original', () => {
    const dir = volume(
      fixture(),
      JSON.stringify({ type: 'resumed', at: AT, by: PHONE })
    )
    const original = fs.readFileSync(join(dir, 'events.jsonl'))
    const store = new ShiftStore(dir, { legacySession: 'synthetic-session' })
    expect(store.storageAvailable).toBe(true)
    expect(store.paused).toBe(true)
    const manifest = JSON.parse(
      fs.readFileSync(join(dir, 'journal/manifest.json'), 'utf8')
    )
    expect(manifest.legacy.bytes).toBeLessThan(original.length)
    expect(
      fs.readFileSync(join(dir, manifest.pendingRecovery.copyPath))
    ).toEqual(original)
    expect(manifest.legacy.fullSha256).toBe(sha256(original))
    store.close()
    const reopened = new ShiftStore(dir, { legacySession: 'synthetic-session' })
    expect(reopened.storageAvailable).toBe(true)
    expect(reopened.paused).toBe(true)
    reopened.close()
    expect(fs.readFileSync(join(dir, 'events.jsonl'))).toEqual(original)
  })

  it('blocks invalid delimited V1, unknown schemas, and identity collisions without publishing a manifest', () => {
    for (const suffix of [
      '{broken}\n',
      '{"type":"unknown","at":"' + AT + '"}\n',
      JSON.stringify({
        type: 'message_received',
        at: AT,
        message: {
          provider: 'waha',
          messageId: 'n1',
          fromPhone: PHONE,
          kind: 'text',
          text: 'different',
          receivedAt: AT
        }
      }) + '\n'
    ]) {
      const dir = volume(fixture(), suffix)
      const original = fs.readFileSync(join(dir, 'events.jsonl'))
      const store = new ShiftStore(dir, { legacySession: 'synthetic-session' })
      expect(store.storageAvailable).toBe(false)
      expect(fs.existsSync(join(dir, 'journal/manifest.json'))).toBe(false)
      store.close()
      expect(fs.readFileSync(join(dir, 'events.jsonl'))).toEqual(original)
    }
  })

  it('externalizes V1 inline larger than V2 budget and old named media, preserving both originals and backup inventory', () => {
    const events = fixture()
    const first = events[0]!
    if (first.type === 'message_received') {
      first.message.kind = 'audio'
      first.message.mimetype = 'audio/ogg'
      first.message.mediaRef =
        'base64:' + Buffer.alloc(MAX_V2_LINE + 10, 2).toString('base64')
    }
    const created = events.find((e) => e.type === 'note_created')
    if (created?.type === 'note_created') created.note.mediaFile = 'old.ogg'
    const dir = volume(events)
    fs.writeFileSync(join(dir, 'media/old.ogg'), Buffer.from([4, 5, 6]))
    const originalHash = sha256(fs.readFileSync(join(dir, 'events.jsonl')))
    const firstStore = new ShiftStore(dir, {
      legacySession: 'synthetic-session'
    })
    expect(firstStore.storageAvailable, firstStore.diagnostic).toBe(true)
    expect(firstStore.mediaInventory().valid).toHaveLength(2)
    expect(firstStore.note('n1')?.mediaFile).not.toBe('old.ogg')
    const migration = firstStore.migration!
    expect(migration.mediaMappings).toHaveLength(2)
    expect(
      fs.readFileSync(join(dir, migration.backupPath, 'media/old.ogg'))
    ).toEqual(Buffer.from([4, 5, 6]))
    const manifest = JSON.parse(
      fs.readFileSync(join(dir, 'journal/manifest.json'), 'utf8')
    )
    expect(
      fs.readFileSync(join(dir, manifest.segments[0].path), 'utf8')
    ).not.toContain('base64:')
    firstStore.close()
    const reopened = new ShiftStore(dir, { legacySession: 'synthetic-session' })
    expect(reopened.storageAvailable, reopened.diagnostic).toBe(true)
    expect(reopened.mediaInventory().valid).toHaveLength(2)
    reopened.close()
    expect(sha256(fs.readFileSync(join(dir, 'events.jsonl')))).toBe(
      originalHash
    )
    expect(fs.readFileSync(join(dir, 'media/old.ogg'))).toEqual(
      Buffer.from([4, 5, 6])
    )
  })

  it('rejects legacy record beyond 128MiB by bounded streaming without deleting it', () => {
    const dir = volume([])
    const fd = fs.openSync(join(dir, 'events.jsonl'), 'w')
    const block = Buffer.alloc(1024 * 1024, 120)
    for (let i = 0; i < 129; i++) fs.writeSync(fd, block)
    fs.writeSync(fd, '\n')
    fs.closeSync(fd)
    expect(() => [...lines(join(dir, 'events.jsonl'), MAX_V1_LINE)]).toThrow(
      'Record exceeds replay budget'
    )
    expect(fs.statSync(join(dir, 'events.jsonl')).size).toBe(
      129 * 1024 * 1024 + 1
    )
  })

  it('retains migration backup and a failed candidate when manifest publication fails', () => {
    const dir = volume(fixture())
    const original = fs.readFileSync(join(dir, 'events.jsonl'))
    const store = new ShiftStore(dir, {
      legacySession: 'synthetic-session',
      io: {
        checkpoint: (point) => {
          if (point === 'before_manifest_rename')
            throw new Error('synthetic manifest failure')
        }
      }
    })
    expect(store.storageAvailable).toBe(false)
    expect(fs.existsSync(join(dir, 'journal/manifest.json'))).toBe(false)
    expect(
      fs.readdirSync(join(dir, 'recovery')).some((p) => p.startsWith('backup-'))
    ).toBe(true)
    expect(fs.readdirSync(join(dir, 'journal/manifests'))).toContain(
      'revision-1.json'
    )
    store.close()
    expect(fs.readFileSync(join(dir, 'events.jsonl'))).toEqual(original)
    // An abandoned complete manifest is not adopted automatically.
    const retry = new ShiftStore(dir, { legacySession: 'synthetic-session' })
    expect(retry.storageAvailable).toBe(false)
    retry.close()
  })

  it('keeps new V1-style confirmation flags from activating tasks pending strict V2 domain integration', () => {
    const store = new ShiftStore()
    const events = fixture().slice(0, 4)
    for (const e of events) store.append(e)
    store.append({
      type: 'task_created',
      at: AT,
      task: { ...task(1, 'n1'), remindedCount: 0 }
    })
    store.append({ type: 'note_confirmed', at: AT, noteId: 'n1' })
    expect(store.note('n1')?.confirmed).toBe(true)
    expect(store.openTasks()).toEqual([])
    expect(store.taskProjectionState(1)).toBe('draft')
    expect(() =>
      store.append({ type: 'task_reminded', at: AT, number: 1 })
    ).toThrow('V2 confirmation/reservation proof required')
    store.close()
  })
})
