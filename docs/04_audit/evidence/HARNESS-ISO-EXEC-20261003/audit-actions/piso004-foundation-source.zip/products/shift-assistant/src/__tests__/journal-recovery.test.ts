// @vitest-environment node
import * as fs from 'node:fs'
import { tmpdir } from 'node:os'
import { spawnSync } from 'node:child_process'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { describe, expect, it } from 'vitest'
import { ShiftStore, type CommitRequest } from '../store.ts'
import {
  canonical,
  sha256,
  MAX_V2_LINE,
  type JournalManifest,
  type JournalIO
} from '../journal.ts'
import type { ShiftEvent } from '../domain.ts'

const AT = '2026-10-03T12:00:00.000Z'
const PHONE = '5511900000001'
const cache = fs.mkdtempSync(join(tmpdir(), 'cvg-piso004-recovery-'))
fs.mkdirSync(join(cache, 'volumes'), { recursive: true })
function volume(): string {
  return fs.mkdtempSync(join(cache, 'volumes/recovery-'))
}
function received(id = 'm1'): ShiftEvent {
  return {
    type: 'message_received',
    at: AT,
    message: {
      provider: 'waha',
      messageId: id,
      fromPhone: PHONE,
      kind: 'text',
      text: 'texto sintético',
      receivedAt: AT
    }
  }
}
function request(id = 'm1'): CommitRequest {
  return {
    transitionId: 'input:' + id,
    expected: { inbox: { [id]: 0 } },
    changes: [received(id)]
  }
}
function manifest(dir: string): JournalManifest {
  return JSON.parse(fs.readFileSync(join(dir, 'journal/manifest.json'), 'utf8'))
}
function active(dir: string): string {
  return join(dir, manifest(dir).segments.at(-1)!.path)
}

describe('journal foundation through ShiftStore', () => {
  it('persists one canonical LF transaction, guards revisions, and returns original idempotent result after reopen', () => {
    const dir = volume()
    const store = new ShiftStore(dir)
    expect(store.storageAvailable).toBe(true)
    const result = store.commit(request())
    expect(
      store.commit({ ...request(), expected: { inbox: { m1: 999 } } })
    ).toEqual(result)
    expect(store.sequence).toBe(1)
    const line = fs.readFileSync(active(dir), 'utf8')
    expect(line.endsWith('\n')).toBe(true)
    const record = JSON.parse(line)
    const { sha256: checksum, ...body } = record
    expect(checksum).toBe(sha256(canonical(body)))
    expect(line).toBe(canonical(record) + '\n')
    expect(record.seq).toBe(1)
    expect(() =>
      store.commit({
        ...request(),
        changes: [{ ...received(), at: '2026-10-03T12:01:00Z' }]
      })
    ).toThrow('IDEMPOTENCY_CONFLICT')
    expect(() =>
      store.commit({ ...request('m2'), expected: { inbox: { m2: 1 } } })
    ).toThrow('STATE_CONFLICT')
    const copies = store.unprocessedMessages()
    expect(Object.isFrozen(copies[0])).toBe(true)
    expect(() => {
      copies[0]!.text = 'alterado'
    }).toThrow()
    store.close()
    const reopened = new ShiftStore(dir)
    expect(reopened.commit(request())).toEqual(result)
    expect(reopened.sequence).toBe(1)
    expect(reopened.unprocessedMessages()[0]!.text).toBe('texto sintético')
    reopened.close()
  })

  it('rejects concurrent writers until explicit close, retains dead locks, and never steals by PID/TTL', () => {
    const dir = volume()
    const first = new ShiftStore(dir)
    const lock = JSON.parse(fs.readFileSync(join(dir, 'store.lock'), 'utf8'))
    expect(lock.pid).toBe(process.pid)
    expect(lock.bootId).toMatch(/^[a-f0-9-]+$/)
    expect(fs.statSync(join(dir, 'store.lock')).mode & 0o777).toBe(0o600)
    expect(() => new ShiftStore(dir)).toThrow('STORE_LOCKED')
    first.close()
    first.close()
    const second = new ShiftStore(dir)
    second.close()
    fs.writeFileSync(
      join(dir, 'store.lock'),
      '{"instanceId":"synthetic-dead","pid":2147483647,"bootId":"old"}'
    )
    expect(() => new ShiftStore(dir)).toThrow('STORE_LOCKED')
  })

  it('handles real short writes including LF and syncs before publishing any batch state', () => {
    const dir = volume()
    let armed = false
    let observed = false
    const io: JournalIO = {
      write: (fd, bytes, offset, length) =>
        fs.writeSync(fd, bytes, offset, Math.min(7, length)),
      sync: (fd) => {
        if (armed) {
          observed = true
          expect(store.hasMessage('m1')).toBe(false)
          expect(store.note('n1')).toBeUndefined()
        }
        fs.fsyncSync(fd)
      }
    }
    const store = new ShiftStore(dir, { io })
    armed = true
    store.commit({
      transitionId: 'batch',
      expected: { inbox: { m1: 0 }, notes: { n1: 0 } },
      changes: [
        received(),
        {
          type: 'note_created',
          at: AT,
          note: {
            id: 'n1',
            messageId: 'm1',
            authorPhone: PHONE,
            createdAt: AT,
            kind: 'text',
            rawText: 'fonte sintética',
            confirmed: false,
            unverifiedNumbers: []
          }
        }
      ]
    })
    armed = false
    expect(observed).toBe(true)
    expect(store.note('n1')?.confirmed).toBe(false)
    store.close()
    const reopened = new ShiftStore(dir)
    expect(reopened.hasMessage('m1')).toBe(true)
    expect(reopened.note('n1')?.rawText).toBe('fonte sintética')
    reopened.close()
  })

  it('does not publish on fsync failure after LF; reopen validates and syncs the ambiguous complete commit', () => {
    const dir = volume()
    let armed = false
    const store = new ShiftStore(dir, {
      io: {
        sync: (fd) => {
          if (armed) throw new Error('synthetic sync failure')
          fs.fsyncSync(fd)
        }
      }
    })
    armed = true
    expect(() => store.commit(request())).toThrow('STORAGE_UNAVAILABLE')
    expect(store.storageAvailable).toBe(false)
    expect(store.hasMessage('m1')).toBe(false)
    expect(store.sequence).toBe(0)
    expect(() => store.append(received('m2'))).toThrow('STORAGE_UNAVAILABLE')
    store.close()
    const reopened = new ShiftStore(dir)
    expect(reopened.storageAvailable).toBe(true)
    expect(reopened.hasMessage('m1')).toBe(true)
    expect(reopened.commit(request()).seq).toBe(1)
    reopened.close()
  })

  it('does not publish after a real partial write and retains the original/tail when reopening', () => {
    const dir = volume()
    let armed = false
    let wrote = false
    const store = new ShiftStore(dir, {
      io: {
        write: (fd, bytes, offset, length) => {
          if (armed && wrote) throw new Error('synthetic write failure')
          if (armed) wrote = true
          return fs.writeSync(
            fd,
            bytes,
            offset,
            armed ? Math.min(13, length) : length
          )
        }
      }
    })
    const original = active(dir)
    armed = true
    expect(() => store.commit(request())).toThrow('STORAGE_UNAVAILABLE')
    expect(store.hasMessage('m1')).toBe(false)
    store.close()
    const originalBytes = fs.readFileSync(original)
    const reopened = new ShiftStore(dir)
    expect(reopened.storageAvailable).toBe(true)
    expect(reopened.hasMessage('m1')).toBe(false)
    const recovered = manifest(dir).pendingRecovery!
    expect(fs.readFileSync(original)).toEqual(originalBytes)
    expect(fs.readFileSync(join(dir, recovered.copyPath))).toEqual(
      originalBytes
    )
    expect(fs.readFileSync(join(dir, recovered.tailPath))).toEqual(
      originalBytes
    )
    expect(reopened.commit(request()).seq).toBe(2) // recovery_recorded, then retried input
    reopened.close()
    const twice = new ShiftStore(dir)
    expect(twice.sequence).toBe(2)
    expect(twice.hasMessage('m1')).toBe(true)
    twice.close()
  })

  it.each(['{"complete":"but no LF"}', '{"incomplete":', 'invalid-tail-utf8'])(
    'isolates nondelimited tail %s without parsing it or changing original bytes',
    (tail) => {
      const dir = volume()
      const first = new ShiftStore(dir)
      first.append(received())
      first.close()
      const original = active(dir)
      fs.appendFileSync(
        original,
        tail === 'invalid-tail-utf8' ? Buffer.from([0xff, 0xfe]) : tail
      )
      const digest = sha256(fs.readFileSync(original))
      const reopened = new ShiftStore(dir)
      expect(reopened.storageAvailable).toBe(true)
      expect(reopened.hasMessage('m1')).toBe(true)
      expect(manifest(dir).segments).toHaveLength(2)
      expect(sha256(fs.readFileSync(original))).toBe(digest)
      expect(manifest(dir).pendingRecovery?.originalSha256).toBe(digest)
      reopened.close()
    }
  )

  it.each([
    'bad-json',
    'bad-utf8',
    'checksum',
    'sequence',
    'unknown-event',
    'blank-line'
  ])(
    'blocks a delimited %s record, exposes only the valid prefix, and does not skip to later lines',
    (mode) => {
      const dir = volume()
      const first = new ShiftStore(dir)
      first.append(received())
      first.close()
      const path = active(dir)
      const good = fs.readFileSync(path, 'utf8')
      let bad: string | Buffer = '{bad}\n'
      if (mode === 'bad-utf8') bad = Buffer.from([0xff, 10])
      if (mode === 'blank-line') bad = '\n'
      if (
        mode === 'checksum' ||
        mode === 'sequence' ||
        mode === 'unknown-event'
      ) {
        const record = JSON.parse(good)
        record.seq = mode === 'sequence' ? 3 : 2
        record.prevSha256 = record.sha256
        record.transitionId = 'bad'
        if (mode === 'unknown-event')
          record.changes = [{ type: 'invented', at: AT }]
        const { sha256: old, ...body } = record
        void old
        record.sha256 =
          mode === 'checksum' ? '0'.repeat(64) : sha256(canonical(body))
        bad = canonical(record) + '\n'
      }
      fs.appendFileSync(path, bad)
      fs.appendFileSync(path, good)
      const before = fs.readFileSync(path)
      const reopened = new ShiftStore(dir)
      expect(reopened.storageAvailable).toBe(false)
      expect(reopened.sequence).toBe(1)
      expect(reopened.hasMessage('m1')).toBe(true)
      expect(() => reopened.append(received('new'))).toThrow(
        'STORAGE_UNAVAILABLE'
      )
      expect(fs.readFileSync(path)).toEqual(before)
      expect(manifest(dir).segments).toHaveLength(1)
      reopened.close()
    }
  )

  it('replays multiple independent tail recoveries and validates the retained tail copies', () => {
    const dir = volume()
    let store = new ShiftStore(dir)
    store.append(received())
    store.close()
    fs.appendFileSync(active(dir), 'first-tail')
    store = new ShiftStore(dir)
    expect(store.storageAvailable).toBe(true)
    store.close()
    const firstRecovery = manifest(dir).pendingRecovery!
    fs.appendFileSync(active(dir), 'second-tail')
    store = new ShiftStore(dir)
    expect(store.storageAvailable).toBe(true)
    store.close()
    store = new ShiftStore(dir)
    expect(store.storageAvailable).toBe(true)
    expect(store.sequence).toBe(3)
    store.close()
    fs.writeFileSync(join(dir, firstRecovery.tailPath), 'bad-bytes!')
    store = new ShiftStore(dir)
    expect(store.storageAvailable).toBe(false)
    store.close()
  })

  it.each([
    'recovery_copies_synced',
    'before_manifest_rename',
    'after_manifest_rename'
  ])(
    'fails closed when recovery checkpoint %s fails and retains originals',
    (point) => {
      const dir = volume()
      const first = new ShiftStore(dir)
      first.append(received())
      first.close()
      const original = active(dir)
      fs.appendFileSync(original, 'retained-tail')
      const before = fs.readFileSync(original)
      const store = new ShiftStore(dir, {
        io: {
          checkpoint: (p) => {
            if (p === point) throw new Error('synthetic manifest failure')
          }
        }
      })
      expect(store.storageAvailable).toBe(false)
      expect(store.hasMessage('m1')).toBe(true)
      expect(() => store.append(received('m2'))).toThrow('STORAGE_UNAVAILABLE')
      expect(fs.readFileSync(original)).toEqual(before)
      expect(fs.readdirSync(join(dir, 'recovery')).length).toBeGreaterThan(0)
      store.close()
      if (point === 'after_manifest_rename') {
        const reopened = new ShiftStore(dir)
        expect(reopened.storageAvailable).toBe(true)
        expect(reopened.sequence).toBe(2)
        reopened.close()
      }
    }
  )

  it('retains a partial operational lock and closes its descriptor after lock-write failure', () => {
    const dir = volume()
    let wrote = false
    const store = new ShiftStore(dir, {
      io: {
        write: (fd, bytes, offset, length) => {
          if (wrote) throw new Error('synthetic lock-write failure')
          wrote = true
          return fs.writeSync(fd, bytes, offset, Math.min(5, length))
        }
      }
    })
    expect(store.storageAvailable).toBe(false)
    expect(() => store.close()).not.toThrow()
    expect(fs.readFileSync(join(dir, 'store.lock')).length).toBe(5)
    expect(() => new ShiftStore(dir)).toThrow('STORE_LOCKED')
  })

  it.each(['before_manifest_rename', 'after_manifest_rename'])(
    'retains recovery artifacts after a real child SIGKILL at %s',
    (point) => {
      const dir = volume()
      const first = new ShiftStore(dir)
      first.append(received())
      first.close()
      const original = active(dir)
      fs.appendFileSync(original, 'retained-tail')
      const before = fs.readFileSync(original)
      const module = new URL('../store.ts', import.meta.url).href
      const code =
        'import { ShiftStore } from ' +
        JSON.stringify(module) +
        '; new ShiftStore(' +
        JSON.stringify(dir) +
        ', {io:{checkpoint(p){if(p===' +
        JSON.stringify(point) +
        ')process.kill(process.pid,"SIGKILL")}}});'
      const child = spawnSync(
        process.execPath,
        ['--import', 'tsx', '--input-type=module', '-e', code],
        {
          cwd: dirname(dirname(fileURLToPath(import.meta.url))),
          encoding: 'utf8',
          timeout: 15000
        }
      )
      expect(child.signal, child.stderr).toBe('SIGKILL')
      expect(() => new ShiftStore(dir)).toThrow('STORE_LOCKED')
      fs.writeFileSync(
        join(dir, 'operator-lock-recovery.json'),
        JSON.stringify({
          actor: 'synthetic-operator',
          previousChildExited: true,
          signal: child.signal,
          point
        })
      )
      fs.unlinkSync(join(dir, 'store.lock'))
      const reopened = new ShiftStore(dir)
      expect(reopened.storageAvailable).toBe(point === 'after_manifest_rename')
      expect(fs.readFileSync(original)).toEqual(before)
      expect(fs.readdirSync(join(dir, 'recovery')).length).toBeGreaterThan(0)
      reopened.close()
      fs.writeFileSync(
        join(dir, 'sigkill-result.json'),
        JSON.stringify({
          point,
          status: child.status,
          signal: child.signal,
          availableAfterRestart: point === 'after_manifest_rename',
          manifest: manifest(dir)
        })
      )
    }
  )

  it('applies the strict schema, finite/undefined checks, reference guards, and line bound in memory too', () => {
    for (const dir of [undefined, volume()]) {
      const store = new ShiftStore(dir)
      expect(() =>
        store.commit({
          ...request(),
          changes: [{ ...received(), alien: true } as unknown as ShiftEvent]
        })
      ).toThrow()
      expect(() =>
        store.commit({
          ...request(),
          changes: [
            { ...received(), extra: undefined } as unknown as ShiftEvent
          ]
        })
      ).toThrow()
      expect(() =>
        store.commit({
          ...request(),
          changes: [{ type: 'task_done', at: AT, number: NaN }]
        })
      ).toThrow()
      expect(() =>
        store.commit({
          transitionId: 'ref',
          expected: { notes: { missing: 0 } },
          changes: [{ type: 'note_confirmed', at: AT, noteId: 'missing' }]
        })
      ).toThrow('STATE_CONFLICT')
      const big = received()
      if (big.type === 'message_received')
        big.message.text = 'x'.repeat(MAX_V2_LINE)
      expect(() => store.commit({ ...request(), changes: [big] })).toThrow()
      const inline = received()
      if (inline.type === 'message_received')
        inline.message.mediaRef = 'base64:AA=='
      expect(() => store.commit({ ...request(), changes: [inline] })).toThrow(
        'Inline media'
      )
      expect(store.sequence).toBe(0)
      store.close()
    }
  })

  it('publishes opaque synced media/sidecar, retains orphans, and rejects missing/corrupt referenced media', () => {
    const dir = volume()
    const store = new ShiftStore(dir)
    const name = store.saveMedia(
      '../../untrusted.png',
      new Uint8Array([1, 2, 3])
    )
    expect(name).toMatch(/^[a-f0-9-]+\.png$/)
    const path = join(dir, 'media', name)
    expect(fs.readFileSync(path)).toEqual(Buffer.from([1, 2, 3]))
    expect(JSON.parse(fs.readFileSync(path + '.json', 'utf8')).sha256).toBe(
      sha256(new Uint8Array([1, 2, 3]))
    )
    expect(store.mediaInventory().valid).toHaveLength(1)
    store.append(received())
    store.append({
      type: 'note_created',
      at: AT,
      note: {
        id: 'n1',
        messageId: 'm1',
        authorPhone: PHONE,
        createdAt: AT,
        kind: 'image',
        rawText: '',
        mediaFile: name,
        confirmed: false,
        unverifiedNumbers: []
      }
    })
    store.close()
    fs.writeFileSync(path, 'corrupt')
    const reopened = new ShiftStore(dir)
    expect(reopened.storageAvailable).toBe(false)
    expect(reopened.note('n1')).toBeUndefined()
    expect(fs.existsSync(path + '.json')).toBe(true)
    reopened.close()
  })

  it('retains partial media when interrupted after file sync and never treats it as usable', () => {
    const dir = volume()
    let armed = false
    const store = new ShiftStore(dir, {
      io: {
        checkpoint: (point) => {
          if (armed && point === 'after_media_sync')
            throw new Error('synthetic crash')
        }
      }
    })
    armed = true
    expect(() =>
      store.saveMedia('untrusted.ogg', new Uint8Array([1, 2, 3]))
    ).toThrow('STORAGE_UNAVAILABLE')
    expect(store.mediaInventory().valid).toHaveLength(0)
    expect(
      store.mediaInventory().retained.some((p) => p.endsWith('.tmp'))
    ).toBe(true)
    store.close()
  })

  it('fails closed on conflicting manifest copies and oversized delimited lines', () => {
    for (const variant of ['manifest', 'line']) {
      const dir = volume()
      const store = new ShiftStore(dir)
      store.close()
      if (variant === 'manifest') {
        const copy = manifest(dir)
        copy.journalId = '00000000-0000-4000-8000-000000000000'
        fs.writeFileSync(join(dir, 'journal/manifest.json'), canonical(copy))
      } else fs.appendFileSync(active(dir), 'x'.repeat(MAX_V2_LINE + 1) + '\n')
      const reopened = new ShiftStore(dir)
      expect(reopened.storageAvailable).toBe(false)
      reopened.close()
    }
  })

  it.each([
    'before_journal_write',
    'before_media_write',
    'partial_write',
    'after_journal_lf',
    'after_journal_sync',
    'after_media_sync',
    'after_media_sidecar_sync'
  ])(
    'survives a real child SIGKILL at %s as an absent or complete transaction',
    (point) => {
      const dir = volume()
      const module = new URL('../store.ts', import.meta.url).href
      const code = [
        'import * as fs from "node:fs";',
        'import { ShiftStore } from ' + JSON.stringify(module) + ';',
        'let armed=false;',
        'const target=' + JSON.stringify(point) + ';',
        'const io={checkpoint(p){if(armed&&p===target)process.kill(process.pid,"SIGKILL")},write(fd,b,o,n){if(armed&&target==="partial_write"){fs.writeSync(fd,b,o,Math.min(21,n));process.kill(process.pid,"SIGKILL")}return fs.writeSync(fd,b,o,n)}};',
        'const s=new ShiftStore(' +
          JSON.stringify(dir) +
          ',{io});if(!s.storageAvailable)throw Error("startup failed");armed=true;',
        point.startsWith('after_media') || point === 'before_media_write'
          ? 's.saveMedia("audio.ogg",new Uint8Array([1,2,3]));'
          : 's.commit(' +
            JSON.stringify({
              transitionId: 'atomic-child',
              expected: {
                inbox: { m1: 0 },
                notes: { n1: 0 },
                tasks: { '1': 0 }
              },
              changes: [
                received(),
                {
                  type: 'note_created',
                  at: AT,
                  note: {
                    id: 'n1',
                    messageId: 'm1',
                    authorPhone: PHONE,
                    createdAt: AT,
                    kind: 'text',
                    rawText: 'synthetic atomic source',
                    confirmed: false,
                    unverifiedNumbers: []
                  }
                },
                {
                  type: 'task_created',
                  at: AT,
                  task: {
                    number: 1,
                    noteId: 'n1',
                    ownerPhone: PHONE,
                    description: 'synthetic atomic draft',
                    dueAt: AT,
                    createdAt: AT,
                    status: 'open',
                    remindedCount: 0
                  }
                }
              ]
            }) +
            ');'
      ].join('\n')
      const child = spawnSync(
        process.execPath,
        ['--import', 'tsx', '--input-type=module', '-e', code],
        {
          cwd: dirname(dirname(fileURLToPath(import.meta.url))),
          encoding: 'utf8',
          timeout: 15000
        }
      )
      expect(child.signal, child.stderr).toBe('SIGKILL')
      expect(child.status).toBeNull()
      expect(() => new ShiftStore(dir)).toThrow('STORE_LOCKED')
      // Synthetic operator test decision only after spawnSync proves that the owned child exited.
      fs.writeFileSync(
        join(dir, 'operator-lock-recovery.json'),
        JSON.stringify({
          actor: 'synthetic-operator',
          previousChildExited: true,
          signal: child.signal,
          decision: 'remove residual operational lock',
          point
        })
      )
      fs.unlinkSync(join(dir, 'store.lock'))
      const reopened = new ShiftStore(dir)
      expect(reopened.storageAvailable, reopened.diagnostic).toBe(true)
      const committed =
        point === 'after_journal_lf' || point === 'after_journal_sync'
      expect(reopened.hasMessage('m1')).toBe(committed)
      expect(Boolean(reopened.note('n1'))).toBe(committed)
      expect(Boolean(reopened.task(1))).toBe(committed)
      expect(reopened.openTasks()).toEqual([])
      if (committed) expect(reopened.sequence).toBe(1)
      if (point === 'after_media_sync')
        expect(reopened.mediaInventory().valid).toHaveLength(0)
      if (point === 'after_media_sidecar_sync')
        expect(reopened.mediaInventory().valid).toHaveLength(1)
      reopened.close()
      fs.writeFileSync(
        join(dir, 'sigkill-result.json'),
        JSON.stringify({
          point,
          status: child.status,
          signal: child.signal,
          committed,
          manifest: manifest(dir)
        })
      )
    }
  )
})
