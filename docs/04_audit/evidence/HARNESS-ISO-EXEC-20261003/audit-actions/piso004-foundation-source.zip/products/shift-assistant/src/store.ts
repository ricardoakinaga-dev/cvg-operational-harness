import { randomUUID } from 'node:crypto'
import {
  Journal,
  ShiftEventSchema,
  StoreError,
  canonical,
  sha256,
  MAX_V2_LINE,
  type JournalEvent,
  type JournalTransaction,
  type JournalIO,
  type MigrationRecord,
  type MediaDescriptor
} from './journal.ts'
import {
  prepareMigration,
  replayLegacy,
  mimeForExtension,
  type MigrationOptions
} from './migrate-journal.ts'
import {
  type InboundMessage,
  type KnownPatient,
  type Note,
  type ShiftEvent,
  type Task
} from './domain.ts'

/**
 * State rebuilt from an append-only JSONL event log. The log is the document
 * of record (decision D4): nothing is rewritten or deleted here.
 */
export class ShiftStore {
  readonly #journal: Journal | undefined
  readonly #memoryMedia = new Map<string, MediaDescriptor>()
  readonly #results = new Map<string, { hash: string; result: CommitResult }>()
  readonly #revisions = new Map<string, number>()
  #migration: MigrationRecord | undefined
  #available = true
  #closed = false
  #seq = 0
  readonly #messages = new Map<string, InboundMessage>()
  readonly #processed = new Set<string>()
  readonly #notes = new Map<string, Note>()
  readonly #tasks = new Map<number, Task>()
  #paused = false

  /** Persistent mode owns an exclusive process lock until close(). */
  constructor(dataDir?: string, options: StoreOptions = {}) {
    if (dataDir) {
      this.#journal = new Journal(dataDir, options.io)
      try {
        this.#journal.assertWritable()
        if (!this.#journal.manifest) {
          const migration = prepareMigration(this.#journal, options, (event) =>
            this.#applyLegacy(event)
          )
          this.#journal.initialize(
            migration?.legacy,
            migration?.record,
            migration?.recovery
          )
          this.#migration = migration?.record
        } else {
          this.#migration = this.#journal.manifest.migration
          replayLegacy(this.#journal, (event) => this.#applyLegacy(event))
        }
        this.#journal.replay((transaction) => this.#replay(transaction))
        const migration = this.#journal.manifest!.migration
        if (migration && !this.#journal.transitions.has(migration.id)) {
          const changes: JournalEvent[] = [
            {
              type: 'migration_applied',
              at: new Date().toISOString(),
              migration
            }
          ]
          this.#replay(this.#journal.append(migration.id, changes))
        }
      } catch (error) {
        this.#journal.fail(error)
        this.#available = false
      }
    }
  }

  get storageAvailable(): boolean {
    return (
      this.#available && !this.#closed && (this.#journal?.available ?? true)
    )
  }

  get diagnostic(): string | undefined {
    return this.#journal?.diagnostic
  }
  get operationalHold(): boolean {
    return this.#migration?.operationalHold ?? false
  }
  get effectsAllowed(): boolean {
    return this.storageAvailable && !this.operationalHold && !this.#paused
  }
  get sequence(): number {
    return this.#seq
  }
  get migration(): Readonly<MigrationRecord> | undefined {
    return this.#migration ? immutable(this.#migration) : undefined
  }

  revision(entity: RevisionEntity, id: string | number): number {
    return this.#revisions.get(entity + ':' + id) ?? 0
  }

  commit(request: CommitRequest): CommitResult {
    if (!this.storageAvailable) throw new StoreError('STORAGE_UNAVAILABLE')
    if (
      !request.transitionId ||
      !Array.isArray(request.changes) ||
      !request.changes.length
    )
      throw new StoreError('INVALID_TRANSITION')
    // Check canonical input before parsing; Zod must not silently strip undefined/unknown properties.
    canonical(request)
    const changes = request.changes.map((event) =>
      ShiftEventSchema.parse(event)
    )
    const digest = sha256(canonical(changes))
    const previous = this.#results.get(request.transitionId)
    if (previous) {
      if (previous.hash !== digest) throw new StoreError('IDEMPOTENCY_CONFLICT')
      return immutable(previous.result)
    }
    this.#checkExpected(request.expected, changes)
    this.#validate(changes)
    const estimated =
      Buffer.byteLength(
        canonical({
          v: 2,
          seq: this.#seq + 1,
          transitionId: request.transitionId,
          at: changes[0]!.at,
          prevSha256: '0'.repeat(64),
          changes,
          sha256: '0'.repeat(64)
        })
      ) + 1
    if (estimated > MAX_V2_LINE)
      throw new StoreError('INVALID_TRANSITION', 'Record exceeds V2 budget')
    let transaction: JournalTransaction
    if (this.#journal)
      transaction = this.#journal.append(request.transitionId, changes)
    else {
      const body = {
        v: 2 as const,
        seq: this.#seq + 1,
        transitionId: request.transitionId,
        at: changes[0]!.at,
        prevSha256: this.#memoryHead,
        changes
      }
      transaction = { ...body, sha256: sha256(canonical(body)) }
      this.#memoryHead = transaction.sha256
    }
    this.#publish(transaction)
    return immutable({ seq: transaction.seq, sha256: transaction.sha256 })
  }
  #memoryHead = sha256('')

  /** Compatibility entry point: still uses schema, guards, one LF and fsync. */
  append(event: ShiftEvent): void {
    const expected: CommitExpected = {}
    for (const [entity, id] of affected(event)) {
      const revisions = expected[entity] ?? {}
      revisions[String(id)] = this.revision(entity, id)
      expected[entity] = revisions
    }
    this.commit({
      transitionId: 'compat:' + randomUUID(),
      expected,
      changes: [event]
    })
  }

  /** Compatibility name is only an extension hint; destination is always generated. */
  saveMedia(name: string, bytes: Uint8Array): string {
    if (!this.storageAvailable) throw new StoreError('STORAGE_UNAVAILABLE')
    const mime = mimeForExtension(name)
    return this.saveMediaDescriptor(
      bytes,
      mime,
      JSON.stringify(['compat-media', randomUUID()])
    ).path.slice('media/'.length)
  }

  saveMediaDescriptor(
    bytes: Uint8Array,
    mime: MediaDescriptor['mime'],
    messageKey: string
  ): Readonly<MediaDescriptor> {
    if (!this.storageAvailable) throw new StoreError('STORAGE_UNAVAILABLE')
    if (this.#journal)
      return immutable(this.#journal.saveMedia(bytes, mime, messageKey))
    const map: Record<MediaDescriptor['mime'], string> = {
      'audio/ogg': 'ogg',
      'audio/mpeg': 'mp3',
      'audio/mp4': 'm4a',
      'audio/wav': 'wav',
      'image/jpeg': 'jpg',
      'image/png': 'png',
      'application/octet-stream': 'bin'
    }
    if (!map[mime] || !messageKey) throw new StoreError('INVALID_TRANSITION')
    const descriptor: MediaDescriptor = {
      messageKey,
      mime,
      bytes: bytes.length,
      sha256: sha256(bytes),
      path: 'media/' + randomUUID() + '.' + map[mime],
      stage: 'published'
    }
    this.#memoryMedia.set(descriptor.path, descriptor)
    return immutable(descriptor)
  }

  mediaInventory(): { valid: Readonly<MediaDescriptor>[]; retained: string[] } {
    return immutable(
      this.#journal?.mediaInventory() ?? {
        valid: [...this.#memoryMedia.values()],
        retained: []
      }
    )
  }

  close(): void {
    if (this.#closed) return
    this.#closed = true
    this.#journal?.close()
  }

  #checkExpected(
    expected: CommitExpected,
    changes: readonly JournalEvent[]
  ): void {
    const all = new Map<string, [RevisionEntity, string | number]>()
    for (const event of changes)
      for (const [entity, id] of affected(event))
        all.set(entity + ':' + id, [entity, id])
    for (const [entity, revisions] of Object.entries(expected)) {
      if (!['inbox', 'notes', 'tasks', 'outbox', 'operation'].includes(entity))
        throw new StoreError('INVALID_TRANSITION')
      for (const [id, revision] of Object.entries(revisions)) {
        if (!Number.isSafeInteger(revision) || revision < 0)
          throw new StoreError('INVALID_TRANSITION')
        if (this.revision(entity as RevisionEntity, id) !== revision)
          throw new StoreError('STATE_CONFLICT')
      }
    }
    for (const [entity, id] of all.values()) {
      if (expected[entity]?.[String(id)] !== this.revision(entity, id))
        throw new StoreError('STATE_CONFLICT')
    }
  }

  #validate(changes: readonly JournalEvent[]): void {
    const messages = new Map(this.#messages)
    const notes = structuredClone(this.#notes)
    const tasks = structuredClone(this.#tasks)
    const processed = new Set(this.#processed)
    for (const event of changes) {
      if (event.type === 'message_received') {
        if (
          event.message.mediaRef?.startsWith('base64:') ||
          event.message.mediaRef?.startsWith('data:')
        )
          throw new StoreError(
            'INVALID_TRANSITION',
            'Inline media requires envelope admission'
          )
        if (messages.has(event.message.messageId))
          throw new StoreError('STATE_CONFLICT')
        if (event.message.mediaRef?.startsWith('media/'))
          this.#verifyMedia(event.message.mediaRef)
        messages.set(event.message.messageId, event.message)
      } else if (event.type === 'message_processed') {
        if (!messages.has(event.messageId) || processed.has(event.messageId))
          throw new StoreError('STATE_CONFLICT')
        processed.add(event.messageId)
      } else if (event.type === 'note_created') {
        if (
          notes.has(event.note.id) ||
          !messages.has(event.note.messageId) ||
          messages.get(event.note.messageId)!.fromPhone !==
            event.note.authorPhone
        )
          throw new StoreError('STATE_CONFLICT')
        if (event.note.confirmed || event.note.supersededBy)
          throw new StoreError('INVALID_TRANSITION')
        if (event.note.mediaFile)
          this.#verifyMedia('media/' + event.note.mediaFile)
        notes.set(event.note.id, structuredClone(event.note))
      } else if (event.type === 'note_confirmed') {
        const note = notes.get(event.noteId)
        if (
          !note ||
          note.confirmed ||
          note.supersededBy ||
          note.unverifiedNumbers.length
        )
          throw new StoreError('STATE_CONFLICT')
        // The V1 flag is historical only; it is never V2 proof of preview/binding approval.
        note.confirmed = true
      } else if (event.type === 'note_superseded') {
        const note = notes.get(event.noteId)
        if (
          !note ||
          note.supersededBy ||
          !notes.has(event.by) ||
          event.by === event.noteId
        )
          throw new StoreError('STATE_CONFLICT')
        note.supersededBy = event.by
      } else if (event.type === 'task_created') {
        if (
          tasks.has(event.task.number) ||
          event.task.number !== maxTaskNumber(tasks.keys()) + 1 ||
          (event.task.noteId && !notes.has(event.task.noteId))
        )
          throw new StoreError('STATE_CONFLICT')
        if (
          event.task.noteId &&
          notes.get(event.task.noteId)!.authorPhone !== event.task.ownerPhone
        )
          throw new StoreError('STATE_CONFLICT')
        if (event.task.status !== 'open' || event.task.remindedCount !== 0)
          throw new StoreError('INVALID_TRANSITION')
        tasks.set(event.task.number, structuredClone(event.task))
      } else if (
        event.type === 'task_done' ||
        event.type === 'task_cancelled' ||
        event.type === 'task_snoozed' ||
        event.type === 'task_reminded'
      ) {
        const task = tasks.get(event.number)
        if (!task || task.status !== 'open')
          throw new StoreError('STATE_CONFLICT')
        if (event.type === 'task_reminded')
          throw new StoreError(
            'INVALID_TRANSITION',
            'V2 confirmation/reservation proof required'
          )
        if (event.type === 'task_done') task.status = 'done'
        if (event.type === 'task_cancelled') task.status = 'cancelled'
        if (event.type === 'task_snoozed') {
          task.dueAt = event.dueAt
          task.remindedCount = 0
        }
      } else if (event.type === 'migration_applied') {
        if (
          !this.#journal?.manifest?.migration ||
          canonical(event.migration) !==
            canonical(this.#journal.manifest.migration)
        )
          throw new StoreError('INVALID_TRANSITION')
      } else if (event.type === 'recovery_recorded') {
        if (!this.#journal) throw new StoreError('INVALID_TRANSITION')
        this.#journal.verifyRecovery(event)
      }
    }
  }

  #verifyMedia(path: string): void {
    if (this.#journal) {
      try {
        this.#journal.verifyMedia(path)
      } catch (error) {
        this.#journal.fail(error)
        throw new StoreError('STORAGE_UNAVAILABLE')
      }
    } else if (!this.#memoryMedia.has(path))
      throw new StoreError('INVALID_TRANSITION', 'Missing media')
  }

  #applyLegacy(event: ShiftEvent): void {
    this.#apply(event)
    this.#touch(event)
  }

  #replay(transaction: JournalTransaction): void {
    this.#validate(transaction.changes)
    this.#publish(transaction)
  }

  #publish(transaction: JournalTransaction): void {
    for (const event of transaction.changes) {
      if (event.type === 'migration_applied')
        this.#migration = structuredClone(event.migration)
      else if (event.type !== 'recovery_recorded') this.#apply(event)
      this.#touch(event)
    }
    this.#seq = transaction.seq
    this.#results.set(transaction.transitionId, {
      hash: sha256(canonical(transaction.changes)),
      result: { seq: transaction.seq, sha256: transaction.sha256 }
    })
  }

  #touch(event: JournalEvent): void {
    for (const [entity, id] of affected(event)) {
      const key = entity + ':' + id
      this.#revisions.set(key, (this.#revisions.get(key) ?? 0) + 1)
    }
  }

  hasMessage(messageId: string): boolean {
    return this.#messages.has(messageId)
  }

  unprocessedMessages(): InboundMessage[] {
    return immutable(
      [...this.#messages.values()].filter(
        (message) =>
          !this.#processed.has(message.messageId) &&
          !this.#migration?.messages.some(
            (m) => m.messageId === message.messageId
          )
      )
    )
  }

  note(id: string): Note | undefined {
    const note = this.#notes.get(id)
    return note ? immutable(note) : undefined
  }

  lastActiveNote(authorPhone: string): Note | undefined {
    return immutable(
      [...this.#notes.values()]
        .filter(
          (note) => note.authorPhone === authorPhone && !note.supersededBy
        )
        .at(-1)
    )
  }

  /**
   * Patients with an ID seen in active notes, most recent first. Phase 1 has
   * no HIS access, so this is the assistant's only memory of who is who.
   */
  knownPatients(name: string): KnownPatient[] {
    void name
    // Activated only by the future strict V2 confirmation/binding event.
    return []
  }

  task(number: number): Task | undefined {
    const task = this.#tasks.get(number)
    return task ? immutable(task) : undefined
  }

  openTasks(ownerPhone?: string): Task[] {
    void ownerPhone
    // All current events are V1: neither that flag nor migration can activate effects.
    return []
  }

  taskProjectionState(
    number: number
  ): 'draft' | 'legacy_review_required' | 'done' | 'cancelled' | undefined {
    const task = this.#tasks.get(number)
    if (!task) return undefined
    if (task.status !== 'open') return task.status
    return this.#migration?.heldTaskNumbers.includes(number) &&
      !this.#migration.draftTaskNumbers.includes(number)
      ? 'legacy_review_required'
      : 'draft'
  }

  nextTaskNumber(): number {
    return maxTaskNumber(this.#tasks.keys()) + 1
  }

  get paused(): boolean {
    return this.#paused
  }

  #apply(event: ShiftEvent): void {
    switch (event.type) {
      case 'message_received':
        this.#messages.set(
          event.message.messageId,
          structuredClone(event.message)
        )
        return
      case 'message_processed':
        this.#processed.add(event.messageId)
        return
      case 'note_created':
        this.#notes.set(event.note.id, structuredClone(event.note))
        return
      case 'note_confirmed': {
        const note = this.#notes.get(event.noteId)
        if (note) note.confirmed = true
        return
      }
      case 'note_superseded': {
        const note = this.#notes.get(event.noteId)
        if (note) note.supersededBy = event.by
        return
      }
      case 'task_created':
        this.#tasks.set(event.task.number, structuredClone(event.task))
        return
      case 'task_done':
        this.#updateTask(event.number, { status: 'done', doneAt: event.at })
        return
      case 'task_cancelled':
        this.#updateTask(event.number, { status: 'cancelled' })
        return
      case 'task_snoozed':
        this.#updateTask(event.number, {
          dueAt: event.dueAt,
          remindedCount: 0
        })
        return
      case 'task_reminded': {
        const task = this.#tasks.get(event.number)
        if (task) {
          task.remindedCount += 1
          task.lastRemindedAt = event.at
        }
        return
      }
      case 'paused':
        this.#paused = true
        return
      case 'resumed':
        this.#paused = false
        return
    }
  }

  #updateTask(number: number, patch: Partial<Task>): void {
    const task = this.#tasks.get(number)
    if (task) Object.assign(task, patch)
    if (task && patch.dueAt) delete task.lastRemindedAt
  }
}

export type RevisionEntity =
  | 'inbox'
  | 'notes'
  | 'tasks'
  | 'outbox'
  | 'operation'
export type CommitExpected = Partial<
  Record<RevisionEntity, Record<string, number>>
>
export interface CommitRequest {
  transitionId: string
  expected: CommitExpected
  changes: readonly ShiftEvent[]
}
export interface CommitResult {
  seq: number
  sha256: string
}
export interface StoreOptions extends MigrationOptions {
  io?: JournalIO
}

function affected(event: JournalEvent): [RevisionEntity, string | number][] {
  switch (event.type) {
    case 'message_received':
      return [['inbox', event.message.messageId]]
    case 'message_processed':
      return [['inbox', event.messageId]]
    case 'note_created':
      return [
        ['notes', event.note.id],
        ['inbox', event.note.messageId]
      ]
    case 'note_confirmed':
      return [['notes', event.noteId]]
    case 'note_superseded':
      return [
        ['notes', event.noteId],
        ['notes', event.by]
      ]
    case 'task_created':
      return [
        ['tasks', event.task.number],
        ...(event.task.noteId
          ? [['notes', event.task.noteId] as [RevisionEntity, string]]
          : [])
      ]
    case 'task_done':
    case 'task_cancelled':
    case 'task_snoozed':
    case 'task_reminded':
      return [['tasks', event.number]]
    case 'paused':
    case 'resumed':
      return [['operation', 'state']]
    case 'migration_applied':
    case 'recovery_recorded':
      return []
  }
}

function immutable<T>(value: T): T {
  const copy = structuredClone(value)
  function freeze(item: unknown): void {
    if (!item || typeof item !== 'object' || Object.isFrozen(item)) return
    for (const child of Object.values(item)) freeze(child)
    Object.freeze(item)
  }
  freeze(copy)
  return copy
}

function maxTaskNumber(numbers: Iterable<number>): number {
  let maximum = 0
  for (const number of numbers) maximum = Math.max(maximum, number)
  return maximum
}
