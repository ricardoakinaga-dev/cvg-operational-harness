import * as fs from 'node:fs'
import { createHash, randomUUID } from 'node:crypto'
import { dirname, join, resolve } from 'node:path'
import { z } from 'zod'
import { OrganizedSchema, type ShiftEvent } from './domain.ts'

export class StoreError extends Error {
  constructor(
    readonly code:
      | 'STORE_LOCKED'
      | 'STORAGE_UNAVAILABLE'
      | 'STATE_CONFLICT'
      | 'IDEMPOTENCY_CONFLICT'
      | 'INVALID_TRANSITION',
    message: string = code
  ) {
    super(message)
    this.name = code
  }
}

const text = z.string().min(1)
const date = z
  .string()
  .refine((s) => Number.isFinite(Date.parse(s)), 'Invalid timestamp')
const number = z.number().int().positive().max(Number.MAX_SAFE_INTEGER)
const kind = z.enum(['text', 'audio', 'image'])
const message = z.strictObject({
  provider: z.enum(['waha', 'evolution']),
  messageId: text,
  fromPhone: text,
  kind,
  text: z.string(),
  mediaRef: text.optional(),
  mimetype: text.optional(),
  receivedAt: date
})
const organized = OrganizedSchema.strict().extend({
  pacientes: z
    .array(
      OrganizedSchema.shape.pacientes.unwrap().element.strict().extend({
        exames_pedidos: OrganizedSchema.shape.pacientes
          .unwrap()
          .element.shape.exames_pedidos.unwrap(),
        condutas: OrganizedSchema.shape.pacientes
          .unwrap()
          .element.shape.condutas.unwrap()
      })
    )
    .max(20),
  pendencias: z
    .array(OrganizedSchema.shape.pendencias.unwrap().element.strict())
    .max(20),
  duvidas: OrganizedSchema.shape.duvidas.unwrap()
})
const note = z.strictObject({
  id: text,
  messageId: text,
  authorPhone: text,
  createdAt: date,
  kind,
  rawText: z.string(),
  mediaFile: text.optional(),
  organized: organized.optional(),
  unverifiedNumbers: z.array(z.string()),
  confirmed: z.boolean(),
  supersededBy: text.optional()
})
const task = z.strictObject({
  number,
  ownerPhone: text,
  noteId: text.optional(),
  description: text,
  patient: text.optional(),
  patientId: text.optional(),
  dueAt: date,
  createdAt: date,
  status: z.enum(['open', 'done', 'cancelled']),
  remindedCount: z.number().int().nonnegative(),
  lastRemindedAt: date.optional(),
  doneAt: date.optional()
})
/** Transitional strict schema for the existing domain union; no unknown event escape hatch. */
const shiftEventSchema = z.discriminatedUnion('type', [
  z.strictObject({ type: z.literal('message_received'), at: date, message }),
  z.strictObject({
    type: z.literal('message_processed'),
    at: date,
    messageId: text
  }),
  z.strictObject({ type: z.literal('note_created'), at: date, note }),
  z.strictObject({ type: z.literal('note_confirmed'), at: date, noteId: text }),
  z.strictObject({
    type: z.literal('note_superseded'),
    at: date,
    noteId: text,
    by: text
  }),
  z.strictObject({ type: z.literal('task_created'), at: date, task }),
  z.strictObject({ type: z.literal('task_done'), at: date, number }),
  z.strictObject({ type: z.literal('task_cancelled'), at: date, number }),
  z.strictObject({
    type: z.literal('task_snoozed'),
    at: date,
    number,
    dueAt: date
  }),
  z.strictObject({ type: z.literal('task_reminded'), at: date, number }),
  z.strictObject({ type: z.literal('paused'), at: date, by: text }),
  z.strictObject({ type: z.literal('resumed'), at: date, by: text })
])
export const ShiftEventSchema =
  shiftEventSchema as unknown as z.ZodType<ShiftEvent>
const hash = z.string().regex(/^[a-f0-9]{64}$/)
const relative = z
  .string()
  .regex(/^(?:[a-zA-Z0-9_-]+\/)*[a-zA-Z0-9_.-]+$/)
  .refine((s) => !s.split('/').some((p) => p === '.' || p === '..'))
const descriptor = z.strictObject({
  path: relative,
  bytes: z.number().int().nonnegative(),
  prefixSha256: hash,
  sealed: z.boolean(),
  fullSha256: hash.optional(),
  reason: text.optional()
})
const mediaDescriptor = z.strictObject({
  messageKey: text,
  mime: z.enum([
    'audio/ogg',
    'audio/mpeg',
    'audio/mp4',
    'audio/wav',
    'image/jpeg',
    'image/png',
    'application/octet-stream'
  ]),
  bytes: z.number().int().nonnegative(),
  sha256: hash,
  path: relative,
  stage: z.literal('published')
})
export type MediaDescriptor = z.infer<typeof mediaDescriptor>
const migration = z.strictObject({
  id: text,
  session: text,
  readerVersion: z.literal(2),
  operationalHold: z.literal(true),
  legacyReviewNoteIds: z.array(text),
  heldTaskNumbers: z.array(number),
  draftTaskNumbers: z.array(number),
  messages: z.array(
    z.strictObject({
      messageId: text,
      messageKey: text,
      state: z.enum(['review_required', 'uncertain_legacy', 'command_recorded'])
    })
  ),
  mediaMappings: z.array(
    z.strictObject({ legacyPath: relative, path: relative })
  ),
  backupPath: relative,
  inventory: z.array(
    z.strictObject({
      path: relative,
      bytes: z.number().int().nonnegative(),
      sha256: hash
    })
  )
})
export type MigrationRecord = z.infer<typeof migration>
const migrationEvent = z.strictObject({
  type: z.literal('migration_applied'),
  at: date,
  migration
})
const recoveryEvent = z.strictObject({
  type: z.literal('recovery_recorded'),
  at: date,
  originalPath: relative,
  originalSha256: hash,
  copyPath: relative,
  tailPath: relative,
  prefixBytes: z.number().int().nonnegative(),
  prefixSha256: hash,
  reason: z.literal('NONDELIMITED_TAIL')
})
export const JournalEventSchema = z.union([
  ShiftEventSchema,
  migrationEvent,
  recoveryEvent
])
export type JournalEvent = z.infer<typeof JournalEventSchema>
const transactionSchema = z.strictObject({
  v: z.literal(2),
  seq: number,
  transitionId: text,
  at: date,
  prevSha256: hash,
  changes: z.array(JournalEventSchema).min(1),
  sha256: hash
})
export type JournalTransaction = z.infer<typeof transactionSchema>
const manifestSchema = z.strictObject({
  v: z.literal(2),
  journalId: z.string().uuid(),
  revision: number,
  legacy: descriptor.optional(),
  migration: migration.optional(),
  segments: z.array(descriptor).min(1),
  pendingRecovery: recoveryEvent.optional()
})
export type JournalManifest = z.infer<typeof manifestSchema>
export const MAX_V2_LINE = 1024 * 1024
export const MAX_V1_LINE = 128 * 1024 * 1024

export function sha256(bytes: string | Uint8Array): string {
  return createHash('sha256').update(bytes).digest('hex')
}
export const EMPTY_SHA256 = sha256(Buffer.alloc(0))

export function canonical(value: unknown): string {
  if (value === null || typeof value === 'string' || typeof value === 'boolean')
    return JSON.stringify(value)
  if (typeof value === 'number' && Number.isFinite(value))
    return JSON.stringify(value)
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']'
  if (
    typeof value === 'object' &&
    Object.getPrototypeOf(value) === Object.prototype
  ) {
    const record = value as Record<string, unknown>
    return (
      '{' +
      Object.keys(record)
        .sort()
        .map((key) => JSON.stringify(key) + ':' + canonical(record[key]))
        .join(',') +
      '}'
    )
  }
  throw new StoreError('INVALID_TRANSITION')
}

export interface JournalIO {
  write?: (
    fd: number,
    bytes: Uint8Array,
    offset: number,
    length: number
  ) => number
  sync?: (fd: number) => void
  checkpoint?: (point: string) => void
}
export function syncDir(path: string, io: JournalIO = {}): void {
  const fd = fs.openSync(
    path,
    fs.constants.O_RDONLY | fs.constants.O_DIRECTORY | fs.constants.O_NOFOLLOW
  )
  try {
    ;(io.sync ?? fs.fsyncSync)(fd)
  } finally {
    fs.closeSync(fd)
  }
}
export function writeAll(
  fd: number,
  bytes: Uint8Array,
  io: JournalIO = {}
): void {
  let offset = 0
  while (offset < bytes.length) {
    const written = io.write
      ? io.write(fd, bytes, offset, bytes.length - offset)
      : fs.writeSync(fd, bytes, offset, bytes.length - offset)
    if (
      !Number.isInteger(written) ||
      written <= 0 ||
      written > bytes.length - offset
    )
      throw new StoreError('STORAGE_UNAVAILABLE')
    offset += written
  }
}
export function exclusiveFile(
  path: string,
  bytes: Uint8Array,
  io: JournalIO = {}
): void {
  const fd = fs.openSync(
    path,
    fs.constants.O_WRONLY |
      fs.constants.O_CREAT |
      fs.constants.O_EXCL |
      fs.constants.O_NOFOLLOW,
    0o600
  )
  try {
    writeAll(fd, bytes, io)
    ;(io.sync ?? fs.fsyncSync)(fd)
  } finally {
    fs.closeSync(fd)
  }
  syncDir(dirname(path), io)
}
export function safePath(root: string, path: string): string {
  relative.parse(path)
  let current = resolve(root)
  for (const part of path.split('/')) {
    current = join(current, part)
    // lstat catches dangling symlinks too.
    try {
      if (fs.lstatSync(current).isSymbolicLink())
        throw new StoreError('STORAGE_UNAVAILABLE', 'Symlink in storage path')
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error
    }
  }
  return current
}
export function fileHash(path: string, bytes?: number): string {
  const fd = fs.openSync(path, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW)
  const digest = createHash('sha256')
  const buffer = Buffer.alloc(64 * 1024)
  let offset = 0
  try {
    const total = bytes ?? fs.fstatSync(fd).size
    while (offset < total) {
      const count = fs.readSync(
        fd,
        buffer,
        0,
        Math.min(buffer.length, total - offset),
        offset
      )
      if (!count) throw new StoreError('STORAGE_UNAVAILABLE')
      digest.update(buffer.subarray(0, count))
      offset += count
    }
  } finally {
    fs.closeSync(fd)
  }
  return digest.digest('hex')
}
export function copySynced(
  source: string,
  destination: string,
  io: JournalIO = {},
  start = 0
): void {
  const input = fs.openSync(
    source,
    fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW
  )
  let output: number | undefined
  try {
    output = fs.openSync(
      destination,
      fs.constants.O_WRONLY |
        fs.constants.O_CREAT |
        fs.constants.O_EXCL |
        fs.constants.O_NOFOLLOW,
      0o600
    )
    const buffer = Buffer.alloc(64 * 1024)
    let offset = start
    while (true) {
      const count = fs.readSync(input, buffer, 0, buffer.length, offset)
      if (!count) break
      writeAll(output, buffer.subarray(0, count), io)
      offset += count
    }
    ;(io.sync ?? fs.fsyncSync)(output)
  } finally {
    fs.closeSync(input)
    if (output !== undefined) fs.closeSync(output)
  }
  syncDir(dirname(destination), io)
  if (start === 0 && fileHash(source) !== fileHash(destination))
    throw new StoreError('STORAGE_UNAVAILABLE')
}

/** Bounded byte streaming; only LF-delimited records are decoded. */
export function* lines(
  path: string,
  max: number,
  limit?: number
): Generator<{ bytes: Buffer; end: number; delimited: boolean }> {
  const fd = fs.openSync(path, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW)
  let offset = 0
  let length = 0
  let chunks: Buffer[] = []
  const buffer = Buffer.alloc(64 * 1024)
  try {
    const total = limit ?? fs.fstatSync(fd).size
    while (offset < total) {
      const count = fs.readSync(
        fd,
        buffer,
        0,
        Math.min(buffer.length, total - offset),
        offset
      )
      if (!count) throw new StoreError('STORAGE_UNAVAILABLE')
      let begin = 0
      for (let i = 0; i < count; i++) {
        if (buffer[i] !== 10) continue
        const part = Buffer.from(buffer.subarray(begin, i))
        length += part.length
        if (length + 1 > max)
          throw new StoreError(
            'STORAGE_UNAVAILABLE',
            'Record exceeds replay budget'
          )
        chunks.push(part)
        yield {
          bytes: Buffer.concat(chunks, length),
          end: offset + i + 1,
          delimited: true
        }
        chunks = []
        length = 0
        begin = i + 1
      }
      const part = Buffer.from(buffer.subarray(begin, count))
      length += part.length
      if (length > max)
        throw new StoreError(
          'STORAGE_UNAVAILABLE',
          'Record exceeds replay budget'
        )
      if (part.length) chunks.push(part)
      offset += count
    }
    if (length)
      yield {
        bytes: Buffer.concat(chunks, length),
        end: offset,
        delimited: false
      }
  } finally {
    fs.closeSync(fd)
  }
}
export function decodeJSON(bytes: Uint8Array): unknown {
  return JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes))
}

export class Journal {
  readonly root: string
  readonly io: JournalIO
  readonly instanceId = randomUUID()
  manifest: JournalManifest | undefined
  seq = 0
  head = EMPTY_SHA256
  available = true
  diagnostic: string | undefined
  readonly transitions = new Map<string, JournalTransaction>()
  #lockFd: number | undefined
  #activeFd: number | undefined
  #closed = false

  constructor(root: string, io: JournalIO = {}) {
    this.root = resolve(root)
    this.io = io
    fs.mkdirSync(this.root, { recursive: true })
    if (fs.lstatSync(this.root).isSymbolicLink())
      throw new StoreError('STORAGE_UNAVAILABLE')
    const lockPath = safePath(this.root, 'store.lock')
    try {
      this.#lockFd = fs.openSync(
        lockPath,
        fs.constants.O_WRONLY |
          fs.constants.O_CREAT |
          fs.constants.O_EXCL |
          fs.constants.O_NOFOLLOW,
        0o600
      )
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'EEXIST')
        throw new StoreError('STORE_LOCKED')
      throw new StoreError('STORAGE_UNAVAILABLE')
    }
    try {
      const bootId = fs
        .readFileSync('/proc/sys/kernel/random/boot_id', 'utf8')
        .trim()
      writeAll(
        this.#lockFd,
        Buffer.from(
          canonical({ instanceId: this.instanceId, pid: process.pid, bootId })
        ),
        io
      )
      ;(io.sync ?? fs.fsyncSync)(this.#lockFd)
      syncDir(this.root, io)
      for (const dir of ['journal', 'media', 'recovery', 'journal/manifests']) {
        fs.mkdirSync(safePath(this.root, dir), { recursive: true })
        syncDir(dirname(join(this.root, dir)), io)
      }
      const path = safePath(this.root, 'journal/manifest.json')
      if (fs.existsSync(path)) {
        this.manifest = manifestSchema.parse(decodeJSON(fs.readFileSync(path)))
        const prior = safePath(
          this.root,
          'journal/manifests/revision-' + this.manifest.revision + '.json'
        )
        if (!fs.existsSync(prior) || fileHash(prior) !== fileHash(path))
          throw new StoreError('STORAGE_UNAVAILABLE', 'Divergent manifest')
      }
    } catch (error) {
      this.fail(error)
    }
  }
  fail(error: unknown): void {
    this.available = false
    this.diagnostic =
      error instanceof StoreError ? error.code : 'STORAGE_UNAVAILABLE'
  }
  assertWritable(): void {
    if (!this.available || this.#closed)
      throw new StoreError('STORAGE_UNAVAILABLE')
  }
  initialize(
    legacy?: z.infer<typeof descriptor>,
    record?: MigrationRecord,
    pendingRecovery?: JournalManifest['pendingRecovery']
  ): void {
    this.assertWritable()
    const segment = this.newSegment()
    this.publishManifest({
      v: 2,
      journalId: randomUUID(),
      revision: 1,
      ...(legacy ? { legacy } : {}),
      ...(record ? { migration: record } : {}),
      segments: [segment],
      ...(pendingRecovery ? { pendingRecovery } : {})
    })
    this.head = legacy?.prefixSha256 ?? EMPTY_SHA256
  }
  newSegment(): z.infer<typeof descriptor> {
    const path = 'journal/segment-' + randomUUID() + '.jsonl'
    exclusiveFile(safePath(this.root, path), Buffer.alloc(0), this.io)
    this.io.checkpoint?.('segment_synced')
    return { path, bytes: 0, prefixSha256: EMPTY_SHA256, sealed: false }
  }
  publishManifest(candidate: JournalManifest): void {
    const parsed = manifestSchema.parse(candidate)
    const bytes = Buffer.from(canonical(parsed) + '\n')
    const prior = safePath(
      this.root,
      'journal/manifests/revision-' + parsed.revision + '.json'
    )
    exclusiveFile(prior, bytes, this.io)
    const tmp = safePath(this.root, 'journal/manifest-' + randomUUID() + '.tmp')
    exclusiveFile(tmp, bytes, this.io)
    this.io.checkpoint?.('before_manifest_rename')
    fs.renameSync(tmp, safePath(this.root, 'journal/manifest.json'))
    this.io.checkpoint?.('after_manifest_rename')
    syncDir(join(this.root, 'journal'), this.io)
    this.manifest = parsed
  }
  verifyDescriptor(item: z.infer<typeof descriptor>): void {
    const path = safePath(this.root, item.path)
    if (
      !fs.statSync(path).isFile() ||
      fs.statSync(path).size < item.bytes ||
      fileHash(path, item.bytes) !== item.prefixSha256 ||
      (item.sealed && (!item.fullSha256 || fileHash(path) !== item.fullSha256))
    )
      throw new StoreError('STORAGE_UNAVAILABLE')
  }
  replay(apply: (transaction: JournalTransaction) => void): void {
    this.assertWritable()
    const manifest = this.manifest
    if (
      !manifest ||
      manifest.segments.at(-1)!.sealed ||
      new Set(manifest.segments.map((s) => s.path)).size !==
        manifest.segments.length ||
      manifest.segments.some(
        (s) => !/^journal\/segment-[a-f0-9-]+\.jsonl$/.test(s.path)
      ) ||
      (manifest.legacy &&
        (manifest.legacy.path !== 'events.jsonl' || !manifest.migration)) ||
      (!manifest.legacy && manifest.migration)
    )
      throw new StoreError('STORAGE_UNAVAILABLE')
    this.head = manifest.legacy?.prefixSha256 ?? EMPTY_SHA256
    if (manifest.legacy) this.verifyDescriptor(manifest.legacy)
    for (let index = 0; index < manifest.segments.length; index++) {
      const segment = manifest.segments[index]!
      this.verifyDescriptor(segment)
      if (!segment.sealed && index !== manifest.segments.length - 1)
        throw new StoreError('STORAGE_UNAVAILABLE')
      let prefixBytes = 0
      for (const line of lines(
        safePath(this.root, segment.path),
        MAX_V2_LINE,
        segment.sealed ? segment.bytes : undefined
      )) {
        if (!line.delimited) {
          this.isolateTail(segment, prefixBytes)
          break
        }
        const transaction = transactionSchema.parse(decodeJSON(line.bytes))
        const { sha256: checksum, ...body } = transaction
        if (
          transaction.seq !== this.seq + 1 ||
          transaction.prevSha256 !== this.head ||
          sha256(canonical(body)) !== checksum ||
          this.transitions.has(transaction.transitionId)
        )
          throw new StoreError('STORAGE_UNAVAILABLE')
        apply(transaction)
        this.seq = transaction.seq
        this.head = transaction.sha256
        this.transitions.set(transaction.transitionId, transaction)
        prefixBytes = line.end
      }
    }
    for (const segment of this.manifest!.segments) {
      const fd = fs.openSync(
        safePath(this.root, segment.path),
        fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW
      )
      try {
        ;(this.io.sync ?? fs.fsyncSync)(fd)
      } finally {
        fs.closeSync(fd)
      }
    }
    const pending = this.manifest!.pendingRecovery
    if (pending) {
      const id =
        'recovery:' + pending.originalSha256 + ':' + pending.prefixBytes
      if (!this.transitions.has(id)) apply(this.append(id, [pending]))
    }
  }
  isolateTail(segment: z.infer<typeof descriptor>, prefixBytes: number): void {
    const manifest = this.manifest!
    const original = safePath(this.root, segment.path)
    const originalSha256 = fileHash(original)
    const dir = 'recovery/' + randomUUID()
    fs.mkdirSync(safePath(this.root, dir))
    syncDir(join(this.root, 'recovery'), this.io)
    const copyPath = dir + '/original-' + originalSha256 + '.jsonl'
    const tailPath = dir + '/tail.jsonl'
    copySynced(original, safePath(this.root, copyPath), this.io)
    copySynced(original, safePath(this.root, tailPath), this.io, prefixBytes)
    const prefixSha256 = fileHash(original, prefixBytes)
    const pendingRecovery: z.infer<typeof recoveryEvent> = {
      type: 'recovery_recorded',
      at: new Date().toISOString(),
      originalPath: segment.path,
      originalSha256,
      copyPath,
      tailPath,
      prefixBytes,
      prefixSha256,
      reason: 'NONDELIMITED_TAIL'
    }
    this.io.checkpoint?.('recovery_copies_synced')
    this.publishManifest({
      ...manifest,
      revision: manifest.revision + 1,
      segments: manifest.segments
        .map((item) =>
          item.path === segment.path
            ? {
                ...item,
                bytes: prefixBytes,
                prefixSha256,
                sealed: true,
                fullSha256: originalSha256,
                reason: 'NONDELIMITED_TAIL'
              }
            : item
        )
        .concat(this.newSegment()),
      pendingRecovery
    })
    this.diagnostic = 'NONDELIMITED_TAIL_RETAINED'
  }
  append(
    transitionId: string,
    changes: readonly JournalEvent[]
  ): JournalTransaction {
    this.assertWritable()
    const body = {
      v: 2 as const,
      seq: this.seq + 1,
      transitionId,
      at: changes[0]!.at,
      prevSha256: this.head,
      changes: [...changes]
    }
    const transaction = transactionSchema.parse({
      ...body,
      sha256: sha256(canonical(body))
    })
    const bytes = Buffer.from(canonical(transaction) + '\n')
    if (bytes.length > MAX_V2_LINE)
      throw new StoreError('INVALID_TRANSITION', 'Record exceeds V2 budget')
    try {
      if (this.#activeFd === undefined)
        this.#activeFd = fs.openSync(
          safePath(this.root, this.manifest!.segments.at(-1)!.path),
          fs.constants.O_WRONLY |
            fs.constants.O_APPEND |
            fs.constants.O_NOFOLLOW
        )
      this.io.checkpoint?.('before_journal_write')
      writeAll(this.#activeFd, bytes, this.io)
      this.io.checkpoint?.('after_journal_lf')
      ;(this.io.sync ?? fs.fsyncSync)(this.#activeFd)
      this.io.checkpoint?.('after_journal_sync')
      this.seq = transaction.seq
      this.head = transaction.sha256
      this.transitions.set(transitionId, transaction)
      return transaction
    } catch (error) {
      this.fail(error)
      throw new StoreError('STORAGE_UNAVAILABLE')
    }
  }
  verifyRecovery(
    event: Extract<JournalEvent, { type: 'recovery_recorded' }>
  ): void {
    const original = safePath(this.root, event.originalPath)
    const copy = safePath(this.root, event.copyPath)
    const tail = safePath(this.root, event.tailPath)
    if (
      fileHash(original) !== event.originalSha256 ||
      fileHash(copy) !== event.originalSha256 ||
      fileHash(original, event.prefixBytes) !== event.prefixSha256 ||
      fs.statSync(tail).size !== fs.statSync(original).size - event.prefixBytes
    )
      throw new StoreError('STORAGE_UNAVAILABLE')
    const source = fs.openSync(
      original,
      fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW
    )
    const target = fs.openSync(
      tail,
      fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW
    )
    try {
      const a = Buffer.alloc(64 * 1024)
      const b = Buffer.alloc(64 * 1024)
      let offset = 0
      while (offset < fs.fstatSync(target).size) {
        const count = fs.readSync(target, b, 0, b.length, offset)
        if (
          fs.readSync(source, a, 0, count, event.prefixBytes + offset) !==
            count ||
          !a.subarray(0, count).equals(b.subarray(0, count))
        )
          throw new StoreError('STORAGE_UNAVAILABLE')
        offset += count
      }
    } finally {
      fs.closeSync(source)
      fs.closeSync(target)
    }
  }

  saveMedia(
    bytes: Uint8Array,
    mime: MediaDescriptor['mime'],
    messageKey: string
  ): MediaDescriptor {
    this.assertWritable()
    const extensions: Record<MediaDescriptor['mime'], string> = {
      'audio/ogg': 'ogg',
      'audio/mpeg': 'mp3',
      'audio/mp4': 'm4a',
      'audio/wav': 'wav',
      'image/jpeg': 'jpg',
      'image/png': 'png',
      'application/octet-stream': 'bin'
    }
    const parsed = mediaDescriptor.parse({
      messageKey,
      mime,
      bytes: bytes.length,
      sha256: sha256(bytes),
      path: 'media/' + randomUUID() + '.' + extensions[mime],
      stage: 'published'
    })
    const path = safePath(this.root, parsed.path)
    try {
      const temporary = safePath(this.root, 'media/' + randomUUID() + '.tmp')
      this.io.checkpoint?.('before_media_write')
      exclusiveFile(temporary, bytes, this.io)
      this.io.checkpoint?.('after_media_sync')
      exclusiveFile(path, Buffer.alloc(0), this.io)
      fs.renameSync(temporary, path)
      syncDir(join(this.root, 'media'), this.io)
      exclusiveFile(
        path + '.json',
        Buffer.from(canonical(parsed) + '\n'),
        this.io
      )
      this.io.checkpoint?.('after_media_sidecar_sync')
      return parsed
    } catch (error) {
      this.fail(error)
      throw new StoreError('STORAGE_UNAVAILABLE')
    }
  }
  verifyMedia(path: string): MediaDescriptor {
    const full = safePath(this.root, path)
    const data = mediaDescriptor.parse(
      decodeJSON(fs.readFileSync(full + '.json'))
    )
    if (
      data.path !== path ||
      fs.statSync(full).size !== data.bytes ||
      fileHash(full) !== data.sha256
    )
      throw new StoreError('STORAGE_UNAVAILABLE')
    return data
  }
  mediaInventory(): { valid: MediaDescriptor[]; retained: string[] } {
    const valid: MediaDescriptor[] = []
    const retained: string[] = []
    for (const name of fs.readdirSync(join(this.root, 'media'))) {
      const path = 'media/' + name
      if (!name.endsWith('.json')) {
        retained.push(path)
        continue
      }
      try {
        valid.push(this.verifyMedia(path.slice(0, -5)))
      } catch {
        retained.push(path)
      }
    }
    return { valid, retained }
  }
  close(): void {
    if (this.#closed) return
    this.#closed = true
    if (this.#activeFd !== undefined) fs.closeSync(this.#activeFd)
    if (this.#lockFd !== undefined) {
      const path = safePath(this.root, 'store.lock')
      try {
        const record = decodeJSON(fs.readFileSync(path)) as {
          instanceId?: string
        }
        if (
          record.instanceId === this.instanceId &&
          fs.statSync(path).ino === fs.fstatSync(this.#lockFd).ino
        ) {
          fs.unlinkSync(path)
          syncDir(this.root)
        }
      } catch (error) {
        // A partial lock cannot be identified by its UUID. Preserve it for operator review.
        this.fail(error)
      } finally {
        fs.closeSync(this.#lockFd)
        this.#lockFd = undefined
      }
    }
  }
}
