import {
  type OrganizedV2,
  type SourceEvidence,
  type PatientBinding,
  type ValidationIssue,
  type NoteV2,
  normalizePatientId,
  ModelEvidenceSchema
} from './domain.ts'

const digits = [
  'zero',
  'um',
  'dois',
  'três',
  'quatro',
  'cinco',
  'seis',
  'sete',
  'oito',
  'nove'
]
const integers = new Map<string, string>()
const small = [
  ...digits,
  'dez',
  'onze',
  'doze',
  'treze',
  'quatorze',
  'quinze',
  'dezesseis',
  'dezessete',
  'dezoito',
  'dezenove'
]
const tens = [
  '',
  '',
  'vinte',
  'trinta',
  'quarenta',
  'cinquenta',
  'sessenta',
  'setenta',
  'oitenta',
  'noventa'
]
const hundreds = [
  '',
  'cento',
  'duzentos',
  'trezentos',
  'quatrocentos',
  'quinhentos',
  'seiscentos',
  'setecentos',
  'oitocentos',
  'novecentos'
]
function spell(n: number): string {
  if (n < 20) return small[n]!
  if (n < 100)
    return tens[Math.floor(n / 10)]! + (n % 10 ? ' e ' + spell(n % 10) : '')
  if (n === 100) return 'cem'
  return (
    hundreds[Math.floor(n / 100)]! + (n % 100 ? ' e ' + spell(n % 100) : '')
  )
}
for (let n = 0; n < 1000; n++) {
  const word = spell(n)
  integers.set(word, String(n))
  for (const v of [
    word.replace(/\bum\b/g, 'uma'),
    word.replace(/\bdois\b/g, 'duas'),
    word.replace(/quatorze/g, 'catorze')
  ])
    integers.set(v, String(n))
}
const digitWords = new Map(digits.map((w, n) => [w, String(n)]))
digitWords.set('uma', '1')
digitWords.set('duas', '2')
function integer(s: string): string | undefined {
  return /^(?:0|[1-9]\d{0,2})$/.test(s) ? s : integers.get(s)
}
export function numeralValue(literal: string): string | undefined {
  const s = literal.toLocaleLowerCase('pt-BR').trim().replace(/ +/g, ' ')
  const clock = /^(.+) horas?(?: e (.+) minutos?)?$/.exec(s)
  if (clock) {
    const h = integer(clock[1]!)
    const m = clock[2] ? integer(clock[2]) : '0'
    if (h !== undefined && m !== undefined && +h < 24 && +m < 60)
      return h.padStart(2, '0') + ':' + m.padStart(2, '0')
    return undefined
  }
  if (/^\d{2}:\d{2}$/.test(s)) {
    const [h, m] = s.split(':').map(Number)
    return h! < 24 && m! < 60 ? s : undefined
  }
  const decimal = s.split(' vírgula ')
  if (decimal.length === 2) {
    const whole = integer(decimal[0]!)
    const frac = decimal[1]!.split(' ').map((w) => digitWords.get(w))
    if (
      whole !== undefined &&
      frac.length >= 1 &&
      frac.length <= 3 &&
      frac.every((x) => x !== undefined)
    )
      return whole + ',' + frac.join('')
    return undefined
  }
  const numeric = /^(0|[1-9]\d{0,2}),(\d{1,3})$/.exec(s)
  if (numeric) return s
  return integer(s)
}
export interface SourceBlock {
  patientRef: string | null
  start: number
  end: number
  patientName?: string
  idLiteral?: string
}
export function locateQuote(
  raw: string,
  blocks: readonly SourceBlock[],
  payload: unknown
) {
  const parsed = ModelEvidenceSchema.safeParse(payload)
  if (!parsed.success)
    return {
      candidateRanges: [],
      serviceEvidence: null,
      issue: 'SOURCE_QUOTE_MISSING'
    }
  const e = parsed.data
  const assigned = blocks.filter((b) => b.patientRef === e.patientRef)
  if (!e.quote)
    return {
      candidateRanges: [],
      serviceEvidence: null,
      issue: 'SOURCE_QUOTE_MISSING'
    }
  if (assigned.length !== 1)
    return {
      candidateRanges: [],
      serviceEvidence: null,
      issue: 'SOURCE_ASSOCIATION_AMBIGUOUS'
    }
  const block = assigned[0]!
  const candidateRanges: { start: number; end: number }[] = []
  let at = raw.indexOf(e.quote, block.start)
  while (at >= 0 && at + e.quote.length <= block.end) {
    candidateRanges.push({ start: at, end: at + e.quote.length })
    at = raw.indexOf(e.quote, at + 1)
  }
  if (candidateRanges.length !== 1)
    return {
      candidateRanges,
      serviceEvidence: null,
      issue: candidateRanges.length
        ? 'SOURCE_ASSOCIATION_AMBIGUOUS'
        : 'SOURCE_QUOTE_NOT_FOUND'
    }
  return {
    candidateRanges,
    serviceEvidence: { ...e, ...candidateRanges[0]! },
    issue: null
  }
}
interface ValueTuple {
  patientBlock: string
  field: string
  valueLiteral: string | null
  unitLiteral: string | null
  quote?: string
}
export function compareSourceValue(
  raw: string,
  blocks: readonly SourceBlock[],
  source: ValueTuple,
  output: ValueTuple
) {
  const displayLiteral = source.valueLiteral ?? source.quote ?? ''
  const reject = (issue: string) => ({
    outcome: 'REJECT',
    comparisonValue: null,
    displayLiteral,
    issue,
    canonicalPatientMerge: false
  })
  if (source.patientBlock !== output.patientBlock)
    return reject('VALUE_PATIENT_MISMATCH')
  if (
    source.field !== output.field ||
    (source.field === 'duration' && output.valueLiteral?.includes(':'))
  )
    return reject('VALUE_FIELD_MISMATCH')
  if (source.unitLiteral !== output.unitLiteral)
    return reject('VALUE_UNIT_MISMATCH')
  if (source.valueLiteral === null || output.valueLiteral === null)
    return reject('UNSOURCED_VALUE')
  const block = blocks.find((b) => b.patientRef === source.patientBlock)
  if (
    !block ||
    !source.quote ||
    !raw.slice(block.start, block.end).includes(source.quote) ||
    !source.quote.includes(source.valueLiteral)
  )
    return reject('SOURCE_ASSOCIATION_AMBIGUOUS')
  const a = numeralValue(source.valueLiteral),
    b = numeralValue(output.valueLiteral)
  if (a === undefined || b === undefined) {
    if (source.valueLiteral === output.valueLiteral)
      return {
        outcome: 'EQUIVALENT',
        comparisonValue: source.valueLiteral,
        displayLiteral,
        issue: null,
        canonicalPatientMerge: false
      }
    return reject('SOURCE_ASSOCIATION_AMBIGUOUS')
  }
  if (a !== b) {
    const others = blocks
      .filter((p) => p.patientRef !== source.patientBlock)
      .map((p) => numericText(raw.slice(p.start, p.end)))
      .join(' ')
    if (others.includes('⟦' + b + '⟧')) return reject('VALUE_PATIENT_MISMATCH')
    if (
      source.field === 'currentValue' &&
      /a anotação anterior dizia/i.test(raw.slice(block.start, block.end))
    ) {
      const historical =
        raw
          .slice(block.start, block.end)
          .split(/a anotação anterior dizia/i)[1]
          ?.split(/[.;]/)[0] ?? ''
      if (numericText(historical).includes('⟦' + b + '⟧'))
        return reject('VALUE_FIELD_MISMATCH')
    }
    return reject('UNSOURCED_VALUE')
  }
  return {
    outcome: 'EQUIVALENT',
    comparisonValue: a,
    displayLiteral,
    issue: null,
    canonicalPatientMerge: false
  }
}
// Longest finite grammar match; only numeric representations change, never units or free prose.
const numberWords = [
  ...new Set(
    [...integers.keys()]
      .flatMap((w) => w.split(' '))
      .concat(digits, ['vírgula', 'hora', 'horas', 'minuto', 'minutos'])
  )
].sort((a, b) => b.length - a.length)
const numericPattern = new RegExp(
  '(?<![\\p{L}\\p{N}])(?:\\d{2}:\\d{2}|\\d+(?:[,.]\\d+)?|(?:' +
    numberWords.join('|') +
    ')(?: (?:' +
    numberWords.join('|') +
    '))*)(?![\\p{L}\\p{N}])',
  'gu'
)
export function numericText(text: string): string {
  return text.replace(numericPattern, (word) => {
    const v = numeralValue(word)
    return v === undefined ? word : '⟦' + v + '⟧'
  })
}
export function buildSourceBlocks(
  raw: string,
  organization: OrganizedV2
): SourceBlock[] {
  const anchors = [
    ...raw.matchAll(/(?:\b[Nn]ovo paciente:|\b[Pp]aciente)\s+([^,.;\n]+)[,.;]/g)
  ]
  const ranges = anchors.map((a, index) => {
    const start = a.index!,
      end = anchors[index + 1]?.index ?? raw.length
    const ids = [
      ...raw
        .slice(start, end)
        .split(/\.\s|\.$|\n/)[0]!
        .matchAll(
          /(?:\bID|\bid|\bficha|\bprontuário)\s+([^,;\n]+?)(?=\.\s|\.$|[,;\n]|$)/g
        )
    ].map((m) => m[1]!.trim())
    return { name: a[1]!.trim(), start, end, ids }
  })
  const blocks: SourceBlock[] = []
  for (const patient of organization.pacientes) {
    const matching = ranges.filter(
      (r) =>
        r.name === patient.nome &&
        (!patient.id ||
          r.ids.some(
            (literal) =>
              literal === patient.id ||
              (numeralValue(literal) !== undefined &&
                numeralValue(literal) === numeralValue(patient.id!))
          ))
    )
    if (matching.length === 1) {
      const r = matching[0]!
      const uniqueIds = [...new Set(r.ids)]
      if (patient.id && uniqueIds.length !== 1) continue
      blocks.push({
        patientRef: patient.localRef,
        patientName: patient.nome,
        start: r.start,
        end: r.end,
        ...(uniqueIds.length === 1 ? { idLiteral: uniqueIds[0]! } : {})
      })
    }
  }
  if (anchors.length) {
    const first = anchors[0]!.index!
    if (
      first > 0 &&
      /(?:[Pp]endência geral:|[Gg]eral:)/.test(raw.slice(0, first))
    )
      blocks.push({ patientRef: null, start: 0, end: first })
  } else if (/^(?:Pendência geral:|Geral:)/.test(raw))
    blocks.push({ patientRef: null, start: 0, end: raw.length })
  return blocks
}
interface BoundField {
  field: string
  start: number
  end: number
  literal: string
}
// Values are extracted from the complete persisted block, never from a potentially
// shortened quote. Only surrounding field separators are removed; units, signs,
// scale, negation and all free prose remain literal.
function fieldRange(
  raw: string,
  field: string,
  start: number,
  end: number
): BoundField {
  while (start < end && /\s/u.test(raw[start]!)) start++
  while (end > start && /\s/u.test(raw[end - 1]!)) end--
  if (/[.,;]/u.test(raw[end - 1] ?? '')) end--
  while (end > start && /\s/u.test(raw[end - 1]!)) end--
  return { field, start, end, literal: raw.slice(start, end) }
}
function boundFields(raw: string, block: SourceBlock): BoundField[] {
  const result: BoundField[] = []
  const text = raw.slice(block.start, block.end)
  const anchor = /^(?:Novo paciente:|Paciente)\s+([^,.;\n]+)[,.;]/i.exec(text)
  let bodyStart = block.start
  if (anchor) {
    const nameAt = block.start + anchor[0].indexOf(anchor[1]!)
    result.push(fieldRange(raw, 'nome', nameAt, nameAt + anchor[1]!.length))
    const stop = /\.\s|\.$|\n/.exec(text)
    const headerEnd = block.start + (stop?.index ?? text.length)
    // Header values consume their complete comma/semicolon-delimited scalar.
    // An ID or bed is never selected from a numeric occurrence elsewhere.
    const headerStart = block.start + anchor[0].length
    const header = raw.slice(headerStart, headerEnd)
    for (const item of header.matchAll(/[^,;\n]+/g)) {
      const segmentStart = headerStart + item.index!
      const segment = item[0]
      const named =
        /^\s*(ID|ficha|prontuário|leito|espécie|tutor|tutora)\s*:?\s+(.+)$/i.exec(
          segment
        )
      if (named) {
        const label = named[1]!.toLocaleLowerCase('pt-BR')
        const field = ['id', 'ficha', 'prontuário'].includes(label)
          ? 'id'
          : label === 'espécie'
            ? 'especie'
            : label === 'tutora'
              ? 'tutor'
              : label
        const valueAt = segmentStart + named[0].length - named[2]!.length
        result.push(
          fieldRange(raw, field, valueAt, segmentStart + segment.length)
        )
      } else if (
        /^\s*(?:canino|felino|cão|cadela|gato|gata)\s*$/u.test(segment)
      ) {
        // Explicit unlabelled species literals used by the existing corpus;
        // no semantic species classifier or alias is introduced.
        result.push(
          fieldRange(
            raw,
            'especie',
            segmentStart,
            segmentStart + segment.length
          )
        )
      }
    }
    bodyStart = stop ? headerEnd + stop[0].length : block.end
  }
  const body = raw.slice(bodyStart, block.end)
  const markers = [
    ...body.matchAll(
      /(?<![\p{L}\p{N}_])(?:Motivo(?: da internação informado)?:|Evolução(?: anotada)?:|Evolucao:|Exames:|Condutas:|Pendência(?: geral| da equipe)?:|Pendencia:|Geral:|Tutor:|Tutora:|Espécie:|Temperatura anotada|Frequência cardíaca|Frequência respiratória|Peso|glicemia|Volume anotado|O valor fornecido agora|a anotação anterior dizia|ID\s+|ficha\s+|prontuário\s+|leito\s+|pedi\s+|solicitar\s+|recebeu\s+|vou\s+|promessa(?: da equipe)?:|prometeu\s+)/giu
    )
  ].filter((m) => {
    const previous = body.slice(0, m.index).trimEnd()
    return /^(?:ID|ficha|prontuário|leito)\s+$/iu.test(m[0])
      ? /[,;.\n]\s*$/u.test(body.slice(0, m.index))
      : !previous || /[,;.:\n]\s*$/u.test(body.slice(0, m.index))
  })
  const fieldFor = (marker: string) => {
    const m = marker.toLocaleLowerCase('pt-BR').trim()
    if (m.startsWith('motivo')) return 'motivo'
    if (
      /^(?:evolução|evolucao|temperatura|frequência|peso|glicemia|volume|o valor)/u.test(
        m
      )
    )
      return 'evolucao'
    if (/^(?:exames|pedi|solicitar)/u.test(m)) return 'exames_pedidos'
    if (/^(?:condutas|recebeu)/u.test(m)) return 'condutas'
    if (/^(?:pendência|pendencia|geral|vou|promessa|prometeu)/u.test(m))
      return 'descricao'
    if (/^tutor/u.test(m)) return 'tutor'
    if (m.startsWith('espécie')) return 'especie'
    // Historical values and header mentions still terminate the previous field,
    // but are not grants for a current clinical field or a header identity.
    return null
  }
  for (const [index, marker] of markers.entries()) {
    const label = marker[0]
    const field = fieldFor(label)
    if (!field) continue
    const markerAt = bodyStart + marker.index!
    const previous = raw.slice(bodyStart, markerAt).trimEnd()
    const parent = markers[index - 1]
    const nested =
      parent &&
      /^(?:Evolução:|Evolucao:)$/iu.test(parent[0]) &&
      body.slice(parent.index! + parent[0].length, marker.index!).trim() === ''
    // A marker embedded in arbitrary/negated prose supplies no field grant.
    // It nevertheless bounds the preceding field, so values cannot leak past it.
    if (
      previous &&
      !/[.,;:\n]\s*$/u.test(raw.slice(bodyStart, markerAt)) &&
      !nested
    )
      continue
    let next = markers[index + 1]
    if (
      next &&
      /^(?:Evolução:|Evolucao:)$/iu.test(label) &&
      body.slice(marker.index! + label.length, next.index!).trim() === '' &&
      fieldFor(next[0]) === 'evolucao'
    )
      next = markers[index + 2]
    const end = next ? bodyStart + next.index! : block.end
    const value = fieldRange(raw, field, markerAt + label.length, end)
    if (!value.literal) continue
    if (field === 'exames_pedidos' || field === 'condutas') {
      for (const item of value.literal.matchAll(/[^;]+/g))
        result.push(
          fieldRange(
            raw,
            field,
            value.start + item.index!,
            value.start + item.index! + item[0].length
          )
        )
    } else if (field === 'descricao') {
      const time = /(?:^|\s)(?:às|as)\s+(.+)$/u.exec(value.literal)
      const clock = time && numeralValue(time[1]!)
      if (time && clock && /^\d{2}:\d{2}$/u.test(clock)) {
        const clockStart =
          value.start + time.index + time[0].length - time[1]!.length
        result.push(fieldRange(raw, 'quando', clockStart, value.end))
        result.push(
          fieldRange(raw, field, value.start, value.start + time.index)
        )
      } else result.push(value)
    } else {
      result.push(value)
      // Literal corpus labels may be retained in the proposed evolution. The
      // complete labelled span is another exact representation, not a substring.
      if (!label.endsWith(':'))
        result.push(fieldRange(raw, field, markerAt, end))
    }
  }
  return [
    ...new Map(
      result.map((f) => [JSON.stringify([f.field, f.start, f.end]), f])
    ).values()
  ]
}
function fieldEquivalent(
  source: string,
  output: string,
  field: string
): boolean {
  if (source === output) return true
  if (field === 'id' || field === 'leito' || field === 'quando') {
    const a = numeralValue(source),
      b = numeralValue(output)
    return (
      a !== undefined && a === b && (field === 'quando' || !a.includes(':'))
    )
  }
  const fieldNumericPattern = new RegExp(
    numericPattern.source.replace('(?: (?:', '(?: +(?:'),
    'giu'
  )
  const canonicalField = (text: string) =>
    text.replace(fieldNumericPattern, (literal, at: number) => {
      const value = numeralValue(literal)
      const before = text.slice(0, at),
        after = text.slice(at + literal.length)
      // Do not partially canonicalize signed quantities, fractions, intervals,
      // percentages, exponents or decimals outside C2 by converting their pieces.
      const compound =
        /[-+/%^.,]\s*$/u.test(before) ||
        /^\s*[-+/%^.,]\s*[\p{L}\p{N}]/u.test(after) ||
        /^\s*[/%^]/u.test(after) ||
        /(?:menos|mais|a|até)\s$/iu.test(before) ||
        /^\s+(?:por cento|a|até)\s?/iu.test(after)
      // C2 clock syntax requires explicit clock context; duration is not a clock.
      if (
        value === undefined ||
        compound ||
        (value.includes(':') && !/(?:às|as)\s$/u.test(before))
      )
        return literal
      return '⟦' + value + '⟧'
    })
  return canonicalField(source) === canonicalField(output)
}
export function validateOrganization(
  raw: string,
  o: OrganizedV2,
  history: readonly NoteV2[] = [],
  elaboratedAt?: string
): {
  evidence: SourceEvidence[]
  bindings: PatientBinding[]
  issues: ValidationIssue[]
} {
  const blocks = buildSourceBlocks(raw, o)
  const evidence: SourceEvidence[] = []
  const bindings: PatientBinding[] = []
  const issues: ValidationIssue[] = []
  const issue = (
    code: string,
    path: string,
    ref: string | null,
    value: string,
    range: SourceEvidence | null = null
  ) =>
    issues.push({
      code,
      path,
      patientRef: ref,
      sourceRange: range ? { start: range.start, end: range.end } : null,
      outputValue: value,
      severity: 'blocking'
    })
  const fieldsByBlock = new Map(
    blocks.map((b) => [b.patientRef, boundFields(raw, b)])
  )
  const verify = (path: string, ref: string | null, value: string) => {
    const es = o.evidence.filter((e) => e.path === path && e.patientRef === ref)
    if (es.length !== 1) {
      issue('SOURCE_QUOTE_MISSING', path, ref, value)
      return
    }
    const located = locateQuote(raw, blocks, es[0])
    if (!located.serviceEvidence) {
      issue(located.issue!, path, ref, value)
      return
    }
    const ev = located.serviceEvidence
    evidence.push(ev)
    const field = path.split('.')[2]!
    const candidates = (fieldsByBlock.get(ref) ?? []).filter(
      (f) => f.field === field
    )
    if (!candidates.length) {
      issue('VALUE_FIELD_MISMATCH', path, ref, value, ev)
      return
    }
    // Header scalars must have one complete source value in their own block.
    if (
      ['id', 'leito', 'nome', 'tutor', 'especie'].includes(field) &&
      candidates.length !== 1
    ) {
      issue('SOURCE_ASSOCIATION_AMBIGUOUS', path, ref, value, ev)
      return
    }
    const matching = candidates.filter(
      (f) =>
        ev.start <= f.start &&
        ev.end >= f.end &&
        fieldEquivalent(f.literal, value, field)
    )
    if (matching.length !== 1)
      issue(
        matching.length ? 'SOURCE_ASSOCIATION_AMBIGUOUS' : 'UNSOURCED_VALUE',
        path,
        ref,
        value,
        ev
      )
  }
  for (const p of o.pacientes) {
    const prefix = 'pacientes.' + p.localRef + '.'
    const block = blocks.find((b) => b.patientRef === p.localRef)
    let inherited: PatientBinding | undefined
    if (!p.id && block) {
      const candidates = history
        .filter((n) => n.state === 'confirmed' && !n.replacementPending)
        .flatMap((n) =>
          n.bindings
            .filter(
              (b) =>
                b.name === p.nome &&
                b.provenance !== 'unresolved' &&
                b.confirmedBy &&
                b.idLiteral &&
                (!p.leito || p.leito === b.bed)
            )
            .map((b) => ({
              ...b,
              evidenceRefs: [
                'history:' + n.id + ':' + n.revision + ':' + n.organizedSha256
              ]
            }))
        )
      const unique = [
        ...new Map(
          candidates.map((b) => [JSON.stringify([b.idLiteral, b.bed]), b])
        ).values()
      ]
      if (unique.length === 1) inherited = unique[0]
    }
    if (!block || (!p.id && !inherited)) {
      issue('UNSOURCED_ID', prefix + 'id', p.localRef, p.id ?? '')
    }
    verify(prefix + 'nome', p.localRef, p.nome)
    if (p.id) verify(prefix + 'id', p.localRef, p.id)
    for (const field of [
      'leito',
      'especie',
      'tutor',
      'motivo',
      'evolucao'
    ] as const)
      if (p[field]) verify(prefix + field, p.localRef, p[field]!)
    for (const [i, v] of p.exames_pedidos.entries())
      verify(prefix + 'exames_pedidos.' + i, p.localRef, v)
    for (const [i, v] of p.condutas.entries())
      verify(prefix + 'condutas.' + i, p.localRef, v)
    bindings.push({
      localRef: p.localRef,
      name: p.nome,
      ...(p.id
        ? {
            idLiteral: block?.idLiteral ?? p.id,
            normalizedId: normalizePatientId(block?.idLiteral ?? p.id)
          }
        : inherited?.idLiteral
          ? {
              idLiteral: inherited.idLiteral,
              normalizedId: normalizePatientId(inherited.idLiteral)
            }
          : {}),
      ...(p.leito ? { bed: p.leito } : {}),
      provenance:
        p.id && block
          ? 'source_explicit'
          : inherited
            ? 'confirmed_history_candidate'
            : 'unresolved',
      evidenceRefs: [
        ...evidence
          .filter((e) => e.patientRef === p.localRef)
          .map((e) => e.path),
        ...(inherited?.evidenceRefs ?? [])
      ]
    })
  }
  for (const t of o.pendencias) {
    const prefix = 'pendencias.' + t.localRef + '.'
    const b = bindings.find((p) => p.localRef === t.pacienteRef)
    if (
      t.pacienteRef &&
      (!b ||
        b.provenance === 'unresolved' ||
        (t.pacienteId &&
          t.pacienteId !== b.idLiteral &&
          !(
            numeralValue(t.pacienteId) !== undefined &&
            numeralValue(t.pacienteId) === numeralValue(b.idLiteral ?? '')
          )))
    )
      issue(
        'VALUE_PATIENT_MISMATCH',
        prefix + 'pacienteRef',
        t.pacienteRef,
        t.pacienteId ?? ''
      )
    verify(prefix + 'descricao', t.pacienteRef, t.descricao)
    const ids = [
      ...t.descricao.matchAll(/(?:ID|ficha|prontuário)\s+([^,.;\s]+)/g)
    ].map((m) => m[1])
    if (ids.some((id) => id !== b?.idLiteral))
      issue(
        'VALUE_PATIENT_MISMATCH',
        prefix + 'descricao',
        t.pacienteRef,
        t.descricao
      )
    if (t.quando) {
      const e = o.evidence.find((e) => e.path === prefix + 'quando')
      const clock = t.quando.match(/T(\d{2}:\d{2})/)
      const baseDay = elaboratedAt
        ? new Date(Date.parse(elaboratedAt) - 10800000)
            .toISOString()
            .slice(0, 10)
        : undefined
      if (
        baseDay &&
        (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:00-03:00$/.test(t.quando) ||
          t.quando.slice(0, 10) !== baseDay)
      )
        issue('UNSOURCED_VALUE', prefix + 'quando', t.pacienteRef, t.quando)
      if (!clock || !e || !/(?:às|as)\s/.test(e.quote))
        issue('UNSOURCED_VALUE', prefix + 'quando', t.pacienteRef, t.quando)
      else verify(prefix + 'quando', t.pacienteRef, clock[1]!)
    }
  }
  // Extras cannot assert unrelated provenance. Ref/field must correspond to a concrete scalar checked above.
  for (const e of o.evidence)
    if (
      !evidence.some((v) => v.path === e.path) &&
      !issues.some((i) => i.path === e.path)
    )
      issue('SOURCE_ASSOCIATION_AMBIGUOUS', e.path, e.patientRef, e.quote)
  for (const b of bindings)
    if (
      bindings.some(
        (other) =>
          other.localRef !== b.localRef &&
          other.normalizedId === b.normalizedId &&
          other.idLiteral !== b.idLiteral
      )
    )
      issue(
        'SOURCE_ASSOCIATION_AMBIGUOUS',
        'pacientes.' + b.localRef + '.id',
        b.localRef,
        b.idLiteral ?? ''
      )
  return { evidence, bindings, issues }
}
