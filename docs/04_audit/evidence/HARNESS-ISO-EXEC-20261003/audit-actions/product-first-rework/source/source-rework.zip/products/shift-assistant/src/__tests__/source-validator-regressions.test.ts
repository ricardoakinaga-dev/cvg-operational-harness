// @vitest-environment node
import { describe, expect, it } from 'vitest'
import { validateOrganization } from '../source-evidence.ts'
import { parseOrganizerResponse } from '../organizer.ts'
import {
  applyVertical,
  emptyVertical,
  revisionToken
} from '../vertical-state.ts'
import { canonical, sha256 } from '../journal.ts'
import type { NoteV2, OrganizedV2 } from '../domain.ts'
import { RAW, RESPONSE } from './vertical-test-fixture.ts'
import { ADMISSION, THOR_AUDIO, BOB_AUDIO } from './e2e-v2-fixtures.ts'
import { LEGACY_RAW, LEGACY_RESPONSE } from './legacy-v2-fixture.ts'

const at = '2026-10-03T18:00:00Z'
function check(raw: string, response: OrganizedV2) {
  return validateOrganization(
    raw,
    parseOrganizerResponse(JSON.stringify(response)),
    [],
    at
  )
}
function evolution(
  source: string,
  output = source,
  quote = 'Evolução: ' + source
) {
  const response = structuredClone(RESPONSE)
  response.pacientes[0]!.evolucao = output
  response.evidence[3]!.quote = quote
  return { raw: RAW.replace('alerta', source), response }
}
function bed(source: string, output: string, quote = 'leito ' + source) {
  const response = structuredClone(RESPONSE)
  response.pacientes[0]!.id = '2'
  response.pacientes[0]!.leito = output
  response.pendencias[0]!.pacienteId = '2'
  response.evidence[0]!.quote = 'Paciente Rex, leito ' + source + ', ID 2'
  response.evidence[1]!.quote = 'ID 2'
  response.evidence[2]!.quote = quote
  return {
    raw: RAW.replace('ID 20202, leito 4', 'leito ' + source + ', ID 2'),
    response
  }
}
function blocked(raw: string, response: OrganizedV2, field: string) {
  const result = check(raw, response)
  expect(
    result.issues.some((i) => i.path === field && i.severity === 'blocking')
  ).toBe(true)
  return result
}
function replay(raw: string, response: OrganizedV2, forgeIssues = false) {
  const organized = parseOrganizerResponse(response)
  const validation = validateOrganization(raw, organized, [], at)
  // This reducer is the real journal caller; no store/app mutation, model or HTTP seam.
  // Empty pending list makes the test focus on recomputation of field provenance.
  const state = emptyVertical()
  const key = JSON.stringify(['waha', 'source-regression', 'note'])
  const phone = '5511900000001'
  state.inbox.set(key, {
    key,
    digest: '0'.repeat(64),
    provider: 'waha',
    session: 'source-regression',
    messageId: 'note',
    memberPhone: phone,
    kind: 'text',
    text: raw,
    receivedAt: at,
    state: 'processing',
    stage: 'organize',
    attempt: 1
  })
  const note: NoteV2 = {
    id: 'source-note',
    messageKey: key,
    authorPhone: phone,
    revision: 1,
    createdAt: at,
    rawText: raw,
    rawTextSha256: sha256(raw),
    organized,
    organizedSha256: sha256(canonical(organized)),
    token: '',
    state: 'draft',
    replacementPending: false,
    evidence: validation.evidence,
    bindings: validation.bindings,
    issues: forgeIssues ? [] : validation.issues,
    warnings: [],
    tasks: [],
    previewIds: ['source-preview']
  }
  note.token = revisionToken(note)
  applyVertical(
    state,
    {
      v: 2,
      type: 'draft_prepared',
      at,
      actor: { kind: 'member', memberPhone: phone },
      key,
      note,
      outboxes: [
        {
          id: 'source-preview',
          purpose: 'preview',
          sourceTransitionId: 'source-draft',
          recipientMemberId: phone,
          noteId: note.id,
          noteRevision: 1,
          payloadText: 'synthetic preview',
          payloadSha256: sha256('synthetic preview'),
          state: 'queued',
          attempt: 0
        }
      ]
    },
    0,
    false
  )
  return state
}
describe('R1 source validator runtime regressions', () => {
  it('F01 rejects bed 2 borrowed from ID 2 in leito 1, ID 2', () => {
    const c = bed('1', '2', 'leito 1, ID 2')
    blocked(c.raw, c.response, 'pacientes.p1.leito')
  })
  it('F02 rejects full unit suffix loss mg/kg to mg', () => {
    const c = evolution('dose 1 mg/kg', 'dose 1 mg')
    blocked(c.raw, c.response, 'pacientes.p1.evolucao')
  })
  it.each(['20', '2A', '2-3', 'dois e três'])(
    'rejects scalar bed substring %s to 2',
    (source) => {
      const c = bed(source, '2')
      blocked(c.raw, c.response, 'pacientes.p1.leito')
    }
  )
  it.each([
    ['dose 1 mg/kg/h', 'dose 1 mg/kg'],
    ['volume 1 mL/kg/h', 'volume 1 mL'],
    ['dose 1 miligramas por quilograma', 'dose 1 miligramas'],
    ['dose 1 mg', 'dose 1 g'],
    ['glicemia 92 mg/dL', 'glicemia 92 mg'],
    ['dose 1,0 mg', 'dose 1 mg'],
    ['dose -2 mg', 'dose 2 mg'],
    ['dose 1/2 mg', 'dose 2 mg'],
    ['dose 2.5 mg', 'dose 2,5 mg'],
    ['não alerta', 'alerta'],
    ['alerta, não estável', 'alerta'],
    ['dose 1 mg; não repetir', 'dose 1 mg'],
    ['dose 1 mg e dose 2 mg', 'dose 2 mg'],
    ['observar por quinze horas', 'observar por 15:00']
  ])('rejects prefix/suffix/negation/conversion %s -> %s', (source, output) => {
    const c = evolution(source, output)
    blocked(c.raw, c.response, 'pacientes.p1.evolucao')
  })
  it.each([
    'dose 1 mg/kg',
    'dose 1 mg/kg/h',
    'volume 1 mL/kg/h',
    'dose 1 miligramas por quilograma',
    'não alerta',
    'alerta, não estável',
    'dose -2 mg',
    'dose 1/2 mg',
    'dose 2.5 mg',
    'dose 1 mg; não repetir'
  ])('accepts correctly identical complete clinical field %s', (source) => {
    const c = evolution(source)
    expect(check(c.raw, c.response).issues).toEqual([])
  })
  it.each([
    ['dose um mg/kg', 'dose 1 mg/kg'],
    ['dose um vírgula zero mg/kg/h', 'dose 1,0 mg/kg/h'],
    ['Volume anotado dois mililitros', 'Volume anotado 2 mililitros'],
    ['vomitou duas vezes', 'vomitou 2 vezes']
  ])(
    'accepts finite numeral equivalence with entire unit/prose %s',
    (source, output) => {
      const c = evolution(source, output)
      expect(check(c.raw, c.response).issues).toEqual([])
    }
  )
  it('accepts exact bed and by-extenso bed without borrowing ID, preserving literal ID', () => {
    for (const source of ['1', 'um']) {
      const c = bed(source, '1', 'leito ' + source + ', ID 2')
      const result = check(c.raw, c.response)
      expect(result.issues).toEqual([])
      expect(result.bindings[0]?.idLiteral).toBe('2')
    }
    const response = structuredClone(RESPONSE)
    response.pacientes[0]!.id = '101'
    response.pendencias[0]!.pacienteId = '101'
    response.evidence[0]!.quote = 'Paciente Rex, ficha cento e um'
    response.evidence[1]!.quote = 'ficha cento e um'
    const result = check(RAW.replace('ID 20202', 'ficha cento e um'), response)
    expect(result.issues).toEqual([])
    expect(result.bindings[0]?.idLiteral).toBe('cento e um')
  })
  it.each(['ID 202', 'ID 2020'])('rejects ID substring %s', (id) => {
    const response = structuredClone(RESPONSE)
    response.pacientes[0]!.id = id.slice(3)
    response.evidence[1]!.quote = id
    blocked(RAW, response, 'pacientes.p1.id')
  })
  it('rejects field borrowing even with a full multi-field quote', () => {
    const response = structuredClone(RESPONSE)
    response.pacientes[0]!.evolucao = 'dose 2 mg'
    response.evidence[3]!.quote = 'Evolução: dose 1 mg. Condutas: dose 2 mg'
    blocked(
      RAW.replace(
        'Evolução: alerta',
        'Evolução: dose 1 mg. Condutas: dose 2 mg'
      ),
      response,
      'pacientes.p1.evolucao'
    )
  })
  it('rejects truncated literal quote hiding full unit or negation outside the quote', () => {
    for (const source of ['dose 1 mg/kg', 'dose 1 mg, não repetir']) {
      const c = evolution(source, 'dose 1 mg', 'Evolução: dose 1 mg')
      blocked(c.raw, c.response, 'pacientes.p1.evolucao')
    }
  })
  it('accepts complete array items, rejects partial and negated items', () => {
    const response = structuredClone(RESPONSE)
    response.pacientes[0]!.exames_pedidos = ['hemograma', 'bioquímico']
    response.evidence.push(
      ...response.pacientes[0]!.exames_pedidos.map((_, i) => ({
        path: 'pacientes.p1.exames_pedidos.' + i,
        patientRef: 'p1',
        quote: 'Exames: hemograma; bioquímico'
      }))
    )
    const raw = RAW.replace(
      'Pendência:',
      'Exames: hemograma; bioquímico. Pendência:'
    )
    expect(check(raw, response).issues).toEqual([])
    response.pacientes[0]!.exames_pedidos[0] = 'hemog'
    blocked(raw, response, 'pacientes.p1.exames_pedidos.0')
    response.pacientes[0]!.exames_pedidos[0] = 'hemograma'
    for (const e of response.evidence.filter((e) =>
      e.path.includes('exames_pedidos')
    ))
      e.quote = 'Exames: hemograma; não bioquímico'
    blocked(
      raw.replace('; bioquímico', '; não bioquímico'),
      response,
      'pacientes.p1.exames_pedidos.1'
    )
  })
  it('rejects negation lost in task descriptions, accepts exact task plus finite time', () => {
    const response = structuredClone(RESPONSE)
    for (const e of response.evidence.filter((e) =>
      e.path.startsWith('pendencias.')
    ))
      e.quote = 'Pendência: não conferir ficha às 16:00'
    const raw = RAW.replace(
      'Pendência: conferir ficha',
      'Pendência: não conferir ficha'
    )
    blocked(raw, response, 'pendencias.t1.descricao')
    response.pendencias[0]!.descricao = 'não conferir ficha'
    expect(check(raw, response).issues).toEqual([])
    for (const e of response.evidence.filter((e) =>
      e.path.startsWith('pendencias.')
    ))
      e.quote = 'Pendência: não conferir ficha às dezesseis horas'
    expect(
      check(raw.replace('16:00', 'dezesseis horas'), response).issues
    ).toEqual([])
  })
  it('does not borrow a clock from another field in a broad quote', () => {
    const response = structuredClone(RESPONSE)
    response.evidence[5]!.quote =
      'Evolução: alerta às 16:00. Pendência: conferir ficha'
    response.evidence[4]!.quote = 'Pendência: conferir ficha'
    const raw = RAW.replace(
      'Evolução: alerta',
      'Evolução: alerta às 16:00'
    ).replace('conferir ficha às 16:00', 'conferir ficha')
    response.pacientes[0]!.evolucao = 'alerta às 16:00'
    response.evidence[3]!.quote = 'Evolução: alerta às 16:00'
    blocked(raw, response, 'pendencias.t1.quando')
  })
  it('rejects cross-patient source despite the same unit and valid literal quote elsewhere', () => {
    const c = evolution(
      'dose 1 mg/kg',
      'dose 2 mg/kg',
      'Evolução: dose 2 mg/kg'
    )
    blocked(
      c.raw + '\nPaciente Lua, ID 3. Evolução: dose 2 mg/kg.',
      c.response,
      'pacientes.p1.evolucao'
    )
  })
  it('preserves absolute literal UTF16 evidence with non-BMP and complete units', () => {
    const c = evolution('dose 1 mg/kg')
    c.raw = '🧪 treinamento sintético. ' + c.raw
    const result = check(c.raw, c.response)
    expect(result.issues).toEqual([])
    for (const e of result.evidence)
      expect(c.raw.slice(e.start, e.end)).toBe(e.quote)
    expect(result.evidence[0]!.start).toBe(c.raw.indexOf('Paciente Rex'))
  })
  it('real reducer recomputes F01/F02 and rejects falsely empty issues', () => {
    for (const c of [
      bed('1', '2', 'leito 1, ID 2'),
      evolution('dose 1 mg/kg', 'dose 1 mg')
    ]) {
      c.response.pendencias = []
      c.response.evidence = c.response.evidence.filter(
        (e) => !e.path.startsWith('pendencias.')
      )
      expect(() => replay(c.raw, c.response, true)).toThrow('STATE_CONFLICT')
      const state = replay(c.raw, c.response)
      expect(state.notes.get('source-note')?.issues.length).toBeGreaterThan(0)
      expect(state.tasks.size).toBe(0)
    }
  })
  it('real reducer accepts valid complete compound unit and equivalent numeral provenance', () => {
    const c = evolution('dose um mg/kg/h', 'dose 1 mg/kg/h')
    c.response.pendencias = []
    c.response.evidence = c.response.evidence.filter(
      (e) => !e.path.startsWith('pendencias.')
    )
    const state = replay(c.raw, c.response)
    expect(state.notes.get('source-note')?.issues).toEqual([])
    expect(
      state.notes
        .get('source-note')
        ?.evidence.some((e) => e.quote === 'Evolução: dose um mg/kg/h')
    ).toBe(true)
  })
  it('retains existing complete admission/audio-text fixture fields without a provider', () => {
    for (const fixture of [
      ADMISSION,
      THOR_AUDIO,
      BOB_AUDIO,
      { raw: LEGACY_RAW, response: LEGACY_RESPONSE }
    ]) {
      const response = structuredClone(fixture.response)
      for (const t of response.pendencias)
        if (t.quando)
          t.quando = t.quando.replace(/^2026-\d{2}-\d{2}/, '2026-10-03')
      expect(check(fixture.raw, response).issues, fixture.raw).toEqual([])
    }
  })
  it('does not truncate free prose at incidental words received or peso', () => {
    for (const source of [
      'não recebeu dose 1 mg/kg',
      'alerta sem peso anotado',
      'peso corporal informado 4 kg'
    ]) {
      const c = evolution(source)
      expect(check(c.raw, c.response).issues).toEqual([])
      c.response.pacientes[0]!.evolucao = source.split(' ')[0]!
      blocked(c.raw, c.response, 'pacientes.p1.evolucao')
    }
  })
  it('a negated marker in arbitrary prose cannot grant a field', () => {
    const response = structuredClone(RESPONSE)
    response.evidence[3]!.quote = 'Evolução: alerta'
    blocked(
      RAW.replace('Evolução:', 'não Evolução:'),
      response,
      'pacientes.p1.evolucao'
    )
  })
  it('a next named/header field bounds the clinical value without lending numeric values', () => {
    for (const next of [
      'Condutas: dose 2 mg',
      'ID 2',
      'leito 2',
      'a anotação anterior dizia dose 2 mg'
    ]) {
      const c = evolution('dose 1 mg. ' + next, 'dose 2 mg')
      blocked(c.raw, c.response, 'pacientes.p1.evolucao')
      c.response.pacientes[0]!.evolucao = 'dose 1 mg'
      c.response.evidence[3]!.quote = 'Evolução: dose 1 mg'
      expect(check(c.raw, c.response).issues, next).toEqual([])
    }
  })

  it.each([
    ['dose -dois mg', 'dose -2 mg'],
    ['dose menos dois mg', 'dose -2 mg'],
    ['dose um/dois mg', 'dose 1/2 mg'],
    ['dose um / dois mg', 'dose 1 / 2 mg'],
    ['dose um a dois mg', 'dose 1 a 2 mg'],
    ['dose um até dois mg', 'dose 1 até 2 mg'],
    ['concentração vinte por cento', 'concentração 20 por cento'],
    ['concentração vinte%', 'concentração 20%']
  ])(
    'C2 forbids converting pieces of unsupported compound %s -> %s',
    (source, output) => {
      const c = evolution(source, output)
      blocked(c.raw, c.response, 'pacientes.p1.evolucao')
      c.response.pacientes[0]!.evolucao = source
      expect(check(c.raw, c.response).issues).toEqual([])
    }
  )
  it('newline bounds explicit fields and never lets an ID lend its scalar', () => {
    const c = evolution('dose 1 mg\nCondutas: dose 2 mg', 'dose 2 mg')
    blocked(c.raw, c.response, 'pacientes.p1.evolucao')
    c.response.pacientes[0]!.evolucao = 'dose 1 mg'
    c.response.evidence[3]!.quote = 'Evolução: dose 1 mg'
    expect(check(c.raw, c.response).issues).toEqual([])
  })

  it('comma-separated next header field is a boundary, not a number pool', () => {
    const c = evolution('dose 1 mg, ID 2', 'dose 2 mg')
    blocked(c.raw, c.response, 'pacientes.p1.evolucao')
    c.response.pacientes[0]!.evolucao = 'dose 1 mg'
    c.response.evidence[3]!.quote = 'Evolução: dose 1 mg'
    expect(check(c.raw, c.response).issues).toEqual([])
  })
  it('C2 folds case/spaces only inside finite numerals, preserving full literal units and prose', () => {
    for (const [source, output] of [
      ['dose DOIS mg/kg', 'dose 2 mg/kg'],
      ['dose trinta  e oito mg/kg', 'dose 38 mg/kg']
    ]) {
      const c = evolution(source!, output!)
      expect(check(c.raw, c.response).issues).toEqual([])
      c.response.pacientes[0]!.evolucao = output!.replace('mg/kg', 'MG/kg')
      blocked(c.raw, c.response, 'pacientes.p1.evolucao')
    }
  })
})
