import { HELP_TEXT, NEW_PATIENT_TEMPLATE, parseCommand } from './commands.ts'
import {
  type InboundMessage,
  type Member,
  type NoteV2,
  type Outbox,
  type V2Event,
  type Inbox,
  samePhone
} from './domain.ts'
import {
  type Organizer,
  parseOrganizerResponse,
  formatLocalTime
} from './organizer.ts'
import { type ShiftStore, type CommitExpected } from './store.ts'
import { canonical, sha256, StoreError } from './journal.ts'
import { inputDigest, revisionToken, taskId } from './vertical-state.ts'
import { validateOrganization } from './source-evidence.ts'
import type { Transcriber } from './transcriber.ts'
import type { WhatsAppClient } from './whatsapp.ts'

export interface ShiftLogger {
  info(event: string, fields?: Record<string, unknown>): void
  error(event: string, fields?: Record<string, unknown>): void
}
export interface ShiftAssistantOptions {
  store: ShiftStore
  members: readonly Member[]
  whatsapp: WhatsAppClient
  organizer: Organizer
  transcriber: Transcriber
  clock?: () => Date
  logger?: ShiftLogger
  defaultDueMinutes?: number
  reminderIntervalMinutes?: number
  maxReminders?: number
  session?: string
  modelTimeoutMs?: number
}
const BACKOFF = [30000, 120000, 600000, 1800000]
export class ShiftAssistant {
  readonly #o: ShiftAssistantOptions
  readonly #clock: () => Date
  readonly #session: string
  #runner: Promise<void> | undefined
  #dispatcher: Promise<void> | undefined
  #stopping = false
  #controller: AbortController | undefined
  readonly #sends = new Set<AbortController>()
  #failureCount = 0
  constructor(options: ShiftAssistantOptions) {
    this.#o = options
    this.#clock = options.clock ?? (() => new Date())
    this.#session = options.session ?? options.whatsapp.session ?? 'default'
    if (
      !this.#session.trim() ||
      !options.members.some((m) => m.manager) ||
      options.members.some((m, i) =>
        options.members.some((n, j) => i !== j && samePhone(m.phone, n.phone))
      )
    )
      throw new Error('Invalid member/session configuration')
  }
  member(phone: string): Member | undefined {
    return this.#o.members.find((m) => samePhone(m.phone, phone))
  }
  #now(): string {
    return this.#clock().toISOString()
  }
  #actor(phone: string) {
    return { kind: 'member' as const, memberPhone: phone }
  }
  #commit(id: string, changes: V2Event[]): void {
    const expected: CommitExpected = {}
    for (const e of changes) {
      if ('outbox' in e && e.outbox) e.outbox.sourceTransitionId = id
      if ('outboxes' in e)
        for (const box of e.outboxes) box.sourceTransitionId = id
      for (const [entity, key] of this.#o.store.references(e)) {
        const map = expected[entity] ?? {}
        map[String(key)] = this.#o.store.revision(entity, key)
        expected[entity] = map
      }
    }
    this.#o.store.commit({ transitionId: id, expected, changes })
  }
  #box(
    id: string,
    phone: string,
    text: string,
    purpose: Outbox['purpose'] = 'response',
    note?: NoteV2
  ): Outbox {
    return {
      id,
      purpose,
      sourceTransitionId: id,
      recipientMemberId: phone,
      payloadText: text,
      payloadSha256: sha256(text),
      state: 'queued',
      attempt: 0,
      ...(note ? { noteId: note.id, noteRevision: note.revision } : {})
    }
  }
  receive(message: InboundMessage): boolean {
    if (this.#stopping) throw new StoreError('STORAGE_UNAVAILABLE')
    const m = this.member(message.fromPhone)
    if (!m) return false
    if (!this.#o.store.storageAvailable)
      throw new StoreError('STORAGE_UNAVAILABLE')
    if (
      message.text.length > 16384 ||
      !message.messageId ||
      message.messageId.length > 256
    )
      throw new StoreError('INVALID_TRANSITION')
    // Inline envelope admission is outside this text slice; never write base64 into a transaction.
    if (message.mediaRef?.startsWith('base64:'))
      throw new StoreError('INVALID_TRANSITION')
    const key = JSON.stringify([
      message.provider,
      this.#session,
      message.messageId
    ])
    const inbox: Inbox = {
      key,
      digest: '0'.repeat(64),
      provider: message.provider,
      session: this.#session,
      messageId: message.messageId,
      memberPhone: m.phone,
      kind: message.kind,
      text: message.text,
      receivedAt: message.receivedAt,
      state: 'received',
      stage: parseCommand(message.text)
        ? 'command'
        : message.kind === 'text'
          ? 'organize'
          : 'media',
      attempt: 0,
      ...(message.mediaRef ? { mediaRef: message.mediaRef } : {}),
      ...(message.mimetype ? { mimetype: message.mimetype } : {})
    }
    inbox.digest = inputDigest(inbox)
    const previous = this.#o.store.inbox(key)
    if (previous) {
      if (previous.digest !== inbox.digest)
        throw new StoreError('IDEMPOTENCY_CONFLICT')
      return false
    }
    const cmd = parseCommand(message.text)
    if (
      this.#o.store
        .inboxes()
        .filter((i) => !['processed', 'review_required'].includes(i.state))
        .length >= 1000 &&
      !(cmd && ['pause', 'resume'].includes(cmd.type))
    )
      throw new Error('QUEUE_FULL')
    const at = this.#now(),
      actor = this.#actor(m.phone)
    const events: V2Event[] = [
      { v: 2, type: 'inbound_recorded', at, actor, inbox }
    ]
    // Manager control is a synchronous lane independent of a suspended organizer/send.
    if (cmd && ['pause', 'resume'].includes(cmd.type) && m.manager) {
      const pause = cmd.type === 'pause'
      events.push({
        v: 2,
        type: pause ? 'operation_paused' : 'operation_resumed',
        key,
        at,
        actor,
        outbox: this.#box(
          'control:' + sha256(key),
          m.phone,
          pause ? 'Assistente pausado.' : 'Assistente retomado.',
          'control'
        )
      })
    }
    if (cmd?.type === 'correct') {
      const notes = this.#o.store.notesV2().filter(
        (n) =>
          n.authorPhone === m.phone &&
          n.state !== 'superseded' &&
          (!n.replacementPending ||
            (this.#o.store
              .inboxes()
              .some((entry) => entry.replacementOf === n.id) &&
              this.#o.store
                .inboxes()
                .filter((entry) => entry.replacementOf === n.id)
                .every((entry) => entry.state === 'review_required')))
      )
      const presented = this.#o.store.lastPresentedNote(m.phone)
      const selected = cmd.token
        ? notes.filter((n) => n.token === cmd.token)
        : notes.filter(
            (n) =>
              n.id === presented?.noteId && n.revision === presented?.revision
          )
      const note = selected.length === 1 ? selected[0] : undefined
      if (note) {
        inbox.replacementText = cmd.text
        events.push({
          v: 2,
          type: 'replacement_started',
          at,
          actor,
          key,
          noteId: note.id,
          revision: note.revision
        })
      }
    }
    this.#commit('admit:' + sha256(key), events)
    if (cmd?.type === 'pause' && m.manager) {
      this.#controller?.abort('paused')
      for (const c of this.#sends) c.abort('paused')
    }
    this.resumePending()
    return true
  }
  resumePending(): number {
    if (!this.#o.store.storageAvailable || this.#stopping) return 0
    const eligible = this.#eligible()
    if (!this.#runner && eligible.length) {
      const runner = this.#processLoop()
      this.#runner = runner
      void runner
        .finally(() => {
          this.#runner = undefined
          this.#startDispatch()
          if (this.#eligible().length) this.resumePending()
        })
        .catch(() => {})
    }
    this.#startDispatch()
    return eligible.length
  }
  recoverPending(): void {
    for (const i of this.#o.store.inboxes())
      if (i.state === 'processing')
        this.#commit(
          'recover-inbox:' +
            sha256(i.key) +
            ':' +
            this.#o.store.revision('inbox', i.key),
          [
            {
              v: 2,
              type: 'processing_retry_scheduled',
              at: this.#now(),
              actor: this.#actor(i.memberPhone),
              key: i.key,
              state: i.attempt >= 5 ? 'review_required' : 'received',
              attempt: i.attempt,
              error: 'processing_interrupted'
            }
          ]
        )
    for (const b of this.#o.store.outboxes())
      if (b.state === 'dispatching')
        this.#commit('recover-outbox:' + b.id + ':' + b.attempt, [
          {
            v: 2,
            type: 'outbox_result',
            at: this.#now(),
            actor: this.#actor(b.recipientMemberId),
            outboxId: b.id,
            state: 'uncertain',
            error: 'dispatch_interrupted'
          }
        ])
    this.resumePending()
  }
  #eligible(): Inbox[] {
    if (!this.#o.store.effectsAllowed || this.#stopping) return []
    return this.#o.store
      .inboxes()
      .filter(
        (i) =>
          ['received', 'retry_wait'].includes(i.state) &&
          (!i.nextAttemptAt ||
            Date.parse(i.nextAttemptAt) <= this.#clock().getTime())
      )
  }
  async idle(): Promise<{ failures: number }> {
    // Future retries are deliberately not awaited.
    while (this.#runner || this.#dispatcher) {
      await Promise.all([this.#runner, this.#dispatcher])
    }
    return { failures: this.#failureCount }
  }
  async #processLoop(): Promise<void> {
    while (this.#eligible().length) {
      const i = this.#eligible()[0]!
      try {
        await this.#process(i)
      } catch {
        this.#failureCount++
        this.#o.logger?.error('shift.processing.failed', {
          code: this.#o.store.storageAvailable
            ? 'PROCESSING_FAILED'
            : 'STORAGE_UNAVAILABLE'
        })
        if (!this.#o.store.storageAvailable) break
      }
    }
  }
  async #process(initial: Inbox): Promise<void> {
    const { store } = this.#o
    const at = this.#now(),
      actor = this.#actor(initial.memberPhone),
      key = initial.key
    const cmd = initial.replacementOf ? undefined : parseCommand(initial.text)
    this.#commit(
      'processing:' + sha256(key) + ':' + store.revision('inbox', key),
      [
        {
          v: 2,
          type: 'processing_started',
          at,
          actor,
          key,
          stage: cmd ? 'command' : initial.stage,
          attempt: initial.attempt + 1,
          deadline: new Date(this.#clock().getTime() + 210000).toISOString(),
          draftAt: initial.draftAt ?? at
        }
      ]
    )
    const controller = new AbortController()
    this.#controller = controller
    const deadline = setTimeout(
      () => controller.abort('deadline'),
      this.#o.modelTimeoutMs ?? 60000
    )
    try {
      if (!this.member(initial.memberPhone)) {
        this.#retry(store.inbox(key)!, 'member_revoked', true)
        return
      }
      if (cmd) {
        this.#command(store.inbox(key)!, cmd)
        return
      }
      let i = store.inbox(key)!
      if (i.kind !== 'text' && !i.transcript) {
        if (!i.mediaPath) {
          const bytes = await this.#o.whatsapp.downloadMedia({
            provider: i.provider,
            messageId: i.messageId,
            fromPhone: i.memberPhone,
            kind: i.kind,
            text: i.text,
            receivedAt: i.receivedAt,
            ...(i.mediaRef ? { mediaRef: i.mediaRef } : {}),
            ...(i.mimetype ? { mimetype: i.mimetype } : {})
          })
          if (controller.signal.aborted)
            return this.#interrupt(key, controller.signal.reason)
          const d = store.saveMediaDescriptor(
            bytes.bytes,
            bytes.mimetype.split(';')[0] as Parameters<
              ShiftStore['saveMediaDescriptor']
            >[1],
            key
          )
          this.#commit('media:' + sha256(key), [
            {
              v: 2,
              type: 'media_attached',
              at: this.#now(),
              actor,
              key,
              path: d.path
            }
          ])
          // Compatibility audio seam: transcript is durable before organizer; no retranscription after retry.
          if (i.kind === 'audio') {
            const transcript = await this.#o.transcriber.transcribe(bytes)
            if (controller.signal.aborted)
              return this.#interrupt(key, controller.signal.reason)
            this.#commit('transcript:' + sha256(key), [
              {
                v: 2,
                type: 'transcript_recorded',
                at: this.#now(),
                actor,
                key,
                text: transcript,
                sha256: sha256(transcript)
              }
            ])
          } else
            this.#commit('caption:' + sha256(key), [
              {
                v: 2,
                type: 'transcript_recorded',
                at: this.#now(),
                actor,
                key,
                text: i.text,
                sha256: sha256(i.text)
              }
            ])
        } else if (!i.transcript) {
          this.#retry(i, 'media_transcript_recovery_required', true)
          return
        }
        i = store.inbox(key)!
      }
      const raw = i.transcript ?? i.replacementText ?? i.text
      let response: unknown
      try {
        response = await abortable(
          this.#o.organizer.organize(
            raw,
            new Date(i.draftAt!),
            controller.signal
          ),
          controller.signal
        )
      } catch (error) {
        if (controller.signal.aborted)
          return this.#interrupt(key, controller.signal.reason)
        const code =
          error && typeof error === 'object' && 'code' in error
            ? String(error.code)
            : 'organizer_failed'
        if (
          [
            'policy_denied',
            'schema_invalid',
            'invalid_request',
            'response_too_large'
          ].includes(code)
        ) {
          this.#draft(i, undefined, [code])
          return
        }
        if (i.attempt < 5) {
          this.#retry(i, 'organizer_transient', false)
          return
        }
        this.#draft(i, undefined, ['organizer_failed'])
        return
      }
      if (controller.signal.aborted)
        return this.#interrupt(key, controller.signal.reason)
      const parsed = (() => {
        try {
          return parseOrganizerResponse(response)
        } catch {
          return undefined
        }
      })()
      this.#draft(i, parsed, parsed ? [] : ['schema_invalid'])
    } catch {
      if (store.storageAvailable) {
        const i = store.inbox(key)
        if (i?.state === 'processing')
          this.#retry(i, 'processing_failed', false)
      } else throw new StoreError('STORAGE_UNAVAILABLE')
    } finally {
      clearTimeout(deadline)
      if (this.#controller === controller) this.#controller = undefined
    }
  }
  #interrupt(key: string, cause: unknown): void {
    const i = this.#o.store.inbox(key)!
    if (cause === 'deadline') {
      this.#retry(i, 'organizer_deadline', false)
      return
    }
    if (this.#o.store.storageAvailable)
      this.#commit(
        'interrupt:' + sha256(key) + ':' + this.#o.store.revision('inbox', key),
        [
          {
            v: 2,
            type: 'processing_retry_scheduled',
            at: this.#now(),
            actor: this.#actor(i.memberPhone),
            key,
            state: 'received',
            attempt: Math.max(0, i.attempt - 1),
            error: this.#stopping ? 'shutdown' : 'paused'
          }
        ]
      )
  }
  #retry(i: Inbox, error: string, permanent: boolean): void {
    const exhausted = permanent || i.attempt >= 5
    this.#commit(
      'retry:' + sha256(i.key) + ':' + this.#o.store.revision('inbox', i.key),
      [
        {
          v: 2,
          type: 'processing_retry_scheduled',
          at: this.#now(),
          actor: this.#actor(i.memberPhone),
          key: i.key,
          state: exhausted ? 'review_required' : 'retry_wait',
          attempt: i.attempt,
          error,
          ...(exhausted && i.replacementOf
            ? {
                outbox: this.#box(
                  'replacement-failure:' + sha256(i.key),
                  i.memberPhone,
                  'Correção pendente de revisão. A nota anterior permanece em substituição pendente e suas pendências continuam suspensas.'
                )
              }
            : {}),
          ...(!exhausted
            ? {
                nextAttemptAt: new Date(
                  this.#clock().getTime() + BACKOFF[i.attempt - 1]!
                ).toISOString()
              }
            : {})
        }
      ]
    )
    this.#failureCount++
    if (exhausted && i.replacementOf) this.#startDispatch()
  }
  #draft(
    i: Inbox,
    organized: ReturnType<typeof parseOrganizerResponse> | undefined,
    warnings: string[]
  ): void {
    const previous = i.replacementOf
      ? this.#o.store.noteV2(i.replacementOf)
      : undefined
    const revision = (previous?.revision ?? 0) + 1
    const raw = i.transcript ?? i.replacementText ?? i.text
    const validation = organized
      ? validateOrganization(raw, organized, this.#o.store.notesV2(), i.draftAt)
      : { evidence: [], bindings: [], issues: [] }
    if (
      previous &&
      (!organized ||
        warnings.length ||
        validation.issues.length ||
        organized.duvidas.length)
    ) {
      this.#retry(i, warnings[0] ?? 'replacement_validation_blocked', true)
      return
    }
    const id = sha256(JSON.stringify([i.key, revision]))
    const n: NoteV2 = {
      id,
      messageKey: i.key,
      authorPhone: i.memberPhone,
      revision,
      createdAt: i.draftAt!,
      rawText: raw,
      rawTextSha256: sha256(raw),
      organizedSha256: sha256(canonical(organized ?? null)),
      token: 'pending',
      state: 'draft',
      replacementPending: false,
      ...(organized ? { organized } : {}),
      ...validation,
      warnings,
      tasks: [],
      previewIds: ['preview:' + id]
    }
    n.token = revisionToken(n)
    if (organized && !validation.issues.length && !organized.duvidas.length) {
      for (const [index, p] of organized.pendencias.entries()) {
        const binding = validation.bindings.find(
          (b) => b.localRef === p.pacienteRef
        )
        const explicit =
          p.quando && Date.parse(p.quando) > Date.parse(i.draftAt!)
        const dueAt = explicit
          ? new Date(p.quando!).toISOString()
          : new Date(
              Date.parse(i.draftAt!) +
                (this.#o.defaultDueMinutes ?? 120) * 60000
            ).toISOString()
        if (!explicit) n.warnings.push('due_fallback_2h:' + p.localRef)
        n.tasks.push({
          id: taskId(id, revision, p.localRef),
          number: this.#o.store.nextTaskNumber() + index,
          noteId: id,
          noteRevision: revision,
          localRef: p.localRef,
          ownerPhone: i.memberPhone,
          description: p.descricao,
          patientRef: p.pacienteRef,
          patientId: binding?.idLiteral ?? null,
          bindingRevision: revision,
          sourceRefs: validation.evidence
            .filter((e) => e.path.startsWith('pendencias.' + p.localRef + '.'))
            .map((e) => e.path),
          dueAt,
          createdAt: i.draftAt!,
          status: 'draft',
          generation: 1,
          remindedCount: 0
        })
      }
    }
    let preview = formatNoteReply(n)
    if (Buffer.byteLength(preview) > 131072) {
      n.tasks = []
      delete n.organized
      n.evidence = []
      n.bindings = []
      n.issues = []
      n.warnings.push('preview_limit')
      n.organizedSha256 = sha256('null')
      n.token = revisionToken(n)
      preview = `RASCUNHO\n${raw}\nAviso: preview_limit\nZero tarefas derivadas.\nConfirme a fonte bruta: ok nota ${n.token}`
    }
    const parts = splitPreview(preview)
    n.previewIds = parts.map(
      (_, index) =>
        'preview:' + id + (parts.length > 1 ? '/part' + (index + 1) : '')
    )
    const outboxes = parts.map((part, index) =>
      this.#box(n.previewIds[index]!, i.memberPhone, part, 'preview', n)
    )
    const common = {
      v: 2 as const,
      at: this.#now(),
      actor: this.#actor(i.memberPhone),
      key: i.key,
      note: n,
      outboxes
    }
    this.#commit('draft:' + sha256(i.key) + ':' + revision, [
      previous
        ? {
            ...common,
            type: 'replacement_prepared',
            previousNoteId: previous.id
          }
        : { ...common, type: 'draft_prepared' }
    ])
    this.#startDispatch()
  }
  #response(i: Inbox, text: string, extra: V2Event[] = []): void {
    const outbox = this.#box('response:' + sha256(i.key), i.memberPhone, text)
    this.#commit('response:' + sha256(i.key), [
      ...extra,
      {
        v: 2,
        type: 'response_committed',
        at: this.#now(),
        actor: this.#actor(i.memberPhone),
        key: i.key,
        outbox
      }
    ])
    this.#startDispatch()
  }
  #command(i: Inbox, cmd: NonNullable<ReturnType<typeof parseCommand>>): void {
    const actor = this.#actor(i.memberPhone),
      at = this.#now(),
      store = this.#o.store
    switch (cmd.type) {
      case 'help':
        this.#response(i, HELP_TEXT)
        return
      case 'template':
        this.#response(i, NEW_PATIENT_TEMPLATE)
        return
      case 'pause':
      case 'resume':
        this.#response(i, 'Somente o gestor pode controlar o assistente.')
        return
      case 'correct':
        this.#response(
          i,
          'CONFIRMATION_NOT_ELIGIBLE: informe o token da sua revisão atual.'
        )
        return
      case 'confirm': {
        const eligible = (n: NoteV2) =>
          n.authorPhone === i.memberPhone &&
          n.state === 'draft' &&
          !n.replacementPending &&
          !n.issues.length &&
          !n.organized?.duvidas.length &&
          n.previewIds.length > 0 &&
          n.previewIds.every(
            (id) => store.outbox(id)?.state === 'provider_accepted'
          )
        let matches = store
          .notesV2()
          .filter(
            (n) => n.authorPhone === i.memberPhone && n.token === cmd.token
          )
        if (!cmd.token) {
          matches = store.notesV2().filter(eligible)
          const presented = store.lastPresentedNote(i.memberPhone)
          const earlier = store.inboxes()
          const current = earlier.findIndex((entry) => entry.key === i.key)
          const pending = earlier
            .slice(0, current)
            .some(
              (entry) =>
                entry.memberPhone === i.memberPhone &&
                entry.state !== 'processed' &&
                (entry.replacementOf ||
                  entry.kind !== 'text' ||
                  !parseCommand(entry.text) ||
                  parseCommand(entry.text)?.type === 'correct')
            )
          if (
            current < 0 ||
            pending ||
            matches.length !== 1 ||
            !presented ||
            presented?.noteId !== matches[0]!.id ||
            presented.revision !== matches[0]!.revision
          ) {
            this.#response(
              i,
              'CONFIRMATION_NOT_ELIGIBLE: informe o token exato: ok nota <token>.'
            )
            return
          }
        }
        if (matches.length !== 1) {
          this.#response(
            i,
            'CONFIRMATION_NOT_ELIGIBLE: informe o token exato: ok nota <token>.'
          )
          return
        }
        const n = matches[0]!
        if (n?.state === 'confirmed' && !n.replacementPending) {
          this.#response(i, 'Nota já confirmada.')
          return
        }
        if (
          !n ||
          n.state !== 'draft' ||
          n.replacementPending ||
          n.issues.length ||
          n.organized?.duvidas.length ||
          !n.previewIds.every(
            (id) => store.outbox(id)?.state === 'provider_accepted'
          )
        ) {
          this.#response(
            i,
            'CONFIRMATION_NOT_ELIGIBLE: revise fonte, autor e token.'
          )
          return
        }
        const outbox = this.#box(
          'confirmation:' + sha256(i.key),
          i.memberPhone,
          'Nota confirmada.' +
            (n.tasks.length
              ? ' Pendências ativadas.'
              : ' Zero tarefas derivadas.')
        )
        this.#commit(
          'confirm:' + n.id + ':' + n.revision + ':' + sha256(i.key),
          [
            {
              v: 2,
              type: 'confirmation_committed',
              at,
              actor,
              key: i.key,
              noteId: n.id,
              revision: n.revision,
              hash: n.organizedSha256,
              token: n.token,
              tasks: n.tasks.map((t) => ({ ...t, status: 'open' })),
              bindings: n.bindings.map((b) => ({
                ...b,
                confirmedBy: i.memberPhone,
                confirmedAt: at
              })),
              outbox
            }
          ]
        )
        this.#startDispatch()
        return
      }
      case 'list':
        this.#response(
          i,
          store
            .tasksV2()
            .filter(
              (t) => t.ownerPhone === i.memberPhone && t.status === 'open'
            )
            .map(
              (t) =>
                `#${t.number} — ${t.description} · ${formatLocalTime(t.dueAt)}`
            )
            .join('\n') || 'Você não tem pendências abertas.'
        )
        return
      case 'done':
      case 'snooze': {
        const t = store
          .tasksV2()
          .find(
            (t) =>
              t.number === cmd.number &&
              t.ownerPhone === i.memberPhone &&
              t.status === 'open'
          )
        if (!t) {
          this.#response(
            i,
            `Não encontrei a pendência ${cmd.number} aberta para você.`
          )
          return
        }
        const e: V2Event =
          cmd.type === 'done'
            ? { v: 2, type: 'task_completed', at, actor, number: t.number }
            : {
                v: 2,
                type: 'task_snoozed_v2',
                at,
                actor,
                number: t.number,
                dueAt: new Date(
                  Math.max(this.#clock().getTime(), Date.parse(t.dueAt)) +
                    cmd.minutes * 60000
                ).toISOString()
              }
        this.#response(
          i,
          cmd.type === 'done'
            ? `Pendência ${t.number} concluída.`
            : `Pendência ${t.number} adiada.`,
          [e]
        )
        return
      }
    }
  }
  #startDispatch(): void {
    if (this.#dispatcher || this.#stopping || !this.#o.store.storageAvailable)
      return
    if (
      !this.#o.store
        .outboxes()
        .some(
          (b) =>
            ['queued', 'retry_wait'].includes(b.state) &&
            (!b.nextAttemptAt ||
              Date.parse(b.nextAttemptAt) <= this.#clock().getTime()) &&
            (!this.#o.store.paused || b.purpose === 'control')
        )
    )
      return
    const work = this.#dispatchLoop()
    this.#dispatcher = work
    void work
      .finally(() => {
        this.#dispatcher = undefined
      })
      .catch(() => {})
  }
  #previewPredecessorsAccepted(b: Outbox): boolean {
    if (b.purpose !== 'preview' || !b.noteId) return true
    const ids = this.#o.store.noteV2(b.noteId)?.previewIds ?? []
    const index = ids.indexOf(b.id)
    return (
      index >= 0 &&
      ids
        .slice(0, index)
        .every((id) => this.#o.store.outbox(id)?.state === 'provider_accepted')
    )
  }
  async #dispatchLoop(): Promise<void> {
    const store = this.#o.store
    while (!this.#stopping && store.storageAvailable) {
      const b = store
        .outboxes()
        .find(
          (b) =>
            ['queued', 'retry_wait'].includes(b.state) &&
            (!b.nextAttemptAt ||
              Date.parse(b.nextAttemptAt) <= this.#clock().getTime()) &&
            (!store.paused || b.purpose === 'control') &&
            this.#previewPredecessorsAccepted(b)
        )
      if (!b || store.operationalHold) break
      const actor = this.#actor(b.recipientMemberId),
        at = this.#now()
      const n = b.noteId ? store.noteV2(b.noteId) : undefined,
        t = b.taskNumber
          ? store.tasksV2().find((t) => t.number === b.taskNumber)
          : undefined
      if (
        !this.member(b.recipientMemberId) ||
        (b.noteId &&
          (!n ||
            n.state === 'superseded' ||
            n.replacementPending ||
            n.revision !== b.noteRevision)) ||
        (b.taskNumber &&
          (!t || t.status !== 'open' || t.generation !== b.taskGeneration))
      ) {
        this.#commit('cancel:' + b.id, [
          {
            v: 2,
            type: 'outbox_result',
            at,
            actor,
            outboxId: b.id,
            state: 'cancelled',
            error: 'recipient_or_version_obsolete'
          }
        ])
        continue
      }
      const c = new AbortController()
      this.#sends.add(c)
      try {
        // Synchronous recheck + intent fsync + start send have no await between them.
        if (
          this.#stopping ||
          !store.storageAvailable ||
          (!store.effectsAllowed && b.purpose !== 'control')
        )
          break
        this.#commit('dispatch:' + b.id + ':' + (b.attempt + 1), [
          {
            v: 2,
            type: 'outbox_dispatch_started',
            at,
            actor,
            outboxId: b.id,
            attempt: b.attempt + 1
          }
        ])
        const result = await this.#o.whatsapp.sendText(
          b.recipientMemberId,
          b.payloadText,
          c.signal
        )
        const event: V2Event = {
          v: 2,
          type: 'outbox_result',
          at: this.#now(),
          actor,
          outboxId: b.id,
          state: 'uncertain',
          error: 'missing_typed_receipt'
        }
        if (result?.status === 'provider_accepted') {
          event.state = 'provider_accepted'
          event.receipt = { ...result.receipt, at: this.#now() }
          delete event.error
        } else if (result?.status === 'definitely_not_accepted') {
          event.state =
            b.attempt + 1 < 5 && b.purpose !== 'control'
              ? 'retry_wait'
              : 'review_required'
          event.error =
            event.state === 'retry_wait'
              ? 'definitely_not_accepted'
              : result.code
          if (event.state === 'retry_wait')
            event.nextAttemptAt = new Date(
              this.#clock().getTime() + BACKOFF[b.attempt]!
            ).toISOString()
        } else if (result?.status === 'uncertain') event.error = result.code
        this.#commit('result:' + b.id + ':' + (b.attempt + 1), [event])
      } catch {
        this.#failureCount++
        if (
          store.storageAvailable &&
          store.outbox(b.id)?.state === 'dispatching'
        )
          this.#commit('uncertain:' + b.id + ':' + (b.attempt + 1), [
            {
              v: 2,
              type: 'outbox_result',
              at: this.#now(),
              actor,
              outboxId: b.id,
              state: 'uncertain',
              error: 'post_start_failure'
            }
          ])
        if (!store.storageAvailable) break
      } finally {
        this.#sends.delete(c)
      }
    }
  }
  async tick(): Promise<number> {
    if (this.#stopping || !this.#o.store.effectsAllowed) return 0
    this.resumePending()
    let count = 0
    for (const t of this.#o.store.tasksV2()) {
      if (
        t.status !== 'open' ||
        Date.parse(t.dueAt) > this.#clock().getTime() ||
        !this.member(t.ownerPhone)
      )
        continue
      const previous = this.#o.store
        .outboxes()
        .filter(
          (b) =>
            b.taskNumber === t.number &&
            b.taskGeneration === t.generation &&
            b.purpose === 'reminder'
        )
      if (
        previous.length >= 4 ||
        previous.some((b) => b.state !== 'provider_accepted') ||
        (previous.at(-1)?.receipt &&
          this.#clock().getTime() - Date.parse(previous.at(-1)!.receipt!.at) <
            1800000)
      )
        continue
      const slot = previous.length + 1
      const n = this.#o.store.noteV2(t.noteId)!
      const b = {
        ...this.#box(
          `reminder:${t.id}:${t.generation}:${slot}`,
          t.ownerPhone,
          `⏰ Lembrete #${t.number}: ${t.description}`,
          'reminder',
          n
        ),
        taskNumber: t.number,
        taskGeneration: t.generation,
        slot
      }
      this.#commit(b.id, [
        {
          v: 2,
          type: 'reminder_reserved',
          at: this.#now(),
          actor: this.#actor(t.ownerPhone),
          number: t.number,
          outbox: b
        }
      ])
      count++
    }
    this.#startDispatch()
    await this.#dispatcher
    return count
  }
  async stop(): Promise<void> {
    if (this.#stopping) return
    this.#stopping = true
    this.#controller?.abort('shutdown')
    for (const c of this.#sends) c.abort('shutdown')
    let timer: ReturnType<typeof setTimeout> | undefined
    try {
      await Promise.race([
        this.idle(),
        new Promise<never>((_, reject) => {
          timer = setTimeout(() => reject(new Error('SHUTDOWN_TIMEOUT')), 10000)
        })
      ])
    } finally {
      if (timer) clearTimeout(timer)
    }
  }
  get stopping(): boolean {
    return this.#stopping
  }
}
export function formatNoteReply(n: NoteV2): string {
  const lines = ['RASCUNHO', `Fonte:\n${n.rawText}`]
  if (!n.organized)
    lines.push(
      'Guardei a fonte; não consegui organizá-la. Zero tarefas derivadas.'
    )
  for (const p of n.organized?.pacientes ?? []) {
    lines.push(
      [
        p.nome,
        p.id ? 'ID ' + p.id : 'ID não informado',
        p.especie,
        p.leito ? 'leito ' + p.leito : null
      ]
        .filter(Boolean)
        .join(' · ')
    )
    if (p.tutor) lines.push('Tutor: ' + p.tutor)
    if (p.motivo) lines.push('Motivo da internação: ' + p.motivo)
    if (p.evolucao) lines.push('Evolução: ' + p.evolucao)
    if (p.exames_pedidos.length)
      lines.push(
        'Exames solicitados: ' +
          p.exames_pedidos.join('; ') +
          ' (lançar na comanda)'
      )
  }
  for (const t of n.tasks)
    lines.push(
      `#${t.number} — ${t.description} · dono: autor · ${formatLocalTime(t.dueAt)} — pendência proposta, ainda sem lembrete`
    )
  for (const issue of n.issues)
    lines.push(
      `Bloqueio ${issue.code} ${issue.path}: saída ${issue.outputValue}; fonte ${issue.sourceRange ? n.rawText.slice(issue.sourceRange.start, issue.sourceRange.end) : 'sem trecho inequívoco'}`
    )
  for (const b of n.bindings)
    if (b.provenance === 'confirmed_history_candidate')
      lines.push(
        `🔎 ID ${b.idLiteral} do ${b.name} veio de uma nota anterior (leito ${b.bed}); confira.`
      )
  for (const w of n.warnings) lines.push('Aviso: ' + w)
  lines.push(
    ...(n.organized?.duvidas ?? []),
    `Confirme a revisão exata: ok nota ${n.token}`
  )
  return lines.join('\n')
}

function abortable<T>(work: Promise<T>, signal: AbortSignal): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const abort = () => {
      signal.removeEventListener('abort', abort)
      reject(new Error('cancelled'))
    }
    signal.addEventListener('abort', abort, { once: true })
    if (signal.aborted) {
      abort()
      return
    }
    work.then(
      (v) => {
        signal.removeEventListener('abort', abort)
        resolve(v)
      },
      (e) => {
        signal.removeEventListener('abort', abort)
        reject(e)
      }
    )
  })
}

function splitPreview(text: string): string[] {
  const parts: string[] = []
  let chunk = '',
    bytes = 0
  for (const char of text) {
    const length = Buffer.byteLength(char)
    if (bytes + length > 32768) {
      parts.push(chunk)
      chunk = ''
      bytes = 0
    }
    chunk += char
    bytes += length
  }
  if (chunk) parts.push(chunk)
  if (parts.length > 4) throw new StoreError('INVALID_TRANSITION')
  return parts
}
