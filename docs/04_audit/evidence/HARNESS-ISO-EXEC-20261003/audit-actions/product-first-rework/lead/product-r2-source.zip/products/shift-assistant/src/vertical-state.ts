import {
  type V2Event,
  type Inbox,
  type NoteV2,
  type TaskV2,
  type Outbox
} from './domain.ts'
import { canonical, sha256, StoreError } from './journal.ts'
import type { RevisionEntity } from './store.ts'
import { validateOrganization } from './source-evidence.ts'

export interface VerticalState {
  inbox: Map<string, Inbox>
  notes: Map<string, NoteV2>
  tasks: Map<number, TaskV2>
  outbox: Map<string, Outbox>
  paused: boolean
}
export function emptyVertical(): VerticalState {
  return {
    inbox: new Map(),
    notes: new Map(),
    tasks: new Map(),
    outbox: new Map(),
    paused: false
  }
}
export function isV2(event: object): event is V2Event {
  return 'v' in event && event.v === 2
}
export function v2Affected(e: V2Event): [RevisionEntity, string | number][] {
  const entries: [RevisionEntity, string | number][] = []
  if ('key' in e) entries.push(['inbox', e.key])
  if ('inbox' in e) entries.push(['inbox', e.inbox.key])
  if ('noteId' in e) entries.push(['notes', e.noteId])
  if ('previousNoteId' in e) entries.push(['notes', e.previousNoteId])
  if ('note' in e) {
    entries.push(['notes', e.note.id])
    for (const t of e.note.tasks) entries.push(['tasks', t.number])
  }
  if ('tasks' in e) for (const t of e.tasks) entries.push(['tasks', t.number])
  if ('number' in e) entries.push(['tasks', e.number])
  if ('outbox' in e && e.outbox) entries.push(['outbox', e.outbox.id])
  if ('outboxes' in e)
    for (const b of e.outboxes) entries.push(['outbox', b.id])
  if ('outboxId' in e) entries.push(['outbox', e.outboxId])
  // Note/task mutations can cancel dependent queued sends and suspend/cancel all bound drafts.
  if (
    e.type === 'replacement_started' ||
    e.type === 'replacement_prepared' ||
    e.type === 'task_completed' ||
    e.type === 'task_snoozed_v2'
  )
    entries.push(['operation', 'dependencies'])
  entries.push(['operation', 'state'])
  return [...new Map(entries.map((a) => [a.join(':'), a])).values()]
}
function requireState(ok: unknown): asserts ok {
  if (!ok) throw new StoreError('STATE_CONFLICT')
}
function member(e: V2Event): string {
  requireState(e.actor.kind === 'member')
  return e.actor.memberPhone
}
export function applyVertical(
  s: VerticalState,
  e: V2Event,
  legacyMax: number,
  hold: boolean
): void {
  const actor = member(e)
  const input = 'key' in e ? s.inbox.get(e.key) : undefined
  if (input) requireState(input.memberPhone === actor)
  const out = (b: Outbox) => {
    requireState(
      !s.outbox.has(b.id) &&
        b.state === 'queued' &&
        b.attempt === 0 &&
        b.payloadSha256 === sha256(b.payloadText) &&
        Buffer.byteLength(b.payloadText) <= 32768 &&
        b.recipientMemberId === actor
    )
    s.outbox.set(b.id, structuredClone(b))
  }
  const finish = () => {
    requireState(input && input.state === 'processing')
    input.state = 'processed'
    delete input.nextAttemptAt
    delete input.error
  }
  const cancel = (predicate: (b: Outbox) => boolean) => {
    for (const b of s.outbox.values())
      if (predicate(b) && ['queued', 'retry_wait'].includes(b.state))
        b.state = 'cancelled'
  }
  switch (e.type) {
    case 'inbound_recorded': {
      const i = e.inbox
      requireState(
        !s.inbox.has(i.key) &&
          i.memberPhone === actor &&
          i.state === 'received' &&
          i.attempt === 0 &&
          i.key === JSON.stringify([i.provider, i.session, i.messageId])
      )
      requireState(i.digest === inputDigest(i))
      s.inbox.set(i.key, structuredClone(i))
      break
    }
    case 'processing_started':
      requireState(
        input &&
          ['received', 'retry_wait'].includes(input.state) &&
          e.attempt === input.attempt + 1 &&
          e.attempt <= 5 &&
          (!input.nextAttemptAt ||
            Date.parse(input.nextAttemptAt) <= Date.parse(e.at))
      )
      requireState(!hold && !s.paused)
      input.state = 'processing'
      input.stage = e.stage
      input.attempt = e.attempt
      input.startedAt = e.at
      input.deadline = e.deadline
      input.draftAt ??= e.draftAt
      break
    case 'processing_retry_scheduled':
      requireState(
        input &&
          input.state === 'processing' &&
          e.attempt <= input.attempt &&
          (e.state !== 'retry_wait' || (e.attempt < 5 && e.nextAttemptAt))
      )
      input.state = e.state
      input.attempt = e.attempt
      input.error = e.error
      delete input.nextAttemptAt
      if (e.nextAttemptAt) input.nextAttemptAt = e.nextAttemptAt
      if (e.outbox) {
        requireState(
          e.state === 'review_required' && e.outbox.purpose === 'response'
        )
        out(e.outbox)
      }
      break
    case 'media_attached':
      requireState(input && input.state === 'processing' && !input.mediaPath)
      input.mediaPath = e.path
      break
    case 'transcript_recorded':
      requireState(
        input &&
          input.state === 'processing' &&
          !input.transcript &&
          sha256(e.text) === e.sha256
      )
      input.transcript = e.text
      input.stage = 'organize'
      input.attempt = 0
      break
    case 'replacement_started': {
      const n = s.notes.get(e.noteId)
      requireState(
        input &&
          input.state === 'received' &&
          n &&
          n.authorPhone === actor &&
          n.revision === e.revision &&
          n.state !== 'superseded' &&
          (!n.replacementPending ||
            ([...s.inbox.values()].some(
              (entry) => entry.replacementOf === n.id
            ) &&
              [...s.inbox.values()]
                .filter((entry) => entry.replacementOf === n.id)
                .every((entry) => entry.state === 'review_required')))
      )
      n.replacementPending = true
      input.replacementOf = n.id
      for (const t of s.tasks.values())
        if (t.noteId === n.id && t.status === 'open') t.status = 'suspended'
      cancel((b) => b.noteId === n.id)
      break
    }
    case 'draft_prepared':
    case 'replacement_prepared': {
      const n = e.note
      requireState(
        input &&
          input.state === 'processing' &&
          !s.notes.has(n.id) &&
          n.authorPhone === actor &&
          n.messageKey === input.key &&
          n.state === 'draft' &&
          !n.replacementPending &&
          sha256(n.rawText) === n.rawTextSha256
      )
      requireState(
        n.rawText === (input.transcript ?? input.replacementText ?? input.text)
      )
      requireState(
        n.organizedSha256 === sha256(canonical(n.organized ?? null)) &&
          n.token === revisionToken(n)
      )
      if (n.organized) {
        const validation = validateOrganization(
          n.rawText,
          n.organized,
          [...s.notes.values()],
          n.createdAt
        )
        requireState(
          canonical(validation.evidence) === canonical(n.evidence) &&
            canonical(validation.bindings) === canonical(n.bindings) &&
            canonical(validation.issues) === canonical(n.issues)
        )
      } else
        requireState(
          !n.tasks.length && !n.bindings.length && !n.evidence.length
        )
      if (n.issues.length || n.organized?.duvidas.length)
        requireState(n.tasks.length === 0)
      else if (n.organized)
        requireState(n.tasks.length === n.organized.pendencias.length)
      const maximum = Math.max(legacyMax, 0, ...s.tasks.keys())
      for (const [index, t] of n.tasks.entries()) {
        requireState(
          t.status === 'draft' &&
            t.number === maximum + index + 1 &&
            !s.tasks.has(t.number) &&
            t.noteId === n.id &&
            t.noteRevision === n.revision &&
            t.ownerPhone === actor &&
            t.bindingRevision === n.revision
        )
        requireState(
          t.id === taskId(n.id, n.revision, t.localRef) &&
            t.generation === 1 &&
            t.remindedCount === 0
        )
        const proposal = n.organized?.pendencias.find(
          (p) => p.localRef === t.localRef
        )
        requireState(
          proposal &&
            proposal.descricao === t.description &&
            proposal.pacienteRef === t.patientRef &&
            t.sourceRefs.includes('pendencias.' + t.localRef + '.descricao')
        )
        if (!t.patientRef) requireState(t.patientId === null)
        if (t.patientRef)
          requireState(
            n.bindings.some(
              (b) =>
                b.localRef === t.patientRef &&
                b.provenance !== 'unresolved' &&
                b.idLiteral === t.patientId
            )
          )
        s.tasks.set(t.number, structuredClone(t))
      }
      requireState(
        canonical(n.previewIds) === canonical(e.outboxes.map((b) => b.id))
      )
      for (const b of e.outboxes) {
        requireState(
          b.purpose === 'preview' &&
            b.noteId === n.id &&
            b.noteRevision === n.revision
        )
        out(b)
      }
      if (e.type === 'replacement_prepared') {
        const previous = s.notes.get(e.previousNoteId)
        requireState(
          previous &&
            previous.replacementPending &&
            input.replacementOf === previous.id &&
            previous.authorPhone === actor &&
            n.revision === previous.revision + 1
        )
        previous.state = 'superseded'
        previous.replacementPending = false
        for (const t of s.tasks.values())
          if (
            t.noteId === previous.id &&
            ['draft', 'suspended', 'open'].includes(t.status)
          )
            t.status = 'cancelled'
      } else requireState(!input.replacementOf && n.revision === 1)
      s.notes.set(n.id, structuredClone(n))
      finish()
      break
    }
    case 'confirmation_committed': {
      const n = s.notes.get(e.noteId)
      requireState(
        n &&
          n.authorPhone === actor &&
          n.state === 'draft' &&
          !n.replacementPending &&
          n.revision === e.revision &&
          n.organizedSha256 === e.hash &&
          n.token === e.token &&
          !n.issues.length &&
          !n.organized?.duvidas.length &&
          !hold &&
          !s.paused
      )
      requireState(
        n.previewIds.every(
          (id) => s.outbox.get(id)?.state === 'provider_accepted'
        )
      )
      requireState(
        canonical(e.tasks) ===
          canonical(n.tasks.map((t) => ({ ...t, status: 'open' })))
      )
      requireState(
        canonical(e.bindings) ===
          canonical(
            n.bindings.map((b) => ({
              ...b,
              confirmedBy: actor,
              confirmedAt: e.at
            }))
          )
      )
      for (const t of e.tasks) {
        requireState(s.tasks.get(t.number)?.status === 'draft')
        s.tasks.set(t.number, structuredClone(t))
      }
      n.state = 'confirmed'
      n.bindings = structuredClone(e.bindings)
      n.tasks = structuredClone(e.tasks)
      out(e.outbox)
      finish()
      break
    }
    case 'response_committed':
      out(e.outbox)
      finish()
      break
    case 'operation_paused':
    case 'operation_resumed':
      requireState(
        input && input.state === 'received' && e.outbox.purpose === 'control'
      )
      s.paused = e.type === 'operation_paused'
      out(e.outbox)
      input.state = 'processed'
      break
    case 'task_completed':
    case 'task_snoozed_v2': {
      const t = s.tasks.get(e.number)
      requireState(t && t.ownerPhone === actor && t.status === 'open' && !hold)
      cancel((b) => b.taskNumber === t.number)
      if (e.type === 'task_completed') t.status = 'done'
      else {
        t.dueAt = e.dueAt
        t.generation++
        t.remindedCount = 0
      }
      break
    }
    case 'reminder_reserved': {
      const t = s.tasks.get(e.number)
      const n = t && s.notes.get(t.noteId)
      const b = e.outbox
      requireState(
        t &&
          n &&
          t.status === 'open' &&
          t.ownerPhone === actor &&
          n.state === 'confirmed' &&
          !n.replacementPending &&
          !hold &&
          !s.paused &&
          Date.parse(t.dueAt) <= Date.parse(e.at)
      )
      const previous = [...s.outbox.values()].filter(
        (p) =>
          p.taskNumber === t.number &&
          p.taskGeneration === t.generation &&
          p.purpose === 'reminder'
      )
      requireState(
        !previous.some((p) =>
          ['queued', 'dispatching', 'retry_wait', 'uncertain'].includes(p.state)
        ) && previous.length < 4
      )
      const latest = previous.at(-1)
      requireState(
        !latest ||
          (latest.state === 'provider_accepted' &&
            Date.parse(e.at) - Date.parse(latest.receipt!.at) >= 1800000)
      )
      requireState(
        b.taskNumber === t.number &&
          b.taskGeneration === t.generation &&
          b.slot === previous.length + 1 &&
          b.noteId === n.id &&
          b.noteRevision === n.revision &&
          b.purpose === 'reminder'
      )
      out(b)
      break
    }
    case 'outbox_dispatch_started': {
      const b = s.outbox.get(e.outboxId)
      requireState(
        b &&
          b.recipientMemberId === actor &&
          ['queued', 'retry_wait'].includes(b.state) &&
          e.attempt === b.attempt + 1 &&
          e.attempt <= 5 &&
          (!b.nextAttemptAt ||
            Date.parse(b.nextAttemptAt) <= Date.parse(e.at)) &&
          !hold &&
          (!s.paused || b.purpose === 'control')
      )
      if (b.noteId) {
        const n = s.notes.get(b.noteId)
        requireState(
          n &&
            n.revision === b.noteRevision &&
            n.state !== 'superseded' &&
            !n.replacementPending
        )
        if (b.purpose === 'preview') {
          const index = n.previewIds.indexOf(b.id)
          requireState(
            index >= 0 &&
              n.previewIds
                .slice(0, index)
                .every((id) => s.outbox.get(id)?.state === 'provider_accepted')
          )
        }
      }
      if (b.taskNumber) {
        const t = s.tasks.get(b.taskNumber)
        requireState(
          t && t.status === 'open' && t.generation === b.taskGeneration
        )
      }
      b.state = 'dispatching'
      b.attempt = e.attempt
      break
    }
    case 'outbox_result': {
      const b = s.outbox.get(e.outboxId)
      requireState(b && b.recipientMemberId === actor)
      if (e.state === 'cancelled')
        requireState(['queued', 'retry_wait'].includes(b.state))
      else requireState(b.state === 'dispatching')
      if (e.state === 'provider_accepted') requireState(e.receipt && !e.error)
      if (e.state === 'retry_wait')
        requireState(
          b.attempt < 5 &&
            e.nextAttemptAt &&
            e.error === 'definitely_not_accepted'
        )
      b.state = e.state
      delete b.nextAttemptAt
      if (e.nextAttemptAt) b.nextAttemptAt = e.nextAttemptAt
      if (e.receipt) b.receipt = structuredClone(e.receipt)
      if (e.error) b.error = e.error
      if (e.state === 'provider_accepted' && b.taskNumber) {
        const t = s.tasks.get(b.taskNumber)
        if (t && t.generation === b.taskGeneration) t.remindedCount++
      }
      break
    }
  }
}
export function inputDigest(
  i: Pick<
    Inbox,
    | 'provider'
    | 'session'
    | 'messageId'
    | 'memberPhone'
    | 'kind'
    | 'text'
    | 'mimetype'
  >
): string {
  return sha256(
    canonical({
      provider: i.provider,
      session: i.session,
      messageId: i.messageId,
      memberPhone: i.memberPhone,
      kind: i.kind,
      text: i.text,
      mimetype: i.mimetype ?? null
    })
  )
}
export function taskId(
  noteId: string,
  revision: number,
  localRef: string
): string {
  return sha256(JSON.stringify([noteId, revision, localRef]))
}
export function revisionToken(
  n: Pick<NoteV2, 'id' | 'revision' | 'organizedSha256'>
): string {
  return `${n.id.slice(0, 12)}-r${n.revision}-${n.organizedSha256.slice(0, 12)}`
}
