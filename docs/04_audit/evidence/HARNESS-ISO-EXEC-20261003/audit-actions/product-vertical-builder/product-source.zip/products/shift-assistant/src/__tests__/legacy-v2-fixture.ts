import { RESPONSE } from './vertical-test-fixture.ts'
/** Old scenarios now use a controlled V2 response with source-faithful literal fields. */
export const LEGACY_RAW =
  'Paciente Thor, ID 101, canino, leito 3. Evolução: Vomitou 2 vezes, piora clínica. Exames: hemograma; bioquímico. Pendência: Ligar para o tutor às 16:00.'
export const LEGACY_RESPONSE = {
  ...structuredClone(RESPONSE),
  pacientes: [
    {
      localRef: 'p1',
      nome: 'Thor',
      id: '101',
      especie: 'canino',
      leito: '3',
      evolucao: 'Vomitou 2 vezes, piora clínica',
      exames_pedidos: ['hemograma', 'bioquímico'],
      condutas: []
    }
  ],
  pendencias: [
    {
      localRef: 't1',
      descricao: 'Ligar para o tutor',
      pacienteRef: 'p1',
      pacienteId: '101',
      quando: '2026-09-30T16:00:00-03:00'
    }
  ],
  evidence: [
    {
      path: 'pacientes.p1.nome',
      patientRef: 'p1',
      quote: 'Paciente Thor, ID 101'
    },
    { path: 'pacientes.p1.id', patientRef: 'p1', quote: 'ID 101' },
    { path: 'pacientes.p1.especie', patientRef: 'p1', quote: 'canino' },
    { path: 'pacientes.p1.leito', patientRef: 'p1', quote: 'leito 3' },
    {
      path: 'pacientes.p1.evolucao',
      patientRef: 'p1',
      quote: 'Evolução: Vomitou 2 vezes, piora clínica'
    },
    {
      path: 'pacientes.p1.exames_pedidos.0',
      patientRef: 'p1',
      quote: 'Exames: hemograma; bioquímico'
    },
    {
      path: 'pacientes.p1.exames_pedidos.1',
      patientRef: 'p1',
      quote: 'Exames: hemograma; bioquímico'
    },
    {
      path: 'pendencias.t1.descricao',
      patientRef: 'p1',
      quote: 'Pendência: Ligar para o tutor às 16:00'
    },
    {
      path: 'pendencias.t1.quando',
      patientRef: 'p1',
      quote: 'Pendência: Ligar para o tutor às 16:00'
    }
  ]
}
