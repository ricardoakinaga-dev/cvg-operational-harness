// @vitest-environment node
import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'
import {
  locateQuote,
  compareSourceValue,
  numeralValue
} from '../source-evidence.ts'
interface Blocks {
  patientRef: string
  start: number
  end: number
}
interface Tuple {
  patientBlock: string
  field: string
  valueLiteral: string | null
  unitLiteral: string | null
  quote?: string
}
const numerical = JSON.parse(
  readFileSync(
    new URL(
      './fixtures/reliability/numeral-equivalence-cases.json',
      import.meta.url
    ),
    'utf8'
  )
) as {
  cases: {
    id: string
    rawText: string
    patientBlocks: Blocks[]
    comparisons: {
      source: Tuple
      output: Tuple
      expected: {
        outcome: string
        comparisonValue: string | null
        displayLiteral: string
        issue: string | null
        canonicalPatientMerge: boolean
      }
    }[]
  }[]
}
const quotes = JSON.parse(
  readFileSync(
    new URL(
      './fixtures/reliability/quote-evidence-cases.json',
      import.meta.url
    ),
    'utf8'
  )
) as {
  cases: {
    id: string
    rawText: string
    patientBlocks: Blocks[]
    modelEvidence: unknown
    expected: {
      candidateRanges: unknown
      serviceEvidence: unknown
      issue: string | null
    }
  }[]
}
describe('C2 finite local numeral oracle', () => {
  it('executes all 41 cases and 139 comparisons without canonical identity merge', () => {
    expect(numerical.cases).toHaveLength(41)
    expect(numerical.cases.reduce((n, c) => n + c.comparisons.length, 0)).toBe(
      139
    )
    for (const c of numerical.cases)
      for (const p of c.comparisons) {
        const actual = compareSourceValue(
          c.rawText,
          c.patientBlocks,
          p.source,
          p.output
        )
        expect(actual, c.id + ' ' + JSON.stringify(p.output)).toEqual({
          outcome: p.expected.outcome,
          comparisonValue: p.expected.comparisonValue,
          displayLiteral: p.expected.displayLiteral,
          issue: p.expected.issue,
          canonicalPatientMerge: false
        })
      }
  })
  it('rejects implicit quantities, accent repairs and unsupported grammar', () => {
    for (const s of [
      'mil',
      'trinta e oito virgula cinco',
      'uma e duas',
      '-2',
      '2.5',
      '24:00',
      'quinze e meia'
    ])
      expect(numeralValue(s), s).toBeUndefined()
    expect(numeralValue('um vírgula zero')).toBe('1,0')
  })
})
describe('C3 quote oracle', () => {
  it('executes all 21 proposed localization cases in absolute UTF16, including overlaps', () => {
    expect(quotes.cases).toHaveLength(21)
    for (const c of quotes.cases) {
      const actual = locateQuote(c.rawText, c.patientBlocks, c.modelEvidence)
      expect(actual, c.id).toEqual({
        candidateRanges: c.expected.candidateRanges,
        serviceEvidence: c.expected.serviceEvidence,
        issue: c.expected.issue
      })
      if (actual.serviceEvidence)
        expect(
          c.rawText.slice(
            actual.serviceEvidence.start,
            actual.serviceEvidence.end
          )
        ).toBe(actual.serviceEvidence.quote)
    }
  })
  it('refuses model offsets rather than accepting legacy hints', () => {
    expect(
      locateQuote('abc', [{ patientRef: 'p1', start: 0, end: 3 }], {
        path: 'pacientes.p1.nome',
        patientRef: 'p1',
        quote: 'abc',
        start: 0,
        end: 3
      }).serviceEvidence
    ).toBeNull()
  })
})
