import type { OrganizedV2 } from '../domain.ts'
/** Pure static response fixture. No provider, classifier or model call. */
export const RAW =
  'Paciente Rex, ID 20202, leito 4. Evolução: alerta. Pendência: conferir ficha às 16:00.'
export const RESPONSE: OrganizedV2 = {
  schemaVersion: 2,
  pacientes: [
    {
      localRef: 'p1',
      nome: 'Rex',
      id: '20202',
      leito: '4',
      evolucao: 'alerta',
      exames_pedidos: [],
      condutas: []
    }
  ],
  pendencias: [
    {
      localRef: 't1',
      descricao: 'conferir ficha',
      pacienteRef: 'p1',
      pacienteId: '20202',
      quando: '2026-10-03T16:00:00-03:00'
    }
  ],
  duvidas: [],
  evidence: [
    {
      path: 'pacientes.p1.nome',
      patientRef: 'p1',
      quote: 'Paciente Rex, ID 20202'
    },
    { path: 'pacientes.p1.id', patientRef: 'p1', quote: 'ID 20202' },
    { path: 'pacientes.p1.leito', patientRef: 'p1', quote: 'leito 4' },
    {
      path: 'pacientes.p1.evolucao',
      patientRef: 'p1',
      quote: 'Evolução: alerta'
    },
    {
      path: 'pendencias.t1.descricao',
      patientRef: 'p1',
      quote: 'Pendência: conferir ficha às 16:00'
    },
    {
      path: 'pendencias.t1.quando',
      patientRef: 'p1',
      quote: 'Pendência: conferir ficha às 16:00'
    }
  ]
}
export const staticOrganizer = {
  async organize() {
    return structuredClone(RESPONSE)
  }
}
