import type { ShiftLogger } from './assistant.ts'
import { composeShiftApp } from './compose.ts'
import { loadShiftConfig } from './config.ts'

const logger: ShiftLogger = {
  info: (event, fields) =>
    console.log(JSON.stringify({ level: 'info', event, ...fields })),
  error: (event, fields) =>
    console.error(JSON.stringify({ level: 'error', event, ...fields }))
}

async function start(): Promise<void> {
  const config = loadShiftConfig(process.env)
  const app = composeShiftApp(config, { logger })
  const pending = app.store
    .inboxes()
    .filter((i) => i.state !== 'processed').length
  const port = await app.start()

  const stop = async () => {
    try {
      await app.stop()
      process.exit(0)
    } catch {
      logger.error('shift.stop.failed', { code: 'SHUTDOWN_FAILED' })
      process.exit(1)
    }
  }
  process.once('SIGTERM', () => void stop())
  process.once('SIGINT', () => void stop())

  logger.info('shift.started', {
    provider: config.env.SHIFT_PROVIDER,
    port,
    members: config.members.length,
    resumedMessages: pending,
    paused: app.store.paused
  })
}

start().catch((error: unknown) => {
  logger.error('shift.start.failed', {
    code: error instanceof Error ? error.name : 'unknown'
  })
  process.exit(1)
})
