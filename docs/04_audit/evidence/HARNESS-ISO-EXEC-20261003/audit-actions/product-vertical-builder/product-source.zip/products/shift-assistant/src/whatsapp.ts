import { sha256 } from './journal.ts'
import type { Outbox } from './domain.ts'
import type { InboundMessage, MessageKind } from './domain.ts'
import { normalizePhone } from './domain.ts'
import type { FetchLike } from './egress.ts'

export interface MediaFile {
  bytes: Uint8Array
  mimetype: string
}

export interface WhatsAppClient {
  readonly provider: 'waha' | 'evolution'
  readonly session?: string
  /** Returns undefined for anything that is not a direct inbound message. */
  parseWebhook(payload: unknown, receivedAt: string): InboundMessage | undefined
  sendText(
    phone: string,
    text: string,
    signal?: AbortSignal
  ): Promise<SendResult | void>
  downloadMedia(message: InboundMessage): Promise<MediaFile>
}

type Json = Record<string, unknown>

function obj(value: unknown): Json | undefined {
  return value && typeof value === 'object' && !Array.isArray(value)
    ? (value as Json)
    : undefined
}

function str(value: unknown): string | undefined {
  return typeof value === 'string' && value.length > 0 ? value : undefined
}

function kindFromMime(mimetype: string | undefined): MessageKind | undefined {
  if (!mimetype) return undefined
  if (mimetype.startsWith('audio/')) return 'audio'
  if (mimetype.startsWith('image/')) return 'image'
  return undefined
}

async function ensureOk(response: Response, what: string): Promise<void> {
  if (!response.ok) {
    throw new Error(`${what} failed with HTTP ${response.status}`)
  }
}

export type SendResult =
  | { status: 'provider_accepted'; receipt: NonNullable<Outbox['receipt']> }
  | { status: 'definitely_not_accepted'; code: string }
  | { status: 'uncertain'; code: string }

export interface WahaOptions {
  baseUrl: string
  apiKey: string
  session: string
  sendTimeoutMs?: number
  fetch: FetchLike
}

/** WAHA (WhatsApp HTTP API): `message` webhook event, `/api/sendText`. */
export class WahaClient implements WhatsAppClient {
  readonly provider = 'waha' as const
  readonly #options: WahaOptions

  constructor(options: WahaOptions) {
    this.#options = { ...options, baseUrl: options.baseUrl.replace(/\/+$/, '') }
  }

  parseWebhook(
    payload: unknown,
    receivedAt: string
  ): InboundMessage | undefined {
    const root = obj(payload)
    if (root?.session !== undefined && root.session !== this.#options.session)
      return undefined
    if (root?.event !== 'message') return undefined
    const message = obj(root.payload)
    const id = str(message?.id)
    const from = str(message?.from)
    if (!message || !id || !from || message.fromMe === true) return undefined
    if (!from.endsWith('@c.us')) return undefined // groups, broadcasts, newsletters
    const media = obj(message.media)
    const mimetype = str(media?.mimetype)
    const mediaKind =
      message.hasMedia === true ? kindFromMime(mimetype) : undefined
    const text = str(message.body) ?? ''
    if (!mediaKind && !text.trim()) return undefined
    return {
      provider: 'waha',
      messageId: id,
      fromPhone: normalizePhone(from),
      kind: mediaKind ?? 'text',
      text,
      ...(mediaKind && str(media?.url) ? { mediaRef: str(media?.url)! } : {}),
      ...(mediaKind && mimetype ? { mimetype } : {}),
      receivedAt
    }
  }

  get session(): string {
    return this.#options.session
  }
  sendText(
    phone: string,
    text: string,
    signal?: AbortSignal
  ): Promise<SendResult> {
    return boundedSend(
      this.#options.fetch,
      `${this.#options.baseUrl}/api/sendText`,
      { 'content-type': 'application/json', 'x-api-key': this.#options.apiKey },
      {
        session: this.#options.session,
        chatId: `${normalizePhone(phone)}@c.us`,
        text
      },
      this.#options.sendTimeoutMs ?? 10000,
      signal
    )
  }

  async downloadMedia(message: InboundMessage): Promise<MediaFile> {
    if (!message.mediaRef) throw new Error('Message has no media')
    const response = await this.#options.fetch(message.mediaRef, {
      headers: { 'x-api-key': this.#options.apiKey }
    })
    await ensureOk(response, 'WAHA media download')
    return {
      bytes: new Uint8Array(await response.arrayBuffer()),
      mimetype:
        message.mimetype ??
        response.headers.get('content-type') ??
        'application/octet-stream'
    }
  }
}

export interface EvolutionOptions {
  baseUrl: string
  apiKey: string
  instance: string
  sendTimeoutMs?: number
  fetch: FetchLike
}

/** Evolution API v2: `messages.upsert` webhook event, `/message/sendText`. */
export class EvolutionClient implements WhatsAppClient {
  readonly provider = 'evolution' as const
  readonly #options: EvolutionOptions

  constructor(options: EvolutionOptions) {
    this.#options = { ...options, baseUrl: options.baseUrl.replace(/\/+$/, '') }
  }

  parseWebhook(
    payload: unknown,
    receivedAt: string
  ): InboundMessage | undefined {
    const root = obj(payload)
    if (
      root?.instance !== undefined &&
      root.instance !== this.#options.instance
    )
      return undefined
    const event = str(root?.event)?.toLowerCase().replace('_', '.')
    if (event !== 'messages.upsert') return undefined
    const data = obj(root?.data)
    const key = obj(data?.key)
    const id = str(key?.id)
    const remoteJid = str(key?.remoteJid)
    if (!data || !id || !remoteJid || key?.fromMe === true) return undefined
    if (!remoteJid.endsWith('@s.whatsapp.net')) return undefined
    const content = obj(data.message)
    if (!content) return undefined
    const audio = obj(content.audioMessage)
    const image = obj(content.imageMessage)
    const extended = obj(content.extendedTextMessage)
    const text =
      str(content.conversation) ??
      str(extended?.text) ??
      str(image?.caption) ??
      ''
    const kind: MessageKind = audio ? 'audio' : image ? 'image' : 'text'
    if (kind === 'text' && !text.trim()) return undefined
    const mimetype = str(audio?.mimetype) ?? str(image?.mimetype)
    // With `webhook_base64` enabled the media arrives inline; otherwise it is
    // fetched by message id.
    const inline = str(content.base64)
    return {
      provider: 'evolution',
      messageId: id,
      fromPhone: normalizePhone(remoteJid),
      kind,
      text,
      ...(kind !== 'text'
        ? { mediaRef: inline ? `base64:${inline}` : `id:${id}` }
        : {}),
      ...(kind !== 'text' && mimetype ? { mimetype } : {}),
      receivedAt
    }
  }

  get session(): string {
    return this.#options.instance
  }
  sendText(
    phone: string,
    text: string,
    signal?: AbortSignal
  ): Promise<SendResult> {
    return boundedSend(
      this.#options.fetch,
      `${this.#options.baseUrl}/message/sendText/${encodeURIComponent(this.#options.instance)}`,
      { 'content-type': 'application/json', apikey: this.#options.apiKey },
      { number: normalizePhone(phone), text },
      this.#options.sendTimeoutMs ?? 10000,
      signal
    )
  }

  async downloadMedia(message: InboundMessage): Promise<MediaFile> {
    const ref = message.mediaRef
    if (!ref) throw new Error('Message has no media')
    const fallbackMime = message.mimetype ?? 'application/octet-stream'
    if (ref.startsWith('base64:')) {
      return {
        bytes: Buffer.from(ref.slice(7), 'base64'),
        mimetype: fallbackMime
      }
    }
    const response = await this.#options.fetch(
      `${this.#options.baseUrl}/chat/getBase64FromMediaMessage/${encodeURIComponent(this.#options.instance)}`,
      {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          apikey: this.#options.apiKey
        },
        body: JSON.stringify({
          message: { key: { id: ref.replace(/^id:/, '') } },
          convertToMp4: false
        })
      }
    )
    await ensureOk(response, 'Evolution media download')
    const body = obj(await response.json())
    const base64 = str(body?.base64)
    if (!base64) throw new Error('Evolution media download returned no data')
    return {
      bytes: Buffer.from(base64, 'base64'),
      mimetype: str(body?.mimetype) ?? fallbackMime
    }
  }
}

async function boundedSend(
  fetchImpl: FetchLike,
  url: string,
  headers: Record<string, string>,
  payload: Record<string, unknown>,
  timeout: number,
  external?: AbortSignal
): Promise<SendResult> {
  if (
    Buffer.byteLength(String(payload.text)) > 32768 ||
    external?.aborted ||
    !Number.isFinite(timeout) ||
    timeout <= 0 ||
    timeout > 10000
  )
    return { status: 'definitely_not_accepted', code: 'local_validation' }
  const c = new AbortController()
  const timer = setTimeout(() => c.abort(), timeout)
  const abort = () => c.abort()
  external?.addEventListener('abort', abort, { once: true })
  if (external?.aborted) c.abort()
  let reader: ReadableStreamDefaultReader<Uint8Array> | undefined
  try {
    const response = await fetchImpl(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
      signal: c.signal,
      redirect: 'manual'
    })
    // No qualified provider idempotency or nonacceptance contract: all post-start errors are uncertain.
    if (!response.ok) {
      await response.body?.cancel()
      return { status: 'uncertain', code: 'http_' + response.status }
    }
    reader = response.body?.getReader()
    const chunks: Uint8Array[] = []
    let total = 0
    if (reader)
      while (true) {
        const { value, done } = await reader.read()
        if (done) break
        if (value.length > 65536 - total) throw new Error('response_too_large')
        total += value.length
        chunks.push(value)
      }
    const body = Buffer.concat(chunks)
    const decoded = new TextDecoder('utf-8', { fatal: true }).decode(body)
    const parsed: unknown = decoded ? JSON.parse(decoded) : {}
    const json = obj(parsed)
    if (!json) throw new Error('invalid_receipt')
    const providerId = str(json.id) ?? str(obj(json.key)?.id)
    return {
      status: 'provider_accepted',
      receipt: {
        status: response.status,
        at: new Date().toISOString(),
        sha256: sha256(body),
        ...(providerId && providerId.length <= 256 ? { providerId } : {})
      }
    }
  } catch {
    return { status: 'uncertain', code: 'post_start_failure' }
  } finally {
    clearTimeout(timer)
    external?.removeEventListener('abort', abort)
    try {
      await reader?.cancel()
    } catch {
      /* closed */
    }
    reader?.releaseLock()
  }
}
