import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
// Read immutable shared sources; all generated inputs/artifacts remain under the product.
// No root build config, package, lock, shared dist or source is changed.
const product = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const root = path.resolve(product, '../..')
fs.mkdirSync(path.join(product, 'dist'), { recursive: true })
const work = fs.mkdtempSync(path.join(product, 'dist/public-'))
const copies = []
function run(args) {
  const p = spawnSync(process.execPath, args, { cwd: work, stdio: 'inherit' })
  if (p.status !== 0) throw new Error('public_build_failed:' + p.status)
}
function copySources(from, to) {
  fs.mkdirSync(to, { recursive: true })
  for (const entry of fs.readdirSync(from, { withFileTypes: true })) {
    const source = path.join(from, entry.name),
      target = path.join(to, entry.name)
    if (entry.isDirectory()) {
      if (entry.name !== '__tests__' && entry.name !== 'sandbox')
        copySources(source, target)
    } else if (entry.name.endsWith('.ts') && !entry.name.endsWith('.test.ts')) {
      fs.copyFileSync(source, target)
      copies.push({
        source: path.relative(root, source),
        sha256: createHash('sha256')
          .update(fs.readFileSync(source))
          .digest('hex')
      })
    }
  }
}
function compile(dir) {
  const config = {
    extends: path.join(root, 'tsconfig.base.json'),
    compilerOptions: {
      paths: {},
      rootDir: path.join(dir, 'src'),
      outDir: path.join(dir, 'dist'),
      tsBuildInfoFile: path.join(dir, 'dist/public.tsbuildinfo'),
      typeRoots: [path.join(root, 'node_modules/@types')],
      noEmitOnError: true
    },
    include: [path.join(dir, 'src/**/*.ts')],
    exclude: [],
    references: []
  }
  fs.writeFileSync(
    path.join(dir, 'build.json'),
    JSON.stringify(config, null, 2) + '\n'
  )
  run([
    path.join(root, 'node_modules/typescript/bin/tsc'),
    '-p',
    path.join(dir, 'build.json'),
    '--pretty',
    'false'
  ])
}
fs.mkdirSync(path.join(product, 'dist'), { recursive: true })
for (const name of ['shared', 'model-gateway']) {
  const source = path.join(root, 'packages', name),
    destination = path.join(work, 'node_modules/@cvg', name)
  fs.mkdirSync(destination, { recursive: true })
  fs.copyFileSync(
    path.join(source, 'package.json'),
    path.join(destination, 'package.json')
  )
  copySources(path.join(source, 'src'), path.join(destination, 'src'))
  compile(destination)
}
const app = path.join(work, 'app')
fs.mkdirSync(app)
fs.copyFileSync(
  path.join(product, 'package.json'),
  path.join(app, 'package.json')
)
copySources(path.join(product, 'src'), path.join(app, 'src'))
compile(app)
const esbuild = await import(
  path.join(root, 'node_modules/esbuild/lib/main.js')
)
await esbuild
  .build({
    entryPoints: [path.join(app, 'dist/main.js')],
    bundle: true,
    platform: 'node',
    target: 'node22',
    format: 'esm',
    legalComments: 'none',
    banner: {
      js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);"
    },
    metafile: true,
    outfile: path.join(product, 'dist/shift-assistant.mjs')
  })
  .then((result) =>
    fs.writeFileSync(
      path.join(product, 'dist/public-inputs.json'),
      JSON.stringify(result.metafile, null, 2) + '\n'
    )
  )

fs.writeFileSync(
  path.join(product, 'dist/public-source-copies.json'),
  JSON.stringify(
    {
      publicExports: true,
      sourceAliases: false,
      sharedWrites: false,
      sources: copies
    },
    null,
    2
  ) + '\n'
)
console.log(
  JSON.stringify({
    publicExports: true,
    sourceAliases: false,
    sharedWrites: false,
    closure: ['@cvg/shared', '@cvg/model-gateway', '@cvg/shift-assistant'],
    artifact: 'products/shift-assistant/dist/shift-assistant.mjs'
  })
)
