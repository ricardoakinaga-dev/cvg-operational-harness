import type { OrganizedV2 } from '../domain.ts'
function fixture(
  name: string,
  id: string | null,
  bed: string | null,
  evolution: string | null,
  pending: string | null,
  time: string | null,
  extra: {
    species?: string
    tutor?: string
    reason?: string
    exams?: string[]
  } = {}
): { raw: string; response: OrganizedV2 } {
  const anchor = `Paciente ${name}${id ? ', ID ' + id : ''}${bed ? ', leito ' + bed : ''}${extra.species ? ', ' + extra.species : ''}.`
  const parts = [
    anchor,
    ...(extra.tutor ? ['Tutor: ' + extra.tutor + '.'] : []),
    ...(extra.reason ? ['Motivo: ' + extra.reason + '.'] : []),
    ...(evolution ? ['Evolução: ' + evolution + '.'] : []),
    ...(extra.exams ? ['Exames: ' + extra.exams.join('; ') + '.'] : []),
    ...(pending
      ? ['Pendência: ' + pending + (time ? ' às ' + time : '') + '.']
      : [])
  ]
  const evidence: OrganizedV2['evidence'] = [
    { path: 'pacientes.p1.nome', patientRef: 'p1', quote: anchor }
  ]
  const add = (path: string, quote: string) =>
    evidence.push({ path, patientRef: 'p1', quote })
  if (id) add('pacientes.p1.id', 'ID ' + id)
  if (bed) add('pacientes.p1.leito', 'leito ' + bed)
  if (extra.species) add('pacientes.p1.especie', extra.species)
  if (extra.tutor) add('pacientes.p1.tutor', 'Tutor: ' + extra.tutor)
  if (extra.reason) add('pacientes.p1.motivo', 'Motivo: ' + extra.reason)
  if (evolution) add('pacientes.p1.evolucao', 'Evolução: ' + evolution)
  extra.exams?.forEach((_, i) =>
    add(
      'pacientes.p1.exames_pedidos.' + i,
      'Exames: ' + extra.exams!.join('; ')
    )
  )
  if (pending)
    add(
      'pendencias.t1.descricao',
      'Pendência: ' + pending + (time ? ' às ' + time : '')
    )
  if (time) add('pendencias.t1.quando', 'Pendência: ' + pending + ' às ' + time)
  return {
    raw: parts.join(' '),
    response: {
      schemaVersion: 2,
      pacientes: [
        {
          localRef: 'p1',
          nome: name,
          id,
          leito: bed,
          especie: extra.species ?? null,
          tutor: extra.tutor ?? null,
          motivo: extra.reason ?? null,
          evolucao: evolution,
          exames_pedidos: extra.exams ?? [],
          condutas: []
        }
      ],
      pendencias: pending
        ? [
            {
              localRef: 't1',
              descricao: pending,
              pacienteRef: 'p1',
              pacienteId: id,
              quando: time ? '2026-10-01T' + time + ':00-03:00' : null
            }
          ]
        : [],
      duvidas: [],
      evidence
    }
  }
}
export const THOR_AUDIO = fixture(
  'Thor',
  '30303',
  '3',
  'vomitou duas vezes',
  'Ligar pro tutor',
  '16:00',
  { exams: ['hemograma', 'bioquímico'] }
)
export const BOB_AUDIO = fixture(
  'Bob',
  '20202',
  '2',
  'estável',
  'Trocar o curativo',
  '18:00'
)
export const ADMISSION = fixture(
  'Rex',
  '48213',
  '4',
  'consciente, com dor',
  'Reavaliar a dor',
  '22:00',
  {
    species: 'canino',
    tutor: 'João Silva',
    reason: 'atropelamento',
    exams: ['raio-x', 'hemograma']
  }
)
export const REX_ONE = fixture('Rex', '111', '4', null, null, null, {
  species: 'canino',
  reason: 'atropelamento'
})
export const REX_TWO = fixture('Rex', '222', '7', null, null, null, {
  species: 'canino',
  reason: 'vômito'
})
export const REX_HISTORY = fixture(
  'Rex',
  null,
  '4',
  'comeu bem',
  'medicar',
  '18:00'
)
export const REX_AMBIGUOUS = fixture('Rex', null, null, 'comeu bem', null, null)
export const THOR_UNKNOWN = fixture('Thor', null, '3', 'estável', null, null)
const all = [
  THOR_AUDIO,
  BOB_AUDIO,
  ADMISSION,
  REX_ONE,
  REX_TWO,
  REX_HISTORY,
  REX_AMBIGUOUS,
  THOR_UNKNOWN
]
/** Closed static synthetic lookup. No model call, extraction heuristic or default runtime hook. */
export const fixtureOrganizer = {
  async organize(text: string) {
    return (
      all.find((f) => f.raw === text)?.response ?? {
        schemaVersion: 2,
        pacientes: [],
        pendencias: [],
        duvidas: ['Qual é o nome do paciente?'],
        evidence: []
      }
    )
  }
}
