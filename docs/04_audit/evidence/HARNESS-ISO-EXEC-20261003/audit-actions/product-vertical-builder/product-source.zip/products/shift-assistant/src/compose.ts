import type { Server } from 'node:http'
import { ShiftAssistant, type ShiftLogger } from './assistant.ts'
import type { ShiftConfig } from './config.ts'
import { allowlistedFetch, type FetchLike } from './egress.ts'
import { ModelOrganizer, type Organizer } from './organizer.ts'
import { buildShiftServer } from './server.ts'
import { ShiftStore } from './store.ts'
import { WhisperTranscriber } from './transcriber.ts'
import { EvolutionClient, WahaClient, type WhatsAppClient } from './whatsapp.ts'

export interface ShiftApp {
  assistant: ShiftAssistant
  store: ShiftStore
  whatsapp: WhatsAppClient
  server: Server
  /** Starts listening and the reminder loop; returns the bound port. */
  start(): Promise<number>
  stop(): Promise<void>
}

export interface ComposeOptions {
  organizer?: Organizer
  logger?: ShiftLogger
  clock?: () => Date
  /** Network implementation under the egress allowlist (tests only). */
  fetchImpl?: FetchLike
}

/**
 * Single composition of the shift assistant, shared by the process entry
 * point, the demo and the integration tests.
 */
export function composeShiftApp(
  config: ShiftConfig,
  options: ComposeOptions = {}
): ShiftApp {
  const { env, members } = config
  const store = new ShiftStore(env.SHIFT_DATA_DIR, {
    legacySession:
      env.SHIFT_PROVIDER === 'waha' ? env.WAHA_SESSION : env.EVOLUTION_INSTANCE!
  })
  const guarded = (origins: string[]) =>
    allowlistedFetch(origins, options.fetchImpl)

  const whatsapp: WhatsAppClient =
    env.SHIFT_PROVIDER === 'waha'
      ? new WahaClient({
          baseUrl: env.WAHA_URL!,
          apiKey: env.WAHA_API_KEY!,
          session: env.WAHA_SESSION,
          fetch: guarded([env.WAHA_URL!])
        })
      : new EvolutionClient({
          baseUrl: env.EVOLUTION_URL!,
          apiKey: env.EVOLUTION_API_KEY!,
          instance: env.EVOLUTION_INSTANCE!,
          fetch: guarded([env.EVOLUTION_URL!])
        })

  const transcriber = new WhisperTranscriber({
    baseUrl: env.WHISPER_URL,
    model: env.WHISPER_MODEL,
    language: 'pt',
    fetch: guarded([env.WHISPER_URL])
  })

  const organizer = options.organizer ?? new ModelOrganizer()

  const assistant = new ShiftAssistant({
    store,
    members,
    whatsapp,
    transcriber,
    organizer,
    ...(options.logger ? { logger: options.logger } : {}),
    ...(options.clock ? { clock: options.clock } : {})
  })

  const server = buildShiftServer({
    assistant,
    store,
    whatsapp,
    webhookSecret: env.SHIFT_WEBHOOK_SECRET,
    ...(options.clock ? { clock: options.clock } : {})
  })

  let timer: ReturnType<typeof setTimeout> | undefined
  let stopPromise: Promise<void> | undefined
  const schedule = () => {
    timer = setTimeout(() => {
      void assistant
        .tick()
        .catch(() => {})
        .finally(() => {
          if (!assistant.stopping) schedule()
        })
    }, env.SHIFT_TICK_SECONDS * 1000)
  }

  return {
    assistant,
    store,
    whatsapp,
    server,
    async start() {
      assistant.recoverPending()
      await new Promise<void>((resolve) =>
        server.listen(env.SHIFT_PORT, env.SHIFT_HOST, resolve)
      )
      schedule()
      const address = server.address()
      return typeof address === 'object' && address
        ? address.port
        : env.SHIFT_PORT
    },
    async stop() {
      if (stopPromise) return stopPromise
      stopPromise = (async () => {
        if (timer) clearTimeout(timer)
        const workers = assistant.stop()
        const http = new Promise<void>((resolve) => {
          server.close(() => resolve())
          server.closeIdleConnections()
          server.closeAllConnections()
        })
        await Promise.all([workers, http])
        store.close()
      })()
      return stopPromise
    }
  }
}
