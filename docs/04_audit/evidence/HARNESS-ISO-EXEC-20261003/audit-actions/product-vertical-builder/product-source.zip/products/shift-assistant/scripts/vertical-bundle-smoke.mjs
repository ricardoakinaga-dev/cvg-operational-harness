import assert from 'node:assert/strict'
import fs from 'node:fs'
import { createServer } from 'node:http'
import { spawn } from 'node:child_process'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
const product = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const dir = fs.mkdtempSync(path.join(tmpdir(), 'cvg-vertical-bundle-'))
let sends = 0,
  modelRequests = 0
const receiver = createServer((req, res) => {
  req.resume()
  sends++
  res.writeHead(201, { 'content-type': 'application/json' })
  res.end(JSON.stringify({ id: 'synthetic-' + sends }))
})
const model = createServer((req, res) => {
  req.resume()
  modelRequests++
  res.end('{}')
})
const bind = (server) =>
  new Promise((resolve) =>
    server.listen(0, '127.0.0.1', () =>
      resolve('http://127.0.0.1:' + server.address().port)
    )
  )
const close = (server) =>
  new Promise((resolve) => {
    server.closeAllConnections()
    server.close(() => resolve())
  })
const waUrl = await bind(receiver),
  modelUrl = await bind(model)
const phone = '5511900000001',
  secret = 'synthetic-bundle-webhook-12345'
const child = spawn(
  process.execPath,
  [path.join(product, 'dist/shift-assistant.mjs')],
  {
    env: {
      ...process.env,
      SHIFT_PROVIDER: 'waha',
      SHIFT_MEMBERS: phone + '=Ana;5511900000009=Manager*',
      SHIFT_WEBHOOK_SECRET: secret,
      SHIFT_DATA_DIR: dir,
      SHIFT_PORT: '0',
      SHIFT_HOST: '127.0.0.1',
      WAHA_URL: waUrl,
      WAHA_API_KEY: 'synthetic-only',
      WHISPER_URL: 'http://127.0.0.1:1',
      LLM_BASE_URL: modelUrl,
      LLM_LOCATION: 'local',
      LLM_MODEL: 'synthetic'
    },
    stdio: ['ignore', 'pipe', 'pipe']
  }
)
const exited = new Promise((resolve, reject) => {
  child.once('error', reject)
  child.once('exit', (code, signal) => resolve({ code, signal }))
})
let stdout = '',
  stderr = ''
child.stderr.on('data', (c) => {
  stderr += c
})
const deadline = setTimeout(() => child.kill('SIGKILL'), 10000)
try {
  const port = await new Promise((resolve, reject) => {
    child.stdout.on('data', (chunk) => {
      stdout += chunk
      for (const line of stdout.split('\n')) {
        try {
          const v = JSON.parse(line)
          if (v.event === 'shift.started') resolve(v.port)
        } catch {
          /* incomplete log line */
        }
      }
    })
    child.once('exit', () => reject(new Error('bundle_exited_before_start')))
  })
  assert.notEqual(port, 3400)
  assert.notEqual(port, 3401)
  const raw = 'Paciente Sintético, ID 101. Evolução: alerta.'
  const post = async (id, text) => {
    const res = await fetch(`http://127.0.0.1:${port}/webhooks/waha`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-cvg-webhook-secret': secret
      },
      body: JSON.stringify({
        event: 'message',
        payload: { id, from: phone + '@c.us', body: text }
      })
    })
    assert.equal(res.status, 200)
    return res.json()
  }
  const transactions = () => {
    const manifest = JSON.parse(
      fs.readFileSync(path.join(dir, 'journal/manifest.json'), 'utf8')
    )
    return manifest.segments.flatMap((segment) =>
      fs
        .readFileSync(path.join(dir, segment.path), 'utf8')
        .trim()
        .split('\n')
        .filter(Boolean)
        .map((line) => JSON.parse(line))
    )
  }
  const events = () => transactions().flatMap((t) => t.changes)
  const waitFor = async (predicate) => {
    for (let n = 0; n < 200; n++) {
      if (predicate()) return
      await new Promise((resolve) => setTimeout(resolve, 10))
    }
    throw new Error('smoke_deadline')
  }
  assert.deepEqual(await post('note', raw), { accepted: true })
  await waitFor(() =>
    events().some(
      (e) => e.type === 'outbox_result' && e.state === 'provider_accepted'
    )
  )
  const note = events().find((e) => e.type === 'draft_prepared').note
  assert.equal(note.rawText, raw)
  assert.deepEqual(note.warnings, ['policy_denied'])
  assert.deepEqual(note.tasks, [])
  assert.deepEqual(await post('confirm', 'ok nota ' + note.token), {
    accepted: true
  })
  await waitFor(
    () =>
      sends === 2 &&
      events().filter(
        (e) => e.type === 'outbox_result' && e.state === 'provider_accepted'
      ).length === 2
  )
  const confirmed = events().find((e) => e.type === 'confirmation_committed')
  assert.deepEqual(confirmed.tasks, [])
  assert.equal(confirmed.hash, note.organizedSha256)
  assert.equal(modelRequests, 0)
  const ready = await fetch(`http://127.0.0.1:${port}/health/ready`)
  assert.equal(ready.status, 200)
  child.kill('SIGTERM')
  const result = await exited
  assert.equal(result.code, 0)
  assert.equal(result.signal, null)
  assert.equal(fs.existsSync(path.join(dir, 'store.lock')), false)
  console.log(
    JSON.stringify({
      status: 'PASS',
      artifact: 'dist/shift-assistant.mjs',
      publicBundle: true,
      modelRequests,
      sends,
      sourcePreserved: true,
      rawDocumentConfirmed: true,
      derivedTasks: 0,
      lockReleased: true,
      exit: result,
      transactions: transactions().length,
      synthetic: true
    })
  )
} finally {
  clearTimeout(deadline)
  if (child.exitCode === null && child.signalCode === null)
    child.kill('SIGKILL')
  await exited
  await close(receiver)
  await close(model)
  if (stderr) process.stderr.write(stderr)
}
