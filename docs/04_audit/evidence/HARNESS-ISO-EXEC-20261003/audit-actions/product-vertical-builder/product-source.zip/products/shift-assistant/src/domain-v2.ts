import { z } from 'zod'

const text = z.string().min(1).max(16384)
const id = z.string().min(1).max(512)
export const HashSchema = z.string().regex(/^[a-f0-9]{64}$/)
const rev = z.number().int().positive().max(Number.MAX_SAFE_INTEGER)
const date = z.string().refine((s) => Number.isFinite(Date.parse(s)))
export const ActorSchema = z.discriminatedUnion('kind', [
  z.strictObject({ kind: z.literal('member'), memberPhone: id }),
  z.strictObject({
    kind: z.literal('operator'),
    operatorId: id,
    evidenceRef: id
  })
])
const optional = (n: number) => z.string().min(1).max(n).nullish()
const pRef = z.string().regex(/^p(?:[1-9]|1[0-9]|20)$/)
const tRef = z.string().regex(/^t(?:[1-9]|1[0-9]|20)$/)
export const ModelEvidenceSchema = z.strictObject({
  path: id,
  patientRef: pRef.nullable(),
  quote: z.string().max(16384)
})
export const OrganizedV2Schema = z
  .strictObject({
    schemaVersion: z.literal(2),
    pacientes: z
      .array(
        z.strictObject({
          localRef: pRef,
          nome: z.string().min(1).max(120),
          id: optional(40),
          leito: optional(40),
          especie: optional(60),
          tutor: optional(120),
          motivo: optional(1000),
          evolucao: optional(4000),
          exames_pedidos: z.array(z.string().min(1).max(200)).max(30),
          condutas: z.array(z.string().min(1).max(500)).max(30)
        })
      )
      .max(20),
    pendencias: z
      .array(
        z.strictObject({
          localRef: tRef,
          descricao: z.string().min(1).max(300),
          pacienteRef: pRef.nullable(),
          pacienteId: optional(40),
          quando: optional(40)
        })
      )
      .max(20),
    duvidas: z.array(z.string().min(1).max(300)).max(10),
    evidence: z.array(ModelEvidenceSchema).max(512)
  })
  .superRefine((v, ctx) => {
    for (const entries of [v.pacientes, v.pendencias])
      if (new Set(entries.map((p) => p.localRef)).size !== entries.length)
        ctx.addIssue({ code: 'custom', message: 'Duplicate localRef' })
    if (new Set(v.evidence.map((e) => e.path)).size !== v.evidence.length)
      ctx.addIssue({ code: 'custom', message: 'Duplicate evidence path' })
  })
export const SourceEvidenceSchema = ModelEvidenceSchema.extend({
  start: z.number().int().nonnegative(),
  end: rev
}).strict()
export const ValidationIssueSchema = z.strictObject({
  code: id,
  path: id,
  patientRef: pRef.nullable(),
  sourceRange: z
    .strictObject({ start: z.number().int().nonnegative(), end: rev })
    .nullable(),
  outputValue: z.string().max(16384),
  severity: z.literal('blocking')
})
export const PatientBindingSchema = z.strictObject({
  localRef: pRef,
  name: text,
  idLiteral: optional(40),
  normalizedId: optional(40),
  bed: optional(40),
  provenance: z.enum([
    'source_explicit',
    'confirmed_history_candidate',
    'unresolved'
  ]),
  evidenceRefs: z.array(id),
  confirmedBy: id.optional(),
  confirmedAt: date.optional()
})
export const InboxSchema = z.strictObject({
  key: id,
  digest: HashSchema,
  provider: z.enum(['waha', 'evolution']),
  session: id,
  messageId: z.string().min(1).max(256),
  memberPhone: id,
  kind: z.enum(['text', 'audio', 'image']),
  text: z.string().max(16384),
  receivedAt: date,
  state: z.enum([
    'received',
    'processing',
    'retry_wait',
    'processed',
    'review_required'
  ]),
  stage: z.enum(['media', 'transcript', 'organize', 'command']),
  attempt: z.number().int().min(0).max(5),
  startedAt: date.optional(),
  deadline: date.optional(),
  nextAttemptAt: date.optional(),
  error: id.optional(),
  mediaRef: id.optional(),
  mimetype: id.optional(),
  mediaPath: id.optional(),
  transcript: z.string().max(16384).optional(),
  replacementOf: id.optional(),
  replacementText: z.string().min(1).max(16384).optional(),
  draftAt: date.optional()
})
export const TaskV2Schema = z.strictObject({
  id,
  number: rev,
  noteId: id,
  noteRevision: rev,
  localRef: tRef,
  ownerPhone: id,
  description: text,
  patientRef: pRef.nullable(),
  patientId: z.string().max(40).nullable(),
  bindingRevision: rev,
  sourceRefs: z.array(id).min(1),
  dueAt: date,
  createdAt: date,
  status: z.enum(['draft', 'open', 'suspended', 'done', 'cancelled']),
  generation: rev,
  remindedCount: z.number().int().min(0).max(4)
})
export const NoteV2Schema = z.strictObject({
  id,
  messageKey: id,
  authorPhone: id,
  revision: rev,
  createdAt: date,
  rawText: z.string().max(16384),
  rawTextSha256: HashSchema,
  organizedSha256: HashSchema,
  token: id,
  state: z.enum(['draft', 'confirmed', 'superseded']),
  replacementPending: z.boolean(),
  organized: OrganizedV2Schema.optional(),
  issues: z.array(ValidationIssueSchema),
  warnings: z.array(id),
  bindings: z.array(PatientBindingSchema).max(20),
  evidence: z.array(SourceEvidenceSchema).max(512),
  tasks: z.array(TaskV2Schema).max(20),
  previewIds: z.array(id).min(1).max(4)
})
export const ReceiptSchema = z.strictObject({
  status: z.number().int().min(200).max(299),
  at: date,
  sha256: HashSchema,
  providerId: z.string().min(1).max(256).optional()
})
export const OutboxSchema = z.strictObject({
  id,
  purpose: z.enum(['preview', 'response', 'control', 'reminder']),
  sourceTransitionId: id,
  recipientMemberId: id,
  payloadText: z.string().max(32768),
  payloadSha256: HashSchema,
  noteId: id.optional(),
  noteRevision: rev.optional(),
  taskNumber: rev.optional(),
  taskGeneration: rev.optional(),
  slot: z.number().int().min(1).max(4).optional(),
  state: z.enum([
    'queued',
    'dispatching',
    'provider_accepted',
    'retry_wait',
    'uncertain',
    'review_required',
    'cancelled'
  ]),
  attempt: z.number().int().min(0).max(5),
  nextAttemptAt: date.optional(),
  receipt: ReceiptSchema.optional(),
  error: id.optional()
})
const base = { v: z.literal(2), at: date, actor: ActorSchema }
export const V2EventSchema = z.discriminatedUnion('type', [
  z.strictObject({
    ...base,
    type: z.literal('inbound_recorded'),
    inbox: InboxSchema
  }),
  z.strictObject({
    ...base,
    type: z.literal('processing_started'),
    key: id,
    stage: InboxSchema.shape.stage,
    attempt: rev,
    deadline: date,
    draftAt: date
  }),
  z.strictObject({
    ...base,
    type: z.literal('processing_retry_scheduled'),
    key: id,
    state: z.enum(['received', 'retry_wait', 'review_required']),
    error: id,
    nextAttemptAt: date.optional(),
    attempt: z.number().int().min(0).max(5)
  }),
  z.strictObject({
    ...base,
    type: z.literal('media_attached'),
    key: id,
    path: id
  }),
  z.strictObject({
    ...base,
    type: z.literal('transcript_recorded'),
    key: id,
    text: z.string().max(16384),
    sha256: HashSchema
  }),
  z.strictObject({
    ...base,
    type: z.literal('draft_prepared'),
    key: id,
    note: NoteV2Schema,
    outboxes: z.array(OutboxSchema).min(1).max(4)
  }),
  z.strictObject({
    ...base,
    type: z.literal('replacement_prepared'),
    key: id,
    note: NoteV2Schema,
    outboxes: z.array(OutboxSchema).min(1).max(4),
    previousNoteId: id
  }),
  z.strictObject({
    ...base,
    type: z.literal('replacement_started'),
    key: id,
    noteId: id,
    revision: rev
  }),
  z.strictObject({
    ...base,
    type: z.literal('confirmation_committed'),
    key: id,
    noteId: id,
    revision: rev,
    hash: HashSchema,
    token: id,
    tasks: z.array(TaskV2Schema).max(20),
    bindings: z.array(PatientBindingSchema).max(20),
    outbox: OutboxSchema
  }),
  z.strictObject({
    ...base,
    type: z.literal('response_committed'),
    key: id,
    outbox: OutboxSchema
  }),
  z.strictObject({ ...base, type: z.literal('task_completed'), number: rev }),
  z.strictObject({
    ...base,
    type: z.literal('task_snoozed_v2'),
    number: rev,
    dueAt: date
  }),
  z.strictObject({
    ...base,
    type: z.literal('reminder_reserved'),
    number: rev,
    outbox: OutboxSchema
  }),
  z.strictObject({
    ...base,
    type: z.literal('outbox_dispatch_started'),
    outboxId: id,
    attempt: rev
  }),
  z.strictObject({
    ...base,
    type: z.literal('outbox_result'),
    outboxId: id,
    state: z.enum([
      'provider_accepted',
      'retry_wait',
      'uncertain',
      'review_required',
      'cancelled'
    ]),
    receipt: ReceiptSchema.optional(),
    error: id.optional(),
    nextAttemptAt: date.optional()
  }),
  z.strictObject({
    ...base,
    type: z.literal('operation_paused'),
    key: id,
    outbox: OutboxSchema
  }),
  z.strictObject({
    ...base,
    type: z.literal('operation_resumed'),
    key: id,
    outbox: OutboxSchema
  })
])
export type OrganizedV2 = z.infer<typeof OrganizedV2Schema>
export type V2Event = z.infer<typeof V2EventSchema>
export type Inbox = z.infer<typeof InboxSchema>
export type NoteV2 = z.infer<typeof NoteV2Schema>
export type TaskV2 = z.infer<typeof TaskV2Schema>
export type Outbox = z.infer<typeof OutboxSchema>
export type PatientBinding = z.infer<typeof PatientBindingSchema>
export type SourceEvidence = z.infer<typeof SourceEvidenceSchema>
export type ValidationIssue = z.infer<typeof ValidationIssueSchema>
