import { type CorrelationId } from '@cvg/shared';
import { type AgentId, type AgentVersionId, type TenantId, type TraceId } from './ids.ts';
export type CapabilityApprovalStatus = 'issued' | 'consumed' | 'revoked' | 'expired';
export interface CapabilityInputBinding {
    tenantId: TenantId;
    agentId: AgentId;
    versionId: AgentVersionId;
    toolName: string;
    input: unknown;
}
export interface CapabilityApprovalIssueInput extends CapabilityInputBinding {
    actorId: string;
    issuer: string;
    expiresAt: Date;
    nonce?: string;
}
/**
 * Optional durable evidence requested from an authority while consuming an
 * approval. Implementations that persist approvals can write this evidence
 * in the same transaction as the single-use state transition.
 */
export interface CapabilityApprovalConsumptionAudit {
    correlationId: CorrelationId;
    policyVersion: string;
    traceId?: TraceId;
}
export interface CapabilityApprovalVerificationInput extends CapabilityInputBinding {
    approvalId: string;
    actorId: string;
    consumptionAudit?: CapabilityApprovalConsumptionAudit;
}
export interface CapabilityApprovalRecord {
    id: string;
    tenantId: TenantId;
    agentId: AgentId;
    versionId: AgentVersionId;
    toolName: string;
    inputHash: string;
    actorId: string;
    nonce: string;
    issuer: string;
    expiresAt: Date;
    issuedAt: Date;
    status: CapabilityApprovalStatus;
    consumedAt: Date | null;
    revokedAt: Date | null;
}
export interface CapabilityApprovalAuthority {
    issue(input: CapabilityApprovalIssueInput): Promise<CapabilityApprovalRecord>;
    verifyAndConsume(input: CapabilityApprovalVerificationInput): Promise<CapabilityApprovalRecord | null>;
    /**
     * Tenant is intentionally required by implementations at runtime. The
     * optional type keeps the in-memory/test contract source-compatible, while
     * omission must fail closed rather than fall back to an unscoped lookup.
     */
    revoke(approvalId: string, issuer: string, tenantId?: TenantId): Promise<boolean>;
    get(approvalId: string, tenantId?: TenantId): Promise<CapabilityApprovalRecord | null>;
}
export declare function canonicalizeCapabilityInput(value: unknown): string;
export declare function createCapabilityInputHash(input: CapabilityInputBinding): string;
export declare class InMemoryCapabilityApprovalAuthority implements CapabilityApprovalAuthority {
    private readonly now;
    private readonly records;
    constructor(now?: () => Date);
    issue(input: CapabilityApprovalIssueInput): Promise<CapabilityApprovalRecord>;
    verifyAndConsume(input: CapabilityApprovalVerificationInput): Promise<CapabilityApprovalRecord | null>;
    revoke(approvalId: string, issuer: string, tenantId?: TenantId): Promise<boolean>;
    get(approvalId: string, tenantId?: TenantId): Promise<CapabilityApprovalRecord | null>;
}
