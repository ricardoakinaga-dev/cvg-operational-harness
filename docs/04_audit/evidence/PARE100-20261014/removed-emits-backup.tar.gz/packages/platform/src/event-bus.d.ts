import { type CorrelationId } from '@cvg/shared';
import { type AgentExecutionMode } from './contracts.ts';
import { type AgentId, type AgentVersionId, type TenantId, type TraceId } from './ids.ts';
import type { RegisteredPlugin } from './plugin-gateway.ts';
export declare const PLATFORM_EVENT_NAMES: readonly ["message.received", "message.normalized", "conversation.loaded", "context.loaded", "agent.resolved", "policy.input.before", "policy.input.after", "policy.output.before", "policy.output.after", "intent.before", "intent.after", "knowledge.before", "knowledge.after", "prompt.before", "prompt.after", "model.before", "model.after", "model.error", "tool.before", "tool.after", "tool.error", "response.before", "response.after", "handoff.requested", "handoff.created", "handoff.failed", "human_takeover.started", "human_takeover.ended", "message.delivery.before", "message.delivery.after", "conversation.completed", "security.blocked", "plugin.started", "plugin.stopped", "plugin.error"];
export type PlatformEventName = (typeof PLATFORM_EVENT_NAMES)[number];
export interface PlatformEventEnvelope {
    readonly id: CorrelationId;
    readonly traceId?: TraceId;
    readonly name: PlatformEventName;
    readonly tenantId: TenantId;
    readonly agentId?: AgentId;
    readonly versionId?: AgentVersionId;
    readonly executionMode?: AgentExecutionMode;
    readonly occurredAt: string;
    readonly payload: Readonly<Record<string, unknown>>;
    readonly redactedFields: readonly string[];
}
export interface PluginHookContext {
    readonly tenantId: TenantId;
    readonly plugin: string;
    readonly version: string;
    readonly eventName: PlatformEventName;
}
export type PluginHookHandler = (event: PlatformEventEnvelope, context: PluginHookContext) => void | Promise<void>;
export interface PlatformEventInput {
    name: PlatformEventName;
    tenantId: TenantId;
    traceId?: TraceId;
    agentId?: AgentId;
    versionId?: AgentVersionId;
    executionMode?: AgentExecutionMode;
    payload?: unknown;
}
export interface PlatformEventDelivery {
    plugin: string;
    version: string;
    status: 'succeeded' | 'failed';
    error?: string;
}
export interface PlatformEventResult {
    event: PlatformEventEnvelope;
    deliveries: PlatformEventDelivery[];
}
export interface PlatformHookAuditEvent {
    type: 'plugin_hook';
    correlationId: CorrelationId;
    traceId?: TraceId;
    tenantId: TenantId;
    plugin: string;
    version: string;
    eventName: PlatformEventName;
    status: 'succeeded' | 'failed';
    payload: Readonly<Record<string, unknown>>;
    error?: string;
}
export interface PlatformEventBusOptions {
    onAudit?: (event: PlatformHookAuditEvent) => void | Promise<void>;
}
interface PlatformEventSubscription {
    tenantId: TenantId;
    plugin: string;
    version: string;
    eventName: PlatformEventName;
    handler: PluginHookHandler;
}
export declare class PlatformEventBus {
    private readonly options;
    private readonly subscriptions;
    constructor(options?: PlatformEventBusOptions, subscriptions?: readonly PlatformEventSubscription[]);
    registerPlugin(input: {
        tenantId: TenantId;
        plugin: RegisteredPlugin;
    }): PlatformEventBus;
    listSubscriptions(): Array<{
        tenantId: TenantId;
        plugin: string;
        version: string;
        eventName: PlatformEventName;
    }>;
    emit(input: PlatformEventInput): Promise<PlatformEventResult>;
    private audit;
}
export {};
