import type { ControlPlaneStore } from './control-plane-store.ts';
import { type TestLabCase, type TestLabEvaluation, type TestLabSuiteResult } from './contracts.ts';
import type { AgentId, AgentVersionId, TenantId } from './ids.ts';
import { type ApprovedKnowledgeResolver } from './test-lab.ts';
export declare function evaluateTestLabCase(input: {
    store: ControlPlaneStore;
    tenantId: TenantId;
    agentId: AgentId;
    versionId: AgentVersionId;
    testCase: TestLabCase;
    resolveApprovedKnowledge?: ApprovedKnowledgeResolver;
}): Promise<TestLabEvaluation>;
export declare function evaluateTestLabSuite(input: {
    store: ControlPlaneStore;
    tenantId: TenantId;
    agentId: AgentId;
    versionId: AgentVersionId;
    cases: TestLabCase[];
    resolveApprovedKnowledge?: ApprovedKnowledgeResolver;
}): Promise<TestLabSuiteResult>;
