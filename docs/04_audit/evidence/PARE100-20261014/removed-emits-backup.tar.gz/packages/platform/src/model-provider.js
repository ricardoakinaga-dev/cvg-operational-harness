import { DomainError } from '@cvg/shared';
export const CONTROLLED_MODEL_PROVIDER = 'fake';
export const CONTROLLED_MODEL = 'deterministic-v1';
export class DeterministicModelProvider {
    name = CONTROLLED_MODEL_PROVIDER;
    supportedModels = Object.freeze([CONTROLLED_MODEL]);
    constructor(config) {
        if (config !== undefined) {
            assertControlledModelConfig(config);
        }
        Object.freeze(this);
    }
    async complete(input) {
        void input.prompt;
        return {
            text: input.fallbackText,
            provider: this.name,
            model: CONTROLLED_MODEL,
            externalCall: false
        };
    }
}
export class ModelProviderRegistry {
    providers;
    constructor(providers = []) {
        const registeredProviders = providers.map(freezeRegisteredProvider);
        const names = registeredProviders.map((provider) => provider.name);
        if (new Set(names).size !== names.length) {
            throw new Error('Model provider already registered');
        }
        this.providers = [...registeredProviders];
        Object.freeze(this.providers);
        Object.freeze(this);
    }
    register(provider) {
        if (this.resolve(provider.name)) {
            throw new Error(`Model provider already registered: ${provider.name}`);
        }
        return new ModelProviderRegistry([...this.providers, provider]);
    }
    resolve(name) {
        return this.providers.find((provider) => provider.name === name) ?? null;
    }
    resolveForConfig(config) {
        if (config.fallbackProvider !== undefined) {
            throw new DomainError('invalid_action', 'Fallback model provider is unavailable in controlled runtime');
        }
        const provider = this.resolve(config.provider);
        if (!provider || !provider.supportedModels.includes(config.model)) {
            throw new DomainError('invalid_action', 'Configured model provider is unavailable in controlled runtime');
        }
        return provider;
    }
    list() {
        return [...this.providers];
    }
}
export function createControlledModelProviderRegistry() {
    return new ModelProviderRegistry([new DeterministicModelProvider()]);
}
export function resolveControlledModelProvider(config) {
    return createControlledModelProviderRegistry().resolveForConfig(config);
}
export function createDryRunModelProvider(config) {
    return resolveControlledModelProvider(config);
}
function assertControlledModelConfig(config) {
    if (config.provider !== CONTROLLED_MODEL_PROVIDER ||
        config.model !== CONTROLLED_MODEL ||
        config.fallbackProvider !== undefined) {
        throw new DomainError('invalid_action', 'Configured model provider is unavailable in controlled runtime');
    }
}
function freezeRegisteredProvider(provider) {
    if (Object.isFrozen(provider) && Object.isFrozen(provider.supportedModels)) {
        return provider;
    }
    return Object.freeze({
        name: provider.name,
        supportedModels: Object.freeze([...provider.supportedModels]),
        complete: provider.complete.bind(provider)
    });
}
//# sourceMappingURL=model-provider.js.map