import { z } from 'zod';
import { AgentIdSchema, AgentVersionIdSchema, TenantIdSchema, TraceIdSchema } from "./ids.js";
export const TenantScopeSchema = z.object({ tenantId: TenantIdSchema }).strict();
export const AgentVersionStatusSchema = z.enum([
    'DRAFT',
    'TESTING',
    'APPROVED',
    'PUBLISHED',
    'ARCHIVED'
]);
const PromptBlockKindSchema = z.enum([
    'system',
    'persona',
    'instruction',
    'safety',
    'context',
    'response'
]);
export const PromptBlockSchema = z
    .object({
    id: z
        .string()
        .trim()
        .min(1)
        .max(80)
        .regex(/^[A-Za-z0-9._:-]+$/),
    kind: PromptBlockKindSchema,
    content: z.string().trim().min(1).max(8000),
    priority: z.number().int().min(-10000).max(10000),
    enabled: z.boolean().default(true),
    locked: z.boolean().optional()
})
    .strict();
const SecretRefSchema = z
    .string()
    .trim()
    .min(1)
    .max(200)
    .regex(/^secret:\/\/[A-Za-z0-9._:/-]+$/);
export const ModelConfigSchema = z
    .object({
    provider: z
        .string()
        .trim()
        .min(1)
        .max(80)
        .regex(/^[A-Za-z0-9._:-]+$/),
    model: z.string().trim().min(1).max(160),
    temperature: z.number().min(0).max(2),
    maxTokens: z.number().int().min(1).max(200000),
    timeoutMs: z.number().int().min(100).max(120000),
    retries: z.number().int().min(0).max(5),
    fallbackProvider: z
        .string()
        .trim()
        .min(1)
        .max(80)
        .regex(/^[A-Za-z0-9._:-]+$/)
        .optional(),
    secretRef: SecretRefSchema.optional()
})
    .strict();
export const PolicyBundleSchema = z
    .object({
    version: z.string().trim().min(1).max(120),
    minConfidence: z.number().min(0).max(1),
    clarifyThreshold: z.number().min(0).max(1).optional(),
    handoffThreshold: z.number().min(0).max(1).optional(),
    lowConfidence: z.enum(['clarify', 'handoff']),
    maxClarifications: z.number().int().min(0).max(5),
    enabledActions: z.array(z.string().trim().min(1).max(120)).max(256),
    approvalActions: z.array(z.string().trim().min(1).max(120)).max(256),
    blockedActions: z.array(z.string().trim().min(1).max(120)).max(256)
})
    .strict()
    .superRefine((value, context) => {
    const clarifyThreshold = value.clarifyThreshold ?? value.minConfidence;
    if (value.clarifyThreshold !== undefined &&
        value.clarifyThreshold !== value.minConfidence) {
        context.addIssue({
            code: 'custom',
            path: ['clarifyThreshold'],
            message: 'clarifyThreshold must match minConfidence'
        });
    }
    if (value.handoffThreshold !== undefined &&
        value.handoffThreshold > clarifyThreshold) {
        context.addIssue({
            code: 'custom',
            path: ['handoffThreshold'],
            message: 'handoffThreshold cannot exceed clarifyThreshold'
        });
    }
});
export const PluginBindingSchema = z
    .object({
    plugin: z
        .string()
        .trim()
        .min(1)
        .max(120)
        .regex(/^[A-Za-z0-9._:-]+$/),
    version: z
        .string()
        .trim()
        .min(1)
        .max(80)
        .refine((value) => value.toLowerCase() !== 'latest', {
        message: 'Plugin version must be exact; latest is not allowed'
    })
        .optional(),
    enabled: z.boolean(),
    allowedTools: z
        .array(z
        .string()
        .trim()
        .min(1)
        .max(120)
        .regex(/^[A-Za-z0-9._:-]+$/))
        .max(128),
    config: z
        .record(z.string(), z.unknown())
        .refine((value) => Object.keys(value).length <= 64, {
        message: 'Plugin configuration has too many keys'
    })
})
    .strict();
export const KnowledgeBindingSchema = z
    .object({
    source: z
        .string()
        .trim()
        .min(1)
        .max(200)
        .regex(/^controlled:\/\//),
    version: z.string().trim().min(1).max(120),
    enabled: z.boolean(),
    requiresApprovedSource: z.boolean()
})
    .strict();
export const ApprovedKnowledgeForTestSchema = z
    .object({
    version: z.string().trim().min(1).max(120),
    answer: z.string().trim().min(1).max(4000),
    source: z
        .string()
        .trim()
        .min(1)
        .max(200)
        .regex(/^controlled:\/\//)
})
    .strict();
export const HandoffPrioritySchema = z.enum(['low', 'medium', 'high']);
const HandoffDestinationSchema = z
    .string()
    .trim()
    .min(1)
    .max(120)
    .regex(/^[A-Za-z0-9._:-]+$/);
export const HandoffConfigSchema = z
    .object({
    lowConfidenceDestination: HandoffDestinationSchema,
    destinations: z.array(HandoffDestinationSchema).min(1).max(32),
    maxClarifications: z.number().int().min(0).max(5),
    priority: HandoffPrioritySchema.optional()
})
    .strict()
    .superRefine((value, context) => {
    if (new Set(value.destinations).size !== value.destinations.length) {
        context.addIssue({
            code: 'custom',
            path: ['destinations'],
            message: 'Handoff destinations must be unique'
        });
    }
    if (!value.destinations.includes(value.lowConfidenceDestination)) {
        context.addIssue({
            code: 'custom',
            path: ['lowConfidenceDestination'],
            message: 'Low-confidence destination must be listed in destinations'
        });
    }
});
export const FeatureFlagsSchema = z
    .record(z
    .string()
    .trim()
    .min(1)
    .max(120)
    .regex(/^[A-Za-z0-9._:-]+$/), z.boolean())
    .refine((flags) => Object.keys(flags).length <= 64);
const sensitiveKeyPattern = /(api.?key|access.?token|client.?secret|credential|password|private.?key)/i;
const secretValuePattern = /^(sk-|pk_|Bearer\s|ghp_|xox[baprs]-)/i;
const MAX_CONFIG_INSPECTION_DEPTH = 16;
const MAX_CONFIG_INSPECTION_NODES = 4096;
function assertNoSecretValues(value, path, seen = new WeakSet(), state = { nodes: 0 }, depth = 0) {
    if (depth > MAX_CONFIG_INSPECTION_DEPTH) {
        throw new Error('Configuration nesting exceeds the controlled limit');
    }
    state.nodes += 1;
    if (state.nodes > MAX_CONFIG_INSPECTION_NODES) {
        throw new Error('Configuration size exceeds the controlled limit');
    }
    if (typeof value === 'string') {
        if (secretValuePattern.test(value)) {
            throw new Error(`Sensitive credential value at ${path}`);
        }
        return;
    }
    if (Array.isArray(value)) {
        value.forEach((item, index) => assertNoSecretValues(item, `${path}[${index}]`));
        return;
    }
    if (typeof value !== 'object' || value === null)
        return;
    if (seen.has(value)) {
        throw new Error(`Cyclic configuration value at ${path}`);
    }
    seen.add(value);
    try {
        Object.entries(value).forEach(([key, child]) => {
            if (key !== 'secretRef' && sensitiveKeyPattern.test(key)) {
                throw new Error(`Sensitive credential field at ${path}.${key}`);
            }
            assertNoSecretValues(child, `${path}.${key}`, seen, state, depth + 1);
        });
    }
    finally {
        seen.delete(value);
    }
}
export const AgentConfigSchema = z
    .object({
    persona: z
        .object({
        name: z.string().trim().min(1).max(120),
        role: z.string().trim().min(1).max(160),
        tone: z.string().trim().min(1).max(120)
    })
        .strict(),
    greeting: z.string().trim().min(1).max(2000),
    promptBlocks: z.array(PromptBlockSchema).max(64),
    responseTemplates: z
        .record(z.string(), z.string().trim().min(1).max(4000))
        .refine((templates) => Object.keys(templates).length <= 128),
    model: ModelConfigSchema,
    featureFlags: FeatureFlagsSchema.default({}),
    policies: PolicyBundleSchema,
    plugins: z.array(PluginBindingSchema).max(128),
    knowledge: z.array(KnowledgeBindingSchema).max(64),
    handoff: HandoffConfigSchema
})
    .strict()
    .superRefine((value, context) => {
    try {
        assertNoSecretValues(value, 'config');
    }
    catch (error) {
        context.addIssue({
            code: 'custom',
            message: error instanceof Error ? error.message : 'Sensitive value'
        });
    }
});
export const AgentCreateInputSchema = z
    .object({
    slug: z
        .string()
        .trim()
        .min(1)
        .max(80)
        .regex(/^[a-z][a-z0-9-]+$/),
    name: z.string().trim().min(1).max(120),
    description: z.string().trim().max(1000)
})
    .strict();
export const PlatformDecisionSchema = z.enum([
    'allowed',
    'blocked',
    'requires_approval',
    'handoff',
    'clarify'
]);
export const AgentExecutionModeSchema = z.enum([
    'TEST_LAB',
    'CONTROLLED_RUNTIME'
]);
export const PluginToolSchema = z
    .object({
    name: z
        .string()
        .trim()
        .min(1)
        .max(120)
        .regex(/^[A-Za-z0-9._:-]+$/),
    permission: z.string().trim().min(1).max(160),
    risk: z.enum(['low', 'medium', 'high', 'critical']),
    requiresApproval: z.boolean(),
    intents: z.array(z.string().trim().min(1).max(80)).max(16).optional()
})
    .strict();
export const PluginManifestSchema = z
    .object({
    name: z
        .string()
        .trim()
        .min(1)
        .max(120)
        .regex(/^[A-Za-z0-9._:-]+$/),
    version: z
        .string()
        .trim()
        .min(1)
        .max(80)
        .refine((value) => value.toLowerCase() !== 'latest', {
        message: 'Plugin version must be exact; latest is not allowed'
    }),
    capabilities: z.array(z.string().trim().min(1).max(160)).max(128),
    permissions: z.array(z.string().trim().min(1).max(160)).max(128),
    tools: z.array(PluginToolSchema).max(128),
    hooks: z.array(z.string().trim().min(1).max(160)).max(128),
    dependencies: z.array(z.string().trim().min(1).max(160)).max(128),
    configSchemaVersion: z.string().trim().min(1).max(80)
})
    .strict()
    .superRefine((manifest, context) => {
    const assertUnique = (values, path) => {
        const seen = new Set();
        values.forEach((value, index) => {
            if (seen.has(value)) {
                context.addIssue({
                    code: 'custom',
                    path: [path, index],
                    message: `${path} entries must be unique`
                });
            }
            seen.add(value);
        });
    };
    assertUnique(manifest.capabilities, 'capabilities');
    assertUnique(manifest.permissions, 'permissions');
    assertUnique(manifest.tools.map((tool) => tool.name), 'tools');
    assertUnique(manifest.hooks, 'hooks');
    assertUnique(manifest.dependencies, 'dependencies');
    manifest.tools.forEach((tool, index) => {
        if (!manifest.permissions.includes(tool.permission)) {
            context.addIssue({
                code: 'custom',
                path: ['tools', index, 'permission'],
                message: 'Tool permission must be declared by the manifest'
            });
        }
    });
    if (manifest.dependencies.includes(manifest.name)) {
        context.addIssue({
            code: 'custom',
            path: ['dependencies'],
            message: 'Plugin cannot depend on itself'
        });
    }
});
export const PluginCatalogStatusSchema = z.enum([
    'DRAFT',
    'APPROVED',
    'ARCHIVED'
]);
export const PluginCatalogCreateInputSchema = z
    .object({ manifest: PluginManifestSchema })
    .strict();
export const PluginCatalogTransitionInputSchema = z
    .object({
    target: PluginCatalogStatusSchema,
    expectedStatus: PluginCatalogStatusSchema.optional()
})
    .strict();
export const KnowledgeSourceStatusSchema = z.enum([
    'DRAFT',
    'APPROVED',
    'ARCHIVED'
]);
const KnowledgeSourceSecretPattern = /(secret|token|password|api[_-]?key)/i;
export const KnowledgeSourceCreateInputSchema = z
    .object({
    source: z
        .string()
        .trim()
        .min(1)
        .max(200)
        .regex(/^controlled:\/\/[A-Za-z0-9._:/-]+$/)
        .refine((value) => !KnowledgeSourceSecretPattern.test(value), {
        message: 'Knowledge source URI cannot contain secret material'
    }),
    version: z
        .string()
        .trim()
        .min(1)
        .max(120)
        .regex(/^[A-Za-z0-9._:-]+$/)
        .refine((value) => !KnowledgeSourceSecretPattern.test(value), {
        message: 'Knowledge source metadata cannot contain secret material'
    }),
    label: z
        .string()
        .trim()
        .min(1)
        .max(120)
        .refine((value) => !KnowledgeSourceSecretPattern.test(value), {
        message: 'Knowledge source metadata cannot contain secret material'
    }),
    description: z
        .string()
        .trim()
        .max(1000)
        .refine((value) => !KnowledgeSourceSecretPattern.test(value), {
        message: 'Knowledge source metadata cannot contain secret material'
    })
})
    .strict();
export const KnowledgeSourceTransitionInputSchema = z
    .object({
    target: KnowledgeSourceStatusSchema,
    expectedStatus: KnowledgeSourceStatusSchema.optional()
})
    .strict();
export const ReleaseCandidateStatusSchema = z.enum([
    'DRAFT',
    'VALIDATED',
    'REJECTED',
    'ARCHIVED'
]);
export const ReleaseCandidateGateKeySchema = z.enum([
    'safety_preflight',
    'test_lab_regression',
    'snapshot_integrity',
    'external_boundary'
]);
export const ReleaseCandidateGateStatusSchema = z.enum(['PASS', 'FAIL']);
const ReleaseCandidateEvidenceRefSchema = z
    .string()
    .trim()
    .min(1)
    .max(200)
    .regex(/^controlled:\/\/evidence\/[A-Za-z0-9._:-]+$/)
    .refine((value) => !KnowledgeSourceSecretPattern.test(value), {
    message: 'Release evidence reference cannot contain secret material'
});
export const ReleaseCandidateGateResultSchema = z
    .object({
    key: ReleaseCandidateGateKeySchema,
    status: ReleaseCandidateGateStatusSchema,
    evidenceRef: ReleaseCandidateEvidenceRefSchema
})
    .strict();
const RELEASE_CANDIDATE_GATE_KEYS = [
    'safety_preflight',
    'test_lab_regression',
    'snapshot_integrity',
    'external_boundary'
];
export const ReleaseCandidateCreateInputSchema = z
    .object({
    agentId: AgentIdSchema,
    versionId: AgentVersionIdSchema,
    gateResults: z
        .array(ReleaseCandidateGateResultSchema)
        .length(RELEASE_CANDIDATE_GATE_KEYS.length)
})
    .strict()
    .superRefine((value, context) => {
    const keys = value.gateResults.map((gate) => gate.key);
    const uniqueKeys = new Set(keys);
    if (uniqueKeys.size !== RELEASE_CANDIDATE_GATE_KEYS.length) {
        context.addIssue({
            code: 'custom',
            path: ['gateResults'],
            message: 'Release candidate must contain each fixed gate exactly once'
        });
        return;
    }
    RELEASE_CANDIDATE_GATE_KEYS.forEach((key) => {
        if (!uniqueKeys.has(key)) {
            context.addIssue({
                code: 'custom',
                path: ['gateResults'],
                message: `Missing release candidate gate: ${key}`
            });
        }
    });
});
export const ReleaseCandidateTransitionInputSchema = z
    .object({
    target: ReleaseCandidateStatusSchema,
    expectedStatus: ReleaseCandidateStatusSchema.optional()
})
    .strict();
export const TestLabCaseSchema = z
    .object({
    id: z
        .string()
        .trim()
        .min(1)
        .max(120)
        .regex(/^[A-Za-z0-9._:-]+$/),
    message: z.string().trim().min(1).max(4000),
    history: z.array(z.string().max(4000)).max(50).default([]),
    expectedPolicyDecision: PlatformDecisionSchema.optional(),
    expectedResponseMode: z.enum(['answer', 'clarify', 'handoff', 'blocked']),
    expectedHandoff: z.boolean().optional(),
    approvedKnowledge: ApprovedKnowledgeForTestSchema.optional()
})
    .strict();
export const TestSuiteCreateInputSchema = z
    .object({
    slug: z
        .string()
        .trim()
        .min(1)
        .max(80)
        .regex(/^[a-z][a-z0-9-]+$/),
    name: z.string().trim().min(1).max(120),
    description: z.string().trim().max(1000),
    agentId: AgentIdSchema,
    versionId: AgentVersionIdSchema,
    cases: z.array(TestLabCaseSchema).min(1).max(100)
})
    .strict();
export const TestSuiteCloneInputSchema = z
    .object({
    name: z.string().trim().min(1).max(120).optional(),
    description: z.string().trim().max(1000).optional(),
    versionId: AgentVersionIdSchema.optional(),
    cases: z.array(TestLabCaseSchema).min(1).max(100).optional()
})
    .strict();
export function assertPlatformIds(input) {
    TenantIdSchema.parse(input.tenantId);
    AgentIdSchema.parse(input.agentId);
    AgentVersionIdSchema.parse(input.versionId);
}
export function assertTraceId(traceId) {
    TraceIdSchema.parse(traceId);
}
//# sourceMappingURL=contracts.js.map