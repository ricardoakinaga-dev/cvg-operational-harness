import type { ControlPlaneStore } from './control-plane-store.ts';
import type { AgentVersionRecord, AgentExecutionMode, TestRunTrace, TraceSpanName, ApprovedKnowledgeForTest } from './contracts.ts';
import { type AgentId, type TenantId, type TraceId } from './ids.ts';
import type { CapabilityApproval, CapabilityApprovalResolver, CapabilityGateway, PluginAuditEvent } from './plugin-gateway.ts';
import type { PlatformEventBus } from './event-bus.ts';
export interface TestLabInput {
    store: ControlPlaneStore;
    tenantId: TenantId;
    agentId: AgentId;
    versionId: AgentVersionRecord['id'];
    traceId?: TraceId;
    message: string;
    history: string[];
    approvedKnowledge?: ApprovedKnowledgeForTest;
    resolveApprovedKnowledge?: ApprovedKnowledgeResolver;
    capabilityGateway?: CapabilityGateway;
    actor?: AgentExecutionActor;
    capabilityApproval?: CapabilityApproval;
    resolveCapabilityApproval?: CapabilityApprovalResolver;
    requireCapabilityApproval?: boolean;
    onToolAudit?: (event: PluginAuditEvent) => void | Promise<void>;
    eventBus?: PlatformEventBus;
    context?: {
        conversationId?: string;
        sessionId?: string;
    };
    monotonicClock?: () => number;
}
export interface ApprovedKnowledgeResolverInput {
    tenantId: TenantId;
    question: string;
}
export type ApprovedKnowledgeResolver = (input: ApprovedKnowledgeResolverInput) => ApprovedKnowledgeForTest | null | undefined | Promise<ApprovedKnowledgeForTest | null | undefined>;
export interface ControlledTraceTiming {
    measure<T>(name: TraceSpanName, operation: () => T): T;
    measureAsync<T>(name: TraceSpanName, operation: () => T | PromiseLike<T>): Promise<T>;
    snapshot(): Partial<Record<TraceSpanName, number>>;
}
export declare function createControlledTraceTiming(clock?: () => number): ControlledTraceTiming;
export interface AgentExecutionActor {
    id: string;
    role: string;
    permissions: string[];
}
export interface ControlledAgentExecutionInput extends TestLabInput {
    executionMode: AgentExecutionMode;
}
export declare function runTestLab(input: TestLabInput): Promise<TestRunTrace>;
export declare function executeConfiguredAgent(input: ControlledAgentExecutionInput): Promise<TestRunTrace>;
