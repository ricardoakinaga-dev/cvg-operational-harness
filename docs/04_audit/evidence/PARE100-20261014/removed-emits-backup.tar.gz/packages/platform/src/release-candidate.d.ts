import { type ReleaseCandidateRecord } from './contracts.ts';
import type { ReleaseCandidateGateResult } from './contracts.ts';
import type { TenantId, AgentId, AgentVersionId } from './ids.ts';
export declare function computeReleaseCandidateEvidenceDigest(input: {
    tenantId: TenantId;
    agentId: AgentId;
    versionId: AgentVersionId;
    gateResults: readonly ReleaseCandidateGateResult[];
}): string;
export declare function hasAllReleaseCandidateGatesPassed(gateResults: readonly ReleaseCandidateGateResult[]): boolean;
export declare function parseReleaseCandidateGateResults(rawGateResults: unknown): ReleaseCandidateGateResult[];
export declare function assertReleaseCandidateEvidenceIntegrity(candidate: ReleaseCandidateRecord): void;
export declare function assertReleaseCandidateIndependentValidator(candidate: ReleaseCandidateRecord, validatorId: string): void;
export declare function assertReleaseCandidatePublishAuthority(input: {
    candidate: ReleaseCandidateRecord | null;
    tenantId: TenantId;
    agentId: AgentId;
    versionId: AgentVersionId;
}): ReleaseCandidateRecord;
