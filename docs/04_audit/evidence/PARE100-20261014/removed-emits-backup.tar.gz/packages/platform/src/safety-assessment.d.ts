/** Conservative lexical screening, not clinical inference. Legacy history has no
 * trustworthy roles or resolution markers; it may raise risk, never clear it. */
export interface SafetyAssessment {
    level: 'low' | 'high' | 'critical';
    reason: string;
}
export declare function normalizeSafetyText(value: string): string;
export declare function assessConversationSafety(message: string, history: readonly string[]): SafetyAssessment;
