import { randomUUID } from 'node:crypto';
import { z } from 'zod';
const uuid = '[0-9a-f-]{36}';
export const TenantIdSchema = z.string().regex(new RegExp(`^tenant_${uuid}$`));
export const AgentIdSchema = z.string().regex(new RegExp(`^agent_${uuid}$`));
export const AgentVersionIdSchema = z
    .string()
    .regex(new RegExp(`^agent_version_${uuid}$`));
export const TraceIdSchema = z.string().regex(new RegExp(`^trace_${uuid}$`));
export const TestSuiteIdSchema = z
    .string()
    .regex(new RegExp(`^test_suite_${uuid}$`));
export const TestSuiteRunIdSchema = z
    .string()
    .regex(new RegExp(`^test_suite_run_${uuid}$`));
export const PluginCatalogIdSchema = z
    .string()
    .regex(new RegExp(`^plugin_catalog_${uuid}$`));
export const KnowledgeSourceIdSchema = z
    .string()
    .regex(new RegExp(`^knowledge_source_${uuid}$`));
export const ReleaseCandidateIdSchema = z
    .string()
    .regex(new RegExp(`^release_candidate_${uuid}$`));
export function createTenantId() {
    return `tenant_${randomUUID()}`;
}
export function createAgentId() {
    return `agent_${randomUUID()}`;
}
export function createAgentVersionId() {
    return `agent_version_${randomUUID()}`;
}
export function createTraceId() {
    return `trace_${randomUUID()}`;
}
export function createTestSuiteId() {
    return `test_suite_${randomUUID()}`;
}
export function createTestSuiteRunId() {
    return `test_suite_run_${randomUUID()}`;
}
export function createPluginCatalogId() {
    return `plugin_catalog_${randomUUID()}`;
}
export function createKnowledgeSourceId() {
    return `knowledge_source_${randomUUID()}`;
}
export function createReleaseCandidateId() {
    return `release_candidate_${randomUUID()}`;
}
//# sourceMappingURL=ids.js.map