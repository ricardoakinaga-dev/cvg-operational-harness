export function composePrompt(config) {
    const blocks = config.promptBlocks
        .filter((block) => block.enabled)
        .slice()
        .sort(comparePromptBlocks);
    return {
        blockIds: blocks.map((block) => block.id),
        text: blocks.map((block) => block.content).join('\n\n')
    };
}
function comparePromptBlocks(left, right) {
    if (left.priority !== right.priority)
        return left.priority - right.priority;
    return left.id.localeCompare(right.id);
}
//# sourceMappingURL=prompt-composer.js.map