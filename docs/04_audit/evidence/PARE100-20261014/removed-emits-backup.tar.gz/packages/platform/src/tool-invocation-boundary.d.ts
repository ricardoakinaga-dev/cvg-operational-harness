import type { CapabilityApproval, CapabilityExecutionInput, CapabilityExecutionResult, PluginAuditEvent, PluginToolInputValidator, PluginToolOutputValidator } from './plugin-gateway.ts';
import type { AgentConfig, PlatformPolicyResult } from './contracts.ts';
import type { AgentId, AgentVersionId, TenantId, TraceId } from './ids.ts';
export declare function blockedResult(reason: string, correlationId: CapabilityExecutionResult['correlationId']): CapabilityExecutionResult;
export declare function createSafeExecutionInput(input: {
    tenantId: TenantId;
    agentId: AgentId;
    versionId: AgentVersionId;
    traceId?: TraceId;
    config: AgentConfig;
    toolName: string;
    actor: {
        id: string;
        role: string;
        permissions: string[];
    };
    policy: Pick<PlatformPolicyResult, 'decision' | 'reason'>;
    dryRun: boolean;
    requireApproval?: boolean;
    approval?: CapabilityApproval;
    onAudit?: (event: PluginAuditEvent) => void | Promise<void>;
}): CapabilityExecutionInput;
export declare function parseToolInput(validator: PluginToolInputValidator, input: unknown): {
    success: true;
    data: Record<string, unknown>;
} | {
    success: false;
};
export declare function normalizePluginHandlerResult(result: unknown, outputValidator: PluginToolOutputValidator): Omit<CapabilityExecutionResult, 'correlationId'> | null;
export declare function isPlainRecord(value: unknown): value is Record<string, unknown>;
