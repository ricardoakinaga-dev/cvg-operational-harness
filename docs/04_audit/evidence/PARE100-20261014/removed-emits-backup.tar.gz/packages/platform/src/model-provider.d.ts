import type { ModelConfig } from './contracts.ts';
export declare const CONTROLLED_MODEL_PROVIDER: "fake";
export declare const CONTROLLED_MODEL: "deterministic-v1";
export interface ModelProviderRequest {
    prompt: string;
    fallbackText: string;
}
export interface ModelProviderResponse {
    text: string;
    provider: string;
    model: string;
    externalCall: false;
}
export interface ModelProvider {
    readonly name: string;
    readonly supportedModels: readonly string[];
    complete(input: ModelProviderRequest): Promise<ModelProviderResponse>;
}
export declare class DeterministicModelProvider implements ModelProvider {
    readonly name: "fake";
    readonly supportedModels: readonly "deterministic-v1"[];
    constructor(config?: ModelConfig);
    complete(input: ModelProviderRequest): Promise<ModelProviderResponse>;
}
export declare class ModelProviderRegistry {
    private readonly providers;
    constructor(providers?: ModelProvider[]);
    register(provider: ModelProvider): ModelProviderRegistry;
    resolve(name: string): ModelProvider | null;
    resolveForConfig(config: ModelConfig): ModelProvider;
    list(): ModelProvider[];
}
export declare function createControlledModelProviderRegistry(): ModelProviderRegistry;
export declare function resolveControlledModelProvider(config: ModelConfig): ModelProvider;
export declare function createDryRunModelProvider(config: ModelConfig): ModelProvider;
