import { type AgentConfig, type AgentVersionRecord, type PromptBlock } from './contracts.ts';
export declare const CONTROLLED_KERNEL_PROMPT_BLOCK: Readonly<PromptBlock>;
export declare const KERNEL_RESPONSE_TEMPLATE_KEYS: readonly string[];
export interface PromptProfileSnapshot {
    version: string;
    status: AgentVersionRecord['status'];
    checksum: string;
    blockIds: string[];
    templateKeys: string[];
}
export declare function createPromptProfileChecksum(config: Pick<AgentConfig, 'promptBlocks' | 'responseTemplates'>): string;
export declare function createPromptProfileSnapshot(version: Pick<AgentVersionRecord, 'id' | 'version' | 'status' | 'config'>): PromptProfileSnapshot;
export declare function assertPromptProfileIntegrity(config: AgentConfig): void;
export declare function assertPromptProfileClone(source: AgentConfig, next: AgentConfig): void;
export declare function isProtectedPromptBlock(block: PromptBlock): boolean;
