import type { ControlPlaneStore } from './control-plane-store.ts';
import { type AgentConfig, type AgentRecord, type ReleaseCandidateRecord } from './contracts.ts';
import { type AgentId, type AgentVersionId, type TenantId } from './ids.ts';
export declare const CONTROLLED_SECRETARY_TENANT_ID: string;
export declare const CONTROLLED_SECRETARY_SLUG = "cvg-secretary";
export declare function createValidatedControlledReleaseCandidate(store: ControlPlaneStore, tenantId: TenantId, agentId: AgentId, versionId: AgentVersionId, createdBy: string): Promise<ReleaseCandidateRecord>;
export declare function ensureControlledSecretaryPreset(store: ControlPlaneStore, tenantId?: TenantId, createdBy?: string): Promise<AgentRecord>;
export declare function createControlledSecretaryConfig(): AgentConfig;
