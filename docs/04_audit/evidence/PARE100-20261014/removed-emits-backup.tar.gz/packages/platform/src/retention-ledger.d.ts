import { type TenantId } from './ids.ts';
export declare const RETENTION_KINDS: readonly ["trace", "metric", "integration", "audit"];
export type RetentionKind = (typeof RETENTION_KINDS)[number];
export interface RetentionRecord {
    tenantId: TenantId;
    id: string;
    kind: RetentionKind;
    createdAt: Date;
    expiresAt: Date;
    metadata: Record<string, string>;
}
export interface RetentionCounters {
    appended: number;
    purged: number;
    preservedAudit: number;
}
export interface RetentionAggregate {
    tenantId: TenantId;
    totalRecords: number;
    activeRecords: number;
    expiredRecords: number;
    byKind: Record<RetentionKind, number>;
    counters: RetentionCounters;
}
export interface RetentionPurgeResult {
    purgedIds: string[];
    preservedAuditIds: string[];
    remaining: number;
}
/** Bounded local retention ledger. Audit rows are never purged by this helper. */
export declare class RetentionLedger {
    private readonly records;
    private readonly counterByTenant;
    private readonly clock;
    constructor(clock?: () => Date);
    append(input: {
        tenantId: TenantId;
        kind: RetentionKind;
        expiresAt: Date;
        metadata?: Record<string, string>;
    }): RetentionRecord;
    purge(rawTenantId: TenantId): RetentionPurgeResult;
    list(rawTenantId: TenantId): RetentionRecord[];
    /** Returns bounded operational counts without retaining or exposing payloads. */
    aggregate(rawTenantId: TenantId): RetentionAggregate;
    counters(rawTenantId: TenantId): RetentionCounters;
    private now;
    private counterFor;
}
