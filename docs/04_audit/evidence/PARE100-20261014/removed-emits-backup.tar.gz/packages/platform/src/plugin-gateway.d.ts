import { type CorrelationId } from '@cvg/shared';
import { type AgentConfig, type PluginManifest, type PlatformPolicyResult } from './contracts.ts';
import { type CapabilityApprovalAuthority } from './approval-authority.ts';
import type { AgentId, AgentVersionId, TenantId, TraceId } from './ids.ts';
import type { PluginHookHandler } from './event-bus.ts';
export interface PluginHandlerContext {
    tenantId: TenantId;
    agentId: AgentId;
    versionId: AgentVersionId;
    toolName: string;
    dryRun: boolean;
}
export interface PluginHandlerResult {
    status: 'succeeded' | 'failed' | 'blocked';
    data?: unknown;
    error?: string;
}
export type PluginHandler = (input: unknown, context: PluginHandlerContext) => PluginHandlerResult | Promise<PluginHandlerResult>;
export interface PluginToolInputValidator {
    safeParse(input: unknown): unknown;
}
export type PluginToolOutputValidator = PluginToolInputValidator;
export interface RegisteredPlugin {
    manifest: PluginManifest;
    handlers: Record<string, PluginHandler>;
    inputValidators?: Record<string, PluginToolInputValidator>;
    outputValidators?: Record<string, PluginToolOutputValidator>;
    hooks?: Record<string, PluginHookHandler>;
}
export interface PlannedCapabilityTool {
    plugin: string;
    version: string;
    toolName: string;
}
export type CapabilityToolBlockReason = 'plugin_binding_missing' | 'plugin_version_required' | 'plugin_version_not_registered' | 'tool_binding_ambiguous' | 'tool_not_registered' | 'tool_input_validator_missing' | 'tool_output_validator_missing' | 'invalid_tool_context' | 'plugin_permission_not_declared';
export type CapabilityToolResolution = {
    status: 'resolved';
    plugin: string;
    version: string;
    toolName: string;
    permission: string;
    requiresApproval: boolean;
} | {
    status: 'blocked';
    reason: CapabilityToolBlockReason;
};
export interface PluginAuditEvent {
    type: 'tool_call';
    correlationId: CorrelationId;
    traceId: TraceId;
    tenantId: TenantId;
    agentId: AgentId;
    versionId: AgentVersionId;
    plugin: string;
    toolName: string;
    status: 'succeeded' | 'failed' | 'blocked';
    payload: unknown;
}
export declare class PluginRegistry {
    private readonly plugins;
    constructor(plugins?: RegisteredPlugin[]);
    register(plugin: RegisteredPlugin): PluginRegistry;
    get(name: string, version: string): RegisteredPlugin | null;
    getLatest(name: string): RegisteredPlugin | null;
    list(): RegisteredPlugin[];
    listPlannedTools(config: AgentConfig, intent: string): PlannedCapabilityTool[];
}
export interface CapabilityExecutionInput {
    tenantId: TenantId;
    agentId: AgentId;
    versionId: AgentVersionId;
    traceId?: TraceId;
    config: AgentConfig;
    toolName: string;
    input: unknown;
    actor: {
        id: string;
        role: string;
        permissions: string[];
    };
    policy: Pick<PlatformPolicyResult, 'decision' | 'reason'>;
    approval?: CapabilityApproval;
    requireApproval?: boolean;
    dryRun: boolean;
    onAudit?: (event: PluginAuditEvent) => void | Promise<void>;
}
export interface CapabilityApproval {
    id: string;
    tenantId: TenantId;
    agentId: AgentId;
    versionId: AgentVersionId;
    toolName: string;
    actorId: string;
    expiresAt: Date;
}
export interface CapabilityApprovalResolutionInput {
    tenantId: TenantId;
    agentId: AgentId;
    versionId: AgentVersionId;
    toolName: string;
    input: unknown;
    actor: {
        id: string;
        role: string;
        permissions: string[];
    };
}
export interface CapabilityActorAuthorizationInput {
    tenantId: TenantId;
    agentId: AgentId;
    versionId: AgentVersionId;
    toolName: string;
    requiredPermission: string;
    actor: {
        id: string;
        role: string;
    };
}
export type CapabilityActorAuthorizer = (input: CapabilityActorAuthorizationInput) => readonly string[] | null | Promise<readonly string[] | null>;
export type CapabilityApprovalResolver = (input: CapabilityApprovalResolutionInput) => CapabilityApproval | null | Promise<CapabilityApproval | null>;
export interface CapabilityGatewayOptions {
    actorAuthorizer?: CapabilityActorAuthorizer;
    approvalAuthority?: CapabilityApprovalAuthority;
    now?: () => Date;
}
export interface CapabilityExecutionResult {
    status: 'succeeded' | 'failed' | 'blocked';
    reason?: string;
    data?: unknown;
    correlationId: CorrelationId;
}
export declare class CapabilityGateway {
    private readonly registry;
    private readonly options;
    private readonly now;
    constructor(registry: PluginRegistry, options?: CapabilityGatewayOptions);
    planTools(config: AgentConfig, intent: string): PlannedCapabilityTool[];
    resolveConfiguredTool(config: AgentConfig, toolName: string): CapabilityToolResolution;
    permissionForConfiguredTool(config: AgentConfig, toolName: string): string | null;
    execute(input: CapabilityExecutionInput): Promise<CapabilityExecutionResult>;
    private authorizeActor;
    private hasValidApproval;
    private blocked;
    private auditSafely;
    private audit;
    private resolveBoundTool;
}
