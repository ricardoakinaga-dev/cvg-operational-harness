import { z } from 'zod';
import type { ControlledOutputDecision, ControlledOutputMode, ControlledOutputReason } from './output-policy.ts';
import { type AgentId, type AgentVersionId, type TenantId, type TraceId, type TestSuiteId, type TestSuiteRunId, type PluginCatalogId, type KnowledgeSourceId, type ReleaseCandidateId } from './ids.ts';
export declare const TenantScopeSchema: z.ZodObject<{
    tenantId: z.ZodString;
}, z.core.$strict>;
export type TenantScope = z.infer<typeof TenantScopeSchema>;
export declare const AgentVersionStatusSchema: z.ZodEnum<{
    DRAFT: "DRAFT";
    TESTING: "TESTING";
    APPROVED: "APPROVED";
    PUBLISHED: "PUBLISHED";
    ARCHIVED: "ARCHIVED";
}>;
export type AgentVersionStatus = z.infer<typeof AgentVersionStatusSchema>;
export declare const PromptBlockSchema: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodEnum<{
        system: "system";
        persona: "persona";
        instruction: "instruction";
        safety: "safety";
        context: "context";
        response: "response";
    }>;
    content: z.ZodString;
    priority: z.ZodNumber;
    enabled: z.ZodDefault<z.ZodBoolean>;
    locked: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>;
export type PromptBlock = z.infer<typeof PromptBlockSchema>;
export declare const ModelConfigSchema: z.ZodObject<{
    provider: z.ZodString;
    model: z.ZodString;
    temperature: z.ZodNumber;
    maxTokens: z.ZodNumber;
    timeoutMs: z.ZodNumber;
    retries: z.ZodNumber;
    fallbackProvider: z.ZodOptional<z.ZodString>;
    secretRef: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type ModelConfig = z.infer<typeof ModelConfigSchema>;
export declare const PolicyBundleSchema: z.ZodObject<{
    version: z.ZodString;
    minConfidence: z.ZodNumber;
    clarifyThreshold: z.ZodOptional<z.ZodNumber>;
    handoffThreshold: z.ZodOptional<z.ZodNumber>;
    lowConfidence: z.ZodEnum<{
        handoff: "handoff";
        clarify: "clarify";
    }>;
    maxClarifications: z.ZodNumber;
    enabledActions: z.ZodArray<z.ZodString>;
    approvalActions: z.ZodArray<z.ZodString>;
    blockedActions: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export type PolicyBundle = z.infer<typeof PolicyBundleSchema>;
export declare const PluginBindingSchema: z.ZodObject<{
    plugin: z.ZodString;
    version: z.ZodOptional<z.ZodString>;
    enabled: z.ZodBoolean;
    allowedTools: z.ZodArray<z.ZodString>;
    config: z.ZodRecord<z.ZodString, z.ZodUnknown>;
}, z.core.$strict>;
export type PluginBinding = z.infer<typeof PluginBindingSchema>;
export declare const KnowledgeBindingSchema: z.ZodObject<{
    source: z.ZodString;
    version: z.ZodString;
    enabled: z.ZodBoolean;
    requiresApprovedSource: z.ZodBoolean;
}, z.core.$strict>;
export type KnowledgeBinding = z.infer<typeof KnowledgeBindingSchema>;
export declare const ApprovedKnowledgeForTestSchema: z.ZodObject<{
    version: z.ZodString;
    answer: z.ZodString;
    source: z.ZodString;
}, z.core.$strict>;
export type ApprovedKnowledgeForTest = z.infer<typeof ApprovedKnowledgeForTestSchema>;
export declare const HandoffPrioritySchema: z.ZodEnum<{
    low: "low";
    medium: "medium";
    high: "high";
}>;
export type HandoffPriority = z.infer<typeof HandoffPrioritySchema>;
export declare const HandoffConfigSchema: z.ZodObject<{
    lowConfidenceDestination: z.ZodString;
    destinations: z.ZodArray<z.ZodString>;
    maxClarifications: z.ZodNumber;
    priority: z.ZodOptional<z.ZodEnum<{
        low: "low";
        medium: "medium";
        high: "high";
    }>>;
}, z.core.$strict>;
export type HandoffConfig = z.infer<typeof HandoffConfigSchema>;
export declare const FeatureFlagsSchema: z.ZodRecord<z.ZodString, z.ZodBoolean>;
export type FeatureFlags = z.infer<typeof FeatureFlagsSchema>;
export declare const AgentConfigSchema: z.ZodObject<{
    persona: z.ZodObject<{
        name: z.ZodString;
        role: z.ZodString;
        tone: z.ZodString;
    }, z.core.$strict>;
    greeting: z.ZodString;
    promptBlocks: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            system: "system";
            persona: "persona";
            instruction: "instruction";
            safety: "safety";
            context: "context";
            response: "response";
        }>;
        content: z.ZodString;
        priority: z.ZodNumber;
        enabled: z.ZodDefault<z.ZodBoolean>;
        locked: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    responseTemplates: z.ZodRecord<z.ZodString, z.ZodString>;
    model: z.ZodObject<{
        provider: z.ZodString;
        model: z.ZodString;
        temperature: z.ZodNumber;
        maxTokens: z.ZodNumber;
        timeoutMs: z.ZodNumber;
        retries: z.ZodNumber;
        fallbackProvider: z.ZodOptional<z.ZodString>;
        secretRef: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    featureFlags: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodBoolean>>;
    policies: z.ZodObject<{
        version: z.ZodString;
        minConfidence: z.ZodNumber;
        clarifyThreshold: z.ZodOptional<z.ZodNumber>;
        handoffThreshold: z.ZodOptional<z.ZodNumber>;
        lowConfidence: z.ZodEnum<{
            handoff: "handoff";
            clarify: "clarify";
        }>;
        maxClarifications: z.ZodNumber;
        enabledActions: z.ZodArray<z.ZodString>;
        approvalActions: z.ZodArray<z.ZodString>;
        blockedActions: z.ZodArray<z.ZodString>;
    }, z.core.$strict>;
    plugins: z.ZodArray<z.ZodObject<{
        plugin: z.ZodString;
        version: z.ZodOptional<z.ZodString>;
        enabled: z.ZodBoolean;
        allowedTools: z.ZodArray<z.ZodString>;
        config: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    }, z.core.$strict>>;
    knowledge: z.ZodArray<z.ZodObject<{
        source: z.ZodString;
        version: z.ZodString;
        enabled: z.ZodBoolean;
        requiresApprovedSource: z.ZodBoolean;
    }, z.core.$strict>>;
    handoff: z.ZodObject<{
        lowConfidenceDestination: z.ZodString;
        destinations: z.ZodArray<z.ZodString>;
        maxClarifications: z.ZodNumber;
        priority: z.ZodOptional<z.ZodEnum<{
            low: "low";
            medium: "medium";
            high: "high";
        }>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export type AgentConfig = z.infer<typeof AgentConfigSchema>;
export declare const AgentCreateInputSchema: z.ZodObject<{
    slug: z.ZodString;
    name: z.ZodString;
    description: z.ZodString;
}, z.core.$strict>;
export type AgentCreateInput = z.infer<typeof AgentCreateInputSchema>;
export interface AgentRecord {
    tenantId: TenantId;
    id: AgentId;
    slug: string;
    name: string;
    description: string;
    activeVersionId: AgentVersionId | null;
    createdAt: Date;
    updatedAt: Date;
}
export interface AgentVersionRecord {
    tenantId: TenantId;
    id: AgentVersionId;
    agentId: AgentId;
    version: number;
    status: AgentVersionStatus;
    config: AgentConfig;
    createdBy: string;
    createdAt: Date;
    publishedAt: Date | null;
}
export declare const PlatformDecisionSchema: z.ZodEnum<{
    handoff: "handoff";
    blocked: "blocked";
    clarify: "clarify";
    allowed: "allowed";
    requires_approval: "requires_approval";
}>;
export type PlatformDecision = z.infer<typeof PlatformDecisionSchema>;
export declare const AgentExecutionModeSchema: z.ZodEnum<{
    TEST_LAB: "TEST_LAB";
    CONTROLLED_RUNTIME: "CONTROLLED_RUNTIME";
}>;
export type AgentExecutionMode = z.infer<typeof AgentExecutionModeSchema>;
export interface PlatformPolicyResult {
    decision: PlatformDecision;
    layer: 'hard_safety' | 'organization' | 'agent_behavior';
    reason: string;
    policyVersion: string;
}
export declare const PluginToolSchema: z.ZodObject<{
    name: z.ZodString;
    permission: z.ZodString;
    risk: z.ZodEnum<{
        low: "low";
        medium: "medium";
        high: "high";
        critical: "critical";
    }>;
    requiresApproval: z.ZodBoolean;
    intents: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strict>;
export declare const PluginManifestSchema: z.ZodObject<{
    name: z.ZodString;
    version: z.ZodString;
    capabilities: z.ZodArray<z.ZodString>;
    permissions: z.ZodArray<z.ZodString>;
    tools: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        permission: z.ZodString;
        risk: z.ZodEnum<{
            low: "low";
            medium: "medium";
            high: "high";
            critical: "critical";
        }>;
        requiresApproval: z.ZodBoolean;
        intents: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    hooks: z.ZodArray<z.ZodString>;
    dependencies: z.ZodArray<z.ZodString>;
    configSchemaVersion: z.ZodString;
}, z.core.$strict>;
export type PluginManifest = z.infer<typeof PluginManifestSchema>;
export type PluginTool = z.infer<typeof PluginToolSchema>;
export declare const PluginCatalogStatusSchema: z.ZodEnum<{
    DRAFT: "DRAFT";
    APPROVED: "APPROVED";
    ARCHIVED: "ARCHIVED";
}>;
export type PluginCatalogStatus = z.infer<typeof PluginCatalogStatusSchema>;
export declare const PluginCatalogCreateInputSchema: z.ZodObject<{
    manifest: z.ZodObject<{
        name: z.ZodString;
        version: z.ZodString;
        capabilities: z.ZodArray<z.ZodString>;
        permissions: z.ZodArray<z.ZodString>;
        tools: z.ZodArray<z.ZodObject<{
            name: z.ZodString;
            permission: z.ZodString;
            risk: z.ZodEnum<{
                low: "low";
                medium: "medium";
                high: "high";
                critical: "critical";
            }>;
            requiresApproval: z.ZodBoolean;
            intents: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        hooks: z.ZodArray<z.ZodString>;
        dependencies: z.ZodArray<z.ZodString>;
        configSchemaVersion: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>;
export type PluginCatalogCreateInput = z.infer<typeof PluginCatalogCreateInputSchema>;
export declare const PluginCatalogTransitionInputSchema: z.ZodObject<{
    target: z.ZodEnum<{
        DRAFT: "DRAFT";
        APPROVED: "APPROVED";
        ARCHIVED: "ARCHIVED";
    }>;
    expectedStatus: z.ZodOptional<z.ZodEnum<{
        DRAFT: "DRAFT";
        APPROVED: "APPROVED";
        ARCHIVED: "ARCHIVED";
    }>>;
}, z.core.$strict>;
export type PluginCatalogTransitionInput = z.infer<typeof PluginCatalogTransitionInputSchema>;
export interface PluginCatalogRecord {
    tenantId: TenantId;
    id: PluginCatalogId;
    manifest: PluginManifest;
    status: PluginCatalogStatus;
    createdBy: string;
    approvedBy: string | null;
    createdAt: Date;
    updatedAt: Date;
}
export declare const KnowledgeSourceStatusSchema: z.ZodEnum<{
    DRAFT: "DRAFT";
    APPROVED: "APPROVED";
    ARCHIVED: "ARCHIVED";
}>;
export type KnowledgeSourceStatus = z.infer<typeof KnowledgeSourceStatusSchema>;
export declare const KnowledgeSourceCreateInputSchema: z.ZodObject<{
    source: z.ZodString;
    version: z.ZodString;
    label: z.ZodString;
    description: z.ZodString;
}, z.core.$strict>;
export type KnowledgeSourceCreateInput = z.infer<typeof KnowledgeSourceCreateInputSchema>;
export declare const KnowledgeSourceTransitionInputSchema: z.ZodObject<{
    target: z.ZodEnum<{
        DRAFT: "DRAFT";
        APPROVED: "APPROVED";
        ARCHIVED: "ARCHIVED";
    }>;
    expectedStatus: z.ZodOptional<z.ZodEnum<{
        DRAFT: "DRAFT";
        APPROVED: "APPROVED";
        ARCHIVED: "ARCHIVED";
    }>>;
}, z.core.$strict>;
export type KnowledgeSourceTransitionInput = z.infer<typeof KnowledgeSourceTransitionInputSchema>;
export interface KnowledgeSourceRecord {
    tenantId: TenantId;
    id: KnowledgeSourceId;
    source: string;
    version: string;
    label: string;
    description: string;
    status: KnowledgeSourceStatus;
    createdBy: string;
    approvedBy: string | null;
    createdAt: Date;
    updatedAt: Date;
}
export declare const ReleaseCandidateStatusSchema: z.ZodEnum<{
    DRAFT: "DRAFT";
    ARCHIVED: "ARCHIVED";
    VALIDATED: "VALIDATED";
    REJECTED: "REJECTED";
}>;
export type ReleaseCandidateStatus = z.infer<typeof ReleaseCandidateStatusSchema>;
export declare const ReleaseCandidateGateKeySchema: z.ZodEnum<{
    safety_preflight: "safety_preflight";
    test_lab_regression: "test_lab_regression";
    snapshot_integrity: "snapshot_integrity";
    external_boundary: "external_boundary";
}>;
export type ReleaseCandidateGateKey = z.infer<typeof ReleaseCandidateGateKeySchema>;
export declare const ReleaseCandidateGateStatusSchema: z.ZodEnum<{
    PASS: "PASS";
    FAIL: "FAIL";
}>;
export type ReleaseCandidateGateStatus = z.infer<typeof ReleaseCandidateGateStatusSchema>;
export declare const ReleaseCandidateGateResultSchema: z.ZodObject<{
    key: z.ZodEnum<{
        safety_preflight: "safety_preflight";
        test_lab_regression: "test_lab_regression";
        snapshot_integrity: "snapshot_integrity";
        external_boundary: "external_boundary";
    }>;
    status: z.ZodEnum<{
        PASS: "PASS";
        FAIL: "FAIL";
    }>;
    evidenceRef: z.ZodString;
}, z.core.$strict>;
export type ReleaseCandidateGateResult = z.infer<typeof ReleaseCandidateGateResultSchema>;
export declare const ReleaseCandidateCreateInputSchema: z.ZodObject<{
    agentId: z.ZodString;
    versionId: z.ZodString;
    gateResults: z.ZodArray<z.ZodObject<{
        key: z.ZodEnum<{
            safety_preflight: "safety_preflight";
            test_lab_regression: "test_lab_regression";
            snapshot_integrity: "snapshot_integrity";
            external_boundary: "external_boundary";
        }>;
        status: z.ZodEnum<{
            PASS: "PASS";
            FAIL: "FAIL";
        }>;
        evidenceRef: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ReleaseCandidateCreateInput = z.infer<typeof ReleaseCandidateCreateInputSchema>;
export declare const ReleaseCandidateTransitionInputSchema: z.ZodObject<{
    target: z.ZodEnum<{
        DRAFT: "DRAFT";
        ARCHIVED: "ARCHIVED";
        VALIDATED: "VALIDATED";
        REJECTED: "REJECTED";
    }>;
    expectedStatus: z.ZodOptional<z.ZodEnum<{
        DRAFT: "DRAFT";
        ARCHIVED: "ARCHIVED";
        VALIDATED: "VALIDATED";
        REJECTED: "REJECTED";
    }>>;
}, z.core.$strict>;
export type ReleaseCandidateTransitionInput = z.infer<typeof ReleaseCandidateTransitionInputSchema>;
export interface ReleaseCandidateRecord {
    tenantId: TenantId;
    id: ReleaseCandidateId;
    agentId: AgentId;
    versionId: AgentVersionId;
    evidenceDigest: string;
    gateResults: ReleaseCandidateGateResult[];
    status: ReleaseCandidateStatus;
    createdBy: string;
    validatedBy: string | null;
    createdAt: Date;
    updatedAt: Date;
    validatedAt: Date | null;
}
export type TraceSpanName = 'normalize' | 'context' | 'intent' | 'policy' | 'knowledge' | 'prompt' | 'model' | 'tool' | 'response' | 'handoff' | 'delivery';
export type TraceSpanStatus = 'completed' | 'blocked' | 'skipped';
export interface TestRunTraceSpan {
    name: TraceSpanName;
    status: TraceSpanStatus;
    durationMs: number;
}
export interface TestRunTrace {
    traceId: TraceId;
    tenantId: TenantId;
    agentId: AgentId;
    versionId: AgentVersionId;
    input: {
        message: string;
        historySize: number;
    };
    intent: {
        name: string;
        confidence: number;
    };
    risk?: {
        level: 'low' | 'medium' | 'high' | 'critical';
        reason: string;
    };
    policy: PlatformPolicyResult[];
    knowledge: {
        status: 'not_requested' | 'approved_source_missing' | 'answered' | 'handoff';
        source?: string;
        version?: string;
    };
    tools: Array<{
        name: string;
        status: 'not_run' | 'blocked' | 'succeeded' | 'failed';
    }>;
    toolResults?: Array<{
        name: string;
        status: 'not_run' | 'blocked' | 'succeeded' | 'failed';
        output: {
            redacted: true;
        } | null;
    }>;
    handoff: {
        requested: boolean;
        reason: string | null;
        state: 'BOT_ACTIVE' | 'HANDOFF_REQUESTED';
        destination?: string;
        priority?: HandoffPriority;
    };
    response: {
        text: string;
        mode: 'answer' | 'clarify' | 'handoff' | 'blocked';
    };
    outputPolicy?: {
        decision: ControlledOutputDecision;
        reason: ControlledOutputReason;
        mode: ControlledOutputMode;
        redacted: boolean;
    };
    provider: {
        provider: string;
        model: string;
        externalCall: false;
    };
    prompt?: {
        version: string;
        blockIds: string[];
        status?: AgentVersionStatus;
        checksum?: string;
    };
    configVersion: string;
    executionMode: AgentExecutionMode;
    status?: 'completed' | 'blocked' | 'failed';
    startedAt?: Date;
    completedAt?: Date;
    latencyMs?: number;
    tokenUsage?: {
        prompt: number;
        completion: number;
        total: number;
        estimated: true;
    };
    spans?: TestRunTraceSpan[];
    conversationId?: string;
    sessionId?: string;
    createdAt: Date;
}
export declare const TestLabCaseSchema: z.ZodObject<{
    id: z.ZodString;
    message: z.ZodString;
    history: z.ZodDefault<z.ZodArray<z.ZodString>>;
    expectedPolicyDecision: z.ZodOptional<z.ZodEnum<{
        handoff: "handoff";
        blocked: "blocked";
        clarify: "clarify";
        allowed: "allowed";
        requires_approval: "requires_approval";
    }>>;
    expectedResponseMode: z.ZodEnum<{
        handoff: "handoff";
        blocked: "blocked";
        clarify: "clarify";
        answer: "answer";
    }>;
    expectedHandoff: z.ZodOptional<z.ZodBoolean>;
    approvedKnowledge: z.ZodOptional<z.ZodObject<{
        version: z.ZodString;
        answer: z.ZodString;
        source: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type TestLabCase = z.infer<typeof TestLabCaseSchema>;
export declare const TestSuiteCreateInputSchema: z.ZodObject<{
    slug: z.ZodString;
    name: z.ZodString;
    description: z.ZodString;
    agentId: z.ZodString;
    versionId: z.ZodString;
    cases: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        message: z.ZodString;
        history: z.ZodDefault<z.ZodArray<z.ZodString>>;
        expectedPolicyDecision: z.ZodOptional<z.ZodEnum<{
            handoff: "handoff";
            blocked: "blocked";
            clarify: "clarify";
            allowed: "allowed";
            requires_approval: "requires_approval";
        }>>;
        expectedResponseMode: z.ZodEnum<{
            handoff: "handoff";
            blocked: "blocked";
            clarify: "clarify";
            answer: "answer";
        }>;
        expectedHandoff: z.ZodOptional<z.ZodBoolean>;
        approvedKnowledge: z.ZodOptional<z.ZodObject<{
            version: z.ZodString;
            answer: z.ZodString;
            source: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type TestSuiteCreateInput = z.infer<typeof TestSuiteCreateInputSchema>;
export declare const TestSuiteCloneInputSchema: z.ZodObject<{
    name: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    versionId: z.ZodOptional<z.ZodString>;
    cases: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        message: z.ZodString;
        history: z.ZodDefault<z.ZodArray<z.ZodString>>;
        expectedPolicyDecision: z.ZodOptional<z.ZodEnum<{
            handoff: "handoff";
            blocked: "blocked";
            clarify: "clarify";
            allowed: "allowed";
            requires_approval: "requires_approval";
        }>>;
        expectedResponseMode: z.ZodEnum<{
            handoff: "handoff";
            blocked: "blocked";
            clarify: "clarify";
            answer: "answer";
        }>;
        expectedHandoff: z.ZodOptional<z.ZodBoolean>;
        approvedKnowledge: z.ZodOptional<z.ZodObject<{
            version: z.ZodString;
            answer: z.ZodString;
            source: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export type TestSuiteCloneInput = z.infer<typeof TestSuiteCloneInputSchema>;
export interface TestSuiteRecord {
    tenantId: TenantId;
    id: TestSuiteId;
    slug: string;
    name: string;
    description: string;
    agentId: AgentId;
    versionId: AgentVersionId;
    version: number;
    cases: TestLabCase[];
    previousSuiteId: TestSuiteId | null;
    createdBy: string;
    createdAt: Date;
    updatedAt: Date;
}
export interface TestLabEvaluation {
    caseId: string;
    passed: boolean;
    failures: string[];
    trace: TestRunTrace;
}
export interface TestLabSuiteResult {
    passed: boolean;
    results: TestLabEvaluation[];
}
export interface TestSuiteVariantResult {
    label: 'A' | 'B';
    versionId: AgentVersionId;
    passed: boolean;
    results: TestLabEvaluation[];
}
export interface TestSuiteRunRecord {
    tenantId: TenantId;
    id: TestSuiteRunId;
    suiteId: TestSuiteId;
    agentId: AgentId;
    variants: TestSuiteVariantResult[];
    passed: boolean;
    createdBy: string;
    createdAt: Date;
}
export type PlatformIds = {
    tenantId: TenantId;
    agentId: AgentId;
    versionId: AgentVersionId;
};
export declare function assertPlatformIds(input: PlatformIds): void;
export declare function assertTraceId(traceId: string): asserts traceId is TraceId;
