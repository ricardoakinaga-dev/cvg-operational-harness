export declare const HUMAN_TAKEOVER_STATES: readonly ["BOT_ACTIVE", "HANDOFF_REQUESTED", "HUMAN_ACTIVE", "RESOLVED"];
export type HumanTakeoverState = (typeof HUMAN_TAKEOVER_STATES)[number];
export declare const HUMAN_TAKEOVER_EVENTS: readonly ["request_handoff", "accept_handoff", "resolve_handoff", "release_to_bot"];
export type HumanTakeoverEvent = (typeof HUMAN_TAKEOVER_EVENTS)[number];
export declare function transitionHumanTakeover(state: HumanTakeoverState, event: HumanTakeoverEvent): HumanTakeoverState;
export declare function canBotRespond(state: HumanTakeoverState): boolean;
