import { type TestRunTrace, type TestSuiteRunRecord } from './contracts.ts';
export declare function sanitizeTraceForPersistence(trace: unknown): TestRunTrace;
export declare function sanitizeTestSuiteRunTraces(rawRun: unknown): TestSuiteRunRecord;
