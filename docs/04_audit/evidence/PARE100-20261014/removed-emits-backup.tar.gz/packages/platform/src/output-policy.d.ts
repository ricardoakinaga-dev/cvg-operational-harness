export declare const CONTROLLED_OUTPUT_MAX_CHARS: 4000;
export declare const CONTROLLED_SAFE_OUTPUTS: Readonly<{
    readonly handoff: "Vou encaminhar sua solicitação para a equipe responsável.";
    readonly blocked: "Essa ação permanece bloqueada pelas políticas de segurança.";
    readonly clarify: "Pode esclarecer um pouco mais sua solicitação?";
    readonly medicationRefusal: "Não posso orientar o uso de medicamentos. Procure um médico-veterinário para avaliação.";
}>;
export type ControlledOutputMode = 'answer' | 'clarify' | 'handoff' | 'blocked';
export type ControlledOutputRiskLevel = 'low' | 'medium' | 'high' | 'critical';
export type ControlledOutputDecision = 'allowed' | 'rewritten';
export type ControlledOutputReason = 'output_allowed' | 'output_redacted' | 'unsafe_output_rejected' | 'invalid_output' | 'output_too_large';
export interface ControlledOutputInput {
    text: unknown;
    mode: unknown;
    riskLevel: unknown;
}
export interface ControlledOutputResult {
    decision: ControlledOutputDecision;
    reason: ControlledOutputReason;
    mode: ControlledOutputMode;
    text: string;
    redacted: boolean;
}
export declare function enforceControlledOutput(input: ControlledOutputInput): ControlledOutputResult;
