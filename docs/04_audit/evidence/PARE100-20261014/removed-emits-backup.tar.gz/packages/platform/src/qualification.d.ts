export interface ControlledQualificationInput {
    persistenceLatenciesMs: number[];
    responseLatenciesMs: number[];
    lostMessages: number;
    duplicateEffects: number;
    gates: Record<string, boolean>;
    targets?: {
        persistenceP95Ms?: number;
        responseP95Ms?: number;
    };
    conditions?: string;
}
export interface ControlledQualificationResult {
    status: 'QUALIFIED_CONTROLLED' | 'NO_GO';
    metrics: {
        persistenceP95Ms: number;
        responseP95Ms: number;
        persistenceSampleCount: number;
        responseSampleCount: number;
        lostMessages: number;
        duplicateEffects: number;
    };
    failedGates: string[];
    productionBoundary: 'NO-GO';
    conditions: string;
}
/** Converts measured local evidence into a conservative, auditable verdict. */
export declare function runControlledQualification(input: ControlledQualificationInput): ControlledQualificationResult;
