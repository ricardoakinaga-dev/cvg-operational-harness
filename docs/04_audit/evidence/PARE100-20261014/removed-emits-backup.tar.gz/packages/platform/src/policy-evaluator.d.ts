import type { AgentConfig, PlatformPolicyResult } from './contracts.ts';
export interface PlatformPolicyInput {
    action: string;
    confidence: number;
    config: AgentConfig;
    policyAvailable?: boolean;
    clarificationCount?: number;
    riskLevel?: 'low' | 'medium' | 'high' | 'critical';
}
export declare function evaluatePlatformPolicy(input: PlatformPolicyInput): PlatformPolicyResult;
