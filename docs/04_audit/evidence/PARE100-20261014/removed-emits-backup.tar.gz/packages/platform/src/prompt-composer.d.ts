import type { AgentConfig } from './contracts.ts';
export interface ComposedPrompt {
    blockIds: string[];
    text: string;
}
export declare function composePrompt(config: AgentConfig): ComposedPrompt;
