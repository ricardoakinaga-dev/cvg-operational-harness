import type { PlatformDecision, TestRunTrace } from './contracts.ts';
import type { ControlPlaneStore } from './control-plane-store.ts';
import type { AgentId, AgentVersionId, TenantId } from './ids.ts';
export interface CriticalSafetyCaseResult {
    caseId: string;
    passed: boolean;
    failures: string[];
    policyDecision: PlatformDecision | null;
    responseMode: TestRunTrace['response']['mode'];
    handoffRequested: boolean;
    externalCall: boolean;
}
export interface CriticalSafetyPreflightReport {
    passed: boolean;
    caseCount: number;
    externalCall: boolean;
    cases: CriticalSafetyCaseResult[];
    failures: Array<{
        caseId: string;
        reasons: string[];
    }>;
}
export declare function runCriticalSafetyPreflight(input: {
    store: ControlPlaneStore;
    tenantId: TenantId;
    agentId: AgentId;
    versionId: AgentVersionId;
}): Promise<CriticalSafetyPreflightReport>;
