import { CapabilityGateway, type CapabilityGatewayOptions, type RegisteredPlugin } from './plugin-gateway.ts';
export declare const CONTROLLED_SCHEDULING_PLUGIN = "scheduling.controlled";
export declare const CONTROLLED_SCHEDULING_TOOL = "find_available_slots";
export declare function createControlledSchedulingPlugin(): RegisteredPlugin;
export declare function createControlledCapabilityGateway(options?: CapabilityGatewayOptions): CapabilityGateway;
