import type { EgressDns } from '@cvg/shared';
import type { ModelLocation, ModelProvider, ProviderRequest, ProviderResult } from '../contracts.ts';
export declare const DEFAULT_MAX_RESPONSE_BYTES: number;
export type FetchLike = (input: string, init: RequestInit) => Promise<Response>;
export interface OpenAICompatibleProviderOptions {
    id: string;
    baseUrl: string;
    model: string;
    location: ModelLocation;
    apiKey?: string;
    requiresApiKey?: boolean;
    fetchImpl?: FetchLike;
    maxResponseBytes?: number;
    allowHttp?: boolean;
    /**
     * AUD19-007 — explicit opt-in for loopback/private networks (local
     * homologation). Default false: private/reserved addresses are denied.
     */
    allowPrivateNetworks?: boolean;
    /** AUD19-007 — injectable DNS for the composed egress guard (tests). */
    dnsLookup?: EgressDns['lookup'];
}
/**
 * OpenAI-compatible provider (OpenAI, vLLM, llama.cpp server, ...). The domain
 * never imports provider SDKs: everything flows through this adapter.
 */
export declare class OpenAICompatibleProvider implements ModelProvider {
    #private;
    readonly id: string;
    readonly location: ModelLocation;
    readonly models: readonly string[];
    constructor(options: OpenAICompatibleProviderOptions);
    execute(request: ProviderRequest): Promise<ProviderResult>;
}
export declare function combineTimeoutSignal(external: AbortSignal, timeoutMs: number): AbortSignal;
