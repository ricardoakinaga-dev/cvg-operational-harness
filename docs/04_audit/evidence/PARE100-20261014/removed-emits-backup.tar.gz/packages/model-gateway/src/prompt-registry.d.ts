import { z } from 'zod';
import { type DataClassification } from '@cvg/shared';
export declare const PromptStatusSchema: z.ZodEnum<{
    draft: "draft";
    approved: "approved";
    revoked: "revoked";
}>;
export type PromptStatus = z.infer<typeof PromptStatusSchema>;
export declare const PromptRecordInputSchema: z.ZodObject<{
    promptId: z.ZodString;
    version: z.ZodString;
    content: z.ZodString;
    owner: z.ZodString;
    approvedBy: z.ZodOptional<z.ZodString>;
    status: z.ZodDefault<z.ZodEnum<{
        draft: "draft";
        approved: "approved";
        revoked: "revoked";
    }>>;
    effectiveFrom: z.ZodString;
    effectiveUntil: z.ZodOptional<z.ZodString>;
    classification: z.ZodDefault<z.ZodEnum<{
        PUBLIC: "PUBLIC";
        INTERNAL: "INTERNAL";
        CONFIDENTIAL: "CONFIDENTIAL";
        CLINICAL: "CLINICAL";
        FINANCIAL: "FINANCIAL";
        CREDENTIAL: "CREDENTIAL";
    }>>;
    tenantId: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type PromptRecordInput = z.input<typeof PromptRecordInputSchema>;
export type NormalizedPromptRecordInput = z.output<typeof PromptRecordInputSchema>;
export interface PromptRecord extends NormalizedPromptRecordInput {
    sha256: string;
}
export interface PromptReference {
    promptId: string;
    version: string;
    sha256?: string;
}
export declare class PromptRegistryError extends Error {
    readonly code: 'prompt_duplicate' | 'prompt_unknown' | 'prompt_revoked' | 'prompt_not_effective' | 'prompt_expired' | 'prompt_hash_mismatch' | 'prompt_tenant_mismatch';
    constructor(code: PromptRegistryError['code'], message: string);
}
export declare function computePromptSha256(content: string): string;
/**
 * Versioned prompt registry. Production prompts must be approved, effective and
 * hash-verified before use; sessions remain pinned to a concrete version.
 */
export declare class PromptRegistry {
    #private;
    register(input: PromptRecordInput): PromptRecord;
    get(promptId: string, version: string): PromptRecord | undefined;
    resolve(reference: PromptReference, options?: {
        tenantId?: string;
        at?: Date;
    }): PromptRecord;
    list(): PromptRecord[];
}
export declare function promptContainsClassification(record: Pick<PromptRecord, 'classification'>): DataClassification;
