import { type ModelGatewayEvent, type ModelGatewayRequest, type ModelProfile, type ModelProfileName, type ModelProvider, type ModelResult, type StructuredOutputContract } from './contracts.ts';
import { type CostBudgetLimits, type CostBudgetStore } from './budget.ts';
import { CircuitBreaker, type CircuitBreakerOptions } from './circuit-breaker.ts';
import { type RetryPolicy } from './retry.ts';
import { PromptRegistry } from './prompt-registry.ts';
import { type ModelRoutingOptions } from './router.ts';
export interface ModelGatewayOptions {
    providers: ModelProvider[];
    profiles: Partial<Record<ModelProfileName, ModelProfile>>;
    prompts: PromptRegistry;
    budget?: {
        store: CostBudgetStore;
        limits: CostBudgetLimits;
    };
    circuitBreaker?: CircuitBreaker | CircuitBreakerOptions;
    routing?: ModelRoutingOptions;
    retry?: Partial<RetryPolicy>;
    clock?: () => Date;
    sleep?: (ms: number) => Promise<void>;
    random?: () => number;
    onEvent?: (event: ModelGatewayEvent) => void;
    defaultTimeoutMs?: number;
    maxOutputChars?: number;
}
export interface GenerateRequest<TStructured = unknown> extends ModelGatewayRequest {
    structuredOutput?: StructuredOutputContract<TStructured>;
    signal?: AbortSignal;
}
/**
 * Provider-agnostic model gateway.
 *
 * Model output is untrusted input: the gateway enforces deadline, retries,
 * circuit breaking, cost budgets, prompt integrity, data-placement policy and
 * fail-closed structured output before anything reaches the domain.
 */
export declare class ModelGateway {
    #private;
    constructor(options: ModelGatewayOptions);
    generate<TStructured = unknown>(request: GenerateRequest<TStructured>): Promise<ModelResult<TStructured>>;
    circuitSnapshot(): Record<string, string>;
}
