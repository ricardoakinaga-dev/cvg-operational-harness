import type { ModelProvider, ProviderRequest, ProviderResult } from '../contracts.ts';
export interface DeterministicProviderOptions {
    id?: string;
    model?: string;
    latencyMs?: number;
    respond?: (request: ProviderRequest) => ProviderResult | Promise<ProviderResult>;
}
/**
 * Controlled deterministic provider. Used by tests, evals and dry runs; it
 * never performs network calls and always reports externalCall: false.
 */
export declare class DeterministicModelProvider implements ModelProvider {
    #private;
    readonly id: string;
    readonly location: "local";
    readonly models: readonly string[];
    constructor(options?: DeterministicProviderOptions);
    execute(request: ProviderRequest): Promise<ProviderResult>;
}
