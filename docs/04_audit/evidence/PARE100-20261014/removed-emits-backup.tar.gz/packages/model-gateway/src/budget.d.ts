import type { ModelGatewayRequest } from './contracts.ts';
export type BudgetScope = 'request' | 'session' | 'tenant' | 'agent' | 'day';
export interface CostBudgetLimits {
    request?: number;
    session?: number;
    tenant?: number;
    agent?: number;
    day?: number;
}
export interface CostBudgetStore {
    consumed(scopeKey: string): number;
    consume(scopeKey: string, amountUsd: number): void;
}
export declare class InMemoryCostBudgetStore implements CostBudgetStore {
    #private;
    consumed(scopeKey: string): number;
    consume(scopeKey: string, amountUsd: number): void;
}
export declare function budgetScopeKeys(request: Pick<ModelGatewayRequest, 'requestId' | 'tenantId' | 'sessionId' | 'agentId'>, now: Date): Record<BudgetScope, string | null>;
export interface BudgetAuthorizationInput {
    request: Pick<ModelGatewayRequest, 'requestId' | 'tenantId' | 'sessionId' | 'agentId'>;
    estimatedCostUsd: number;
    limits: CostBudgetLimits;
    store: CostBudgetStore;
    now: Date;
}
export interface BudgetAuthorization {
    allowed: boolean;
    deniedScope?: BudgetScope;
    deniedKey?: string;
    spentUsd?: number;
    limitUsd?: number;
    reservedKeys: string[];
}
/**
 * Two-phase guard: authorize every configured scope before reserving the
 * estimate, so a rejected call never partially consumes budget. Settlement is
 * conservative: overruns always charge the difference, refunds never happen.
 */
export declare class BudgetGuard {
    #private;
    constructor(options: {
        store: CostBudgetStore;
        limits: CostBudgetLimits;
        clock?: () => Date;
    });
    authorize(input: {
        request: Pick<ModelGatewayRequest, 'requestId' | 'tenantId' | 'sessionId' | 'agentId'>;
        estimatedCostUsd: number;
    }): BudgetAuthorization;
    settle(input: {
        reservedKeys: readonly string[];
        estimatedCostUsd: number;
        actualCostUsd: number;
    }): void;
}
