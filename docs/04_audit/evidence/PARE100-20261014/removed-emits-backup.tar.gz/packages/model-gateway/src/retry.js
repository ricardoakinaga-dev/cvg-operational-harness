import { ModelGatewayError } from "./errors.js";
export const DEFAULT_RETRY_POLICY = {
    maxRetries: 2,
    baseDelayMs: 250,
    maxDelayMs: 4_000,
    jitterRatio: 0.2
};
/**
 * Bounded exponential backoff with proportional jitter. Deterministic when the
 * injected random source is deterministic.
 */
export function computeRetryDelayMs({ attempt, policy, random }) {
    const exponent = Math.max(0, attempt - 1);
    const raw = policy.baseDelayMs * 2 ** exponent;
    const bounded = Math.min(raw, policy.maxDelayMs);
    const jitter = bounded * policy.jitterRatio * clampUnit(random());
    return Math.round(bounded - bounded * policy.jitterRatio + jitter);
}
function clampUnit(value) {
    if (!Number.isFinite(value))
        return 0;
    if (value <= 0)
        return 0;
    if (value >= 1)
        return 1;
    return value;
}
export function isRetryable(error) {
    return error instanceof ModelGatewayError && error.retryable;
}
//# sourceMappingURL=retry.js.map