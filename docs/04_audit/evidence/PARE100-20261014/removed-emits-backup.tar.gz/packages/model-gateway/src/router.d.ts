import { type DataClassification } from '@cvg/shared';
import { type ModelProfile, type ModelProfileName } from './contracts.ts';
export interface ModelRoutingRule {
    task: string;
    profile: ModelProfileName;
}
export interface ModelRoutingOptions {
    rules?: ModelRoutingRule[];
    /** Explicit opt-in only; never substitute model location silently. */
    allowLocalSubstitution?: boolean;
    allowFallback?: boolean;
}
export interface ModelRoute {
    profile: ModelProfile;
    substitutedProfile?: ModelProfileName;
    ruleTask?: string;
}
export declare class ModelRouter {
    #private;
    constructor(profiles: Partial<Record<ModelProfileName, ModelProfile>>, options?: ModelRoutingOptions);
    get allowFallback(): boolean;
    profile(name: ModelProfileName): ModelProfile | undefined;
    resolve(input: {
        requestedProfile: ModelProfileName;
        task?: string;
        dataClassification: DataClassification;
    }): ModelRoute;
    fallbackFor(profile: ModelProfile): ModelProfile | undefined;
}
