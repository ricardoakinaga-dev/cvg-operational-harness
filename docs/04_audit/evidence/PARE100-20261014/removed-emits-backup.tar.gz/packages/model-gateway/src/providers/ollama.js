import { z } from 'zod';
import { evaluateOutboundUrl, fetchWithSsrfGuard, isLoopbackHostname } from '@cvg/shared';
import { ModelProviderError } from "../errors.js";
import { assertResponseSize, networkError, providerHttpError } from "./http-errors.js";
import { fetchWithResolvedAddress } from "./ssrf-node.js";
import { DEFAULT_MAX_RESPONSE_BYTES, combineTimeoutSignal } from "./openai-compatible.js";
const OllamaResponseSchema = z.object({
    message: z.object({ content: z.string().optional() }).optional(),
    response: z.string().optional(),
    prompt_eval_count: z.number().int().nonnegative().optional(),
    eval_count: z.number().int().nonnegative().optional(),
    done: z.boolean().optional()
});
/**
 * Local Ollama provider. Defaults to loopback; remote deployment must provide
 * an explicit base URL and API key. Never exposed publicly by default.
 */
export class OllamaProvider {
    id;
    location = 'local';
    models;
    #baseUrl;
    #model;
    #apiKey;
    #fetch;
    #maxResponseBytes;
    #allowedHosts;
    #allowHttp;
    #allowPrivateNetworks;
    #dnsLookup;
    #boundFetch;
    constructor(options) {
        const baseUrl = (options.baseUrl ?? 'http://127.0.0.1:11434')
            .trim()
            .replace(/\/+$/, '');
        const parsedBaseUrl = new URL(baseUrl);
        const allowPrivateNetworks = options.allowPrivateNetworks ?? false;
        const allowHttp = parsedBaseUrl.protocol === 'http:' &&
            allowPrivateNetworks &&
            isLoopbackHostname(parsedBaseUrl.hostname);
        const guard = evaluateOutboundUrl(baseUrl, {
            allowedHosts: [new URL(baseUrl).hostname.toLowerCase()],
            allowedProtocols: allowHttp ? ['https:', 'http:'] : ['https:'],
            allowPrivateNetworks
        });
        if (!guard.allowed) {
            throw new ModelProviderError(options.id ?? 'ollama', 'invalid_request', `Ollama base URL rejected: ${guard.reason}`);
        }
        this.id = options.id ?? 'ollama';
        this.models = [options.model];
        this.#baseUrl = baseUrl;
        this.#model = options.model;
        if (options.apiKey !== undefined)
            this.#apiKey = options.apiKey;
        this.#fetch = options.fetchImpl ?? globalThis.fetch;
        this.#maxResponseBytes =
            options.maxResponseBytes ?? DEFAULT_MAX_RESPONSE_BYTES;
        this.#allowedHosts = [parsedBaseUrl.hostname.toLowerCase()];
        this.#allowHttp = allowHttp;
        this.#allowPrivateNetworks = allowPrivateNetworks;
        this.#dnsLookup = options.dnsLookup;
        this.#boundFetch = options.fetchImpl ? undefined : fetchWithResolvedAddress;
    }
    async execute(request) {
        const endpoint = `${this.#baseUrl}/api/chat`;
        const signal = combineTimeoutSignal(request.signal, request.timeoutMs);
        const messages = [
            ...(request.input.system
                ? [{ role: 'system', content: request.input.system }]
                : []),
            ...request.input.messages
        ];
        const body = {
            model: this.#model,
            messages,
            stream: false,
            options: {
                temperature: request.temperature,
                num_predict: request.maxTokens
            }
        };
        if (request.structuredSchemaName) {
            body.format = 'json';
        }
        let response;
        try {
            const fetchImpl = (url, requestInit) => this.#fetch(url, requestInit);
            const deps = this.#boundFetch
                ? {
                    ...(this.#dnsLookup ? { dnsLookup: this.#dnsLookup } : {}),
                    boundFetchImpl: this.#boundFetch
                }
                : { ...(this.#dnsLookup ? { dnsLookup: this.#dnsLookup } : {}) };
            response = await fetchWithSsrfGuard(fetchImpl, endpoint, {
                method: 'POST',
                headers: {
                    'content-type': 'application/json',
                    ...(this.#apiKey ? { authorization: `Bearer ${this.#apiKey}` } : {})
                },
                body: JSON.stringify(body),
                signal,
                redirect: 'manual'
            }, {
                allowedHosts: this.#allowedHosts,
                allowedProtocols: this.#allowHttp ? ['https:', 'http:'] : ['https:'],
                allowPrivateNetworks: this.#allowPrivateNetworks,
                allowLoopbackOnly: this.#allowHttp,
                maxRedirects: 0
            }, deps);
        }
        catch (error) {
            if (error instanceof Error && error.name === 'UnsafeUrlError') {
                throw new ModelProviderError(this.id, 'invalid_request', `Ollama endpoint rejected: ${error.message}`);
            }
            throw networkError(this.id, error);
        }
        if (!response.ok) {
            throw providerHttpError(this.id, response.status);
        }
        let rawBody;
        try {
            rawBody = await response.text();
        }
        catch (error) {
            throw networkError(this.id, error);
        }
        assertResponseSize(this.id, rawBody, this.#maxResponseBytes);
        let parsedJson;
        try {
            parsedJson = JSON.parse(rawBody);
        }
        catch {
            throw new ModelProviderError(this.id, 'malformed_response', 'Ollama returned invalid JSON');
        }
        const parsed = OllamaResponseSchema.safeParse(parsedJson);
        if (!parsed.success) {
            throw new ModelProviderError(this.id, 'malformed_response', 'Ollama response did not match the expected contract');
        }
        const text = parsed.data.message?.content ?? parsed.data.response ?? '';
        return {
            text,
            usage: {
                inputTokens: parsed.data.prompt_eval_count ?? 0,
                outputTokens: parsed.data.eval_count ?? 0
            },
            providerId: this.id,
            model: this.#model,
            externalCall: false
        };
    }
}
//# sourceMappingURL=ollama.js.map