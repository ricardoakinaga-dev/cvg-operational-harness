export interface RetryPolicy {
    maxRetries: number;
    baseDelayMs: number;
    maxDelayMs: number;
    jitterRatio: number;
}
export declare const DEFAULT_RETRY_POLICY: RetryPolicy;
export interface RetryDelayInput {
    attempt: number;
    policy: RetryPolicy;
    random: () => number;
}
/**
 * Bounded exponential backoff with proportional jitter. Deterministic when the
 * injected random source is deterministic.
 */
export declare function computeRetryDelayMs({ attempt, policy, random }: RetryDelayInput): number;
export declare function isRetryable(error: unknown): boolean;
