import { z } from 'zod';
import { DataClassificationSchema } from '@cvg/shared';
export const ModelProfileNameSchema = z.enum([
    'fast',
    'balanced',
    'reasoning',
    'local',
    'critical-review'
]);
export const ModelLocationSchema = z.enum(['external', 'local']);
export const ModelMessageSchema = z.object({
    role: z.enum(['system', 'user', 'assistant']),
    content: z.string().min(1).max(32_000)
});
export const ModelInputSchema = z
    .object({
    system: z.string().max(16_000).optional(),
    messages: z.array(ModelMessageSchema).min(1).max(64)
})
    .strict();
/**
 * Serializable subset of a gateway request. Structured output contracts carry
 * live zod schemas and are validated at runtime, outside this wire schema.
 */
export const ModelGatewayRequestSchema = z
    .object({
    requestId: z.string().min(8).max(120),
    tenantId: z.string().regex(/^tenant_[0-9a-f-]{36}$/),
    agentId: z.string().min(1).max(120).optional(),
    agentVersionId: z.string().min(1).max(120).optional(),
    sessionId: z.string().min(1).max(120).optional(),
    conversationId: z.string().min(1).max(120).optional(),
    correlationId: z.string().min(8).max(120),
    promptId: z.string().min(1).max(120),
    promptVersion: z.string().min(1).max(60),
    promptSha256: z
        .string()
        .regex(/^[0-9a-f]{64}$/)
        .optional(),
    policyVersion: z.string().min(1).max(120).optional(),
    modelProfile: ModelProfileNameSchema,
    task: z.string().min(1).max(120).optional(),
    dataClassification: DataClassificationSchema.default('INTERNAL'),
    input: ModelInputSchema,
    timeoutMs: z.number().int().min(100).max(120_000).optional(),
    maxTokens: z.number().int().min(1).max(32_000).optional(),
    maxCostUsd: z.number().min(0).max(1000).optional(),
    estimatedCostUsd: z.number().min(0).max(1000).optional(),
    metadata: z
        .record(z.string().min(1).max(64), z.string().max(256))
        .optional()
})
    .strict();
//# sourceMappingURL=contracts.js.map