import { request as httpRequest } from 'node:http';
import { request as httpsRequest } from 'node:https';
import { isIP } from 'node:net';
/**
 * Node-only connect-bound transport for model providers. Keep the provider
 * hostname as HTTP authority/TLS SNI while pinning lookup to the address
 * already accepted by the shared SSRF guard.
 */
export async function fetchWithResolvedAddress(rawUrl, init, resolvedAddresses) {
    const url = new URL(rawUrl);
    const address = resolvedAddresses[0];
    if (!address)
        throw new Error('No resolved address available');
    const hostname = stripBrackets(url.hostname);
    const family = isIP(stripBrackets(address));
    if (family === 0)
        throw new Error('Resolved address is not an IP literal');
    if (url.protocol !== 'http:' && url.protocol !== 'https:') {
        throw new Error(`Unsupported transport protocol: ${url.protocol}`);
    }
    const body = await encodeBody(init.body);
    const headers = toHeaders(init.headers);
    headers.delete('host');
    headers.set('host', url.host);
    if (body !== undefined && !headers.has('content-length')) {
        headers.set('content-length', String(body.byteLength));
    }
    const requestOptions = {
        agent: false,
        hostname,
        port: url.port || undefined,
        path: `${url.pathname || '/'}${url.search}`,
        method: typeof init.method === 'string' ? init.method : 'GET',
        headers: Object.fromEntries(headers.entries()),
        lookup: pinnedLookup(stripBrackets(address)),
        ...(url.protocol === 'https:' ? { servername: hostname } : {})
    };
    return new Promise((resolve, reject) => {
        let settled = false;
        const finish = (callback) => {
            if (settled)
                return;
            settled = true;
            callback();
        };
        const request = url.protocol === 'https:'
            ? httpsRequest(requestOptions, (response) => {
                void readResponse(response).then((result) => finish(() => resolve(result)), (error) => finish(() => reject(error)));
            })
            : httpRequest(requestOptions, (response) => {
                void readResponse(response).then((result) => finish(() => resolve(result)), (error) => finish(() => reject(error)));
            });
        request.once('error', (error) => finish(() => reject(error)));
        const signal = asAbortSignal(init.signal);
        const abort = () => {
            const reason = signal?.reason;
            const error = reason instanceof Error
                ? reason
                : new DOMException('Request aborted', 'AbortError');
            request.destroy(error);
        };
        if (signal) {
            if (signal.aborted) {
                abort();
            }
            else {
                signal.addEventListener('abort', abort, { once: true });
                request.once('close', () => signal.removeEventListener('abort', abort));
            }
        }
        request.end(body === undefined ? undefined : Buffer.from(body));
    });
}
function stripBrackets(value) {
    return value.replace(/^\[|\]$/g, '');
}
function pinnedLookup(address) {
    const family = isIP(address);
    if (family === 0)
        throw new Error('Resolved address is not an IP literal');
    return (_hostname, _options, callback) => callback(null, address, family);
}
function toHeaders(value) {
    const headers = new Headers();
    if (value instanceof Headers) {
        value.forEach((entry, name) => headers.set(name, entry));
        return headers;
    }
    if (Array.isArray(value)) {
        for (const entry of value) {
            if (Array.isArray(entry) && entry.length >= 2) {
                headers.set(String(entry[0]), String(entry[1]));
            }
        }
        return headers;
    }
    if (value && typeof value === 'object') {
        for (const [name, entry] of Object.entries(value)) {
            if (Array.isArray(entry)) {
                headers.set(name, entry.map(String).join(', '));
            }
            else if (entry !== undefined) {
                headers.set(name, String(entry));
            }
        }
    }
    return headers;
}
async function encodeBody(value) {
    if (value === undefined || value === null)
        return undefined;
    if (typeof value === 'string')
        return new TextEncoder().encode(value);
    if (value instanceof Uint8Array)
        return value;
    if (value instanceof ArrayBuffer)
        return new Uint8Array(value);
    if (ArrayBuffer.isView(value)) {
        return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
    }
    if (value instanceof URLSearchParams) {
        return new TextEncoder().encode(value.toString());
    }
    if (typeof Blob !== 'undefined' && value instanceof Blob) {
        return new Uint8Array(await value.arrayBuffer());
    }
    throw new Error('Unsupported request body for bound Node transport');
}
function asAbortSignal(value) {
    if (value &&
        typeof value === 'object' &&
        'aborted' in value &&
        'addEventListener' in value &&
        'removeEventListener' in value) {
        return value;
    }
    return undefined;
}
async function readResponse(response) {
    const chunks = [];
    for await (const chunk of response) {
        chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
    }
    const headers = new Headers();
    for (const [name, value] of Object.entries(response.headers)) {
        if (Array.isArray(value)) {
            for (const entry of value)
                headers.append(name, entry);
        }
        else if (value !== undefined) {
            headers.append(name, value);
        }
    }
    const status = response.statusCode;
    if (!status)
        throw new Error('Response did not include an HTTP status');
    return new Response(Buffer.concat(chunks), {
        status,
        statusText: response.statusMessage ?? '',
        headers
    });
}
//# sourceMappingURL=ssrf-node.js.map