export class InMemoryCostBudgetStore {
    #consumed = new Map();
    consumed(scopeKey) {
        return this.#consumed.get(scopeKey) ?? 0;
    }
    consume(scopeKey, amountUsd) {
        if (!Number.isFinite(amountUsd) || amountUsd <= 0)
            return;
        this.#consumed.set(scopeKey, this.consumed(scopeKey) + amountUsd);
    }
}
export function budgetScopeKeys(request, now) {
    const day = now.toISOString().slice(0, 10);
    return {
        request: `request:${request.requestId}`,
        session: request.sessionId
            ? `session:${request.tenantId}:${request.sessionId}`
            : null,
        tenant: `tenant:${request.tenantId}`,
        agent: request.agentId
            ? `agent:${request.tenantId}:${request.agentId}`
            : null,
        day: `day:${request.tenantId}:${day}`
    };
}
/**
 * Two-phase guard: authorize every configured scope before reserving the
 * estimate, so a rejected call never partially consumes budget. Settlement is
 * conservative: overruns always charge the difference, refunds never happen.
 */
export class BudgetGuard {
    #store;
    #limits;
    #clock;
    constructor(options) {
        this.#store = options.store;
        this.#limits = options.limits;
        this.#clock = options.clock ?? (() => new Date());
    }
    authorize(input) {
        const keys = budgetScopeKeys(input.request, this.#clock());
        const estimate = Number.isFinite(input.estimatedCostUsd)
            ? Math.max(0, input.estimatedCostUsd)
            : 0;
        const scopes = [
            'request',
            'session',
            'tenant',
            'agent',
            'day'
        ];
        for (const scope of scopes) {
            const limit = this.#limits[scope];
            const key = keys[scope];
            if (limit === undefined || key === null)
                continue;
            const spent = this.#store.consumed(key);
            if (spent + estimate > limit) {
                return {
                    allowed: false,
                    deniedScope: scope,
                    deniedKey: key,
                    spentUsd: spent,
                    limitUsd: limit,
                    reservedKeys: []
                };
            }
        }
        const reservedKeys = [];
        for (const scope of scopes) {
            const key = keys[scope];
            if (key === null)
                continue;
            if (this.#limits[scope] === undefined)
                continue;
            this.#store.consume(key, estimate);
            reservedKeys.push(key);
        }
        return { allowed: true, reservedKeys };
    }
    settle(input) {
        const delta = input.actualCostUsd - input.estimatedCostUsd;
        if (!Number.isFinite(delta) || delta <= 0)
            return;
        for (const key of input.reservedKeys) {
            this.#store.consume(key, delta);
        }
    }
}
//# sourceMappingURL=budget.js.map