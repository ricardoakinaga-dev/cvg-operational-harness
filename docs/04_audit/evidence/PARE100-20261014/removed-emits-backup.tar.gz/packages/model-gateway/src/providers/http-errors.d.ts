import { ModelProviderError, type ModelProviderErrorKind } from '../errors.ts';
export declare function mapHttpStatusToKind(status: number): ModelProviderErrorKind;
export declare function providerHttpError(providerId: string, status: number): ModelProviderError;
export declare function networkError(providerId: string, error: unknown): ModelProviderError;
export declare function assertResponseSize(providerId: string, body: string, maxBytes: number): void;
