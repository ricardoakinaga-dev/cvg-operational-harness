export class CircuitOpenError extends Error {
    key;
    retryAt;
    constructor(key, retryAt) {
        super(`Circuit breaker is open for ${key}`);
        this.name = 'CircuitOpenError';
        this.key = key;
        this.retryAt = retryAt;
    }
}
/**
 * Per provider/model circuit breaker with CLOSED -> OPEN -> HALF_OPEN
 * transitions. HALF_OPEN admits a single probe at a time.
 */
export class CircuitBreaker {
    #failureThreshold;
    #openMs;
    #halfOpenSuccesses;
    #clock;
    #onTransition;
    #entries = new Map();
    constructor(options = {}) {
        this.#failureThreshold = options.failureThreshold ?? 5;
        this.#openMs = options.openMs ?? 30_000;
        this.#halfOpenSuccesses = options.halfOpenSuccesses ?? 2;
        this.#clock = options.clock ?? (() => Date.now());
        if (options.onTransition)
            this.#onTransition = options.onTransition;
    }
    state(key) {
        const entry = this.#entry(key);
        this.#refresh(entry, key);
        return entry.state;
    }
    canRequest(key) {
        const entry = this.#entry(key);
        this.#refresh(entry, key);
        if (entry.state === 'CLOSED')
            return true;
        if (entry.state === 'OPEN')
            return false;
        if (entry.halfOpenInFlight)
            return false;
        entry.halfOpenInFlight = true;
        return true;
    }
    onSuccess(key) {
        const entry = this.#entry(key);
        this.#refresh(entry, key);
        if (entry.state === 'HALF_OPEN') {
            entry.successes += 1;
            entry.halfOpenInFlight = false;
            if (entry.successes >= this.#halfOpenSuccesses) {
                entry.failures = 0;
                entry.successes = 0;
                this.#transition(entry, key, 'CLOSED');
            }
            return;
        }
        entry.failures = 0;
        entry.halfOpenInFlight = false;
    }
    onFailure(key) {
        const entry = this.#entry(key);
        this.#refresh(entry, key);
        entry.halfOpenInFlight = false;
        if (entry.state === 'HALF_OPEN') {
            entry.failures = this.#failureThreshold;
            entry.successes = 0;
            entry.openedAt = this.#clock();
            this.#transition(entry, key, 'OPEN');
            return;
        }
        entry.failures += 1;
        if (entry.failures >= this.#failureThreshold) {
            entry.openedAt = this.#clock();
            this.#transition(entry, key, 'OPEN');
        }
    }
    snapshot() {
        const result = {};
        for (const [key, entry] of this.#entries) {
            this.#refresh(entry, key);
            result[key] = entry.state;
        }
        return result;
    }
    #entry(key) {
        let entry = this.#entries.get(key);
        if (!entry) {
            entry = {
                state: 'CLOSED',
                failures: 0,
                successes: 0,
                openedAt: 0,
                halfOpenInFlight: false
            };
            this.#entries.set(key, entry);
        }
        return entry;
    }
    #refresh(entry, key) {
        if (entry.state === 'OPEN' &&
            this.#clock() - entry.openedAt >= this.#openMs) {
            entry.state = 'HALF_OPEN';
            entry.successes = 0;
            entry.halfOpenInFlight = false;
            this.#emit({ key, from: 'OPEN', to: 'HALF_OPEN', at: this.#clock() });
        }
    }
    #transition(entry, key, to) {
        const from = entry.state;
        entry.state = to;
        if (to === 'OPEN') {
            entry.openedAt = this.#clock();
        }
        this.#emit({ key, from, to, at: this.#clock() });
    }
    #emit(transition) {
        this.#onTransition?.(transition);
    }
}
//# sourceMappingURL=circuit-breaker.js.map