/**
 * Controlled deterministic provider. Used by tests, evals and dry runs; it
 * never performs network calls and always reports externalCall: false.
 */
export class DeterministicModelProvider {
    id;
    location = 'local';
    models;
    #latencyMs;
    #respond;
    constructor(options = {}) {
        this.id = options.id ?? 'deterministic';
        this.models = [options.model ?? 'deterministic-v1'];
        this.#latencyMs = Math.max(0, options.latencyMs ?? 0);
        this.#respond =
            options.respond ??
                ((request) => ({
                    text: `deterministic:${request.model}`,
                    usage: { inputTokens: 0, outputTokens: 0 },
                    providerId: this.id,
                    model: request.model,
                    externalCall: false,
                    finishReason: 'stop'
                }));
    }
    async execute(request) {
        if (this.#latencyMs > 0) {
            await abortableDelay(this.#latencyMs, request.signal);
        }
        if (request.signal.aborted) {
            throw abortError();
        }
        return this.#respond(request);
    }
}
function abortError() {
    const error = new Error('Provider call aborted');
    error.name = 'AbortError';
    return error;
}
function abortableDelay(ms, signal) {
    return new Promise((resolve, reject) => {
        if (signal.aborted) {
            reject(abortError());
            return;
        }
        const timer = setTimeout(() => {
            signal.removeEventListener('abort', onAbort);
            resolve();
        }, ms);
        function onAbort() {
            clearTimeout(timer);
            reject(abortError());
        }
        signal.addEventListener('abort', onAbort, { once: true });
    });
}
//# sourceMappingURL=deterministic.js.map