export declare const ModelGatewayErrorCodes: {
    readonly invalid_request: "invalid_request";
    readonly prompt_unknown: "prompt_unknown";
    readonly prompt_revoked: "prompt_revoked";
    readonly prompt_hash_mismatch: "prompt_hash_mismatch";
    readonly profile_unknown: "profile_unknown";
    readonly provider_unknown: "provider_unknown";
    readonly policy_denied: "policy_denied";
    readonly budget_exceeded: "budget_exceeded";
    readonly circuit_open: "circuit_open";
    readonly provider_timeout: "provider_timeout";
    readonly provider_unavailable: "provider_unavailable";
    readonly provider_rate_limited: "provider_rate_limited";
    readonly provider_auth_failed: "provider_auth_failed";
    readonly provider_invalid_request: "provider_invalid_request";
    readonly provider_connection_reset: "provider_connection_reset";
    readonly provider_response_too_large: "provider_response_too_large";
    readonly provider_malformed_response: "provider_malformed_response";
    readonly schema_invalid: "schema_invalid";
    readonly cancelled: "cancelled";
    readonly internal_error: "internal_error";
};
export type ModelGatewayErrorCode = (typeof ModelGatewayErrorCodes)[keyof typeof ModelGatewayErrorCodes];
export declare class ModelGatewayError extends Error {
    readonly code: ModelGatewayErrorCode;
    readonly retryable: boolean;
    readonly status?: number;
    constructor(code: ModelGatewayErrorCode, message: string, options?: {
        retryable?: boolean;
        status?: number;
    });
}
export type ModelProviderErrorKind = 'timeout' | 'rate_limited' | 'unavailable' | 'auth' | 'invalid_request' | 'connection' | 'response_too_large' | 'malformed_response' | 'cancelled' | 'internal';
export declare class ModelProviderError extends Error {
    readonly kind: ModelProviderErrorKind;
    readonly status?: number;
    readonly providerId: string;
    constructor(providerId: string, kind: ModelProviderErrorKind, message: string, status?: number);
    get retryable(): boolean;
}
export declare function toGatewayError(error: unknown, providerId?: string): ModelGatewayError;
