export type CircuitState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';
export interface CircuitBreakerOptions {
    failureThreshold?: number;
    openMs?: number;
    halfOpenSuccesses?: number;
    clock?: () => number;
    onTransition?: (transition: CircuitTransition) => void;
}
export interface CircuitTransition {
    key: string;
    from: CircuitState;
    to: CircuitState;
    at: number;
}
export declare class CircuitOpenError extends Error {
    readonly key: string;
    readonly retryAt: number;
    constructor(key: string, retryAt: number);
}
/**
 * Per provider/model circuit breaker with CLOSED -> OPEN -> HALF_OPEN
 * transitions. HALF_OPEN admits a single probe at a time.
 */
export declare class CircuitBreaker {
    #private;
    constructor(options?: CircuitBreakerOptions);
    state(key: string): CircuitState;
    canRequest(key: string): boolean;
    onSuccess(key: string): void;
    onFailure(key: string): void;
    snapshot(): Record<string, CircuitState>;
}
