import type { EgressDns } from '@cvg/shared';
import type { ModelProvider, ProviderRequest, ProviderResult } from '../contracts.ts';
import { type FetchLike } from './openai-compatible.ts';
export interface OllamaProviderOptions {
    id?: string;
    baseUrl?: string;
    model: string;
    apiKey?: string;
    fetchImpl?: FetchLike;
    maxResponseBytes?: number;
    allowHttp?: boolean;
    /**
     * AUD19-007 — explicit opt-in for loopback/private networks (local
     * homologation). Default false: private/reserved addresses are denied.
     */
    allowPrivateNetworks?: boolean;
    /** AUD19-007 — injectable DNS for the composed egress guard (tests). */
    dnsLookup?: EgressDns['lookup'];
}
/**
 * Local Ollama provider. Defaults to loopback; remote deployment must provide
 * an explicit base URL and API key. Never exposed publicly by default.
 */
export declare class OllamaProvider implements ModelProvider {
    #private;
    readonly id: string;
    readonly location: "local";
    readonly models: readonly string[];
    constructor(options: OllamaProviderOptions);
    execute(request: ProviderRequest): Promise<ProviderResult>;
}
