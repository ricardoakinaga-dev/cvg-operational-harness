import { z } from 'zod';
export declare const ModelProfileNameSchema: z.ZodEnum<{
    fast: "fast";
    balanced: "balanced";
    reasoning: "reasoning";
    local: "local";
    "critical-review": "critical-review";
}>;
export type ModelProfileName = z.infer<typeof ModelProfileNameSchema>;
export declare const ModelLocationSchema: z.ZodEnum<{
    local: "local";
    external: "external";
}>;
export type ModelLocation = z.infer<typeof ModelLocationSchema>;
export declare const ModelMessageSchema: z.ZodObject<{
    role: z.ZodEnum<{
        system: "system";
        user: "user";
        assistant: "assistant";
    }>;
    content: z.ZodString;
}, z.core.$strip>;
export type ModelMessage = z.infer<typeof ModelMessageSchema>;
export declare const ModelInputSchema: z.ZodObject<{
    system: z.ZodOptional<z.ZodString>;
    messages: z.ZodArray<z.ZodObject<{
        role: z.ZodEnum<{
            system: "system";
            user: "user";
            assistant: "assistant";
        }>;
        content: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strict>;
export type ModelInput = z.infer<typeof ModelInputSchema>;
/**
 * Serializable subset of a gateway request. Structured output contracts carry
 * live zod schemas and are validated at runtime, outside this wire schema.
 */
export declare const ModelGatewayRequestSchema: z.ZodObject<{
    requestId: z.ZodString;
    tenantId: z.ZodString;
    agentId: z.ZodOptional<z.ZodString>;
    agentVersionId: z.ZodOptional<z.ZodString>;
    sessionId: z.ZodOptional<z.ZodString>;
    conversationId: z.ZodOptional<z.ZodString>;
    correlationId: z.ZodString;
    promptId: z.ZodString;
    promptVersion: z.ZodString;
    promptSha256: z.ZodOptional<z.ZodString>;
    policyVersion: z.ZodOptional<z.ZodString>;
    modelProfile: z.ZodEnum<{
        fast: "fast";
        balanced: "balanced";
        reasoning: "reasoning";
        local: "local";
        "critical-review": "critical-review";
    }>;
    task: z.ZodOptional<z.ZodString>;
    dataClassification: z.ZodDefault<z.ZodEnum<{
        PUBLIC: "PUBLIC";
        INTERNAL: "INTERNAL";
        CONFIDENTIAL: "CONFIDENTIAL";
        CLINICAL: "CLINICAL";
        FINANCIAL: "FINANCIAL";
        CREDENTIAL: "CREDENTIAL";
    }>>;
    input: z.ZodObject<{
        system: z.ZodOptional<z.ZodString>;
        messages: z.ZodArray<z.ZodObject<{
            role: z.ZodEnum<{
                system: "system";
                user: "user";
                assistant: "assistant";
            }>;
            content: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strict>;
    timeoutMs: z.ZodOptional<z.ZodNumber>;
    maxTokens: z.ZodOptional<z.ZodNumber>;
    maxCostUsd: z.ZodOptional<z.ZodNumber>;
    estimatedCostUsd: z.ZodOptional<z.ZodNumber>;
    metadata: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
}, z.core.$strict>;
export type ModelGatewayRequest = z.infer<typeof ModelGatewayRequestSchema>;
export interface StructuredOutputContract<T = unknown> {
    schemaName: string;
    schema: z.ZodType<T>;
    /** Defaults to true: invalid structured output always fails closed. */
    failClosed?: boolean;
}
export interface ProviderUsage {
    inputTokens: number;
    outputTokens: number;
}
export interface ProviderRequest {
    requestId: string;
    tenantId: string;
    correlationId: string;
    model: string;
    input: ModelInput;
    temperature: number;
    maxTokens: number;
    promptSha256: string;
    structuredSchemaName?: string;
    signal: AbortSignal;
    timeoutMs: number;
    metadata?: Record<string, string>;
}
export interface ProviderResult {
    text: string;
    usage: ProviderUsage;
    providerId: string;
    model: string;
    externalCall: boolean;
    finishReason?: string;
}
export interface ModelProvider {
    readonly id: string;
    readonly location: ModelLocation;
    readonly models: readonly string[];
    execute(request: ProviderRequest): Promise<ProviderResult>;
}
export interface ModelProfile {
    name: ModelProfileName;
    providerId: string;
    model: string;
    location: ModelLocation;
    temperature: number;
    maxTokens: number;
    timeoutMs: number;
    maxCostUsd: number;
    estimatedCostUsd: number;
    maxRetries: number;
    pricing: {
        inputPer1kUsd: number;
        outputPer1kUsd: number;
    };
    fallbackProfile?: ModelProfileName;
}
export interface ModelResult<TStructured = unknown> {
    requestId: string;
    tenantId: string;
    correlationId: string;
    providerId: string;
    model: string;
    profile: ModelProfileName;
    output: {
        text: string;
        structured?: TStructured;
    };
    usage: ProviderUsage;
    costUsd: number;
    attempts: number;
    latencyMs: number;
    promptSha256: string;
    createdAt: string;
    fallbackUsed: boolean;
    substitutedProfile?: ModelProfileName;
}
export type ModelGatewayEventType = 'model.call.started' | 'model.call.completed' | 'model.call.failed' | 'model.retry.scheduled' | 'model.budget.denied' | 'model.routing.substituted' | 'model.routing.fallback' | 'model.circuit.transition';
export interface ModelGatewayEvent {
    type: ModelGatewayEventType;
    requestId: string;
    tenantId: string;
    correlationId: string;
    providerId?: string;
    model?: string;
    profile?: ModelProfileName;
    code?: string;
    attempt?: number;
    delayMs?: number;
    costUsd?: number;
    circuitState?: string;
    detail?: string;
}
