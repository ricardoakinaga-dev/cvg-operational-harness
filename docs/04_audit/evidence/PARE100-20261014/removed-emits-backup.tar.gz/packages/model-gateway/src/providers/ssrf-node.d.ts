/**
 * Node-only connect-bound transport for model providers. Keep the provider
 * hostname as HTTP authority/TLS SNI while pinning lookup to the address
 * already accepted by the shared SSRF guard.
 */
export declare function fetchWithResolvedAddress(rawUrl: string, init: Record<string, unknown>, resolvedAddresses: readonly string[]): Promise<Response>;
