import { type TenantId } from '@cvg/platform';
import { type AuditEvidenceCheckpointCreateInput, type AuditEvidenceCheckpointRecord, type AuditEvidenceCheckpointStatus } from '../audit-evidence-checkpoint.ts';
import type { InMemoryDatabase } from '../db.ts';
import type { AuditEventRecord, AuditEvidenceFilters, AuditEvidencePage, AuditEvidenceQuery, AuditEvidenceSummary } from '../schema.ts';
export declare class AuditRepository {
    private readonly db;
    constructor(db: InMemoryDatabase);
    append(input: Omit<AuditEventRecord, 'id' | 'createdAt'>, rawTenantId?: TenantId): AuditEventRecord;
    listByCorrelation(correlationId: string, rawTenantId?: TenantId): AuditEventRecord[];
    listBySession(sessionId: string, rawTenantId?: TenantId): AuditEventRecord[];
    listEvidence(query: AuditEvidenceQuery, rawTenantId?: TenantId): AuditEvidencePage;
    summarizeEvidence(filters?: AuditEvidenceFilters, rawTenantId?: TenantId): AuditEvidenceSummary;
    listAuditEventsByIds(rawIds: string[], rawTenantId?: TenantId): AuditEventRecord[];
    createAuditEvidenceCheckpoint(rawInput: AuditEvidenceCheckpointCreateInput, rawCreatedBy: string, rawTenantId?: TenantId): AuditEvidenceCheckpointRecord;
    getAuditEvidenceCheckpoint(rawId: string, rawTenantId?: TenantId): AuditEvidenceCheckpointRecord | null;
    listAuditEvidenceCheckpoints(rawTenantId?: TenantId): AuditEvidenceCheckpointRecord[];
    transitionAuditEvidenceCheckpoint(rawId: string, rawStatus: AuditEvidenceCheckpointStatus, rawUpdatedBy: string, rawExpectedStatus: AuditEvidenceCheckpointStatus, rawTenantId?: TenantId): AuditEvidenceCheckpointRecord | null;
    private filterEvidence;
    private eventBelongsToTenant;
}
export declare function summarizeAuditEvents(events: AuditEventRecord[]): AuditEvidenceSummary;
export declare function auditEventMatches(event: AuditEventRecord, filters: AuditEvidenceFilters): boolean;
