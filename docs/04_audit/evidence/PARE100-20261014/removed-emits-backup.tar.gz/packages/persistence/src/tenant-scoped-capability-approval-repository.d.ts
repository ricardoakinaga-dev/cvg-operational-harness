import { type CapabilityApprovalAuthority, type CapabilityApprovalIssueInput, type CapabilityApprovalRecord, type CapabilityApprovalVerificationInput, type TenantId } from '@cvg/platform';
import { type PostgresCapabilityApprovalRepositoryOptions } from './platform-approval-repository.ts';
import { type PostgresPoolLike } from './tenant-scoped-postgres.ts';
/**
 * Binds every approval operation to a checked-out tenant connection. In
 * particular, verifyAndConsume runs its whole transaction on that one
 * connection, so a pool cannot split BEGIN/SELECT/UPDATE/COMMIT.
 */
export declare class TenantScopedPostgresCapabilityApprovalRepository implements CapabilityApprovalAuthority {
    private readonly pool;
    private readonly options;
    constructor(pool: PostgresPoolLike, options?: PostgresCapabilityApprovalRepositoryOptions);
    issue(input: CapabilityApprovalIssueInput): Promise<CapabilityApprovalRecord>;
    verifyAndConsume(input: CapabilityApprovalVerificationInput): Promise<CapabilityApprovalRecord | null>;
    revoke(approvalId: string, issuer: string, tenantId?: TenantId): Promise<boolean>;
    get(approvalId: string, tenantId?: TenantId): Promise<CapabilityApprovalRecord | null>;
}
