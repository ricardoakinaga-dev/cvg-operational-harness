import { type TenantId } from '@cvg/platform';
import { z } from 'zod';
import type { AuditEventRecord, AuditEvidenceFilters } from './schema.ts';
export declare const AuditEvidenceCheckpointIdSchema: z.ZodString;
export type AuditEvidenceCheckpointId = z.infer<typeof AuditEvidenceCheckpointIdSchema>;
export declare const AuditEvidenceCheckpointStatusSchema: z.ZodEnum<{
    SEALED: "SEALED";
    ARCHIVED: "ARCHIVED";
}>;
export type AuditEvidenceCheckpointStatus = z.infer<typeof AuditEvidenceCheckpointStatusSchema>;
export declare const AuditEvidenceCheckpointFiltersSchema: z.ZodObject<{
    sessionId: z.ZodOptional<z.ZodString>;
    correlationId: z.ZodOptional<z.ZodString>;
    type: z.ZodOptional<z.ZodEnum<{
        handoff: "handoff";
        approval_decision: "approval_decision";
        tool_call: "tool_call";
        safety_event: "safety_event";
        integration_event: "integration_event";
        policy_decision: "policy_decision";
    }>>;
    actorId: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type AuditEvidenceCheckpointFilters = z.infer<typeof AuditEvidenceCheckpointFiltersSchema>;
export declare const AuditEvidenceCheckpointCreateInputSchema: z.ZodObject<{
    eventIds: z.ZodArray<z.ZodString>;
    filters: z.ZodDefault<z.ZodObject<{
        sessionId: z.ZodOptional<z.ZodString>;
        correlationId: z.ZodOptional<z.ZodString>;
        type: z.ZodOptional<z.ZodEnum<{
            handoff: "handoff";
            approval_decision: "approval_decision";
            tool_call: "tool_call";
            safety_event: "safety_event";
            integration_event: "integration_event";
            policy_decision: "policy_decision";
        }>>;
        actorId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type AuditEvidenceCheckpointCreateInput = z.input<typeof AuditEvidenceCheckpointCreateInputSchema>;
export declare const AuditEvidenceCheckpointTransitionInputSchema: z.ZodObject<{
    status: z.ZodLiteral<"ARCHIVED">;
    expectedStatus: z.ZodLiteral<"SEALED">;
}, z.core.$strict>;
export type AuditEvidenceCheckpointTransitionInput = z.infer<typeof AuditEvidenceCheckpointTransitionInputSchema>;
export declare const AuditEvidenceCheckpointActorIdSchema: z.ZodString;
export interface AuditEvidenceCheckpointRecord {
    tenantId: TenantId;
    id: AuditEvidenceCheckpointId;
    filters: AuditEvidenceCheckpointFilters;
    eventIds: string[];
    eventCount: number;
    evidenceDigest: string;
    status: AuditEvidenceCheckpointStatus;
    createdBy: string;
    updatedBy: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare function createAuditEvidenceCheckpointId(): AuditEvidenceCheckpointId;
export declare function computeAuditEvidenceCheckpointDigest(rawTenantId: TenantId, rawInput: AuditEvidenceCheckpointCreateInput, events: AuditEventRecord[]): string;
export declare function cloneAuditEvidenceCheckpoint(checkpoint: AuditEvidenceCheckpointRecord): AuditEvidenceCheckpointRecord;
export declare function normalizeAuditEvidenceCheckpointFilters(filters: AuditEvidenceCheckpointFilters): AuditEvidenceFilters;
