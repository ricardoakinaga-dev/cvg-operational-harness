import { type CapabilityApprovalAuthority, type CapabilityApprovalIssueInput, type CapabilityApprovalRecord, type CapabilityApprovalVerificationInput, type TenantId } from '@cvg/platform';
import type { PostgresTransactionClient } from './postgres.ts';
export interface PostgresCapabilityApprovalRepositoryOptions {
    now?: () => Date;
}
export declare class PostgresCapabilityApprovalRepository implements CapabilityApprovalAuthority {
    private readonly client;
    private readonly now;
    constructor(client: PostgresTransactionClient, options?: PostgresCapabilityApprovalRepositoryOptions);
    issue(rawInput: CapabilityApprovalIssueInput): Promise<CapabilityApprovalRecord>;
    verifyAndConsume(rawInput: CapabilityApprovalVerificationInput): Promise<CapabilityApprovalRecord | null>;
    revoke(approvalId: string, issuer: string, tenantId?: TenantId): Promise<boolean>;
    get(approvalId: string, tenantId?: TenantId): Promise<CapabilityApprovalRecord | null>;
}
