import { type Channel } from '@cvg/shared';
import { type AgentId, type AgentVersionId, type HumanTakeoverEvent, type TenantId } from '@cvg/platform';
import type { InMemoryDatabase } from '../db.ts';
import type { OutboxEnqueueInput } from '../outbox.ts';
import type { ConversationPage, ConversationRecord, InboundRuntimeContext, MessageRecord, PaginationInput, SessionRecord } from '../schema.ts';
export declare class ConversationRepository {
    private readonly db;
    constructor(db: InMemoryDatabase);
    createWithSessionAndOutbox(input: Parameters<ConversationRepository['createWithSession']>[0], outboxInput: OutboxEnqueueInput): ReturnType<ConversationRepository['createWithSession']> & {
        outbox: import('../schema.ts').OutboxEventRecord;
    };
    findByExternalMessage(tenantId: TenantId, channel: Channel, externalMessageId: string): MessageRecord | null;
    createWithSession(input: {
        tenantId: TenantId;
        channel: Channel;
        senderRef: string;
        externalMessageId: string;
        body: string;
        conversationId?: string | undefined;
        sessionId?: string | undefined;
    }): {
        conversation: ConversationRecord;
        session: SessionRecord;
        message: MessageRecord;
    };
    bindSessionAgentVersion(rawTenantId: TenantId, sessionId: string, rawAgentId: AgentId, rawAgentVersionId: AgentVersionId): SessionRecord | null;
    appendOutboundMessage(input: {
        tenantId: TenantId;
        conversationId: string;
        externalMessageId: string;
        body: string;
    }): MessageRecord;
    markInboundRuntimeCompleted(messageId: string, tenantId: TenantId): boolean;
    findInboundRuntimeContext(tenantId: TenantId, conversationId: string, sessionId: string | null, messageId: string): InboundRuntimeContext | null;
    transitionTakeover(rawTenantId: TenantId, sessionId: string, event: HumanTakeoverEvent): SessionRecord | null;
    timeline(tenantId: TenantId, conversationId: string): {
        messages: MessageRecord[];
        sessions: SessionRecord[];
    };
    listPage(tenantId: TenantId, input: PaginationInput): ConversationPage;
    private toListItem;
}
