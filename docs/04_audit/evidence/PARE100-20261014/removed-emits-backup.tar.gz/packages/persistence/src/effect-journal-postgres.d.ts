import { type EffectAttemptRef, type EffectConfirmRef, type EffectFailRef, type EffectJournalPort, type EffectReconcileRef, type EffectRecord, type EffectReserveInput, type EffectReserveOutcome, type EffectUncertainRef } from '@cvg/agent-runtime';
import type { PostgresQueryable } from './postgres.ts';
export interface PostgresEffectJournalOptions {
    /** Repository-owned clock; callers cannot override transition decisions. */
    clock?: () => Date;
}
/**
 * PostgreSQL incarnation of `EffectJournalPort` (AAA-03 §7). It shares the
 * pure reservation/transition state machine with the in-memory and file
 * adapters, and persists every transition with an explicit
 * `UPDATE ... WHERE state AND revision AND attempt_id` compare-and-swap under
 * `FOR UPDATE`. The table is tenant-isolated by forced RLS, so callers must
 * set `cvg.tenant_id` on the connection (`withTenantContext`).
 *
 * The client must be one checked-out connection: the adapter issues
 * BEGIN/COMMIT and a `pg.Pool` may route statements to different connections.
 */
export declare class PostgresEffectJournal implements EffectJournalPort {
    #private;
    constructor(client: PostgresQueryable, options?: PostgresEffectJournalOptions);
    reserve(input: EffectReserveInput): Promise<EffectReserveOutcome>;
    markEffectStarted(ref: EffectAttemptRef): Promise<EffectRecord>;
    confirmEffect(ref: EffectConfirmRef): Promise<EffectRecord>;
    failEffect(ref: EffectFailRef): Promise<EffectRecord>;
    markUncertain(ref: EffectUncertainRef): Promise<EffectRecord>;
    get(tenantId: string, operationKey: string): Promise<EffectRecord | undefined>;
    releaseExpired(now: Date, ttlMs: number): Promise<number>;
    reconcile(ref: EffectReconcileRef): Promise<EffectRecord>;
}
