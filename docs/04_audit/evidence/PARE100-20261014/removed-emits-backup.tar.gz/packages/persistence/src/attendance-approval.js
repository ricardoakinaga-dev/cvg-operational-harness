"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateAttendanceDecision = validateAttendanceDecision;
exports.assertApprovalCreation = assertApprovalCreation;
exports.cloneAttendanceApproval = cloneAttendanceApproval;
exports.attendanceDecisionAudit = attendanceDecisionAudit;
const shared_1 = require("@cvg/shared");
function validateAttendanceDecision(input) {
    const parsed = shared_1.ResolveApprovalSchema.parse(input);
    const correlationId = shared_1.CorrelationIdSchema.parse(input.correlationId);
    (0, shared_1.requirePermission)(input.role, 'approval:decide');
    const normalized = {
        approvalRequestId: parsed.approvalRequestId,
        decision: parsed.decision,
        operatorId: parsed.operatorId,
        role: input.role,
        correlationId
    };
    if (parsed.note !== undefined)
        normalized.note = parsed.note;
    return normalized;
}
function assertApprovalCreation(request) {
    if (request.status !== 'pending' ||
        request.decidedBy !== null ||
        request.decidedAt !== null) {
        throw new shared_1.DomainError('invalid_action', 'Approval creation must be pending');
    }
}
function cloneAttendanceApproval(request) {
    return {
        ...request,
        createdAt: new Date(request.createdAt),
        decidedAt: request.decidedAt ? new Date(request.decidedAt) : null
    };
}
function attendanceDecisionAudit(request, input, tenantId) {
    return {
        ...(tenantId ? { tenantId } : {}),
        type: request.status === 'assumed' ? 'handoff' : 'approval_decision',
        actorType: input.role,
        actorId: input.operatorId,
        correlationId: input.correlationId,
        policyVersion: 'api-runtime-v1',
        payload: {
            sessionId: request.sessionId,
            approvalRequestId: request.id,
            status: request.status,
            ...(tenantId ? { tenantId } : {}),
            effect: request.status === 'assumed' ? 'handoff_only' : 'approval_state_only'
        }
    };
}
//# sourceMappingURL=attendance-approval.js.map