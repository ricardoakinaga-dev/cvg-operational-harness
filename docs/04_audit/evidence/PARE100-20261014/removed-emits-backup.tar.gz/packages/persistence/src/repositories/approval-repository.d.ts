import { type TenantId } from '@cvg/platform';
import { InMemoryDatabase } from '../db.ts';
import type { ApprovalRequestRecord } from '../schema.ts';
import { type AttendanceApprovalDecision } from '../attendance-approval.ts';
export declare class ApprovalRepository {
    private readonly db;
    constructor(db: InMemoryDatabase);
    save(request: ApprovalRequestRecord, rawTenantId?: TenantId): ApprovalRequestRecord;
    decideWithAudit(input: AttendanceApprovalDecision, rawTenantId?: TenantId): ApprovalRequestRecord;
    findById(id: string, rawTenantId?: TenantId): ApprovalRequestRecord | null;
    list(rawTenantId?: TenantId): ApprovalRequestRecord[];
    private sessionBelongsToTenant;
}
