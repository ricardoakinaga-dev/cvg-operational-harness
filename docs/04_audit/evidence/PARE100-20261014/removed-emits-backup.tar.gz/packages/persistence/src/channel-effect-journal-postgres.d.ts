import type { ChannelEffectIdentity, ChannelEffectJournal, ChannelEffectReconciliation, ChannelEffectReconciliationActor, ChannelEffectRecord, ChannelEffectReserveInput, ChannelEffectReserveOutcome, ChannelEffectTransition, ChannelErrorCode, OutboundResult } from '@cvg/channel-gateway';
import type { PostgresQueryable } from './postgres.ts';
export declare const LEGACY_CHANNEL_HASH_VERSION = "legacy-local-v1";
export declare const SHARED_CHANNEL_HASH_VERSION = "shared-rfc8785-subset-v1";
export declare function isSupportedChannelHashVersion(version: unknown): version is string;
export declare function resolveStoredChannelHashVersion(record: Pick<ChannelEffectRecord, 'hashVersion'>): string | undefined;
export declare class PostgresChannelEffectError extends Error {
    readonly code: ChannelErrorCode;
    readonly retryable: boolean;
    constructor(code: ChannelErrorCode, message: string, retryable?: boolean);
}
export interface PostgresChannelEffectJournalOptions {
    clock?: () => number;
    pollMs?: number;
}
/**
 * PostgreSQL incarnation of the frozen `ChannelEffectJournal` interface
 * (AAA-12 / D05-2). It imports only channel-gateway types to avoid a runtime
 * dependency cycle, and reimplements the same state machine as
 * `decideReserve` in `channel-gateway/src/effect-journal.ts`.
 *
 * Every transition is an explicit `UPDATE ... WHERE state AND revision AND
 * lease_owner` compare-and-swap; a stale worker token returns `lease_lost`
 * and never overwrites another worker result. The table is tenant-isolated by
 * forced RLS, so callers must set `cvg.tenant_id` on the connection.
 *
 * The client must be one checked-out connection: the adapter issues
 * BEGIN/COMMIT and a `pg.Pool` may route statements to different connections.
 */
export declare class PostgresChannelEffectJournal implements ChannelEffectJournal {
    #private;
    constructor(client: PostgresQueryable, options?: PostgresChannelEffectJournalOptions);
    reserve(input: ChannelEffectReserveInput): Promise<ChannelEffectReserveOutcome>;
    claimSend(identity: ChannelEffectIdentity, leaseOwner: string): Promise<ChannelEffectRecord>;
    renew(identity: ChannelEffectIdentity, leaseOwner: string, leaseMs: number): Promise<boolean>;
    complete(identity: ChannelEffectIdentity, leaseOwner: string, result: OutboundResult): Promise<ChannelEffectTransition>;
    fail(identity: ChannelEffectIdentity, leaseOwner: string, errorCode: ChannelErrorCode): Promise<ChannelEffectTransition>;
    release(identity: ChannelEffectIdentity, leaseOwner: string, errorCode: ChannelErrorCode): Promise<ChannelEffectTransition>;
    markUncertain(identity: ChannelEffectIdentity, leaseOwner: string, errorCode: ChannelErrorCode): Promise<ChannelEffectTransition>;
    find(identity: ChannelEffectIdentity): Promise<ChannelEffectRecord | undefined>;
    waitForTerminal(identity: ChannelEffectIdentity, timeoutMs: number): Promise<ChannelEffectRecord | undefined>;
    resolveUncertain(identity: ChannelEffectIdentity, resolution: ChannelEffectReconciliation, actor: ChannelEffectReconciliationActor): Promise<ChannelEffectRecord>;
}
