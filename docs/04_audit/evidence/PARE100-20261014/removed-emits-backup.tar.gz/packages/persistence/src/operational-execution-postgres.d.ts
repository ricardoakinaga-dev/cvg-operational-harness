import type { EffectJournal, EffectJournalRecord, ExecutionEvent, ExecutionRecord, ExecutionSubmission, OperationalExecutionStore, SubmitResult, ClaimResult, ExecutionTransitionInput, ExecutionCancellationInput } from '@cvg/harness';
import type { PostgresQueryable } from './postgres.ts';
import { type PostgresPoolLike } from './tenant-scoped-postgres.ts';
export type OperationalExecutionPostgresConnection = PostgresQueryable | PostgresPoolLike;
export interface PostgresOperationalExecutionStoreOptions {
    readonly leaseMs?: number;
    readonly retryDelayMs?: number;
    readonly maxAttempts?: number;
    readonly clock?: () => Date;
}
/** PostgreSQL authority for the neutral AAA-21 execution spine. */
export declare class PostgresOperationalExecutionStore implements OperationalExecutionStore {
    private readonly connection;
    private readonly leaseMs;
    private readonly retryDelayMs;
    private readonly maxAttempts;
    private readonly clock;
    constructor(connection: OperationalExecutionPostgresConnection, options?: PostgresOperationalExecutionStoreOptions);
    submit(input: ExecutionSubmission, rawNow?: Date): Promise<SubmitResult>;
    get(tenantId: string, executionId: string): Promise<ExecutionRecord | null>;
    claimNext(tenantId: string, workerId: string, rawNow?: Date, rawLeaseMs?: number): Promise<ClaimResult | null>;
    heartbeat(tenantId: string, executionId: string, workerId: string, fenceToken: number, rawNow?: Date, rawLeaseMs?: number): Promise<ExecutionRecord>;
    transition(input: ExecutionTransitionInput, rawNow?: Date): Promise<ExecutionRecord>;
    cancel(input: ExecutionCancellationInput, rawNow?: Date): Promise<ExecutionRecord>;
    resolveApproval(input: {
        readonly tenantId: string;
        readonly executionId: string;
        readonly approvalId: string;
        readonly actorId: string;
        readonly decision: 'APPROVED' | 'REJECTED';
        readonly reason?: string;
    }, rawNow?: Date): Promise<ExecutionRecord>;
    provideUserInput(input: {
        readonly tenantId: string;
        readonly executionId: string;
        readonly actorId: string;
        readonly message: string;
    }, rawNow?: Date): Promise<ExecutionRecord>;
    recoverExpired(tenantId: string, rawNow?: Date): Promise<readonly ExecutionRecord[]>;
    listEvents(tenantId: string, executionId: string): Promise<readonly ExecutionEvent[]>;
    private run;
    private lockedRecord;
    private assertLease;
    private queueUpdateForTransition;
    private appendEvent;
}
/** PostgreSQL incarnation of the neutral effect journal. */
export declare class PostgresOperationalEffectJournal implements EffectJournal {
    private readonly connection;
    constructor(connection: OperationalExecutionPostgresConnection);
    reserve(input: {
        tenantId: string;
        operationKey: string;
        proposalHash: string;
        attemptId: string;
    }): Promise<EffectJournalRecord>;
    markStarted(input: {
        tenantId: string;
        operationKey: string;
        attemptId: string;
    }): Promise<EffectJournalRecord>;
    confirm(input: {
        tenantId: string;
        operationKey: string;
        attemptId: string;
        result: unknown;
    }): Promise<EffectJournalRecord>;
    fail(input: {
        tenantId: string;
        operationKey: string;
        attemptId: string;
        error: string;
    }): Promise<EffectJournalRecord>;
    markUncertain(input: {
        tenantId: string;
        operationKey: string;
        attemptId: string;
        reason: string;
    }): Promise<EffectJournalRecord>;
    get(tenantId: string, operationKey: string): Promise<EffectJournalRecord | null>;
    private transition;
    private run;
}
