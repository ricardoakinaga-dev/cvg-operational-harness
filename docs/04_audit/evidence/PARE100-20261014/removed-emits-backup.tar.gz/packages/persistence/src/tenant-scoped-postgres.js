"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TenantScopedPostgresControlPlaneRepository = exports.TenantScopedPostgresRuntimeRepository = exports.CVG_TENANT_CONTEXT_SETTING = void 0;
exports.withTenantContext = withTenantContext;
exports.withTenantTransaction = withTenantTransaction;
const shared_1 = require("@cvg/shared");
const platform_1 = require("@cvg/platform");
const postgres_ts_1 = require("./postgres.js");
const platform_control_plane_repository_ts_1 = require("./platform-control-plane-repository.js");
exports.CVG_TENANT_CONTEXT_SETTING = 'cvg.tenant_id';
/**
 * Runs an operation on one pool connection with a session-local tenant
 * context. The connection is destroyed when cleanup fails, preventing a
 * tenant context from leaking to the next borrower.
 */
async function withTenantContext(pool, rawTenantId, operation) {
    const tenantId = platform_1.TenantIdSchema.parse(rawTenantId);
    const client = await pool.connect();
    let contextSet = false;
    let originalSearchPath;
    let callbackResult;
    let callbackError;
    try {
        const searchPath = await client.query('SHOW search_path');
        originalSearchPath = searchPath.rows[0]?.search_path;
        await client.query('SELECT set_config($1, $2, false)', [
            exports.CVG_TENANT_CONTEXT_SETTING,
            tenantId
        ]);
        contextSet = true;
        try {
            callbackResult = await operation(client);
        }
        catch (error) {
            callbackError = error;
        }
        let cleanupError;
        try {
            await client.query('SELECT set_config($1, $2, false)', [
                exports.CVG_TENANT_CONTEXT_SETTING,
                ''
            ]);
        }
        catch (error) {
            cleanupError = toError(error);
        }
        if (!cleanupError && originalSearchPath) {
            try {
                await client.query('SELECT set_config($1, $2, false)', [
                    'search_path',
                    originalSearchPath
                ]);
                const restoredSearchPath = await client.query('SHOW search_path');
                if (restoredSearchPath.rows[0]?.search_path !== originalSearchPath) {
                    cleanupError = new Error('PostgreSQL search_path reset was not verified');
                }
            }
            catch (error) {
                cleanupError = toError(error);
            }
        }
        client.release(cleanupError);
        if (cleanupError)
            throw cleanupError;
        if (callbackError)
            throw callbackError;
        return callbackResult;
    }
    catch (error) {
        if (!contextSet)
            client.release(toError(error));
        throw error;
    }
}
/**
 * Runs a short transaction on one pool connection with the same session-local
 * tenant context used by {@link withTenantContext}. The callback, its state
 * mutations and any audit insert commit together; a failure rolls everything
 * back and the tenant context is cleared before the connection returns to the
 * pool. A connection whose context cleanup fails is destroyed instead of
 * being reused with a dirty context.
 */
async function withTenantTransaction(pool, rawTenantId, operation) {
    const tenantId = platform_1.TenantIdSchema.parse(rawTenantId);
    const client = await pool.connect();
    let released = false;
    const release = (error) => {
        if (released)
            return;
        released = true;
        client.release(error);
    };
    let cleanupFailure;
    const clearTenantContext = async () => {
        try {
            await client.query('SELECT set_config($1, $2, false)', [
                exports.CVG_TENANT_CONTEXT_SETTING,
                ''
            ]);
            const leaked = await client.query(`SELECT NULLIF(current_setting($1, true), '') AS tenant_id`, [exports.CVG_TENANT_CONTEXT_SETTING]);
            if (leaked.rows.length !== 1 || leaked.rows[0]?.tenant_id !== null) {
                throw new Error('PostgreSQL tenant context cleanup was not verified');
            }
        }
        catch (error) {
            cleanupFailure = toError(error);
            throw error;
        }
    };
    try {
        await client.query('BEGIN');
        await client.query('SELECT set_config($1, $2, false)', [
            exports.CVG_TENANT_CONTEXT_SETTING,
            tenantId
        ]);
        const result = await operation(client);
        await clearTenantContext();
        await client.query('COMMIT');
        release();
        return result;
    }
    catch (error) {
        try {
            await client.query('ROLLBACK');
        }
        catch (rollbackError) {
            release(toError(rollbackError));
            throw error;
        }
        try {
            await clearTenantContext();
        }
        catch (cleanupError) {
            release(toError(cleanupError));
            throw error;
        }
        release(cleanupFailure);
        throw error;
    }
}
class TenantScopedPostgresRuntimeRepository {
    pool;
    constructor(pool) {
        this.pool = pool;
    }
    enqueue(input) {
        return this.run(input.tenantId, (repository) => repository.enqueue(input));
    }
    findOutboxById(tenantId, eventId) {
        return this.run(tenantId, (repository) => repository.findOutboxById(tenantId, eventId));
    }
    claimNext(input) {
        return this.run(input.tenantId, (repository) => repository.claimNext(input));
    }
    ack(input) {
        return this.run(input.tenantId, (repository) => repository.ack(input));
    }
    fail(input) {
        return this.run(input.tenantId, (repository) => repository.fail(input));
    }
    requeueDeadLetter(input) {
        return this.run(input.tenantId, (repository) => repository.requeueDeadLetter(input));
    }
    findByExternalMessage(tenantId, channel, externalMessageId) {
        return this.run(tenantId, (repository) => repository.findByExternalMessage(tenantId, channel, externalMessageId));
    }
    createWithSession(input) {
        return this.run(input.tenantId, (repository) => repository.createWithSession(input));
    }
    createWithSessionAndOutbox(input, outbox) {
        return this.run(input.tenantId, (repository) => repository.createWithSessionAndOutbox(input, outbox));
    }
    bindSessionAgentVersion(tenantId, sessionId, agentId, agentVersionId) {
        return this.run(tenantId, (repository) => repository.bindSessionAgentVersion(tenantId, sessionId, agentId, agentVersionId));
    }
    appendOutboundMessage(input) {
        return this.run(input.tenantId, (repository) => repository.appendOutboundMessage(input));
    }
    markInboundRuntimeCompleted(messageId, tenantId) {
        return this.run(tenantId, (repository) => repository.markInboundRuntimeCompleted(messageId, tenantId));
    }
    findInboundRuntimeContext(tenantId, conversationId, sessionId, messageId) {
        return this.run(tenantId, (repository) => repository.findInboundRuntimeContext(tenantId, conversationId, sessionId, messageId));
    }
    completeInboundRuntime(input) {
        return withTenantContext(this.pool, input.tenantId, (client) => new postgres_ts_1.PostgresRuntimeRepository(client, {
            tenantIsolation: true
        }).completeInboundRuntime(input, new platform_control_plane_repository_ts_1.PostgresControlPlaneRepository(client)));
    }
    transitionTakeover(tenantId, sessionId, event) {
        return this.run(tenantId, (repository) => repository.transitionTakeover(tenantId, sessionId, event));
    }
    appendAudit(input, rawTenantId) {
        const tenantId = requireTenantId(rawTenantId);
        const payloadTenantId = readPayloadTenantId(input.payload);
        if (payloadTenantId !== tenantId) {
            throw new shared_1.DomainError('invalid_action', 'Audit payload tenant does not match the explicit tenant scope');
        }
        return this.run(tenantId, (repository) => repository.appendAudit({ ...input, tenantId }));
    }
    listAuditBySession(sessionId, tenantId) {
        return this.run(tenantId, (repository) => repository.listAuditBySession(sessionId, tenantId));
    }
    listAuditEvidence(query, tenantId) {
        return this.run(tenantId, (repository) => repository.listAuditEvidence(query, tenantId));
    }
    summarizeAuditEvidence(filters, tenantId) {
        return this.run(tenantId, (repository) => repository.summarizeAuditEvidence(filters, tenantId));
    }
    createAuditEvidenceCheckpoint(input, createdBy, tenantId) {
        return this.run(tenantId, (repository) => repository.createAuditEvidenceCheckpoint(input, createdBy, tenantId));
    }
    getAuditEvidenceCheckpoint(id, tenantId) {
        return this.run(tenantId, (repository) => repository.getAuditEvidenceCheckpoint(id, tenantId));
    }
    listAuditEvidenceCheckpoints(tenantId) {
        return this.run(tenantId, (repository) => repository.listAuditEvidenceCheckpoints(tenantId));
    }
    transitionAuditEvidenceCheckpoint(id, status, updatedBy, expectedStatus, tenantId) {
        return this.run(tenantId, (repository) => repository.transitionAuditEvidenceCheckpoint(id, status, updatedBy, expectedStatus, tenantId));
    }
    timeline(tenantId, conversationId) {
        return this.run(tenantId, (repository) => repository.timeline(tenantId, conversationId));
    }
    listPage(tenantId, input) {
        return this.run(tenantId, (repository) => repository.listPage(tenantId, input));
    }
    createTask(input, tenantId) {
        const scope = requireTenantId(tenantId);
        return this.run(scope, (repository) => repository.createTask(input, scope));
    }
    listTasks(tenantId) {
        const scope = requireTenantId(tenantId);
        return this.run(scope, (repository) => repository.listTasks(scope));
    }
    findTaskById(id, tenantId) {
        const scope = requireTenantId(tenantId);
        return this.run(scope, (repository) => repository.findTaskById(id, scope));
    }
    updateTaskStatus(id, status, tenantId) {
        const scope = requireTenantId(tenantId);
        return this.run(scope, (repository) => repository.updateTaskStatus(id, status, scope));
    }
    saveApproval(request, tenantId) {
        const scope = requireTenantId(tenantId);
        return this.run(scope, (repository) => repository.saveApproval(request, scope));
    }
    decideApprovalWithAudit(input, tenantId) {
        const scope = requireTenantId(tenantId);
        return this.run(scope, (repository) => repository.decideApprovalWithAudit(input, scope));
    }
    findApprovalById(id, tenantId) {
        const scope = requireTenantId(tenantId);
        return this.run(scope, (repository) => repository.findApprovalById(id, scope));
    }
    listApprovals(tenantId) {
        const scope = requireTenantId(tenantId);
        return this.run(scope, (repository) => repository.listApprovals(scope));
    }
    run(tenantId, operation) {
        return withTenantContext(this.pool, tenantId, (client) => operation(new postgres_ts_1.PostgresRuntimeRepository(client, { tenantIsolation: true })));
    }
}
exports.TenantScopedPostgresRuntimeRepository = TenantScopedPostgresRuntimeRepository;
class TenantScopedPostgresControlPlaneRepository {
    pool;
    constructor(pool) {
        this.pool = pool;
    }
    createAgent(scope, input) {
        return this.run(scope, (repository) => repository.createAgent(scope, input));
    }
    getAgent(scope, agentId) {
        return this.run(scope, (repository) => repository.getAgent(scope, agentId));
    }
    listAgents(scope) {
        return this.run(scope, (repository) => repository.listAgents(scope));
    }
    createVersion(scope, agentId, config, createdBy) {
        return this.run(scope, (repository) => repository.createVersion(scope, agentId, config, createdBy));
    }
    getVersion(scope, versionId) {
        return this.run(scope, (repository) => repository.getVersion(scope, versionId));
    }
    listVersions(scope, agentId) {
        return this.run(scope, (repository) => repository.listVersions(scope, agentId));
    }
    transitionVersion(scope, versionId, target, expectedStatus) {
        return this.run(scope, (repository) => repository.transitionVersion(scope, versionId, target, expectedStatus));
    }
    publishVersion(scope, versionId, releaseCandidateId, expectedStatus) {
        return this.run(scope, (repository) => repository.publishVersion(scope, versionId, releaseCandidateId, expectedStatus));
    }
    rollback(scope, agentId, versionId, createdBy, releaseCandidateId, expectedStatus) {
        return this.run(scope, (repository) => repository.rollback(scope, agentId, versionId, createdBy, releaseCandidateId, expectedStatus));
    }
    resolvePublished(scope, agentId) {
        return this.run(scope, (repository) => repository.resolvePublished(scope, agentId));
    }
    createKnowledgeSource(scope, input, createdBy) {
        return this.run(scope, (repository) => repository.createKnowledgeSource(scope, input, createdBy));
    }
    getKnowledgeSource(scope, sourceId) {
        return this.run(scope, (repository) => repository.getKnowledgeSource(scope, sourceId));
    }
    listKnowledgeSources(scope) {
        return this.run(scope, (repository) => repository.listKnowledgeSources(scope));
    }
    transitionKnowledgeSource(scope, sourceId, target, actorId, expectedStatus) {
        return this.run(scope, (repository) => repository.transitionKnowledgeSource(scope, sourceId, target, actorId, expectedStatus));
    }
    createReleaseCandidate(scope, input, createdBy) {
        return this.run(scope, (repository) => repository.createReleaseCandidate(scope, input, createdBy));
    }
    getReleaseCandidate(scope, candidateId) {
        return this.run(scope, (repository) => repository.getReleaseCandidate(scope, candidateId));
    }
    listReleaseCandidates(scope, agentId) {
        return this.run(scope, (repository) => repository.listReleaseCandidates(scope, agentId));
    }
    transitionReleaseCandidate(scope, candidateId, target, actorId, expectedStatus) {
        return this.run(scope, (repository) => repository.transitionReleaseCandidate(scope, candidateId, target, actorId, expectedStatus));
    }
    createPluginCatalogEntry(scope, input, createdBy) {
        return this.run(scope, (repository) => repository.createPluginCatalogEntry(scope, input, createdBy));
    }
    getPluginCatalogEntry(scope, pluginId) {
        return this.run(scope, (repository) => repository.getPluginCatalogEntry(scope, pluginId));
    }
    listPluginCatalogEntries(scope, name) {
        return this.run(scope, (repository) => repository.listPluginCatalogEntries(scope, name));
    }
    transitionPluginCatalogEntry(scope, pluginId, target, actorId, expectedStatus) {
        return this.run(scope, (repository) => repository.transitionPluginCatalogEntry(scope, pluginId, target, actorId, expectedStatus));
    }
    resolveApprovedPlugin(scope, name, version) {
        return this.run(scope, (repository) => repository.resolveApprovedPlugin(scope, name, version));
    }
    recordTestRun(scope, trace) {
        return this.run(scope, (repository) => repository.recordTestRun(scope, trace));
    }
    listTestRuns(scope, limit) {
        return this.run(scope, (repository) => repository.listTestRuns(scope, limit));
    }
    recordExecutionTrace(scope, trace) {
        return this.run(scope, (repository) => repository.recordExecutionTrace(scope, trace));
    }
    listExecutionTraces(scope, limit) {
        return this.run(scope, (repository) => repository.listExecutionTraces(scope, limit));
    }
    createTestSuite(scope, input, createdBy) {
        return this.run(scope, (repository) => repository.createTestSuite(scope, input, createdBy));
    }
    getTestSuite(scope, suiteId) {
        return this.run(scope, (repository) => repository.getTestSuite(scope, suiteId));
    }
    listTestSuites(scope, agentId) {
        return this.run(scope, (repository) => repository.listTestSuites(scope, agentId));
    }
    cloneTestSuite(scope, suiteId, input, createdBy) {
        return this.run(scope, (repository) => repository.cloneTestSuite(scope, suiteId, input, createdBy));
    }
    recordTestSuiteRun(scope, run) {
        return this.run(scope, (repository) => repository.recordTestSuiteRun(scope, run));
    }
    listTestSuiteRuns(scope, suiteId, limit) {
        return this.run(scope, (repository) => repository.listTestSuiteRuns(scope, suiteId, limit));
    }
    run(rawScope, operation) {
        const scope = platform_1.TenantScopeSchema.parse(rawScope);
        return withTenantContext(this.pool, scope.tenantId, (client) => operation(new platform_control_plane_repository_ts_1.PostgresControlPlaneRepository(client)));
    }
}
exports.TenantScopedPostgresControlPlaneRepository = TenantScopedPostgresControlPlaneRepository;
function readPayloadTenantId(payload) {
    if (typeof payload === 'object' &&
        payload !== null &&
        'tenantId' in payload) {
        const parsed = platform_1.TenantIdSchema.safeParse(payload.tenantId);
        if (parsed.success)
            return parsed.data;
    }
    throw new shared_1.DomainError('invalid_action', 'A tenant-scoped audit payload is required');
}
function toError(error) {
    return error instanceof Error
        ? error
        : new Error('PostgreSQL tenant context failure');
}
function requireTenantId(rawTenantId) {
    if (!rawTenantId) {
        throw new shared_1.DomainError('invalid_action', 'Tenant scope is required');
    }
    return platform_1.TenantIdSchema.parse(rawTenantId);
}
//# sourceMappingURL=tenant-scoped-postgres.js.map