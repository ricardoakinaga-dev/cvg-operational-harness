import { type TaskPriority, type TaskStatus } from '@cvg/shared';
import { type TenantId } from '@cvg/platform';
import type { InMemoryDatabase } from '../db.ts';
import type { TaskRecord } from '../schema.ts';
export declare class TaskRepository {
    private readonly db;
    constructor(db: InMemoryDatabase);
    create(input: {
        sessionId: string;
        title: string;
        description: string;
        priority: TaskPriority;
        source: string;
        idempotencyKey: string;
    }, rawTenantId?: TenantId): TaskRecord;
    list(rawTenantId?: TenantId): TaskRecord[];
    findById(id: string, rawTenantId?: TenantId): TaskRecord | null;
    updateStatus(id: string, status: TaskStatus, rawTenantId?: TenantId): TaskRecord | null;
    private taskBelongsToTenant;
    private sessionBelongsToTenant;
}
