import { type ApprovalDecision, type Role } from '@cvg/shared';
import type { TenantId } from '@cvg/platform';
import type { ApprovalRequestRecord, AuditEventRecord } from './schema.ts';
export interface AttendanceApprovalDecision {
    approvalRequestId: string;
    decision: ApprovalDecision;
    operatorId: string;
    role: Role;
    correlationId: string;
    note?: string;
}
export declare function validateAttendanceDecision(input: AttendanceApprovalDecision): AttendanceApprovalDecision;
export declare function assertApprovalCreation(request: ApprovalRequestRecord): void;
export declare function cloneAttendanceApproval(request: ApprovalRequestRecord): ApprovalRequestRecord;
export declare function attendanceDecisionAudit(request: ApprovalRequestRecord, input: AttendanceApprovalDecision, tenantId?: TenantId): Omit<AuditEventRecord, 'id' | 'createdAt'>;
