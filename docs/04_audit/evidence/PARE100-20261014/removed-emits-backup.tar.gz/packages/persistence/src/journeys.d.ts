import { type TenantId } from '@cvg/platform';
import type { InMemoryDatabase } from './db.ts';
import type { AppointmentDraftRecord, OwnerDraftRecord, PatientDraftRecord, TaskRecord } from './schema.ts';
export declare const SYNTHETIC_SCHEDULE_VERSION = "synthetic-schedule-v1";
export declare const DEFAULT_DRAFT_TTL_MS: number;
export interface JourneyCandidate {
    id: string;
    displayName: string;
    kind: 'owner' | 'patient';
    ownerId?: string;
}
export interface JourneySlot {
    id: string;
    startsAt: string;
    sourceVersion: string;
}
export interface JourneyRepositoryOptions {
    clock?: () => Date;
    draftTtlMs?: number;
}
/**
 * Actor and correlation carried by journey audit events. `System` is an
 * explicit repository/execution identity, never a simulated human operator.
 */
export interface JourneyAuditContext {
    actorType: 'Operator' | 'System';
    actorId: string;
    correlationId?: string;
}
export interface OwnerDraftInput {
    tenantId: TenantId;
    phone?: string | null;
    name?: string | null;
    conversationId?: string | null;
    sessionId?: string | null;
    idempotencyKey: string;
    auditContext?: JourneyAuditContext;
}
export interface PatientDraftInput {
    tenantId: TenantId;
    ownerDraftId?: string | null;
    ownerCandidateId?: string | null;
    name?: string | null;
    species?: string | null;
    conversationId?: string | null;
    sessionId?: string | null;
    idempotencyKey: string;
    auditContext?: JourneyAuditContext;
}
export interface AppointmentDraftInput {
    tenantId: TenantId;
    patientDraftId: string;
    slot: string;
    conversationId?: string | null;
    sessionId?: string | null;
    idempotencyKey: string;
    auditContext?: JourneyAuditContext;
}
export interface SearchPatientInput {
    tenantId: TenantId;
    ownerDraftId?: string | null;
    ownerCandidateId?: string | null;
    name?: unknown;
}
export interface LinkPatientInput {
    tenantId: TenantId;
    patientDraftId: string;
    candidateId: string;
    auditContext?: JourneyAuditContext;
}
export type CreateJourneyTaskInput = {
    tenantId: TenantId;
    sessionId: string;
    title: string;
    description: string;
    priority?: 'low' | 'medium' | 'high' | 'urgent';
    idempotencyKey: string;
    auditContext?: JourneyAuditContext;
};
export interface RecordHandoffInput {
    tenantId: TenantId;
    conversationId?: string | null;
    sessionId?: string | null;
    intent: string;
    risk: string;
    pendingItems?: string[];
    nextStep: string;
    auditContext?: JourneyAuditContext;
}
export type MaybePromise<T> = T | Promise<T>;
/**
 * Port shared by the in-memory and PostgreSQL journey repositories. The memory
 * implementation answers synchronously; the PostgreSQL one answers with
 * promises. Callers await either shape.
 */
export interface JourneyRepositoryPort {
    searchOwnerByPhone(rawTenantId: TenantId, rawPhone: unknown): MaybePromise<JourneyCandidate[]>;
    createOwnerDraft(input: OwnerDraftInput): MaybePromise<OwnerDraftRecord>;
    listOwnerDrafts(rawTenantId: TenantId): MaybePromise<OwnerDraftRecord[]>;
    findOwnerDraft(rawTenantId: TenantId, id: string): MaybePromise<OwnerDraftRecord | null>;
    searchPatient(input: SearchPatientInput): MaybePromise<JourneyCandidate[]>;
    listPatientDrafts(rawTenantId: TenantId): MaybePromise<PatientDraftRecord[]>;
    findPatientDraft(rawTenantId: TenantId, id: string): MaybePromise<PatientDraftRecord | null>;
    createPatientDraft(input: PatientDraftInput): MaybePromise<PatientDraftRecord>;
    linkPatient(input: LinkPatientInput): MaybePromise<PatientDraftRecord>;
    findAvailableSlots(rawTenantId: TenantId, limit?: number): MaybePromise<JourneySlot[]>;
    createAppointmentDraft(input: AppointmentDraftInput): MaybePromise<AppointmentDraftRecord>;
    listAppointmentDrafts(rawTenantId: TenantId): MaybePromise<AppointmentDraftRecord[]>;
    createJourneyTask(input: CreateJourneyTaskInput): MaybePromise<TaskRecord>;
    recordHandoff(input: RecordHandoffInput): MaybePromise<void>;
}
/**
 * Controlled persistence for the tutor/pet/agenda journeys.
 *
 * The catalog deliberately contains synthetic fixtures only. It is useful in
 * Test Lab and local development because it proves restart, ambiguity and
 * tenant boundaries without pretending to be a clinical or scheduling system.
 */
export declare class JourneyRepository implements JourneyRepositoryPort {
    private readonly db;
    private readonly audit;
    private readonly tasks;
    private readonly clock;
    private readonly draftTtlMs;
    constructor(db: InMemoryDatabase, options?: JourneyRepositoryOptions);
    searchOwnerByPhone(rawTenantId: TenantId, rawPhone: unknown): JourneyCandidate[];
    createOwnerDraft(input: OwnerDraftInput): OwnerDraftRecord;
    listOwnerDrafts(rawTenantId: TenantId): OwnerDraftRecord[];
    findOwnerDraft(rawTenantId: TenantId, id: string): OwnerDraftRecord | null;
    searchPatient(input: SearchPatientInput): JourneyCandidate[];
    listPatientDrafts(rawTenantId: TenantId): PatientDraftRecord[];
    findPatientDraft(rawTenantId: TenantId, id: string): PatientDraftRecord | null;
    createPatientDraft(input: PatientDraftInput): PatientDraftRecord;
    linkPatient(input: LinkPatientInput): PatientDraftRecord;
    findAvailableSlots(rawTenantId: TenantId, limit?: number): JourneySlot[];
    createAppointmentDraft(input: AppointmentDraftInput): AppointmentDraftRecord;
    listAppointmentDrafts(rawTenantId: TenantId): AppointmentDraftRecord[];
    createJourneyTask(input: CreateJourneyTaskInput): TaskRecord;
    recordHandoff(input: RecordHandoffInput): void;
    private expireOwnerDraft;
    private expirePatientDraft;
    private expireAppointmentDraft;
    private activeOwnerDrafts;
    private requireOwnerDraft;
    private requirePatientDraft;
    /**
     * Journey references are caller supplied identifiers, so validate their
     * tenant ownership before persisting them in a draft or audit trail.
     * A session may imply its conversation; an explicit pair must agree.
     */
    private resolveJourneyContext;
    private appendJourneyAudit;
    private tenant;
    private now;
}
declare function normalizePhone(raw: unknown): string;
declare function boundedKey(raw: unknown): string;
declare function boundedText(raw: unknown, field: string): string;
declare function boundedOptionalText(raw: unknown, field: string): string | null;
declare function normalizeOptionalReference(raw: string | null | undefined, field: string): string | null;
export declare const SYSTEM_JOURNEY_ACTOR = "system.journey-repository";
/**
 * Normalizes the caller-supplied audit context shared by the memory and
 * PostgreSQL repositories. Missing context records an explicit system actor;
 * it never fabricates a human operator.
 */
export declare function normalizeJourneyAuditContext(raw: JourneyAuditContext | undefined, resourceId: string): {
    actorType: 'Operator' | 'System';
    actorId: string;
    correlationId: string;
};
/**
 * Deterministic synthetic slot generation shared by both repositories.
 * Slots are generated from the UTC calendar day, not the instant, so two
 * reads during one day return the same value for a selected slot.
 */
export declare function buildJourneySlots(rawTenantId: TenantId, now: Date, limit?: number): JourneySlot[];
declare function syntheticOwners(tenantId: TenantId): Array<{
    id: string;
    phone: string;
    candidate: JourneyCandidate;
}>;
declare function syntheticPatients(tenantId: TenantId): Array<{
    id: string;
    name: string;
    ownerId: string;
    candidate: JourneyCandidate;
}>;
declare function cloneCandidate(candidate: JourneyCandidate): JourneyCandidate;
declare function cloneOwnerDraft(draft: OwnerDraftRecord): OwnerDraftRecord;
declare function clonePatientDraft(draft: PatientDraftRecord): PatientDraftRecord;
declare function cloneAppointmentDraft(draft: AppointmentDraftRecord): AppointmentDraftRecord;
export { boundedKey, boundedOptionalText, boundedText, cloneAppointmentDraft, cloneCandidate, cloneOwnerDraft, clonePatientDraft, normalizeOptionalReference, normalizePhone, syntheticOwners, syntheticPatients };
