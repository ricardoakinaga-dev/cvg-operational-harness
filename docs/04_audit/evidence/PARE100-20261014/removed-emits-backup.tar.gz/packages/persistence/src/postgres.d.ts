import { type AttendanceApprovalDecision } from './attendance-approval.ts';
import { type Channel, type TaskPriority, type TaskStatus } from '@cvg/shared';
import { type AgentId, type AgentVersionId, type PluginAuditEvent, type TestRunTrace, type HumanTakeoverEvent, type TenantId } from '@cvg/platform';
import type { QueryResult, QueryResultRow } from 'pg';
import { type AuditEvidenceCheckpointCreateInput, type AuditEvidenceCheckpointRecord, type AuditEvidenceCheckpointStatus } from './audit-evidence-checkpoint.ts';
import type { ApprovalRequestRecord, AuditEventRecord, AuditEvidenceFilters, AuditEvidencePage, AuditEvidenceQuery, AuditEvidenceSummary, ConversationPage, ConversationRecord, InboundRuntimeContext, MessageRecord, PaginationInput, OutboxEventRecord, SessionRecord, TaskRecord } from './schema.ts';
import { type OutboxAckInput as MemoryOutboxAckInput, type OutboxClaimInput, type OutboxEnqueueInput as MemoryOutboxEnqueueInput, type OutboxFailInput, type OutboxRequeueInput as MemoryOutboxRequeueInput } from './outbox.ts';
export interface PostgresMigrationOptions {
    schemaName?: string;
    migrations?: string[];
    createSchema?: boolean;
}
export interface PostgresQueryable {
    query<T extends QueryResultRow = QueryResultRow>(text: string, values?: unknown[]): Promise<QueryResult<T>>;
}
/**
 * A checked-out pool connection is required for approval transactions. A
 * `pg.Pool` also exposes `query`, but it may route each statement to a
 * different connection and therefore cannot safely carry BEGIN/COMMIT.
 */
export interface PostgresTransactionClient extends PostgresQueryable {
    release(error?: Error): void;
}
export interface PostgresRuntimeRepositoryOptions {
    tenantIsolation?: boolean;
    /** Repository-owned clock; callers cannot override lease/retry decisions. */
    clock?: () => Date;
}
export interface InboundRuntimeCompletionInput {
    tenantId: TenantId;
    conversationId: string;
    sessionId: string | null;
    inboundMessageId: string;
    trace: TestRunTrace;
    toolAuditEvents: PluginAuditEvent[];
    correlationId: string;
}
export type DurableOutboxStatus = OutboxEventRecord['status'];
export type DurableOutboxEventRecord = OutboxEventRecord & {
    tenantId: TenantId;
    correlationId: string;
    idempotencyKey: string;
    envelopeVersion: number;
    conversationId: string | null;
    sessionId: string | null;
    agentId: string | null;
    agentVersionId: string | null;
    inboundMessageId: string | null;
    availableAt: Date;
    attempts: number;
    leaseOwner: string | null;
    leaseUntil: Date | null;
    lastError: string | null;
    processedAt: Date | null;
    deadLetteredAt: Date | null;
    parentEventId: string | null;
};
export type PostgresOutboxEnqueueInput = MemoryOutboxEnqueueInput & {
    /** Optional deterministic values are used by PostgreSQL integration tests. */
    createdAt?: Date;
    availableAt?: Date;
};
export type PostgresOutboxAckInput = Omit<MemoryOutboxAckInput, 'effect'> & {
    effect?: MemoryOutboxAckInput['effect'];
};
export type PostgresOutboxRequeueInput = MemoryOutboxRequeueInput & {
    now?: Date;
};
export declare const OUTBOX_MAX_ATTEMPTS = 5;
export declare const OUTBOX_DEFAULT_LEASE_MS = 30000;
export declare const OUTBOX_BASE_BACKOFF_MS = 1000;
export declare const OUTBOX_MAX_BACKOFF_MS = 60000;
export declare function readInitialMigrationSql(): Promise<string>;
export declare function readPostgresMigrationSql(version: string): Promise<string>;
export declare function runInitialPostgresMigration(client: PostgresQueryable, options?: PostgresMigrationOptions): Promise<void>;
/**
 * Applies ordered migrations with a checksum guard. The legacy 0000 file is
 * intentionally preserved; production startup must use this runner so a
 * database marked with 0000 cannot silently skip tenant isolation.
 */
export declare function runPostgresMigrations(client: PostgresQueryable, options?: PostgresMigrationOptions): Promise<void>;
export interface LegacyMigrationBaselineApproval {
    actor: string;
    reference: string;
}
export declare const legacyRequiredColumns: readonly [readonly ["conversations", "tenant_id"], readonly ["conversations", "id"], readonly ["conversations", "channel"], readonly ["conversations", "sender_ref"], readonly ["conversations", "sender_ref_hash"], readonly ["conversations", "status"], readonly ["conversations", "correlation_id"], readonly ["conversations", "created_at"], readonly ["conversations", "updated_at"], readonly ["messages", "id"], readonly ["messages", "conversation_id"], readonly ["messages", "external_message_id"], readonly ["messages", "direction"], readonly ["messages", "body"], readonly ["messages", "runtime_status"], readonly ["messages", "created_at"], readonly ["sessions", "id"], readonly ["sessions", "conversation_id"], readonly ["sessions", "status"], readonly ["sessions", "takeover_state"], readonly ["sessions", "created_at"], readonly ["sessions", "updated_at"], readonly ["agent_runs", "id"], readonly ["agent_runs", "session_id"], readonly ["agent_runs", "status"], readonly ["agent_runs", "created_at"], readonly ["agent_runs", "updated_at"], readonly ["tool_calls", "id"], readonly ["tool_calls", "agent_run_id"], readonly ["tool_calls", "tool_name"], readonly ["tool_calls", "status"], readonly ["tool_calls", "input"], readonly ["tool_calls", "output"], readonly ["tool_calls", "error"], readonly ["tool_calls", "created_at"], readonly ["approval_requests", "id"], readonly ["approval_requests", "session_id"], readonly ["approval_requests", "proposed_action"], readonly ["approval_requests", "summary"], readonly ["approval_requests", "risk_level"], readonly ["approval_requests", "status"], readonly ["approval_requests", "decided_by"], readonly ["approval_requests", "decided_at"], readonly ["approval_requests", "created_at"], readonly ["tasks", "id"], readonly ["tasks", "session_id"], readonly ["tasks", "title"], readonly ["tasks", "description"], readonly ["tasks", "priority"], readonly ["tasks", "source"], readonly ["tasks", "status"], readonly ["tasks", "idempotency_key"], readonly ["tasks", "created_at"], readonly ["audit_events", "id"], readonly ["audit_events", "type"], readonly ["audit_events", "actor_type"], readonly ["audit_events", "actor_id"], readonly ["audit_events", "correlation_id"], readonly ["audit_events", "policy_version"], readonly ["audit_events", "payload"], readonly ["audit_events", "created_at"], readonly ["idempotency", "tenant_id"], readonly ["idempotency", "key"], readonly ["idempotency", "resource_id"], readonly ["idempotency", "created_at"], readonly ["outbox_events", "id"], readonly ["outbox_events", "type"], readonly ["outbox_events", "payload"], readonly ["outbox_events", "status"], readonly ["outbox_events", "created_at"], readonly ["platform_agents", "tenant_id"], readonly ["platform_agents", "id"], readonly ["platform_agents", "slug"], readonly ["platform_agents", "name"], readonly ["platform_agents", "description"], readonly ["platform_agents", "active_version_id"], readonly ["platform_agents", "created_at"], readonly ["platform_agents", "updated_at"], readonly ["platform_agent_versions", "tenant_id"], readonly ["platform_agent_versions", "id"], readonly ["platform_agent_versions", "agent_id"], readonly ["platform_agent_versions", "version"], readonly ["platform_agent_versions", "status"], readonly ["platform_agent_versions", "config"], readonly ["platform_agent_versions", "created_by"], readonly ["platform_agent_versions", "created_at"], readonly ["platform_agent_versions", "published_at"], readonly ["platform_test_runs", "tenant_id"], readonly ["platform_test_runs", "trace_id"], readonly ["platform_test_runs", "agent_id"], readonly ["platform_test_runs", "version_id"], readonly ["platform_test_runs", "trace"], readonly ["platform_test_runs", "created_at"], readonly ["platform_execution_traces", "tenant_id"], readonly ["platform_execution_traces", "trace_id"], readonly ["platform_execution_traces", "agent_id"], readonly ["platform_execution_traces", "version_id"], readonly ["platform_execution_traces", "trace"], readonly ["platform_execution_traces", "created_at"]];
export declare const legacyRequiredIndexes: readonly ["conversations_pkey", "messages_pkey", "sessions_pkey", "agent_runs_pkey", "tool_calls_pkey", "approval_requests_pkey", "tasks_pkey", "audit_events_pkey", "idempotency_pkey", "outbox_events_pkey", "platform_agents_pkey", "platform_agent_versions_pkey", "platform_test_runs_pkey", "platform_execution_traces_pkey", "idx_messages_conversation_id", "idx_messages_runtime_status", "idx_conversations_tenant_id", "idx_sessions_conversation_id", "idx_agent_runs_session_id", "idx_approval_requests_session_id", "idx_tasks_session_id", "idx_audit_events_correlation_id", "idx_audit_events_type", "idx_audit_events_actor_id", "idx_audit_events_payload_session_id", "idx_outbox_events_status", "idx_platform_agents_tenant_id", "idx_platform_agent_versions_tenant_agent", "idx_platform_agent_versions_one_published", "idx_platform_test_runs_tenant_created", "idx_platform_execution_traces_tenant_created"];
/**
 * Records an operator-approved checksum baseline for a legacy database that
 * was created by 0000_initial before checksum tracking existed. This is never
 * called by application startup; it is an explicit infrastructure operation.
 */
export declare function baselineLegacyPostgresMigration(client: PostgresQueryable, options: PostgresMigrationOptions & {
    approval: LegacyMigrationBaselineApproval;
}): Promise<void>;
export declare class PostgresRuntimeRepository {
    private readonly client;
    private readonly tenantIsolation;
    private readonly clock;
    constructor(client: PostgresQueryable, options?: PostgresRuntimeRepositoryOptions);
    /**
     * Enqueues an event using the durable tenant/idempotency boundary. Passing
     * a transaction client lets the inbound finalizer include this insert in
     * its existing commit; otherwise this method owns a short transaction.
     */
    enqueue(rawInput: PostgresOutboxEnqueueInput, transactionClient?: PostgresQueryable): Promise<DurableOutboxEventRecord>;
    findOutboxById(rawTenantId: TenantId, eventId: string): Promise<DurableOutboxEventRecord | null>;
    claimNext(rawInput: OutboxClaimInput): Promise<DurableOutboxEventRecord | null>;
    ack(rawInput: PostgresOutboxAckInput): Promise<DurableOutboxEventRecord>;
    fail(rawInput: OutboxFailInput): Promise<DurableOutboxEventRecord>;
    requeueDeadLetter(rawInput: PostgresOutboxRequeueInput): Promise<DurableOutboxEventRecord>;
    findByExternalMessage(tenantId: TenantId, channel: Channel, externalMessageId: string): Promise<MessageRecord | null>;
    createWithSession(input: {
        tenantId: TenantId;
        channel: Channel;
        senderRef: string;
        externalMessageId: string;
        body: string;
        conversationId?: string | undefined;
        sessionId?: string | undefined;
    }, durableOutbox?: PostgresOutboxEnqueueInput): Promise<{
        conversation: ConversationRecord;
        session: SessionRecord;
        message: MessageRecord;
        outbox?: DurableOutboxEventRecord;
    }>;
    createWithSessionAndOutbox(input: Parameters<PostgresRuntimeRepository['createWithSession']>[0], outbox: PostgresOutboxEnqueueInput): Promise<{
        conversation: ConversationRecord;
        session: SessionRecord;
        message: MessageRecord;
        outbox: DurableOutboxEventRecord;
    }>;
    bindSessionAgentVersion(rawTenantId: TenantId, sessionId: string, rawAgentId: AgentId, rawAgentVersionId: AgentVersionId): Promise<SessionRecord | null>;
    appendOutboundMessage(input: {
        tenantId: TenantId;
        conversationId: string;
        externalMessageId: string;
        body: string;
    }): Promise<MessageRecord>;
    markInboundRuntimeCompleted(messageId: string, rawTenantId: TenantId): Promise<boolean>;
    findInboundRuntimeContext(rawTenantId: TenantId, conversationId: string, sessionId: string | null, messageId: string): Promise<InboundRuntimeContext | null>;
    transitionTakeover(rawTenantId: TenantId, sessionId: string, event: HumanTakeoverEvent): Promise<SessionRecord | null>;
    transitionTakeoverInTransaction(rawTenantId: TenantId, sessionId: string, event: HumanTakeoverEvent): Promise<SessionRecord | null>;
    completeInboundRuntime(input: InboundRuntimeCompletionInput, controlPlane: {
        recordExecutionTrace: (scope: {
            tenantId: TenantId;
        }, trace: TestRunTrace) => Promise<TestRunTrace>;
    }): Promise<{
        status: 'completed' | 'paused';
    }>;
    appendAudit(input: Omit<AuditEventRecord, 'id' | 'createdAt'>): Promise<AuditEventRecord>;
    listAuditBySession(sessionId: string, rawTenantId?: TenantId): Promise<AuditEventRecord[]>;
    listAuditEvidence(query: AuditEvidenceQuery, rawTenantId?: TenantId): Promise<AuditEvidencePage>;
    summarizeAuditEvidence(filters: AuditEvidenceFilters, rawTenantId?: TenantId): Promise<AuditEvidenceSummary>;
    listAuditEventsByIds(rawIds: string[], rawTenantId?: TenantId): Promise<AuditEventRecord[]>;
    createAuditEvidenceCheckpoint(rawInput: AuditEvidenceCheckpointCreateInput, rawCreatedBy: string, rawTenantId?: TenantId): Promise<AuditEvidenceCheckpointRecord>;
    getAuditEvidenceCheckpoint(rawId: string, rawTenantId?: TenantId): Promise<AuditEvidenceCheckpointRecord | null>;
    listAuditEvidenceCheckpoints(rawTenantId?: TenantId): Promise<AuditEvidenceCheckpointRecord[]>;
    transitionAuditEvidenceCheckpoint(rawId: string, rawStatus: AuditEvidenceCheckpointStatus, rawUpdatedBy: string, rawExpectedStatus: AuditEvidenceCheckpointStatus, rawTenantId?: TenantId): Promise<AuditEvidenceCheckpointRecord | null>;
    timeline(tenantId: TenantId, conversationId: string): Promise<{
        messages: MessageRecord[];
        sessions: SessionRecord[];
    }>;
    listPage(tenantId: TenantId, input: PaginationInput): Promise<ConversationPage>;
    createTask(input: {
        sessionId: string;
        title: string;
        description: string;
        priority: TaskPriority;
        source: string;
        idempotencyKey: string;
    }, rawTenantId?: TenantId, onCreated?: (task: TaskRecord) => Promise<void>): Promise<TaskRecord>;
    listTasks(rawTenantId?: TenantId): Promise<TaskRecord[]>;
    findTaskById(id: string, rawTenantId?: TenantId): Promise<TaskRecord | null>;
    updateTaskStatus(id: string, status: TaskStatus, rawTenantId?: TenantId): Promise<TaskRecord | null>;
    private assertSessionTenant;
    saveApproval(request: ApprovalRequestRecord, rawTenantId?: TenantId): Promise<ApprovalRequestRecord>;
    decideApprovalWithAudit(input: AttendanceApprovalDecision, rawTenantId?: TenantId): Promise<ApprovalRequestRecord>;
    findApprovalById(id: string, rawTenantId?: TenantId): Promise<ApprovalRequestRecord | null>;
    listApprovals(rawTenantId?: TenantId): Promise<ApprovalRequestRecord[]>;
    private markOutboxSessionHandoff;
    private isOutboxTakeoverActive;
    private suppressOutboxForTakeover;
    private repositoryNow;
    private mapTask;
    private mapApproval;
    private mapAuditEvent;
}
