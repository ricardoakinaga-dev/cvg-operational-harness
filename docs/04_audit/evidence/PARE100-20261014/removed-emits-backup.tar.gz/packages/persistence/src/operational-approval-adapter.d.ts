import { type ApprovalAuthority } from '@cvg/approval-engine';
import type { ApprovalDecision, ApprovalEngine, ApprovalExecutionPort, ApprovalRequest } from '@cvg/harness-contracts';
export interface DurableApprovalAdapterOptions {
    readonly defaultOperatorId?: string;
    readonly defaultPolicyVersion?: string;
}
/**
 * Bridges the neutral harness approval port to the durable ApprovalAuthority.
 * The authority remains the only state-machine decision maker; this adapter
 * only performs idempotent lookup, canonical binding checks, and translation
 * to the neutral runtime contract.
 */
export declare class DurableApprovalEngineAdapter implements ApprovalEngine {
    readonly authority: ApprovalAuthority;
    private readonly defaultOperatorId;
    private readonly defaultPolicyVersion;
    private readonly requestLocks;
    readonly execution: ApprovalExecutionPort;
    constructor(authority: ApprovalAuthority, options?: DurableApprovalAdapterOptions);
    request(input: ApprovalRequest): Promise<ApprovalDecision>;
    private requestUnserialized;
    private findBoundApproval;
    private beginExecution;
    private completeExecution;
    private failExecution;
    private markUncertain;
    private toDecision;
}
