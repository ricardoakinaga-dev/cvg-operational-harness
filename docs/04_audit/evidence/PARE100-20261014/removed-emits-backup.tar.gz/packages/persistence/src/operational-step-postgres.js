"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostgresExecutionStepStore = void 0;
const harness_contracts_1 = require("@cvg/harness-contracts");
const harness_1 = require("@cvg/harness");
const platform_1 = require("@cvg/platform");
const tenant_scoped_postgres_ts_1 = require("./tenant-scoped-postgres.js");
const stepColumns = `
  tenant_id, execution_id, step_number, step_id, step_type, status, attempt,
  side_effecting, decision_type, reason_code, error_code, observation_refs,
  started_at, completed_at`;
const checkpointColumns = `
  tenant_id, execution_id, checkpoint_id, checkpoint_version, runtime_profile,
  runtime_version, orchestrator_version, step_number, state, budget_usage,
  digest, created_at`;
function text(value, label, max = 200) {
    if (typeof value !== 'string' || value.trim().length === 0) {
        throw new harness_1.CheckpointError('checkpoint_binding', `${label} is required`);
    }
    if (value.length > max) {
        throw new harness_1.CheckpointError('checkpoint_binding', `${label} is too long`);
    }
    return value.trim();
}
function asIso(value) {
    if (value === null)
        return null;
    return value instanceof Date
        ? value.toISOString()
        : new Date(value).toISOString();
}
function jsonValue(value) {
    if (typeof value !== 'string')
        return value;
    try {
        return JSON.parse(value);
    }
    catch {
        throw new harness_1.CheckpointError('checkpoint_integrity', 'Persisted step JSON is invalid');
    }
}
function jsonText(value, label) {
    try {
        const serialized = JSON.stringify(value);
        if (serialized === undefined)
            throw new Error('undefined');
        return serialized;
    }
    catch {
        throw new harness_1.CheckpointError('checkpoint_integrity', `${label} cannot be serialized`);
    }
}
function mapStep(row) {
    const refs = jsonValue(row.observation_refs);
    return {
        stepId: row.step_id,
        executionId: row.execution_id,
        tenantId: row.tenant_id,
        stepNumber: row.step_number,
        stepType: row.step_type,
        status: row.status,
        attempt: row.attempt,
        sideEffecting: row.side_effecting,
        startedAt: asIso(row.started_at),
        ...(row.completed_at
            ? { completedAt: asIso(row.completed_at) }
            : {}),
        ...(row.decision_type ? { decisionType: row.decision_type } : {}),
        ...(row.reason_code
            ? {
                reasonCode: row.reason_code
            }
            : {}),
        observationRefs: Array.isArray(refs) ? refs : [],
        ...(row.error_code ? { errorCode: row.error_code } : {})
    };
}
function mapCheckpoint(row) {
    return {
        checkpointId: row.checkpoint_id,
        executionId: row.execution_id,
        tenantId: row.tenant_id,
        checkpointVersion: row.checkpoint_version,
        runtimeProfile: row.runtime_profile,
        runtimeVersion: row.runtime_version,
        orchestratorVersion: row.orchestrator_version,
        stepNumber: row.step_number,
        state: jsonValue(row.state),
        budgetUsage: jsonValue(row.budget_usage),
        createdAt: asIso(row.created_at),
        digest: row.digest
    };
}
function isPool(connection) {
    return typeof connection.connect === 'function';
}
/**
 * Durable Phase 3 step/checkpoint authority. Tenant scoping is inherited from
 * the Phase 2 connection discipline; checkpoint integrity is validated before
 * every write and after every read.
 */
class PostgresExecutionStepStore {
    connection;
    clock;
    constructor(connection, options = {}) {
        this.connection = connection;
        this.clock = options.clock ?? (() => new Date());
    }
    recordStep(step) {
        const tenant = platform_1.TenantIdSchema.parse(step.tenantId);
        if (!Number.isSafeInteger(step.stepNumber) || step.stepNumber < 1) {
            throw new harness_1.CheckpointError('step_conflict', 'A step number must be a positive integer');
        }
        return this.run(tenant, (client) => transaction(client, async () => {
            const existing = await client.query(`SELECT ${stepColumns}
             FROM operational_execution_steps
            WHERE tenant_id = $1 AND execution_id = $2 AND step_number = $3
            FOR UPDATE`, [tenant, step.executionId, step.stepNumber]);
            const current = existing.rows[0];
            if (current) {
                if (current.step_id !== step.stepId) {
                    throw new harness_1.CheckpointError('step_conflict', 'A different step already occupies this step number');
                }
                if (current.status !== step.status &&
                    !(0, harness_contracts_1.isStepTransitionAllowed)(current.status, step.status)) {
                    throw new harness_1.CheckpointError('step_transition', `Step transition ${current.status} -> ${step.status} is not allowed`);
                }
                await client.query(`UPDATE operational_execution_steps
                SET status = $4, attempt = $5, side_effecting = $6,
                    decision_type = $7, reason_code = $8, error_code = $9,
                    observation_refs = $10::jsonb,
                    started_at = $11, completed_at = $12
              WHERE tenant_id = $1 AND execution_id = $2 AND step_number = $3`, [
                    tenant,
                    step.executionId,
                    step.stepNumber,
                    step.status,
                    step.attempt,
                    step.sideEffecting,
                    step.decisionType ?? null,
                    step.reasonCode ?? null,
                    step.errorCode ?? null,
                    jsonText(step.observationRefs, 'observation refs'),
                    step.startedAt,
                    step.completedAt ?? null
                ]);
                return;
            }
            const blocking = await client.query(`SELECT step_number
             FROM operational_execution_steps
            WHERE tenant_id = $1 AND execution_id = $2
              AND step_number < $3
              AND status NOT IN ('SUCCEEDED', 'FAILED', 'SKIPPED', 'WAITING')
            ORDER BY step_number ASC
            LIMIT 1`, [tenant, step.executionId, step.stepNumber]);
            if (blocking.rows[0]) {
                throw new harness_1.CheckpointError('step_transition', `Step ${step.stepNumber} cannot start before step ${blocking.rows[0].step_number} settles`);
            }
            await client.query(`INSERT INTO operational_execution_steps
             (tenant_id, execution_id, step_number, step_id, step_type, status,
              attempt, side_effecting, decision_type, reason_code, error_code,
              observation_refs, started_at, completed_at)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12::jsonb,
                   $13, $14)`, [
                tenant,
                step.executionId,
                step.stepNumber,
                step.stepId,
                step.stepType,
                step.status,
                step.attempt,
                step.sideEffecting,
                step.decisionType ?? null,
                step.reasonCode ?? null,
                step.errorCode ?? null,
                jsonText(step.observationRefs, 'observation refs'),
                step.startedAt,
                step.completedAt ?? null
            ]);
        }));
    }
    listSteps(tenantId, executionId) {
        const tenant = platform_1.TenantIdSchema.parse(tenantId);
        const id = text(executionId, 'executionId');
        return this.run(tenant, async (client) => {
            const result = await client.query(`SELECT ${stepColumns}
           FROM operational_execution_steps
          WHERE tenant_id = $1 AND execution_id = $2
          ORDER BY step_number ASC`, [tenant, id]);
            return result.rows.map(mapStep);
        });
    }
    saveCheckpoint(checkpoint) {
        const tenant = platform_1.TenantIdSchema.parse(checkpoint.tenantId);
        (0, harness_1.validateCheckpointIntegrity)(checkpoint, {
            tenantId: checkpoint.tenantId,
            executionId: checkpoint.executionId
        });
        return this.run(tenant, (client) => transaction(client, async () => {
            await client.query(`INSERT INTO operational_execution_checkpoints
             (tenant_id, execution_id, checkpoint_id, checkpoint_version,
              runtime_profile, runtime_version, orchestrator_version,
              step_number, state, budget_usage, digest, created_at)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9::jsonb, $10::jsonb,
                   $11, $12)
           ON CONFLICT (tenant_id, execution_id) DO UPDATE
             SET checkpoint_id = EXCLUDED.checkpoint_id,
                 checkpoint_version = EXCLUDED.checkpoint_version,
                 runtime_profile = EXCLUDED.runtime_profile,
                 runtime_version = EXCLUDED.runtime_version,
                 orchestrator_version = EXCLUDED.orchestrator_version,
                 step_number = EXCLUDED.step_number,
                 state = EXCLUDED.state,
                 budget_usage = EXCLUDED.budget_usage,
                 digest = EXCLUDED.digest,
                 created_at = EXCLUDED.created_at`, [
                tenant,
                checkpoint.executionId,
                checkpoint.checkpointId,
                checkpoint.checkpointVersion,
                checkpoint.runtimeProfile,
                checkpoint.runtimeVersion,
                checkpoint.orchestratorVersion,
                checkpoint.stepNumber,
                jsonText(checkpoint.state, 'checkpoint state'),
                jsonText(checkpoint.budgetUsage, 'checkpoint budget usage'),
                checkpoint.digest,
                checkpoint.createdAt
            ]);
        }));
    }
    loadCheckpoint(tenantId, executionId) {
        const tenant = platform_1.TenantIdSchema.parse(tenantId);
        const id = text(executionId, 'executionId');
        return this.run(tenant, async (client) => {
            const result = await client.query(`SELECT ${checkpointColumns}
           FROM operational_execution_checkpoints
          WHERE tenant_id = $1 AND execution_id = $2`, [tenant, id]);
            const row = result.rows[0];
            if (!row)
                return null;
            const checkpoint = mapCheckpoint(row);
            (0, harness_1.validateCheckpointIntegrity)(checkpoint, { tenantId, executionId: id });
            return checkpoint;
        });
    }
    async run(tenant, operation) {
        if (isPool(this.connection)) {
            return (0, tenant_scoped_postgres_ts_1.withTenantContext)(this.connection, tenant, (client) => operation(client));
        }
        return operation(this.connection);
    }
}
exports.PostgresExecutionStepStore = PostgresExecutionStepStore;
async function transaction(client, operation) {
    await client.query('BEGIN');
    try {
        const result = await operation();
        await client.query('COMMIT');
        return result;
    }
    catch (error) {
        await client.query('ROLLBACK').catch(() => undefined);
        throw error;
    }
}
//# sourceMappingURL=operational-step-postgres.js.map