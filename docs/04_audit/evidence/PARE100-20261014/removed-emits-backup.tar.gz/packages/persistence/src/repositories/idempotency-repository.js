"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IdempotencyRepository = void 0;
class IdempotencyRepository {
    db;
    constructor(db) {
        this.db = db;
    }
    find(key) {
        return (this.db.state.idempotency.find((record) => record.key === key)
            ?.resourceId ?? null);
    }
    save(key, resourceId) {
        if (this.find(key))
            return;
        this.db.state.idempotency = [
            ...this.db.state.idempotency,
            { key, resourceId, createdAt: new Date() }
        ];
    }
}
exports.IdempotencyRepository = IdempotencyRepository;
//# sourceMappingURL=idempotency-repository.js.map