import { type TenantId } from '@cvg/platform';
import type { InMemoryDatabase } from './db.ts';
import type { DatabaseState } from './schema.ts';
export interface DatabaseSnapshot {
    formatVersion: 1;
    capturedAt: string;
    digest: string;
    state: DatabaseState;
}
export declare function createDatabaseSnapshot(db: InMemoryDatabase, options?: {
    tenantId?: TenantId;
}): DatabaseSnapshot;
export declare function restoreDatabaseSnapshot(db: InMemoryDatabase, snapshot: DatabaseSnapshot, options?: {
    tenantId?: TenantId;
}): {
    digest: string;
    restoredAt: string;
};
export declare function digestDatabaseState(state: DatabaseState): string;
