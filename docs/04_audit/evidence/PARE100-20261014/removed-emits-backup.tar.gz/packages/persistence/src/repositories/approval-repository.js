"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApprovalRepository = void 0;
const shared_1 = require("@cvg/shared");
const platform_1 = require("@cvg/platform");
const db_ts_1 = require("../db.js");
const audit_repository_ts_1 = require("./audit-repository.js");
const attendance_approval_ts_1 = require("../attendance-approval.js");
class ApprovalRepository {
    db;
    constructor(db) {
        this.db = db;
    }
    save(request, rawTenantId) {
        const tenantId = rawTenantId ? platform_1.TenantIdSchema.parse(rawTenantId) : undefined;
        if (tenantId && !this.sessionBelongsToTenant(request.sessionId, tenantId)) {
            throw new shared_1.DomainError('invalid_action', 'Session not found');
        }
        (0, attendance_approval_ts_1.assertApprovalCreation)(request);
        if (this.db.state.approvals.some((approval) => approval.id === request.id)) {
            throw new shared_1.DomainError('conflict', 'Approval request already exists');
        }
        this.db.state.approvals = [
            ...this.db.state.approvals,
            (0, attendance_approval_ts_1.cloneAttendanceApproval)(request)
        ];
        return (0, attendance_approval_ts_1.cloneAttendanceApproval)(request);
    }
    decideWithAudit(input, rawTenantId) {
        input = (0, attendance_approval_ts_1.validateAttendanceDecision)(input);
        const tenantId = rawTenantId ? platform_1.TenantIdSchema.parse(rawTenantId) : undefined;
        const current = this.findById(input.approvalRequestId, tenantId);
        if (!current)
            throw new shared_1.DomainError('invalid_action', 'Approval request not found');
        if (current.status !== 'pending')
            throw new shared_1.DomainError('conflict', 'Approval request is no longer pending');
        const decided = {
            ...current,
            status: input.decision,
            decidedBy: input.operatorId,
            decidedAt: new Date()
        };
        // Stage both writes before publishing either; audit preparation may throw.
        const staged = new db_ts_1.InMemoryDatabase({ ...this.db.state });
        new audit_repository_ts_1.AuditRepository(staged).append((0, attendance_approval_ts_1.attendanceDecisionAudit)(decided, input, tenantId), tenantId);
        const approvals = this.db.state.approvals.map((item) => item.id === decided.id ? (0, attendance_approval_ts_1.cloneAttendanceApproval)(decided) : item);
        this.db.state.approvals = approvals;
        this.db.state.auditEvents = staged.state.auditEvents;
        return (0, attendance_approval_ts_1.cloneAttendanceApproval)(decided);
    }
    findById(id, rawTenantId) {
        const tenantId = rawTenantId ? platform_1.TenantIdSchema.parse(rawTenantId) : undefined;
        const found = this.db.state.approvals.find((approval) => approval.id === id &&
            (!tenantId || this.sessionBelongsToTenant(approval.sessionId, tenantId)));
        return found ? (0, attendance_approval_ts_1.cloneAttendanceApproval)(found) : null;
    }
    list(rawTenantId) {
        const tenantId = rawTenantId ? platform_1.TenantIdSchema.parse(rawTenantId) : undefined;
        return this.db.state.approvals
            .filter((approval) => !tenantId || this.sessionBelongsToTenant(approval.sessionId, tenantId))
            .map(attendance_approval_ts_1.cloneAttendanceApproval);
    }
    sessionBelongsToTenant(sessionId, tenantId) {
        const session = this.db.state.sessions.find((item) => item.id === sessionId);
        const conversation = session
            ? this.db.state.conversations.find((item) => item.id === session.conversationId)
            : undefined;
        return conversation?.tenantId === tenantId;
    }
}
exports.ApprovalRepository = ApprovalRepository;
//# sourceMappingURL=approval-repository.js.map