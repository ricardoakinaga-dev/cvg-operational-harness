import type { InMemoryDatabase } from '../db.ts';
export declare class IdempotencyRepository {
    private readonly db;
    constructor(db: InMemoryDatabase);
    find(key: string): string | null;
    save(key: string, resourceId: string): void;
}
