"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostgresJourneyRepository = void 0;
const shared_1 = require("@cvg/shared");
const platform_1 = require("@cvg/platform");
const journeys_ts_1 = require("./journeys.js");
const postgres_ts_1 = require("./postgres.js");
const tenant_scoped_postgres_ts_1 = require("./tenant-scoped-postgres.js");
const ownerDraftColumns = `
  tenant_id, id, conversation_id, session_id, phone, name, candidate_ids,
  status, idempotency_key, created_at, updated_at, expires_at`;
const patientDraftColumns = `
  tenant_id, id, owner_draft_id, owner_candidate_id, conversation_id,
  session_id, name, species, candidate_ids, status, idempotency_key,
  created_at, updated_at, expires_at`;
const appointmentDraftColumns = `
  tenant_id, id, patient_draft_id, conversation_id, session_id, slot,
  source_version, status, confirmation_blocked, idempotency_key,
  created_at, updated_at, expires_at`;
function stringArray(value) {
    if (!Array.isArray(value))
        return [];
    return value.filter((item) => typeof item === 'string');
}
function mapOwnerDraftRow(row) {
    return {
        tenantId: row.tenant_id,
        id: row.id,
        conversationId: row.conversation_id,
        sessionId: row.session_id,
        phone: row.phone,
        name: row.name,
        candidateIds: stringArray(row.candidate_ids),
        status: row.status,
        idempotencyKey: row.idempotency_key,
        createdAt: new Date(row.created_at),
        updatedAt: new Date(row.updated_at),
        expiresAt: new Date(row.expires_at)
    };
}
function mapPatientDraftRow(row) {
    return {
        tenantId: row.tenant_id,
        id: row.id,
        ownerDraftId: row.owner_draft_id,
        ownerCandidateId: row.owner_candidate_id,
        conversationId: row.conversation_id,
        sessionId: row.session_id,
        name: row.name,
        species: row.species,
        candidateIds: stringArray(row.candidate_ids),
        status: row.status,
        idempotencyKey: row.idempotency_key,
        createdAt: new Date(row.created_at),
        updatedAt: new Date(row.updated_at),
        expiresAt: new Date(row.expires_at)
    };
}
function mapAppointmentDraftRow(row) {
    return {
        tenantId: row.tenant_id,
        id: row.id,
        patientDraftId: row.patient_draft_id,
        conversationId: row.conversation_id,
        sessionId: row.session_id,
        slot: row.slot,
        sourceVersion: row.source_version,
        status: row.status,
        confirmationBlocked: true,
        idempotencyKey: row.idempotency_key,
        createdAt: new Date(row.created_at),
        updatedAt: new Date(row.updated_at),
        expiresAt: new Date(row.expires_at)
    };
}
/**
 * Tenant-scoped PostgreSQL journey drafts.
 *
 * Every operation runs through a tenant-scoped context; mutations commit in a
 * short transaction with their audit event (`withTenantTransaction`), so RLS
 * and the row-level
 * predicates always see exactly one tenant. Drafts are never deleted: expiry
 * marks `status = 'expired'` and keeps the row as evidence. Appointment drafts
 * are draft-only (`confirmation_blocked = true`); no real confirmation state
 * exists.
 */
class PostgresJourneyRepository {
    pool;
    clock;
    draftTtlMs;
    constructor(pool, options = {}) {
        this.pool = pool;
        this.clock = options.clock ?? (() => new Date());
        this.draftTtlMs = options.draftTtlMs ?? journeys_ts_1.DEFAULT_DRAFT_TTL_MS;
        if (!Number.isSafeInteger(this.draftTtlMs) || this.draftTtlMs < 1_000) {
            throw new shared_1.DomainError('validation_failed', 'Draft TTL is invalid');
        }
    }
    searchOwnerByPhone(rawTenantId, rawPhone) {
        const tenantId = platform_1.TenantIdSchema.parse(rawTenantId);
        return (0, tenant_scoped_postgres_ts_1.withTenantTransaction)(this.pool, tenantId, (client) => this.searchOwnerByPhoneScoped(client, tenantId, rawPhone));
    }
    createOwnerDraft(input) {
        const tenantId = platform_1.TenantIdSchema.parse(input.tenantId);
        return (0, tenant_scoped_postgres_ts_1.withTenantTransaction)(this.pool, tenantId, (client) => this.createOwnerDraftScoped(client, tenantId, input));
    }
    listOwnerDrafts(rawTenantId) {
        const tenantId = platform_1.TenantIdSchema.parse(rawTenantId);
        return (0, tenant_scoped_postgres_ts_1.withTenantTransaction)(this.pool, tenantId, async (client) => {
            await this.expireOwnerDraftsScoped(client, tenantId);
            const result = await client.query(`SELECT ${ownerDraftColumns}
         FROM journey_owner_drafts
         WHERE tenant_id = $1
         ORDER BY created_at ASC, id ASC`, [tenantId]);
            return result.rows.map((row) => (0, journeys_ts_1.cloneOwnerDraft)(mapOwnerDraftRow(row)));
        });
    }
    findOwnerDraft(rawTenantId, id) {
        const tenantId = platform_1.TenantIdSchema.parse(rawTenantId);
        return (0, tenant_scoped_postgres_ts_1.withTenantTransaction)(this.pool, tenantId, async (client) => {
            const result = await client.query(`SELECT ${ownerDraftColumns}
         FROM journey_owner_drafts
         WHERE tenant_id = $1 AND id = $2
         LIMIT 1`, [tenantId, id]);
            const row = result.rows[0];
            if (!row)
                return null;
            return this.expireOwnerDraftRow(client, tenantId, row);
        });
    }
    searchPatient(input) {
        const tenantId = platform_1.TenantIdSchema.parse(input.tenantId);
        return (0, tenant_scoped_postgres_ts_1.withTenantTransaction)(this.pool, tenantId, (client) => this.searchPatientScoped(client, tenantId, input));
    }
    listPatientDrafts(rawTenantId) {
        const tenantId = platform_1.TenantIdSchema.parse(rawTenantId);
        return (0, tenant_scoped_postgres_ts_1.withTenantTransaction)(this.pool, tenantId, async (client) => {
            await this.expirePatientDraftsScoped(client, tenantId);
            const result = await client.query(`SELECT ${patientDraftColumns}
         FROM journey_patient_drafts
         WHERE tenant_id = $1
         ORDER BY created_at ASC, id ASC`, [tenantId]);
            return result.rows.map((row) => (0, journeys_ts_1.clonePatientDraft)(mapPatientDraftRow(row)));
        });
    }
    findPatientDraft(rawTenantId, id) {
        const tenantId = platform_1.TenantIdSchema.parse(rawTenantId);
        return (0, tenant_scoped_postgres_ts_1.withTenantTransaction)(this.pool, tenantId, async (client) => {
            const result = await client.query(`SELECT ${patientDraftColumns}
         FROM journey_patient_drafts
         WHERE tenant_id = $1 AND id = $2
         LIMIT 1`, [tenantId, id]);
            const row = result.rows[0];
            if (!row)
                return null;
            return this.expirePatientDraftRow(client, tenantId, row);
        });
    }
    createPatientDraft(input) {
        const tenantId = platform_1.TenantIdSchema.parse(input.tenantId);
        return (0, tenant_scoped_postgres_ts_1.withTenantTransaction)(this.pool, tenantId, (client) => this.createPatientDraftScoped(client, tenantId, input));
    }
    linkPatient(input) {
        const tenantId = platform_1.TenantIdSchema.parse(input.tenantId);
        return (0, tenant_scoped_postgres_ts_1.withTenantTransaction)(this.pool, tenantId, async (client) => {
            const draft = await this.requirePatientDraftScoped(client, tenantId, input.patientDraftId);
            if (draft.status !== 'draft') {
                throw new shared_1.DomainError('conflict', 'Patient draft is not linkable');
            }
            if (draft.candidateIds.length !== 1 ||
                draft.candidateIds[0] !== input.candidateId) {
                throw new shared_1.DomainError('conflict', 'Patient candidate is ambiguous or invalid');
            }
            const now = this.now();
            const updated = await client.query(`UPDATE journey_patient_drafts
         SET status = 'linked', updated_at = $3
         WHERE tenant_id = $1 AND id = $2 AND status = 'draft'
         RETURNING ${patientDraftColumns}`, [tenantId, draft.id, now]);
            const row = updated.rows[0];
            if (!row) {
                throw new shared_1.DomainError('conflict', 'Patient draft is not linkable');
            }
            await this.appendJourneyAuditScoped(client, tenantId, 'patient_linked', draft.id, draft.conversationId, draft.sessionId, input.auditContext, { candidateId: input.candidateId });
            return (0, journeys_ts_1.clonePatientDraft)(mapPatientDraftRow(row));
        });
    }
    findAvailableSlots(rawTenantId, limit = 2) {
        const tenantId = platform_1.TenantIdSchema.parse(rawTenantId);
        return (0, journeys_ts_1.buildJourneySlots)(tenantId, this.now(), limit);
    }
    createAppointmentDraft(input) {
        const tenantId = platform_1.TenantIdSchema.parse(input.tenantId);
        return (0, tenant_scoped_postgres_ts_1.withTenantTransaction)(this.pool, tenantId, (client) => this.createAppointmentDraftScoped(client, tenantId, input));
    }
    listAppointmentDrafts(rawTenantId) {
        const tenantId = platform_1.TenantIdSchema.parse(rawTenantId);
        return (0, tenant_scoped_postgres_ts_1.withTenantTransaction)(this.pool, tenantId, async (client) => {
            await this.expireAppointmentDraftsScoped(client, tenantId);
            const result = await client.query(`SELECT ${appointmentDraftColumns}
         FROM journey_appointment_drafts
         WHERE tenant_id = $1
         ORDER BY created_at ASC, id ASC`, [tenantId]);
            return result.rows.map((row) => (0, journeys_ts_1.cloneAppointmentDraft)(mapAppointmentDraftRow(row)));
        });
    }
    createJourneyTask(input) {
        const tenantId = platform_1.TenantIdSchema.parse(input.tenantId);
        return (0, tenant_scoped_postgres_ts_1.withTenantTransaction)(this.pool, tenantId, (client) => new postgres_ts_1.PostgresRuntimeRepository(client, {
            tenantIsolation: true,
            clock: this.clock
        }).createTask({
            sessionId: input.sessionId,
            title: (0, journeys_ts_1.boundedText)(input.title, 'title'),
            description: (0, journeys_ts_1.boundedText)(input.description, 'description'),
            priority: input.priority ?? 'medium',
            source: 'journey-r3',
            idempotencyKey: (0, journeys_ts_1.boundedKey)(input.idempotencyKey)
        }, tenantId, async (task) => {
            const context = await this.resolveJourneyContextScoped(client, tenantId, undefined, input.sessionId);
            await this.appendJourneyAuditScoped(client, tenantId, 'journey_task_created', task.id, context.conversationId, context.sessionId, input.auditContext);
        }));
    }
    recordHandoff(input) {
        const tenantId = platform_1.TenantIdSchema.parse(input.tenantId);
        return (0, tenant_scoped_postgres_ts_1.withTenantTransaction)(this.pool, tenantId, async (client) => {
            const context = await this.resolveJourneyContextScoped(client, tenantId, input.conversationId, input.sessionId);
            await this.appendJourneyAuditScoped(client, tenantId, 'journey_handoff', context.conversationId ??
                context.sessionId ??
                (0, shared_1.createDomainId)('handoff'), context.conversationId, context.sessionId, input.auditContext, {
                intent: (0, journeys_ts_1.boundedText)(input.intent, 'intent'),
                risk: (0, journeys_ts_1.boundedText)(input.risk, 'risk'),
                pendingCount: Math.min(input.pendingItems?.length ?? 0, 20),
                nextStep: (0, journeys_ts_1.boundedText)(input.nextStep, 'nextStep')
            });
        });
    }
    async searchOwnerByPhoneScoped(client, tenantId, rawPhone) {
        const phone = (0, journeys_ts_1.normalizePhone)(rawPhone);
        await this.expireOwnerDraftsScoped(client, tenantId);
        const drafts = await client.query(`SELECT candidate_ids FROM journey_owner_drafts
       WHERE tenant_id = $1 AND phone = $2
         AND status IN ('draft', 'linked')`, [tenantId, phone]);
        const byId = new Map();
        for (const owner of (0, journeys_ts_1.syntheticOwners)(tenantId)) {
            if (owner.phone === phone)
                byId.set(owner.id, owner.candidate);
        }
        for (const draft of drafts.rows) {
            for (const candidateId of stringArray(draft.candidate_ids)) {
                const candidate = (0, journeys_ts_1.syntheticOwners)(tenantId).find((owner) => owner.id === candidateId);
                if (candidate)
                    byId.set(candidate.id, candidate.candidate);
            }
        }
        return [...byId.values()].map(journeys_ts_1.cloneCandidate);
    }
    async createOwnerDraftScoped(client, tenantId, input) {
        const context = await this.resolveJourneyContextScoped(client, tenantId, input.conversationId, input.sessionId);
        const idempotencyKey = (0, journeys_ts_1.boundedKey)(input.idempotencyKey);
        const existing = await this.selectOwnerDraftByKey(client, tenantId, idempotencyKey);
        if (existing)
            return this.expireOwnerDraftRow(client, tenantId, existing);
        const now = this.now();
        const phone = input.phone == null ? null : (0, journeys_ts_1.normalizePhone)(input.phone);
        const name = input.name == null ? null : (0, journeys_ts_1.boundedOptionalText)(input.name, 'name');
        const candidates = phone
            ? await this.searchOwnerByPhoneScoped(client, tenantId, phone)
            : [];
        const draft = {
            tenantId,
            id: (0, shared_1.createDomainId)('owner_draft'),
            conversationId: context.conversationId,
            sessionId: context.sessionId,
            phone,
            name,
            candidateIds: candidates.map((candidate) => candidate.id),
            status: 'draft',
            idempotencyKey,
            createdAt: now,
            updatedAt: now,
            expiresAt: new Date(now.getTime() + this.draftTtlMs)
        };
        const inserted = await client.query(`INSERT INTO journey_owner_drafts
         (tenant_id, id, conversation_id, session_id, phone, name,
          candidate_ids, status, idempotency_key, created_at, updated_at,
          expires_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb, $8, $9, $10, $11, $12)
       ON CONFLICT (tenant_id, idempotency_key) DO NOTHING
       RETURNING ${ownerDraftColumns}`, [
            tenantId,
            draft.id,
            draft.conversationId,
            draft.sessionId,
            draft.phone,
            draft.name,
            JSON.stringify(draft.candidateIds),
            draft.status,
            draft.idempotencyKey,
            draft.createdAt,
            draft.updatedAt,
            draft.expiresAt
        ]);
        if (!inserted.rows[0]) {
            const winner = await this.selectOwnerDraftByKey(client, tenantId, idempotencyKey);
            if (!winner) {
                throw new shared_1.DomainError('conflict', 'Owner draft insert was not stored');
            }
            return this.expireOwnerDraftRow(client, tenantId, winner);
        }
        await this.appendJourneyAuditScoped(client, tenantId, 'owner_draft_created', draft.id, draft.conversationId, draft.sessionId, input.auditContext);
        return (0, journeys_ts_1.cloneOwnerDraft)(draft);
    }
    async searchPatientScoped(client, tenantId, input) {
        const ownerDraft = input.ownerDraftId
            ? await this.requireOwnerDraftScoped(client, tenantId, input.ownerDraftId)
            : null;
        const ownerCandidateId = input.ownerCandidateId ?? ownerDraft?.candidateIds[0] ?? null;
        if (ownerDraft &&
            ownerDraft.candidateIds.length > 1 &&
            !input.ownerCandidateId) {
            return [];
        }
        const name = input.name == null
            ? null
            : (0, journeys_ts_1.boundedOptionalText)(input.name, 'name')?.toLocaleLowerCase();
        return (0, journeys_ts_1.syntheticPatients)(tenantId)
            .filter((patient) => !ownerCandidateId || patient.ownerId === ownerCandidateId)
            .filter((patient) => !name || patient.name.toLocaleLowerCase().includes(name))
            .map((patient) => (0, journeys_ts_1.cloneCandidate)(patient.candidate));
    }
    async createPatientDraftScoped(client, tenantId, input) {
        const ownerDraft = input.ownerDraftId
            ? await this.requireOwnerDraftScoped(client, tenantId, input.ownerDraftId)
            : null;
        const context = await this.resolveJourneyContextScoped(client, tenantId, input.conversationId, input.sessionId, ownerDraft
            ? {
                conversationId: ownerDraft.conversationId,
                sessionId: ownerDraft.sessionId
            }
            : undefined);
        const idempotencyKey = (0, journeys_ts_1.boundedKey)(input.idempotencyKey);
        const existing = await this.selectPatientDraftByKey(client, tenantId, idempotencyKey);
        if (existing)
            return this.expirePatientDraftRow(client, tenantId, existing);
        const ownerCandidateId = input.ownerCandidateId ?? null;
        if (ownerDraft &&
            ownerCandidateId &&
            !ownerDraft.candidateIds.includes(ownerCandidateId)) {
            throw new shared_1.DomainError('invalid_action', 'Owner candidate is not in the draft');
        }
        if (ownerDraft && ownerDraft.candidateIds.length > 1 && !ownerCandidateId) {
            throw new shared_1.DomainError('conflict', 'Owner identity is ambiguous');
        }
        const name = input.name == null ? null : (0, journeys_ts_1.boundedOptionalText)(input.name, 'name');
        const species = input.species == null
            ? null
            : (0, journeys_ts_1.boundedOptionalText)(input.species, 'species');
        const candidates = await this.searchPatientScoped(client, tenantId, {
            tenantId,
            ...(input.ownerDraftId ? { ownerDraftId: input.ownerDraftId } : {}),
            ...(ownerCandidateId ? { ownerCandidateId } : {}),
            ...(name ? { name } : {})
        });
        const now = this.now();
        const draft = {
            tenantId,
            id: (0, shared_1.createDomainId)('patient_draft'),
            ownerDraftId: input.ownerDraftId ?? null,
            ownerCandidateId,
            conversationId: context.conversationId,
            sessionId: context.sessionId,
            name,
            species,
            candidateIds: candidates.map((candidate) => candidate.id),
            status: 'draft',
            idempotencyKey,
            createdAt: now,
            updatedAt: now,
            expiresAt: new Date(now.getTime() + this.draftTtlMs)
        };
        const inserted = await client.query(`INSERT INTO journey_patient_drafts
         (tenant_id, id, owner_draft_id, owner_candidate_id, conversation_id,
          session_id, name, species, candidate_ids, status, idempotency_key,
          created_at, updated_at, expires_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9::jsonb, $10, $11, $12, $13, $14)
       ON CONFLICT (tenant_id, idempotency_key) DO NOTHING
       RETURNING ${patientDraftColumns}`, [
            tenantId,
            draft.id,
            draft.ownerDraftId,
            draft.ownerCandidateId,
            draft.conversationId,
            draft.sessionId,
            draft.name,
            draft.species,
            JSON.stringify(draft.candidateIds),
            draft.status,
            draft.idempotencyKey,
            draft.createdAt,
            draft.updatedAt,
            draft.expiresAt
        ]);
        if (!inserted.rows[0]) {
            const winner = await this.selectPatientDraftByKey(client, tenantId, idempotencyKey);
            if (!winner) {
                throw new shared_1.DomainError('conflict', 'Patient draft insert was not stored');
            }
            return this.expirePatientDraftRow(client, tenantId, winner);
        }
        await this.appendJourneyAuditScoped(client, tenantId, 'patient_draft_created', draft.id, draft.conversationId, draft.sessionId, input.auditContext);
        return (0, journeys_ts_1.clonePatientDraft)(draft);
    }
    async createAppointmentDraftScoped(client, tenantId, input) {
        const patientDraft = await this.requirePatientDraftScoped(client, tenantId, input.patientDraftId);
        const context = await this.resolveJourneyContextScoped(client, tenantId, input.conversationId, input.sessionId, {
            conversationId: patientDraft.conversationId,
            sessionId: patientDraft.sessionId
        });
        const idempotencyKey = (0, journeys_ts_1.boundedKey)(input.idempotencyKey);
        const existing = await this.selectAppointmentDraftByKey(client, tenantId, idempotencyKey);
        if (existing) {
            return this.expireAppointmentDraftRow(client, tenantId, existing);
        }
        if (patientDraft.status !== 'linked') {
            throw new shared_1.DomainError('invalid_action', 'Patient must be linked before proposing a slot');
        }
        const slot = (0, journeys_ts_1.buildJourneySlots)(tenantId, this.now(), 8).find((candidate) => candidate.startsAt === input.slot || candidate.id === input.slot);
        if (!slot) {
            throw new shared_1.DomainError('conflict', 'Slot is unavailable or expired');
        }
        const now = this.now();
        const draft = {
            tenantId,
            id: (0, shared_1.createDomainId)('appointment_draft'),
            patientDraftId: patientDraft.id,
            conversationId: context.conversationId,
            sessionId: context.sessionId,
            slot: slot.startsAt,
            sourceVersion: slot.sourceVersion,
            status: 'awaiting_approval',
            confirmationBlocked: true,
            idempotencyKey,
            createdAt: now,
            updatedAt: now,
            expiresAt: new Date(now.getTime() + this.draftTtlMs)
        };
        const inserted = await client.query(`INSERT INTO journey_appointment_drafts
         (tenant_id, id, patient_draft_id, conversation_id, session_id, slot,
          source_version, status, confirmation_blocked, idempotency_key,
          created_at, updated_at, expires_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, true, $9, $10, $11, $12)
       ON CONFLICT (tenant_id, idempotency_key) DO NOTHING
       RETURNING ${appointmentDraftColumns}`, [
            tenantId,
            draft.id,
            draft.patientDraftId,
            draft.conversationId,
            draft.sessionId,
            draft.slot,
            draft.sourceVersion,
            draft.status,
            draft.idempotencyKey,
            draft.createdAt,
            draft.updatedAt,
            draft.expiresAt
        ]);
        if (!inserted.rows[0]) {
            const winner = await this.selectAppointmentDraftByKey(client, tenantId, idempotencyKey);
            if (!winner) {
                throw new shared_1.DomainError('conflict', 'Appointment draft insert was not stored');
            }
            return this.expireAppointmentDraftRow(client, tenantId, winner);
        }
        await this.appendJourneyAuditScoped(client, tenantId, 'appointment_draft_created', draft.id, draft.conversationId, draft.sessionId, input.auditContext);
        return (0, journeys_ts_1.cloneAppointmentDraft)(draft);
    }
    async expireOwnerDraftRow(client, tenantId, row) {
        const draft = mapOwnerDraftRow(row);
        if (draft.status !== 'draft' ||
            draft.expiresAt.getTime() > this.now().getTime()) {
            return (0, journeys_ts_1.cloneOwnerDraft)(draft);
        }
        const now = this.now();
        const updated = await client.query(`UPDATE journey_owner_drafts
       SET status = 'expired', updated_at = $3
       WHERE tenant_id = $1 AND id = $2 AND status = 'draft'
       RETURNING ${ownerDraftColumns}`, [tenantId, draft.id, now]);
        return (0, journeys_ts_1.cloneOwnerDraft)(updated.rows[0]
            ? mapOwnerDraftRow(updated.rows[0])
            : { ...draft, status: 'expired', updatedAt: now });
    }
    async expirePatientDraftRow(client, tenantId, row) {
        const draft = mapPatientDraftRow(row);
        if (draft.status !== 'draft' ||
            draft.expiresAt.getTime() > this.now().getTime()) {
            return (0, journeys_ts_1.clonePatientDraft)(draft);
        }
        const now = this.now();
        const updated = await client.query(`UPDATE journey_patient_drafts
       SET status = 'expired', updated_at = $3
       WHERE tenant_id = $1 AND id = $2 AND status = 'draft'
       RETURNING ${patientDraftColumns}`, [tenantId, draft.id, now]);
        return (0, journeys_ts_1.clonePatientDraft)(updated.rows[0]
            ? mapPatientDraftRow(updated.rows[0])
            : { ...draft, status: 'expired', updatedAt: now });
    }
    async expireAppointmentDraftRow(client, tenantId, row) {
        const draft = mapAppointmentDraftRow(row);
        if (draft.status === 'expired' ||
            draft.status === 'cancelled' ||
            draft.expiresAt.getTime() > this.now().getTime()) {
            return (0, journeys_ts_1.cloneAppointmentDraft)(draft);
        }
        const now = this.now();
        const updated = await client.query(`UPDATE journey_appointment_drafts
       SET status = 'expired', updated_at = $3
       WHERE tenant_id = $1 AND id = $2
         AND status NOT IN ('expired', 'cancelled')
       RETURNING ${appointmentDraftColumns}`, [tenantId, draft.id, now]);
        return (0, journeys_ts_1.cloneAppointmentDraft)(updated.rows[0]
            ? mapAppointmentDraftRow(updated.rows[0])
            : { ...draft, status: 'expired', updatedAt: now });
    }
    async expireOwnerDraftsScoped(client, tenantId) {
        const now = this.now();
        await client.query(`UPDATE journey_owner_drafts
       SET status = 'expired', updated_at = $2
       WHERE tenant_id = $1 AND status = 'draft' AND expires_at <= $2`, [tenantId, now]);
    }
    async expirePatientDraftsScoped(client, tenantId) {
        const now = this.now();
        await client.query(`UPDATE journey_patient_drafts
       SET status = 'expired', updated_at = $2
       WHERE tenant_id = $1 AND status = 'draft' AND expires_at <= $2`, [tenantId, now]);
    }
    async expireAppointmentDraftsScoped(client, tenantId) {
        const now = this.now();
        await client.query(`UPDATE journey_appointment_drafts
       SET status = 'expired', updated_at = $2
       WHERE tenant_id = $1
         AND status NOT IN ('expired', 'cancelled')
         AND expires_at <= $2`, [tenantId, now]);
    }
    async requireOwnerDraftScoped(client, tenantId, id) {
        const result = await client.query(`SELECT ${ownerDraftColumns}
       FROM journey_owner_drafts
       WHERE tenant_id = $1 AND id = $2
       LIMIT 1`, [tenantId, id]);
        const row = result.rows[0];
        if (!row)
            throw new shared_1.DomainError('not_found', 'Owner draft not found');
        const current = await this.expireOwnerDraftRow(client, tenantId, row);
        if (current.status === 'expired') {
            throw new shared_1.DomainError('conflict', 'Owner draft expired');
        }
        return current;
    }
    async requirePatientDraftScoped(client, tenantId, id) {
        const result = await client.query(`SELECT ${patientDraftColumns}
       FROM journey_patient_drafts
       WHERE tenant_id = $1 AND id = $2
       LIMIT 1`, [tenantId, id]);
        const row = result.rows[0];
        if (!row)
            throw new shared_1.DomainError('not_found', 'Patient draft not found');
        const current = await this.expirePatientDraftRow(client, tenantId, row);
        if (current.status === 'expired') {
            throw new shared_1.DomainError('conflict', 'Patient draft expired');
        }
        return current;
    }
    /**
     * Journey references are caller supplied identifiers, so validate their
     * tenant ownership before persisting them in a draft or audit trail.
     * A session may imply its conversation; an explicit pair must agree.
     */
    async resolveJourneyContextScoped(client, tenantId, rawConversationId, rawSessionId, inherited) {
        const conversationId = (0, journeys_ts_1.normalizeOptionalReference)(rawConversationId ?? inherited?.conversationId, 'conversationId');
        const sessionId = (0, journeys_ts_1.normalizeOptionalReference)(rawSessionId ?? inherited?.sessionId, 'sessionId');
        const conversation = conversationId
            ? await client.query(`SELECT tenant_id FROM conversations WHERE id = $1 LIMIT 1`, [conversationId])
            : null;
        const conversationRow = conversation?.rows[0];
        if (conversationRow && conversationRow.tenant_id !== tenantId) {
            throw new shared_1.DomainError('forbidden', 'Journey conversation is outside the tenant scope');
        }
        if (conversationId && !conversationRow) {
            throw new shared_1.DomainError('invalid_action', 'Conversation not found');
        }
        const session = sessionId
            ? await client.query(`SELECT conversation_id FROM sessions WHERE id = $1 LIMIT 1`, [sessionId])
            : null;
        const sessionRow = session?.rows[0];
        if (sessionId && !sessionRow) {
            throw new shared_1.DomainError('invalid_action', 'Session not found');
        }
        let sessionConversationId = null;
        if (sessionRow) {
            sessionConversationId = sessionRow.conversation_id;
            const sessionConversation = await client.query(`SELECT tenant_id FROM conversations WHERE id = $1 LIMIT 1`, [sessionConversationId]);
            if (sessionConversation.rows[0]?.tenant_id !== tenantId) {
                throw new shared_1.DomainError('forbidden', 'Journey session is outside the tenant scope');
            }
        }
        if (conversationId &&
            sessionConversationId &&
            sessionConversationId !== conversationId) {
            throw new shared_1.DomainError('conflict', 'Journey conversation and session do not match');
        }
        return {
            conversationId: conversationId ?? sessionConversationId ?? null,
            sessionId: sessionId ?? null
        };
    }
    async appendJourneyAuditScoped(client, tenantId, action, resourceId, conversationId, sessionId, auditContext, extra = {}) {
        const audit = (0, journeys_ts_1.normalizeJourneyAuditContext)(auditContext, resourceId);
        const payload = (0, shared_1.sanitizeAuditEvidencePayload)({
            journey: action,
            resourceId,
            ...(conversationId ? { conversationId } : {}),
            ...(sessionId ? { sessionId } : {}),
            ...extra
        }).payload;
        await client.query(`INSERT INTO audit_events
         (tenant_id, id, type, actor_type, actor_id, correlation_id,
          policy_version, payload, created_at)
       VALUES
         ($1, $2, 'integration_event', $3, $4, $5,
          'journey-r3', $6::jsonb, $7)`, [
            tenantId,
            (0, shared_1.createDomainId)('audit'),
            audit.actorType,
            audit.actorId,
            audit.correlationId,
            JSON.stringify(payload),
            new Date()
        ]);
    }
    async selectOwnerDraftByKey(client, tenantId, idempotencyKey) {
        const result = await client.query(`SELECT ${ownerDraftColumns}
       FROM journey_owner_drafts
       WHERE tenant_id = $1 AND idempotency_key = $2
       LIMIT 1`, [tenantId, idempotencyKey]);
        return result.rows[0] ?? null;
    }
    async selectPatientDraftByKey(client, tenantId, idempotencyKey) {
        const result = await client.query(`SELECT ${patientDraftColumns}
       FROM journey_patient_drafts
       WHERE tenant_id = $1 AND idempotency_key = $2
       LIMIT 1`, [tenantId, idempotencyKey]);
        return result.rows[0] ?? null;
    }
    async selectAppointmentDraftByKey(client, tenantId, idempotencyKey) {
        const result = await client.query(`SELECT ${appointmentDraftColumns}
       FROM journey_appointment_drafts
       WHERE tenant_id = $1 AND idempotency_key = $2
       LIMIT 1`, [tenantId, idempotencyKey]);
        return result.rows[0] ?? null;
    }
    now() {
        const value = new Date(this.clock());
        if (!Number.isFinite(value.getTime())) {
            throw new shared_1.DomainError('validation_failed', 'Journey clock is invalid');
        }
        return value;
    }
}
exports.PostgresJourneyRepository = PostgresJourneyRepository;
//# sourceMappingURL=journeys-postgres.js.map