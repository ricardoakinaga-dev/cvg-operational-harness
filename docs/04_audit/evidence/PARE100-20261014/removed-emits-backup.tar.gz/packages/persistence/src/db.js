"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InMemoryDatabase = void 0;
exports.createInMemoryState = createInMemoryState;
function createInMemoryState() {
    return {
        conversations: [],
        messages: [],
        sessions: [],
        agentRuns: [],
        toolCalls: [],
        approvals: [],
        tasks: [],
        auditEvents: [],
        auditEvidenceCheckpoints: [],
        idempotency: [],
        outbox: [],
        outboxAttempts: [],
        outboxEffects: [],
        ownerDrafts: [],
        patientDrafts: [],
        appointmentDrafts: []
    };
}
class InMemoryDatabase {
    state;
    constructor(state = createInMemoryState()) {
        this.state = state;
    }
}
exports.InMemoryDatabase = InMemoryDatabase;
//# sourceMappingURL=db.js.map