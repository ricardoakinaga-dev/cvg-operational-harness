"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OutboxRepository = exports.OUTBOX_TAKEOVER_SUPPRESSED_ERROR = exports.DEFAULT_OUTBOX_MAX_PAYLOAD_BYTES = exports.DEFAULT_OUTBOX_RETRY_MAX_MS = exports.DEFAULT_OUTBOX_RETRY_BASE_MS = exports.DEFAULT_OUTBOX_LEASE_MS = exports.DEFAULT_OUTBOX_MAX_ATTEMPTS = exports.DEFAULT_OUTBOX_ENVELOPE_VERSION = void 0;
const shared_1 = require("@cvg/shared");
const platform_1 = require("@cvg/platform");
exports.DEFAULT_OUTBOX_ENVELOPE_VERSION = 1;
exports.DEFAULT_OUTBOX_MAX_ATTEMPTS = 5;
exports.DEFAULT_OUTBOX_LEASE_MS = 30_000;
exports.DEFAULT_OUTBOX_RETRY_BASE_MS = 1_000;
exports.DEFAULT_OUTBOX_RETRY_MAX_MS = 60_000;
exports.DEFAULT_OUTBOX_MAX_PAYLOAD_BYTES = 64 * 1024;
exports.OUTBOX_TAKEOVER_SUPPRESSED_ERROR = 'human takeover active; automatic outbound suppressed';
/**
 * Deterministic in-memory implementation of the durable outbox contract.
 *
 * It intentionally keeps state in `DatabaseState` so tests can inspect every
 * claim and effect. It does not pretend to provide process durability; the
 * PostgreSQL adapter owns that guarantee.
 */
class OutboxRepository {
    db;
    clock;
    maxAttempts;
    leaseMs;
    retryBaseMs;
    retryMaxMs;
    maxPayloadBytes;
    auditWriter;
    constructor(db, options = {}) {
        this.db = db;
        this.clock = options.clock ?? options.now ?? (() => new Date());
        this.maxAttempts = positiveInteger(options.maxAttempts ?? exports.DEFAULT_OUTBOX_MAX_ATTEMPTS, 'maxAttempts');
        this.leaseMs = positiveInteger(options.leaseMs ?? exports.DEFAULT_OUTBOX_LEASE_MS, 'leaseMs');
        this.retryBaseMs = positiveInteger(options.retryBaseMs ??
            options.backoffBaseMs ??
            exports.DEFAULT_OUTBOX_RETRY_BASE_MS, 'retryBaseMs');
        this.retryMaxMs = positiveInteger(options.retryMaxMs ?? options.backoffMaxMs ?? exports.DEFAULT_OUTBOX_RETRY_MAX_MS, 'retryMaxMs');
        if (this.retryMaxMs < this.retryBaseMs) {
            throw new shared_1.DomainError('validation_failed', 'retryMaxMs must be greater than or equal to retryBaseMs');
        }
        this.maxPayloadBytes = positiveInteger(options.maxPayloadBytes ?? exports.DEFAULT_OUTBOX_MAX_PAYLOAD_BYTES, 'maxPayloadBytes');
        this.auditWriter = options.auditWriter;
        this.ensureStateCollections();
    }
    enqueue(inputOrType, payloadOrTx) {
        if (typeof inputOrType === 'string') {
            return this.enqueueLegacy(inputOrType, payloadOrTx);
        }
        const tenantId = requireTenant(inputOrType.tenantId);
        const idempotencyKey = requireIdempotencyKey(inputOrType.idempotencyKey);
        const type = requireEventType(inputOrType.type);
        const payload = validateAndRedactPayload(inputOrType.payload, this.maxPayloadBytes);
        const existing = this.db.state.outbox.find((event) => event.tenantId === tenantId && event.idempotencyKey === idempotencyKey);
        if (existing)
            return cloneEvent(existing);
        const now = this.currentTime();
        const correlationId = inputOrType.correlationId
            ? requireCorrelationId(inputOrType.correlationId)
            : (0, shared_1.createCorrelationId)();
        const id = inputOrType.id ?? inputOrType.eventId ?? (0, shared_1.createDomainId)('outbox');
        if (!id.trim()) {
            throw new shared_1.DomainError('validation_failed', 'Outbox event id is required');
        }
        const event = {
            id,
            type,
            payload,
            tenantId,
            correlationId,
            idempotencyKey,
            envelopeVersion: inputOrType.envelopeVersion ?? exports.DEFAULT_OUTBOX_ENVELOPE_VERSION,
            conversationId: inputOrType.conversationId ?? null,
            sessionId: inputOrType.sessionId ?? null,
            agentId: inputOrType.agentId ?? null,
            agentVersionId: inputOrType.agentVersionId ?? null,
            inboundMessageId: inputOrType.inboundMessageId ?? null,
            status: 'pending',
            createdAt: now,
            availableAt: now,
            attempts: 0,
            leaseOwner: null,
            leaseUntil: null,
            lastError: null,
            processedAt: null,
            deadLetteredAt: null,
            parentEventId: inputOrType.parentEventId ?? null
        };
        this.db.state.outbox = [...this.db.state.outbox, cloneEvent(event)];
        return cloneEvent(event);
    }
    /** Lists only pending events for compatibility with the legacy repository. */
    pending(rawTenantId) {
        const tenantId = rawTenantId ? requireTenant(rawTenantId) : undefined;
        return this.db.state.outbox
            .filter((event) => event.status === 'pending' &&
            (!tenantId || event.tenantId === tenantId))
            .map(cloneEvent);
    }
    findById(eventId, rawTenantId) {
        const tenantId = rawTenantId ? requireTenant(rawTenantId) : undefined;
        const event = this.db.state.outbox.find((candidate) => candidate.id === eventId &&
            (!tenantId || candidate.tenantId === tenantId));
        return event ? cloneEvent(event) : null;
    }
    claimNext(input) {
        const tenantId = requireTenant(input.tenantId);
        const workerId = requireActor(input.workerId, 'workerId');
        const now = this.currentTime();
        const leaseMs = positiveInteger(input.leaseMs ?? this.leaseMs, 'leaseMs');
        const candidate = this.db.state.outbox
            .filter((event) => {
            if (event.tenantId !== tenantId)
                return false;
            if (input.eventId && event.id !== input.eventId)
                return false;
            if (event.status === 'pending') {
                return (!event.availableAt || event.availableAt.getTime() <= now.getTime());
            }
            if (event.status === 'failed') {
                return Boolean(event.availableAt && event.availableAt.getTime() <= now.getTime());
            }
            return (event.status === 'processing' &&
                Boolean(event.leaseUntil && event.leaseUntil.getTime() <= now.getTime()));
        })
            .sort((left, right) => eligibleAt(left) - eligibleAt(right))[0];
        if (!candidate)
            return null;
        if (candidate.status === 'processing') {
            this.markExpiredClaim(candidate);
        }
        const attempts = Math.max(0, candidate.attempts ?? 0) + 1;
        const claimed = {
            ...cloneEvent(candidate),
            status: 'processing',
            attempts,
            leaseOwner: workerId,
            leaseUntil: new Date(now.getTime() + leaseMs),
            lastError: null
        };
        this.replaceEvent(claimed);
        this.db.state.outboxAttempts = [
            ...this.db.state.outboxAttempts,
            {
                eventId: claimed.id,
                attempt: attempts,
                tenantId,
                workerId,
                claimedAt: new Date(now),
                outcome: 'claimed',
                error: null
            }
        ];
        return cloneEvent(claimed);
    }
    ack(input) {
        const tenantId = requireTenant(input.tenantId);
        const workerId = requireActor(input.workerId, 'workerId');
        const now = this.currentTime();
        const current = this.requireOwnedEvent(tenantId, input.eventId, workerId, now);
        const key = requireEventIdempotencyKey(current);
        const journal = this.db.state.outboxEffects.find((effect) => effect.tenantId === tenantId && effect.idempotencyKey === key);
        if (journal) {
            if (journal.eventId !== current.id) {
                throw new shared_1.DomainError('conflict', 'Outbox effect journal points to another event');
            }
            return this.commitAck(current, workerId, cloneValue(journal.result), now);
        }
        if (!input.effect && input.result === undefined) {
            throw new shared_1.DomainError('validation_failed', 'A local effect or result is required before ack');
        }
        const runAck = (takeoverActive) => {
            if (takeoverActive) {
                return this.fail({
                    tenantId,
                    eventId: current.id,
                    workerId,
                    terminal: true,
                    handoff: true,
                    error: exports.OUTBOX_TAKEOVER_SUPPRESSED_ERROR
                });
            }
            const effectResult = input.effect
                ? input.effect(cloneEvent(current))
                : input.result;
            if (isPromiseLike(effectResult)) {
                return Promise.resolve(effectResult).then((value) => this.commitAck(current, workerId, value === undefined && input.result !== undefined
                    ? cloneValue(input.result)
                    : cloneValue(value), this.currentTime()));
            }
            return this.commitAck(current, workerId, effectResult === undefined && input.result !== undefined
                ? cloneValue(input.result)
                : cloneValue(effectResult), now);
        };
        const takeover = resolveTakeoverCheck(input.takeoverActive);
        if (isPromiseLike(takeover)) {
            return Promise.resolve(takeover).then(runAck);
        }
        return runAck(takeover);
    }
    fail(input) {
        const tenantId = requireTenant(input.tenantId);
        const workerId = requireActor(input.workerId, 'workerId');
        const now = this.currentTime();
        const current = this.requireOwnedEvent(tenantId, input.eventId, workerId, now);
        const attempts = Math.max(0, current.attempts ?? 0);
        const error = redactError(input.error);
        const handoff = input.handoff === true;
        const deadLetter = handoff || Boolean(input.terminal) || attempts >= this.maxAttempts;
        const snapshot = this.snapshot();
        try {
            const updated = {
                ...cloneEvent(current),
                status: deadLetter ? 'dead_letter' : 'failed',
                attempts,
                leaseOwner: null,
                leaseUntil: null,
                lastError: error,
                ...(deadLetter
                    ? { deadLetteredAt: new Date(now) }
                    : {
                        availableAt: new Date(now.getTime() + this.retryDelayMs(attempts)),
                        deadLetteredAt: null
                    })
            };
            if (deadLetter)
                delete updated.availableAt;
            this.replaceEvent(updated);
            this.markAttemptOutcome(updated, workerId, handoff ? 'handoff' : deadLetter ? 'dead_letter' : 'failed', error);
            if (handoff) {
                this.markSessionForHandoff(updated, now);
                this.appendAudit(updated, 'handoff', workerId, updated.correlationId ?? (0, shared_1.createCorrelationId)(), {
                    eventId: updated.id,
                    ...(updated.sessionId ? { sessionId: updated.sessionId } : {}),
                    ...(updated.conversationId
                        ? { conversationId: updated.conversationId }
                        : {}),
                    status: updated.status,
                    action: 'human_takeover',
                    attempt: updated.attempts ?? 0,
                    error
                }, now);
            }
            else {
                this.appendTransitionAudit(updated, workerId, deadLetter ? 'dead_letter' : 'failed', error, now);
            }
            return cloneEvent(updated);
        }
        catch (error) {
            this.restore(snapshot);
            throw error;
        }
    }
    requeueDeadLetter(input) {
        const tenantId = requireTenant(input.tenantId);
        const operatorId = requireActor(input.operatorId, 'operatorId');
        const correlationId = requireCorrelationId(input.correlationId);
        const current = this.db.state.outbox.find((event) => event.id === input.eventId && event.tenantId === tenantId);
        if (!current) {
            throw new shared_1.DomainError('not_found', 'Outbox event not found');
        }
        if (current.status !== 'dead_letter') {
            throw new shared_1.DomainError('conflict', 'Only dead-letter events can be requeued');
        }
        const now = this.currentTime();
        const snapshot = this.snapshot();
        const priorError = current.lastError ?? null;
        const priorAttempts = Math.max(0, current.attempts ?? 0);
        try {
            const updated = {
                ...cloneEvent(current),
                status: 'pending',
                attempts: 0,
                availableAt: new Date(now),
                leaseOwner: null,
                leaseUntil: null,
                lastError: null,
                deadLetteredAt: null
            };
            this.replaceEvent(updated);
            this.db.state.outboxAttempts = [
                ...this.db.state.outboxAttempts,
                {
                    eventId: updated.id,
                    attempt: priorAttempts,
                    tenantId,
                    workerId: operatorId,
                    claimedAt: new Date(now),
                    outcome: 'requeued',
                    error: priorError
                }
            ];
            this.appendAudit(updated, 'integration_event', operatorId, correlationId, {
                eventId: updated.id,
                status: 'pending',
                action: 'requeue_dead_letter',
                attempt: priorAttempts,
                error: priorError
            }, now);
            return cloneEvent(updated);
        }
        catch (error) {
            this.restore(snapshot);
            throw error;
        }
    }
    enqueueLegacy(type, payload) {
        const validType = requireEventType(type);
        const event = {
            id: (0, shared_1.createDomainId)('outbox'),
            type: validType,
            payload: validateAndRedactPayload(payload, this.maxPayloadBytes),
            status: 'pending',
            createdAt: this.currentTime()
        };
        this.db.state.outbox = [...this.db.state.outbox, cloneEvent(event)];
        return cloneEvent(event);
    }
    commitAck(current, workerId, result, now) {
        const tenantId = requireTenant(current.tenantId);
        const owned = this.requireOwnedEvent(tenantId, current.id, workerId, now);
        const key = requireEventIdempotencyKey(owned);
        const snapshot = this.snapshot();
        try {
            const safeResult = validateAndRedactResult(result, this.maxPayloadBytes);
            const journal = {
                tenantId,
                idempotencyKey: key,
                eventId: owned.id,
                result: safeResult,
                appliedAt: new Date(now)
            };
            const existing = this.db.state.outboxEffects.find((effect) => effect.tenantId === tenantId && effect.idempotencyKey === key);
            const persistedResult = existing
                ? validateAndRedactResult(existing.result, this.maxPayloadBytes)
                : safeResult;
            if (existing) {
                this.db.state.outboxEffects = this.db.state.outboxEffects.map((candidate) => candidate === existing
                    ? { ...candidate, result: persistedResult }
                    : candidate);
            }
            else {
                this.db.state.outboxEffects = [...this.db.state.outboxEffects, journal];
            }
            const updated = {
                ...cloneEvent(owned),
                status: 'processed',
                leaseOwner: null,
                leaseUntil: null,
                lastError: null,
                processedAt: new Date(now)
            };
            this.replaceEvent(updated);
            this.markAttemptOutcome(updated, workerId, 'processed', null);
            this.appendTransitionAudit(updated, workerId, 'processed', null, now, persistedResult);
            return cloneEvent(updated);
        }
        catch (error) {
            this.restore(snapshot);
            throw error;
        }
    }
    requireOwnedEvent(tenantId, eventId, workerId, now) {
        const event = this.db.state.outbox.find((candidate) => candidate.id === eventId);
        if (!event || event.tenantId !== tenantId) {
            throw new shared_1.DomainError('forbidden', 'Outbox event is outside tenant scope');
        }
        if (event.status !== 'processing') {
            throw new shared_1.DomainError('conflict', `Outbox event is ${event.status}; processing ownership is required`);
        }
        if (event.leaseOwner !== workerId) {
            throw new shared_1.DomainError('conflict', 'Outbox lease belongs to another worker');
        }
        if (!event.leaseUntil || event.leaseUntil.getTime() <= now.getTime()) {
            throw new shared_1.DomainError('conflict', 'Outbox lease has expired');
        }
        return event;
    }
    appendTransitionAudit(event, actorId, status, error, now, result) {
        this.appendAudit(event, 'integration_event', actorId, event.correlationId ?? (0, shared_1.createCorrelationId)(), {
            eventId: event.id,
            status,
            attempt: event.attempts ?? 0,
            ...(error ? { error } : {}),
            ...(status === 'processed' ? { result: summarizeResult(result) } : {})
        }, now);
    }
    markSessionForHandoff(event, now) {
        if (!event.sessionId)
            return;
        const session = this.db.state.sessions.find((candidate) => candidate.id === event.sessionId);
        if (!session)
            return;
        const conversation = this.db.state.conversations.find((candidate) => candidate.id === session.conversationId);
        if (!conversation || conversation.tenantId !== event.tenantId) {
            throw new shared_1.DomainError('forbidden', 'Outbox session is outside the event tenant scope');
        }
        const updatedSession = session.takeoverState === 'BOT_ACTIVE'
            ? {
                ...session,
                takeoverState: 'HANDOFF_REQUESTED',
                updatedAt: new Date(now)
            }
            : session;
        if (updatedSession !== session) {
            this.db.state.sessions = this.db.state.sessions.map((candidate) => candidate.id === updatedSession.id ? updatedSession : candidate);
            this.db.state.conversations = this.db.state.conversations.map((conversation) => conversation.id === updatedSession.conversationId
                ? {
                    ...conversation,
                    status: 'waiting_human',
                    updatedAt: updatedSession.updatedAt
                }
                : conversation);
        }
    }
    appendAudit(event, type, actorId, correlationId, payload, now) {
        const tenantId = requireTenant(event.tenantId);
        const audit = {
            id: (0, shared_1.createDomainId)('audit'),
            tenantId,
            type,
            actorType: actorId.startsWith('op_') ? 'Operator' : 'System',
            actorId,
            correlationId,
            policyVersion: 'outbox-r2',
            payload: (0, shared_1.sanitizeAuditEvidencePayload)(payload).payload,
            createdAt: new Date(now)
        };
        this.db.state.auditEvents = [...this.db.state.auditEvents, audit];
        this.auditWriter?.(cloneAudit(audit));
    }
    markAttemptOutcome(event, workerId, outcome, error) {
        for (let index = this.db.state.outboxAttempts.length - 1; index >= 0; index -= 1) {
            const attempt = this.db.state.outboxAttempts[index];
            if (attempt &&
                attempt.eventId === event.id &&
                attempt.attempt === (event.attempts ?? 0) &&
                attempt.workerId === workerId &&
                attempt.outcome === 'claimed') {
                this.db.state.outboxAttempts = this.db.state.outboxAttempts.map((candidate, candidateIndex) => candidateIndex === index
                    ? { ...candidate, outcome, error }
                    : candidate);
                return;
            }
        }
    }
    markExpiredClaim(event) {
        for (let index = this.db.state.outboxAttempts.length - 1; index >= 0; index -= 1) {
            const attempt = this.db.state.outboxAttempts[index];
            if (attempt &&
                attempt.eventId === event.id &&
                attempt.attempt === (event.attempts ?? 0) &&
                attempt.outcome === 'claimed') {
                this.db.state.outboxAttempts = this.db.state.outboxAttempts.map((candidate, candidateIndex) => candidateIndex === index
                    ? {
                        ...candidate,
                        outcome: 'lease_expired',
                        error: (0, shared_1.sanitizeOutboxError)({ code: 'lease_expired' })
                    }
                    : candidate);
                return;
            }
        }
    }
    retryDelayMs(attempts) {
        const exponent = Math.max(0, attempts - 1);
        return Math.min(this.retryMaxMs, this.retryBaseMs * 2 ** exponent);
    }
    currentTime() {
        const raw = typeof this.clock === 'function' ? this.clock() : this.clock.now();
        const time = new Date(raw);
        if (!Number.isFinite(time.getTime())) {
            throw new shared_1.DomainError('validation_failed', 'Outbox clock returned an invalid date');
        }
        return time;
    }
    replaceEvent(event) {
        this.db.state.outbox = this.db.state.outbox.map((candidate) => candidate.id === event.id ? cloneEvent(event) : candidate);
    }
    ensureStateCollections() {
        this.db.state.outboxAttempts ??= [];
        this.db.state.outboxEffects ??= [];
    }
    snapshot() {
        return {
            conversations: this.db.state.conversations,
            sessions: this.db.state.sessions,
            outbox: this.db.state.outbox,
            attempts: this.db.state.outboxAttempts,
            effects: this.db.state.outboxEffects,
            auditEvents: this.db.state.auditEvents
        };
    }
    restore(snapshot) {
        this.db.state.conversations = snapshot.conversations;
        this.db.state.sessions = snapshot.sessions;
        this.db.state.outbox = snapshot.outbox;
        this.db.state.outboxAttempts = snapshot.attempts;
        this.db.state.outboxEffects = snapshot.effects;
        this.db.state.auditEvents = snapshot.auditEvents;
    }
}
exports.OutboxRepository = OutboxRepository;
function requireTenant(rawTenantId) {
    const parsed = platform_1.TenantIdSchema.safeParse(rawTenantId);
    if (!parsed.success) {
        throw new shared_1.DomainError('unauthorized', 'Tenant scope is required');
    }
    return parsed.data;
}
function requireActor(rawActor, field) {
    if (typeof rawActor !== 'string' ||
        !rawActor.trim() ||
        rawActor.length > 200) {
        throw new shared_1.DomainError('validation_failed', `${field} is invalid`);
    }
    return rawActor.trim();
}
function requireEventType(rawType) {
    if (typeof rawType !== 'string' ||
        !/^[a-z][a-z0-9_.:-]{1,127}$/.test(rawType)) {
        throw new shared_1.DomainError('validation_failed', 'Outbox event type is invalid');
    }
    return rawType;
}
function requireIdempotencyKey(rawKey) {
    const parsed = shared_1.IdempotencyKeySchema.safeParse(rawKey);
    if (!parsed.success) {
        throw new shared_1.DomainError('validation_failed', 'Outbox idempotency key is invalid');
    }
    return parsed.data;
}
function requireCorrelationId(rawCorrelationId) {
    const parsed = shared_1.CorrelationIdSchema.safeParse(rawCorrelationId);
    if (!parsed.success) {
        throw new shared_1.DomainError('validation_failed', 'Outbox correlation id is invalid');
    }
    return parsed.data;
}
function requireEventIdempotencyKey(event) {
    if (!event.tenantId || !event.idempotencyKey) {
        throw new shared_1.DomainError('invalid_action', 'Legacy outbox events cannot be acknowledged by the durable contract');
    }
    return requireIdempotencyKey(event.idempotencyKey);
}
function positiveInteger(value, field) {
    if (!Number.isInteger(value) || value <= 0) {
        throw new shared_1.DomainError('validation_failed', `${field} must be a positive integer`);
    }
    return value;
}
function validateAndRedactPayload(payload, maxBytes) {
    if (payload === undefined) {
        throw new shared_1.DomainError('validation_failed', 'Outbox payload is required');
    }
    return sanitizeAndValidateValue(payload, maxBytes, 'Outbox payload');
}
function validateAndRedactResult(result, maxBytes) {
    return sanitizeAndValidateValue(result ?? null, maxBytes, 'Outbox result');
}
function sanitizeAndValidateValue(value, maxBytes, label) {
    let serialized;
    try {
        serialized = JSON.stringify(value) ?? '';
    }
    catch {
        throw new shared_1.DomainError('validation_failed', `${label} is not serializable`);
    }
    if (Buffer.byteLength(serialized, 'utf8') > maxBytes) {
        throw new shared_1.DomainError('payload_too_large', `${label} exceeds its limit`);
    }
    const sanitized = (0, shared_1.sanitizeOutboxPayload)(value).payload;
    const sanitizedSerialized = JSON.stringify(sanitized) ?? '';
    if (Buffer.byteLength(sanitizedSerialized, 'utf8') > maxBytes) {
        throw new shared_1.DomainError('payload_too_large', `Sanitized ${label.toLowerCase()} exceeds its limit`);
    }
    return sanitized;
}
function redactError(error) {
    if (error === exports.OUTBOX_TAKEOVER_SUPPRESSED_ERROR) {
        return exports.OUTBOX_TAKEOVER_SUPPRESSED_ERROR;
    }
    return (0, shared_1.sanitizeOutboxError)(error);
}
function eligibleAt(event) {
    return (event.availableAt?.getTime() ??
        event.leaseUntil?.getTime() ??
        event.createdAt.getTime());
}
function cloneEvent(event) {
    return {
        ...event,
        createdAt: new Date(event.createdAt),
        ...(event.availableAt ? { availableAt: new Date(event.availableAt) } : {}),
        ...(event.leaseUntil ? { leaseUntil: new Date(event.leaseUntil) } : {}),
        ...(event.processedAt ? { processedAt: new Date(event.processedAt) } : {}),
        ...(event.deadLetteredAt
            ? { deadLetteredAt: new Date(event.deadLetteredAt) }
            : {}),
        payload: cloneValue(event.payload)
    };
}
function cloneAudit(event) {
    return {
        ...event,
        createdAt: new Date(event.createdAt),
        payload: cloneValue(event.payload)
    };
}
function cloneValue(value) {
    if (value === undefined || value === null)
        return value;
    try {
        return structuredClone(value);
    }
    catch {
        return value;
    }
}
function summarizeResult(result) {
    if (result === undefined)
        return undefined;
    if (typeof result === 'number' || typeof result === 'boolean')
        return result;
    return (0, shared_1.sanitizeOutboxPayload)(result).payload;
}
function isPromiseLike(value) {
    return (typeof value === 'object' &&
        value !== null &&
        'then' in value &&
        typeof value.then === 'function');
}
function resolveTakeoverCheck(value) {
    if (typeof value === 'function')
        return Promise.resolve(value());
    return value === true;
}
//# sourceMappingURL=outbox.js.map