import type { ExecutionCheckpoint, ExecutionStep, ExecutionStepStore } from '@cvg/harness-contracts';
import type { PostgresQueryable } from './postgres.ts';
import { type PostgresPoolLike } from './tenant-scoped-postgres.ts';
export type OperationalStepPostgresConnection = PostgresQueryable | PostgresPoolLike;
export interface PostgresExecutionStepStoreOptions {
    readonly clock?: () => Date;
}
/**
 * Durable Phase 3 step/checkpoint authority. Tenant scoping is inherited from
 * the Phase 2 connection discipline; checkpoint integrity is validated before
 * every write and after every read.
 */
export declare class PostgresExecutionStepStore implements ExecutionStepStore {
    private readonly connection;
    private readonly clock;
    constructor(connection: OperationalStepPostgresConnection, options?: PostgresExecutionStepStoreOptions);
    recordStep(step: ExecutionStep): Promise<void>;
    listSteps(tenantId: string, executionId: string): Promise<readonly ExecutionStep[]>;
    saveCheckpoint(checkpoint: ExecutionCheckpoint): Promise<void>;
    loadCheckpoint(tenantId: string, executionId: string): Promise<ExecutionCheckpoint | null>;
    private run;
}
