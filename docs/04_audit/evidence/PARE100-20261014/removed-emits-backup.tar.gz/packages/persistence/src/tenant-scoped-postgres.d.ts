import type { AttendanceApprovalDecision } from './attendance-approval.ts';
import { type AgentConfig, type AgentId, type AgentVersionId, type AgentVersionStatus, type AgentCreateInput, type AgentRecord, type AgentVersionRecord, type KnowledgeSourceCreateInput, type KnowledgeSourceId, type KnowledgeSourceRecord, type KnowledgeSourceStatus, type ReleaseCandidateCreateInput, type ReleaseCandidateId, type ReleaseCandidateRecord, type ReleaseCandidateStatus, type TenantScope, type TestRunTrace, type PluginCatalogCreateInput, type PluginCatalogId, type PluginCatalogRecord, type PluginCatalogStatus, type PluginManifest, type TenantId, type TestSuiteCloneInput, type TestSuiteCreateInput, type TestSuiteId, type TestSuiteRecord, type TestSuiteRunRecord } from '@cvg/platform';
import type { ApprovalRequestRecord, AuditEventRecord, AuditEvidenceFilters, AuditEvidencePage, AuditEvidenceQuery, AuditEvidenceSummary, ConversationPage, InboundRuntimeContext, MessageRecord, SessionRecord, TaskRecord } from './schema.ts';
import type { OutboxAckInput, OutboxClaimInput, OutboxEnqueueInput, OutboxFailInput, OutboxRequeueInput } from './outbox.ts';
import type { AuditEvidenceCheckpointCreateInput, AuditEvidenceCheckpointRecord, AuditEvidenceCheckpointStatus } from './audit-evidence-checkpoint.ts';
import { PostgresRuntimeRepository, type DurableOutboxEventRecord, type InboundRuntimeCompletionInput, type PostgresQueryable } from './postgres.ts';
import type { Channel, TaskStatus } from '@cvg/shared';
export declare const CVG_TENANT_CONTEXT_SETTING = "cvg.tenant_id";
export interface PostgresPoolClient extends PostgresQueryable {
    release(error?: Error): void;
}
export interface PostgresPoolLike {
    connect(): Promise<PostgresPoolClient>;
}
/**
 * Runs an operation on one pool connection with a session-local tenant
 * context. The connection is destroyed when cleanup fails, preventing a
 * tenant context from leaking to the next borrower.
 */
export declare function withTenantContext<T>(pool: PostgresPoolLike, rawTenantId: TenantId, operation: (client: PostgresPoolClient) => Promise<T>): Promise<T>;
/**
 * Runs a short transaction on one pool connection with the same session-local
 * tenant context used by {@link withTenantContext}. The callback, its state
 * mutations and any audit insert commit together; a failure rolls everything
 * back and the tenant context is cleared before the connection returns to the
 * pool. A connection whose context cleanup fails is destroyed instead of
 * being reused with a dirty context.
 */
export declare function withTenantTransaction<T>(pool: PostgresPoolLike, rawTenantId: TenantId, operation: (client: PostgresPoolClient) => Promise<T>): Promise<T>;
export declare class TenantScopedPostgresRuntimeRepository {
    private readonly pool;
    constructor(pool: PostgresPoolLike);
    enqueue(input: OutboxEnqueueInput): Promise<DurableOutboxEventRecord>;
    findOutboxById(tenantId: TenantId, eventId: string): Promise<DurableOutboxEventRecord | null>;
    claimNext(input: OutboxClaimInput): Promise<DurableOutboxEventRecord | null>;
    ack(input: OutboxAckInput): Promise<DurableOutboxEventRecord>;
    fail(input: OutboxFailInput): Promise<DurableOutboxEventRecord>;
    requeueDeadLetter(input: OutboxRequeueInput): Promise<DurableOutboxEventRecord>;
    findByExternalMessage(tenantId: TenantId, channel: Channel, externalMessageId: string): Promise<MessageRecord | null>;
    createWithSession(input: Parameters<PostgresRuntimeRepository['createWithSession']>[0]): Promise<Awaited<ReturnType<PostgresRuntimeRepository['createWithSession']>>>;
    createWithSessionAndOutbox(input: Parameters<PostgresRuntimeRepository['createWithSession']>[0], outbox: OutboxEnqueueInput): Promise<Awaited<ReturnType<PostgresRuntimeRepository['createWithSessionAndOutbox']>>>;
    bindSessionAgentVersion(tenantId: TenantId, sessionId: string, agentId: AgentId, agentVersionId: AgentVersionId): Promise<SessionRecord | null>;
    appendOutboundMessage(input: Parameters<PostgresRuntimeRepository['appendOutboundMessage']>[0]): Promise<Awaited<ReturnType<PostgresRuntimeRepository['appendOutboundMessage']>>>;
    markInboundRuntimeCompleted(messageId: string, tenantId: TenantId): Promise<boolean>;
    findInboundRuntimeContext(tenantId: TenantId, conversationId: string, sessionId: string | null, messageId: string): Promise<InboundRuntimeContext | null>;
    completeInboundRuntime(input: InboundRuntimeCompletionInput): Promise<{
        status: 'completed' | 'paused';
    }>;
    transitionTakeover(tenantId: TenantId, sessionId: string, event: Parameters<PostgresRuntimeRepository['transitionTakeover']>[2]): Promise<SessionRecord | null>;
    appendAudit(input: Parameters<PostgresRuntimeRepository['appendAudit']>[0], rawTenantId?: TenantId): Promise<AuditEventRecord>;
    listAuditBySession(sessionId: string, tenantId: TenantId): Promise<AuditEventRecord[]>;
    listAuditEvidence(query: AuditEvidenceQuery, tenantId: TenantId): Promise<AuditEvidencePage>;
    summarizeAuditEvidence(filters: AuditEvidenceFilters, tenantId: TenantId): Promise<AuditEvidenceSummary>;
    createAuditEvidenceCheckpoint(input: AuditEvidenceCheckpointCreateInput, createdBy: string, tenantId: TenantId): Promise<AuditEvidenceCheckpointRecord>;
    getAuditEvidenceCheckpoint(id: string, tenantId: TenantId): Promise<AuditEvidenceCheckpointRecord | null>;
    listAuditEvidenceCheckpoints(tenantId: TenantId): Promise<AuditEvidenceCheckpointRecord[]>;
    transitionAuditEvidenceCheckpoint(id: string, status: AuditEvidenceCheckpointStatus, updatedBy: string, expectedStatus: AuditEvidenceCheckpointStatus, tenantId: TenantId): Promise<AuditEvidenceCheckpointRecord | null>;
    timeline(tenantId: TenantId, conversationId: string): Promise<Awaited<ReturnType<PostgresRuntimeRepository['timeline']>>>;
    listPage(tenantId: TenantId, input: Parameters<PostgresRuntimeRepository['listPage']>[1]): Promise<ConversationPage>;
    createTask(input: Parameters<PostgresRuntimeRepository['createTask']>[0], tenantId?: TenantId): Promise<TaskRecord>;
    listTasks(tenantId?: TenantId): Promise<TaskRecord[]>;
    findTaskById(id: string, tenantId?: TenantId): Promise<TaskRecord | null>;
    updateTaskStatus(id: string, status: TaskStatus, tenantId?: TenantId): Promise<TaskRecord | null>;
    saveApproval(request: ApprovalRequestRecord, tenantId?: TenantId): Promise<ApprovalRequestRecord>;
    decideApprovalWithAudit(input: AttendanceApprovalDecision, tenantId?: TenantId): Promise<ApprovalRequestRecord>;
    findApprovalById(id: string, tenantId?: TenantId): Promise<ApprovalRequestRecord | null>;
    listApprovals(tenantId?: TenantId): Promise<ApprovalRequestRecord[]>;
    private run;
}
export declare class TenantScopedPostgresControlPlaneRepository {
    private readonly pool;
    constructor(pool: PostgresPoolLike);
    createAgent(scope: TenantScope, input: AgentCreateInput): Promise<AgentRecord>;
    getAgent(scope: TenantScope, agentId: AgentId): Promise<AgentRecord | null>;
    listAgents(scope: TenantScope): Promise<AgentRecord[]>;
    createVersion(scope: TenantScope, agentId: AgentId, config: AgentConfig, createdBy: string): Promise<AgentVersionRecord>;
    getVersion(scope: TenantScope, versionId: AgentVersionId): Promise<AgentVersionRecord | null>;
    listVersions(scope: TenantScope, agentId: AgentId): Promise<AgentVersionRecord[]>;
    transitionVersion(scope: TenantScope, versionId: AgentVersionId, target: AgentVersionStatus, expectedStatus?: AgentVersionStatus): Promise<AgentVersionRecord>;
    publishVersion(scope: TenantScope, versionId: AgentVersionId, releaseCandidateId: ReleaseCandidateId, expectedStatus?: AgentVersionStatus): Promise<AgentVersionRecord>;
    rollback(scope: TenantScope, agentId: AgentId, versionId: AgentVersionId, createdBy: string, releaseCandidateId: ReleaseCandidateId, expectedStatus?: AgentVersionStatus): Promise<AgentVersionRecord>;
    resolvePublished(scope: TenantScope, agentId: AgentId): Promise<AgentVersionRecord | null>;
    createKnowledgeSource(scope: TenantScope, input: KnowledgeSourceCreateInput, createdBy: string): Promise<KnowledgeSourceRecord>;
    getKnowledgeSource(scope: TenantScope, sourceId: KnowledgeSourceId): Promise<KnowledgeSourceRecord | null>;
    listKnowledgeSources(scope: TenantScope): Promise<KnowledgeSourceRecord[]>;
    transitionKnowledgeSource(scope: TenantScope, sourceId: KnowledgeSourceId, target: KnowledgeSourceStatus, actorId: string, expectedStatus?: KnowledgeSourceStatus): Promise<KnowledgeSourceRecord>;
    createReleaseCandidate(scope: TenantScope, input: ReleaseCandidateCreateInput, createdBy: string): Promise<ReleaseCandidateRecord>;
    getReleaseCandidate(scope: TenantScope, candidateId: ReleaseCandidateId): Promise<ReleaseCandidateRecord | null>;
    listReleaseCandidates(scope: TenantScope, agentId?: AgentId): Promise<ReleaseCandidateRecord[]>;
    transitionReleaseCandidate(scope: TenantScope, candidateId: ReleaseCandidateId, target: ReleaseCandidateStatus, actorId: string, expectedStatus?: ReleaseCandidateStatus): Promise<ReleaseCandidateRecord>;
    createPluginCatalogEntry(scope: TenantScope, input: PluginCatalogCreateInput, createdBy: string): Promise<PluginCatalogRecord>;
    getPluginCatalogEntry(scope: TenantScope, pluginId: PluginCatalogId): Promise<PluginCatalogRecord | null>;
    listPluginCatalogEntries(scope: TenantScope, name?: string): Promise<PluginCatalogRecord[]>;
    transitionPluginCatalogEntry(scope: TenantScope, pluginId: PluginCatalogId, target: PluginCatalogStatus, actorId: string, expectedStatus?: PluginCatalogStatus): Promise<PluginCatalogRecord>;
    resolveApprovedPlugin(scope: TenantScope, name: string, version?: string): Promise<PluginManifest | null>;
    recordTestRun(scope: TenantScope, trace: TestRunTrace): Promise<TestRunTrace>;
    listTestRuns(scope: TenantScope, limit?: number): Promise<TestRunTrace[]>;
    recordExecutionTrace(scope: TenantScope, trace: TestRunTrace): Promise<TestRunTrace>;
    listExecutionTraces(scope: TenantScope, limit?: number): Promise<TestRunTrace[]>;
    createTestSuite(scope: TenantScope, input: TestSuiteCreateInput, createdBy: string): Promise<TestSuiteRecord>;
    getTestSuite(scope: TenantScope, suiteId: TestSuiteId): Promise<TestSuiteRecord | null>;
    listTestSuites(scope: TenantScope, agentId?: AgentId): Promise<TestSuiteRecord[]>;
    cloneTestSuite(scope: TenantScope, suiteId: TestSuiteId, input: TestSuiteCloneInput, createdBy: string): Promise<TestSuiteRecord>;
    recordTestSuiteRun(scope: TenantScope, run: TestSuiteRunRecord): Promise<TestSuiteRunRecord>;
    listTestSuiteRuns(scope: TenantScope, suiteId: TestSuiteId, limit?: number): Promise<TestSuiteRunRecord[]>;
    private run;
}
