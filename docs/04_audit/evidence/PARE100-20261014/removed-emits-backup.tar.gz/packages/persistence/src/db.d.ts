import type { DatabaseState } from './schema.ts';
export declare function createInMemoryState(): DatabaseState;
export declare class InMemoryDatabase {
    readonly state: DatabaseState;
    constructor(state?: DatabaseState);
}
