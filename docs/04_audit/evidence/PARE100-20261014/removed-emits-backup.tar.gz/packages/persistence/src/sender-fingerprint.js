"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createSenderRefFingerprint = createSenderRefFingerprint;
const node_crypto_1 = require("node:crypto");
function createSenderRefFingerprint(tenantId, senderRef) {
    return (0, node_crypto_1.createHash)('sha256')
        .update(`${tenantId}\u0000${senderRef}`, 'utf8')
        .digest('hex');
}
//# sourceMappingURL=sender-fingerprint.js.map