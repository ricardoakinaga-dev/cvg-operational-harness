"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TaskRepository = void 0;
const shared_1 = require("@cvg/shared");
const platform_1 = require("@cvg/platform");
class TaskRepository {
    db;
    constructor(db) {
        this.db = db;
    }
    create(input, rawTenantId) {
        const tenantId = rawTenantId ? platform_1.TenantIdSchema.parse(rawTenantId) : undefined;
        if (tenantId && !this.sessionBelongsToTenant(input.sessionId, tenantId)) {
            throw new shared_1.DomainError('invalid_action', 'Session not found');
        }
        const existing = this.db.state.tasks.find((task) => task.sessionId === input.sessionId &&
            task.source === input.source &&
            task.idempotencyKey === input.idempotencyKey &&
            (!tenantId || this.taskBelongsToTenant(task, tenantId)));
        if (existing)
            return existing;
        const task = {
            id: (0, shared_1.createDomainId)('task'),
            sessionId: input.sessionId,
            title: input.title,
            description: input.description,
            priority: input.priority,
            source: input.source,
            status: 'open',
            idempotencyKey: input.idempotencyKey,
            createdAt: new Date()
        };
        this.db.state.tasks = [...this.db.state.tasks, task];
        return task;
    }
    list(rawTenantId) {
        const tenantId = rawTenantId ? platform_1.TenantIdSchema.parse(rawTenantId) : undefined;
        return this.db.state.tasks.filter((task) => !tenantId || this.taskBelongsToTenant(task, tenantId));
    }
    findById(id, rawTenantId) {
        const tenantId = rawTenantId ? platform_1.TenantIdSchema.parse(rawTenantId) : undefined;
        return (this.db.state.tasks.find((task) => task.id === id &&
            (!tenantId || this.taskBelongsToTenant(task, tenantId))) ?? null);
    }
    updateStatus(id, status, rawTenantId) {
        const existing = this.findById(id, rawTenantId);
        if (!existing)
            return null;
        const updated = { ...existing, status };
        this.db.state.tasks = this.db.state.tasks.map((task) => task.id === id ? updated : task);
        return updated;
    }
    taskBelongsToTenant(task, tenantId) {
        return this.sessionBelongsToTenant(task.sessionId, tenantId);
    }
    sessionBelongsToTenant(sessionId, tenantId) {
        const session = this.db.state.sessions.find((item) => item.id === sessionId);
        const conversation = session
            ? this.db.state.conversations.find((item) => item.id === session.conversationId)
            : undefined;
        return conversation?.tenantId === tenantId;
    }
}
exports.TaskRepository = TaskRepository;
//# sourceMappingURL=task-repository.js.map