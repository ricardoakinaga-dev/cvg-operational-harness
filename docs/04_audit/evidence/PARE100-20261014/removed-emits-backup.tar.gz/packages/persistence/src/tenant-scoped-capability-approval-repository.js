"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TenantScopedPostgresCapabilityApprovalRepository = void 0;
const platform_1 = require("@cvg/platform");
const platform_approval_repository_ts_1 = require("./platform-approval-repository.js");
const tenant_scoped_postgres_ts_1 = require("./tenant-scoped-postgres.js");
/**
 * Binds every approval operation to a checked-out tenant connection. In
 * particular, verifyAndConsume runs its whole transaction on that one
 * connection, so a pool cannot split BEGIN/SELECT/UPDATE/COMMIT.
 */
class TenantScopedPostgresCapabilityApprovalRepository {
    pool;
    options;
    constructor(pool, options = {}) {
        this.pool = pool;
        this.options = options;
    }
    issue(input) {
        const tenantId = platform_1.TenantIdSchema.parse(input.tenantId);
        return (0, tenant_scoped_postgres_ts_1.withTenantContext)(this.pool, tenantId, (client) => new platform_approval_repository_ts_1.PostgresCapabilityApprovalRepository(client, this.options).issue(input));
    }
    verifyAndConsume(input) {
        const tenantId = platform_1.TenantIdSchema.safeParse(input.tenantId);
        if (!tenantId.success)
            return Promise.resolve(null);
        return (0, tenant_scoped_postgres_ts_1.withTenantContext)(this.pool, tenantId.data, (client) => new platform_approval_repository_ts_1.PostgresCapabilityApprovalRepository(client, this.options).verifyAndConsume(input));
    }
    revoke(approvalId, issuer, tenantId) {
        if (!tenantId || !platform_1.TenantIdSchema.safeParse(tenantId).success) {
            return Promise.resolve(false);
        }
        return (0, tenant_scoped_postgres_ts_1.withTenantContext)(this.pool, tenantId, (client) => new platform_approval_repository_ts_1.PostgresCapabilityApprovalRepository(client, this.options).revoke(approvalId, issuer, tenantId));
    }
    get(approvalId, tenantId) {
        if (!tenantId || !platform_1.TenantIdSchema.safeParse(tenantId).success) {
            return Promise.resolve(null);
        }
        return (0, tenant_scoped_postgres_ts_1.withTenantContext)(this.pool, tenantId, (client) => new platform_approval_repository_ts_1.PostgresCapabilityApprovalRepository(client, this.options).get(approvalId, tenantId));
    }
}
exports.TenantScopedPostgresCapabilityApprovalRepository = TenantScopedPostgresCapabilityApprovalRepository;
//# sourceMappingURL=tenant-scoped-capability-approval-repository.js.map