"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostgresCapabilityApprovalRepository = void 0;
const shared_1 = require("@cvg/shared");
const platform_1 = require("@cvg/platform");
const approvalColumns = `
  id, tenant_id, agent_id, version_id, tool_name, input_hash,
  actor_id, nonce, issuer, expires_at, issued_at, status,
  consumed_at, revoked_at`;
class PostgresCapabilityApprovalRepository {
    client;
    now;
    constructor(client, options = {}) {
        this.client = client;
        this.now = options.now ?? (() => new Date());
    }
    async issue(rawInput) {
        const input = normalizeIssueInput(rawInput, this.now);
        const id = (0, shared_1.createDomainId)('approval');
        const inputHash = (0, platform_1.createCapabilityInputHash)(input);
        try {
            const result = await this.client.query(`INSERT INTO platform_capability_approvals
           (id, tenant_id, agent_id, version_id, tool_name, input_hash,
            actor_id, nonce, issuer, expires_at, issued_at, status)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, 'issued')
         RETURNING ${approvalColumns}`, [
                id,
                input.tenantId,
                input.agentId,
                input.versionId,
                input.toolName,
                inputHash,
                input.actorId,
                input.nonce,
                input.issuer,
                input.expiresAt,
                input.issuedAt
            ]);
            const row = result.rows[0];
            if (!row)
                throw new Error('Capability approval was not persisted');
            return mapApproval(row);
        }
        catch (error) {
            if (isUniqueViolation(error)) {
                throw new Error('Approval nonce already exists');
            }
            throw error;
        }
    }
    async verifyAndConsume(rawInput) {
        const input = normalizeVerificationInput(rawInput);
        if (!input)
            return null;
        await this.client.query('BEGIN');
        try {
            const result = await this.client.query(`SELECT ${approvalColumns}
         FROM platform_capability_approvals
         WHERE tenant_id = $1 AND id = $2
         FOR UPDATE`, [input.tenantId, input.approvalId]);
            const current = result.rows[0];
            if (!current || current.status !== 'issued') {
                await this.client.query('COMMIT');
                return null;
            }
            const now = copyDate(this.now(), 'Approval verification time');
            if (new Date(current.expires_at).getTime() <= now.getTime()) {
                await this.client.query(`UPDATE platform_capability_approvals
           SET status = 'expired'
           WHERE tenant_id = $1 AND id = $2 AND status = 'issued'`, [input.tenantId, input.approvalId]);
                await this.client.query('COMMIT');
                return null;
            }
            let inputHash;
            try {
                inputHash = (0, platform_1.createCapabilityInputHash)({
                    tenantId: input.tenantId,
                    agentId: input.agentId,
                    versionId: input.versionId,
                    toolName: input.toolName,
                    input: input.input
                });
            }
            catch {
                await this.client.query('COMMIT');
                return null;
            }
            if (current.agent_id !== input.agentId ||
                current.version_id !== input.versionId ||
                current.tool_name !== input.toolName ||
                current.actor_id !== input.actorId ||
                current.input_hash !== inputHash) {
                await this.client.query('COMMIT');
                return null;
            }
            const consumed = await this.client.query(`UPDATE platform_capability_approvals
         SET status = 'consumed', consumed_at = $3
         WHERE tenant_id = $1 AND id = $2 AND status = 'issued'
         RETURNING ${approvalColumns}`, [input.tenantId, input.approvalId, now]);
            const row = consumed.rows[0];
            if (!row) {
                await this.client.query('COMMIT');
                return null;
            }
            if (input.consumptionAudit) {
                const payload = (0, shared_1.sanitizeAuditEvidencePayload)({
                    tenantId: input.tenantId,
                    event: 'capability_approval_consumed',
                    approvalId: row.id,
                    agentId: row.agent_id,
                    versionId: row.version_id,
                    toolName: row.tool_name,
                    actorId: row.actor_id,
                    ...(input.consumptionAudit.traceId !== undefined
                        ? { traceId: input.consumptionAudit.traceId }
                        : {})
                }).payload;
                await this.client.query(`INSERT INTO audit_events
             (tenant_id, id, type, actor_type, actor_id, correlation_id,
              policy_version, payload, created_at)
           VALUES ($1, $2, 'approval_decision', 'System',
                   'capability-approval-authority', $3, $4, $5::jsonb, $6)`, [
                    input.tenantId,
                    (0, shared_1.createDomainId)('audit'),
                    input.consumptionAudit.correlationId,
                    input.consumptionAudit.policyVersion,
                    JSON.stringify(payload),
                    now
                ]);
            }
            await this.client.query('COMMIT');
            return mapApproval(row);
        }
        catch (error) {
            await this.client.query('ROLLBACK');
            throw error;
        }
    }
    async revoke(approvalId, issuer, tenantId) {
        if (!shared_1.DomainIdSchema.safeParse(approvalId).success ||
            typeof issuer !== 'string' ||
            !issuer.trim() ||
            !tenantId ||
            !platform_1.TenantIdSchema.safeParse(tenantId).success) {
            return false;
        }
        const now = copyDate(this.now(), 'Approval revocation time');
        const result = await this.client.query(`UPDATE platform_capability_approvals
       SET status = 'revoked', revoked_at = $2
       WHERE id = $1 AND tenant_id = $4 AND issuer = $3 AND status = 'issued'
       RETURNING id`, [approvalId, now, issuer, tenantId]);
        return result.rows.length > 0;
    }
    async get(approvalId, tenantId) {
        if (!shared_1.DomainIdSchema.safeParse(approvalId).success ||
            !tenantId ||
            !platform_1.TenantIdSchema.safeParse(tenantId).success) {
            return null;
        }
        const result = await this.client.query(`SELECT ${approvalColumns}
       FROM platform_capability_approvals
       WHERE tenant_id = $1 AND id = $2
       LIMIT 1`, [tenantId, approvalId]);
        const row = result.rows[0];
        return row ? mapApproval(row) : null;
    }
}
exports.PostgresCapabilityApprovalRepository = PostgresCapabilityApprovalRepository;
function normalizeIssueInput(rawInput, now) {
    const tenantId = platform_1.TenantIdSchema.parse(rawInput.tenantId);
    const agentId = platform_1.AgentIdSchema.parse(rawInput.agentId);
    const versionId = platform_1.AgentVersionIdSchema.parse(rawInput.versionId);
    const issuedAt = copyDate(now(), 'Approval issue time');
    const expiresAt = copyDate(rawInput.expiresAt, 'Approval expiry');
    const toolName = typeof rawInput.toolName === 'string' ? rawInput.toolName.trim() : '';
    const actorId = typeof rawInput.actorId === 'string' ? rawInput.actorId.trim() : '';
    const issuer = typeof rawInput.issuer === 'string' ? rawInput.issuer.trim() : '';
    const nonce = typeof rawInput.nonce === 'string'
        ? rawInput.nonce.trim() || (0, shared_1.createDomainId)('nonce')
        : (0, shared_1.createDomainId)('nonce');
    if (!toolName || !actorId || !issuer || !nonce) {
        throw new Error('Approval binding fields are required');
    }
    if (actorId === issuer) {
        throw new Error('Approval issuer and executor must be different');
    }
    if (expiresAt.getTime() <= issuedAt.getTime()) {
        throw new Error('Approval expiry must be in the future');
    }
    return {
        ...rawInput,
        tenantId,
        agentId,
        versionId,
        toolName,
        actorId,
        issuer,
        nonce,
        expiresAt,
        issuedAt
    };
}
function normalizeVerificationInput(rawInput) {
    const tenantId = platform_1.TenantIdSchema.safeParse(rawInput.tenantId);
    const agentId = platform_1.AgentIdSchema.safeParse(rawInput.agentId);
    const versionId = platform_1.AgentVersionIdSchema.safeParse(rawInput.versionId);
    const consumptionAudit = rawInput.consumptionAudit;
    const validConsumptionAudit = consumptionAudit === undefined ||
        (typeof consumptionAudit === 'object' &&
            consumptionAudit !== null &&
            shared_1.CorrelationIdSchema.safeParse(consumptionAudit.correlationId).success &&
            typeof consumptionAudit.policyVersion === 'string' &&
            consumptionAudit.policyVersion.trim().length > 0 &&
            (consumptionAudit.traceId === undefined ||
                platform_1.TraceIdSchema.safeParse(consumptionAudit.traceId).success));
    if (!tenantId.success ||
        !agentId.success ||
        !versionId.success ||
        !validConsumptionAudit ||
        !shared_1.DomainIdSchema.safeParse(rawInput.approvalId).success ||
        typeof rawInput.toolName !== 'string' ||
        typeof rawInput.actorId !== 'string' ||
        !rawInput.toolName.trim() ||
        !rawInput.actorId.trim()) {
        return null;
    }
    return {
        ...rawInput,
        tenantId: tenantId.data,
        agentId: agentId.data,
        versionId: versionId.data,
        toolName: rawInput.toolName.trim(),
        actorId: rawInput.actorId.trim(),
        ...(consumptionAudit
            ? {
                consumptionAudit: {
                    correlationId: shared_1.CorrelationIdSchema.parse(consumptionAudit.correlationId),
                    policyVersion: consumptionAudit.policyVersion.trim(),
                    ...(consumptionAudit.traceId !== undefined
                        ? { traceId: platform_1.TraceIdSchema.parse(consumptionAudit.traceId) }
                        : {})
                }
            }
            : {})
    };
}
function mapApproval(row) {
    return {
        id: row.id,
        tenantId: row.tenant_id,
        agentId: row.agent_id,
        versionId: row.version_id,
        toolName: row.tool_name,
        inputHash: row.input_hash,
        actorId: row.actor_id,
        nonce: row.nonce,
        issuer: row.issuer,
        expiresAt: new Date(row.expires_at),
        issuedAt: new Date(row.issued_at),
        status: row.status,
        consumedAt: row.consumed_at ? new Date(row.consumed_at) : null,
        revokedAt: row.revoked_at ? new Date(row.revoked_at) : null
    };
}
function copyDate(value, label) {
    if (!(value instanceof Date) || !Number.isFinite(value.getTime())) {
        throw new Error(`${label} must be a valid date`);
    }
    return new Date(value.getTime());
}
function isUniqueViolation(error) {
    return (typeof error === 'object' &&
        error !== null &&
        'code' in error &&
        error.code === '23505');
}
//# sourceMappingURL=platform-approval-repository.js.map