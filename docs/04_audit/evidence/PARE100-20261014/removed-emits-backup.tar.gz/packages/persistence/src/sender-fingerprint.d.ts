export declare function createSenderRefFingerprint(tenantId: string, senderRef: string): string;
