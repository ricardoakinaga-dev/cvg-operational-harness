"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditRepository = void 0;
exports.summarizeAuditEvents = summarizeAuditEvents;
exports.auditEventMatches = auditEventMatches;
const shared_1 = require("@cvg/shared");
const platform_1 = require("@cvg/platform");
const audit_evidence_checkpoint_ts_1 = require("../audit-evidence-checkpoint.js");
class AuditRepository {
    db;
    constructor(db) {
        this.db = db;
    }
    append(input, rawTenantId) {
        const tenantId = rawTenantId ? platform_1.TenantIdSchema.parse(rawTenantId) : undefined;
        const event = {
            ...input,
            ...(tenantId ? { tenantId } : {}),
            payload: (0, shared_1.sanitizeAuditEvidencePayload)(input.payload).payload,
            id: (0, shared_1.createDomainId)('audit'),
            createdAt: new Date()
        };
        this.db.state.auditEvents = [...this.db.state.auditEvents, event];
        return event;
    }
    listByCorrelation(correlationId, rawTenantId) {
        const tenantId = rawTenantId ? platform_1.TenantIdSchema.parse(rawTenantId) : undefined;
        return this.db.state.auditEvents.filter((event) => event.correlationId === correlationId &&
            (!tenantId || this.eventBelongsToTenant(event, tenantId)));
    }
    listBySession(sessionId, rawTenantId) {
        const tenantId = rawTenantId ? platform_1.TenantIdSchema.parse(rawTenantId) : undefined;
        return this.db.state.auditEvents.filter((event) => {
            if (!payloadHasSession(event.payload, sessionId)) {
                return false;
            }
            return !tenantId || this.eventBelongsToTenant(event, tenantId);
        });
    }
    listEvidence(query, rawTenantId) {
        const tenantId = rawTenantId ? platform_1.TenantIdSchema.parse(rawTenantId) : undefined;
        const filtered = this.filterEvidence(query, tenantId);
        const items = filtered.slice(query.offset, query.offset + query.limit);
        return {
            items,
            pageInfo: {
                limit: query.limit,
                offset: query.offset,
                total: filtered.length,
                hasNextPage: query.offset + items.length < filtered.length
            }
        };
    }
    summarizeEvidence(filters = {}, rawTenantId) {
        const tenantId = rawTenantId ? platform_1.TenantIdSchema.parse(rawTenantId) : undefined;
        const filtered = this.filterEvidence(filters, tenantId);
        return summarizeAuditEvents(filtered);
    }
    listAuditEventsByIds(rawIds, rawTenantId) {
        const tenantId = rawTenantId ? platform_1.TenantIdSchema.parse(rawTenantId) : undefined;
        const ids = new Set(rawIds);
        return this.db.state.auditEvents.filter((event) => ids.has(event.id) &&
            (!tenantId || this.eventBelongsToTenant(event, tenantId)));
    }
    createAuditEvidenceCheckpoint(rawInput, rawCreatedBy, rawTenantId) {
        const tenantId = requireCheckpointTenant(rawTenantId);
        const input = audit_evidence_checkpoint_ts_1.AuditEvidenceCheckpointCreateInputSchema.parse(rawInput);
        const createdBy = audit_evidence_checkpoint_ts_1.AuditEvidenceCheckpointActorIdSchema.parse(rawCreatedBy);
        const events = this.listAuditEventsByIds(input.eventIds, tenantId);
        assertCheckpointEvents(input, events, input.eventIds);
        const evidenceDigest = (0, audit_evidence_checkpoint_ts_1.computeAuditEvidenceCheckpointDigest)(tenantId, input, events);
        if (this.db.state.auditEvidenceCheckpoints.some((checkpoint) => checkpoint.tenantId === tenantId &&
            checkpoint.evidenceDigest === evidenceDigest)) {
            throw new shared_1.DomainError('conflict', 'Audit evidence checkpoint already exists');
        }
        const now = new Date();
        const checkpoint = {
            tenantId,
            id: (0, audit_evidence_checkpoint_ts_1.createAuditEvidenceCheckpointId)(),
            filters: { ...(input.filters ?? {}) },
            eventIds: [...input.eventIds].sort(),
            eventCount: input.eventIds.length,
            evidenceDigest,
            status: 'SEALED',
            createdBy,
            updatedBy: createdBy,
            createdAt: now,
            updatedAt: now
        };
        this.db.state.auditEvidenceCheckpoints = [
            ...this.db.state.auditEvidenceCheckpoints,
            (0, audit_evidence_checkpoint_ts_1.cloneAuditEvidenceCheckpoint)(checkpoint)
        ];
        return (0, audit_evidence_checkpoint_ts_1.cloneAuditEvidenceCheckpoint)(checkpoint);
    }
    getAuditEvidenceCheckpoint(rawId, rawTenantId) {
        const tenantId = requireCheckpointTenant(rawTenantId);
        const id = audit_evidence_checkpoint_ts_1.AuditEvidenceCheckpointIdSchema.parse(rawId);
        const checkpoint = this.db.state.auditEvidenceCheckpoints.find((candidate) => candidate.id === id && candidate.tenantId === tenantId);
        return checkpoint ? (0, audit_evidence_checkpoint_ts_1.cloneAuditEvidenceCheckpoint)(checkpoint) : null;
    }
    listAuditEvidenceCheckpoints(rawTenantId) {
        const tenantId = requireCheckpointTenant(rawTenantId);
        return this.db.state.auditEvidenceCheckpoints
            .filter((checkpoint) => checkpoint.tenantId === tenantId)
            .sort((left, right) => right.createdAt.getTime() - left.createdAt.getTime())
            .map(audit_evidence_checkpoint_ts_1.cloneAuditEvidenceCheckpoint);
    }
    transitionAuditEvidenceCheckpoint(rawId, rawStatus, rawUpdatedBy, rawExpectedStatus, rawTenantId) {
        const tenantId = requireCheckpointTenant(rawTenantId);
        const id = audit_evidence_checkpoint_ts_1.AuditEvidenceCheckpointIdSchema.parse(rawId);
        const status = audit_evidence_checkpoint_ts_1.AuditEvidenceCheckpointStatusSchema.parse(rawStatus);
        const expectedStatus = audit_evidence_checkpoint_ts_1.AuditEvidenceCheckpointStatusSchema.parse(rawExpectedStatus);
        const updatedBy = audit_evidence_checkpoint_ts_1.AuditEvidenceCheckpointActorIdSchema.parse(rawUpdatedBy);
        const current = this.db.state.auditEvidenceCheckpoints.find((candidate) => candidate.id === id && candidate.tenantId === tenantId);
        if (!current)
            return null;
        if (current.status !== expectedStatus) {
            throw new shared_1.DomainError('conflict', `Audit evidence checkpoint status is ${current.status}, expected ${expectedStatus}`);
        }
        if (current.status !== 'SEALED' || status !== 'ARCHIVED') {
            throw new shared_1.DomainError('invalid_action', 'Audit evidence checkpoint transition is not allowed');
        }
        const updated = {
            ...current,
            status,
            updatedBy,
            updatedAt: new Date()
        };
        this.db.state.auditEvidenceCheckpoints =
            this.db.state.auditEvidenceCheckpoints.map((candidate) => candidate.id === id && candidate.tenantId === tenantId
                ? (0, audit_evidence_checkpoint_ts_1.cloneAuditEvidenceCheckpoint)(updated)
                : candidate);
        return (0, audit_evidence_checkpoint_ts_1.cloneAuditEvidenceCheckpoint)(updated);
    }
    filterEvidence(filters, tenantId) {
        return this.db.state.auditEvents.filter((event) => auditEventMatches(event, filters) &&
            (!tenantId || this.eventBelongsToTenant(event, tenantId)));
    }
    eventBelongsToTenant(event, tenantId) {
        return event.tenantId === tenantId;
    }
}
exports.AuditRepository = AuditRepository;
function requireCheckpointTenant(rawTenantId) {
    const parsed = platform_1.TenantIdSchema.safeParse(rawTenantId);
    if (!parsed.success) {
        throw new shared_1.DomainError('unauthorized', 'Tenant scope is required');
    }
    return parsed.data;
}
function assertCheckpointEvents(input, events, requestedIds) {
    if (events.length !== requestedIds.length) {
        throw new shared_1.DomainError('invalid_action', 'All audit evidence events must exist in the tenant scope');
    }
    const filters = (0, audit_evidence_checkpoint_ts_1.normalizeAuditEvidenceCheckpointFilters)(input.filters ?? {});
    if (events.some((event) => !auditEventMatches(event, filters))) {
        throw new shared_1.DomainError('invalid_action', 'All audit evidence events must match the checkpoint filters');
    }
}
function summarizeAuditEvents(events) {
    return events.reduce((summary, event) => {
        const sessionId = readPayloadSessionId(event.payload);
        return {
            totalEvents: summary.totalEvents + 1,
            byType: {
                ...summary.byType,
                [event.type]: (summary.byType[event.type] ?? 0) + 1
            },
            byActorType: {
                ...summary.byActorType,
                [event.actorType]: (summary.byActorType[event.actorType] ?? 0) + 1
            },
            byCorrelationId: {
                ...summary.byCorrelationId,
                [event.correlationId]: (summary.byCorrelationId[event.correlationId] ?? 0) + 1
            },
            bySessionId: sessionId
                ? {
                    ...summary.bySessionId,
                    [sessionId]: (summary.bySessionId[sessionId] ?? 0) + 1
                }
                : summary.bySessionId
        };
    }, {
        totalEvents: 0,
        byType: {},
        byActorType: {},
        byCorrelationId: {},
        bySessionId: {}
    });
}
function auditEventMatches(event, filters) {
    if (filters.sessionId && !payloadHasSession(event.payload, filters.sessionId))
        return false;
    if (filters.correlationId && event.correlationId !== filters.correlationId)
        return false;
    if (filters.type && event.type !== filters.type)
        return false;
    if (filters.actorId && event.actorId !== filters.actorId)
        return false;
    return true;
}
function payloadHasSession(payload, sessionId) {
    return readPayloadSessionId(payload) === sessionId;
}
function readPayloadSessionId(payload) {
    if (typeof payload !== 'object' ||
        payload === null ||
        !('sessionId' in payload)) {
        return null;
    }
    const sessionId = payload.sessionId;
    return typeof sessionId === 'string' ? sessionId : null;
}
//# sourceMappingURL=audit-repository.js.map