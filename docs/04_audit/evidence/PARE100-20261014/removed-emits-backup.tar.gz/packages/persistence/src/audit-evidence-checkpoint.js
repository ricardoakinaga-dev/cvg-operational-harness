"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditEvidenceCheckpointActorIdSchema = exports.AuditEvidenceCheckpointTransitionInputSchema = exports.AuditEvidenceCheckpointCreateInputSchema = exports.AuditEvidenceCheckpointFiltersSchema = exports.AuditEvidenceCheckpointStatusSchema = exports.AuditEvidenceCheckpointIdSchema = void 0;
exports.createAuditEvidenceCheckpointId = createAuditEvidenceCheckpointId;
exports.computeAuditEvidenceCheckpointDigest = computeAuditEvidenceCheckpointDigest;
exports.cloneAuditEvidenceCheckpoint = cloneAuditEvidenceCheckpoint;
exports.normalizeAuditEvidenceCheckpointFilters = normalizeAuditEvidenceCheckpointFilters;
const node_crypto_1 = require("node:crypto");
const shared_1 = require("@cvg/shared");
const platform_1 = require("@cvg/platform");
const zod_1 = require("zod");
const boundedFilter = zod_1.z
    .string()
    .trim()
    .min(1)
    .max(120)
    .regex(/^[A-Za-z0-9._:-]+$/);
exports.AuditEvidenceCheckpointIdSchema = zod_1.z
    .string()
    .regex(/^audit_checkpoint_[0-9a-f-]{36}$/);
exports.AuditEvidenceCheckpointStatusSchema = zod_1.z.enum([
    'SEALED',
    'ARCHIVED'
]);
exports.AuditEvidenceCheckpointFiltersSchema = zod_1.z
    .object({
    sessionId: boundedFilter.optional(),
    correlationId: boundedFilter.optional(),
    type: zod_1.z
        .enum([
        'tool_call',
        'safety_event',
        'integration_event',
        'policy_decision',
        'approval_decision',
        'handoff'
    ])
        .optional(),
    actorId: boundedFilter.optional()
})
    .strict();
const AuditEvidenceEventIdSchema = zod_1.z.string().regex(/^audit_[0-9a-f-]{36}$/);
exports.AuditEvidenceCheckpointCreateInputSchema = zod_1.z
    .object({
    eventIds: zod_1.z.array(AuditEvidenceEventIdSchema).min(1).max(200),
    filters: exports.AuditEvidenceCheckpointFiltersSchema.default({})
})
    .strict()
    .superRefine((input, context) => {
    if (new Set(input.eventIds).size !== input.eventIds.length) {
        context.addIssue({
            code: 'custom',
            path: ['eventIds'],
            message: 'eventIds must be unique'
        });
    }
});
exports.AuditEvidenceCheckpointTransitionInputSchema = zod_1.z
    .object({
    status: zod_1.z.literal('ARCHIVED'),
    expectedStatus: zod_1.z.literal('SEALED')
})
    .strict();
exports.AuditEvidenceCheckpointActorIdSchema = boundedFilter;
function createAuditEvidenceCheckpointId() {
    return exports.AuditEvidenceCheckpointIdSchema.parse(`audit_checkpoint_${(0, node_crypto_1.randomUUID)()}`);
}
function computeAuditEvidenceCheckpointDigest(rawTenantId, rawInput, events) {
    const tenantId = platform_1.TenantIdSchema.parse(rawTenantId);
    const input = exports.AuditEvidenceCheckpointCreateInputSchema.parse(rawInput);
    const canonical = {
        tenantId,
        filters: canonicalize(input.filters),
        eventIds: [...input.eventIds].sort(),
        events: [...events]
            .sort((left, right) => left.id.localeCompare(right.id))
            .map((event) => ({
            id: event.id,
            type: event.type,
            actorType: event.actorType,
            actorId: event.actorId,
            correlationId: event.correlationId,
            policyVersion: event.policyVersion,
            createdAt: canonicalize(event.createdAt),
            payload: canonicalize((0, shared_1.sanitizeAuditEvidencePayload)(event.payload).payload)
        }))
    };
    return (0, node_crypto_1.createHash)('sha256').update(canonicalJson(canonical)).digest('hex');
}
function cloneAuditEvidenceCheckpoint(checkpoint) {
    return {
        ...checkpoint,
        filters: { ...checkpoint.filters },
        eventIds: [...checkpoint.eventIds],
        createdAt: new Date(checkpoint.createdAt.getTime()),
        updatedAt: new Date(checkpoint.updatedAt.getTime())
    };
}
function normalizeAuditEvidenceCheckpointFilters(filters) {
    return {
        ...(filters.sessionId ? { sessionId: filters.sessionId } : {}),
        ...(filters.correlationId ? { correlationId: filters.correlationId } : {}),
        ...(filters.type ? { type: filters.type } : {}),
        ...(filters.actorId ? { actorId: filters.actorId } : {})
    };
}
function canonicalJson(value) {
    return JSON.stringify(canonicalize(value));
}
function canonicalize(value) {
    if (value instanceof Date)
        return value.toISOString();
    if (Array.isArray(value))
        return value.map((item) => canonicalize(item));
    if (typeof value === 'object' && value !== null) {
        return Object.fromEntries(Object.entries(value)
            .sort(([left], [right]) => left.localeCompare(right))
            .map(([key, item]) => [key, canonicalize(item)]));
    }
    return value;
}
//# sourceMappingURL=audit-evidence-checkpoint.js.map