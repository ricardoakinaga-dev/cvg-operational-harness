import { type TenantId } from '@cvg/platform';
import { type AppointmentDraftInput, type CreateJourneyTaskInput, type JourneyCandidate, type JourneyRepositoryOptions, type JourneyRepositoryPort, type JourneySlot, type LinkPatientInput, type OwnerDraftInput, type PatientDraftInput, type RecordHandoffInput, type SearchPatientInput } from './journeys.ts';
import { type PostgresPoolLike } from './tenant-scoped-postgres.ts';
import type { AppointmentDraftRecord, OwnerDraftRecord, PatientDraftRecord, TaskRecord } from './schema.ts';
/**
 * Tenant-scoped PostgreSQL journey drafts.
 *
 * Every operation runs through a tenant-scoped context; mutations commit in a
 * short transaction with their audit event (`withTenantTransaction`), so RLS
 * and the row-level
 * predicates always see exactly one tenant. Drafts are never deleted: expiry
 * marks `status = 'expired'` and keeps the row as evidence. Appointment drafts
 * are draft-only (`confirmation_blocked = true`); no real confirmation state
 * exists.
 */
export declare class PostgresJourneyRepository implements JourneyRepositoryPort {
    private readonly pool;
    private readonly clock;
    private readonly draftTtlMs;
    constructor(pool: PostgresPoolLike, options?: JourneyRepositoryOptions);
    searchOwnerByPhone(rawTenantId: TenantId, rawPhone: unknown): Promise<JourneyCandidate[]>;
    createOwnerDraft(input: OwnerDraftInput): Promise<OwnerDraftRecord>;
    listOwnerDrafts(rawTenantId: TenantId): Promise<OwnerDraftRecord[]>;
    findOwnerDraft(rawTenantId: TenantId, id: string): Promise<OwnerDraftRecord | null>;
    searchPatient(input: SearchPatientInput): Promise<JourneyCandidate[]>;
    listPatientDrafts(rawTenantId: TenantId): Promise<PatientDraftRecord[]>;
    findPatientDraft(rawTenantId: TenantId, id: string): Promise<PatientDraftRecord | null>;
    createPatientDraft(input: PatientDraftInput): Promise<PatientDraftRecord>;
    linkPatient(input: LinkPatientInput): Promise<PatientDraftRecord>;
    findAvailableSlots(rawTenantId: TenantId, limit?: number): JourneySlot[];
    createAppointmentDraft(input: AppointmentDraftInput): Promise<AppointmentDraftRecord>;
    listAppointmentDrafts(rawTenantId: TenantId): Promise<AppointmentDraftRecord[]>;
    createJourneyTask(input: CreateJourneyTaskInput): Promise<TaskRecord>;
    recordHandoff(input: RecordHandoffInput): Promise<void>;
    private searchOwnerByPhoneScoped;
    private createOwnerDraftScoped;
    private searchPatientScoped;
    private createPatientDraftScoped;
    private createAppointmentDraftScoped;
    private expireOwnerDraftRow;
    private expirePatientDraftRow;
    private expireAppointmentDraftRow;
    private expireOwnerDraftsScoped;
    private expirePatientDraftsScoped;
    private expireAppointmentDraftsScoped;
    private requireOwnerDraftScoped;
    private requirePatientDraftScoped;
    /**
     * Journey references are caller supplied identifiers, so validate their
     * tenant ownership before persisting them in a draft or audit trail.
     * A session may imply its conversation; an explicit pair must agree.
     */
    private resolveJourneyContextScoped;
    private appendJourneyAuditScoped;
    private selectOwnerDraftByKey;
    private selectPatientDraftByKey;
    private selectAppointmentDraftByKey;
    private now;
}
