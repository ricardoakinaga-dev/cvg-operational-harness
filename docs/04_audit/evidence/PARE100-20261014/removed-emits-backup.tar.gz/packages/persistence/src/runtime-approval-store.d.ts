import type { QueryResultRow } from 'pg';
import { type ApprovalAuthority, type ApprovalConsumption, type ApprovalEngineOptions, type ApprovalRecord, type ApprovalRequestInput, type ApprovalReserveInput, type ApprovalReservation, type ApprovalStatus, type EffectEvidence } from '@cvg/approval-engine';
import { type PostgresPoolLike } from './tenant-scoped-postgres.ts';
export interface PostgresApprovalAuthorityOptions {
    /**
     * Engine configuration shared by every scratch decision engine. `store` is
     * owned by the adapter because each operation seeds a fresh scratch store.
     */
    engine?: Omit<ApprovalEngineOptions, 'store'>;
    /**
     * Repository-owned clock for row timestamps. Defaults to the engine clock so
     * the decision state machine and the persisted revision timestamps agree.
     */
    clock?: () => Date;
}
export interface RuntimeApprovalRow extends QueryResultRow {
    tenant_id: string;
    approval_id: string;
    operator_id: string;
    agent_id: string;
    agent_version: string;
    action: string;
    resource_type: string;
    resource_id: string | null;
    payload_hash: string;
    policy_version: string;
    prompt_version: string | null;
    correlation_id: string;
    status: string;
    single_use: boolean;
    requested_at: Date | string;
    expires_at: Date | string;
    approved_at: Date | string | null;
    executed_at: Date | string | null;
    rejected_at: Date | string | null;
    cancelled_at: Date | string | null;
    expired_at: Date | string | null;
    approver_id: string | null;
    decision_reason: string | null;
    execution_count: number;
    execution_ref: string | null;
    reservation_id: string | null;
    reservation_owner: string | null;
    reservation_expires_at: Date | string | null;
    reservation_generation: number | string;
    used_reservation_ids: unknown;
    reserved_at: Date | string | null;
    executing_at: Date | string | null;
    released_at: Date | string | null;
    failed_at: Date | string | null;
    uncertain_at: Date | string | null;
    confirmed_at: Date | string | null;
    confirmation_evidence_ref: string | null;
    proposal_id: string | null;
    proposal_hash: string | null;
    capability: string | null;
    data_classification: string | null;
    proposal_payload: unknown;
    operation_key: string | null;
    revision: number | string;
    created_at: Date | string;
    updated_at: Date | string;
}
/**
 * Maps a `runtime_approvals` row back to the exact canonical `ApprovalRecord`
 * shape the in-memory store would hold. Optional fields absent from the row
 * stay absent (never `undefined` keys) so equality with the scratch engine
 * record is stable.
 */
export declare function mapRuntimeApprovalRow(row: RuntimeApprovalRow): ApprovalRecord;
/**
 * PostgreSQL incarnation of `ApprovalAuthority` (PROD-04, architecture A2).
 *
 * The canonical decision state machine is not duplicated: every operation
 * loads the affected record(s) `FOR UPDATE` inside one `withTenantTransaction`,
 * seeds a scratch `InMemoryApprovalStore`, runs the same synchronous
 * `ApprovalEngine` method and persists the resulting record(s) with a
 * compare-and-set on revision, status, reservation id and reservation
 * generation. SQL serializes writers; the engine remains the only authority
 * that decides transitions.
 */
export declare class PostgresApprovalAuthority implements ApprovalAuthority {
    #private;
    constructor(pool: PostgresPoolLike, options?: PostgresApprovalAuthorityOptions);
    request(input: ApprovalRequestInput): Promise<ApprovalRecord>;
    submit(tenantId: string, approvalId: string, actorId: string): Promise<ApprovalRecord>;
    approve(tenantId: string, approvalId: string, input: {
        approverId: string;
        reason?: string;
    }): Promise<ApprovalRecord>;
    reject(tenantId: string, approvalId: string, input: {
        approverId: string;
        reason?: string;
    }): Promise<ApprovalRecord>;
    cancel(tenantId: string, approvalId: string, actorId: string): Promise<ApprovalRecord>;
    verifyAndConsume(input: {
        tenantId: string;
        approvalId: string;
        action: string;
        resource: {
            type: string;
            id?: string;
        };
        payload: unknown;
        executionRef?: string;
    }): Promise<ApprovalConsumption>;
    reserve(input: ApprovalReserveInput): Promise<ApprovalReservation>;
    markExecuting(input: {
        tenantId: string;
        approvalId: string;
        reservationId: string;
    }): Promise<ApprovalRecord>;
    confirm(input: {
        tenantId: string;
        approvalId: string;
        reservationId: string;
        evidence: EffectEvidence;
    }): Promise<ApprovalRecord>;
    release(input: {
        tenantId: string;
        approvalId: string;
        reservationId: string;
        evidence: EffectEvidence;
    }): Promise<ApprovalRecord>;
    fail(input: {
        tenantId: string;
        approvalId: string;
        reservationId: string;
        evidence: EffectEvidence;
    }): Promise<ApprovalRecord>;
    markUncertain(input: {
        tenantId: string;
        approvalId: string;
        reservationId: string;
        reason: string;
        evidence?: EffectEvidence;
    }): Promise<ApprovalRecord>;
    reconcile(input: {
        tenantId: string;
        approvalId: string;
        actorId: string;
        evidence: EffectEvidence;
    }): Promise<ApprovalRecord>;
    releaseExpired(input: {
        tenantId: string;
        now?: Date;
        ttlMs?: number;
        evidenceFor: (record: ApprovalRecord) => EffectEvidence | undefined;
    }): Promise<{
        released: number;
        uncertain: number;
    }>;
    /**
     * The engine sweep is cross-tenant (`store.listExpiringBefore` has no tenant
     * filter) while every durable connection carries exactly one
     * `cvg.tenant_id`. The durable authority fails closed instead of pretending
     * the RLS scope can cover every tenant; production sweeps per tenant through
     * `releaseExpired`.
     */
    expireStale(): Promise<never>;
    list(tenantId: string, status?: ApprovalStatus): Promise<ApprovalRecord[]>;
    get(tenantId: string, approvalId: string): Promise<ApprovalRecord>;
    /** Approvals still awaiting an operator decision (REQUESTED or PENDING). */
    listPending(tenantId: string): Promise<ApprovalRecord[]>;
    /**
     * Returns every candidate sharing the operation key. The key is not unique:
     * the effect journal (0013) is the authority that binds a key to a single
     * effect, so callers must reconcile candidates explicitly.
     */
    getByOperationKey(tenantId: string, operationKey: string): Promise<ApprovalRecord[]>;
}
