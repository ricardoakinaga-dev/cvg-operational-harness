import { type AgentId, type AgentVersionId, type TenantId } from '@cvg/platform';
import type { InMemoryDatabase } from './db.ts';
import type { AuditEventRecord, OutboxEventRecord } from './schema.ts';
export declare const DEFAULT_OUTBOX_ENVELOPE_VERSION = 1;
export declare const DEFAULT_OUTBOX_MAX_ATTEMPTS = 5;
export declare const DEFAULT_OUTBOX_LEASE_MS = 30000;
export declare const DEFAULT_OUTBOX_RETRY_BASE_MS = 1000;
export declare const DEFAULT_OUTBOX_RETRY_MAX_MS = 60000;
export declare const DEFAULT_OUTBOX_MAX_PAYLOAD_BYTES: number;
export declare const OUTBOX_TAKEOVER_SUPPRESSED_ERROR = "human takeover active; automatic outbound suppressed";
export type OutboxClock = (() => Date) | {
    now(): Date;
};
export interface OutboxRepositoryOptions {
    /** The production repository owns the clock; tests inject a deterministic one. */
    clock?: OutboxClock;
    /** Alias retained for deterministic fixtures. */
    now?: () => Date;
    maxAttempts?: number;
    leaseMs?: number;
    retryBaseMs?: number;
    retryMaxMs?: number;
    backoffBaseMs?: number;
    backoffMaxMs?: number;
    maxPayloadBytes?: number;
    /** A local audit hook may fail; repository operations roll back on failure. */
    auditWriter?: (event: AuditEventRecord) => void;
}
export interface OutboxEnqueueInput {
    tenantId: TenantId;
    type: string;
    payload: unknown;
    idempotencyKey: string;
    correlationId?: string;
    envelopeVersion?: number;
    conversationId?: string | null;
    sessionId?: string | null;
    agentId?: AgentId | null;
    agentVersionId?: AgentVersionId | null;
    inboundMessageId?: string | null;
    /** Test fixtures may provide a stable id; production callers normally omit it. */
    id?: string;
    /** Alias accepted for envelope terminology. */
    eventId?: string;
    /** Reserved for an intentional future migration/command. */
    parentEventId?: string | null;
}
export interface OutboxClaimInput {
    tenantId: TenantId;
    workerId: string;
    /** Deprecated compatibility field; repository-owned time is authoritative. */
    now?: Date;
    leaseMs?: number;
    eventId?: string;
}
export type OutboxEffect = (event: OutboxEventRecord) => unknown | Promise<unknown>;
export type OutboxTakeoverCheck = boolean | (() => boolean | Promise<boolean>);
export interface OutboxAckInput {
    tenantId: TenantId;
    eventId: string;
    workerId: string;
    effect?: OutboxEffect;
    /** Used only when the injected effect intentionally returns no value. */
    result?: unknown;
    /** Rechecked by the adapter inside the ack boundary before any effect. */
    takeoverActive?: OutboxTakeoverCheck;
    /** Deprecated compatibility field; repository-owned time is authoritative. */
    now?: Date;
}
export interface OutboxFailInput {
    tenantId: TenantId;
    eventId: string;
    workerId: string;
    error: unknown;
    /** An unknown handler or equivalent failure is terminal by explicit policy. */
    terminal?: boolean;
    /** Marks a terminal failure caused by human takeover; no effect may run. */
    handoff?: boolean;
    /** Deprecated compatibility field; repository-owned time is authoritative. */
    now?: Date;
}
export interface OutboxRequeueInput {
    tenantId: TenantId;
    eventId: string;
    operatorId: string;
    correlationId: string;
}
export interface DurableOutboxAdapter {
    enqueue(input: OutboxEnqueueInput, tx?: unknown): OutboxEventRecord | Promise<OutboxEventRecord>;
    claimNext(input: OutboxClaimInput): OutboxEventRecord | null | Promise<OutboxEventRecord | null>;
    ack(input: OutboxAckInput): OutboxEventRecord | Promise<OutboxEventRecord>;
    fail(input: OutboxFailInput): OutboxEventRecord | Promise<OutboxEventRecord>;
    requeueDeadLetter(input: OutboxRequeueInput): OutboxEventRecord | Promise<OutboxEventRecord>;
}
/**
 * Deterministic in-memory implementation of the durable outbox contract.
 *
 * It intentionally keeps state in `DatabaseState` so tests can inspect every
 * claim and effect. It does not pretend to provide process durability; the
 * PostgreSQL adapter owns that guarantee.
 */
export declare class OutboxRepository implements DurableOutboxAdapter {
    private readonly db;
    private readonly clock;
    private readonly maxAttempts;
    private readonly leaseMs;
    private readonly retryBaseMs;
    private readonly retryMaxMs;
    private readonly maxPayloadBytes;
    private readonly auditWriter;
    constructor(db: InMemoryDatabase, options?: OutboxRepositoryOptions);
    enqueue(type: string, payload: unknown): OutboxEventRecord;
    enqueue(input: OutboxEnqueueInput, tx?: unknown): OutboxEventRecord;
    /** Lists only pending events for compatibility with the legacy repository. */
    pending(rawTenantId?: TenantId): OutboxEventRecord[];
    findById(eventId: string, rawTenantId?: TenantId): OutboxEventRecord | null;
    claimNext(input: OutboxClaimInput): OutboxEventRecord | null;
    ack(input: OutboxAckInput): OutboxEventRecord | Promise<OutboxEventRecord>;
    fail(input: OutboxFailInput): OutboxEventRecord;
    requeueDeadLetter(input: OutboxRequeueInput): OutboxEventRecord;
    private enqueueLegacy;
    private commitAck;
    private requireOwnedEvent;
    private appendTransitionAudit;
    private markSessionForHandoff;
    private appendAudit;
    private markAttemptOutcome;
    private markExpiredClaim;
    private retryDelayMs;
    private currentTime;
    private replaceEvent;
    private ensureStateCollections;
    private snapshot;
    private restore;
}
