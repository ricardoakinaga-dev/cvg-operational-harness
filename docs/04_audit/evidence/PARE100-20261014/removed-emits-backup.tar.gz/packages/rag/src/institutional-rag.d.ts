import { type TenantId } from '@cvg/platform';
export interface ApprovedInstitutionalSource {
    version: string;
    answer: string;
    source: string;
}
export interface KnowledgeSourceVersion {
    tenantId: TenantId;
    id: string;
    version: string;
    question: string;
    answer: string;
    source: string;
    status: 'draft' | 'published' | 'revoked';
    createdAt: Date;
    publishedAt: Date | null;
    revokedAt: Date | null;
}
/** Versioned local catalog; a revoked or missing source always hands off. */
export declare class VersionedKnowledgeCatalog {
    private readonly records;
    add(input: {
        tenantId: TenantId;
        version: string;
        question: string;
        answer: string;
        source: string;
    }): KnowledgeSourceVersion;
    publish(rawTenantId: TenantId, id: string): KnowledgeSourceVersion;
    revoke(rawTenantId: TenantId, id: string): KnowledgeSourceVersion;
    answer(rawTenantId: TenantId, question: string): ReturnType<typeof answerFromInstitutionalSource>;
    list(rawTenantId: TenantId): KnowledgeSourceVersion[];
    private require;
}
export declare function answerFromInstitutionalSource(question: string, source: ApprovedInstitutionalSource | null): {
    status: string;
    reason: string;
    answer?: never;
    source?: never;
    version?: never;
} | {
    status: string;
    answer: string;
    source: string;
    version: string;
    reason?: never;
};
