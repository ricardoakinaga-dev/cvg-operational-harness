export declare function noopRagSource(): null;
