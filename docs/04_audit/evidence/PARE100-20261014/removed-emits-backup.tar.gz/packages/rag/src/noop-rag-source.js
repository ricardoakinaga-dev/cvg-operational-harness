export function noopRagSource() {
    return null;
}
//# sourceMappingURL=noop-rag-source.js.map