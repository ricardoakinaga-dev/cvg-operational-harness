import type { CanonicalEnvelopeInput, CanonicalOutboundMessage } from './contracts.ts';
export interface InboundDedupStore {
    /**
     * Atomic insert-if-absent with expiration. Returns true only when the caller
     * reserved the key (first delivery).
     */
    reserve(key: string, expiresAtMs: number): boolean;
    has(key: string): boolean;
}
export declare class InMemoryInboundDedupStore implements InboundDedupStore {
    #private;
    constructor(options?: {
        clock?: () => number;
    });
    reserve(key: string, expiresAtMs: number): boolean;
    has(key: string): boolean;
    size(): number;
}
export declare class InboundDeduplicator {
    #private;
    constructor(options?: {
        store?: InboundDedupStore;
        ttlMs?: number;
        clock?: () => number;
    });
    accept(envelope: Pick<CanonicalEnvelopeInput, 'idempotencyKey'>): {
        accepted: boolean;
        key: string;
    };
}
export type { CanonicalOutboundMessage };
