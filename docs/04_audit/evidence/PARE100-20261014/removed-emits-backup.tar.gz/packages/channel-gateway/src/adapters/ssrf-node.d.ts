/**
 * Node-only transport for the composed SSRF guard. The URL hostname remains
 * the authority used for HTTP Host and TLS SNI, while lookup pins the socket
 * to an address already checked by the guard for this exact hop.
 */
export declare function fetchWithResolvedAddress(rawUrl: string, init: Record<string, unknown>, resolvedAddresses: readonly string[]): Promise<Response>;
