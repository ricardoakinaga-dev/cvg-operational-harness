import { CanonicalEnvelopeSchema, canonicalIdempotencyKey } from "../contracts.js";
import { ChannelError } from "../errors.js";
/**
 * Deterministic fake channel used by tests, evals and dry runs. It never
 * performs network calls and keeps an inspectable outbound journal.
 */
export class ControlledFakeChannelAdapter {
    channel;
    enabled = true;
    sent = [];
    #clock;
    #failNextSend;
    constructor(options = {}) {
        this.channel = options.channel ?? 'whatsapp';
        this.#clock = options.clock ?? (() => new Date());
        this.#failNextSend = options.failNextSend ?? false;
    }
    failNextSend() {
        this.#failNextSend = true;
    }
    normalize(raw, context) {
        const message = raw;
        if (!message ||
            typeof message.externalId !== 'string' ||
            typeof message.senderId !== 'string' ||
            typeof message.recipientId !== 'string' ||
            typeof message.text !== 'string') {
            throw new ChannelError('invalid_payload', 'Fake channel payload is invalid');
        }
        const envelope = {
            messageId: `msg_${message.externalId}`,
            externalId: message.externalId,
            tenantId: context.tenantId,
            conversationId: context.conversationId,
            channel: this.channel,
            sender: { id: message.senderId, type: 'phone' },
            recipient: { id: message.recipientId, type: 'phone' },
            timestamp: message.timestamp ?? this.#clock().toISOString(),
            body: {
                text: message.text,
                attachments: Array.from({ length: message.attachmentCount ?? 0 }, (_, index) => ({
                    id: `att_${index}`,
                    kind: 'document',
                    mimeType: 'application/octet-stream',
                    sizeBytes: 1024
                }))
            },
            correlationId: context.correlationId,
            idempotencyKey: canonicalIdempotencyKey({
                tenantId: context.tenantId,
                channel: this.channel,
                externalId: message.externalId
            }),
            metadata: {}
        };
        return CanonicalEnvelopeSchema.parse(envelope);
    }
    async send(message) {
        if (this.#failNextSend) {
            this.#failNextSend = false;
            throw new ChannelError('send_failed', 'Fake channel outage', true);
        }
        this.sent.push(message);
        return {
            externalId: `fake_${message.messageId}`,
            channel: this.channel,
            accepted: true,
            sentAt: this.#clock().toISOString()
        };
    }
}
//# sourceMappingURL=fake.js.map