import { createHash } from 'node:crypto';
import { mkdir, open, readFile, rename, stat, unlink, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { ChannelError } from "./errors.js";
import { LEGACY_HASH_VERSION, assertSupportedPersistedHashVersion, assertValidReconciliationActor, channelEffectHasActiveLease, channelEffectKey, cloneEffectRecord, createEffectRecord, decideReserve, delay, isSupportedHashVersion, isTerminalForWaiter } from "./effect-journal.js";
/**
 * Durable single-host journal. Reservations use atomic file creation, and
 * every transition is a locked read-modify-write with atomic rename, so two
 * processes sharing the same directory cannot both reserve the same
 * operation. It survives process restarts; it does NOT replace PostgreSQL for
 * multi-host deployments.
 */
export class FileChannelEffectJournal {
    #directory;
    #clock;
    #pollMs;
    #lockTimeoutMs;
    #staleLockMs;
    #temporaryCounter = 0;
    constructor(options) {
        if (!options.directory || options.directory.trim() === '') {
            throw new ChannelError('invalid_config', 'FileChannelEffectJournal requires a directory');
        }
        this.#directory = options.directory;
        this.#clock = options.clock ?? (() => Date.now());
        this.#pollMs = options.pollMs ?? 5;
        this.#lockTimeoutMs = options.lockTimeoutMs ?? 2_000;
        this.#staleLockMs = options.staleLockMs ?? 10_000;
    }
    async reserve(input) {
        if (!isSupportedHashVersion(input.hashVersion)) {
            return { outcome: 'version_mismatch' };
        }
        await mkdir(this.#directory, { recursive: true });
        const key = channelEffectKey(input.identity);
        const created = createEffectRecord(input, this.#clock());
        if (await this.#tryCreate(key, created)) {
            return { outcome: 'reserved', record: cloneEffectRecord(created) };
        }
        return this.#withLock(key, async () => {
            const existing = await this.#readRecord(key);
            const decision = decideReserve(existing, input, this.#clock());
            if (decision.action === 'version_mismatch') {
                return { outcome: 'version_mismatch' };
            }
            if (decision.action === 'create') {
                const record = createEffectRecord(input, this.#clock());
                await this.#writeRecord(key, record);
                return { outcome: 'reserved', record: cloneEffectRecord(record) };
            }
            const record = decision.record;
            if (decision.action === 'takeover') {
                await this.#writeRecord(key, record);
                return { outcome: 'reserved', record: cloneEffectRecord(record) };
            }
            if (decision.action === 'uncertain') {
                if (existing?.state !== 'UNCERTAIN')
                    await this.#writeRecord(key, record);
                return { outcome: 'uncertain', record: cloneEffectRecord(record) };
            }
            if (decision.action === 'conflict') {
                return { outcome: 'conflict', record: cloneEffectRecord(record) };
            }
            if (decision.action === 'replay') {
                return { outcome: 'replay', record: cloneEffectRecord(record) };
            }
            return { outcome: 'in_flight', record: cloneEffectRecord(record) };
        });
    }
    async claimSend(identity, leaseOwner) {
        const key = channelEffectKey(identity);
        return this.#withLock(key, async () => {
            const record = await this.#readRecord(key);
            if (record)
                assertSupportedPersistedHashVersion(record);
            const now = this.#clock();
            if (!record ||
                record.state !== 'PENDING' ||
                record.leaseOwner !== leaseOwner ||
                !channelEffectHasActiveLease(record, now)) {
                throw new ChannelError('lease_lost', 'Channel operation lease is not owned by the caller', true);
            }
            const updated = {
                ...record,
                state: 'SENDING',
                updatedAtMs: now,
                revision: record.revision + 1
            };
            await this.#writeRecord(key, updated);
            return cloneEffectRecord(updated);
        });
    }
    async renew(identity, leaseOwner, leaseMs) {
        const key = channelEffectKey(identity);
        return this.#withLock(key, async () => {
            const record = await this.#readRecord(key);
            if (record)
                assertSupportedPersistedHashVersion(record);
            const now = this.#clock();
            if (!record ||
                record.leaseOwner !== leaseOwner ||
                !channelEffectHasActiveLease(record, now)) {
                return false;
            }
            await this.#writeRecord(key, {
                ...record,
                leaseExpiresAtMs: now + leaseMs,
                updatedAtMs: now
            });
            return true;
        });
    }
    async complete(identity, leaseOwner, result) {
        return this.#settle(identity, leaseOwner, (record, now) => ({
            ...record,
            state: 'CONFIRMED',
            result,
            errorCode: null,
            leaseOwner: null,
            leaseExpiresAtMs: null,
            updatedAtMs: now,
            revision: record.revision + 1
        }));
    }
    async fail(identity, leaseOwner, errorCode) {
        return this.#settle(identity, leaseOwner, (record, now) => ({
            ...record,
            state: 'FAILED',
            errorCode,
            leaseOwner: null,
            leaseExpiresAtMs: null,
            updatedAtMs: now,
            revision: record.revision + 1
        }));
    }
    async release(identity, leaseOwner, errorCode) {
        return this.#settle(identity, leaseOwner, (record, now) => ({
            ...record,
            state: 'PENDING',
            errorCode,
            leaseOwner: null,
            leaseExpiresAtMs: null,
            updatedAtMs: now,
            revision: record.revision + 1
        }));
    }
    async markUncertain(identity, leaseOwner, errorCode) {
        return this.#settle(identity, leaseOwner, (record, now) => ({
            ...record,
            state: 'UNCERTAIN',
            errorCode,
            leaseOwner: null,
            leaseExpiresAtMs: null,
            updatedAtMs: now,
            revision: record.revision + 1
        }));
    }
    async find(identity) {
        return this.#readRecord(channelEffectKey(identity));
    }
    async waitForTerminal(identity, timeoutMs) {
        const key = channelEffectKey(identity);
        const deadline = this.#clock() + timeoutMs;
        for (;;) {
            const record = await this.#readRecord(key);
            if (record)
                assertSupportedPersistedHashVersion(record);
            if (record && isTerminalForWaiter(record.state))
                return record;
            const remaining = deadline - this.#clock();
            if (remaining <= 0)
                return undefined;
            await delay(Math.max(1, Math.min(this.#pollMs, remaining)));
        }
    }
    async resolveUncertain(identity, resolution, actor) {
        assertValidReconciliationActor(actor);
        const key = channelEffectKey(identity);
        return this.#withLock(key, async () => {
            const record = await this.#readRecord(key);
            if (record)
                assertSupportedPersistedHashVersion(record);
            if (!record || record.state !== 'UNCERTAIN') {
                throw new ChannelError('reconciliation_required', `Channel operation is ${record?.state ?? 'missing'}, not UNCERTAIN`, false);
            }
            const now = this.#clock();
            const updated = resolution.kind === 'confirmed'
                ? {
                    ...record,
                    state: 'CONFIRMED',
                    result: resolution.result,
                    errorCode: null,
                    updatedAtMs: now,
                    revision: record.revision + 1
                }
                : {
                    ...record,
                    state: 'PENDING',
                    errorCode: null,
                    leaseOwner: null,
                    leaseExpiresAtMs: null,
                    updatedAtMs: now,
                    revision: record.revision + 1
                };
            await this.#writeRecord(key, updated);
            return cloneEffectRecord(updated);
        });
    }
    async #settle(identity, leaseOwner, update) {
        const key = channelEffectKey(identity);
        return this.#withLock(key, async () => {
            const record = await this.#readRecord(key);
            if (!record)
                return 'lease_lost';
            assertSupportedPersistedHashVersion(record);
            if (record.state === 'CONFIRMED' ||
                record.state === 'FAILED' ||
                record.state === 'UNCERTAIN') {
                return 'lease_lost';
            }
            if (record.leaseOwner !== leaseOwner)
                return 'lease_lost';
            await this.#writeRecord(key, update(record, this.#clock()));
            return 'committed';
        });
    }
    async #tryCreate(key, record) {
        try {
            const handle = await open(this.#recordPath(key), 'wx');
            try {
                await handle.writeFile(JSON.stringify(record), 'utf8');
            }
            finally {
                await handle.close();
            }
            return true;
        }
        catch (error) {
            if (error.code === 'EEXIST')
                return false;
            throw new ChannelError('journal_unavailable', 'Channel effect journal could not create the operation record');
        }
    }
    async #readRecord(key) {
        try {
            const raw = await readFile(this.#recordPath(key), 'utf8');
            const parsed = JSON.parse(raw);
            if (!parsed ||
                typeof parsed !== 'object' ||
                typeof parsed.revision !== 'number' ||
                typeof parsed.state !== 'string') {
                throw new Error('invalid channel effect record');
            }
            // Only an absent property represents a legacy record. An explicit
            // malformed or unknown value is preserved as-is and fails closed at the
            // version check; the file is never rewritten on read.
            if (parsed.hashVersion === undefined) {
                parsed.hashVersion = LEGACY_HASH_VERSION;
            }
            return parsed;
        }
        catch (error) {
            if (error.code === 'ENOENT')
                return undefined;
            throw new ChannelError('journal_unavailable', 'Channel effect journal record is unreadable or corrupt');
        }
    }
    async #writeRecord(key, record) {
        const target = this.#recordPath(key);
        const temporary = `${target}.${process.pid}.${this.#temporaryCounter++}.tmp`;
        try {
            await writeFile(temporary, JSON.stringify(record), 'utf8');
            await rename(temporary, target);
        }
        catch {
            await unlink(temporary).catch(() => undefined);
            throw new ChannelError('journal_unavailable', 'Channel effect journal record could not be persisted');
        }
    }
    async #withLock(key, operation) {
        const lockPath = `${this.#recordPath(key)}.lock`;
        const deadline = this.#clock() + this.#lockTimeoutMs;
        for (;;) {
            try {
                const handle = await open(lockPath, 'wx');
                try {
                    await handle.writeFile(String(process.pid), 'utf8');
                }
                finally {
                    await handle.close();
                }
                break;
            }
            catch (error) {
                if (error.code !== 'EEXIST') {
                    throw new ChannelError('journal_unavailable', 'Channel effect journal lock could not be acquired');
                }
                const info = await stat(lockPath).catch(() => undefined);
                if (info && this.#clock() - info.mtimeMs > this.#staleLockMs) {
                    await unlink(lockPath).catch(() => undefined);
                    continue;
                }
                if (this.#clock() >= deadline) {
                    throw new ChannelError('journal_unavailable', 'Timed out acquiring the channel effect journal lock', true);
                }
                await delay(this.#pollMs);
            }
        }
        try {
            return await operation();
        }
        finally {
            await unlink(lockPath).catch(() => undefined);
        }
    }
    #recordPath(key) {
        const digest = createHash('sha256').update(key).digest('hex');
        return join(this.#directory, `${digest}.json`);
    }
}
//# sourceMappingURL=effect-journal-file.js.map