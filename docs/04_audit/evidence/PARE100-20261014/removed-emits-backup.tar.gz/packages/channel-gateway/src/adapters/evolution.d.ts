import type { EgressDns } from '@cvg/shared';
import { type CanonicalEnvelopeInput, type CanonicalOutboundMessage, type InboundChannelAdapter, type InboundNormalizeContext, type OutboundChannelAdapter, type OutboundResult } from '../contracts.ts';
export type FetchLike = (input: string, init: RequestInit) => Promise<Response>;
export interface EvolutionAdapterOptions {
    /** Integrations are opt-in; disabled adapters fail closed. */
    enabled?: boolean;
    baseUrl?: string;
    apiKey?: string;
    instance?: string;
    fetchImpl?: FetchLike;
    clock?: () => Date;
    maxResponseBytes?: number;
    /**
     * AUD19-007 — explicit opt-in for loopback/private networks (local
     * homologation). Default false: private/reserved addresses are denied.
     */
    allowPrivateNetworks?: boolean;
    /** AUD19-007 — injectable DNS for the composed egress guard (tests). */
    dnsLookup?: EgressDns['lookup'];
}
/**
 * EvolutionAPI adapter. Disabled by default; when enabled it requires an
 * explicit HTTPS base URL (or loopback), API key and instance.
 */
export declare class EvolutionChannelAdapter implements InboundChannelAdapter, OutboundChannelAdapter {
    #private;
    readonly channel = "whatsapp";
    readonly enabled: boolean;
    constructor(options?: EvolutionAdapterOptions);
    normalize(raw: unknown, context: InboundNormalizeContext): CanonicalEnvelopeInput;
    send(message: CanonicalOutboundMessage): Promise<OutboundResult>;
}
