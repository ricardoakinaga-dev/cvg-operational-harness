import { type CanonicalEnvelopeInput, type CanonicalOutboundMessage, type InboundChannelAdapter, type InboundNormalizeContext, type OutboundChannelAdapter, type OutboundResult } from '../contracts.ts';
export interface FakeRawMessage {
    externalId: string;
    senderId: string;
    senderName?: string;
    recipientId: string;
    text: string;
    timestamp?: string;
    attachmentCount?: number;
}
export interface ControlledFakeChannelAdapterOptions {
    channel?: string;
    clock?: () => Date;
    failNextSend?: boolean;
}
/**
 * Deterministic fake channel used by tests, evals and dry runs. It never
 * performs network calls and keeps an inspectable outbound journal.
 */
export declare class ControlledFakeChannelAdapter implements InboundChannelAdapter, OutboundChannelAdapter {
    #private;
    readonly channel: string;
    readonly enabled = true;
    readonly sent: CanonicalOutboundMessage[];
    constructor(options?: ControlledFakeChannelAdapterOptions);
    failNextSend(): void;
    normalize(raw: unknown, context: InboundNormalizeContext): CanonicalEnvelopeInput;
    send(message: CanonicalOutboundMessage): Promise<OutboundResult>;
}
