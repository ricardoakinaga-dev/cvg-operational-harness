export class InMemoryInboundDedupStore {
    #entries = new Map();
    #clock;
    constructor(options = {}) {
        this.#clock = options.clock ?? (() => Date.now());
    }
    reserve(key, expiresAtMs) {
        this.#sweep();
        const existing = this.#entries.get(key);
        if (existing !== undefined && existing > this.#clock())
            return false;
        this.#entries.set(key, expiresAtMs);
        return true;
    }
    has(key) {
        this.#sweep();
        return this.#entries.has(key);
    }
    size() {
        return this.#entries.size;
    }
    #sweep() {
        const now = this.#clock();
        for (const [key, expiresAt] of this.#entries) {
            if (expiresAt <= now)
                this.#entries.delete(key);
        }
    }
}
export class InboundDeduplicator {
    #store;
    #ttlMs;
    #clock;
    constructor(options = {}) {
        this.#clock = options.clock ?? (() => Date.now());
        this.#store =
            options.store ?? new InMemoryInboundDedupStore({ clock: this.#clock });
        this.#ttlMs = options.ttlMs ?? 7 * 24 * 60 * 60 * 1000;
    }
    accept(envelope) {
        const key = envelope.idempotencyKey;
        const accepted = this.#store.reserve(key, this.#clock() + this.#ttlMs);
        return { accepted, key };
    }
}
//# sourceMappingURL=idempotency.js.map