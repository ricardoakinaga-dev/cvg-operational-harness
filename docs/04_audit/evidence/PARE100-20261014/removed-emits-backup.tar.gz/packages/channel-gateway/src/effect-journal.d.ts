import type { CanonicalOutboundMessage, OutboundResult } from './contracts.ts';
import { type ChannelErrorCode } from './errors.ts';
export declare const CHANNEL_OPERATION_KIND: "outbound_message";
export type ChannelOperationKind = typeof CHANNEL_OPERATION_KIND;
export declare const LEGACY_HASH_VERSION = "legacy-local-v1";
export declare const SHARED_HASH_VERSION = "shared-rfc8785-subset-v1";
export declare const CURRENT_HASH_VERSION = "shared-rfc8785-subset-v1";
export declare function isSupportedHashVersion(version: unknown): version is string;
/**
 * Returns the version of a persisted record. Only an absent property is
 * interpreted as `legacy-local-v1`; an explicit malformed or unknown value
 * resolves to `undefined` (fail closed) and is never blessed as legacy.
 */
export declare function resolvePersistedHashVersion(record: Pick<ChannelEffectRecord, 'hashVersion'>): string | undefined;
export declare function assertSupportedPersistedHashVersion(record: ChannelEffectRecord): string;
export interface ChannelEffectIdentity {
    tenantId: string;
    channel: string;
    operationKind: ChannelOperationKind;
    idempotencyKey: string;
}
export type ChannelEffectState = 'PENDING' | 'SENDING' | 'CONFIRMED' | 'FAILED' | 'UNCERTAIN' | 'EXPIRED';
export interface ChannelEffectRecord {
    identity: ChannelEffectIdentity;
    payloadHash: string;
    hashVersion: string;
    state: ChannelEffectState;
    attempt: number;
    leaseOwner: string | null;
    leaseExpiresAtMs: number | null;
    result: OutboundResult | null;
    errorCode: ChannelErrorCode | null;
    updatedAtMs: number;
    revision: number;
}
export type ChannelEffectReserveOutcome = {
    outcome: 'reserved';
    record: ChannelEffectRecord;
} | {
    outcome: 'replay';
    record: ChannelEffectRecord;
} | {
    outcome: 'in_flight';
    record: ChannelEffectRecord;
} | {
    outcome: 'conflict';
    record: ChannelEffectRecord;
} | {
    outcome: 'uncertain';
    record: ChannelEffectRecord;
} | {
    outcome: 'version_mismatch';
};
export interface ChannelEffectReserveInput {
    identity: ChannelEffectIdentity;
    payloadHash: string;
    hashVersion: string;
    leaseOwner: string;
    leaseMs: number;
}
export type ChannelEffectTransition = 'committed' | 'lease_lost';
export type ChannelEffectReconciliation = {
    kind: 'confirmed';
    result: OutboundResult;
} | {
    kind: 'not_effected';
};
export interface ChannelEffectReconciliationActor {
    actorId: string;
    reason: string;
}
/**
 * A reconciliation is an audited human/operator intervention: it is only
 * accepted with a non-empty actorId and reason. Invalid actors fail with the
 * stable non-retryable `reconciliation_required` before any mutation.
 */
export declare function assertValidReconciliationActor(actor: {
    actorId?: unknown;
    reason?: unknown;
} | null | undefined): asserts actor is ChannelEffectReconciliationActor;
export interface ChannelEffectJournal {
    reserve(input: ChannelEffectReserveInput): Promise<ChannelEffectReserveOutcome>;
    claimSend(identity: ChannelEffectIdentity, leaseOwner: string): Promise<ChannelEffectRecord>;
    renew(identity: ChannelEffectIdentity, leaseOwner: string, leaseMs: number): Promise<boolean>;
    complete(identity: ChannelEffectIdentity, leaseOwner: string, result: OutboundResult): Promise<ChannelEffectTransition>;
    fail(identity: ChannelEffectIdentity, leaseOwner: string, errorCode: ChannelErrorCode): Promise<ChannelEffectTransition>;
    release(identity: ChannelEffectIdentity, leaseOwner: string, errorCode: ChannelErrorCode): Promise<ChannelEffectTransition>;
    markUncertain(identity: ChannelEffectIdentity, leaseOwner: string, errorCode: ChannelErrorCode): Promise<ChannelEffectTransition>;
    find(identity: ChannelEffectIdentity): Promise<ChannelEffectRecord | undefined>;
    waitForTerminal(identity: ChannelEffectIdentity, timeoutMs: number): Promise<ChannelEffectRecord | undefined>;
    resolveUncertain(identity: ChannelEffectIdentity, resolution: ChannelEffectReconciliation, actor: ChannelEffectReconciliationActor): Promise<ChannelEffectRecord>;
}
export declare function channelEffectKey(identity: ChannelEffectIdentity): string;
export declare function channelEffectHasActiveLease(record: ChannelEffectRecord, nowMs: number): boolean;
export declare function isTerminalForWaiter(state: ChannelEffectState): boolean;
export declare function cloneEffectRecord(record: ChannelEffectRecord): ChannelEffectRecord;
export declare function createEffectRecord(input: ChannelEffectReserveInput, nowMs: number): ChannelEffectRecord;
export interface ReserveDecision {
    action: 'create' | 'takeover' | 'replay' | 'in_flight' | 'conflict' | 'uncertain' | 'version_mismatch';
    record?: ChannelEffectRecord;
}
/**
 * Pure state-machine decision shared by every journal adapter. Callers are
 * responsible for atomicity around read/decision/write.
 */
export declare function decideReserve(existing: ChannelEffectRecord | undefined, input: ChannelEffectReserveInput, nowMs: number): ReserveDecision;
/**
 * @deprecated Kept for API compatibility. The single canonical source is
 * `canonicalizeJson` from `@cvg/shared`; this wrapper delegates to it so no
 * caller keeps the legacy integer-like key ordering.
 */
export declare function canonicalizePayload(value: unknown): string;
export type OutboundPayloadHashInput = Pick<CanonicalOutboundMessage, 'conversationId' | 'channel' | 'recipient' | 'body' | 'correlationId' | 'metadata'>;
/**
 * Stable payload identity for a channel operation. messageId is deliberately
 * excluded so a retried notification with the same content is not treated as
 * a different operation.
 */
export declare function hashOutboundPayload(message: OutboundPayloadHashInput): string;
export interface InMemoryChannelEffectJournalOptions {
    clock?: () => number;
    pollMs?: number;
}
/**
 * Reference journal for a single process. It is atomic within one Node event
 * loop but NOT durable across restarts; use it only in tests, evals and
 * explicitly ephemeral flows. Cross-process durability requires the file or
 * SQL adapters.
 */
export declare class InMemoryChannelEffectJournal implements ChannelEffectJournal {
    #private;
    constructor(options?: InMemoryChannelEffectJournalOptions);
    reserve(input: ChannelEffectReserveInput): Promise<ChannelEffectReserveOutcome>;
    claimSend(identity: ChannelEffectIdentity, leaseOwner: string): Promise<ChannelEffectRecord>;
    renew(identity: ChannelEffectIdentity, leaseOwner: string, leaseMs: number): Promise<boolean>;
    complete(identity: ChannelEffectIdentity, leaseOwner: string, result: OutboundResult): Promise<ChannelEffectTransition>;
    fail(identity: ChannelEffectIdentity, leaseOwner: string, errorCode: ChannelErrorCode): Promise<ChannelEffectTransition>;
    release(identity: ChannelEffectIdentity, leaseOwner: string, errorCode: ChannelErrorCode): Promise<ChannelEffectTransition>;
    markUncertain(identity: ChannelEffectIdentity, leaseOwner: string, errorCode: ChannelErrorCode): Promise<ChannelEffectTransition>;
    find(identity: ChannelEffectIdentity): Promise<ChannelEffectRecord | undefined>;
    waitForTerminal(identity: ChannelEffectIdentity, timeoutMs: number): Promise<ChannelEffectRecord | undefined>;
    resolveUncertain(identity: ChannelEffectIdentity, resolution: ChannelEffectReconciliation, actor: ChannelEffectReconciliationActor): Promise<ChannelEffectRecord>;
}
export declare function delay(ms: number): Promise<void>;
