export const ChannelErrorCodes = {
    invalid_payload: 'invalid_payload',
    invalid_config: 'invalid_config',
    channel_disabled: 'channel_disabled',
    channel_unknown: 'channel_unknown',
    human_takeover_active: 'human_takeover_active',
    send_failed: 'send_failed',
    provider_rejected: 'provider_rejected',
    url_rejected: 'url_rejected',
    idempotency_key_reuse: 'idempotency_key_reuse',
    operation_in_progress: 'operation_in_progress',
    effect_uncertain: 'effect_uncertain',
    lease_lost: 'lease_lost',
    reconciliation_required: 'reconciliation_required',
    journal_unavailable: 'journal_unavailable',
    hash_algorithm_mismatch: 'hash_algorithm_mismatch'
};
export class ChannelError extends Error {
    code;
    retryable;
    effectUnknown;
    constructor(code, message, retryable = false, options = {}) {
        super(message);
        this.name = 'ChannelError';
        this.code = code;
        this.retryable = retryable;
        this.effectUnknown = options.effectUnknown ?? false;
    }
}
//# sourceMappingURL=errors.js.map