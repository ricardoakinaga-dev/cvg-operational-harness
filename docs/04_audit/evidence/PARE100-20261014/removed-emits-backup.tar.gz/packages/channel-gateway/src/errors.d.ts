export declare const ChannelErrorCodes: {
    readonly invalid_payload: "invalid_payload";
    readonly invalid_config: "invalid_config";
    readonly channel_disabled: "channel_disabled";
    readonly channel_unknown: "channel_unknown";
    readonly human_takeover_active: "human_takeover_active";
    readonly send_failed: "send_failed";
    readonly provider_rejected: "provider_rejected";
    readonly url_rejected: "url_rejected";
    readonly idempotency_key_reuse: "idempotency_key_reuse";
    readonly operation_in_progress: "operation_in_progress";
    readonly effect_uncertain: "effect_uncertain";
    readonly lease_lost: "lease_lost";
    readonly reconciliation_required: "reconciliation_required";
    readonly journal_unavailable: "journal_unavailable";
    readonly hash_algorithm_mismatch: "hash_algorithm_mismatch";
};
export type ChannelErrorCode = (typeof ChannelErrorCodes)[keyof typeof ChannelErrorCodes];
export interface ChannelErrorOptions {
    /**
     * True when the send attempt may have reached the provider. The gateway
     * must treat such failures as uncertain: blind retries are forbidden.
     */
    effectUnknown?: boolean;
}
export declare class ChannelError extends Error {
    readonly code: ChannelErrorCode;
    readonly retryable: boolean;
    readonly effectUnknown: boolean;
    constructor(code: ChannelErrorCode, message: string, retryable?: boolean, options?: ChannelErrorOptions);
}
