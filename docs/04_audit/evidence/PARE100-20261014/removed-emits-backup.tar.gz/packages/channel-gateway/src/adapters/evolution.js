import { evaluateOutboundUrl, fetchWithSsrfGuard, isLoopbackHostname } from '@cvg/shared';
import { CanonicalEnvelopeSchema, canonicalIdempotencyKey } from "../contracts.js";
import { ChannelError } from "../errors.js";
import { fetchWithResolvedAddress } from "./ssrf-node.js";
const DEFAULT_MAX_RESPONSE_BYTES = 64 * 1024;
/**
 * EvolutionAPI adapter. Disabled by default; when enabled it requires an
 * explicit HTTPS base URL (or loopback), API key and instance.
 */
export class EvolutionChannelAdapter {
    channel = 'whatsapp';
    enabled;
    #baseUrl;
    #apiKey;
    #instance;
    #fetch;
    #clock;
    #maxResponseBytes;
    #allowedHosts;
    #allowPrivateNetworks;
    #allowHttp;
    #dnsLookup;
    #boundFetch;
    constructor(options = {}) {
        this.enabled = options.enabled ?? false;
        this.#clock = options.clock ?? (() => new Date());
        this.#maxResponseBytes =
            options.maxResponseBytes ?? DEFAULT_MAX_RESPONSE_BYTES;
        if (this.enabled) {
            const baseUrl = options.baseUrl?.trim().replace(/\/+$/, '');
            if (!baseUrl || !options.apiKey || !options.instance) {
                throw new ChannelError('invalid_config', 'EvolutionAPI requires baseUrl, apiKey and instance when enabled');
            }
            let parsedBaseUrl;
            try {
                parsedBaseUrl = new URL(baseUrl);
            }
            catch {
                throw new ChannelError('url_rejected', 'EvolutionAPI base URL rejected: malformed_url');
            }
            const allowPrivateNetworks = options.allowPrivateNetworks ?? false;
            const allowHttp = parsedBaseUrl.protocol === 'http:' &&
                allowPrivateNetworks &&
                isLoopbackHostname(parsedBaseUrl.hostname);
            const guard = evaluateOutboundUrl(baseUrl, {
                allowedProtocols: allowHttp ? ['https:', 'http:'] : ['https:'],
                allowPrivateNetworks
            });
            if (!guard.allowed) {
                throw new ChannelError('url_rejected', `EvolutionAPI base URL rejected: ${guard.reason}`);
            }
            this.#baseUrl = baseUrl;
            this.#apiKey = options.apiKey;
            this.#instance = options.instance;
            this.#fetch = options.fetchImpl ?? globalThis.fetch;
            this.#allowedHosts = [parsedBaseUrl.hostname.toLowerCase()];
            this.#allowPrivateNetworks = allowPrivateNetworks;
            this.#allowHttp = allowHttp;
            this.#dnsLookup = options.dnsLookup;
            this.#boundFetch = options.fetchImpl
                ? undefined
                : fetchWithResolvedAddress;
        }
        else {
            this.#allowedHosts = [];
            this.#allowPrivateNetworks = false;
            this.#allowHttp = false;
            this.#boundFetch = undefined;
        }
    }
    normalize(raw, context) {
        this.#assertEnabled();
        const payload = raw;
        const data = payload?.data;
        const remoteJid = data?.key?.remoteJid;
        const externalId = data?.key?.id;
        const text = data?.message?.conversation ?? data?.message?.extendedTextMessage?.text;
        if (!remoteJid || !externalId || typeof text !== 'string') {
            throw new ChannelError('invalid_payload', 'EvolutionAPI payload is missing message fields');
        }
        if (data?.key?.fromMe === true) {
            throw new ChannelError('invalid_payload', 'Outbound echo events are not accepted as inbound messages');
        }
        const senderId = remoteJid.split('@')[0] ?? remoteJid;
        const timestamp = data?.messageTimestamp
            ? new Date(data.messageTimestamp * 1000).toISOString()
            : this.#clock().toISOString();
        return CanonicalEnvelopeSchema.parse({
            messageId: `msg_${externalId}`,
            externalId,
            tenantId: context.tenantId,
            conversationId: context.conversationId,
            channel: this.channel,
            sender: {
                id: senderId,
                type: 'phone',
                ...(data?.pushName ? { displayName: data.pushName } : {})
            },
            recipient: { id: this.#instance ?? 'instance', type: 'system' },
            timestamp,
            body: { text, attachments: [] },
            correlationId: context.correlationId,
            idempotencyKey: canonicalIdempotencyKey({
                tenantId: context.tenantId,
                channel: this.channel,
                externalId
            }),
            metadata: {}
        });
    }
    async send(message) {
        this.#assertEnabled();
        const endpoint = `${this.#baseUrl}/message/sendText/${this.#instance}`;
        // AUD21-REM21-004 — validate every hop and bind the default Node socket
        // to the addresses returned by that same validation.
        try {
            const fetchImpl = (url, requestInit) => this.#fetch(url, requestInit);
            const deps = this.#boundFetch
                ? {
                    ...(this.#dnsLookup ? { dnsLookup: this.#dnsLookup } : {}),
                    boundFetchImpl: this.#boundFetch
                }
                : { ...(this.#dnsLookup ? { dnsLookup: this.#dnsLookup } : {}) };
            const response = await fetchWithSsrfGuard(fetchImpl, endpoint, {
                method: 'POST',
                headers: {
                    'content-type': 'application/json',
                    apikey: this.#apiKey ?? ''
                },
                body: JSON.stringify({
                    number: message.recipient.id,
                    text: message.body.text
                }),
                redirect: 'manual'
            }, {
                allowedHosts: this.#allowedHosts,
                allowedProtocols: this.#allowHttp ? ['https:', 'http:'] : ['https:'],
                allowPrivateNetworks: this.#allowPrivateNetworks,
                allowLoopbackOnly: this.#allowHttp
            }, deps);
            return this.#mapResponse(response, message);
        }
        catch (error) {
            if (error instanceof ChannelError)
                throw error;
            if (error instanceof Error && error.name === 'UnsafeUrlError') {
                throw new ChannelError('url_rejected', `EvolutionAPI endpoint rejected: ${error.message}`);
            }
            throw new ChannelError('send_failed', 'EvolutionAPI request failed', true, { effectUnknown: true });
        }
    }
    async #mapResponse(response, message) {
        if (!response.ok) {
            throw new ChannelError('provider_rejected', `EvolutionAPI responded with status ${response.status}`, response.status >= 500 || response.status === 429);
        }
        const body = await response.text();
        if (new TextEncoder().encode(body).length > this.#maxResponseBytes) {
            throw new ChannelError('provider_rejected', 'EvolutionAPI response exceeded the size limit');
        }
        return {
            externalId: message.messageId,
            channel: this.channel,
            accepted: true,
            sentAt: this.#clock().toISOString()
        };
    }
    #assertEnabled() {
        if (!this.enabled) {
            throw new ChannelError('channel_disabled', 'EvolutionAPI channel is disabled; enable it explicitly to use it');
        }
    }
}
//# sourceMappingURL=evolution.js.map