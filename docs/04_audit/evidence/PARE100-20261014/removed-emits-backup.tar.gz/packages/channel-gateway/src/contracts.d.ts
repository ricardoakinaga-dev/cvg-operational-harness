import { z } from 'zod';
export declare const MessagePartySchema: z.ZodObject<{
    id: z.ZodString;
    type: z.ZodEnum<{
        system: "system";
        user: "user";
        phone: "phone";
    }>;
    displayName: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type MessageParty = z.infer<typeof MessagePartySchema>;
export declare const MessageAttachmentSchema: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodEnum<{
        image: "image";
        audio: "audio";
        video: "video";
        document: "document";
        other: "other";
    }>;
    mimeType: z.ZodString;
    sizeBytes: z.ZodNumber;
}, z.core.$strict>;
export type MessageAttachment = z.infer<typeof MessageAttachmentSchema>;
export declare const MessageBodySchema: z.ZodObject<{
    text: z.ZodString;
    attachments: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            image: "image";
            audio: "audio";
            video: "video";
            document: "document";
            other: "other";
        }>;
        mimeType: z.ZodString;
        sizeBytes: z.ZodNumber;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export type MessageBody = z.output<typeof MessageBodySchema>;
export declare const CanonicalEnvelopeSchema: z.ZodObject<{
    messageId: z.ZodString;
    externalId: z.ZodString;
    tenantId: z.ZodString;
    conversationId: z.ZodString;
    channel: z.ZodEnum<{
        whatsapp: "whatsapp";
        web: "web";
        internal: "internal";
    }>;
    sender: z.ZodObject<{
        id: z.ZodString;
        type: z.ZodEnum<{
            system: "system";
            user: "user";
            phone: "phone";
        }>;
        displayName: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    recipient: z.ZodObject<{
        id: z.ZodString;
        type: z.ZodEnum<{
            system: "system";
            user: "user";
            phone: "phone";
        }>;
        displayName: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    timestamp: z.ZodString;
    body: z.ZodObject<{
        text: z.ZodString;
        attachments: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                image: "image";
                audio: "audio";
                video: "video";
                document: "document";
                other: "other";
            }>;
            mimeType: z.ZodString;
            sizeBytes: z.ZodNumber;
        }, z.core.$strict>>>;
    }, z.core.$strict>;
    correlationId: z.ZodString;
    idempotencyKey: z.ZodString;
    metadata: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
}, z.core.$strict>;
export type CanonicalEnvelope = z.output<typeof CanonicalEnvelopeSchema>;
export type CanonicalEnvelopeInput = z.input<typeof CanonicalEnvelopeSchema>;
export declare const CanonicalOutboundMessageSchema: z.ZodObject<{
    messageId: z.ZodString;
    tenantId: z.ZodString;
    conversationId: z.ZodString;
    channel: z.ZodEnum<{
        whatsapp: "whatsapp";
        web: "web";
        internal: "internal";
    }>;
    recipient: z.ZodObject<{
        id: z.ZodString;
        type: z.ZodEnum<{
            system: "system";
            user: "user";
            phone: "phone";
        }>;
        displayName: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    body: z.ZodObject<{
        text: z.ZodString;
        attachments: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                image: "image";
                audio: "audio";
                video: "video";
                document: "document";
                other: "other";
            }>;
            mimeType: z.ZodString;
            sizeBytes: z.ZodNumber;
        }, z.core.$strict>>>;
    }, z.core.$strict>;
    correlationId: z.ZodString;
    idempotencyKey: z.ZodString;
    metadata: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
}, z.core.$strict>;
export type CanonicalOutboundMessage = z.output<typeof CanonicalOutboundMessageSchema>;
export type CanonicalOutboundMessageInput = z.input<typeof CanonicalOutboundMessageSchema>;
export interface InboundNormalizeContext {
    tenantId: string;
    conversationId: string;
    correlationId: string;
}
export interface InboundChannelAdapter {
    readonly channel: string;
    readonly enabled: boolean;
    normalize(raw: unknown, context: InboundNormalizeContext): CanonicalEnvelopeInput;
}
export interface OutboundResult {
    externalId: string;
    channel: string;
    accepted: boolean;
    sentAt: string;
}
export interface OutboundChannelAdapter {
    readonly channel: string;
    readonly enabled: boolean;
    send(message: CanonicalOutboundMessage): Promise<OutboundResult>;
}
export declare function canonicalIdempotencyKey(input: {
    tenantId: string;
    channel: string;
    externalId: string;
}): string;
