import { type CanonicalEnvelope, type CanonicalOutboundMessageInput, type InboundChannelAdapter, type InboundNormalizeContext, type OutboundChannelAdapter, type OutboundResult } from './contracts.ts';
import { type ChannelEffectJournal } from './effect-journal.ts';
import { InboundDeduplicator } from './idempotency.ts';
export type ChannelEventType = 'channel.inbound.accepted' | 'channel.inbound.duplicate' | 'channel.inbound.rejected' | 'channel.outbound.sent' | 'channel.outbound.replayed' | 'channel.outbound.blocked' | 'channel.outbound.rejected' | 'channel.outbound.uncertain';
export interface ChannelEvent {
    type: ChannelEventType;
    channel: string;
    tenantId: string;
    correlationId: string;
    messageId?: string;
    code?: string;
}
export interface ChannelGatewayOptions {
    inboundAdapters?: InboundChannelAdapter[];
    outboundAdapters?: OutboundChannelAdapter[];
    deduplicator?: InboundDeduplicator;
    effectJournal?: ChannelEffectJournal;
    leaseMs?: number;
    leaseOwner?: string;
    clock?: () => number;
    waitTimeoutMs?: number;
    heartbeatIntervalMs?: number;
    onEvent?: (event: ChannelEvent) => void;
}
export interface IngestResult {
    accepted: boolean;
    duplicate: boolean;
    envelope: CanonicalEnvelope;
}
export declare const DEFAULT_CHANNEL_LEASE_MS = 30000;
/**
 * Single entry point for every channel. Inbound payloads are canonicalized and
 * deduplicated; outbound messages are blocked by human takeover and reserved
 * atomically before any provider effect, so concurrent dispatches, retries and
 * restarts never produce a second confirmed send for the same operation.
 */
export declare class ChannelGateway {
    #private;
    constructor(options?: ChannelGatewayOptions);
    ingest(channel: string, raw: unknown, context: InboundNormalizeContext): IngestResult;
    dispatch(message: CanonicalOutboundMessageInput, options: {
        takeoverActive: boolean;
    }): Promise<OutboundResult>;
}
