import type { EgressDns } from '@cvg/shared';
import { type CanonicalEnvelopeInput, type CanonicalOutboundMessage, type InboundChannelAdapter, type InboundNormalizeContext, type OutboundChannelAdapter, type OutboundResult } from '../contracts.ts';
import type { FetchLike } from './evolution.ts';
export interface ChatwootAdapterOptions {
    enabled?: boolean;
    baseUrl?: string;
    apiKey?: string;
    accountId?: string;
    fetchImpl?: FetchLike;
    clock?: () => Date;
    maxResponseBytes?: number;
    /**
     * AUD19-007 — explicit opt-in for loopback/private networks (local
     * homologation). Default false: private/reserved addresses are denied.
     */
    allowPrivateNetworks?: boolean;
    /** AUD19-007 — injectable DNS for the composed egress guard (tests). */
    dnsLookup?: EgressDns['lookup'];
}
/**
 * Chatwoot adapter. Disabled by default and fail-closed when enabled without
 * complete configuration.
 */
export declare class ChatwootChannelAdapter implements InboundChannelAdapter, OutboundChannelAdapter {
    #private;
    readonly channel = "web";
    readonly enabled: boolean;
    constructor(options?: ChatwootAdapterOptions);
    normalize(raw: unknown, context: InboundNormalizeContext): CanonicalEnvelopeInput;
    send(message: CanonicalOutboundMessage): Promise<OutboundResult>;
}
