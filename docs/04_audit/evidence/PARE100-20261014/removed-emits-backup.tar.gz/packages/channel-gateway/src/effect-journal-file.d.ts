import type { OutboundResult } from './contracts.ts';
import { type ChannelErrorCode } from './errors.ts';
import { type ChannelEffectIdentity, type ChannelEffectJournal, type ChannelEffectReconciliation, type ChannelEffectReconciliationActor, type ChannelEffectRecord, type ChannelEffectReserveInput, type ChannelEffectReserveOutcome, type ChannelEffectTransition } from './effect-journal.ts';
export interface FileChannelEffectJournalOptions {
    /** Directory owned by this journal; one JSON file per operation. */
    directory: string;
    clock?: () => number;
    pollMs?: number;
    lockTimeoutMs?: number;
    staleLockMs?: number;
}
/**
 * Durable single-host journal. Reservations use atomic file creation, and
 * every transition is a locked read-modify-write with atomic rename, so two
 * processes sharing the same directory cannot both reserve the same
 * operation. It survives process restarts; it does NOT replace PostgreSQL for
 * multi-host deployments.
 */
export declare class FileChannelEffectJournal implements ChannelEffectJournal {
    #private;
    constructor(options: FileChannelEffectJournalOptions);
    reserve(input: ChannelEffectReserveInput): Promise<ChannelEffectReserveOutcome>;
    claimSend(identity: ChannelEffectIdentity, leaseOwner: string): Promise<ChannelEffectRecord>;
    renew(identity: ChannelEffectIdentity, leaseOwner: string, leaseMs: number): Promise<boolean>;
    complete(identity: ChannelEffectIdentity, leaseOwner: string, result: OutboundResult): Promise<ChannelEffectTransition>;
    fail(identity: ChannelEffectIdentity, leaseOwner: string, errorCode: ChannelErrorCode): Promise<ChannelEffectTransition>;
    release(identity: ChannelEffectIdentity, leaseOwner: string, errorCode: ChannelErrorCode): Promise<ChannelEffectTransition>;
    markUncertain(identity: ChannelEffectIdentity, leaseOwner: string, errorCode: ChannelErrorCode): Promise<ChannelEffectTransition>;
    find(identity: ChannelEffectIdentity): Promise<ChannelEffectRecord | undefined>;
    waitForTerminal(identity: ChannelEffectIdentity, timeoutMs: number): Promise<ChannelEffectRecord | undefined>;
    resolveUncertain(identity: ChannelEffectIdentity, resolution: ChannelEffectReconciliation, actor: ChannelEffectReconciliationActor): Promise<ChannelEffectRecord>;
}
