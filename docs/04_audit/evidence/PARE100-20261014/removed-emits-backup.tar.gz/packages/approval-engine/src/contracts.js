import { createHash } from 'node:crypto';
import { z } from 'zod';
import { canonicalizeJson } from '@cvg/shared';
export const ApprovalStatusSchema = z.enum([
    'REQUESTED',
    'PENDING',
    'APPROVED',
    'RESERVED',
    'EXECUTING',
    'REJECTED',
    'EXPIRED',
    'CANCELLED',
    'EXECUTED',
    'FAILED',
    'UNCERTAIN'
]);
export const ApprovalDecisionActorTypeSchema = z.enum([
    'Approver',
    'Supervisor'
]);
export const ApprovalResourceSchema = z
    .object({
    type: z.string().min(1).max(120),
    id: z.string().min(1).max(160).optional()
})
    .strict();
export const ApprovalRequestSchema = z
    .object({
    tenantId: z.string().min(1).max(120),
    operatorId: z.string().min(1).max(120),
    agentId: z.string().min(1).max(120),
    agentVersion: z.string().min(1).max(120),
    action: z.string().min(1).max(120),
    resource: ApprovalResourceSchema,
    payload: z.unknown(),
    policyVersion: z.string().min(1).max(120),
    promptVersion: z.string().min(1).max(120).optional(),
    correlationId: z.string().min(8).max(120),
    expiresInMs: z
        .number()
        .int()
        .min(1_000)
        .max(7 * 24 * 60 * 60 * 1_000)
        .optional(),
    singleUse: z.boolean().optional(),
    reason: z.string().max(500).optional(),
    operationKey: z.string().trim().min(1).max(200).optional(),
    executionRef: z.string().trim().min(1).max(200).optional(),
    proposalId: z.string().min(1).max(160).optional(),
    proposalHash: z
        .string()
        .regex(/^[0-9a-f]{64}$/)
        .optional(),
    capability: z.string().min(1).max(120).optional(),
    dataClassification: z.string().min(1).max(120).optional(),
    proposalPayload: z.unknown().optional()
})
    .strict();
/**
 * Typed proof about an effect. Absence/confirmation must be explicit; missing or
 * ambiguous information can never release a reservation by inference.
 */
export const EffectEvidenceSchema = z.discriminatedUnion('outcome', [
    z
        .object({
        outcome: z.literal('no_effect'),
        source: z.enum(['journal', 'adapter', 'operator']),
        evidenceRef: z.string().min(1).max(200)
    })
        .strict(),
    z
        .object({
        outcome: z.literal('effect_confirmed'),
        executionRef: z.string().min(1).max(200),
        evidenceRef: z.string().min(1).max(200)
    })
        .strict(),
    z
        .object({
        outcome: z.literal('effect_possibly_started'),
        evidenceRef: z.string().min(1).max(200)
    })
        .strict(),
    z
        .object({
        outcome: z.literal('unknown'),
        reason: z.string().min(1).max(500)
    })
        .strict()
]);
export const ApprovalReserveSchema = z
    .object({
    tenantId: z.string().min(1).max(120),
    approvalId: z.string().min(1).max(160),
    action: z.string().min(1).max(120),
    resource: ApprovalResourceSchema,
    payload: z.unknown().optional(),
    proposalHash: z
        .string()
        .regex(/^[0-9a-f]{64}$/)
        .optional(),
    agentId: z.string().min(1).max(120).optional(),
    agentVersion: z.string().min(1).max(120).optional(),
    policyVersion: z.string().min(1).max(120).optional(),
    capability: z.string().min(1).max(120).optional(),
    operationKey: z.string().trim().min(1).max(200).optional(),
    reservationId: z.string().min(1).max(160).optional(),
    ownerId: z.string().min(1).max(120).optional(),
    ttlMs: z
        .number()
        .int()
        .min(1_000)
        .max(7 * 24 * 60 * 60 * 1_000)
        .optional()
})
    .strict();
export const ApprovalDecisionInputSchema = z
    .object({
    approverId: z.string().trim().min(3).max(80),
    reason: z.string().max(500).optional(),
    decisionActorType: ApprovalDecisionActorTypeSchema.optional(),
    decisionCorrelationId: z.string().trim().min(8).max(120).optional(),
    commandKey: z
        .string()
        .trim()
        .min(8)
        .max(200)
        .regex(/^[A-Za-z0-9._:-]+$/)
        .optional()
})
    .strict();
export function computeApprovalPayloadHash(input) {
    const canonical = canonicalizeJson({
        action: input.action,
        resource: {
            type: input.resource.type,
            ...(input.resource.id !== undefined ? { id: input.resource.id } : {})
        },
        payload: input.payload
    });
    return createHash('sha256').update(canonical, 'utf8').digest('hex');
}
export function approvalMatchesAction(record, candidate) {
    if (record.action !== candidate.action)
        return false;
    if (record.resource.type !== candidate.resource.type)
        return false;
    if ((record.resource.id ?? null) !== (candidate.resource.id ?? null))
        return false;
    return record.payloadHash === computeApprovalPayloadHash(candidate);
}
//# sourceMappingURL=contracts.js.map