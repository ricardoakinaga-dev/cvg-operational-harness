import { z } from 'zod';
export declare const ApprovalStatusSchema: z.ZodEnum<{
    REQUESTED: "REQUESTED";
    PENDING: "PENDING";
    APPROVED: "APPROVED";
    RESERVED: "RESERVED";
    EXECUTING: "EXECUTING";
    REJECTED: "REJECTED";
    EXPIRED: "EXPIRED";
    CANCELLED: "CANCELLED";
    EXECUTED: "EXECUTED";
    FAILED: "FAILED";
    UNCERTAIN: "UNCERTAIN";
}>;
export type ApprovalStatus = z.infer<typeof ApprovalStatusSchema>;
export declare const ApprovalDecisionActorTypeSchema: z.ZodEnum<{
    Approver: "Approver";
    Supervisor: "Supervisor";
}>;
export type ApprovalDecisionActorType = z.infer<typeof ApprovalDecisionActorTypeSchema>;
export declare const ApprovalResourceSchema: z.ZodObject<{
    type: z.ZodString;
    id: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type ApprovalResource = z.infer<typeof ApprovalResourceSchema>;
export declare const ApprovalRequestSchema: z.ZodObject<{
    tenantId: z.ZodString;
    operatorId: z.ZodString;
    agentId: z.ZodString;
    agentVersion: z.ZodString;
    action: z.ZodString;
    resource: z.ZodObject<{
        type: z.ZodString;
        id: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    payload: z.ZodUnknown;
    policyVersion: z.ZodString;
    promptVersion: z.ZodOptional<z.ZodString>;
    correlationId: z.ZodString;
    expiresInMs: z.ZodOptional<z.ZodNumber>;
    singleUse: z.ZodOptional<z.ZodBoolean>;
    reason: z.ZodOptional<z.ZodString>;
    operationKey: z.ZodOptional<z.ZodString>;
    executionRef: z.ZodOptional<z.ZodString>;
    proposalId: z.ZodOptional<z.ZodString>;
    proposalHash: z.ZodOptional<z.ZodString>;
    capability: z.ZodOptional<z.ZodString>;
    dataClassification: z.ZodOptional<z.ZodString>;
    proposalPayload: z.ZodOptional<z.ZodUnknown>;
}, z.core.$strict>;
/**
 * Typed proof about an effect. Absence/confirmation must be explicit; missing or
 * ambiguous information can never release a reservation by inference.
 */
export declare const EffectEvidenceSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    outcome: z.ZodLiteral<"no_effect">;
    source: z.ZodEnum<{
        journal: "journal";
        adapter: "adapter";
        operator: "operator";
    }>;
    evidenceRef: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    outcome: z.ZodLiteral<"effect_confirmed">;
    executionRef: z.ZodString;
    evidenceRef: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    outcome: z.ZodLiteral<"effect_possibly_started">;
    evidenceRef: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    outcome: z.ZodLiteral<"unknown">;
    reason: z.ZodString;
}, z.core.$strict>], "outcome">;
export type EffectEvidence = z.infer<typeof EffectEvidenceSchema>;
export declare const ApprovalReserveSchema: z.ZodObject<{
    tenantId: z.ZodString;
    approvalId: z.ZodString;
    action: z.ZodString;
    resource: z.ZodObject<{
        type: z.ZodString;
        id: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    payload: z.ZodOptional<z.ZodUnknown>;
    proposalHash: z.ZodOptional<z.ZodString>;
    agentId: z.ZodOptional<z.ZodString>;
    agentVersion: z.ZodOptional<z.ZodString>;
    policyVersion: z.ZodOptional<z.ZodString>;
    capability: z.ZodOptional<z.ZodString>;
    operationKey: z.ZodOptional<z.ZodString>;
    reservationId: z.ZodOptional<z.ZodString>;
    ownerId: z.ZodOptional<z.ZodString>;
    ttlMs: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
export type ApprovalReserveInput = z.input<typeof ApprovalReserveSchema>;
export interface ApprovalReservation {
    approvalId: string;
    tenantId: string;
    reservationId: string;
    reservationOwner: string;
    reservedAt: string;
    reservationExpiresAt: string;
    action: string;
    resource: ApprovalResource;
    payloadHash: string;
    generation: number;
    proposalHash?: string;
    operationKey?: string;
}
export type ApprovalRequestInput = z.input<typeof ApprovalRequestSchema>;
export type NormalizedApprovalRequest = z.output<typeof ApprovalRequestSchema>;
export declare const ApprovalDecisionInputSchema: z.ZodObject<{
    approverId: z.ZodString;
    reason: z.ZodOptional<z.ZodString>;
    decisionActorType: z.ZodOptional<z.ZodEnum<{
        Approver: "Approver";
        Supervisor: "Supervisor";
    }>>;
    decisionCorrelationId: z.ZodOptional<z.ZodString>;
    commandKey: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type ApprovalDecisionInput = z.input<typeof ApprovalDecisionInputSchema>;
export interface ApprovalRecord {
    approvalId: string;
    tenantId: string;
    operatorId: string;
    agentId: string;
    agentVersion: string;
    action: string;
    resource: ApprovalResource;
    payloadHash: string;
    policyVersion: string;
    promptVersion?: string;
    correlationId: string;
    status: ApprovalStatus;
    singleUse: boolean;
    requestedAt: string;
    expiresAt: string;
    approvedAt?: string;
    executedAt?: string;
    rejectedAt?: string;
    cancelledAt?: string;
    expiredAt?: string;
    approverId?: string;
    decisionActorType?: ApprovalDecisionActorType;
    decisionCorrelationId?: string;
    decisionCommandKey?: string;
    decisionReason?: string;
    executionCount: number;
    executionRef?: string;
    reservationId?: string;
    reservationOwner?: string;
    reservationExpiresAt?: string;
    reservationGeneration?: number;
    usedReservationIds?: string[];
    reservedAt?: string;
    executingAt?: string;
    releasedAt?: string;
    failedAt?: string;
    uncertainAt?: string;
    confirmedAt?: string;
    confirmationEvidenceRef?: string;
    proposalId?: string;
    proposalHash?: string;
    capability?: string;
    dataClassification?: string;
    proposalPayload?: unknown;
    operationKey?: string;
}
export declare function computeApprovalPayloadHash(input: {
    action: string;
    resource: ApprovalResource;
    payload: unknown;
}): string;
export declare function approvalMatchesAction(record: Pick<ApprovalRecord, 'action' | 'resource' | 'payloadHash'>, candidate: {
    action: string;
    resource: ApprovalResource;
    payload: unknown;
}): boolean;
