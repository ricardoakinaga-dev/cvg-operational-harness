export class InMemoryApprovalStore {
    #records = new Map();
    #key(tenantId, approvalId) {
        return `${tenantId}:${approvalId}`;
    }
    insert(record) {
        this.#records.set(this.#key(record.tenantId, record.approvalId), record);
    }
    get(tenantId, approvalId) {
        return this.#records.get(this.#key(tenantId, approvalId));
    }
    update(tenantId, approvalId, expectedStatus, update) {
        const key = this.#key(tenantId, approvalId);
        const current = this.#records.get(key);
        if (!current || current.status !== expectedStatus)
            return undefined;
        const next = update(current);
        this.#records.set(key, next);
        return next;
    }
    list(query) {
        const records = [...this.#records.values()].filter((record) => record.tenantId === query.tenantId &&
            (query.status === undefined || record.status === query.status));
        return records.slice(0, query.limit ?? records.length);
    }
    listExpiringBefore(nowIso, statuses) {
        return [...this.#records.values()].filter((record) => statuses.includes(record.status) &&
            Date.parse(record.expiresAt) < Date.parse(nowIso));
    }
}
//# sourceMappingURL=store.js.map