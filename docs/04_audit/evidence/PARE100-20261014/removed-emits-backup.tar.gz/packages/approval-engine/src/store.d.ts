import type { ApprovalRecord, ApprovalStatus } from './contracts.ts';
export interface ApprovalQuery {
    tenantId: string;
    status?: ApprovalStatus;
    limit?: number;
}
export interface ApprovalStore {
    insert(record: ApprovalRecord): void;
    get(tenantId: string, approvalId: string): ApprovalRecord | undefined;
    /** Compare-and-set transition; returns the updated record or undefined. */
    update(tenantId: string, approvalId: string, expectedStatus: ApprovalStatus, update: (current: ApprovalRecord) => ApprovalRecord): ApprovalRecord | undefined;
    list(query: ApprovalQuery): ApprovalRecord[];
    listExpiringBefore(nowIso: string, statuses: readonly ApprovalStatus[]): ApprovalRecord[];
}
export declare class InMemoryApprovalStore implements ApprovalStore {
    #private;
    insert(record: ApprovalRecord): void;
    get(tenantId: string, approvalId: string): ApprovalRecord | undefined;
    update(tenantId: string, approvalId: string, expectedStatus: ApprovalStatus, update: (current: ApprovalRecord) => ApprovalRecord): ApprovalRecord | undefined;
    list(query: ApprovalQuery): ApprovalRecord[];
    listExpiringBefore(nowIso: string, statuses: readonly ApprovalStatus[]): ApprovalRecord[];
}
