import { type ApprovalRecord, type ApprovalDecisionInput, type ApprovalRequestInput, type ApprovalReservation, type ApprovalReserveInput, type ApprovalResource, type EffectEvidence } from './contracts.ts';
import { type ApprovalStore } from './store.ts';
export declare const ApprovalErrorCodes: {
    readonly not_found: "not_found";
    readonly invalid_state: "invalid_state";
    readonly tenant_mismatch: "tenant_mismatch";
    readonly action_mismatch: "action_mismatch";
    readonly payload_mismatch: "payload_mismatch";
    readonly proposal_mismatch: "proposal_mismatch";
    readonly expired: "expired";
    readonly already_executed: "already_executed";
    readonly already_reserved: "already_reserved";
    readonly reservation_expired: "reservation_expired";
    readonly reservation_mismatch: "reservation_mismatch";
    readonly reservation_reused: "reservation_reused";
    readonly uncertain: "uncertain";
    readonly invalid_proof: "invalid_proof";
    readonly self_approval_denied: "self_approval_denied";
    readonly not_authorized: "not_authorized";
    readonly invalid_request: "invalid_request";
};
export type ApprovalErrorCode = (typeof ApprovalErrorCodes)[keyof typeof ApprovalErrorCodes];
export declare class ApprovalError extends Error {
    readonly code: ApprovalErrorCode;
    constructor(code: ApprovalErrorCode, message: string);
}
export type ApprovalEventType = 'approval.requested' | 'approval.pending' | 'approval.approved' | 'approval.rejected' | 'approval.expired' | 'approval.cancelled' | 'approval.reserved' | 'approval.executing' | 'approval.released' | 'approval.failed' | 'approval.uncertain' | 'approval.reconciled' | 'approval.executed' | 'approval.denied';
export interface ApprovalEvent {
    type: ApprovalEventType;
    approvalId: string;
    tenantId: string;
    correlationId: string;
    actorId?: string;
    detail?: string;
    reservationId?: string;
}
export interface ApprovalEngineOptions {
    store?: ApprovalStore;
    clock?: () => Date;
    idFactory?: () => string;
    defaultExpiryMs?: number;
    reservationTtlMs?: number;
    allowSelfApproval?: boolean;
    onEvent?: (event: ApprovalEvent) => void;
}
export interface ApprovalConsumption {
    approvalId: string;
    tenantId: string;
    action: string;
    payloadHash: string;
    executedAt: string;
    executionRef?: string;
}
/**
 * Cryptographically bound, single-use, expiring approval engine.
 *
 * An approval for action A can never execute action B: the approval stores a
 * SHA-256 hash of the canonical action payload and every execution re-derives
 * and compares the hash before consuming the approval.
 */
export declare class ApprovalEngine {
    #private;
    constructor(options?: ApprovalEngineOptions);
    request(input: ApprovalRequestInput): ApprovalRecord;
    submit(tenantId: string, approvalId: string, actorId: string): ApprovalRecord;
    approve(tenantId: string, approvalId: string, rawInput: ApprovalDecisionInput): ApprovalRecord;
    reject(tenantId: string, approvalId: string, rawInput: ApprovalDecisionInput): ApprovalRecord;
    cancel(tenantId: string, approvalId: string, actorId: string): ApprovalRecord;
    verifyAndConsume(input: {
        tenantId: string;
        approvalId: string;
        action: string;
        resource: ApprovalResource;
        payload: unknown;
        executionRef?: string;
    }): ApprovalConsumption;
    /**
     * Reserves an approved request without executing the effect. Only
     * confirm(executionRef, effect_confirmed evidence) can reach EXECUTED.
     */
    reserve(input: ApprovalReserveInput): ApprovalReservation;
    markExecuting(input: {
        tenantId: string;
        approvalId: string;
        reservationId: string;
    }): ApprovalRecord;
    confirm(input: {
        tenantId: string;
        approvalId: string;
        reservationId: string;
        evidence: EffectEvidence;
    }): ApprovalRecord;
    release(input: {
        tenantId: string;
        approvalId: string;
        reservationId: string;
        evidence: EffectEvidence;
    }): ApprovalRecord;
    fail(input: {
        tenantId: string;
        approvalId: string;
        reservationId: string;
        evidence: EffectEvidence;
    }): ApprovalRecord;
    markUncertain(input: {
        tenantId: string;
        approvalId: string;
        reservationId: string;
        reason: string;
        evidence?: EffectEvidence;
    }): ApprovalRecord;
    reconcile(input: {
        tenantId: string;
        approvalId: string;
        actorId: string;
        evidence: EffectEvidence;
    }): ApprovalRecord;
    /**
     * TTL recovery sweep. It never executes an effect: explicit `no_effect`
     * evidence returns the approval to APPROVED; anything else (missing,
     * ambiguous or throwing evidence) keeps an honest UNCERTAIN state.
     */
    releaseExpired(input: {
        tenantId: string;
        now?: Date;
        ttlMs?: number;
        evidenceFor: (record: ApprovalRecord) => EffectEvidence | undefined;
    }): {
        released: number;
        uncertain: number;
    };
    expireStale(now?: Date): number;
    list(tenantId: string, status?: ApprovalRecord['status']): ApprovalRecord[];
    get(tenantId: string, approvalId: string): ApprovalRecord;
}
