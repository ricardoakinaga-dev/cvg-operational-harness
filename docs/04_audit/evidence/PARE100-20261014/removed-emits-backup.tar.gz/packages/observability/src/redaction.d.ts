export declare function redactValue(value: unknown, depth?: number): unknown;
/**
 * Centralized redaction for structured logs and telemetry attributes. Never
 * pass raw medical notes, credentials or full personal identifiers to sinks.
 */
export declare function redactFields(fields: Record<string, unknown> | undefined): Record<string, unknown>;
export declare function redactAttributeValue(value: string): string;
export declare function assertNoSensitiveKeys(fields: Record<string, unknown>): string[];
