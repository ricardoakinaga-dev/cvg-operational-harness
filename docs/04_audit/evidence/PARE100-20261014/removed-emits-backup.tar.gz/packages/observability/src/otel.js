import { SpanStatusCode, context as otelContext, trace as otelTrace } from '@opentelemetry/api';
import { InMemoryTelemetry } from "./telemetry.js";
/**
 * Real OpenTelemetry adapter. Spans are exported through the configured
 * TracerProvider; metrics through the configured MeterProvider. Local bounded
 * buffers are kept for diagnostics and tests.
 */
export class OpenTelemetryTelemetry {
    #tracer;
    #meter;
    #fallback;
    #instruments = new Map();
    constructor(options) {
        this.#tracer = options.tracer;
        if (options.meter)
            this.#meter = options.meter;
        this.#fallback = options.fallback ?? new InMemoryTelemetry();
    }
    startSpan(name, attributes = {}, parent) {
        const otelAttributes = toOtelAttributes(attributes);
        if (parent?.correlationId) {
            otelAttributes.correlationId = parent.correlationId;
        }
        const otelSpan = this.#tracer.startSpan(name, {
            attributes: otelAttributes
        });
        return new OtelActiveSpan(this, name, otelSpan, attributes, this.#tracer);
    }
    recordMetric(name, value, attributes = {}) {
        this.#fallback.recordMetric(name, value, attributes);
        if (!this.#meter)
            return;
        const instrument = this.#instrument(name);
        if (name.endsWith('_total') || name.endsWith('_count')) {
            ;
            instrument.add(value, toOtelAttributes(attributes));
        }
        else {
            ;
            instrument.record(value, toOtelAttributes(attributes));
        }
    }
    log(level, message, fields) {
        this.#fallback.log(level, message, fields);
    }
    spans() {
        return this.#fallback.spans();
    }
    metrics() {
        return this.#fallback.metrics();
    }
    logs() {
        return this.#fallback.logs();
    }
    recordLocalSpan(span) {
        this.#fallback
            .startSpan(span.name, span.attributes, {
            traceId: span.traceId,
            spanId: span.spanId,
            correlationId: span.correlationId
        })
            .end(span.status, span.errorCode);
    }
    #instrument(name) {
        const existing = this.#instruments.get(name);
        if (existing)
            return existing;
        const instrument = name.endsWith('_total') || name.endsWith('_count')
            ? this.#meter.createCounter(name)
            : this.#meter.createHistogram(name);
        this.#instruments.set(name, instrument);
        return instrument;
    }
}
class OtelActiveSpan {
    name;
    traceId;
    spanId;
    context;
    #telemetry;
    #span;
    #tracer;
    #attributes;
    #ended = false;
    constructor(telemetry, name, span, attributes, tracer) {
        this.#telemetry = telemetry;
        this.#span = span;
        this.#tracer = tracer;
        this.name = name;
        const spanContext = span.spanContext();
        this.traceId = spanContext.traceId;
        this.spanId = spanContext.spanId;
        const correlationId = typeof attributes.correlationId === 'string'
            ? attributes.correlationId
            : 'corr_unknown_span';
        this.context = {
            traceId: this.traceId,
            spanId: this.spanId,
            correlationId
        };
        this.#attributes = { ...attributes };
    }
    setAttribute(key, value) {
        this.#attributes[key] = value;
        this.#span.setAttribute(key, value);
        return this;
    }
    child(name, attributes = {}) {
        const parentContext = otelTrace.setSpan(otelContext.active(), this.#span);
        const childSpan = this.#tracer.startSpan(name, { attributes: toOtelAttributes(attributes) }, parentContext);
        return new OtelActiveSpan(this.#telemetry, name, childSpan, attributes, this.#tracer);
    }
    end(status = 'ok', errorCode) {
        if (this.#ended)
            return;
        this.#ended = true;
        if (status === 'error') {
            this.#span.setStatus({
                code: SpanStatusCode.ERROR,
                ...(errorCode !== undefined ? { message: errorCode } : {})
            });
        }
        else {
            this.#span.setStatus({ code: SpanStatusCode.OK });
        }
        this.#span.end();
        this.#telemetry.recordLocalSpan({
            name: this.name,
            traceId: this.traceId,
            spanId: this.spanId,
            correlationId: this.context.correlationId,
            startedAt: new Date(0).toISOString(),
            endedAt: new Date(0).toISOString(),
            durationMs: 0,
            status,
            ...(errorCode !== undefined ? { errorCode } : {}),
            attributes: this.#attributes
        });
    }
}
function toOtelAttributes(attributes) {
    const result = {};
    for (const [key, value] of Object.entries(attributes)) {
        result[key] = value;
    }
    return result;
}
//# sourceMappingURL=otel.js.map