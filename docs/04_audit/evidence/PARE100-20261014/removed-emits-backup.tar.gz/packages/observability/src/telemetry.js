import { cryptoIdGenerator } from "./trace-context.js";
import { redactAttributeValue, redactFields } from "./redaction.js";
export const METRIC_ATTRIBUTE_ALLOWLIST = [
    'operation',
    'channel',
    'provider',
    'model',
    'profile',
    'status',
    'decision',
    'capability',
    'agentProfile',
    'risk',
    'outcome'
];
export class MetricAttributeError extends Error {
    key;
    constructor(key) {
        super(`Metric attribute ${key} is not allowlisted to avoid high cardinality`);
        this.name = 'MetricAttributeError';
        this.key = key;
    }
}
/**
 * Deterministic in-process telemetry. Used by tests, evals and by engines that
 * run without an OpenTelemetry runtime; the OTel adapter lives in otel.ts.
 */
export class InMemoryTelemetry {
    #clock;
    #ids;
    #spans = [];
    #metrics = [];
    #logs = [];
    #onSpan;
    #onMetric;
    #onLog;
    #maxSpans;
    #maxMetrics;
    #maxLogs;
    constructor(options = {}) {
        this.#clock = options.clock ?? (() => new Date());
        this.#ids = options.idGenerator ?? cryptoIdGenerator;
        if (options.onSpan)
            this.#onSpan = options.onSpan;
        if (options.onMetric)
            this.#onMetric = options.onMetric;
        if (options.onLog)
            this.#onLog = options.onLog;
        this.#maxSpans = options.maxSpans ?? 1_000;
        this.#maxMetrics = options.maxMetrics ?? 5_000;
        this.#maxLogs = options.maxLogs ?? 2_000;
    }
    startSpan(name, attributes = {}, parent) {
        return new InMemoryActiveSpan(this, {
            name,
            attributes,
            ...(parent !== undefined ? { parent } : {}),
            clock: this.#clock,
            ids: this.#ids,
            record: (span) => this.#recordSpan(span)
        });
    }
    recordMetric(name, value, attributes = {}) {
        for (const key of Object.keys(attributes)) {
            if (!METRIC_ATTRIBUTE_ALLOWLIST.includes(key)) {
                throw new MetricAttributeError(key);
            }
        }
        const metric = {
            name,
            value,
            attributes: sanitizeAttributes(attributes),
            timestamp: this.#clock().toISOString()
        };
        pushBounded(this.#metrics, metric, this.#maxMetrics);
        this.#onMetric?.(metric);
    }
    log(level, message, fields = {}) {
        const log = {
            level,
            message: redactAttributeValue(message),
            fields: redactFields(fields),
            timestamp: this.#clock().toISOString()
        };
        pushBounded(this.#logs, log, this.#maxLogs);
        this.#onLog?.(log);
    }
    spans() {
        return [...this.#spans];
    }
    metrics() {
        return [...this.#metrics];
    }
    logs() {
        return [...this.#logs];
    }
    #recordSpan(span) {
        pushBounded(this.#spans, span, this.#maxSpans);
        this.#onSpan?.(span);
    }
}
class InMemoryActiveSpan {
    name;
    traceId;
    spanId;
    context;
    #telemetry;
    #attributes;
    #parentSpanId;
    #clock;
    #ids;
    #record;
    #startedAt;
    #ended = false;
    constructor(telemetry, options) {
        this.#telemetry = telemetry;
        this.name = options.name;
        this.#clock = options.clock;
        this.#ids = options.ids;
        this.#record = options.record;
        this.traceId = options.parent?.traceId ?? options.ids.traceId();
        this.spanId = options.ids.spanId();
        this.#parentSpanId = options.parent?.spanId;
        this.#startedAt = options.clock();
        this.#attributes = sanitizeAttributes(options.attributes);
        this.context = {
            traceId: this.traceId,
            spanId: this.spanId,
            correlationId: options.parent?.correlationId ??
                attributeString(this.#attributes, 'correlationId') ??
                'corr_unknown_span',
            ...pickContextAttribute('tenantId', options.parent?.tenantId, this.#attributes),
            ...pickContextAttribute('conversationId', options.parent?.conversationId, this.#attributes),
            ...pickContextAttribute('sessionId', options.parent?.sessionId, this.#attributes),
            ...pickContextAttribute('agentId', options.parent?.agentId, this.#attributes),
            ...pickContextAttribute('agentVersion', options.parent?.agentVersion, this.#attributes)
        };
    }
    setAttribute(key, value) {
        this.#attributes[key] = redactAttributeValue(String(value));
        return this;
    }
    child(name, attributes = {}) {
        return this.#telemetry.startSpan(name, attributes, this.context);
    }
    end(status = 'ok', errorCode) {
        if (this.#ended)
            return;
        this.#ended = true;
        const endedAt = this.#clock();
        const span = {
            name: this.name,
            traceId: this.traceId,
            spanId: this.spanId,
            ...(this.#parentSpanId !== undefined
                ? { parentSpanId: this.#parentSpanId }
                : {}),
            correlationId: this.context.correlationId,
            startedAt: this.#startedAt.toISOString(),
            endedAt: endedAt.toISOString(),
            durationMs: Math.max(0, endedAt.getTime() - this.#startedAt.getTime()),
            status,
            ...(errorCode !== undefined ? { errorCode } : {}),
            attributes: this.#attributes
        };
        this.#record(span);
    }
}
function attributeString(attributes, key) {
    const value = attributes[key];
    return typeof value === 'string' ? value : undefined;
}
function pickContextAttribute(key, parentValue, attributes) {
    const value = parentValue ?? attributeString(attributes, key);
    return value !== undefined ? { [key]: value } : {};
}
function sanitizeAttributes(attributes) {
    const result = {};
    for (const [key, value] of Object.entries(attributes)) {
        result[key] = redactAttributeValue(String(value));
    }
    return result;
}
function pushBounded(target, value, max) {
    target.push(value);
    while (target.length > max)
        target.shift();
}
export async function withTelemetrySpan(telemetry, name, attributes, operation) {
    const span = telemetry.startSpan(name, attributes);
    try {
        const result = await operation(span);
        span.end('ok');
        return result;
    }
    catch (error) {
        span.end('error', error instanceof Error && 'code' in error
            ? String(error.code)
            : 'error');
        throw error;
    }
}
//# sourceMappingURL=telemetry.js.map