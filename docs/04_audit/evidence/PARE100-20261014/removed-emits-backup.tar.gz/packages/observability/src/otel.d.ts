import { type Meter, type Tracer } from '@opentelemetry/api';
import { type ActiveSpan, type Attributes, type LogLevel, type RecordedLog, type RecordedMetric, type RecordedSpan, type Telemetry } from './telemetry.ts';
export interface OpenTelemetryOptions {
    tracer: Tracer;
    meter?: Meter;
    /** Local bounded buffer used for logs and inspection. */
    fallback?: Telemetry;
}
/**
 * Real OpenTelemetry adapter. Spans are exported through the configured
 * TracerProvider; metrics through the configured MeterProvider. Local bounded
 * buffers are kept for diagnostics and tests.
 */
export declare class OpenTelemetryTelemetry implements Telemetry {
    #private;
    constructor(options: OpenTelemetryOptions);
    startSpan(name: string, attributes?: Attributes, parent?: import('./trace-context.ts').TraceContext): ActiveSpan;
    recordMetric(name: string, value: number, attributes?: Attributes): void;
    log(level: LogLevel, message: string, fields?: Record<string, unknown>): void;
    spans(): RecordedSpan[];
    metrics(): RecordedMetric[];
    logs(): RecordedLog[];
    recordLocalSpan(span: RecordedSpan): void;
}
