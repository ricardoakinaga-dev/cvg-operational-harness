import type { TraceContext, TraceIdGenerator } from './trace-context.ts';
export type LogLevel = 'debug' | 'info' | 'warn' | 'error';
export type AttributeValue = string | number | boolean;
export type Attributes = Record<string, AttributeValue>;
export interface RecordedSpan {
    name: string;
    traceId: string;
    spanId: string;
    parentSpanId?: string;
    correlationId: string;
    startedAt: string;
    endedAt: string;
    durationMs: number;
    status: 'ok' | 'error';
    errorCode?: string;
    attributes: Attributes;
}
export interface RecordedMetric {
    name: string;
    value: number;
    attributes: Attributes;
    timestamp: string;
}
export interface RecordedLog {
    level: LogLevel;
    message: string;
    fields: Record<string, unknown>;
    timestamp: string;
}
export interface ActiveSpan {
    readonly name: string;
    readonly traceId: string;
    readonly spanId: string;
    readonly context: TraceContext;
    setAttribute(key: string, value: AttributeValue): ActiveSpan;
    child(name: string, attributes?: Attributes): ActiveSpan;
    end(status?: 'ok' | 'error', errorCode?: string): void;
}
export interface Telemetry {
    startSpan(name: string, attributes?: Attributes, parent?: TraceContext): ActiveSpan;
    recordMetric(name: string, value: number, attributes?: Attributes): void;
    log(level: LogLevel, message: string, fields?: Record<string, unknown>): void;
    spans(): RecordedSpan[];
    metrics(): RecordedMetric[];
    logs(): RecordedLog[];
}
export declare const METRIC_ATTRIBUTE_ALLOWLIST: readonly string[];
export declare class MetricAttributeError extends Error {
    readonly key: string;
    constructor(key: string);
}
export interface TelemetryOptions {
    clock?: () => Date;
    idGenerator?: TraceIdGenerator;
    onSpan?: (span: RecordedSpan) => void;
    onMetric?: (metric: RecordedMetric) => void;
    onLog?: (log: RecordedLog) => void;
    maxSpans?: number;
    maxMetrics?: number;
    maxLogs?: number;
}
/**
 * Deterministic in-process telemetry. Used by tests, evals and by engines that
 * run without an OpenTelemetry runtime; the OTel adapter lives in otel.ts.
 */
export declare class InMemoryTelemetry implements Telemetry {
    #private;
    constructor(options?: TelemetryOptions);
    startSpan(name: string, attributes?: Attributes, parent?: TraceContext): ActiveSpan;
    recordMetric(name: string, value: number, attributes?: Attributes): void;
    log(level: LogLevel, message: string, fields?: Record<string, unknown>): void;
    spans(): RecordedSpan[];
    metrics(): RecordedMetric[];
    logs(): RecordedLog[];
}
export declare function withTelemetrySpan<T>(telemetry: Telemetry, name: string, attributes: Attributes, operation: (span: ActiveSpan) => Promise<T>): Promise<T>;
