import { z } from 'zod';
export declare const TraceContextSchema: z.ZodObject<{
    traceId: z.ZodString;
    spanId: z.ZodString;
    correlationId: z.ZodString;
    tenantId: z.ZodOptional<z.ZodString>;
    conversationId: z.ZodOptional<z.ZodString>;
    sessionId: z.ZodOptional<z.ZodString>;
    agentId: z.ZodOptional<z.ZodString>;
    agentVersion: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type TraceContext = z.infer<typeof TraceContextSchema>;
export interface TraceContextInput {
    correlationId: string;
    tenantId?: string;
    conversationId?: string;
    sessionId?: string;
    agentId?: string;
    agentVersion?: string;
}
export interface TraceIdGenerator {
    traceId(): string;
    spanId(): string;
}
export declare const cryptoIdGenerator: TraceIdGenerator;
export declare function createTraceContext(input: TraceContextInput, generator?: TraceIdGenerator): TraceContext;
export declare function toTraceparent(context: TraceContext): string;
export declare function fromTraceparent(traceparent: string, correlationId: string): TraceContext | undefined;
export declare function createCorrelationId(): string;
