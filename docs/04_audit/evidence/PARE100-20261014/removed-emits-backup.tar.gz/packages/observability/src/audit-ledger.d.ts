import { z } from 'zod';
export declare const GENESIS_HASH: string;
export declare const AuditLedgerEntrySchema: z.ZodObject<{
    eventId: z.ZodString;
    type: z.ZodString;
    actor: z.ZodString;
    tenantId: z.ZodString;
    correlationId: z.ZodString;
    timestamp: z.ZodString;
    payload: z.ZodOptional<z.ZodUnknown>;
}, z.core.$strict>;
export type AuditLedgerEntry = z.output<typeof AuditLedgerEntrySchema>;
export type AuditLedgerEntryInput = z.input<typeof AuditLedgerEntrySchema>;
export interface AuditLedgerRecord extends AuditLedgerEntry {
    sequence: number;
    previousHash: string;
    payloadHash: string;
    eventHash: string;
}
export interface AuditLedgerVerification {
    valid: boolean;
    brokenAt?: number;
    reason?: string;
}
/**
 * Append-only hash-chained audit ledger. Each event binds the previous event
 * hash, its own payload hash and its metadata, so silent tampering breaks the
 * chain and is detectable. This is integrity, not blockchain.
 */
export declare class HashChainedAuditLedger {
    #private;
    append(entry: AuditLedgerEntryInput): AuditLedgerRecord;
    /**
     * Returns the internal records for inspection/verification. References are
     * exposed so adversarial tests can prove tampering is detected; callers must
     * not mutate them in production paths.
     */
    records(): AuditLedgerRecord[];
    head(): AuditLedgerRecord | undefined;
    size(): number;
    verify(): AuditLedgerVerification;
}
