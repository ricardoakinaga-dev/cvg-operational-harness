/**
 * SSRF defense for outbound HTTP tools/providers.
 *
 * Static URL validation plus optional DNS resolution verification. Private,
 * loopback, link-local, multicast and documentation ranges are denied by
 * default; host allowlists are exact or `*.suffix` matches.
 */
export declare const DEFAULT_URL_MAX_LENGTH = 2048;
export interface UrlGuardOptions {
    allowedProtocols?: readonly string[];
    allowedHosts?: readonly string[];
    allowPrivateNetworks?: boolean;
    /** Restrict a private-network opt-in to loopback addresses only. */
    allowLoopbackOnly?: boolean;
    allowHttp?: boolean;
    maxUrlLength?: number;
}
export interface UrlGuardAllowed {
    allowed: true;
    url: URL;
}
export interface UrlGuardDenied {
    allowed: false;
    reason: string;
}
export type UrlGuardResult = UrlGuardAllowed | UrlGuardDenied;
export declare class UnsafeUrlError extends Error {
    readonly reason: string;
    constructor(reason: string);
}
export declare function isPrivateIpAddress(rawAddress: string): boolean;
export declare function isLoopbackHostname(rawHostname: string): boolean;
export declare function evaluateOutboundUrl(rawUrl: string, options?: UrlGuardOptions): UrlGuardResult;
export declare function assertSafeOutboundUrl(rawUrl: string, options?: UrlGuardOptions): URL;
export declare function evaluateResolvedAddresses(addresses: readonly string[], options?: Pick<UrlGuardOptions, 'allowPrivateNetworks' | 'allowLoopbackOnly'>): UrlGuardResult | {
    allowed: true;
};
export interface EgressDns {
    lookup(hostname: string): Promise<readonly string[]>;
}
export interface EgressGuardOptions extends UrlGuardOptions {
    maxRedirects?: number;
}
export interface GuardedOutboundUrl {
    url: URL;
    resolvedAddresses: readonly string[];
}
/**
 * AUD19-007 — composed egress guard: static policy PLUS resolution.
 * Every resolved address is validated, including for allowlisted hosts
 * (an allowlist names who may be contacted, never which addresses are
 * safe). Literal IP hostnames skip DNS. Any DNS failure, empty resolution
 * or private/reserved address denies fail-closed.
 */
export declare function resolveAndGuardOutboundUrl(rawUrl: string, options?: EgressGuardOptions, deps?: {
    dnsLookup?: EgressDns['lookup'];
}): Promise<GuardedOutboundUrl>;
export interface GuardedFetchResponse {
    status: number;
    headers: {
        get(name: string): string | null;
    };
}
export type BoundFetchImpl<T extends GuardedFetchResponse> = (url: string, init: Record<string, unknown>, resolvedAddresses: readonly string[]) => Promise<T>;
/**
 * AUD19-007 — fetch with per-hop egress validation. The initial URL and
 * every redirect target (absolute or relative) pass the full composed guard
 * before any bytes are sent to that hop. Redirects are followed manually so
 * no hop is ever contacted without validation.
 */
export declare function fetchWithSsrfGuard<T extends GuardedFetchResponse>(fetchImpl: (url: string, init: Record<string, unknown>) => Promise<T>, rawUrl: string, init: Record<string, unknown> | undefined, options?: EgressGuardOptions, deps?: {
    dnsLookup?: EgressDns['lookup'];
    boundFetchImpl?: BoundFetchImpl<T>;
}): Promise<T>;
