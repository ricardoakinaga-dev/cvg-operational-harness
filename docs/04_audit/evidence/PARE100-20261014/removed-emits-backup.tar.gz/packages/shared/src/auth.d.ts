import { z } from 'zod';
import type { Role } from './enums.ts';
export declare function roleHasPermission(role: Role, permission: string): boolean;
export declare function requirePermission(role: Role, permission: string): void;
export declare const OperatorRoleSchema: z.ZodEnum<{
    Operator: "Operator";
    Approver: "Approver";
    Supervisor: "Supervisor";
    Admin: "Admin";
}>;
export type OperatorRole = z.infer<typeof OperatorRoleSchema>;
export declare const OperatorIdentitySchema: z.ZodObject<{
    operatorId: z.ZodString;
    role: z.ZodEnum<{
        Operator: "Operator";
        Approver: "Approver";
        Supervisor: "Supervisor";
        Admin: "Admin";
    }>;
    tenantId: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type OperatorIdentity = z.infer<typeof OperatorIdentitySchema>;
export declare function parseOperatorIdentity(headers: Record<string, unknown>): OperatorIdentity;
/**
 * Trusted identity port. Implementations resolve an operator identity from the
 * request (claims/tokens), never from self-asserted simulation headers.
 */
export type OperatorIdentityResolver = (headers: Record<string, unknown>) => OperatorIdentity;
export declare const IdentityModeSchema: z.ZodEnum<{
    simulation: "simulation";
    trusted: "trusted";
}>;
export type IdentityMode = z.infer<typeof IdentityModeSchema>;
export declare const IDENTITY_MODE_ENV = "CVG_IDENTITY_MODE";
/**
 * Explicit identity mode. `simulation` is the controlled header-based flow and
 * is only a default for `NODE_ENV=test`; every other environment fails closed
 * to `trusted` unless an operator opts in explicitly.
 */
export declare function parseIdentityMode(raw: string | null | undefined, nodeEnv: string | undefined): IdentityMode;
export interface IdentitySigningKey {
    keyId: string;
    /** Local/synthetic key material only; production secrets stay in runtime env. */
    secret: string;
}
/**
 * Rotation port for trusted identity signing keys. Implementations must return
 * only the keys usable at `nowSeconds`: revoked keys and previous keys past the
 * bounded rotation window are omitted, so a stale or revoked key never
 * authorizes a request.
 */
export interface IdentityKeyRingPort {
    keysAt(nowSeconds: number): readonly IdentitySigningKey[];
}
