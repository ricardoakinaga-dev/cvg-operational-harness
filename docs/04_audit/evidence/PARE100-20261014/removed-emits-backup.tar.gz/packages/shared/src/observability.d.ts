import { type CorrelationId } from './ids.ts';
export interface Correlated {
    correlationId: CorrelationId;
}
export declare function withCorrelation<T extends object>(value: T, correlationId?: CorrelationId): T & Correlated;
