import { z } from 'zod';
export declare const DomainIdSchema: z.ZodString;
export type DomainId = z.infer<typeof DomainIdSchema>;
export declare function createDomainId(prefix: string): DomainId;
export declare const CorrelationIdSchema: z.ZodString;
export type CorrelationId = z.infer<typeof CorrelationIdSchema>;
export declare function createCorrelationId(): CorrelationId;
export declare const IdempotencyKeySchema: z.ZodString;
export type IdempotencyKey = z.infer<typeof IdempotencyKeySchema>;
