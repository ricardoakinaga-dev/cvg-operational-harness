import type { CorrelationId } from './ids.ts';
export interface ApiEnvelope<T> {
    success: boolean;
    data: T | null;
    error: {
        code: string;
        message: string;
    } | null;
    meta: {
        correlationId: CorrelationId;
    };
}
export declare function ok<T>(data: T, correlationId: CorrelationId): ApiEnvelope<T>;
export declare function fail(code: string, message: string, correlationId: CorrelationId): ApiEnvelope<never>;
