import { createCorrelationId } from "./ids.js";
export function withCorrelation(value, correlationId = createCorrelationId()) {
    return { ...value, correlationId };
}
//# sourceMappingURL=observability.js.map