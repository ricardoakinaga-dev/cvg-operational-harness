export declare const auditEvidenceGovernance: {
    readonly retention: {
        readonly policyId: "controlled-construction-audit-retention-v1";
        readonly mode: "controlled_construction";
        readonly defaultRetentionDays: 30;
        readonly auditEvidenceRetentionDays: 180;
        readonly approvedForRealData: false;
        readonly humanSignoffRequired: true;
    };
    readonly payload: {
        readonly mode: "minimized";
        readonly rawPayloadReturned: false;
    };
    readonly export: {
        readonly externalDispatch: false;
        readonly externalExportRequiresApproval: true;
    };
};
export interface SanitizedAuditEvidencePayload {
    payload: unknown;
    redactedFields: string[];
}
export declare const REDACTED_OUTBOX_ERROR = "[redacted-outbox-error]";
/**
 * Durable error columns are operational metadata, never an error-message
 * transport. Preserve only a bounded machine code when one is explicitly
 * supplied; arbitrary Error messages are replaced with a fixed marker.
 */
export declare function sanitizeOutboxError(error: unknown): string;
export declare function sanitizeAuditEvidencePayload(payload: unknown): SanitizedAuditEvidencePayload;
/**
 * Sanitizes durable queue envelopes while preserving their shape for a
 * controlled consumer. Audit evidence intentionally drops sensitive fields;
 * an outbox envelope instead keeps stable keys as explicit placeholders so a
 * worker can correlate the event by id without persisting raw inbound content.
 */
export declare function sanitizeOutboxPayload(payload: unknown): SanitizedAuditEvidencePayload;
export declare function redactSensitiveText(text: string): string;
