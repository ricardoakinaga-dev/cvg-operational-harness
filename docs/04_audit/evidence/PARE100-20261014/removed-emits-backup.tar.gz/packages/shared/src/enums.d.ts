import { z } from 'zod';
export declare const ChannelSchema: z.ZodEnum<{
    whatsapp: "whatsapp";
    web: "web";
    internal: "internal";
}>;
export type Channel = z.infer<typeof ChannelSchema>;
export declare const ConversationStatusSchema: z.ZodEnum<{
    new: "new";
    active: "active";
    waiting_human: "waiting_human";
    waiting_approval: "waiting_approval";
    resolved: "resolved";
    archived: "archived";
}>;
export type ConversationStatus = z.infer<typeof ConversationStatusSchema>;
export declare const SessionStatusSchema: z.ZodEnum<{
    open: "open";
    collecting_data: "collecting_data";
    triage: "triage";
    scheduling: "scheduling";
    handoff: "handoff";
    closed: "closed";
}>;
export type SessionStatus = z.infer<typeof SessionStatusSchema>;
export declare const IntentSchema: z.ZodEnum<{
    triage: "triage";
    scheduling: "scheduling";
    handoff: "handoff";
    identify_owner_pet: "identify_owner_pet";
    task: "task";
    institutional_question: "institutional_question";
    unknown: "unknown";
}>;
export type Intent = z.infer<typeof IntentSchema>;
export declare const RiskLevelSchema: z.ZodEnum<{
    low: "low";
    medium: "medium";
    high: "high";
    critical: "critical";
}>;
export type RiskLevel = z.infer<typeof RiskLevelSchema>;
export declare const AutonomyLevelSchema: z.ZodEnum<{
    level_1_collect: "level_1_collect";
    level_2_suggest: "level_2_suggest";
}>;
export type AutonomyLevel = z.infer<typeof AutonomyLevelSchema>;
export declare const ApprovalDecisionSchema: z.ZodEnum<{
    approved: "approved";
    rejected: "rejected";
    assumed: "assumed";
}>;
export type ApprovalDecision = z.infer<typeof ApprovalDecisionSchema>;
export declare const ApprovalStatusSchema: z.ZodEnum<{
    approved: "approved";
    rejected: "rejected";
    assumed: "assumed";
    pending: "pending";
    expired: "expired";
}>;
export type ApprovalStatus = z.infer<typeof ApprovalStatusSchema>;
export declare const TaskPrioritySchema: z.ZodEnum<{
    low: "low";
    medium: "medium";
    high: "high";
    urgent: "urgent";
}>;
export type TaskPriority = z.infer<typeof TaskPrioritySchema>;
export declare const TaskStatusSchema: z.ZodEnum<{
    open: "open";
    in_progress: "in_progress";
    done: "done";
    canceled: "canceled";
}>;
export type TaskStatus = z.infer<typeof TaskStatusSchema>;
export declare const RoleSchema: z.ZodEnum<{
    Operator: "Operator";
    Approver: "Approver";
    Supervisor: "Supervisor";
    Admin: "Admin";
    System: "System";
}>;
export type Role = z.infer<typeof RoleSchema>;
export declare const ToolStatusSchema: z.ZodEnum<{
    pending: "pending";
    succeeded: "succeeded";
    failed: "failed";
    blocked: "blocked";
}>;
export type ToolStatus = z.infer<typeof ToolStatusSchema>;
export declare const PolicyDecisionSchema: z.ZodEnum<{
    handoff: "handoff";
    blocked: "blocked";
    allowed: "allowed";
    requires_approval: "requires_approval";
}>;
export type PolicyDecision = z.infer<typeof PolicyDecisionSchema>;
