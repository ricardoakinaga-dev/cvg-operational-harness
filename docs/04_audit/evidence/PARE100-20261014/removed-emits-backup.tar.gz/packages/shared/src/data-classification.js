import { z } from 'zod';
/**
 * Data classification and handling policy.
 *
 * Technical support for LGPD-aligned governance: purpose limitation,
 * minimization, retention and transmission rules per class. This is not a
 * legal compliance claim.
 */
export const DataClassificationSchema = z.enum([
    'PUBLIC',
    'INTERNAL',
    'CONFIDENTIAL',
    'CLINICAL',
    'FINANCIAL',
    'CREDENTIAL'
]);
export const LlmTransmissionSchema = z.enum([
    'EXTERNAL_MODEL_ALLOWED',
    'LOCAL_ONLY',
    'NO_MODEL'
]);
export const HandlingActionSchema = z.enum([
    'allow',
    'redact',
    'require_approval',
    'forbid'
]);
export const DATA_HANDLING_POLICY = Object.freeze({
    PUBLIC: {
        classification: 'PUBLIC',
        logging: 'allow',
        telemetry: 'allow',
        rag: 'allow',
        export: 'allow',
        backup: 'allow',
        llmTransmission: 'EXTERNAL_MODEL_ALLOWED',
        retentionDays: 365,
        requiresAccessAudit: false
    },
    INTERNAL: {
        classification: 'INTERNAL',
        logging: 'allow',
        telemetry: 'allow',
        rag: 'require_approval',
        export: 'require_approval',
        backup: 'allow',
        llmTransmission: 'EXTERNAL_MODEL_ALLOWED',
        retentionDays: 365,
        requiresAccessAudit: false
    },
    CONFIDENTIAL: {
        classification: 'CONFIDENTIAL',
        logging: 'redact',
        telemetry: 'redact',
        rag: 'require_approval',
        export: 'require_approval',
        backup: 'allow',
        llmTransmission: 'LOCAL_ONLY',
        retentionDays: 180,
        requiresAccessAudit: true
    },
    CLINICAL: {
        classification: 'CLINICAL',
        logging: 'forbid',
        telemetry: 'forbid',
        rag: 'require_approval',
        export: 'require_approval',
        backup: 'allow',
        llmTransmission: 'NO_MODEL',
        retentionDays: 730,
        requiresAccessAudit: true
    },
    FINANCIAL: {
        classification: 'FINANCIAL',
        logging: 'redact',
        telemetry: 'forbid',
        rag: 'forbid',
        export: 'require_approval',
        backup: 'allow',
        llmTransmission: 'NO_MODEL',
        retentionDays: 1825,
        requiresAccessAudit: true
    },
    CREDENTIAL: {
        classification: 'CREDENTIAL',
        logging: 'forbid',
        telemetry: 'forbid',
        rag: 'forbid',
        export: 'forbid',
        backup: 'forbid',
        llmTransmission: 'NO_MODEL',
        retentionDays: 0,
        requiresAccessAudit: true
    }
});
export function handlingRuleFor(classification) {
    return DATA_HANDLING_POLICY[classification];
}
export function mayTransmitToExternalModel(classification) {
    return (handlingRuleFor(classification).llmTransmission === 'EXTERNAL_MODEL_ALLOWED');
}
export function mayTransmitToLocalModel(classification) {
    const transmission = handlingRuleFor(classification).llmTransmission;
    return (transmission === 'EXTERNAL_MODEL_ALLOWED' || transmission === 'LOCAL_ONLY');
}
export function mayTransmitToModel(classification, modelLocation) {
    return modelLocation === 'external'
        ? mayTransmitToExternalModel(classification)
        : mayTransmitToLocalModel(classification);
}
export function requiresRedaction(classification) {
    return handlingRuleFor(classification).logging !== 'allow';
}
export function retentionDaysFor(classification) {
    return handlingRuleFor(classification).retentionDays;
}
/**
 * Highest-risk class in a set; used to select the strictest handling rule when
 * data of multiple classes flows through one operation.
 */
export function strictestClassification(classifications) {
    const order = [
        'PUBLIC',
        'INTERNAL',
        'CONFIDENTIAL',
        'CLINICAL',
        'FINANCIAL',
        'CREDENTIAL'
    ];
    let selected = 'PUBLIC';
    for (const classification of classifications) {
        if (order.indexOf(classification) > order.indexOf(selected)) {
            selected = classification;
        }
    }
    return selected;
}
//# sourceMappingURL=data-classification.js.map