import { z } from 'zod';
export declare const ReceiveInboundMessageBaseSchema: z.ZodObject<{
    tenantId: z.ZodString;
    channel: z.ZodEnum<{
        whatsapp: "whatsapp";
        web: "web";
        internal: "internal";
    }>;
    externalMessageId: z.ZodString;
    senderRef: z.ZodString;
    body: z.ZodString;
    receivedAt: z.ZodCoercedDate<unknown>;
    conversationId: z.ZodOptional<z.ZodString>;
    sessionId: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export declare const ReceiveInboundMessageSchema: z.ZodObject<{
    tenantId: z.ZodString;
    channel: z.ZodEnum<{
        whatsapp: "whatsapp";
        web: "web";
        internal: "internal";
    }>;
    externalMessageId: z.ZodString;
    senderRef: z.ZodString;
    body: z.ZodString;
    receivedAt: z.ZodCoercedDate<unknown>;
    conversationId: z.ZodOptional<z.ZodString>;
    sessionId: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export declare const RunAgentTurnSchema: z.ZodObject<{
    sessionId: z.ZodString;
    triggerMessageId: z.ZodString;
    autonomyLevel: z.ZodEnum<{
        level_1_collect: "level_1_collect";
        level_2_suggest: "level_2_suggest";
    }>;
}, z.core.$strip>;
export declare const RequestHumanApprovalSchema: z.ZodObject<{
    sessionId: z.ZodString;
    proposedAction: z.ZodString;
    summary: z.ZodString;
    riskLevel: z.ZodEnum<{
        low: "low";
        medium: "medium";
        high: "high";
        critical: "critical";
    }>;
}, z.core.$strip>;
export declare const ResolveApprovalSchema: z.ZodObject<{
    approvalRequestId: z.ZodString;
    decision: z.ZodEnum<{
        approved: "approved";
        rejected: "rejected";
        assumed: "assumed";
    }>;
    operatorId: z.ZodString;
    note: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export declare const CreateInternalTaskSchema: z.ZodObject<{
    sessionId: z.ZodString;
    title: z.ZodString;
    description: z.ZodString;
    priority: z.ZodEnum<{
        low: "low";
        medium: "medium";
        high: "high";
        urgent: "urgent";
    }>;
    source: z.ZodString;
    idempotencyKey: z.ZodString;
}, z.core.$strip>;
