/**
 * Canonical JSON serialization (RFC 8785 subset) used for deterministic
 * payload hashing, approval binding and evidence digests.
 *
 * Rules:
 * - object keys sorted by UTF-16 code units;
 * - arrays keep order, `undefined` becomes `null`;
 * - `undefined` object members are omitted;
 * - numbers must be finite, `-0` serializes as `0`;
 * - only plain objects/null-prototype objects are accepted;
 * - depth and node budgets fail closed.
 */
export declare const CANONICAL_JSON_MAX_DEPTH = 64;
export declare const CANONICAL_JSON_MAX_NODES = 20000;
export declare class CanonicalJsonError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export declare function canonicalizeJson(value: unknown): string;
