export declare const ErrorCodes: {
    readonly duplicate_message: "duplicate_message";
    readonly invalid_channel: "invalid_channel";
    readonly invalid_pagination: "invalid_pagination";
    readonly empty_body: "empty_body";
    readonly session_not_found: "session_not_found";
    readonly policy_unavailable: "policy_unavailable";
    readonly workflow_failed: "workflow_failed";
    readonly tool_not_found: "tool_not_found";
    readonly validation_failed: "validation_failed";
    readonly action_requires_approval: "action_requires_approval";
    readonly invalid_action: "invalid_action";
    readonly conflict: "conflict";
    readonly unauthorized: "unauthorized";
    readonly missing_summary: "missing_summary";
    readonly approval_not_pending: "approval_not_pending";
    readonly operator_not_allowed: "operator_not_allowed";
    readonly invalid_priority: "invalid_priority";
    readonly missing_context: "missing_context";
    readonly insufficient_context: "insufficient_context";
    readonly forbidden: "forbidden";
    readonly rate_limited: "rate_limited";
    readonly secure_transport_required: "secure_transport_required";
    readonly unsupported_media_type: "unsupported_media_type";
    readonly payload_too_large: "payload_too_large";
    readonly not_found: "not_found";
    readonly request_uri_too_long: "request_uri_too_long";
    readonly configuration_error: "configuration_error";
};
export type ErrorCode = keyof typeof ErrorCodes;
export declare class DomainError extends Error {
    readonly code: ErrorCode;
    constructor(code: ErrorCode, message: string);
}
export declare function toSafeError(error: unknown): {
    code: string;
    message: string;
};
