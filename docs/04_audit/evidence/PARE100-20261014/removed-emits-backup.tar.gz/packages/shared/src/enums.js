import { z } from 'zod';
export const ChannelSchema = z.enum(['whatsapp', 'web', 'internal']);
export const ConversationStatusSchema = z.enum([
    'new',
    'active',
    'waiting_human',
    'waiting_approval',
    'resolved',
    'archived'
]);
export const SessionStatusSchema = z.enum([
    'open',
    'collecting_data',
    'triage',
    'scheduling',
    'handoff',
    'closed'
]);
export const IntentSchema = z.enum([
    'identify_owner_pet',
    'triage',
    'scheduling',
    'handoff',
    'task',
    'institutional_question',
    'unknown'
]);
export const RiskLevelSchema = z.enum(['low', 'medium', 'high', 'critical']);
export const AutonomyLevelSchema = z.enum([
    'level_1_collect',
    'level_2_suggest'
]);
export const ApprovalDecisionSchema = z.enum([
    'approved',
    'rejected',
    'assumed'
]);
export const ApprovalStatusSchema = z.enum([
    'pending',
    'approved',
    'rejected',
    'expired',
    'assumed'
]);
export const TaskPrioritySchema = z.enum(['low', 'medium', 'high', 'urgent']);
export const TaskStatusSchema = z.enum([
    'open',
    'in_progress',
    'done',
    'canceled'
]);
export const RoleSchema = z.enum([
    'Operator',
    'Approver',
    'Supervisor',
    'Admin',
    'System'
]);
export const ToolStatusSchema = z.enum([
    'pending',
    'succeeded',
    'failed',
    'blocked'
]);
export const PolicyDecisionSchema = z.enum([
    'allowed',
    'blocked',
    'requires_approval',
    'handoff'
]);
//# sourceMappingURL=enums.js.map