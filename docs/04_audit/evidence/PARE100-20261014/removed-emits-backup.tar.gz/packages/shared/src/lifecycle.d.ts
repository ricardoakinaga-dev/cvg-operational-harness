export type ShutdownSignal = 'SIGTERM' | 'SIGINT';
export interface SignalSource {
    once(event: string, listener: () => void): unknown;
}
export interface ShutdownEvent {
    type: 'shutdown.started' | 'shutdown.completed' | 'shutdown.failed' | 'shutdown.timeout' | 'shutdown.ignored';
    signal?: ShutdownSignal;
    code?: number;
    error?: string;
}
export interface ShutdownControllerOptions {
    close: () => Promise<void> | void;
    flush?: () => Promise<void> | void;
    exit: (code: number) => void;
    log?: (event: ShutdownEvent) => void;
    timeoutMs?: number;
    signals?: ShutdownSignal[];
}
export interface ShutdownController {
    shutdown(signal?: ShutdownSignal, code?: number): Promise<void>;
    install(source: SignalSource): void;
    isShuttingDown(): boolean;
}
/**
 * Graceful shutdown: stop accepting work (caller closes the server/pool),
 * flush telemetry, then exit. Repeated signals are ignored; a hung close is
 * bounded by a timeout that still exits non-zero.
 */
export declare function createShutdownController(options: ShutdownControllerOptions): ShutdownController;
