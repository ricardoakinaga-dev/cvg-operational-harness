export function ok(data, correlationId) {
    return { success: true, data, error: null, meta: { correlationId } };
}
export function fail(code, message, correlationId) {
    return {
        success: false,
        data: null,
        error: { code, message },
        meta: { correlationId }
    };
}
//# sourceMappingURL=envelope.js.map