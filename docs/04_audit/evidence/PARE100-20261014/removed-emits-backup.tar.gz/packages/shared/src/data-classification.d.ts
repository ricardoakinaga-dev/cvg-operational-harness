import { z } from 'zod';
/**
 * Data classification and handling policy.
 *
 * Technical support for LGPD-aligned governance: purpose limitation,
 * minimization, retention and transmission rules per class. This is not a
 * legal compliance claim.
 */
export declare const DataClassificationSchema: z.ZodEnum<{
    PUBLIC: "PUBLIC";
    INTERNAL: "INTERNAL";
    CONFIDENTIAL: "CONFIDENTIAL";
    CLINICAL: "CLINICAL";
    FINANCIAL: "FINANCIAL";
    CREDENTIAL: "CREDENTIAL";
}>;
export type DataClassification = z.infer<typeof DataClassificationSchema>;
export declare const LlmTransmissionSchema: z.ZodEnum<{
    EXTERNAL_MODEL_ALLOWED: "EXTERNAL_MODEL_ALLOWED";
    LOCAL_ONLY: "LOCAL_ONLY";
    NO_MODEL: "NO_MODEL";
}>;
export type LlmTransmission = z.infer<typeof LlmTransmissionSchema>;
export declare const HandlingActionSchema: z.ZodEnum<{
    allow: "allow";
    redact: "redact";
    require_approval: "require_approval";
    forbid: "forbid";
}>;
export type HandlingAction = z.infer<typeof HandlingActionSchema>;
export interface DataHandlingRule {
    classification: DataClassification;
    logging: HandlingAction;
    telemetry: HandlingAction;
    rag: HandlingAction;
    export: HandlingAction;
    backup: HandlingAction;
    llmTransmission: LlmTransmission;
    retentionDays: number;
    requiresAccessAudit: boolean;
}
export declare const DATA_HANDLING_POLICY: Readonly<Record<DataClassification, DataHandlingRule>>;
export declare function handlingRuleFor(classification: DataClassification): DataHandlingRule;
export declare function mayTransmitToExternalModel(classification: DataClassification): boolean;
export declare function mayTransmitToLocalModel(classification: DataClassification): boolean;
export declare function mayTransmitToModel(classification: DataClassification, modelLocation: 'external' | 'local'): boolean;
export declare function requiresRedaction(classification: DataClassification): boolean;
export declare function retentionDaysFor(classification: DataClassification): number;
/**
 * Highest-risk class in a set; used to select the strictest handling rule when
 * data of multiple classes flows through one operation.
 */
export declare function strictestClassification(classifications: readonly DataClassification[]): DataClassification;
