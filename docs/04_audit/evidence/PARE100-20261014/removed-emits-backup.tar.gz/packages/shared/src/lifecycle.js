/**
 * Graceful shutdown: stop accepting work (caller closes the server/pool),
 * flush telemetry, then exit. Repeated signals are ignored; a hung close is
 * bounded by a timeout that still exits non-zero.
 */
export function createShutdownController(options) {
    const timeoutMs = options.timeoutMs ?? 15_000;
    const signals = options.signals ?? ['SIGTERM', 'SIGINT'];
    let shuttingDown = false;
    const emit = (event) => {
        options.log?.(event);
    };
    const shutdown = async (signal = 'SIGTERM', code = 0) => {
        if (shuttingDown) {
            emit({ type: 'shutdown.ignored', signal });
            return;
        }
        shuttingDown = true;
        emit({ type: 'shutdown.started', signal });
        let settled = false;
        const timer = setTimeout(() => {
            if (settled)
                return;
            settled = true;
            emit({ type: 'shutdown.timeout', signal });
            options.exit(1);
        }, timeoutMs);
        timer.unref?.();
        try {
            await options.close();
            await options.flush?.();
            if (settled)
                return;
            settled = true;
            clearTimeout(timer);
            emit({ type: 'shutdown.completed', signal, code });
            options.exit(code);
        }
        catch (error) {
            if (settled)
                return;
            settled = true;
            clearTimeout(timer);
            emit({
                type: 'shutdown.failed',
                signal,
                error: error instanceof Error ? error.message : 'unknown_error'
            });
            options.exit(1);
        }
    };
    const install = (source) => {
        for (const signal of signals) {
            source.once(signal, () => {
                void shutdown(signal);
            });
        }
    };
    return {
        shutdown,
        install,
        isShuttingDown: () => shuttingDown
    };
}
//# sourceMappingURL=lifecycle.js.map