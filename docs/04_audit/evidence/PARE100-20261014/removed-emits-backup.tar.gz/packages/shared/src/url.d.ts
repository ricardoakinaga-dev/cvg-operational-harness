/**
 * Drops trailing `/` from a configured base URL in one linear pass; a regex
 * such as `/\/+$/` backtracks quadratically on long runs of slashes (CodeQL
 * js/polynomial-redos, AUD-0599).
 */
export declare function withoutTrailingSlashes(value: string): string;
