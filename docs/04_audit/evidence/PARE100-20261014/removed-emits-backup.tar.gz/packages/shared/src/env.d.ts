import { z } from 'zod';
export declare const TRUSTED_PROXY_HOPS_MIGRATION_ERROR = "API_TRUSTED_PROXY_HOPS is deprecated; configure API_TRUSTED_PROXY_ADDRESSES with explicit IP addresses";
export declare const EnvSchema: z.ZodObject<{
    NODE_ENV: z.ZodEnum<{
        development: "development";
        test: "test";
        production: "production";
    }>;
    API_PERSISTENCE_MODE: z.ZodDefault<z.ZodEnum<{
        memory: "memory";
        postgres: "postgres";
    }>>;
    CVG_IDENTITY_MODE: z.ZodPipe<z.ZodTransform<unknown, unknown>, z.ZodOptional<z.ZodEnum<{
        simulation: "simulation";
        trusted: "trusted";
    }>>>;
    CVG_OPERATOR_IDENTITY_KEYRING: z.ZodOptional<z.ZodString>;
    CVG_RATE_LIMIT_KEYRING: z.ZodOptional<z.ZodString>;
    DATABASE_URL: z.ZodOptional<z.ZodString>;
    DATABASE_MIGRATION_URL: z.ZodOptional<z.ZodString>;
    INBOUND_TENANT_ID: z.ZodOptional<z.ZodString>;
    INBOUND_AGENT_ID: z.ZodOptional<z.ZodString>;
    WEBHOOK_SIGNING_SECRET: z.ZodOptional<z.ZodString>;
    API_ALLOWED_ORIGINS: z.ZodOptional<z.ZodString>;
    API_REQUIRE_HTTPS: z.ZodPipe<z.ZodDefault<z.ZodUnion<readonly [z.ZodBoolean, z.ZodEnum<{
        true: "true";
        false: "false";
    }>]>>, z.ZodTransform<boolean, boolean | "true" | "false">>;
    API_TRUSTED_PROXY_ADDRESSES: z.ZodOptional<z.ZodString>;
    API_TRUSTED_PROXY_HOPS: z.ZodPipe<z.ZodTransform<number, unknown>, z.ZodLiteral<0>>;
    POSTGRES_AUTO_MIGRATE: z.ZodPipe<z.ZodDefault<z.ZodUnion<readonly [z.ZodBoolean, z.ZodEnum<{
        true: "true";
        false: "false";
    }>]>>, z.ZodTransform<boolean, boolean | "true" | "false">>;
    POSTGRES_RLS_ENFORCEMENT: z.ZodPipe<z.ZodDefault<z.ZodUnion<readonly [z.ZodBoolean, z.ZodEnum<{
        true: "true";
        false: "false";
    }>]>>, z.ZodTransform<boolean, boolean | "true" | "false">>;
    POSTGRES_SCHEMA: z.ZodPipe<z.ZodTransform<unknown, unknown>, z.ZodOptional<z.ZodString>>;
    OUTBOX_DURABLE_INBOUND: z.ZodPipe<z.ZodDefault<z.ZodUnion<readonly [z.ZodBoolean, z.ZodEnum<{
        true: "true";
        false: "false";
    }>]>>, z.ZodTransform<boolean, boolean | "true" | "false">>;
    PORT: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    CVG_API_PORT: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    OPENAI_API_KEY: z.ZodOptional<z.ZodString>;
    ENABLE_REAL_CHANNELS: z.ZodPipe<z.ZodDefault<z.ZodUnion<readonly [z.ZodBoolean, z.ZodEnum<{
        true: "true";
        false: "false";
    }>]>>, z.ZodTransform<boolean, boolean | "true" | "false">>;
    ENABLE_REAL_RAG: z.ZodPipe<z.ZodDefault<z.ZodUnion<readonly [z.ZodBoolean, z.ZodEnum<{
        true: "true";
        false: "false";
    }>]>>, z.ZodTransform<boolean, boolean | "true" | "false">>;
    ENABLE_REAL_PAYMENTS: z.ZodPipe<z.ZodDefault<z.ZodUnion<readonly [z.ZodBoolean, z.ZodEnum<{
        true: "true";
        false: "false";
    }>]>>, z.ZodTransform<boolean, boolean | "true" | "false">>;
    ENABLE_REAL_MEDICAL_RECORDS: z.ZodPipe<z.ZodDefault<z.ZodUnion<readonly [z.ZodBoolean, z.ZodEnum<{
        true: "true";
        false: "false";
    }>]>>, z.ZodTransform<boolean, boolean | "true" | "false">>;
}, z.core.$strip>;
export type AppEnv = z.infer<typeof EnvSchema>;
export declare function parseEnv(input: NodeJS.ProcessEnv): AppEnv;
export declare function realWorldActionsDisabled(env: AppEnv): boolean;
