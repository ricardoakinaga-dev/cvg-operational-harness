import { z } from 'zod';
const permissionsByRole = {
    Operator: [
        'approval:view',
        'approval:execute',
        'audit:view_limited',
        'conversation:view_assigned',
        'conversation:update',
        'conversation:assume',
        'task:view',
        'task:update'
    ],
    Approver: [
        'approval:view',
        'approval:decide',
        'audit:view_limited',
        'conversation:view_assigned',
        'conversation:update',
        'task:view'
    ],
    Supervisor: [
        'approval:view',
        'approval:decide',
        'audit:view_full',
        'conversation:view_assigned',
        'conversation:update',
        'conversation:assume',
        'safety:review',
        'task:view'
    ],
    Admin: [
        'approval:view',
        'audit:view_full',
        'channel:configure',
        'conversation:view_assigned',
        'conversation:update',
        'conversation:assume',
        'agent:view',
        'agent:configure',
        'plugin:configure',
        'policy:configure',
        'test:run',
        'task:view'
    ],
    System: ['tool:execute_policy_allowed', 'audit:create']
};
export function roleHasPermission(role, permission) {
    return permissionsByRole[role].includes(permission);
}
export function requirePermission(role, permission) {
    if (!roleHasPermission(role, permission)) {
        throw new Error(`Role ${role} cannot perform ${permission}`);
    }
}
export const OperatorRoleSchema = z.enum([
    'Operator',
    'Approver',
    'Supervisor',
    'Admin'
]);
export const OperatorIdentitySchema = z.object({
    operatorId: z
        .string()
        .trim()
        .min(3)
        .max(80)
        .regex(/^[A-Za-z0-9._:-]+$/),
    role: OperatorRoleSchema,
    tenantId: z
        .string()
        .trim()
        .regex(/^tenant_[0-9a-f-]{36}$/)
        .optional()
});
function readHeaderValue(value) {
    if (Array.isArray(value))
        return value[0];
    return value;
}
export function parseOperatorIdentity(headers) {
    const tenantId = readHeaderValue(headers['x-tenant-id']);
    return OperatorIdentitySchema.parse({
        operatorId: readHeaderValue(headers['x-operator-id']),
        role: readHeaderValue(headers['x-operator-role']),
        ...(tenantId === undefined ? {} : { tenantId })
    });
}
export const IdentityModeSchema = z.enum(['simulation', 'trusted']);
export const IDENTITY_MODE_ENV = 'CVG_IDENTITY_MODE';
/**
 * Explicit identity mode. `simulation` is the controlled header-based flow and
 * is only a default for `NODE_ENV=test`; every other environment fails closed
 * to `trusted` unless an operator opts in explicitly.
 */
export function parseIdentityMode(raw, nodeEnv) {
    const value = typeof raw === 'string' ? raw.trim() : '';
    if (value === '')
        return nodeEnv === 'test' ? 'simulation' : 'trusted';
    const parsed = IdentityModeSchema.safeParse(value);
    if (!parsed.success) {
        throw new Error('CVG_IDENTITY_MODE must be simulation or trusted');
    }
    return parsed.data;
}
//# sourceMappingURL=auth.js.map