import { z } from 'zod';
export declare const WebhookMessagePayloadSchema: z.ZodObject<{
    tenantId: z.ZodString;
    body: z.ZodString;
    externalMessageId: z.ZodString;
    senderRef: z.ZodString;
    receivedAt: z.ZodCoercedDate<unknown>;
    conversationId: z.ZodOptional<z.ZodString>;
    sessionId: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export declare const ApprovalDecisionPayloadSchema: z.ZodObject<{
    operatorId: z.ZodString;
    decision: z.ZodEnum<{
        approved: "approved";
        rejected: "rejected";
        assumed: "assumed";
    }>;
    note: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export declare const CreateTaskPayloadSchema: z.ZodObject<{
    sessionId: z.ZodString;
    title: z.ZodString;
    description: z.ZodString;
    priority: z.ZodEnum<{
        low: "low";
        medium: "medium";
        high: "high";
        urgent: "urgent";
    }>;
    source: z.ZodString;
    idempotencyKey: z.ZodString;
}, z.core.$strip>;
export declare const ListConversationsQuerySchema: z.ZodObject<{
    status: z.ZodOptional<z.ZodString>;
    channel: z.ZodOptional<z.ZodString>;
    contactId: z.ZodOptional<z.ZodString>;
    updatedAfter: z.ZodOptional<z.ZodCoercedDate<unknown>>;
}, z.core.$strip>;
