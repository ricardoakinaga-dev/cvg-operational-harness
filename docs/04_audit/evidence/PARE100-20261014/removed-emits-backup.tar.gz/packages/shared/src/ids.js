import { z } from 'zod';
const idPattern = /^[a-z]+_[0-9a-f-]{36}$/;
function createUuid() {
    const cryptoApi = globalThis.crypto;
    if (typeof cryptoApi?.randomUUID === 'function') {
        return cryptoApi.randomUUID();
    }
    if (typeof cryptoApi?.getRandomValues === 'function') {
        const bytes = cryptoApi.getRandomValues(new Uint8Array(16));
        bytes[6] = ((bytes[6] ?? 0) & 0x0f) | 0x40;
        bytes[8] = ((bytes[8] ?? 0) & 0x3f) | 0x80;
        const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('');
        return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
    }
    throw new Error('Secure UUID generation is unavailable');
}
export const DomainIdSchema = z.string().regex(idPattern);
export function createDomainId(prefix) {
    return `${prefix}_${createUuid()}`;
}
export const CorrelationIdSchema = z.string().regex(/^corr_[0-9a-f-]{36}$/);
export function createCorrelationId() {
    return `corr_${createUuid()}`;
}
export const IdempotencyKeySchema = z.string().min(8).max(200);
//# sourceMappingURL=ids.js.map