import type { AgenticKnowledgeProvider, ApprovalEngine, ExecutionStepStore, LoopDecision, SufficiencyEvaluator, ToolExecutionContext, ToolRegistry } from '@cvg/harness-contracts';
import type { OperationalHarnessOptions } from '@cvg/harness';
export declare const PHASE3_SCENARIOS: readonly ["operational", "knowledge", "waiting_user", "approval"];
export type Phase3Scenario = (typeof PHASE3_SCENARIOS)[number];
export declare const PHASE3_TOOL_AVAILABILITY = "synthetic.phase3.availability";
export declare const PHASE3_TOOL_RESERVE = "synthetic.phase3.reserve";
export interface Phase3Observer {
    (context: ToolExecutionContext): void;
}
/**
 * Controlled Phase 3 fixture. It is rejected in production by the worker
 * factory before this module is used; every executor is deterministic and
 * performs no network, channel or product side effect.
 */
export declare function createPhase3ToolRegistry(observer?: Phase3Observer): ToolRegistry;
export declare function createPhase3KnowledgeProvider(): AgenticKnowledgeProvider;
export declare function createPhase3SufficiencyEvaluator(): SufficiencyEvaluator;
export declare function createPhase3ClaimExtractor(): (response: string) => readonly {
    text: string;
    evidenceRefs: readonly string[];
}[];
export declare function phase3ScenarioScript(scenario: Phase3Scenario, resumeKind: 'approval' | 'user_input' | undefined): readonly LoopDecision[];
export interface Phase3HarnessOptionsInput {
    readonly scenario: Phase3Scenario;
    readonly stepStore: ExecutionStepStore;
    readonly approvals: ApprovalEngine;
    readonly resumeKind?: 'approval' | 'user_input';
    readonly observer?: Phase3Observer;
}
/** Builds the controlled iterative harness options for a scenario attempt. */
export declare function createPhase3IterativeHarnessOptions(input: Phase3HarnessOptionsInput): OperationalHarnessOptions;
export declare function parsePhase3RuntimeProfile(value: string | undefined): 'single_pass' | 'iterative';
export declare function parsePhase3Scenario(value: string | undefined): Phase3Scenario | undefined;
