import { type TenantId } from '@cvg/platform';
import { type PostgresPoolLike } from '@cvg/persistence';
/**
 * Tables the PostgreSQL worker reads or writes during a controlled drain. Each
 * one must exist in the runtime schema with RLS + FORCE RLS enabled, and the
 * runtime role must not own them.
 */
export declare const WORKER_CRITICAL_TABLES: readonly ["conversations", "messages", "sessions", "agent_runs", "tool_calls", "approval_requests", "tasks", "audit_events", "outbox_events", "outbox_attempts", "outbox_effects"];
export declare const OPERATIONAL_HARNESS_CRITICAL_TABLES: readonly ["runtime_approvals", "operational_executions", "operational_execution_outbox", "operational_execution_events", "operational_effect_journal", "operational_execution_steps", "operational_execution_checkpoints"];
export declare const OPERATIONAL_HARNESS_REQUIRED_MIGRATIONS: readonly ["0015_runtime_approval_store", "0016_operational_execution_spine", "0017_runtime_approval_execution_binding", "0018_operational_execution_invariants", "0019_iterative_execution_steps", "0024_approval_decision_causality"];
export interface PostgresWorkerPreflightOptions {
    tenantId: TenantId;
    criticalTables?: readonly string[];
    requiredMigrations?: readonly string[];
}
/**
 * Verifies the effective PostgreSQL role and tenant-isolation schema before the
 * worker claims its first event. Environment flags never replace this query.
 *
 * The preflight borrows one pool connection, sets the tenant context, runs the
 * checks and clears the context before releasing the connection; a connection
 * whose context cannot be cleared is destroyed instead of being reused.
 */
export declare function assertPostgresWorkerPreflight(pool: PostgresPoolLike, options: PostgresWorkerPreflightOptions): Promise<void>;
