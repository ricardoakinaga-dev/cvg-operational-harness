import { type DurableOutboxAdapter, type OutboxEffect } from '@cvg/persistence';
import type { TenantId } from '@cvg/platform';
import { CONTROLLED_OUTBOX_EVENT_TYPES, type ProcessOutboxEventResult } from './jobs/process-outbox-event.ts';
export { CONTROLLED_OUTBOX_EVENT_TYPES };
export type ControlledOutboxEventType = (typeof CONTROLLED_OUTBOX_EVENT_TYPES)[number];
/**
 * The composition boundary is deliberately closed over known event types.
 * Callers cannot inject an arbitrary string-to-handler registry into the
 * worker process; the inbound and outbound seams are explicit and auditable.
 */
export interface ControlledWorkerHandlers {
    inboundProcess: OutboxEffect;
    messageOutbound: OutboxEffect;
}
export interface ControlledWorkerOptions {
    tenantId: TenantId;
    workerId: string;
    adapter: DurableOutboxAdapter;
    handlers: ControlledWorkerHandlers;
    leaseMs?: number;
    takeoverActive?: boolean | (() => boolean | Promise<boolean>);
}
export interface ControlledWorkerDrainResult {
    processed: number;
    results: ProcessOutboxEventResult[];
}
export interface ControlledWorker {
    processNext(eventId?: string): Promise<ProcessOutboxEventResult>;
    drain(maxEvents?: number): Promise<ControlledWorkerDrainResult>;
}
export declare function createControlledWorker(options: ControlledWorkerOptions): ControlledWorker;
export declare function createControlledDispatch(handlers: ControlledWorkerHandlers): OutboxEffect;
