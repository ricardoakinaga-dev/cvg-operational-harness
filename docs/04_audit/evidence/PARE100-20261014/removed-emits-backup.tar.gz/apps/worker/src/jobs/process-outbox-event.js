"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CONTROLLED_OUTBOX_EVENT_TYPES = void 0;
exports.processOutboxEvent = processOutboxEvent;
exports.completeClaimedOutboxEvent = completeClaimedOutboxEvent;
const persistence_1 = require("@cvg/persistence");
exports.CONTROLLED_OUTBOX_EVENT_TYPES = [
    'inbound.process',
    'message.outbound'
];
/**
 * Claims one event and delegates the only execution of its local effect to
 * the adapter's at-least-once `ack` protocol. The PostgreSQL adapter commits
 * ownership before invoking a handler and commits the sanitized journal/state
 * transition afterward; controlled handlers must therefore be idempotent.
 * A handler is never invoked in the job itself.
 */
async function processOutboxEvent(input) {
    const event = await input.adapter.claimNext({
        tenantId: input.tenantId,
        workerId: input.workerId,
        ...(input.eventId ? { eventId: input.eventId } : {}),
        ...(input.leaseMs ? { leaseMs: input.leaseMs } : {})
    });
    if (!event)
        return null;
    return completeClaimedOutboxEvent({ ...input, event });
}
/**
 * Executes the controlled dispatch and durable acknowledgement for an event
 * that was already claimed (and whose lease belongs to `workerId`). The
 * continuous worker uses this seam to heartbeat the lease while the handler
 * runs without claiming the same event twice.
 */
async function completeClaimedOutboxEvent(input) {
    const event = input.event;
    if (await isTakeoverActive(input.takeoverActive)) {
        await input.adapter.fail({
            tenantId: input.tenantId,
            eventId: event.id,
            workerId: input.workerId,
            terminal: true,
            handoff: true,
            error: persistence_1.OUTBOX_TAKEOVER_SUPPRESSED_ERROR
        });
        return {
            eventId: event.id,
            tenantId: input.tenantId,
            status: 'handoff',
            handoff: true
        };
    }
    if (!isControlledOutboxEventType(event.type) || !input.effect) {
        return input.adapter.fail({
            tenantId: input.tenantId,
            eventId: event.id,
            workerId: input.workerId,
            terminal: true,
            error: `unknown controlled outbox handler: ${event.type}`
        });
    }
    try {
        const acked = await input.adapter.ack({
            tenantId: input.tenantId,
            eventId: event.id,
            workerId: input.workerId,
            effect: input.effect,
            ...(input.takeoverActive !== undefined
                ? { takeoverActive: input.takeoverActive }
                : {}),
            ...(input.result !== undefined ? { result: input.result } : {})
        });
        if (acked.status === 'dead_letter' &&
            acked.lastError === persistence_1.OUTBOX_TAKEOVER_SUPPRESSED_ERROR) {
            return {
                eventId: acked.id,
                tenantId: input.tenantId,
                status: 'handoff',
                handoff: true
            };
        }
        return acked;
    }
    catch (error) {
        // The adapter owns the durable ack boundary. If the handler or final
        // journal transition fails, the same lease is sent through the
        // repository's retry policy.
        try {
            return await input.adapter.fail({
                tenantId: input.tenantId,
                eventId: event.id,
                workerId: input.workerId,
                error
            });
        }
        catch {
            throw error;
        }
    }
}
async function isTakeoverActive(value) {
    if (typeof value === 'function')
        return Boolean(await value());
    return value === true;
}
function isControlledOutboxEventType(value) {
    return exports.CONTROLLED_OUTBOX_EVENT_TYPES.includes(value);
}
//# sourceMappingURL=process-outbox-event.js.map