import { type Telemetry } from '@cvg/observability';
export type WorkerLogLevel = 'debug' | 'info' | 'warn' | 'error';
export interface WorkerTelemetry {
    log(event: string, fields?: Record<string, unknown>, level?: WorkerLogLevel): void;
    metric(name: string, value: number, attributes?: Record<string, string | number | boolean>): void;
}
export interface JsonWorkerTelemetryOptions {
    clock?: () => Date;
    write?: (line: string) => void;
}
/**
 * Structured JSON sink for the worker process. Log fields and metric
 * attributes pass through the centralized redaction before serialization;
 * payloads, bodies and identities are never recorded by convention, and the
 * redaction layer is the second line of defense.
 */
export declare function createJsonWorkerTelemetry(options?: JsonWorkerTelemetryOptions): WorkerTelemetry;
/**
 * Adapter for `@cvg/observability` telemetry. Metric attribute names are
 * restricted by the caller to the allowlist shared with the runtime
 * (`status`, `outcome`, `operation`) to avoid high-cardinality sinks.
 */
export declare function createTelemetryWorkerSink(telemetry: Pick<Telemetry, 'log' | 'recordMetric'>): WorkerTelemetry;
