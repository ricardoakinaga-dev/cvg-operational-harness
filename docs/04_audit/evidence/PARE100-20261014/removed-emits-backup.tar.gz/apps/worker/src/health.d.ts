/**
 * Worker health.
 *
 * `workerHealth` stays a static liveness answer (the process responds).
 * AUD19-009 adds `checkHomologHealth`: real dependency checks for the
 * homologation composition (database round-trip plus queue depth), each
 * with its own timeout. Callers keep health observation independent from work
 * and may pause claims while an unhealthy report is active; recovery is
 * observed on the next health tick.
 */
import { type PostgresPoolLike } from '@cvg/persistence';
import type { TenantId } from '@cvg/platform';
export declare function workerHealth(): {
    status: "ok";
};
export interface HomologHealthCheck {
    name: string;
    status: 'ok' | 'failed';
    detail: string;
    latencyMs: number;
}
export interface HomologHealthReport {
    healthy: boolean;
    checks: HomologHealthCheck[];
}
export declare function checkHomologHealth(pool: PostgresPoolLike, tenantId: TenantId, timeoutMs?: number): Promise<HomologHealthReport>;
