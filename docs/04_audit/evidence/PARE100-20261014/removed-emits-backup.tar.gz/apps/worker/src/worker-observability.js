"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createJsonWorkerTelemetry = createJsonWorkerTelemetry;
exports.createTelemetryWorkerSink = createTelemetryWorkerSink;
const observability_1 = require("@cvg/observability");
/**
 * Structured JSON sink for the worker process. Log fields and metric
 * attributes pass through the centralized redaction before serialization;
 * payloads, bodies and identities are never recorded by convention, and the
 * redaction layer is the second line of defense.
 */
function createJsonWorkerTelemetry(options = {}) {
    const clock = options.clock ?? (() => new Date());
    const write = options.write ?? ((line) => process.stdout.write(`${line}\n`));
    return {
        log(event, fields = {}, level = 'info') {
            write(JSON.stringify({
                event,
                level,
                timestamp: clock().toISOString(),
                ...(0, observability_1.redactFields)(fields)
            }));
        },
        metric(name, value, attributes = {}) {
            write(JSON.stringify({
                event: 'worker.metric',
                name,
                value,
                attributes: (0, observability_1.redactFields)(attributes),
                timestamp: clock().toISOString()
            }));
        }
    };
}
/**
 * Adapter for `@cvg/observability` telemetry. Metric attribute names are
 * restricted by the caller to the allowlist shared with the runtime
 * (`status`, `outcome`, `operation`) to avoid high-cardinality sinks.
 */
function createTelemetryWorkerSink(telemetry) {
    return {
        log(event, fields = {}, level = 'info') {
            telemetry.log(level, event, fields);
        },
        metric(name, value, attributes = {}) {
            telemetry.recordMetric(name, value, attributes);
        }
    };
}
//# sourceMappingURL=worker-observability.js.map