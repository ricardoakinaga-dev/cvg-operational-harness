"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createWorkerReadiness = createWorkerReadiness;
/**
 * Small fail-closed lifecycle boundary for consumers. A transition is
 * published before it is committed so an exporter/sink failure cannot leave
 * the process internally ready while the readiness signal was lost.
 */
function createWorkerReadiness(options = {}) {
    const clock = options.clock ?? (() => new Date());
    let current = 'not_ready';
    const transitionTo = (next, reason) => {
        if (current === 'stopped' || current === next)
            return false;
        const transition = {
            from: current,
            to: next,
            reason,
            at: clock().toISOString()
        };
        options.onTransition?.(transition);
        current = next;
        return true;
    };
    return {
        status: () => current,
        isReady: () => current === 'ready',
        markReady: (reason) => {
            if (current !== 'not_ready')
                return false;
            return transitionTo('ready', reason);
        },
        markNotReady: (reason) => {
            if (current !== 'ready')
                return false;
            return transitionTo('not_ready', reason);
        },
        markStopped: (reason) => transitionTo('stopped', reason)
    };
}
//# sourceMappingURL=readiness.js.map