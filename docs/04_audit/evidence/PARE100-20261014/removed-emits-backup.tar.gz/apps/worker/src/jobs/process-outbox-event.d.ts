import { type DurableOutboxAdapter, type OutboxEffect, type OutboxEventRecord, type OutboxTakeoverCheck } from '@cvg/persistence';
import type { TenantId } from '@cvg/platform';
export declare const CONTROLLED_OUTBOX_EVENT_TYPES: readonly ["inbound.process", "message.outbound"];
export interface ProcessOutboxEventInput {
    tenantId: TenantId;
    workerId: string;
    adapter: DurableOutboxAdapter;
    eventId?: string;
    leaseMs?: number;
    effect?: OutboxEffect;
    /** The adapter rechecks this inside its ack boundary before any effect. */
    takeoverActive?: OutboxTakeoverCheck;
    /** Used only when an effect intentionally returns no value. */
    result?: unknown;
}
export interface OutboxHandoffResult {
    eventId: string;
    tenantId: TenantId;
    status: 'handoff';
    handoff: true;
}
export type ProcessOutboxEventResult = OutboxEventRecord | OutboxHandoffResult | null;
export type ClaimedOutboxEventResult = Exclude<ProcessOutboxEventResult, null>;
export interface CompleteClaimedOutboxEventInput {
    tenantId: TenantId;
    workerId: string;
    adapter: DurableOutboxAdapter;
    event: OutboxEventRecord;
    effect?: OutboxEffect;
    /** The adapter rechecks this inside its ack boundary before any effect. */
    takeoverActive?: OutboxTakeoverCheck;
    /** Used only when an effect intentionally returns no value. */
    result?: unknown;
}
/**
 * Claims one event and delegates the only execution of its local effect to
 * the adapter's at-least-once `ack` protocol. The PostgreSQL adapter commits
 * ownership before invoking a handler and commits the sanitized journal/state
 * transition afterward; controlled handlers must therefore be idempotent.
 * A handler is never invoked in the job itself.
 */
export declare function processOutboxEvent(input: ProcessOutboxEventInput): Promise<ProcessOutboxEventResult>;
/**
 * Executes the controlled dispatch and durable acknowledgement for an event
 * that was already claimed (and whose lease belongs to `workerId`). The
 * continuous worker uses this seam to heartbeat the lease while the handler
 * runs without claiming the same event twice.
 */
export declare function completeClaimedOutboxEvent(input: CompleteClaimedOutboxEventInput): Promise<ClaimedOutboxEventResult>;
