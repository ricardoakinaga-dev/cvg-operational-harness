"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OPERATIONAL_SYNTHETIC_EFFECT_ENV = exports.OPERATIONAL_FAULT_POINT_AFTER_CLAIM = exports.OPERATIONAL_HARNESS_WORKER_RUNTIME = void 0;
exports.parseOperationalFaultPoint = parseOperationalFaultPoint;
exports.parseOperationalSyntheticEffect = parseOperationalSyntheticEffect;
exports.parseOperationalWorkerIdleWait = parseOperationalWorkerIdleWait;
exports.parseOperationalWorkerPollInterval = parseOperationalWorkerPollInterval;
exports.createOperationalHarnessFaultInjector = createOperationalHarnessFaultInjector;
exports.parseOperationalWorkerConcurrency = parseOperationalWorkerConcurrency;
exports.createOperationalHarnessWorker = createOperationalHarnessWorker;
exports.assertOperationalHarnessPostgresPreflight = assertOperationalHarnessPostgresPreflight;
exports.assertOperationalHarnessProfilePreflight = assertOperationalHarnessProfilePreflight;
const pg_1 = require("pg");
const harness_1 = require("@cvg/harness");
const harness_orchestrator_1 = require("@cvg/harness-orchestrator");
const phase3_synthetic_agent_ts_1 = require("./phase3-synthetic-agent.js");
const persistence_1 = require("@cvg/persistence");
const platform_1 = require("@cvg/platform");
const postgres_role_preflight_ts_1 = require("./postgres-role-preflight.js");
const phase2_synthetic_effect_ts_1 = require("./phase2-synthetic-effect.js");
exports.OPERATIONAL_HARNESS_WORKER_RUNTIME = 'operational-harness';
exports.OPERATIONAL_FAULT_POINT_AFTER_CLAIM = harness_1.OPERATIONAL_EXECUTION_FAULT_POINT_AFTER_CLAIM;
exports.OPERATIONAL_SYNTHETIC_EFFECT_ENV = 'CVG_WORKER_SYNTHETIC_EFFECT';
const MAX_OPERATIONAL_WORKER_CONCURRENCY = 32;
const MAX_OPERATIONAL_WORKER_IDLE_WAIT_MS = 60_000;
const MAX_OPERATIONAL_WORKER_POLL_INTERVAL_MS = 1_000;
function parseOperationalFaultPoint(raw, env = process.env) {
    const value = raw?.trim();
    if (!value)
        return undefined;
    if (env.NODE_ENV === 'production') {
        throw new Error('PHASE2_FAULT_POINT is forbidden in production');
    }
    if (env.CVG_WORKER_CONTROLLED_MODE !== 'true') {
        throw new Error('PHASE2_FAULT_POINT requires CVG_WORKER_CONTROLLED_MODE=true');
    }
    if (value !== exports.OPERATIONAL_FAULT_POINT_AFTER_CLAIM) {
        throw new Error(`PHASE2_FAULT_POINT must be ${exports.OPERATIONAL_FAULT_POINT_AFTER_CLAIM}`);
    }
    return exports.OPERATIONAL_FAULT_POINT_AFTER_CLAIM;
}
function parseOperationalSyntheticEffect(raw, env = process.env) {
    const value = raw?.trim();
    if (!value || value === 'false')
        return false;
    if (value !== 'true') {
        throw new Error(`${exports.OPERATIONAL_SYNTHETIC_EFFECT_ENV} must be either true or false`);
    }
    if (env.NODE_ENV === 'production') {
        throw new Error(`${exports.OPERATIONAL_SYNTHETIC_EFFECT_ENV} is forbidden in production`);
    }
    if (env.CVG_WORKER_CONTROLLED_MODE !== 'true') {
        throw new Error(`${exports.OPERATIONAL_SYNTHETIC_EFFECT_ENV} requires CVG_WORKER_CONTROLLED_MODE=true`);
    }
    return true;
}
function parseOperationalWorkerIdleWait(raw, fallback = 0) {
    const value = raw?.trim() ? Number(raw) : fallback;
    if (!Number.isSafeInteger(value) ||
        value < 0 ||
        value > MAX_OPERATIONAL_WORKER_IDLE_WAIT_MS) {
        throw new Error(`CVG_WORKER_IDLE_WAIT_MS must be an integer between 0 and ${MAX_OPERATIONAL_WORKER_IDLE_WAIT_MS}`);
    }
    return value;
}
function parseOperationalWorkerPollInterval(raw, fallback = 25) {
    const value = raw?.trim() ? Number(raw) : fallback;
    if (!Number.isSafeInteger(value) ||
        value < 1 ||
        value > MAX_OPERATIONAL_WORKER_POLL_INTERVAL_MS) {
        throw new Error(`CVG_WORKER_POLL_INTERVAL_MS must be an integer between 1 and ${MAX_OPERATIONAL_WORKER_POLL_INTERVAL_MS}`);
    }
    return value;
}
function createOperationalHarnessFaultInjector(env, terminate = (signal) => {
    process.kill(process.pid, signal);
}) {
    const point = parseOperationalFaultPoint(env.PHASE2_FAULT_POINT, env);
    if (!point)
        return undefined;
    let triggered = false;
    return async (receivedPoint) => {
        if (triggered || receivedPoint !== point)
            return;
        triggered = true;
        terminate('SIGKILL');
    };
}
function parseOperationalWorkerConcurrency(raw, fallback = 1) {
    const value = raw?.trim() ? Number(raw) : fallback;
    if (!Number.isSafeInteger(value) ||
        value < 1 ||
        value > MAX_OPERATIONAL_WORKER_CONCURRENCY) {
        throw new Error(`CVG_WORKER_CONCURRENCY must be an integer between 1 and ${MAX_OPERATIONAL_WORKER_CONCURRENCY}`);
    }
    return value;
}
function parseOperationalWorkerAttempts(raw) {
    if (!raw?.trim())
        return undefined;
    const value = Number(raw);
    if (!Number.isSafeInteger(value) || value < 1 || value > 100) {
        throw new Error('CVG_WORKER_MAX_ATTEMPTS must be an integer between 1 and 100');
    }
    return value;
}
/**
 * Neutral Phase 2 worker composition. It has no Secretary/product adapter and
 * uses only a deterministic model. The tool registry stays empty unless the
 * explicit controlled synthetic-effect fixture is enabled.
 */
function createOperationalHarnessWorker(env, options = {}) {
    if (env.NODE_ENV === 'production') {
        throw new Error('Neutral operational harness worker remains controlled-only; production is forbidden');
    }
    const faultInjector = createOperationalHarnessFaultInjector(env);
    const runtimeProfile = (0, phase3_synthetic_agent_ts_1.parsePhase3RuntimeProfile)(env.CVG_WORKER_RUNTIME_PROFILE);
    const iterativeScenario = (0, phase3_synthetic_agent_ts_1.parsePhase3Scenario)(env.CVG_WORKER_ITERATIVE_SCENARIO);
    if (runtimeProfile === 'iterative' && !iterativeScenario) {
        throw new Error('CVG_WORKER_RUNTIME_PROFILE=iterative requires CVG_WORKER_ITERATIVE_SCENARIO');
    }
    const syntheticEffectEnabled = parseOperationalSyntheticEffect(env[exports.OPERATIONAL_SYNTHETIC_EFFECT_ENV], env);
    const tenantId = platform_1.TenantIdSchema.parse(env.CVG_WORKER_TENANT_ID);
    const maxAttempts = parseOperationalWorkerAttempts(env.CVG_WORKER_MAX_ATTEMPTS);
    const schemaName = env.POSTGRES_SCHEMA?.trim() || undefined;
    assertSafeSchemaName(schemaName);
    let pool = null;
    const store = options.store ??
        (env.DATABASE_URL
            ? ((pool = new pg_1.Pool({
                connectionString: env.DATABASE_URL,
                ...(schemaName ? { options: `-c search_path=${schemaName}` } : {})
            })),
                new persistence_1.PostgresOperationalExecutionStore(pool, maxAttempts !== undefined ? { maxAttempts } : {}))
            : (0, harness_1.createInMemoryOperationalExecutionStore)(maxAttempts !== undefined ? { maxAttempts } : {}));
    const approvalAuthority = pool
        ? new persistence_1.PostgresApprovalAuthority(pool)
        : new persistence_1.ApprovalEngine();
    const effectJournal = pool
        ? new persistence_1.PostgresOperationalEffectJournal(pool)
        : syntheticEffectEnabled || runtimeProfile === 'iterative'
            ? new harness_1.InMemoryEffectJournal()
            : undefined;
    const stepStore = runtimeProfile === 'iterative'
        ? pool
            ? new persistence_1.PostgresExecutionStepStore(pool)
            : new harness_1.InMemoryExecutionStepStore()
        : null;
    const approvalEngine = new persistence_1.DurableApprovalEngineAdapter(approvalAuthority);
    const harnessOptions = options.harnessOptions ??
        (runtimeProfile === 'iterative' && iterativeScenario && stepStore
            ? (record) => (0, phase3_synthetic_agent_ts_1.createPhase3IterativeHarnessOptions)({
                scenario: iterativeScenario,
                stepStore,
                approvals: approvalEngine,
                ...(record.resume ? { resumeKind: record.resume.kind } : {}),
                ...(options.syntheticEffectObserver
                    ? { observer: options.syntheticEffectObserver }
                    : {})
            })
            : createSyntheticHarnessOptions(approvalEngine, syntheticEffectEnabled
                ? (0, phase2_synthetic_effect_ts_1.createPhase2SyntheticEffectRegistry)(options.syntheticEffectObserver)
                : { list: () => [], resolve: () => undefined }));
    let closed = false;
    const workerOptions = {
        store,
        workerId: env.CVG_WORKER_ID?.trim() || 'worker-operational-harness',
        tenantId,
        ...(env.CVG_WORKER_LEASE_MS
            ? { leaseMs: Number(env.CVG_WORKER_LEASE_MS) }
            : {}),
        harnessOptions,
        ...(effectJournal ? { effectJournal } : {}),
        ...(faultInjector ? { faultInjector } : {})
    };
    const worker = new harness_1.OperationalExecutionWorker(workerOptions);
    return {
        worker,
        store,
        approvalAuthority,
        effectJournal: effectJournal ?? null,
        stepStore,
        runtimeProfile,
        tenantId,
        pool,
        close: async () => {
            if (closed)
                return;
            closed = true;
            if (pool)
                await pool.end();
        }
    };
}
async function assertOperationalHarnessPostgresPreflight(runtime) {
    if (!runtime.pool)
        return;
    await (0, postgres_role_preflight_ts_1.assertPostgresWorkerPreflight)(runtime.pool, {
        tenantId: runtime.tenantId,
        criticalTables: postgres_role_preflight_ts_1.OPERATIONAL_HARNESS_CRITICAL_TABLES,
        requiredMigrations: postgres_role_preflight_ts_1.OPERATIONAL_HARNESS_REQUIRED_MIGRATIONS
    });
}
/**
 * The memory composition has no database/RLS claim surface. Keep that
 * boundary explicit so the entrypoint cannot accidentally describe it as a
 * durable preflight; production is rejected when the runtime is constructed.
 */
function assertOperationalHarnessProfilePreflight(runtime) {
    if (runtime.pool)
        return;
    if (runtime.runtimeProfile === 'single_pass' && runtime.stepStore !== null) {
        throw new Error('Single-pass operational harness memory profile cannot expose an iterative step store');
    }
    if (runtime.runtimeProfile === 'iterative' && runtime.stepStore === null) {
        throw new Error('Iterative operational harness memory profile requires an in-memory step store');
    }
    if (!runtime.worker || !runtime.store || !runtime.approvalAuthority) {
        throw new Error('Operational harness memory profile is missing its synthetic execution boundary');
    }
}
function createSyntheticHarnessOptions(approvals, tools) {
    return {
        orchestrator: new harness_orchestrator_1.SinglePassOrchestrator(),
        modelGateway: {
            complete: async () => ({
                text: 'Acknowledged.',
                provider: 'deterministic-v1',
                model: 'synthetic-fixture',
                inputTokens: 1,
                outputTokens: 1,
                costUsd: 0
            })
        },
        policy: {
            evaluate: async () => ({
                outcome: 'ALLOW',
                reason: 'synthetic controlled policy',
                policyVersion: 'synthetic-v1'
            })
        },
        approvals,
        tools,
        audit: {
            append: async () => undefined
        },
        telemetry: {
            record: () => undefined
        }
    };
}
function assertSafeSchemaName(schemaName) {
    if (schemaName && !/^[a-z][a-z0-9_]{0,62}$/.test(schemaName)) {
        throw new Error('POSTGRES_SCHEMA must be a safe lowercase identifier');
    }
}
//# sourceMappingURL=operational-harness-worker.js.map