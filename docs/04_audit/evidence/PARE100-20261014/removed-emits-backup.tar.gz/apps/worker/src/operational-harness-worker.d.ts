import { Pool } from 'pg';
import { OperationalExecutionWorker, type EffectJournal, type OperationalExecutionStore, type OperationalHarnessOptions, type OperationalExecutionFaultPoint } from '@cvg/harness';
import type { ApprovalAuthority } from '@cvg/persistence';
import type { ExecutionStepStore } from '@cvg/harness';
import { type TenantId } from '@cvg/platform';
import type { SyntheticEffectObserver } from './phase2-synthetic-effect.ts';
export declare const OPERATIONAL_HARNESS_WORKER_RUNTIME: "operational-harness";
export declare const OPERATIONAL_FAULT_POINT_AFTER_CLAIM: "AFTER_CLAIM";
export declare const OPERATIONAL_SYNTHETIC_EFFECT_ENV: "CVG_WORKER_SYNTHETIC_EFFECT";
export type OperationalHarnessFaultInjector = (point: OperationalExecutionFaultPoint) => Promise<void>;
interface ControlledWorkerSafetyEnv {
    readonly NODE_ENV?: string;
    readonly CVG_WORKER_CONTROLLED_MODE?: string;
}
export declare function parseOperationalFaultPoint(raw: string | undefined, env?: ControlledWorkerSafetyEnv): OperationalExecutionFaultPoint | undefined;
export declare function parseOperationalSyntheticEffect(raw: string | undefined, env?: ControlledWorkerSafetyEnv): boolean;
export declare function parseOperationalWorkerIdleWait(raw: string | undefined, fallback?: number): number;
export declare function parseOperationalWorkerPollInterval(raw: string | undefined, fallback?: number): number;
export declare function createOperationalHarnessFaultInjector(env: NodeJS.ProcessEnv, terminate?: (signal: NodeJS.Signals) => void): OperationalHarnessFaultInjector | undefined;
export declare function parseOperationalWorkerConcurrency(raw: string | undefined, fallback?: number): number;
export interface OperationalHarnessWorkerRuntime {
    readonly worker: OperationalExecutionWorker;
    readonly store: OperationalExecutionStore;
    readonly approvalAuthority: ApprovalAuthority;
    readonly effectJournal: Pick<EffectJournal, 'get'> | null;
    readonly stepStore: ExecutionStepStore | null;
    readonly runtimeProfile: 'single_pass' | 'iterative';
    readonly tenantId: TenantId;
    readonly pool: Pool | null;
    close(): Promise<void>;
}
/**
 * Neutral Phase 2 worker composition. It has no Secretary/product adapter and
 * uses only a deterministic model. The tool registry stays empty unless the
 * explicit controlled synthetic-effect fixture is enabled.
 */
export declare function createOperationalHarnessWorker(env: NodeJS.ProcessEnv, options?: {
    readonly store?: OperationalExecutionStore;
    readonly harnessOptions?: OperationalHarnessOptions;
    readonly syntheticEffectObserver?: SyntheticEffectObserver;
}): OperationalHarnessWorkerRuntime;
export declare function assertOperationalHarnessPostgresPreflight(runtime: OperationalHarnessWorkerRuntime): Promise<void>;
/**
 * The memory composition has no database/RLS claim surface. Keep that
 * boundary explicit so the entrypoint cannot accidentally describe it as a
 * durable preflight; production is rejected when the runtime is constructed.
 */
export declare function assertOperationalHarnessProfilePreflight(runtime: OperationalHarnessWorkerRuntime): void;
export {};
