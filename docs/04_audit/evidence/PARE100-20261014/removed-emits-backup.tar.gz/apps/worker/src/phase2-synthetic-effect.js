"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PHASE2_SYNTHETIC_EFFECT_TOOL_VERSION = exports.PHASE2_SYNTHETIC_EFFECT_TOOL_ID = void 0;
exports.createPhase2SyntheticEffectTool = createPhase2SyntheticEffectTool;
exports.createPhase2SyntheticEffectRegistry = createPhase2SyntheticEffectRegistry;
exports.PHASE2_SYNTHETIC_EFFECT_TOOL_ID = 'synthetic.phase2-effect';
exports.PHASE2_SYNTHETIC_EFFECT_TOOL_VERSION = 'v1';
/**
 * Controlled Phase 2 fixture. The executor has no network or product
 * dependency; durability is supplied by the journal wrapper at the worker
 * boundary. Keeping the executor deterministic makes replay assertions
 * inspectable without introducing a fake external system.
 */
function createPhase2SyntheticEffectTool(observe) {
    return {
        id: exports.PHASE2_SYNTHETIC_EFFECT_TOOL_ID,
        version: exports.PHASE2_SYNTHETIC_EFFECT_TOOL_VERSION,
        description: 'Controlled synthetic Phase 2 durable-effect fixture',
        inputSchema: { type: 'object' },
        outputSchema: {
            type: 'object',
            properties: {
                fixture: { const: 'phase2' },
                applied: { const: true }
            },
            required: ['fixture', 'applied'],
            additionalProperties: false
        },
        risk: 'LOW',
        sideEffect: 'WRITE',
        idempotent: false,
        requiresApproval: false,
        execute: async (_input, context) => {
            observe?.(context);
            return {
                status: 'SUCCEEDED',
                output: { fixture: 'phase2', applied: true }
            };
        }
    };
}
function createPhase2SyntheticEffectRegistry(observe) {
    const tool = createPhase2SyntheticEffectTool(observe);
    return {
        list: () => [tool],
        resolve: (toolId, version) => toolId === tool.id && (version === undefined || version === tool.version)
            ? tool
            : undefined
    };
}
//# sourceMappingURL=phase2-synthetic-effect.js.map