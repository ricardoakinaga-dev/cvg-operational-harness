"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_HOMOLOG_HEALTH_INTERVAL_MS = exports.DEFAULT_HOMOLOG_SWEEP_INTERVAL_MS = exports.HOMOLOG_HEALTH_INTERVAL_ENV = exports.HOMOLOG_SWEEP_INTERVAL_ENV = exports.HOMOLOG_SYNTHETIC_ONLY_ENV = exports.OPERATIONAL_HARNESS_HOMOLOG_RUNTIME = void 0;
exports.parseHomologConfig = parseHomologConfig;
exports.assertHomologHealthPreflight = assertHomologHealthPreflight;
exports.reconcileStuckApprovalDecisions = reconcileStuckApprovalDecisions;
exports.runHomologSweepTick = runHomologSweepTick;
exports.runOperationalHarnessHomologWorker = runOperationalHarnessHomologWorker;
const platform_1 = require("@cvg/platform");
const shared_1 = require("@cvg/shared");
const agent_runtime_1 = require("@cvg/agent-runtime");
const agent_core_1 = require("@cvg/agent-core");
const persistence_1 = require("@cvg/persistence");
const worker_observability_ts_1 = require("./worker-observability.js");
const health_ts_1 = require("./health.js");
const operational_harness_worker_ts_1 = require("./operational-harness-worker.js");
const readiness_ts_1 = require("./readiness.js");
exports.OPERATIONAL_HARNESS_HOMOLOG_RUNTIME = 'operational-harness-homolog';
exports.HOMOLOG_SYNTHETIC_ONLY_ENV = 'CVG_HOMOLOG_SYNTHETIC_ONLY';
exports.HOMOLOG_SWEEP_INTERVAL_ENV = 'CVG_HOMOLOG_SWEEP_INTERVAL_MS';
exports.HOMOLOG_HEALTH_INTERVAL_ENV = 'CVG_HOMOLOG_HEALTH_INTERVAL_MS';
exports.DEFAULT_HOMOLOG_SWEEP_INTERVAL_MS = 5_000;
exports.DEFAULT_HOMOLOG_HEALTH_INTERVAL_MS = 1_000;
function parseHomologConfig(env) {
    if (env.NODE_ENV === 'production') {
        throw new Error('Homologation worker is forbidden in production; production remains NO_GO');
    }
    if (env[exports.HOMOLOG_SYNTHETIC_ONLY_ENV] !== 'true') {
        throw new Error(`${exports.HOMOLOG_SYNTHETIC_ONLY_ENV}=true is required to arm the homologation worker`);
    }
    if (!env.DATABASE_URL?.trim()) {
        throw new Error('DATABASE_URL is required for the homologation worker');
    }
    if (env.POSTGRES_RLS_ENFORCEMENT !== 'true') {
        throw new Error('POSTGRES_RLS_ENFORCEMENT=true is required for the homologation worker');
    }
    if (env.CVG_WORKER_CONTROLLED_MODE !== 'true') {
        throw new Error('CVG_WORKER_CONTROLLED_MODE=true is required for the homologation worker');
    }
    const tenantId = platform_1.TenantIdSchema.parse(env.CVG_WORKER_TENANT_ID);
    const rawSweep = env[exports.HOMOLOG_SWEEP_INTERVAL_ENV]?.trim();
    const sweepIntervalMs = rawSweep === undefined || rawSweep === ''
        ? exports.DEFAULT_HOMOLOG_SWEEP_INTERVAL_MS
        : Number(rawSweep);
    if (!Number.isInteger(sweepIntervalMs) || sweepIntervalMs <= 0) {
        throw new Error(`${exports.HOMOLOG_SWEEP_INTERVAL_ENV} must be a positive integer`);
    }
    const rawHealth = env[exports.HOMOLOG_HEALTH_INTERVAL_ENV]?.trim();
    const healthIntervalMs = rawHealth === undefined || rawHealth === ''
        ? exports.DEFAULT_HOMOLOG_HEALTH_INTERVAL_MS
        : Number(rawHealth);
    if (!Number.isInteger(healthIntervalMs) || healthIntervalMs <= 0) {
        throw new Error(`${exports.HOMOLOG_HEALTH_INTERVAL_ENV} must be a positive integer`);
    }
    return { tenantId, sweepIntervalMs, healthIntervalMs };
}
function healthFailureDetail(report) {
    return report.checks
        .map((check) => `${check.name}:${check.status}:${check.detail}`)
        .join(', ');
}
async function assertHomologHealthPreflight(pool, tenantId, timeoutMs = 1_000) {
    const report = await (0, health_ts_1.checkHomologHealth)(pool, tenantId, timeoutMs);
    if (!report.healthy) {
        throw new Error(`Homologation worker health preflight failed: ${healthFailureDetail(report)}`);
    }
}
/**
 * Recovery tick for approvals decided while their execution stayed waiting
 * (crash between decision and resume/audit). Every step is idempotent, so
 * the tick converges without risking a second effect.
 */
async function reconcileStuckApprovalDecisions(pool, tenantId, runtime, limit = 25) {
    const stuck = await (0, persistence_1.withTenantContext)(pool, tenantId, (client) => client.query(`SELECT e.id AS execution_id, e.approval_id,
               CASE WHEN a.status = 'APPROVED' THEN 'APPROVED' ELSE 'REJECTED' END AS decision
       FROM operational_executions AS e
       INNER JOIN runtime_approvals AS a
         ON a.tenant_id = e.tenant_id AND a.approval_id = e.approval_id
       WHERE e.tenant_id = NULLIF(current_setting('cvg.tenant_id', true), '')
          AND a.status IN ('APPROVED', 'REJECTED')
          AND NOT EXISTS (
            SELECT 1
            FROM audit_events AS audit
            WHERE audit.tenant_id = e.tenant_id
              AND audit.type = 'approval_decision'
              AND audit.payload->>'approvalId' = a.approval_id
              AND audit.payload->>'decision' =
                CASE WHEN a.status = 'APPROVED' THEN 'approved' ELSE 'rejected' END
          )
       ORDER BY e.updated_at ASC
       LIMIT $1`, [limit]));
    const audit = new persistence_1.TenantScopedPostgresRuntimeRepository(pool);
    let reconciled = 0;
    for (const row of stuck.rows) {
        const decision = row.decision === 'APPROVED' ? 'APPROVED' : 'REJECTED';
        const approval = await runtime.approvalAuthority.get(tenantId, row.approval_id);
        await (0, agent_core_1.reconcileApprovalDecision)({
            getApproval: () => approval,
            resolveExecution: (input) => runtime.store.resolveApproval(input),
            appendAudit: (event, tenant) => audit.appendAudit({
                ...event,
                payload: {
                    ...event.payload,
                    tenantId: tenant
                }
            }, tenant)
        }, {
            tenantId: tenantId,
            executionId: row.execution_id,
            approvalId: row.approval_id,
            decision
        });
        reconciled += 1;
    }
    return reconciled;
}
async function runHomologSweepTick(runtime, tenantId) {
    const now = new Date();
    const approvals = await (0, agent_runtime_1.sweepExpiredApprovals)({
        approvals: runtime.approvalAuthority,
        tenantId: tenantId,
        now,
        ttlMs: 60_000
    });
    let reconciled = 0;
    if (runtime.pool) {
        reconciled = await reconcileStuckApprovalDecisions(runtime.pool, tenantId, runtime);
    }
    return {
        approvalsReleased: approvals.released,
        approvalsUncertain: approvals.uncertain,
        approvalsReconciled: reconciled
    };
}
async function runOperationalHarnessHomologWorker(env) {
    const { tenantId, sweepIntervalMs, healthIntervalMs } = parseHomologConfig(env);
    const runtime = (0, operational_harness_worker_ts_1.createOperationalHarnessWorker)(env);
    if (!runtime.pool) {
        await runtime.close();
        throw new Error('Homologation worker requires durable PostgreSQL; memory mode is refused');
    }
    const telemetry = (0, worker_observability_ts_1.createJsonWorkerTelemetry)();
    const workerId = env.CVG_WORKER_ID?.trim() || 'worker-homolog';
    const readiness = (0, readiness_ts_1.createWorkerReadiness)({
        onTransition: (transition) => telemetry.log('worker.readiness', {
            workerId,
            status: transition.to,
            reason: transition.reason,
            readinessAt: transition.at
        })
    });
    let cleanupPromise;
    const cleanup = (reason) => {
        if (cleanupPromise)
            return cleanupPromise;
        cleanupPromise = (async () => {
            readiness.markNotReady(reason);
            runtime.worker.requestStop();
            await runtime.worker.stop();
            await runtime.close();
            readiness.markStopped(reason === 'shutdown_started' ? 'shutdown_completed' : 'run_completed');
        })();
        return cleanupPromise;
    };
    const shutdown = (0, shared_1.createShutdownController)({
        close: () => cleanup('shutdown_started'),
        exit: (code) => {
            process.exitCode = code;
        },
        timeoutMs: 15_000,
        log: (event) => {
            if (event.type !== 'shutdown.started') {
                console.error(JSON.stringify({ event: event.type, signal: event.signal }));
            }
        }
    });
    shutdown.install(process);
    const idleWaitMs = (0, operational_harness_worker_ts_1.parseOperationalWorkerIdleWait)(env.CVG_WORKER_IDLE_WAIT_MS);
    const pollIntervalMs = (0, operational_harness_worker_ts_1.parseOperationalWorkerPollInterval)(env.CVG_WORKER_POLL_INTERVAL_MS);
    const maxEventsRaw = env.CVG_WORKER_MAX_EVENTS?.trim();
    const maxEvents = maxEventsRaw === undefined || maxEventsRaw === ''
        ? Number.POSITIVE_INFINITY
        : Number(maxEventsRaw);
    let processed = 0;
    let lastSweep = 0;
    let lastHealth = 0;
    try {
        await (0, operational_harness_worker_ts_1.assertOperationalHarnessPostgresPreflight)(runtime);
        await assertHomologHealthPreflight(runtime.pool, tenantId, Math.min(healthIntervalMs, 1_000));
        if (shutdown.isShuttingDown())
            return;
        readiness.markReady('startup_preflight_passed');
        console.log(JSON.stringify({
            event: 'worker.homolog_ready',
            workerId,
            processed: 0,
            durable: true,
            externalEffects: false,
            syntheticOnly: true,
            runtime: exports.OPERATIONAL_HARNESS_HOMOLOG_RUNTIME
        }));
        lastHealth = Date.now();
        const startMs = Date.now();
        const idleDeadlineMs = idleWaitMs > 0 ? startMs + idleWaitMs : Number.POSITIVE_INFINITY;
        while (!shutdown.isShuttingDown()) {
            if (processed >= maxEvents)
                break;
            const now = Date.now();
            if (now - lastHealth >= healthIntervalMs) {
                lastHealth = now;
                const health = await (0, health_ts_1.checkHomologHealth)(runtime.pool, tenantId, Math.min(healthIntervalMs, 1_000));
                if (shutdown.isShuttingDown())
                    break;
                telemetry.log('worker.homolog_health', {
                    workerId,
                    healthy: health.healthy,
                    checks: health.checks.map((check) => `${check.name}:${check.status}`)
                }, health.healthy ? 'info' : 'warn');
                if (!health.healthy) {
                    telemetry.log('worker.homolog_unhealthy', {
                        workerId,
                        checks: health.checks.map((check) => `${check.name}:${check.status}`)
                    }, 'warn');
                    readiness.markNotReady('dependency_health_failed');
                    continue;
                }
                if (!readiness.isReady()) {
                    readiness.markReady('dependencies_recovered');
                }
            }
            if (!readiness.isReady()) {
                await new Promise((resolve) => setTimeout(resolve, pollIntervalMs));
                continue;
            }
            if (shutdown.isShuttingDown())
                break;
            telemetry.log('worker.homolog_process_next', { workerId });
            const result = await runtime.worker.processNext();
            if (shutdown.isShuttingDown())
                break;
            if (result.kind === 'processed') {
                processed += 1;
            }
            else if (Date.now() > idleDeadlineMs) {
                break;
            }
            const sweepNow = Date.now();
            if (sweepNow - lastSweep >= sweepIntervalMs) {
                lastSweep = sweepNow;
                try {
                    const sweep = await runHomologSweepTick(runtime, tenantId);
                    telemetry.log('worker.homolog_sweep', {
                        workerId,
                        released: sweep.approvalsReleased,
                        uncertain: sweep.approvalsUncertain,
                        reconciled: sweep.approvalsReconciled
                    });
                }
                catch (error) {
                    telemetry.log('worker.homolog_sweep_failed', {
                        workerId,
                        error: error instanceof Error ? error.message : 'unknown'
                    });
                }
            }
            if (result.kind !== 'processed') {
                await new Promise((resolve) => setTimeout(resolve, pollIntervalMs));
            }
        }
        if (!shutdown.isShuttingDown()) {
            console.log(JSON.stringify({
                event: 'worker.homolog_completed',
                workerId,
                processed,
                durable: true,
                externalEffects: false,
                syntheticOnly: true,
                runtime: exports.OPERATIONAL_HARNESS_HOMOLOG_RUNTIME
            }));
        }
    }
    catch (error) {
        if (shutdown.isShuttingDown())
            return;
        throw error;
    }
    finally {
        await cleanup(shutdown.isShuttingDown() ? 'shutdown_started' : 'run_completed');
    }
}
//# sourceMappingURL=homolog-worker.js.map