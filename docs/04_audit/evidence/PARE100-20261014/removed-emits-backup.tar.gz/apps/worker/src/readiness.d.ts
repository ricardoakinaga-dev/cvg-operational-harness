export type WorkerReadinessStatus = 'not_ready' | 'ready' | 'stopped';
export interface WorkerReadinessTransition {
    from: WorkerReadinessStatus;
    to: WorkerReadinessStatus;
    reason: string;
    at: string;
}
export interface WorkerReadinessOptions {
    clock?: () => Date;
    onTransition?: (transition: WorkerReadinessTransition) => void;
}
export interface WorkerReadiness {
    status(): WorkerReadinessStatus;
    isReady(): boolean;
    markReady(reason: string): boolean;
    markNotReady(reason: string): boolean;
    markStopped(reason: string): boolean;
}
/**
 * Small fail-closed lifecycle boundary for consumers. A transition is
 * published before it is committed so an exporter/sink failure cannot leave
 * the process internally ready while the readiness signal was lost.
 */
export declare function createWorkerReadiness(options?: WorkerReadinessOptions): WorkerReadiness;
