import type { ToolDefinition, ToolExecutionContext, ToolRegistry } from '@cvg/harness-contracts';
export declare const PHASE2_SYNTHETIC_EFFECT_TOOL_ID = "synthetic.phase2-effect";
export declare const PHASE2_SYNTHETIC_EFFECT_TOOL_VERSION = "v1";
export type SyntheticEffectObserver = (context: ToolExecutionContext) => void;
/**
 * Controlled Phase 2 fixture. The executor has no network or product
 * dependency; durability is supplied by the journal wrapper at the worker
 * boundary. Keeping the executor deterministic makes replay assertions
 * inspectable without introducing a fake external system.
 */
export declare function createPhase2SyntheticEffectTool(observe?: SyntheticEffectObserver): ToolDefinition;
export declare function createPhase2SyntheticEffectRegistry(observe?: SyntheticEffectObserver): ToolRegistry;
