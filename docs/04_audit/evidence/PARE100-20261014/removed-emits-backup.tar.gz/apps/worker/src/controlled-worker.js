"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CONTROLLED_OUTBOX_EVENT_TYPES = void 0;
exports.createControlledWorker = createControlledWorker;
exports.createControlledDispatch = createControlledDispatch;
const process_outbox_event_ts_1 = require("./jobs/process-outbox-event.js");
Object.defineProperty(exports, "CONTROLLED_OUTBOX_EVENT_TYPES", { enumerable: true, get: function () { return process_outbox_event_ts_1.CONTROLLED_OUTBOX_EVENT_TYPES; } });
function createControlledWorker(options) {
    const workerId = options.workerId.trim();
    if (!workerId)
        throw new Error('Controlled worker id is required');
    const dispatch = createControlledDispatch(options.handlers);
    const processNext = async (eventId) => (0, process_outbox_event_ts_1.processOutboxEvent)({
        tenantId: options.tenantId,
        workerId,
        adapter: options.adapter,
        ...(eventId ? { eventId } : {}),
        ...(options.leaseMs ? { leaseMs: options.leaseMs } : {}),
        ...(options.takeoverActive !== undefined
            ? { takeoverActive: options.takeoverActive }
            : {}),
        effect: dispatch
    });
    const drain = async (maxEvents = 1) => {
        if (!Number.isInteger(maxEvents) || maxEvents <= 0 || maxEvents > 100) {
            throw new Error('Controlled worker drain limit must be between 1 and 100');
        }
        const results = [];
        for (let index = 0; index < maxEvents; index += 1) {
            const result = await (0, process_outbox_event_ts_1.processOutboxEvent)({
                tenantId: options.tenantId,
                workerId,
                adapter: options.adapter,
                ...(options.leaseMs ? { leaseMs: options.leaseMs } : {}),
                ...(options.takeoverActive !== undefined
                    ? { takeoverActive: options.takeoverActive }
                    : {}),
                effect: dispatch
            });
            if (!result)
                break;
            results.push(result);
        }
        return { processed: results.length, results };
    };
    return { processNext, drain };
}
function createControlledDispatch(handlers) {
    if (typeof handlers.inboundProcess !== 'function' ||
        typeof handlers.messageOutbound !== 'function') {
        throw new Error('Controlled worker handlers are required');
    }
    return (event) => {
        switch (event.type) {
            case 'inbound.process':
                return handlers.inboundProcess(event);
            case 'message.outbound':
                return handlers.messageOutbound(event);
            default:
                throw new Error(`Unsupported controlled outbox event: ${event.type}`);
        }
    };
}
//# sourceMappingURL=controlled-worker.js.map