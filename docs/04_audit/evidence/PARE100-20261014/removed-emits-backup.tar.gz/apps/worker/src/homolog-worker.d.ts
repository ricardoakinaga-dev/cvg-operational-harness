/**
 * AUD19-008 — durable homologation worker composition.
 *
 * `CVG_WORKER_RUNTIME=operational-harness-homolog` runs the neutral
 * operational harness against durable PostgreSQL with periodic sweeps and
 * approval-convergence recovery, restricted to synthetic homologation:
 *
 * - explicit arming (`CVG_HOMOLOG_SYNTHETIC_ONLY=true`) is required;
 * - `NODE_ENV=production` refuses to start (production stays `NO_GO`);
 * - `DATABASE_URL` is required (memory mode is refused: homologation
 *   without durability proves nothing);
 * - the tool surface is the synthetic empty registry (no tool resolves,
 *   no real effect is possible).
 *
 * Rollback is configuration-only: change `CVG_WORKER_RUNTIME` back.
 */
import { Pool } from 'pg';
import { type TenantId } from '@cvg/platform';
import { type PostgresPoolLike } from '@cvg/persistence';
import { type OperationalHarnessWorkerRuntime } from './operational-harness-worker.ts';
export declare const OPERATIONAL_HARNESS_HOMOLOG_RUNTIME: "operational-harness-homolog";
export declare const HOMOLOG_SYNTHETIC_ONLY_ENV = "CVG_HOMOLOG_SYNTHETIC_ONLY";
export declare const HOMOLOG_SWEEP_INTERVAL_ENV = "CVG_HOMOLOG_SWEEP_INTERVAL_MS";
export declare const HOMOLOG_HEALTH_INTERVAL_ENV = "CVG_HOMOLOG_HEALTH_INTERVAL_MS";
export declare const DEFAULT_HOMOLOG_SWEEP_INTERVAL_MS = 5000;
export declare const DEFAULT_HOMOLOG_HEALTH_INTERVAL_MS = 1000;
export interface HomologSweepResult {
    approvalsReleased: number;
    approvalsUncertain: number;
    approvalsReconciled: number;
}
export declare function parseHomologConfig(env: NodeJS.ProcessEnv): {
    tenantId: TenantId;
    sweepIntervalMs: number;
    healthIntervalMs: number;
};
export declare function assertHomologHealthPreflight(pool: PostgresPoolLike, tenantId: TenantId, timeoutMs?: number): Promise<void>;
/**
 * Recovery tick for approvals decided while their execution stayed waiting
 * (crash between decision and resume/audit). Every step is idempotent, so
 * the tick converges without risking a second effect.
 */
export declare function reconcileStuckApprovalDecisions(pool: Pool, tenantId: TenantId, runtime: OperationalHarnessWorkerRuntime, limit?: number): Promise<number>;
export declare function runHomologSweepTick(runtime: OperationalHarnessWorkerRuntime, tenantId: TenantId): Promise<HomologSweepResult>;
export declare function runOperationalHarnessHomologWorker(env: NodeJS.ProcessEnv): Promise<void>;
